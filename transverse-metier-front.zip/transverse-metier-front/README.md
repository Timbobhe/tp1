# Transverse-metier-front

## CI
https://master-1.pacific.appli/job/A1282/job/transverse-metier-front/

## Librairie Angular
https://www.willtaylor.blog/complete-guide-to-angular-libraries/

## Transverse-metier-ng
En mode DEV :

```cmd
cd tranverse-metier-front
npm run build_lib_trm

cd dist/transverse-metier-ng
npm link

cd ../.. (tranverse-metier-front)
npm link @ag2rlamondiale/transverse-metier-ng

cd ecrs-front
npm link @ag2rlamondiale/transverse-metier-ng
npm install
```

### Règles à respecter (pour ne pas perdre du temps)
1. Tout ce qui est injectable (en argument des constructeurs) ne doit pas être importés avec un index.ts mais explicitement.

```ts
import { APP_CONFIG, AppConfig } from '../../../../models';// <- KO
import { APP_CONFIG, AppConfig } from '../../../../models/app.model';// <- OK
```

2. Pareil, tout ce qui est "déclaré" dans les NgModule doit être importé explicitement

## Développement

### Assets
Pour faire référence aux Assets

1. Déclaration des Assets dans le fichier `projects/transverse-metier-ng/ng-package.json` :` "styleIncludePaths": ["./src/assets"]`
```json
{
  "$schema": "../../node_modules/ng-packagr/ng-package.schema.json",
  "dest": "../../dist/transverse-metier-ng",
  "lib": {
    "entryFile": "src/public-api.ts",
    "styleIncludePaths": ["./src/assets"]
  }
}
```

2. Faire référence aux assets dans les SCSS : chemin relatif au `styleIncludePaths`

```scss
.p-accordion-toggle-icon {
  background: url('icon-2019/haut.svg') no-repeat -5px -5px;
}
```

3. Avec les `@import` de SASS : chemin relatif au `styleIncludePaths`

```scss
@import "styles/variables";
```

Pour les TU, dans `angular.json`, il faut rajouter le paramétrage : `stylePreprocessorOptions`

```json
 "transverse-metier-ng": {

    "test": {
      "builder": "@angular-devkit/build-angular:karma",
      "options": {
        "main": "projects/transverse-metier-ng/src/test.ts",
        "tsConfig": "projects/transverse-metier-ng/tsconfig.spec.json",
        "karmaConfig": "projects/transverse-metier-ng/karma.conf.js",
        "stylePreprocessorOptions": {
          "includePaths": [
            "projects/transverse-metier-ng/src/assets"
          ]
        }
      }
    }
}
```


### Composants partagés
- [ButtonCTA](projects/transverse-metier-ng/src/lib/shared/components/button-cta/README.md) : Bouton CTA générique
### node-sass
Récuperer la version compilée directement depuis : https://github.com/sass/node-sass/releases/tag/v4.12.0
_Pas la peine d'essayer de compiler .Net framework 2/VS 2005, et .... qui ne marche pas._
- Pour node x64 (v10.18.1)
- https://github.com/sass/node-sass/releases/download/v4.12.0/win32-x64-67_binding.node
- copier dans "./node_modules/node-sass/vendor/win32-x64-64/binding.node"
### Snippets disponibles
Dans le fichier `.vscode/redux.code-snippets` les snippets suivantes sont disponibles :
- `red` : Construit un nouveau Reducer
- `act` :  Construit une nouvelle Action
- `ared` : Construit un nouveau Reducer s'appuyant sur les ApiAction [redux-api-ng](https://git-prd.server.lan/A1282/redux-api-ng)
- `aact` : Construit une nouvelle Action s'appuyant sur les ApiAction [redux-api-ng](https://git-prd.server.lan/A1282/redux-api-ng)
  Pour créer le *Body* des snippets, à partir d'un fichier *modèle* exécuter :
```cmd
node .vscode\extract_body_snippet.js CHEMIN_VERS_LE_FICHIER
```
Le contenu est copié dans le presse-papier, à coller dans le body de la snippet.
