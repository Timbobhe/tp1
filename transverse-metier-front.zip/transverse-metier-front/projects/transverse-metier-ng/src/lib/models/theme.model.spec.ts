/* tslint:disable:no-unused-variable */
import { Theming } from './theme.model';


describe('theme.model', () => {

  it('should create minimal Theme', () => {
    const theme = Theming.Theme.from({
      name: 'test',
      palette: {
        primary: {main: 'blue', contrastText: '#FFF'},
        secondary: {main: 'orange', contrastText: '#FFF'},
        info: {main: 'yellow', contrastText: '#000'},
        text: {primary: '#000', disabled: 'grey'}
      },
      typography: {
        default: {
          fontFamily: 'Arial',
          fontWeight: 'normal',
          fontSize: '12px',
          lineHeight: 'normal'
        },
        h1: {fontSize: '20px'},
        h2: {fontSize: '18px'},
        h3: {fontSize: '16px'},
        h4: {fontSize: '14px'},
      }
    });

    expect(theme.palette.primary.main).toEqual('blue');
    expect(theme.palette.secondary.main).toEqual('orange');
    expect(theme.palette.info.main).toEqual('yellow');
    expect(theme.palette.actionPrimary.active.main).toEqual(theme.palette.primary.main);
    expect(theme.palette.actionSecondary.active.main).toEqual(theme.palette.secondary.main);
    expect(theme.palette.link.active).toEqual(theme.palette.primary.main);
    expect(theme.palette.info1.active.main).toEqual(theme.palette.info.main);
    expect(theme.palette.info2.active.main).toEqual(theme.palette.info.main);
    expect(theme.palette.info3.active.main).toEqual(theme.palette.info.main);
    expect(theme.palette.info4.active.main).toEqual(theme.palette.info.main);
    expect(theme.palette.info5.active.main).toEqual(theme.palette.info.main);

    for (let p of ['body1', 'body2', 'subtitle1', 'subtitle2', 'caption', 'button', 'overline']) {
      expect(theme.typography[p].fontFamily).toEqual(theme.typography.default.fontFamily);
      expect(theme.typography[p].fontWeight).toEqual(theme.typography.default.fontWeight);
      expect(theme.typography[p].fontSize).toEqual(theme.typography.default.fontSize);
      expect(theme.typography[p].lineHeight).toEqual(theme.typography.default.lineHeight);
    }


    for (let p of ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']) {
      expect(theme.typography[p].fontFamily).toEqual(theme.typography.default.fontFamily);
      expect(theme.typography[p].fontWeight).toEqual(theme.typography.default.fontWeight);
      expect(theme.typography[p].lineHeight).toEqual(theme.typography.default.lineHeight);
    }

    expect(theme.typography.h1.fontSize).toEqual('20px');
    expect(theme.typography.h2.fontSize).toEqual('18px');
    expect(theme.typography.h3.fontSize).toEqual('16px');
    expect(theme.typography.h4.fontSize).toEqual('14px');
    expect(theme.typography.h5.fontSize).toEqual('14px');
    expect(theme.typography.h6.fontSize).toEqual('14px');

  });

});
