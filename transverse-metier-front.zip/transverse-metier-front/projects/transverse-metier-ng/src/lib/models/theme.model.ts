import { forEachEntry } from '../shared/utils/utils.functions';
import { setCssVariable } from '../shared/utils/css-utils';

export namespace Theming {
  export type Color = string | any;

  export type FonctionName = string;

  export interface Font {
    fontFamily?: string;
    fontWeight?: string;
    fontSize?: string;
    lineHeight?: string;
    letterSpacing?: string;
    textTransform?: FonctionName;
  }

  export interface IPaletteColor {
    main: Color;
    light?: Color;
    dark?: Color;
    contrastText?: Color;
    border?: Color;
  }

  export class PaletteColor implements IPaletteColor {
    main: Color;
    light?: Color;
    dark?: Color;
    contrastText?: Color;
    border?: Color;

    static from(object: IPaletteColor) {
      return Object.assign(new PaletteColor(), object || {}).complete();
    }

    complete() {
      this.light = this.light || this.main;
      this.dark = this.dark || this.main;
      this.border = this.border || this.main;
      return this;
    }
  }

  export interface IActionColor {
    active: IPaletteColor;
    disabled: IPaletteColor;
    hover: IPaletteColor;
  }

  export class ActionColor implements IActionColor {
    active: IPaletteColor;
    disabled: IPaletteColor;
    hover: IPaletteColor;

    static from(object: IActionColor) {
      const obj = object || {active: null, disabled: null, hover: null};
      return Object.assign(new ActionColor(), {
        active: PaletteColor.from(obj.active),
        disabled: PaletteColor.from(obj.disabled),
        hover: PaletteColor.from(obj.hover)
      });
    }
  }

  export interface IInfoColor {
    active: IPaletteColor;
    disabled: IPaletteColor;
  }

  export class InfoColor implements IInfoColor {
    active: IPaletteColor;
    disabled: IPaletteColor;

    static from(object: IInfoColor) {
      const obj = object || {active: null, disabled: null};
      return Object.assign(new ActionColor(), {
        active: PaletteColor.from(obj.active),
        disabled: PaletteColor.from(obj.disabled),
      });
    }
  }


  export interface TextColor {
    primary: Color;
    secondary?: Color;
    disabled: Color;
    hint?: Color;
  }

  export interface LinkColor {
    active: Color;
    hover: Color;
    visited: Color;
  }

  export interface BackgroundColor {
    paper: Color;
    default: Color;
  }

  export class GreyColor {
    '50' = '#fafafa';
    '100' = '#f5f5f5';
    '200' = '#eeeeee';
    '300' = '#e0e0e0';
    '400' = '#bdbdbd';
    '500' = '#9e9e9e';
    '600' = '#757575';
    '700' = '#616161';
    '800' = '#424242';
    '900' = '#212121';
    'A100' = '#d5d5d5';
    'A200' = '#aaaaaa';
    'A400' = '#303030';
    'A700' = '#616161';
  }

  export const greyColors = new GreyColor();


  export class Palette {
    primary: IPaletteColor;
    secondary: IPaletteColor;
    error: IPaletteColor;
    warning: IPaletteColor;
    info: IPaletteColor;
    success: IPaletteColor;
    grey: GreyColor = new GreyColor();
    text: TextColor;
    link: LinkColor;
    divider: Color;
    background: BackgroundColor;
    actionPrimary: IActionColor;
    actionSecondary: IActionColor;
    info1: IInfoColor;
    info2: IInfoColor;
    info3: IInfoColor;
    info4: IInfoColor;
    info5: IInfoColor;

    static from(object: any) {
      const res = new Palette();
      const obj = object || {};
      Object.assign(res, {
        ...obj,
        primary: PaletteColor.from(obj.primary),
        secondary: PaletteColor.from(obj.secondary),
        error: PaletteColor.from(obj.error),
        warning: PaletteColor.from(obj.warning),
        info: PaletteColor.from(obj.info),
        success: PaletteColor.from(obj.success),

        actionPrimary: ActionColor.from(obj.actionPrimary),
        actionSecondary: ActionColor.from(obj.actionSecondary),

        text: {...obj.text},
        link: {...obj.link},
        divider: {...obj.divider},
        background: {...obj.background},

        info1: InfoColor.from(obj.info1),
        info2: InfoColor.from(obj.info2),
        info3: InfoColor.from(obj.info3),
        info4: InfoColor.from(obj.info4),
        info5: InfoColor.from(obj.info5),
      });

      return res;
    }

    dup(): Palette {
      const res = new Palette();
      Object.assign(res, {
        primary: {...this.primary},
        secondary: {...this.secondary},
        error: {...this.error},
        warning: {...this.warning},
        info: {...this.info},
        success: {...this.success},
        grey: {...this.grey},
        text: {...this.text},
        link: {...this.link},
        divider: {...this.divider},
        background: {...this.background},
        actionPrimary: {...this.actionPrimary},
        actionSecondary: {...this.actionSecondary},
        info1: {...this.info1},
        info2: {...this.info2},
        info3: {...this.info3},
        info4: {...this.info4},
        info5: {...this.info5}
      });
      return res;
    }

    complete(): Palette {
      this.secondary = PaletteColor.from({...this.primary, ...this.secondary});

      this.success = PaletteColor.from({...this.info, ...this.success});
      this.warning = PaletteColor.from({...this.success, ...this.warning});
      this.error = PaletteColor.from({...this.warning, ...this.error});

      this.actionPrimary = ActionColor.from({
        active: PaletteColor.from({...this.primary, ...this.actionPrimary.active}),
        disabled: PaletteColor.from({...this.primary, ...this.actionPrimary.disabled}),
        hover: PaletteColor.from({...this.primary, ...this.actionPrimary.hover}),
      });

      this.secondary = PaletteColor.from({...this.primary, ...this.secondary});
      this.link = {
        active: this.actionPrimary.active.main,
        hover: this.actionPrimary.hover.main,
        visited: this.actionPrimary.active.main, ...this.link
      };

      this.divider = this.divider || this.grey['300'];
      this.background = {
        paper: this.background.paper || 'white',
        default: this.background.default || this.grey['200']
      };

      this.actionSecondary = ActionColor.from({
        active: PaletteColor.from({...this.actionPrimary.active, ...this.secondary, ...this.actionSecondary.active}),
        disabled: PaletteColor.from({...this.secondary, ...this.actionPrimary.disabled, ...this.actionSecondary.disabled}),
        hover: PaletteColor.from({...this.secondary, ...this.actionPrimary.hover, ...this.actionSecondary.hover}),
      });

      this.info1 = InfoColor.from({
        active: PaletteColor.from({...this.info, ...this.info1.active}),
        disabled: PaletteColor.from({...this.actionPrimary.disabled, ...this.info1.disabled})
      });

      this.info2 = InfoColor.from({
        active: PaletteColor.from({...this.info1.active, ...this.info2.active}),
        disabled: PaletteColor.from({...this.info1.disabled, ...this.info2.disabled})
      });


      this.info3 = InfoColor.from({
        active: PaletteColor.from({...this.info2.active, ...this.info3.active}),
        disabled: PaletteColor.from({...this.info2.disabled, ...this.info3.disabled})
      });

      this.info4 = InfoColor.from({
        active: PaletteColor.from({...this.info3.active, ...this.info4.active}),
        disabled: PaletteColor.from({...this.info3.disabled, ...this.info4.disabled})
      });


      this.info5 = InfoColor.from({
        active: PaletteColor.from({...this.info4.active, ...this.info5.active}),
        disabled: PaletteColor.from({...this.info4.disabled, ...this.info5.disabled})
      });

      return this;
    }
  }

  export class Typography {
    default: Font;
    h1: Font;
    h2: Font;
    h3: Font;
    h4: Font;
    h5: Font;
    h6: Font;
    subtitle1: Font;
    subtitle2: Font;
    body1: Font;
    body2: Font;
    button: Font;
    caption: Font;
    overline: Font;

    static from(object: any) {
      return Object.assign(new Typography(), object || {});
    }

    dup(): Typography {
      const res = new Typography();
      Object.assign(res, {
        default: {...this.default},
        h1: {...this.h1},
        h2: {...this.h2},
        h3: {...this.h3},
        h4: {...this.h4},
        h5: {...this.h5},
        h6: {...this.h6},
        subtitle1: {...this.subtitle1},
        subtitle2: {...this.subtitle2},
        body1: {...this.body1},
        body2: {...this.body2},
        button: {...this.button},
        caption: {...this.caption},
        overline: {...this.overline}
      });
      return res;
    }

    complete(): Typography {
      this.body1 = {...this.default, ...this.body1};
      this.body2 = {...this.body1, ...this.body2};

      this.subtitle1 = {...this.default, ...this.subtitle1};
      this.subtitle2 = {...this.subtitle1, ...this.body2, ...this.subtitle2};
      this.caption = {...this.subtitle1, ...this.caption};

      this.button = {...this.default, ...this.button};
      this.overline = {...this.default, ...this.overline};

      this.h1 = {...this.default, ...this.h1};
      this.h2 = {...this.h1, ...this.h2};
      this.h3 = {...this.h2, ...this.h3};
      this.h4 = {...this.h3, ...this.h4};
      this.h5 = {...this.h4, ...this.h5};
      this.h6 = {...this.h5, ...this.h6};

      return this;
    }
  }

  export interface Variables { [k: string]: any; }

  export class Theme {
    name: string;
    palette: Palette;
    typography: Typography;
    variables: Variables = {};

    static from(theme: { name: string, palette: Partial<Palette>, typography: Partial<Typography>, variables?: Variables }): Theme {
      const res = new Theme();
      Object.assign(res, {
        name: theme.name,
        palette: Palette.from(theme.palette),
        typography: Typography.from(theme.typography),
        variables: theme.variables
      });
      return res.complete();
    }

    dup(): Theme {
      const res = new Theme();
      Object.assign(res, {
        palette: this.palette.dup(),
        typography: this.typography.dup()
      });
      return res;
    }

    complete(): Theme {
      this.palette.complete();
      this.typography.complete();
      return this;
    }

    toCssVars(prefix = '--theme'): any {
      const res = {};
      toCssVars({name: this.name, palette: this.palette, typography: this.typography}, prefix, res);
      forEachEntry(this.variables, (key, value) => {
        if (typeof value === 'object') {
          toCssVars(value, key, res);
        } else {
          res[key] = value;
        }
      });
      return res;
    }

    apply() {
      const vars = this.toCssVars();
      for (const key in vars) {
        if (vars.hasOwnProperty(key)) {
          const value = vars[key];
          setCssVariable(key, value);
        }
      }
    }
  }

  export const toCssVars = (theme: any, prefix = '--theme', res = {}) => {
    forEachEntry(theme, (key, value) => {
      if (typeof value === 'object') {
        toCssVars(value, `${prefix}-${key}`, res);
      } else {
        res[`${prefix}-${key}`] = value;
      }
    });

    return res;
  };
}


