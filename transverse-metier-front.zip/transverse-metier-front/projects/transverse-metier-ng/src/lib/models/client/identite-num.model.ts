import { FileUploadModel } from './file-upload.model';

export class IdentiteNum {
  pieceJointes: FileUploadModel[] = [];
  typeDoc: string;
  nom?: string;
  prenom?: string;

  dateNaissance?: Date;
}


export class PrevalidationIdentNumResult {
  idUniverSign: string;
  codeStatutControle: number;
  libelleStatutControle: string;
  codeRetour: string;
  messageRetour: string;
  details: DetailControle[];
}

export class DetailControle {
  informationControlee: string;
  indicateurInformationValidee: boolean;
  valeurDeclaree: string;
  valeurDocument: string;
}

