export const CodeSiloERE = 'ERE';
export const CodeSiloMDP = 'MDP';

export type CodeSiloType = typeof CodeSiloERE | typeof CodeSiloMDP;

export interface ContratId {
  codeSilo: CodeSiloType | string;
  nomContrat: string;
  idAdherente?: string;
  idContractante?: string;
  idCollege?: string;
}

export type AffichageType = 'NORMAL' | 'GRISE' | 'LECTURE_SEULE';
export type DisponibiliteType = 'DISPONIBLE' | 'DISPO_RETRAITE' | 'DISPO_SOUS_CONDITIONS' | 'NON_CLASSES';

export interface MiniContrat extends ContratId {
  identifiantAssure?: string;
  description: string;
  raisonSociale?: string;
  college?: string;
  idCollege?: string;
  estCompartiment?: boolean;
  compartimentType?: CompartimentType;
  avecEncours?: boolean;
  encours?: Encours;
  encoursGlobalContrat?: Encours;
  pacte?: boolean;
  affichageType: AffichageType;
  disponibilite?: DisponibiliteType;
}


export class CompartimentId {
  idAssure?: string;
  nomContrat?: string;
  compartimentType: CompartimentType;
}

export type CompartimentType = 'C1' | 'C2' | 'C3' | 'C4';


export class Encours {
  dateEncours?: any;
  montantEncours: number;
  encoursEnErreur?: boolean;
}


export function toStringContratId(contratId: ContratId) {
  const id = [contratId.codeSilo, contratId.nomContrat];
  if (contratId.codeSilo === CodeSiloERE) {
    if (contratId.idAdherente) {
      id.push(contratId.idAdherente);
    }
    if (contratId.idContractante) {
      id.push(contratId.idContractante);
    }
    if (contratId.idCollege) {
      id.push(contratId.idCollege);
    }
  }
  return id.join('-');
}

export function toQueryParamsContratId(contratId: ContratId) {
  const qs = [];
  qs.push(`codeSilo=${encodeURIComponent(contratId.codeSilo)}`);
  qs.push(`nomContrat=${encodeURIComponent(contratId.nomContrat)}`);
  if (contratId.codeSilo === CodeSiloERE) {
    if (contratId.idContractante) {
      qs.push(`idContractante=${encodeURIComponent(contratId.idContractante)}`);
    }
    if (contratId.idAdherente) {
      qs.push(`idAdherente=${encodeURIComponent(contratId.idAdherente)}`);
    }
    if (contratId.idCollege) {
      qs.push(`idCollege=${encodeURIComponent(contratId.idCollege)}`);
    }
  }
  return qs.join('&');
}

export const CONTRAT_ID_QS_NAMES = {nomContrat: 'onglet', idCollege: 'cat'};

export function toQueryParamsContratIdRouter(contratId: ContratId, names = CONTRAT_ID_QS_NAMES) {

  let qs = {[names.nomContrat]: contratId.nomContrat};

  if (contratId.codeSilo === CodeSiloERE) {

    if (contratId.idCollege) {
      qs = {...qs, [names.idCollege]: contratId.idCollege};
    }
  }
  return qs;
}

export function toCompartimentId(miniContrat: MiniContrat): CompartimentId {
  if (miniContrat.codeSilo === 'ERE') {
    return {
      compartimentType: miniContrat.compartimentType,
      idAssure: miniContrat.identifiantAssure,
    };
  } else {
    return {
      compartimentType: miniContrat.compartimentType,
      nomContrat: miniContrat.nomContrat
    };
  }
}
