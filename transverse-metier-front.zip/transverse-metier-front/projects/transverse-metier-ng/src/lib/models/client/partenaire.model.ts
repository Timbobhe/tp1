export class PartenaireInfo {
  codePartenaire: string;
  codePartenairePrincipal: string;
  label: string;
  urlHeader: string;
  urlFooter: string;
  urlError: string;
  urlMenu: string;
  nomCss: string;
  idContrats: string;
  fonctionnnalitesBloquees: Array<string>;
  baseUrl: string;
}


export const STEP_STARTED = 'STARTED'; // Ouverture du parcours
export const STEP_SUMMARY = 'SUMMARY'; // Etape de récapitulatif de la saisie de l’assuré
export const STEP_SIGELEC = 'SIGELEC'; // Redirection vers le partenaire pour la signature en ligne
export const STEP_COMPLETED = 'COMPLETED'; // Parcours terminé

export type STEPS_PARCOURS = typeof STEP_STARTED
  | typeof STEP_SUMMARY
  | typeof STEP_SIGELEC
  | typeof STEP_COMPLETED;
