import { VarsPathData } from '../../shared/utils/pathvars.utils';
import { InjectionToken } from '@angular/core';

export class BaseTrackingInfo {
  user_id: string;
  client_genre: string;
  client_age: string;
  client_postcode: string;
  client_situation: string;
  impersonnation: string;
  partenaire: string;
}


export interface TrackingConfig {
  /**
   * Le nom du contexte de l'application, exemple /retraite-supplementaire pour ECRS
   */
  appNameContext: string;

  /**
   * --- EVENT : pageview ----
   *
   * Les variables à rajouter aux tc_vars selon l'URL accédée.
   *
   * Mapping entre URL de la page et les variables.
   *
   * Permet de positionner des variables sur un PATH. Description hiérarchiques du PATH :
   * Exemple :
   * /accueil/**\/beneficiaires => cumule les variables pour :
   *
   * path: '/accueil',
   *   vars: {
   *     form_profil: 'particuliers',
   *   },
   *
   * ET
   *
   *  path: 'beneficiaires',
   *  vars: {
   *    form_step: 'beneficiaires'
   *  }
   *
   * En vrai on a l'URL : /accueil/configurer-votre-espace/beneficiaires ICI ** = configurer-votre-espace.
   */
  varsPath: VarsPathData[];


  /**
   * --- EVENT : eventGA ----
   *
   * La Categorie des actions selon l'URL accédée
   */
  categoriesPath: VarsPathData[];
}

export const TRACKING_CONFIG = new InjectionToken<TrackingConfig>('Configuration du Tacking');
