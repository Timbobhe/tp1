import { TestBed, waitForAsync } from '@angular/core/testing';

import { TagCommanderConfigService } from './tag-commander-config.service';
import { TRACKING_CONFIG, TrackingConfig } from '../models/client/tracking.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '../reducers/global.state';
import { Observable, of } from 'rxjs';


describe('TagCommanderConfigService', () => {

  let tagco: TagCommanderConfigService;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      providers: [TagCommanderConfigService, {provide: TRACKING_CONFIG, useValue: MockEcrsTrackingConfig}]
    })
      .compileComponents();
    tagco = TestBed.inject(TagCommanderConfigService);
  }));

  it('should be created', () => {
    const service: TagCommanderConfigService = TestBed.inject(TagCommanderConfigService);
    expect(service).toBeTruthy();
  });


  it('varsFromUrl /synthese-des-comptes', () => {
    const vars = tagco.varsFromUrl('/synthese-des-comptes');

    expect(vars).toEqual(jasmine.objectContaining<any>({
      client_profil: 'particuliers'
    }));
  });


  it('varsFromUrl /accueil/configurer-votre-espace/beneficiaires', () => {
    const vars = tagco.varsFromUrl('/accueil/configurer-votre-espace/beneficiaires');

    expect(vars).toEqual(jasmine.objectContaining<any>({
      form_profil: 'particuliers'
      , form_step: 'beneficiaires'
    }));
  });

  it('varsFromUrl /accueil/configurer-votre-espace/gestion-financiere', () => {
    const vars = tagco.varsFromUrl('/accueil/configurer-votre-espace/gestion-financiere');

    expect(vars).toEqual(jasmine.objectContaining<any>({
      form_profil: 'particuliers'
      , form_step: 'gestion-financiere'
    }));
  });

  it('varsFromUrl /accueil/configurer-votre-espace/objectifs', () => {
    const vars = tagco.varsFromUrl('/accueil/configurer-votre-espace/objectifs');

    expect(vars).toEqual(jasmine.objectContaining<any>({
      form_profil: 'particuliers'
      , form_step: 'objectifs'
    }));
  });

  it('varsFromUrl /coordonnees-bancaires/consultation', () => {
    const vars = tagco.varsFromUrl('/coordonnees-bancaires/consultation');

    expect(vars).toEqual(jasmine.objectContaining<any>({
      form_profil: 'particuliers'
      , form_step: 'objectifs'
    }));
  });
});


/**
 * --- EVENT : pageview ----
 */
const TC_VARS = [
  {
    path: '/synthese-des-comptes',
    vars: {
      client_profil: 'particuliers'
    }
  },
  {
    path: '/accueil',
    vars: {
      form_profil: 'particuliers',
    },
    children: [
      {
        path: 'configurer-votre-espace',
        vars: {
          notag: true
        },
        children: [
          {
            path: 'beneficiaires',
            vars: {
              notag: false,
              form_step: 'beneficiaires'
            }
          },
          {
            path: 'gestion-financiere',
            vars: {
              notag: false,
              form_step: 'gestion-financiere'
            }
          },
          {
            path: 'objectifs',
            vars: {
              notag: false,
              form_step: 'objectifs'
            }
          }
        ]
      }
    ]
  },
  {
    path: '/nous-contacter',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'type-demande',
        vars: {
          notag: false,
          form_step: 'type-demande'
        }
      },
      {
        path: 'contact',
        vars: {
          notag: false,
          form_step: 'contact'
        }
      },
      {
        path: 'reclamation',
        vars: {
          notag: false,
          form_step: 'reclamation'
        }
      }
    ]
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'consultation',
        vars: {
          notag: false,
          form_step: 'consultation',
          nombres_contrats$: (store: Store<GlobalState>): Observable<number> =>
            of(2)
        }
      },
      {
        path: 'modification',
        vars: {
          notag: false,
          form_step: 'modification'
        }
      },
      {
        path: 'verification-donnees-personnelles',
        vars: {
          notag: false,
          form_step: 'verification'
        }
      },
    ]
  }
];


/**
 * --- EVENT : eventGA ----
 */
const TC_CATEGORY_URL = [
  {
    path: '/accueil',
    vars: {
      category: 'onboarding'
    }
  },
  {
    path: '/synthese-des-comptes',
    vars: {
      category: 'synthese'
    }
  },
  {
    path: '/modifier-objectif',
    vars: {
      category: 'modificationObjectif'
    }
  },
  {
    path: '/bulletin-affiliation',
    vars: {
      category: 'bia'
    }
  },
  {
    path: '/nous-contacter',
    vars: {
      category: 'contact'
    }
  },
  {
    path: '/coordonnees-bancaires',
    vars: {
      category: 'coordonneesBancaires'
    }
  },
  {
    path: '/clause-beneficiaire',
    vars: {
      category: 'modificationClauseBeneficiaire'
    }
  },
  {
    path: '/modification-gestion-financiere',
    vars: {
      category: 'arbitrage'
    }
  },

];

const MockEcrsTrackingConfig: TrackingConfig = {
  appNameContext: '/retraite-supplementaire',
  varsPath: TC_VARS,
  categoriesPath: TC_CATEGORY_URL
};
