import { Injectable } from '@angular/core';
import { ChainAction, CHAIN_ACTION, ExecuteAction, EXECUTE_ACTION } from '../actions/global.actions';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map, mergeMap, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class GlobalEffects {
  constructor(private readonly actions$: Actions) {
  }

  @Effect({dispatch: true})
  chainAction$ = this.actions$.pipe(
    ofType(CHAIN_ACTION),
    map(action => action as ChainAction),
    mergeMap((action) => action.payload)
  );


  @Effect({dispatch: false})
  executeAction$ = this.actions$.pipe(
    ofType(EXECUTE_ACTION),
    map(action => action as ExecuteAction),
    tap(action => action.payload())
  );

}
