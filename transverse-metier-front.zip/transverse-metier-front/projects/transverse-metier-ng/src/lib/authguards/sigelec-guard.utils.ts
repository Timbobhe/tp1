import { RouterStateSnapshot } from '@angular/router';

export function isRetourSigElec(state: RouterStateSnapshot) {
  return state.url.endsWith('/signature/echouee')
    || state.url.endsWith('/signature/annulee')
    || state.url.endsWith('/signature/terminee');
}
