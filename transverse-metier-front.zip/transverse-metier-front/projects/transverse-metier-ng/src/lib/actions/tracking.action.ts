import { Action } from '@ngrx/store';
import { CodeSiloType } from '../models/client/contrat.model';

export const DISPO_TAG_COMMANDER = '[TRACKING]_DISPO_TAG_COMMANDER';
export const TRACKING_ACTION = '[TRACKING]_TRACK_ACTION';
export const TRACKING_SET_ENV_TEMPLATE = '[TRACKING]_SET_ENV_TEMPLATE';
export const TRACKING_INFO_FETCH = '[TRACKING]_INFO_FETCH';

export class TrackingActionPayload<C = string, A = string> {
  from?: any;

  tc_category?: C;
  tc_action?: A;
  tc_label?: string;

  by_user?: boolean;
}

export class TrackingAction<C = string, A = string> implements Action {
  type = TRACKING_ACTION;

  constructor(public payload: TrackingActionPayload<C, A>) {
  }
}

export function tracking<C = string, A = string>(tc_category: C, tc_action: A, tc_label: string = null, by_user = true) {
  return new TrackingAction<C, A>({tc_category, tc_action, tc_label, by_user});
}

export class SetTrackingEnvTemplate implements Action {
  type = TRACKING_SET_ENV_TEMPLATE;

  constructor(public payload: Array<CodeSiloType | string>) {
  }
}


export class DispoTagCommander implements Action {
  type = DISPO_TAG_COMMANDER;

  constructor(public payload = null) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type TrackingActions = DispoTagCommander | TrackingAction | SetTrackingEnvTemplate;
