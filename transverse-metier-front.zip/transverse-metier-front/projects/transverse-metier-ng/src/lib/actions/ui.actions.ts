import { Action } from '@ngrx/store';
import { MessageModel } from '../models/message.model';


export const INIT_APP = '[UI]_INIT_APP';
export const PUSH_TOAST_MESSAGE = '[UI]_PUSH_TOAST_MESSAGE';
export const CLEAR_TOAST_MESSAGE = '[UI]_CLEAR_TOAST_MESSAGE';

export class InitApp implements Action {
  type = INIT_APP;

  constructor(public payload = null) {
  }
}

export class PushToastMessage implements Action {
  type = PUSH_TOAST_MESSAGE;
  payload: MessageModel[];

  constructor(...payload: MessageModel[]) {
    this.payload = payload;
  }
}

export class ClearToastMessage implements Action {
  type = CLEAR_TOAST_MESSAGE;

  constructor(public payload: string = null) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type UiActions =
  InitApp
  | PushToastMessage
  | ClearToastMessage;
