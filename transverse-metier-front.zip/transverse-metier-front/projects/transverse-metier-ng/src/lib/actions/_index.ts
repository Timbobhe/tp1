import { Action } from '@ngrx/store';

export interface ActionWithPayload<T = any> extends Action {
  payload: T;
}
