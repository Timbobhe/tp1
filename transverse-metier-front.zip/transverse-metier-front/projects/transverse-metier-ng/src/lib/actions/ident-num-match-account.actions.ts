import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng';
import { IdentiteNumerique } from '../models/client/identiteNumerique.model';

export const GET_IDENT_NUM_MATCH_ACCOUNT = '[MATCH_ACCOUNT]_GET';

export class GetIdentNumMatchAccount extends ApiAction<IdentiteNumerique> {
  constructor() {
    super(GET_IDENT_NUM_MATCH_ACCOUNT, 'backend/matchAccount', null);
  }
}

export type IdentNumMatchAccountActions = GetIdentNumMatchAccount
  | ApiActions;
