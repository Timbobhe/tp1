import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RedirectService {

  openUrl(url: string) {
    window.location.replace(url);
  }
}
