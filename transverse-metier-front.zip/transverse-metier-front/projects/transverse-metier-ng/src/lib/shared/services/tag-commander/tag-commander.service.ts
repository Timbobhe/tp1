import { EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Injectable, NgZone } from '@angular/core';
import { DispoTagCommander } from '../../../actions/tracking.action';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../reducers/global.state';

const TC_VARS_EMPTY = {page_event_manual: true};


@Injectable({
  providedIn: 'root'
})
export class TagCommanderService {

  private static isTcLoaded = false;

  private loadingCounter = 0;

  private readonly global: any = window;

  constructor(
    private readonly envSpec: EnvSpecificService,
    private readonly store: Store<GlobalState>,
    private readonly zone: NgZone) {
  }

  get isActive() {
    return !this.envSpec.config.tc_disabled;
  }


  public sendEvent(from: any, category: string, action: string, label: string, valueGA: string = '', nonInteraction: string = '') {
    if (this.isActive) {
      this.zone.runOutsideAngular(() =>
        this.global.tc_events_1(from, 'eventGA', {
          Category: category,
          Action: action,
          Label: label,
          ValueGA: valueGA,
          nonInteraction
        })
      );
    }
  }

  public sendPageView(from: any, url: string) {
    if (this.isActive) {
      this.zone.runOutsideAngular(() =>
        this.global.tc_events_1(from, 'pageview', {
          pageURL: url,
          nonInteraction: ''
        })
      );
    }
  }

  public setTcVar(tcKey: string, tcVar: any) {
    if (!this.global.tc_vars) {
      this.global.tc_vars = {[tcKey]: tcVar};
    } else if (this.global.tc_vars) {
      this.global.tc_vars[tcKey] = tcVar;
    }
  }

  public setTcVars(vars: object): void {
    this.global.tc_vars = vars;
  }

  public getTcVars() {
    return this.global.tc_vars;
  }

  initTcContainer() {
    if (!TagCommanderService.isTcLoaded && this.isActive) {
      trace('## Début de l\installation de TAGCO');
      this.setTcVars(TC_VARS_EMPTY);

      // Container 1
      this.loadScript('script1-head', this.envSpec.config.tc_head_url, 'head');
      this.loadContainer('container1-head', this.envSpec.config.tc_head_iframe_url, 'head');

      // Container 2
      this.loadScript('script2-body', this.envSpec.config.tc_body_url, 'body');
      this.loadContainer('container2-body', this.envSpec.config.tc_body_iframe_url, 'body');

      trace('## Fin de l\'installation de TAGCO');
      TagCommanderService.isTcLoaded = true;
    }
  }


  private loadScript(srcType: string, scriptSrc: string, htmlNode: string): void {
    const script: HTMLScriptElement = document.createElement('script');
    script.type = 'text/javascript';
    script.src = scriptSrc;
    script.onload = () => this.handleLoading(srcType);
    script.onerror = () => trace('', new Error(`Erreur pendant le chargement TAGCO ${srcType}`));
    document.getElementsByTagName(htmlNode)[0].appendChild(script);
  }

  private loadContainer(srcType: string, iframeSrc: string, htmlNode: string): void {
    const noscript: HTMLElement = document.createElement('noscript');
    const iframe: HTMLIFrameElement = document.createElement('iframe');
    noscript.appendChild(iframe);
    Object.assign(iframe, {
      src: iframeSrc,
      width: '1',
      height: '1',
      rel: 'noindex,nofollow',
      onload: () => this.handleLoading(srcType)
    });
    document.getElementsByTagName(htmlNode)[0].appendChild(noscript);
  }

  private handleLoading(src: string) {
    this.loadingCounter++;
    trace(`Chargement ${this.loadingCounter}/4 OK de ${src}`);
    if (this.loadingCounter === 4) {
      trace(`Chargement terminé OK de TAGCO`);
      this.store.dispatch(new DispoTagCommander());
    }
  }

}
