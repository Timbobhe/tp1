import { Injectable } from '@angular/core';
import { BehaviorSubject, EMPTY, fromEvent, Observable } from 'rxjs';
import { catchError, distinctUntilKeyChanged, filter, map } from 'rxjs/operators';

const Global: any = window;

export type Device = 'mobile' | 'tablette' | 'desktop';
export type Size = 'S' | 'M' | 'L';

export class DeviceSize {

  name: Device;
  size: Size;

  fullname: string;

  constructor(data: any) {
    Object.assign(this, data);
    this.fullname = `${this.name}-${this.size}`;
  }

  static current() {
    return toDeviceSize(Global.innerWidth);
  }

  isMobile() {
    return this.name === 'mobile';
  }
  isTablette() {
    return this.name === 'tablette';
  }
  isDesktop() {
    return this.name === 'desktop';
  }
  isSmall() {
    return this.size === 'S';
  }
  isMedium() {
    return this.size === 'M';
  }
  isLarge() {
    return this.size === 'L';
  }
}

export function toDeviceSize(width: number): DeviceSize {
  if (width <= 320) {
    return new DeviceSize({ name: 'mobile', size: 'S' });
  }
  if (width <= 480) {
    return new DeviceSize({ name: 'mobile', size: 'M' });
  }
  if (width <= 768) {
    return new DeviceSize({ name: 'tablette', size: 'S' });
  }
  if (width <= 959) {
    return new DeviceSize({ name: 'tablette', size: 'M' });
  }
  if (width <= 1024) {
    return new DeviceSize({ name: 'tablette', size: 'L' });
  }
  if (width <= 1200) {
    return new DeviceSize({ name: 'desktop', size: 'M' });
  }
  if (width >= 1201) {
    return new DeviceSize({ name: 'desktop', size: 'L' });
  }
}

@Injectable({
  providedIn: 'root'
})
export class ResponsiveService {

  private readonly resizeSubject: BehaviorSubject<DeviceSize>;

  constructor() {
    this.resizeSubject = new BehaviorSubject<DeviceSize>(DeviceSize.current());
    fromEvent(window, 'resize')
      .pipe(
        map((event: any) => toDeviceSize(event.target.innerWidth)),
        catchError(err => EMPTY)
      )
      .subscribe((curr) => this.resizeSubject.next(curr));
  }

  get onResize$(): Observable<DeviceSize> {
    return this.resizeSubject.asObservable().pipe(
      filter(d => !!d),
      distinctUntilKeyChanged('fullname'),
      catchError(err => EMPTY)
    );
  }


}
