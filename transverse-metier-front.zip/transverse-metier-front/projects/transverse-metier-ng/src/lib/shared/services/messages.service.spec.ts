import { TestBed } from '@angular/core/testing';

import { MessagesService } from './messages.service';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';

describe('MessagesService', () => {
  let jahiaServiceStub: Partial<JahiaService>;

  jahiaServiceStub = {};

  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      {provide: JahiaService, useValue: jahiaServiceStub}
    ]
  }));

  it('should be created', () => {
    const service: MessagesService = TestBed.inject(MessagesService);
    expect(service).toBeTruthy();
  });
});
