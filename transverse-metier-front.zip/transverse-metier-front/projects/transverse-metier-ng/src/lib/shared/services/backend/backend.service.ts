import { BackendService as BackEndProvider } from '@ag2rlamondiale/metis-ng';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FileUploadResponseModel } from '../../../models/client/file-upload.model';
import { Observable } from 'rxjs';

@Injectable()
export class BackendService {

  constructor(private readonly _http: HttpClient,
              private readonly backendService: BackEndProvider) {
  }

  uploadJustif(formData: FormData): Observable<HttpEvent<FileUploadResponseModel>> {
    return this._http.post<any>(this.backendService.getEndpointUrl('upload'), formData, {
      reportProgress: true,
      observe: 'events',
      responseType: 'json'
    });
  }

}
