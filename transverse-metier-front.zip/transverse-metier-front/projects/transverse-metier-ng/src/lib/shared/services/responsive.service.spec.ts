import { waitForAsync, TestBed } from '@angular/core/testing';
import { DeviceSize, ResponsiveService, toDeviceSize } from './responsive.service';

describe('Service: ResponsiveService', () => {

  let responsiveService: ResponsiveService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResponsiveService]
    });

    responsiveService = TestBed.inject(ResponsiveService);
  });

  it('should instanciate', () => {
    expect(responsiveService).toBeTruthy();
  });


  it('should identify DeviceSize', () => {
    expect(toDeviceSize(100)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'mobile', size: 'S' }));
    expect(toDeviceSize(400)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'mobile', size: 'M' }));
    expect(toDeviceSize(600)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'tablette', size: 'S' }));
    expect(toDeviceSize(900)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'tablette', size: 'M' }));
    expect(toDeviceSize(1024)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'tablette', size: 'L' }));
    expect(toDeviceSize(1100)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'desktop', size: 'M' }));
    expect(toDeviceSize(1300)).toEqual(jasmine.objectContaining<DeviceSize>({ name: 'desktop', size: 'L' }));
  });


  it('should test Device', () => {
    expect(toDeviceSize(100).isMobile()).toBeTruthy();
    expect(toDeviceSize(400).isMobile()).toBeTruthy();
    expect(toDeviceSize(600).isTablette()).toBeTruthy();
    expect(toDeviceSize(900).isTablette()).toBeTruthy();
    expect(toDeviceSize(1024).isTablette()).toBeTruthy();
    expect(toDeviceSize(1100).isDesktop()).toBeTruthy();
    expect(toDeviceSize(1300).isDesktop()).toBeTruthy();
  });


  it('should test Device size', () => {
    expect(toDeviceSize(100).isSmall()).toBeTruthy();
    expect(toDeviceSize(400).isMedium()).toBeTruthy();
    expect(toDeviceSize(600).isSmall()).toBeTruthy();
    expect(toDeviceSize(900).isMedium()).toBeTruthy();
    expect(toDeviceSize(1024).isLarge()).toBeTruthy();
    expect(toDeviceSize(1100).isMedium()).toBeTruthy();
    expect(toDeviceSize(1300).isLarge()).toBeTruthy();
  });


  it('should subscribe onResize', waitForAsync(() => {
    responsiveService.onResize$.subscribe(ds => {
      expect(ds).toBeTruthy();
    });
  }));





});
