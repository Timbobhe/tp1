import { Injectable } from '@angular/core';
import { Validators } from '@angular/forms';


@Injectable()
export class Globals {

  FRENCH_IBAN_PATTERN = '^[fF][rR]\\d{2}';
  ONLY_ALPHANUMERIC = '[A-Z0-9]*';
  TREE_ALPHANUMERIC_WITH_SPACE = '(?:[ ]?[A-Z0-9]{3})';
  FOUR_ALPHANUMERIC_WITH_SPACE = '(?:[ ]?[A-Z0-9]{4})';
  FIVE_TIMES_FOUR_ALPHANUMERIC_WITH_SPACE = this.FOUR_ALPHANUMERIC_WITH_SPACE + '{5}';

  PATTERNS = {
    email: '^([a-zA-Z0-9])([a-zA-Z0-9_\\-\\.]*)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$',
    phone: '^([0-9]{10,14}$|(?:[+])[1-9]([^a-zA-Z\s\\d:]*[0-9]{1}){10,11})$'

  };

  ERROR_MESSAGES = {
    email: 'Le format de l\'adresse e-mail est incorrect.',
    phone: 'Le format du numéro de tétéphone portable est incorrect.',
    required: 'Ce champ est obligatoire'
  };

  get emailValidator() {
    return Validators.pattern(this.PATTERNS.email);
  }

  get telValidator() {
    return Validators.pattern(this.PATTERNS.phone);
  }
}
