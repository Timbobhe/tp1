import { paramsToQueryString, queryStringToObject } from './url-utils';

describe('url-utils', () => {

  it('should retrieve paramMap', () => {
    const map = queryStringToObject('?onglet=RG1515&type=stock');
    expect(map).toEqual(jasmine.objectContaining({onglet: 'RG1515', type: 'stock'}));
  });

  it('should retrieve paramMap with frame', () => {
    const map = queryStringToObject('?frame&onglet=RG1515&type=stock');
    expect(map).toEqual(jasmine.objectContaining({frame: true, onglet: 'RG1515', type: 'stock'}));
  });

  it('should transform 2 Params to string', () => {
    const qs = paramsToQueryString({onglet: 'RG152222876', type: 'flux'});
    expect(qs).toEqual('?onglet=RG152222876&type=flux');
  });

  it('should transform 1 Params to string', () => {
    const qs = paramsToQueryString({onglet: 'RG152222876'});
    expect(qs).toEqual('?onglet=RG152222876');
  });

  it('should transform Empty Params to Empty string', () => {
    const qs = paramsToQueryString({});
    expect(qs).toEqual('');
  });

  it('should transform Null Params to Null string', () => {
    const qs = paramsToQueryString(null);
    expect(qs).toBeFalsy();
  });

});
