import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActionsBarComponent } from './actions-bar.component';
import { ResponsiveService } from '../../services/responsive.service';

describe('ActionsBarComponent', () => {
  let component: ActionsBarComponent;
  let fixture: ComponentFixture<ActionsBarComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ ActionsBarComponent ],
      providers: [ResponsiveService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActionsBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
