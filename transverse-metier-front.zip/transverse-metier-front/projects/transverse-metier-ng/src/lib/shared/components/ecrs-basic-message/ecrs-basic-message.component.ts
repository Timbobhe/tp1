import { Component, Input, OnInit } from '@angular/core';
import { BasicMessage } from '../../../models/message.model';

@Component({
  selector: 'trm-basic-message',
  templateUrl: './ecrs-basic-message.component.html',
  styleUrls: ['./ecrs-basic-message.component.scss']
})
export class EcrsBasicMessageComponent implements OnInit {

  @Input() message: BasicMessage;
  @Input() jahiaDicoId: string;

  constructor() {
  }

  ngOnInit() {
  }

}
