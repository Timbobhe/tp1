import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'trm-badge-hexagon',
  templateUrl: './badge-hexagon.component.html',
  styleUrls: ['./badge-hexagon.component.scss']
})
export class BadgeHexagonComponent implements OnInit {

  @Input() backgroundColor: string = '#00E8FF';
  @Input() color: string = 'white';
  @Input() marginLeft = '10px';
  @Input() fontSize = '28px';

  constructor() {
  }

  ngOnInit() {
  }

}
