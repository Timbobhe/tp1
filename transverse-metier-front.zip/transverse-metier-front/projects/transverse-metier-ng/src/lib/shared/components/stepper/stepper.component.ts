import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { DeviceSize, ResponsiveService } from '../../services/responsive.service';
import { Observable } from 'rxjs';


export type Variant = 'standard' | 'mini' | 'standard-mini-mobile';

export interface Step {
  index?: number; // calculer selon index dans le tableau
  label: string;
}

@Component({
  selector: 'trm-stepper',
  templateUrl: 'stepper.component.html',
  styleUrls: ['stepper.component.scss']
})
export class StepperComponent implements OnInit, OnChanges {

  @Input() variant: Variant = 'standard';

  @Input() steps: Array<Step> = [];

  @Input() totalSteps: number;

  @Output() stepChanged = new EventEmitter<Step>();

  @Output() stepChangedByClickingItem: EventEmitter<Step> = new EventEmitter<Step>();

  @Input() currentStepIndex = 0;
  lastStepIndex = 0;

  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsive: ResponsiveService) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit(): void {
    if (this.steps.length !== 0) {
      this.lastStepIndex = this.steps.length - 1;
    } else if (this.totalSteps) {
      this.steps = [];
      this.lastStepIndex = this.totalSteps - 1;
      for (let i = 0; i < this.totalSteps; i++) {
        this.steps.push({label: 'Etape ' + (i + 1)});
      }
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.steps) {
      this.lastStepIndex = this.steps.length - 1;
    } else if (changes.totalSteps) {
      this.totalSteps = changes.totalSteps.currentValue;
      this.lastStepIndex = this.totalSteps - 1;
      this.steps = [];
      for (let i = 0; i < this.totalSteps; i++) {
        this.steps.push({label: 'Etape ' + (i + 1)});
      }
    }

    if (changes.currentStepIndex) {
      const originalValue = changes.currentStepIndex.previousValue;
      const valueAfterChange = changes.currentStepIndex.currentValue;
      if (valueAfterChange < 0 || (this.lastStepIndex && valueAfterChange > this.lastStepIndex)) {
        this.currentStepIndex = originalValue;
        throw new Error(`${valueAfterChange} is an invalid step index.`);
      }
      this.notifyStepChange(this.currentStepIndex);
    }
  }

  setCurrentStepIndex(newIndex: number) {
    if (newIndex < 0 || (this.lastStepIndex && newIndex > this.lastStepIndex)) {
      throw new Error(`${newIndex} is an invalid step index.`);
    }
    this.currentStepIndex = newIndex;
    this.notifyStepChange(newIndex);
  }

  next() {
    if (this.currentStepIndex + 1 <= this.lastStepIndex) {
      this.currentStepIndex++;
      this.notifyStepChange(this.currentStepIndex);
    }
  }
  previous() {
    if (this.currentStepIndex - 1 >= 0) {
      this.currentStepIndex--;
      this.notifyStepChange(this.currentStepIndex);
    }
  }

  notifyStepChange(currentStepIndex: number) {
    const step = this.steps[currentStepIndex]; // the object that represents the step
    this.stepChanged.emit({ ...step, index: currentStepIndex });
  }

  goToStep(stepIndex: number) {
    if (stepIndex < this.currentStepIndex) {
      this.currentStepIndex = +stepIndex;
      const step = this.steps[this.currentStepIndex]; // the object that represents the step
      this.stepChanged.emit({ ...step, index: this.currentStepIndex });
      this.stepChangedByClickingItem.emit({ ...step, index: this.currentStepIndex});
    }
  }
}
