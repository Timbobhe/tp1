import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { ButtonRadioComponent } from './button-radio.component';

describe('ButtonRadioComponent', () => {
  let component: ButtonRadioComponent;
  let fixture: ComponentFixture<ButtonRadioComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ButtonRadioComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonRadioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create ButtonRadioComponent', () => {
    expect(component).toBeTruthy();
  });
});
