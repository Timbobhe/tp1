import { CUSTOM_ELEMENTS_SCHEMA, SimpleChange } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ModalPaginationComponent } from './modal-pagination.component';


function configureTestBed(): void {
  TestBed.configureTestingModule({
    declarations: [ModalPaginationComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
  })
    .compileComponents();
}

describe('ModalPaginationComponent', () => {
  let component: ModalPaginationComponent;
  let fixture: ComponentFixture<ModalPaginationComponent>;

  beforeEach(waitForAsync(() => {
    configureTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalPaginationComponent);
    component = fixture.componentInstance;
    component.steps = [{ label: 'Step 0' }, { label: 'Step 1' }, { label: 'Step 2' }];
    component.totalSteps = 3;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should contains 3 steps', () => {
    const element = fixture.debugElement;
    const piecesInactives = element.queryAll(By.css('.ag2rlm-modal-pagination-inactive'));
    const piecesActives = element.queryAll(By.css('.ag2rlm-modal-pagination-active'));
    expect(piecesInactives.length).toEqual(2);
    expect(piecesActives.length).toEqual(1);
    expect(component.currentStepIndex).toEqual(0);
  });

  it('should no-prev step', () => {
    component.currentStepIndex = 0;
    fixture.detectChanges();
    component.previous();
    fixture.detectChanges();

    expect(component.currentStepIndex).toEqual(0);
    const element = fixture.debugElement;
    const piecesActives = element.queryAll(By.css('.ag2rlm-modal-pagination-active'));
    expect(Object.keys(piecesActives[0].classes)).toContain('ag2rlm-modal-pagination-active');
  });

  it('should setCurrentStepIndex', () => {
    component.setCurrentStepIndex(1);
    fixture.detectChanges();
    expect(component.currentStepIndex).toEqual(1);
    const element = fixture.debugElement;
    const piecesInactives = element.queryAll(By.css('.ag2rlm-modal-pagination-inactive'));
    expect(Object.keys(piecesInactives[0].classes)).toContain('ag2rlm-modal-pagination-inactive');
  });

  it('should not setCurrentStepIndex', () => {
    expect(function () { component.setCurrentStepIndex(-1); }).toThrowError('-1 is an invalid step index.');
  });

  it('should detect changes on currentStepIndex', () => {
    component.currentStepIndex = 2;
    component.ngOnChanges({
      currentStepIndex: new SimpleChange(1, component.currentStepIndex, false)
    });
    fixture.detectChanges();
    expect(component.currentStepIndex).toEqual(2);
    const element = fixture.debugElement;
    const piecesInactives = element.queryAll(By.css('.ag2rlm-modal-pagination-inactive'));
    expect(Object.keys(piecesInactives[0].classes)).toContain('ag2rlm-modal-pagination-inactive');
    expect(Object.keys(piecesInactives[1].classes)).toContain('ag2rlm-modal-pagination-inactive');
  });

  it('should not detect changes on currentStepIndex', () => {
    component.currentStepIndex = 20;
    expect(function () {
      component.ngOnChanges({
        currentStepIndex: new SimpleChange(1, component.currentStepIndex, false)
      });
      fixture.detectChanges();
    }).toThrowError('20 is an invalid step index.');
  });

  it('should detect changes on totalSteps', () => {
    component.totalSteps = 8;
    component.ngOnChanges({
      totalSteps: new SimpleChange(null, component.totalSteps, true)
    });
    fixture.detectChanges();
    expect(component.totalSteps).toEqual(8);
  });

  it('should create stepper with totalSteps', () => {
    TestBed.resetTestingModule();
    configureTestBed();
    fixture = TestBed.createComponent(ModalPaginationComponent);
    component = fixture.componentInstance;
    component.totalSteps = 5;
    fixture.detectChanges();
    const element = fixture.debugElement;
    const piecesInactives = element.queryAll(By.css('.ag2rlm-modal-pagination-inactive'));
    const piecesActives = element.queryAll(By.css('.ag2rlm-modal-pagination-active'));
    expect(piecesInactives.length).toEqual(4);
    expect(piecesActives.length).toEqual(1);
    expect(component.currentStepIndex).toEqual(0);
  });

});
