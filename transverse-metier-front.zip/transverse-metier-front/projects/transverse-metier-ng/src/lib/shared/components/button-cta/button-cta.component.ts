import { Component, Directive, ElementRef, EventEmitter, HostListener, Input, OnInit, Output } from '@angular/core';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';


@Directive({
  selector: '[clickHandler]'
})
export class ClickHandlerDirective {

  constructor(private element: ElementRef<HTMLInputElement>) {
  }

  @HostListener('click', ['$event'])
  handleClick(event) {
    if ((this.element.nativeElement.firstChild as HTMLButtonElement).disabled) {
      event.stopImmediatePropagation();
    }
  }
}

@Component({
  selector: 'trm-button-cta',
  templateUrl: './button-cta.component.html',
  styleUrls: ['./button-cta.component.scss']
})

export class ButtonCtaComponent implements OnInit {

  @Input() text: string;
  @Input() isCtaPrincipal: boolean;
  @Input() isLight: boolean;

  @Input() disabled = false;
  @Input() jahiaTitle: string;
  @Input() jahiaKey: string;

  @Input() icon: string;
  @Input() iconPosition: 'left' | 'right';

  @Output() clickAction: EventEmitter<any> = new EventEmitter();

  label$: Observable<string>;

  buttonClass: string;

  constructor(private readonly jahia: JahiaService) {
  }

  ngOnInit() {
    this.buttonClass = this.isCtaPrincipal ? 'btn-primary' : 'btn-secondary';
    this.buttonClass = this.buttonClass.concat(this.isLight ? ' btn-light' : '');

    if (this.jahiaTitle && this.jahiaKey) {
      this.label$ = this.jahia.getDicoEntry(this.jahiaTitle, this.jahiaKey).pipe(
        map(e => e.label)
      );
    } else {
      this.label$ = of(this.text);
    }
  }

  click(event: any) {
    if (this.disabled === false) {
      this.clickAction.emit(event);
    }
  }
}
