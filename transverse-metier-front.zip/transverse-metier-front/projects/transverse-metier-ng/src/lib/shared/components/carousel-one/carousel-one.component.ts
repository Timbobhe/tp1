import {
  AfterContentInit,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  TemplateRef,
} from "@angular/core";
import { PrimeTemplate } from "primeng/api";

export type CarouselStatus = { index: number; first: boolean; last: boolean; total: number };

@Component({
  selector: "trm-carousel-one",
  templateUrl: "./carousel-one.component.html",
  styleUrls: ["./carousel-one.component.scss"],
})
export class CarouselOneComponent implements OnInit, AfterContentInit {
  @Input() value: any[] = [];
  @Input() index = 0;
  @Output() onMove = new EventEmitter<CarouselStatus>();

  itemsTemplate: TemplateRef<any>;

  @ContentChildren(PrimeTemplate) templates: QueryList<PrimeTemplate>;

  constructor() {}

  ngOnInit() {
    this.moving();
  }

  ngAfterContentInit(): void {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "items":
          this.itemsTemplate = item.template;
          break;
      }
    });
  }

  next() {
    if (this.index < this.value.length - 1) {
      ++this.index;
    }
    this.moving();
  }

  previous() {
    if (this.index > 0) {
      --this.index;
    }
    this.moving();
  }

  get currentItem() {
    return this.value[this.index];
  }

  get status(): CarouselStatus {
    return {
      index: this.index,
      first: this.index === 0,
      last: this.index === this.value.length - 1,
      total: this.value.length
    };
  }

  private moving() {
    this.onMove.emit(this.status);
  }
}
