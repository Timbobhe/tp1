import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  Output,
  ViewChild
} from '@angular/core';

@Component({
  selector: 'trm-ruler',
  templateUrl: './ecrs-ruler.component.html',
  styleUrls: ['./ecrs-ruler.component.scss']
})
export class EcrsRulerComponent implements AfterViewInit {
  constructor() {
  }

  spaceStepperAdjust = 13;
  _minSteps = 61; // ici la valeur par défaut
  _maxSteps = 65; // ici la valeur max par défaut
  @Output() sliderValue = new EventEmitter<number>();

  borneMin: number;
  borneMax: number;

  steps: number;
  widthSlider: number;
  spaceStep: number;
  previousSliderValue: number;
  @ViewChild('pSliderContainer') pSlider: ElementRef<HTMLElement>;
  @ViewChild('stepNumber') stepNumber: ElementRef<HTMLElement>;

  initSlider() {
    if (!this.pSlider || !this.stepNumber) {
      return;
    }

    this.widthSlider = this.pSlider.nativeElement.offsetWidth;
    const stepsNumber = this.maxSteps - this.minSteps;
    // Calculer l'espace entre les steps de la reglette
    const spaceSlider = this.widthSlider / stepsNumber;

    // Créer le l'indicateur de l'age sur la reglette
    const backgroundSize = 'background-size: 20px 100px, 20px 100px, '
      + spaceSlider
      + 'px 1px !important;';
    this.pSlider.nativeElement.setAttribute('style', backgroundSize);
    const initStepNumberWidth = this.stepNumber.nativeElement.offsetWidth;
    // Calculer l'espace entre les indicateurs d'age
    this.spaceStep = spaceSlider - initStepNumberWidth;
  }

  ngAfterViewInit() {
    this.steps = this.minSteps;
    this.initSlider();
  }

  /**
   * Redessiner la reglette en cas de resize de l'ecran
   * @param event
   */
  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.initSlider();
  }

  /**
   * Methode pour iterer de 0 -> nombre de steps
   * @param i
   */
  counter(i: number) {
    return new Array(i);
  }

  /**
   * detect du changement  dans la reglette
   * @param $event
   */
  handleChange($event: any) {
    // Envoi l'age une fois il sera changé
    if (this.previousSliderValue !== $event.value) {
      if ($event.value > this.borneMin && $event.value < this.borneMax) {
        // Emitter la valeur d'age selectionné
        this.sliderValue.emit($event.value);
      } else {
        this.sliderValue.emit(null);
      }
    }
    this.previousSliderValue = this.steps;
  }

  @Input() set minSteps(value) {
    this._minSteps = value - 1;
    this.borneMin = this._minSteps;
  }

  @Input() set maxSteps(value) {
    this._maxSteps = value + 1;
    this.borneMax = this._maxSteps;
  }

  get minSteps() {
    return this._minSteps;
  }

  get maxSteps() {
    return this._maxSteps;
  }
}
