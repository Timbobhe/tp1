import {
  AfterContentInit,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  TemplateRef
} from '@angular/core';
import { PrimeTemplate, SelectItem } from 'primeng/api';
import { Reponse } from '../../../models';

@Component({
  selector: 'trm-select-button',
  templateUrl: './select-button.component.html',
  styleUrls: ['./select-button.component.scss'],
})
export class SelectButtonComponent implements OnInit, AfterContentInit {
  @Input() jahiaDicoId: string;
  @Input() isMultipleChoice = false;
  @Output() optionClicked = new EventEmitter<Reponse>();
  @Output() optionsClicked = new EventEmitter<Reponse[]>();

  @Input()
  selectedOption: SelectItem;
  @Input()
  selectedOptions: SelectItem[] = [];

  selectItems: SelectItem[] = [];

  complementReponseTemplate: TemplateRef<any>;

  specialReponseTemplate: TemplateRef<any>;

  @ContentChildren(PrimeTemplate) templates: QueryList<PrimeTemplate>;

  constructor() {
  }

  ngOnInit() {
  }

  ngAfterContentInit(): void {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case 'complementReponse':
          this.complementReponseTemplate = item.template;
          break;

        case 'specialReponse':
          this.specialReponseTemplate = item.template;
          break;
      }
    });
  }

  @Input()
  set options(options: Reponse[]) {
    this.selectItems = options.map((e) => {
      return {value: e, disabled: e.disabled};
    });
  }

  selectOption(event: SelectItem | SelectItem[]) {
    // console.log('select-button, selectOption', event);
    if (this.isMultipleChoice && Array.isArray(event)) {
      this.optionsClicked.emit(event);
    } else if (!this.isMultipleChoice && !Array.isArray(event)) {
      this.optionClicked.emit(event);
    }
  }
}
