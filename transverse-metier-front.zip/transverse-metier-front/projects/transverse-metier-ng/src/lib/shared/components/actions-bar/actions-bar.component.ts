import { Component, Input, OnInit } from '@angular/core';
import { DeviceSize, ResponsiveService } from '../../services/responsive.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'trm-actions-bar',
  templateUrl: './actions-bar.component.html',
  styleUrls: ['./actions-bar.component.scss']
})
export class ActionsBarComponent implements OnInit {
  @Input() keepAlignment = false;

  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = responsiveService.onResize$;
  }

  ngOnInit() {
  }

}
