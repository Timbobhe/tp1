import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'trm-custom-input',
  templateUrl: './custom-input.component.html',
  styleUrls: ['./custom-input.component.scss']
})
export class CustomInputComponent implements OnInit {

  @Input() inputName: string;
  @Input() inputLabel: string;
  @Input() controlFrom: FormControl = new FormControl();
  @Input() type: string;
  @Input() value: string;
  @Input() showErrorDetails = false;
  @Output() onInput = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    if (this.value === undefined) {
      this.value = this.controlFrom.value;
    }
   }

   onInputValue($event) {
    this.onInput.emit($event);
   }

}
