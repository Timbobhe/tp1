import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnInit,
  SimpleChanges
} from '@angular/core';
import { MessagesService } from '../../services/messages.service';
import { MessageModel } from '../../../models/message.model';

@Component({
  selector: 'trm-messages',
  templateUrl: './ecrs-messages.component.html',
  styleUrls: ['./ecrs-messages.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EcrsMessagesComponent implements OnInit, OnChanges {
  @Input() value: MessageModel[] = [];
  @Input() msg: MessageModel;
  @Input() closable = false;

  messages = [];

  constructor(
    private readonly messagesService: MessagesService,
    private readonly cd: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.value) {
      this.messages = [];
    }
    if (changes.msg) {
      this.messages = [];
    }
  }


  messageFromJahia(msg: MessageModel) {
    return this.messagesService.messageFromJahia(msg);
  }


  append(resolved: MessageModel) {
    if (resolved) {
      this.messages.push(resolved);
      this.cd.markForCheck();
    }
  }


  get inputValue() {
    if (this.msg) {
      return [this.msg];
    }
    if (this.value) {
      return this.value;
    }
    return [];
  }

}
