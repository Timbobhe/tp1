export const TYPES_AUTORISES = ['pdf', 'tif', 'tiff', 'png', 'bmp', 'jpg', 'jpeg'] ;

export enum CustomUploadState {
  EMPTY = 'EMPTY',
  UPLOADING = 'UPLOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR'
}

export const UNIT = 1024;
export const PJ_TAILLE_MAX = 2048 * UNIT;
