import { Theming } from '../../../models';
import { baseColors } from './theme-ag2r';
import { icones } from './theme-base';

export const addingColors = {
  /* Couleurs ADDING */
  blueAdding: '#1C6791',
  cyanAdding: '#0097A3',
  greyAdding: '#63666A',
};


export const AddingTheme = Theming.Theme.from({
  name: 'adding',
  palette: {
    primary: {main: addingColors.blueAdding, contrastText: 'white'},
    secondary: {main: addingColors.cyanAdding, contrastText: 'white'},
    text: {primary: addingColors.greyAdding, disabled: '#eeeeee'},
    link: {active: addingColors.blueAdding, hover: addingColors.greyAdding, visited: addingColors.greyAdding},
    actionPrimary: {
      active: {main: addingColors.blueAdding, contrastText: 'white', light: '#2485BC'},
      disabled: {main: baseColors.greyAg2r, contrastText: 'white'},
      hover: {main: '#2485BC', contrastText: 'white', border: addingColors.blueAdding}
    },
    actionSecondary: {
      active: {main: 'white', contrastText: addingColors.greyAdding, border: addingColors.greyAdding},
      disabled: {main: Theming.greyColors['300']},
      hover: {main: '#2485BC', contrastText: 'white', border: addingColors.blueAdding}
    },
    background: {default: baseColors.lightGreyAg2r, paper: 'white'},
    info1: {
      active: {main: addingColors.cyanAdding, contrastText: 'white'},
      disabled: {main: Theming.greyColors['300'], contrastText: 'white'}
    },
    info2: {
      active: {main: addingColors.cyanAdding, contrastText: 'white'},
      disabled: {main: Theming.greyColors['300'], contrastText: 'white'}
    },
    info3: {
      active: {main: addingColors.cyanAdding, contrastText: 'white'},
      disabled: {main: Theming.greyColors['300'], contrastText: 'white'}
    },
    info4: {
      active: {main: addingColors.blueAdding, contrastText: 'white'},
      disabled: {main: Theming.greyColors['300'], contrastText: 'white'}
    },

    error: {main: baseColors.redAg2r, contrastText: 'white'},
    success: {main: '#4CE686', contrastText: addingColors.greyAdding},
    warning: {main: '#e6864c', contrastText: 'white'},
    info: {main: baseColors.yellowAg2r, contrastText: addingColors.greyAdding},
  },
  typography: {
    default: {
      fontFamily: 'Open Sans',
      fontSize: '0.965rem',
      fontWeight: '300',
      lineHeight: '1.25rem'
    },
    h1: {
      fontSize: '2.15rem',
      fontWeight: '700',
      lineHeight: '2.2rem'
    },
    h2: {
      fontSize: '1.75rem',
      lineHeight: '1.88rem'
    },
    h3: {
      fontSize: '1.5rem',
      lineHeight: '1.88rem'
    },
    h4: {
      fontSize: '1.25rem',
      lineHeight: 'normal'
    },
    h5: {
      fontSize: '1rem',
      lineHeight: '1.5rem'
    },
    subtitle1: {
      fontSize: '1.25rem',
      lineHeight: '1.375rem'
    },
    caption: {
      fontSize: '1rem',
      lineHeight: '1.5rem'
    }
  },
  variables: {
    /* styles/ag2rlm-theme-2018.scss */
    '--ag2r-primayColor': baseColors.brunAg2r,
    '--ag2r-secondaryColor': baseColors.blueAg2r,
    '--ag2r-thirdColor': baseColors.lightGreyAg2r,
    '--ag2r-fourthColor': baseColors.redAg2r,

    /* styles/jahiacontrib.scss */
    '--jahia-contrib-txt-greenColor': '#47d5cd',
    '--jahia-contrib-txt-blueColor': '#00b9e4',
    '--jahia-contrib-txt-underline_blueColor': '#9FBFFF',

    /* styles/prime-ng-custom-theme.scss */
    '--primeng-primaryColor': 'white',
    '--primeng-secondaryColor': baseColors.blueAg2r,
    '--primeng-thirdColor': baseColors.brunAg2r,
    '--primeng-fourthColor': '#333333',
    '--primeng-fifthColor': '#eaeaea',
    '--primeng-sixthColor': '#d8dae2',
    '--primeng-seventhColor': '#c6c6c6',
    '--primeng-eighthColor': '#868686',
    '--primeng-ninthColor': '#a6a6a6',
    '--primeng-tenthColor': '#d0d0d0',
    '--primeng-eleventhColor': '#b7b7b7',
    '--primeng-twelfth': baseColors.lightGreyAg2r,
    '--primeng-thirteenthColor': 'rgba(0, 0, 0, 0.16)',

    /* AutresContratComponent */
    '--autresContrat-primaryColor': 'white',
    '--autresContrat-secondaryColor': baseColors.lightGreyAg2r,

    /* BreadcrumbComponent */
    '--breadcrumb-primaryColor': baseColors.brunAg2r,

    /* BubbleComponent */
    '--bubble-primaryColor': addingColors.blueAdding,
    '--bubble-secondaryColor': 'white',
    '--bubble-textColor': baseColors.brunAg2r,
    '--bubble-selectedTextColor': 'white',

    /* DetailsCompartimentComponent */
    '--detailCompartiment-principalColor': 'white',

    /* DetailContratComponent */
    '--detailContrat-primaryColor': baseColors.brunAg2r,
    '--detailContrat-secondaryColor': addingColors.blueAdding,
    '--detailContrat-thirdColor': '#c9c9c9',
    '--detailContrat-fourthColor': '#a7a7a7',
    '--detailContrat-fifthColor': 'white',
    '--detailContrat-sixthColor': baseColors.lightGreyAg2r,
    '--detailContrat-hoverColor': addingColors.greyAdding,

    /* DoughnutComponent */
    '--doughnut': {
      'bgColor': addingColors.cyanAdding,
      'textColor': addingColors.greyAdding,
      'primaryColor': addingColors.greyAdding,
      'secondaryColor': 'white',
      'thirdColor': addingColors.greyAdding,
      'fourthColor': addingColors.blueAdding
    },

    /* EvenementComponent */
    '--evenement-primaryColor': baseColors.blueAg2r,

    /* FormCheckboxComponent */
    '--formCheckbox-primaryColor': baseColors.blueAg2r,
    '--formCheckbox-secondaryColor': '#c6c6c6',

    /* NavMenuComponent */
    '--nav-menu-primaryColor': baseColors.brunAg2r,
    '--nav-menu-secondaryColor': 'white',
    '--nav-menu-thirdColor': baseColors.lightGreyAg2r,
    '--nav-menu-fourthColor': addingColors.blueAdding,
    '--nav-menu-primaryColor-hover': '#5C91AF',
    '--nav-menu-selected-active': '#5C91AF',
    '--nav-menu-secondaryColor-hover': 'white',

    /*TrmHeaderMenu*/
    '--trm-header-menu-primaryColor':  addingColors.blueAdding,
    '--trm-header-menu-user-color': addingColors.blueAdding,
    '--trm-header-menu-user-color-textColor': 'white',
    '--trm-header-menu-user-other-color': 'white',
    '--trm-header-menu-nav-contrat-text': baseColors.superHeaderText,
    '--trm-header-menu-nav-border': baseColors.greyAg2r,
    '--trm-header-menu-nav-selected-active': '#5C91AF',
    '--trm-header-menu-user-contact-button-text-color-hover': '#5C91AF',
    '--trm-header-menu-user-contact-button-text-color': addingColors.blueAdding,
    '--trm-header-menu-nav-color': baseColors.lightGreyAg2r,
    '--trm-header-menu-user-hover': addingColors.cyanAdding,
    '--trm-header-menu-user-acount': addingColors.cyanAdding,


    /* OngletCompartiment */
    '--onglet-primaryColor': 'rgba(99, 102, 106, .90)',
    '--onglet-secondaryColor': 'white',
    '--onglet-thirdColor': addingColors.blueAdding,
    '--onglet-fourthColor': addingColors.greyAdding,
    '--onglet-fifthColor': baseColors.lightGreyAg2r,
    '--onglet-textColor': baseColors.brunAg2r,

    /* PostLazyLoaderComponent */
    '--postLazyLoader-primaryColor': '#f6f7f8',
    '--postLazyLoader-secondaryColor': 'white',

    /* ScrollableComponent */
    '--scrollable-primaryColor': baseColors.brunAg2r,
    '--scrollable-secondaryColor': baseColors.lightGreyAg2r,
    '--scrollable-thirdColor': '#f4f4f4',

    /* SimulateurComponent */
    '--simulateur-primaryColor': addingColors.blueAdding,
    '--simulateur-secondaryColor': addingColors.cyanAdding,
    '--simulateur-thirdColor': '#c9c9c9',
    '--simulateur-fourthColor': 'white',
    '--simulateur-fifthColor': baseColors.brunAg2r,
    '--simulateur-textRightColor': 'white',

    /* SyntheseComponent */
    '--synthese-primaryColor': baseColors.lightGreyAg2r,
    '--synthese-secondaryColor': 'white',
    '--synthese-thirdColor': baseColors.brunAg2r,
    '--synthese-fourthColor': 'lightgrey',
    '--synthese-textErrorColor': baseColors.redAg2r,


    /* VosActionsComponent */
    '--vosAction-primaryColor': 'white',
    '--vosAction-secondaryColor': addingColors.blueAdding,
    '--vosAction-thirdColor': '#cccccc',
    '--vosAction-fourthColor': baseColors.brunAg2r,

    /* EcrsObjectifComponent */
    '--objectif-primaryColor': 'white',
    '--objectif-secondaryColor': baseColors.blueAg2r,
    '--objectif-thirdColor': '#cccccc',
    '--objectif-fourthColor': baseColors.brunAg2r,

    /* OnboardingConfigComponent */
    '--onboardingConfig-primaryColor': 'white',
    '--onboardingConfig-secondaryColor': baseColors.yellowAg2r,
    '--onboardingConfig-thirdColor': '#e5e5e5',
    '--onboardingConfig-fourthColor': baseColors.blueAg2r,

    /* EcrsArticleTemplateComponent */
    '--articleTemplate-contentBackgroundColor': 'white',
    '--articleTemplate-backgroundColor': baseColors.lightGreyAg2r,
    '--articleTemplate-hashtagBackgroundColor': addingColors.blueAdding,
    '--articleTemplate-hashtagTextColor': 'white',
    '--articleTemplate-dateTextColor': 'rgba(56, 26, 10, 0.7)',

    /* EcrsBadgeComponent */
    '--badge-primaryColor': 'white',
    '--badge-secondaryColor': baseColors.brunAg2r,
    '--badge-thirdColor': '#939393',
    '--badge-fourthColor': baseColors.blueAg2r,

    /* EcrsErrorMajeureComponent*/
    '--erreurMajeure-principalColor': 'white',

    /* EcrsErrorMineureComponent*/
    '--erreurMineure-principalColor': 'white',
    '--erreurMineure-secondaryColor': baseColors.redAg2r,

    /* EcrsErrorModereeComponent*/
    '--erreurModeree-principalColor': 'white',
    '--erreurModeree-secondaryColor': baseColors.redAg2r,

    /* StepperComponent */
    '--stepper-primaryColor': addingColors.blueAdding,
    '--stepper-actionColor': addingColors.cyanAdding,
    '--stepper-secondaryColor': 'white',
    '--stepper-disabledColor': '#939393',
    '--stepper-disabledSecondaryColor': '#c9c9c9',

    /* EcrsProgressBarComponent */
    '--progressBar-primaryColor': addingColors.blueAdding,

    /* SpinnerComponent */
    '--spinner-primaryColor': addingColors.blueAdding,

    /* ContactReclamationComponent */
    '--contactReclamation-backgroundColor': 'white',
    '--contactReclamation-inputbackgroundColor': '#f2f2f2',
    '--contactReclamation-msgErreurColor': baseColors.redAg2r,
    '--contactReclamation-calendarbackgroundColor': '#dee2e6',
    '--contactReclamation-dateColor': 'black',
    '--contactReclamation-listeDeroulanteColor': '#848484',
    '--contactReclamation-listeDeroulanteIconColor': '#868686',
    '--contactReclamation-toastSuccesColor': '#008000',
    '--contactReclamation-selectionButtonColor': '#0000FF',

    /* CoordonneesBancairesComponent */
    '--coordonneesBancaires-primaryColor': 'white',
    '--coordonneesBancaires-secondaryColor': '#381a0a',
    '--coordonneesBancaires-thirdColor': '#0052ff',
    '--coordonneesBancaires-fourthColor': '#5e5e5e',
    '--coordonneesBancaires-fifthColor': '#c9c9c9',

    /* QAD */
    '--gestFinQad-primaryColor': '#ffffff',
    '--gestFinQad-secondaryColor': addingColors.blueAdding,
    '--gestFinQad-thirdColor': '#47d5cd',
    '--gestFinQad-fifthColor': '#a6a6a6',

    /* EcrsTableauRepartFinanciereComponent */
    '--tableauRepartFin-ligneBgColor': 'white',
    '--tableauRepartFin-ligneBorderColor': '#939393',
    '--tableauRepartFin-totalBgColor': '#c9c9c9',
    '--tableauRepartFin-fieldsetBorderColor': '#c9c9c9',
    '--tableauRepartFin-actionColor': '#0052ff',
    '--tableauRepartFin-secondaryColor': baseColors.brunAg2r,
    '--tableauRepartFin-fontColor': baseColors.brunAg2r,
    '--tableauRepartFin-noneColor': '#000',
    '--tableauRepartFin-partialColor': '#000',
    '--tableauRepartFin-completeColor': '#000',
    '--tableauRepartFin-selectionBgColor': addingColors.blueAdding,
    '--tableauRepartFin-selectionColor': 'white',

    /* EcrsRepartitionFinanciereContratComponent */
    '--repartFinanciere-tagBackgroundColor': '#fff',
    '--repartFinanciere-tagBorderColor': addingColors.blueAdding,
    '--repartFinanciere-iconDownloadColor': addingColors.cyanAdding,
    '--repartFinanciere-tagFontColor': baseColors.brunAg2r,

    '--typeSujet': {
      COMPRENDRE: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.idea},
      ESTIMER: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.additionalPension},
      AMELIORER: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.trackProgress},
      DEFISCALISER: {
        couleur: addingColors.cyanAdding,
        contrastText: 'white',
        icone: icones.speedWeighBoost
      },
      DECOUVRIR: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.multiscreens},
      BIA: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.multiscreens},
      VERIFICATIONIDENTITE: {
        couleur: addingColors.cyanAdding,
        contrastText: 'white',
        icone: icones.multiscreens
      },

      default: {couleur: addingColors.cyanAdding, contrastText: 'white', icone: icones.multiscreens}
    },

    /* Parcours manuscrit Confirmation */
    '--manuscrit-confirmation-picto': {
      verifier: {bgcolor: addingColors.cyanAdding, color: '#381a0a'},
      imprimer: {bgcolor: addingColors.cyanAdding, color: '#381a0a'},
      envoyer: {bgcolor: addingColors.cyanAdding, color: '#381a0a'},
    }
  }
});
