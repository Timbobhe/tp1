import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'trm-container-card-with-picto',
  templateUrl: './container-card-with-picto.component.html',
  styleUrls: ['./container-card-with-picto.component.scss']
})
export class ContainerCardWithPictoComponent implements OnInit {

  @Input()
  backgroundIconColor: 'info1' | 'info2' | 'info3' | 'info4' | 'info5';

  @Input()
  icon: string;

  @Input()
  titre: string;

  @Input()
  soustitre: string;

  @Input()
  linkTo: string;
  @Input()
  lien: string;

  @Input()
  heightPicto = '3.125rem';

  backgroundColor: string;
  isInfo1 = false;
  isInfo2 = false;
  isInfo3 = false;
  isInfo4 = false;
  isInfo5 = false;

  constructor(private readonly router: Router) {}

  ngOnInit() {
    if (this.backgroundIconColor === 'info1') {
      this.isInfo1 = true;
    }
    if (this.backgroundIconColor === 'info2') {
      this.isInfo2 = true;
    }
    if (this.backgroundIconColor === 'info3') {
      this.isInfo3 = true;
    }
    if (this.backgroundIconColor === 'info4') {
      this.isInfo4 = true;
    }
    if (this.backgroundIconColor === 'info5') {
      this.isInfo5 = true;
    }

  }

  linkToGo() {
    this.router.navigate([this.linkTo]);
  }

}


