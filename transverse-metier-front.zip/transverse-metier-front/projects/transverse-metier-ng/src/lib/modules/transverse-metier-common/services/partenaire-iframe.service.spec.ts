import { TestBed } from '@angular/core/testing';

import { PartenaireIframeService } from './partenaire-iframe.service';
import {
  initialStateWithClientInfos,
  initialStateWithClientInfosAndPartenaireNie
} from '../../../test/store-states.mock';
import { testingModule } from '../../../test/testing-module';

describe('PartenaireIframeService', () => {
  function prepare(partenaire: boolean) {
    const initialState = partenaire ? initialStateWithClientInfosAndPartenaireNie : initialStateWithClientInfos;

    return testingModule({...initialState}, {
      providers: [PartenaireIframeService]
    });
  }

  it('should be created with partenaire', () => {
    prepare(true);
    const service: PartenaireIframeService = TestBed.inject(PartenaireIframeService);
    expect(service).toBeTruthy();
    expect(service.partenaireInfo).toBeTruthy();
  });

  it('should be created without partenaire', () => {
    prepare(false);
    const service: PartenaireIframeService = TestBed.inject(PartenaireIframeService);
    expect(service).toBeTruthy();
    expect(service.partenaireInfo).toBeFalsy();
  });
});
