import { AfterContentInit, Component, ContentChildren, Input, OnInit, QueryList, TemplateRef } from '@angular/core';
import { PrimeTemplate } from 'primeng/api';
import { Observable } from 'rxjs';
import { HeaderData } from '../../../../models/header.model';
import { MenuItem } from '../../../../models/menuItem.model';
import { DeviceSize, ResponsiveService } from '../../../../shared/services/responsive.service';


export interface Templates {
  [k: string]: TemplateRef<any>;
}

@Component({
  selector: 'trm-header-menu',
  templateUrl: './header-menu.component.html',
  styleUrls: ['./header-menu.component.scss']
})
export class HeaderMenuComponent implements OnInit, AfterContentInit {
  @Input() nom: string;
  @Input() prenom: string;
  @Input() data: HeaderData;
  @Input() menuList: MenuItem[];
  @Input() lienContact: string;
  @Input() displayUser = true;
  @Input() isPartenaire = false;
  @Input() displayMenu = true;
  @Input() nombreItemsTablette = 5;
  @Input() nombreItemsMobile = 2;
  @Input() isFilialeAca: boolean = false;
  menuListTablette: MenuItem[] = [];
  menuListMobile: MenuItem[] = [];

  templates: Templates = {};
  @ContentChildren(PrimeTemplate) queryTemplates: QueryList<PrimeTemplate>;
  onResize$: Observable<DeviceSize>;

  constructor(private readonly responsiveService: ResponsiveService) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
    if (this.menuList) {
      for (let index = 0; index < this.nombreItemsTablette && index < this.menuList.length; index++) {
        this.menuListTablette.push(this.menuList[index]);

      }
      for (let index = 0; index < this.nombreItemsMobile  && index < this.menuList.length; index++) {
        this.menuListMobile.push(this.menuList[index]);

      }
    }
  }

  ngAfterContentInit(): void {
    this.templates = {};
    this.queryTemplates.forEach((item) => {
      this.templates[item.getType()] = item.template;
    });
  }


}
