import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'trm-layout-pop-in',
  templateUrl: './layout-pop-in.component.html',
  styleUrls: ['./layout-pop-in.component.scss'],
})
export class LayoutPopInComponent implements OnInit {
  @Input() displayPop = true;
  @Input() fullScreen = false;
  @Input() closable = true;
  @Output() onClose = new EventEmitter<boolean>();

  constructor() {}

  ngOnInit() {}

  closePopin() {
    this.displayPop = false;
    this.onClose.emit(true);
  }
}
