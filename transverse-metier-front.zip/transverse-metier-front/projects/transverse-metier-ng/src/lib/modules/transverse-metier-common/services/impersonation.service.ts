import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../reducers/global.state';
import { selectInfoClient } from '../../../reducers/transverse-metier.selectors';
import { filter, takeUntil } from 'rxjs/operators';
import { of } from 'rxjs';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { PushToastMessage } from '../../../actions/ui.actions';

@Injectable({
  providedIn: 'root'
})
export class ImpersonationService {

  private impersonation = null;

  constructor(private readonly store: Store<GlobalState>) {
    this.store.select(selectInfoClient)
      .pipe(
        takeUntil(of(this.impersonation).pipe(filter(x => !!x)))
      )
      .subscribe(x => {
        this.impersonation = x.impersonation;
        trace('Mode impersonation :', this.impersonation);
      });
  }

  isImpersonation() {
    return this.impersonation;
  }

  protect(actionLabel: string, action: () => any, onImpossible: () => any = null) {
    if (this.impersonation === null) {
      this.store.dispatch(new PushToastMessage({severity: 'error', summary: 'Impersonation non initialisé'}));
    } else if (this.impersonation === true) {
      this.store.dispatch(new PushToastMessage({
        severity: 'warn',
        summary: 'Impersonation',
        detail: `${actionLabel} interdite en impersonation`
      }));
      if (onImpossible) {
        onImpossible();
      }
    } else if (this.impersonation === false) {
      action();
    }
  }

}
