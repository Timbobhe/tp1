import { AfterViewInit, Directive, EventEmitter, OnDestroy, OnInit, Output, ViewContainerRef } from '@angular/core';
import { Subject, Subscription } from 'rxjs';
import { distinctUntilChanged, tap } from 'rxjs/operators';

@Directive({
  selector: '[inView]'
})
export class InViewDirective implements OnInit, OnDestroy, AfterViewInit {

  @Output() onInView = new EventEmitter<boolean>();
  inView$ = new Subject<boolean>();
  subscription: Subscription;

  constructor(
    private vcRef: ViewContainerRef) {
  }

  ngOnInit(): void {
    this.subscription = this.inView$.pipe(
      distinctUntilChanged(),
      tap(e => this.onInView.emit(e))
    ).subscribe();
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }


  ngAfterViewInit() {
    const commentEl = this.vcRef.element.nativeElement; // template
    const elToObserve = commentEl.parentElement;
    this.setMinWidthHeight(elToObserve);

    try {
      const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          this.renderContents(entry.isIntersecting);
        });
      }, {threshold: [0, .1, .9, 1]});
      observer.observe(elToObserve);
    } catch (e) {
      console.error('in-view', e);
      this.renderContents(true);
    }
  }

  renderContents(isInView) {
    this.inView$.next(isInView);
  }

  setMinWidthHeight(el) { // prevent issue being visible all together
    const style = window.getComputedStyle(el);
    const [width, height] = [parseInt(style.width, 10), parseInt(style.height, 10)];
    if (!width) {
      el.style.minWidth = '40px';
    }
    if (!height) {
      el.style.minHeight = '40px';
    }
  }

}
