import { Component, Inject, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CancelSigElecDem, DemandeSigElec } from '../../../../actions/sig-elec.actions';
import { GlobalState } from '../../../../reducers/global.state';
import { Store } from '@ngrx/store';

import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { APP_CONFIG, AppConfig } from '../../../../models/app.model';
import { ImpersonationService } from '../../services/impersonation.service';
import { DeviceSize, ResponsiveService } from '../../../../shared/services/responsive.service';
import { RedirectService } from '../../../../shared/services/redirect.service';
import { getCssVariable } from '../../../../shared/utils/css-utils';


@Component({
  selector: 'trm-demsigelec',
  templateUrl: './demsigelec.component.html',
  styleUrls: ['./demsigelec.component.scss']
})
export class DemsigelecRepriseComponent implements OnInit {

  @Input() operationType: string | any;
  @Input() urlRetour: string;
  @Input() demandeSigElec: DemandeSigElec;

  demandeEncours$: Observable<DemandeSigElec>;
  dictionnaireFeature: string;
  fonctionnalite: string;
  onResize$: Observable<DeviceSize>;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly redirectService: RedirectService,
    private readonly activeRoute: ActivatedRoute,
    private readonly responsiveService: ResponsiveService,
    private readonly impersonationService: ImpersonationService,
    @Inject(APP_CONFIG) private readonly appConfig: AppConfig) {
    this.onResize$ = this.responsiveService.onResize$;
  }

  ngOnInit() {
    const feature = this.appConfig.featureMap[this.operationType];
    this.fonctionnalite = feature.libelle;
    this.dictionnaireFeature = feature.dico;

    if (this.demandeSigElec) {
      this.demandeEncours$ = of(this.demandeSigElec);
    }
    else {
      this.demandeEncours$ = this.store.select('sigElec').pipe(
        filter(sigDem => sigDem && sigDem.isFetched),
        map(sigDem => sigDem.demande)
      );
    }
  }

  ngStyle() {
    return {'background-image': getCssVariable(this.appConfig.featureMap[this.operationType].image)};
  }

  reprendreSigElec(demandeEncours: DemandeSigElec) {
    this.impersonationService.protect('Reprise signature électronique',
      () => this.redirectService.openUrl(demandeEncours.urlPageSignature));
  }

  newSigElecDem(demandeEncours: DemandeSigElec) {
    this.impersonationService.protect('Nouvelle signature électronique (annulation)', () => {
      const acn = new CancelSigElecDem({idDemande: demandeEncours.idExt, operationType: demandeEncours.operationType});
      acn.payload.onSuccess = data => this.router.navigate([this.urlRetour], {relativeTo: this.activeRoute});
      this.store.dispatch(acn);
    });
  }
}
