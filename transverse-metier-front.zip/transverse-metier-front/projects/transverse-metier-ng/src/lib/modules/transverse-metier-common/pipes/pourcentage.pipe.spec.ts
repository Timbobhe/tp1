import { PourcentagePipe } from './pourcentage.pipe';
import { CommonModule, PercentPipe } from '@angular/common';
import { waitForAsync, TestBed } from '@angular/core/testing';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';

registerLocaleData(localeFr, 'fr');

describe('PourcentagePipe', () => {
  let pipe: PourcentagePipe;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [CommonModule],
      declarations: [PourcentagePipe],
      providers: [
        {provide: PercentPipe, useClass: PercentPipe},
        {provide: PourcentagePipe, useClass: PourcentagePipe}
      ]
    })
      .compileComponents();
  }));

  it('create an instance', () => {
    pipe = TestBed.inject(PourcentagePipe);
    expect(pipe).toBeTruthy();
  });

  it('format 20 %', () => {
    pipe = TestBed.inject(PourcentagePipe);
    const actual = pipe.transform(0.2);
    expect(typeof actual).toBe('string');
    expect(actual.match(/^20\s*%$/)).toBeTruthy();
  });

  it('format 20.50 %', () => {
    pipe = TestBed.inject(PourcentagePipe);
    const actual = pipe.transform(0.205);
    expect(typeof actual).toBe('string');
    expect(actual.match(/^20,50\s*%$/)).toBeTruthy();
  });

});
