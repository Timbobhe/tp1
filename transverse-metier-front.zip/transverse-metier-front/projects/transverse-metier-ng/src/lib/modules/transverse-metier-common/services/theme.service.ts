import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Theming } from '../../../models';
import { setCssVariable } from '../../../shared/utils/css-utils';
import { AddingTheme } from '../themes/theme-adding';
import { Ag2rTheme } from '../themes/theme-ag2r';
import { NieTheme } from '../themes/theme-nie';
import { ThemeConfig, ThemeType, THEME_CONFIG } from './theme.config';

export const DEFAULT_THEMES = {
  ag2r: Ag2rTheme,
  adding: AddingTheme,
  nie: NieTheme
};

export const DEFAULT_LOGOS = {
  ag2r: {name: 'ag2r'},
  aca: {name: 'aca'},
  nie: {name: 'nie'},
  adding: {name: 'adding'}
};


@Injectable({
  providedIn: 'root'
})
export class ThemeService {

  private _currentThemeType: ThemeType;

  private _onChange = new BehaviorSubject<{ themeType: ThemeType, theme: Theming.Theme }>(null);

  constructor(
    private readonly configService: ConfigService,
    @Inject(THEME_CONFIG) private readonly themeConfig: ThemeConfig) {
    if (!this.themeConfig.themes) {
      this.themeConfig.themes = {};
    }
    this.themeConfig.themes = {...DEFAULT_THEMES, ...this.themeConfig.themes};

    if (!this.themeConfig.logos) {
      this.themeConfig.logos = {};
    }
    this.themeConfig.logos = {...DEFAULT_LOGOS, ...this.themeConfig.logos};

    if (this.themeConfig.defaultTheme) {
      console.log(`DEFAULT THEME = `, this.themeConfig.defaultTheme);
      this.changeTheme(themeConfig.defaultTheme.themeType, themeConfig.defaultTheme.logoName);
    }
  }

  get currentThemeType() {
    return this._currentThemeType;
  }

  get onChange() {
    return this._onChange.asObservable();
  }

  get currentTheme(): Observable<Theming.Theme> {
    return this.onChange.pipe(map(x => x.theme));
  }

  changeTheme(themeType: ThemeType, logoName: string = null) {
    this._currentThemeType = themeType;
    const theme = this.getCurrentTheme();
    if (this.themeConfig.onInitTheme) {
      this.themeConfig.onInitTheme(theme, this.configService);
    }

    const tv: any = theme.toCssVars();


    let logo = logoName ? this.themeConfig.logos[logoName] : null;
    if (logo && this.themeConfig.onInitLogo) {
      logo = this.themeConfig.onInitLogo({...logo}, this.configService);
    }

    console.log(`THEME ${themeType} APPLIED (LOGO ${logoName})`);
    this.applyTheme(tv, logo);

    this._onChange.next({themeType, theme: this.getCurrentTheme()});
  }

  getCurrentTheme() {
    if (this.currentThemeType) {
      return this.themeConfig.themes[this.currentThemeType];
    }
    return null;
  }

  private applyTheme(theme: any, logo: any) {
    const themeLogo = {...theme, ...logo};
    for (const key in themeLogo) {
      if (themeLogo.hasOwnProperty(key)) {
        const value = themeLogo[key];
        setCssVariable(key, value);
      }
    }
  }

  get theme() {
    return this.getCurrentTheme();
  }
}
