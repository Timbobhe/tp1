import { Inject, Injectable, InjectionToken, NgZone, Optional } from '@angular/core';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { ApiAction, ApiCallerService, PerformanceConfig } from '@ag2rlamondiale/redux-api-ng';

export interface TraceFrontConfig extends PerformanceConfig {
  traceFront?: boolean;
}

export interface NombreTracesConfig {
  [k: string]: { number: number, justLog?: boolean };
}

interface BasicNombreTracesConfig {
  [k: string]: number;
}

export const TRACE_FRONT_CONFIG = new InjectionToken<NombreTracesConfig>('Configuration des Traces Front');

export class TracePerformanceMeasure {
  name: string;
  startTime: number;
  timeOrigin: number;
  startTimeFromOrigin: Date;
  endTimeFromOrigin: Date;
  duration: number;
  justLog = false;
}

class TracePerformanceAction extends ApiAction<any, TracePerformanceMeasure[]> {

  constructor(traces: TracePerformanceMeasure[]) {
    super('[TRACE_FRONT]_PERFORMANCE', 'backend/traceFrontPerformance', traces);
    this.payload.method = 'POST';
    this.payload.requestData = traces;
  }
}


@Injectable({
  providedIn: 'root'
})
export class TraceFrontService {

  private readonly traceConfig: TraceFrontConfig;

  nombreTraces: BasicNombreTracesConfig = {};
  private nombreTracesConfig: NombreTracesConfig = {};

  constructor(
    private readonly configService: ConfigService,
    private readonly ngZone: NgZone,
    private readonly apiCallerService: ApiCallerService,
    @Optional() @Inject(TRACE_FRONT_CONFIG) private readonly injectableNombreTracesConfig: NombreTracesConfig) {

    this.traceConfig = this.configService.config.performance || {active: false};
    console.log('TraceFrontConfig', this.traceConfig, injectableNombreTracesConfig);

    if (this.injectableNombreTracesConfig) {
      this.prepareSending(this.injectableNombreTracesConfig);
    }
  }

  map(measure: PerformanceMeasure): TracePerformanceMeasure {
    const res: TracePerformanceMeasure = new TracePerformanceMeasure();
    res.name = measure.name;
    res.duration = measure.duration;
    res.timeOrigin = performance.timeOrigin;
    res.startTime = measure.startTime;
    res.startTimeFromOrigin = new Date(performance.timeOrigin + measure.startTime);
    res.endTimeFromOrigin = new Date(performance.timeOrigin + measure.startTime + measure.duration);
    return res;
  }

  configure(names: NombreTracesConfig) {
    Object.entries(names).forEach(e => {
      const [name, cfg] = e;
      this.nombreTraces[name] = 0;
      this.nombreTracesConfig[name] = cfg;
    });
  }

  verifyPerformanceNotActive() {
    return !this.traceConfig.active || !this.traceConfig.traceFront || !performance;
  }

  prepareSending(names: NombreTracesConfig) {
    this.configure(names);
    if (this.verifyPerformanceNotActive()) {
      console.warn('performance Not Active');
      return;
    }

    const sender = (list, observer) => {
      const measures: TracePerformanceMeasure[] = [];
      list.getEntries().forEach(e => {
        const cfg = this.nombreTracesConfig[e.name];
        if (cfg && cfg.number > this.nombreTraces[e.name]) {
          const measure = this.map(e);
          measure.justLog = cfg.justLog;
          ++this.nombreTraces[e.name];
          measures.push(measure);
        }
      });

      if (measures.length > 0) {
        this.sendTracePerformance(measures);
      }

      if (this.checkNombreTracesAllPassed()) {
        observer.disconnect();
      }
    };

    try {
      new PerformanceObserver(sender).observe({entryTypes: ['measure']});
    } catch (e) {
      console.error('performance-traceFront', e);
    }
  }

  sendTracePerformance(traces: TracePerformanceMeasure[]) {
    if (traces && traces.length > 0) {
      this.ngZone.runOutsideAngular(() =>
        this.apiCallerService.basicRequest(new TracePerformanceAction(traces))
          .subscribe()
      );
    }
  }

  checkNombreTracesAllPassed() {
    let allPassed = true;
    Object.entries(this.nombreTracesConfig).forEach(e => {
      const [name, cfg] = e;
      allPassed = allPassed && (this.nombreTraces[name] === cfg.number);
    });

    return allPassed;
  }

}
