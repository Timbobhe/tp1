import { Location } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { DeviceSize, ResponsiveService } from '../../../../shared/services/responsive.service';
import { getCssVariable } from '../../../../shared/utils/css-utils';
import { UrlService } from '../../../../shared/utils/url-utils';

@Component({
  selector: 'trm-layout-functionality',
  templateUrl: './layout-functionality.component.html',
  styleUrls: ['./layout-functionality.component.scss']
})
export class LayoutFunctionalityComponent implements OnInit {
  /**
   * Nom de la variable css
   */
  @Input() backgroundImageDesktop: string;

  /**
   * Nom de la variable css
   */
  @Input() backgroundImageMobile: string;

  @Input() contentSameSize = false;
  @Input() header = true;

  onResize$: Observable<DeviceSize>;

  constructor(
    private readonly responsive: ResponsiveService,
    private readonly location: Location,
    public readonly urlService: UrlService) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit() {
  }

  goBack() {
    this.location.back();
  }

  ngStyle(device: DeviceSize) {
    return {'background-image': device.isMobile() ? getCssVariable(this.backgroundImageMobile) : getCssVariable(this.backgroundImageDesktop)};
  }
}
