import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutFunctionalityComponent } from './layout-functionality.component';
import {NO_ERRORS_SCHEMA} from '@angular/core';
import {Location} from '@angular/common';

describe('EcrsLayoutFunctionalityComponent', () => {
  let component: LayoutFunctionalityComponent;
  let fixture: ComponentFixture<LayoutFunctionalityComponent>;

  let locationStub: Partial<Location>;

  locationStub = {
    back: function () { }
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ LayoutFunctionalityComponent ],
      schemas: [ NO_ERRORS_SCHEMA ],
      providers: [
        { provide: Location, useValue: locationStub }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutFunctionalityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
