/* tslint:disable:no-unused-variable */
import { Ag2rTheme } from './theme-ag2r';
import { AddingTheme } from './theme-adding';
import { NieTheme } from './theme-nie';
import { Theming } from '../../../models';


describe('themes', () => {

  it('should has full Themes', () => {
    const miniTheme = Theming.Theme.from({
      name: 'test',
      palette: {
        primary: {main: 'blue', contrastText: '#FFF'},
        secondary: {main: 'orange', contrastText: '#FFF'},
        info: {main: 'yellow', contrastText: '#000'},
        text: {primary: '#000', disabled: 'grey'}
      },
      typography: {
        default: {
          fontFamily: 'Arial',
          fontWeight: 'normal',
          fontSize: '12px',
          lineHeight: 'normal'
        },
        h1: {fontSize: '20px'},
        h2: {fontSize: '18px'},
        h3: {fontSize: '16px'},
        h4: {fontSize: '14px'},
      }
    });

    const mini = miniTheme.toCssVars();
    const ag2r = Ag2rTheme.toCssVars();
    const adding = AddingTheme.toCssVars();
    const nie = NieTheme.toCssVars();

    console.log('mini', Object.keys(mini));
    console.log('ag2r', Object.keys(ag2r));

    const clesMiniAbsentesAg2r = Object.keys(mini).filter(e => !ag2r.hasOwnProperty(e));
    console.log('Clé mini absentes de ag2r', clesMiniAbsentesAg2r);

    expect(clesMiniAbsentesAg2r.length).toEqual(0);
    expect(new Set(Object.keys(ag2r))).toEqual(new Set(Object.keys(adding)));
    expect(new Set(Object.keys(ag2r))).toEqual(new Set(Object.keys(adding)));
    expect(new Set(Object.keys(ag2r))).toEqual(new Set(Object.keys(nie)));
  });

});
