import { CoordonneesBancaires, InfosBlocagesClient } from '../../models';

export function coordonneesBancairesNonBloquees(
  blocage: InfosBlocagesClient,
  coordonneesBancaires: CoordonneesBancaires[],
  fonctionnaliteBloquee: string) {

  const coordonneesBancairesFiltres: CoordonneesBancaires[] = [];
  coordonneesBancaires.forEach(i => {
    if (!blocage.isFonctionnaliteBloqueePourContrat(i.contrat.nomContrat, fonctionnaliteBloquee)) {
      coordonneesBancairesFiltres.push(i);
    }
  });

  return coordonneesBancairesFiltres;
}
