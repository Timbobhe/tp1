import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { OgiIconModule } from '@ag2rlamondiale/ogi-lib';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EffectsModule } from '@ngrx/effects';
import { InputMaskModule } from 'primeng/inputmask';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { MessagesModule } from 'primeng/messages';
import { RadioButtonModule } from 'primeng/radiobutton';
import { SelectButtonModule } from 'primeng/selectbutton';
import { SharedModule } from '../../shared/shared.module';
import { IdentiteNumModule } from '../identite-num/identite-num.module';
import { TransverseMetierCommonModule } from '../transverse-metier-common/transverse-metier-common.module';
import { CoordonneesBancairesConsultationComponent } from './coordonnees-bancaires-consultation/coordonnees-bancaires-consultation.component';
import { CoordonneesBancairesDemsigelecComponent } from './coordonnees-bancaires-demsigelec/coordonnees-bancaires-demsigelec.component';
import { CoordonneesBancairesEcritureComponent } from './coordonnees-bancaires-ecriture/coordonnees-bancaires-ecriture.component';
import { CoordonneesBancairesLectureComponent } from './coordonnees-bancaires-lecture/coordonnees-bancaires-lecture.component';
import { CoordonneesBancairesMatchAccountComponent } from './coordonnees-bancaires-match-account/coordonnees-bancaires-match-account.component';
import { CoordonneesBancairesModificationComponent } from './coordonnees-bancaires-modification/coordonnees-bancaires-modification.component';
import { ReglesMetiersRib } from './coordonnees-bancaires-modification/regles-metiers/regles-metiers-rib';
import { CoordonneesBancairesRoutingModule } from './coordonnees-bancaires-routing.module';
import { CoordonneesBancairesSigelecRedirectComponent } from './coordonnees-bancaires-sigelec-redirect/coordonnees-bancaires-sigelec-redirect.component';
import { CoordonneesBancaireTrackingEffects } from './coordonnees-bancaires-tracking-effects.service';
import { CoordonneesBancairesComponent } from './coordonnees-bancaires.component';
import { BicPipe } from './pipes/bic.pipe';
import { IbanPipe } from './pipes/iban.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    JahiaNgModule,
    InputTextareaModule,
    RadioButtonModule,
    SharedModule,
    TransverseMetierCommonModule,
    CoordonneesBancairesRoutingModule,
    SelectButtonModule,
    MessagesModule,
    IdentiteNumModule,
    EffectsModule.forFeature([CoordonneesBancaireTrackingEffects]),
    InputMaskModule,
    OgiIconModule,
  ],
  providers: [ReglesMetiersRib, BicPipe, IbanPipe],
  declarations: [
    CoordonneesBancairesComponent,
    CoordonneesBancairesConsultationComponent,
    CoordonneesBancairesModificationComponent,
    CoordonneesBancairesMatchAccountComponent,
    CoordonneesBancairesSigelecRedirectComponent,
    CoordonneesBancairesDemsigelecComponent,
    CoordonneesBancairesEcritureComponent,
    CoordonneesBancairesLectureComponent,
    BicPipe,
    IbanPipe,
  ],
  exports: [
    CoordonneesBancairesConsultationComponent,
    CoordonneesBancairesModificationComponent,
    CoordonneesBancairesMatchAccountComponent,
    CoordonneesBancairesSigelecRedirectComponent,
    CoordonneesBancairesDemsigelecComponent,
    CoordonneesBancairesEcritureComponent,
    CoordonneesBancairesLectureComponent,
    BicPipe,
    IbanPipe,
  ],
})
export class CoordonneesBancairesModule {
}
