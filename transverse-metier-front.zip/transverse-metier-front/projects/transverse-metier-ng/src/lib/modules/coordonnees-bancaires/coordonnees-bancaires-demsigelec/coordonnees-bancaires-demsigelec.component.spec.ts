import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { initialStateWithSigElec } from 'test/store-states.mock';
import { CoordonneesBancairesDemsigelecComponent } from './coordonnees-bancaires-demsigelec.component';



describe('CoordonneesBancairesDemsigelecComponent', () => {
  let component: CoordonneesBancairesDemsigelecComponent;
  let fixture: ComponentFixture<CoordonneesBancairesDemsigelecComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CoordonneesBancairesDemsigelecComponent ],
      imports: [RouterModule.forRoot([]), StoreModule.forRoot(fromRoot.reducers, initialStateWithSigElec)],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CoordonneesBancairesDemsigelecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
