import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

export const SIGELEC_MSG_PATH = '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=';

@Component({
  selector: 'mrb-coordonnees-bancaires-sigelec-redirect',
  templateUrl: './coordonnees-bancaires-sigelec-redirect.component.html',
  styleUrls: ['./coordonnees-bancaires-sigelec-redirect.component.scss']
})
export class CoordonneesBancairesSigelecRedirectComponent implements OnInit {
  signatureStatus: string;
  urlPathPrefix: string;

  constructor(private readonly route: ActivatedRoute) {
  }

  ngOnInit() {
    this.signatureStatus = this.route.snapshot.params.status;
    this.urlPathPrefix = SIGELEC_MSG_PATH;
  }
}
