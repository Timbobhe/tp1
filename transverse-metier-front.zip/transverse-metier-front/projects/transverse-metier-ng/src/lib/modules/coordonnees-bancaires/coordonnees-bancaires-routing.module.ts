import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CoordonneesBancairesConsultationComponent } from './coordonnees-bancaires-consultation/coordonnees-bancaires-consultation.component';
import { CoordonneesBancairesDemsigelecComponent } from './coordonnees-bancaires-demsigelec/coordonnees-bancaires-demsigelec.component';
import { CoordonneesBancairesMatchAccountComponent } from './coordonnees-bancaires-match-account/coordonnees-bancaires-match-account.component';
import { CoordonneesBancairesModificationComponent } from './coordonnees-bancaires-modification/coordonnees-bancaires-modification.component';
import { CoordonneesBancairesSigelecRedirectComponent } from './coordonnees-bancaires-sigelec-redirect/coordonnees-bancaires-sigelec-redirect.component';
import { CoordonneesBancairesComponent } from './coordonnees-bancaires.component';
import { ModificationGuard } from './guards/modification.guard';
import { ResetStateGuard } from './guards/reset-state.guard';
import { SigelecGuard } from './guards/sigelec.guard';
import { CoordonneesBancairesStateGuard } from './guards/coordonnees-bancaires-state.guard';
import { StartGuard } from './guards/start.guard';


const routes: Routes = [{
  path: '',
  component: CoordonneesBancairesComponent,
  canActivate: [ResetStateGuard],
  canActivateChild: [CoordonneesBancairesStateGuard],
  children: [
    {
      path: 'consultation',
      component: CoordonneesBancairesConsultationComponent,
      canActivate: [StartGuard]
    },
    {
      path: 'modification',
      component: CoordonneesBancairesModificationComponent,
      canActivate: [ModificationGuard]
    },
    {
      path: 'verification-donnees-personnelles',
      component: CoordonneesBancairesMatchAccountComponent
    },
    {
      path: 'signature/:status',
      component: CoordonneesBancairesSigelecRedirectComponent
    },
    {
      path: 'demande-signature-electronique',
      component: CoordonneesBancairesDemsigelecComponent,
      canActivate: [SigelecGuard]
    },
    {
      path: '**',
      redirectTo: 'consultation',
      pathMatch: 'full'
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoordonneesBancairesRoutingModule {
}
