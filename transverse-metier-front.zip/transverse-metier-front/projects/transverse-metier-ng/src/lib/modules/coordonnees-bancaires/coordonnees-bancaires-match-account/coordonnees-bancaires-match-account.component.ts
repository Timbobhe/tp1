import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { TerminateModifierCoordonneesBancaires, tracking } from '../../../actions';
import { Categorie, TypeOriginAction } from '../../../consts/tracking.const';
import { ModificationCoordonneesBancairesDto } from '../../../models';
import { selectCurrentContratAndCoordonneesBancairesAndInfoClient } from '../../../reducers';
import { GlobalState } from '../../../reducers/global.state';
import { ImpersonationService } from '../../transverse-metier-common/services/impersonation.service';

@Component({
  selector: 'mrb-coordonnees-bancaires-match-account',
  templateUrl: './coordonnees-bancaires-match-account.component.html',
  styleUrls: ['./coordonnees-bancaires-match-account.component.scss']
})
export class CoordonneesBancairesMatchAccountComponent implements OnInit {

  subtitleDescriptionFront = new BehaviorSubject<string>('');
  subtitleRaisonSocialeFront = new BehaviorSubject<string>('');

  URL_NEXT_PAGE = '/';
  urlCancel: string;
  matchAccount: boolean;
  terminating = false;
  demandeModification: ModificationCoordonneesBancairesDto[];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly impersonationService: ImpersonationService) {
  }

  ngOnInit() {
    selectCurrentContratAndCoordonneesBancairesAndInfoClient(this.store).pipe(take(1)).subscribe(x => {
      this.demandeModification = x.coordonneesBancaires.demandeModificationCoordonneesBancaires;
      if (x.currentContrat) {
        this.subtitleDescriptionFront.next(`${x.currentContrat.description} - ${x.currentContrat.nomContrat}`);
        this.subtitleRaisonSocialeFront.next(`${x.currentContrat.raisonSociale != null ? x.currentContrat.raisonSociale : ''}`);
      }
    });
  }

  handleMatchAcocunt(value: boolean) {
    this.matchAccount = value;
  }

  next() {
    this.impersonationService.protect('Signature électronique sur la Modification du RIB', () => this.nextSigElec());
  }

  nextSigElec() {
    if (this.terminating) {
      return;
    }

    const terminate = new TerminateModifierCoordonneesBancaires(this.demandeModification);
    this.terminating = true;
    terminate.payload.onSuccess = (data => {
      this.demandeModification.forEach(demande => {
        // if blank, put '' instead of nothing to ease API requesting
        const modifiedRib = demande.coordonneesBancairesModifiees.codeIBAN || '';
        this.store.dispatch(tracking(Categorie.coordonneesBancaires,
          TypeOriginAction.coordonneesBancaires_confirmation,
          modifiedRib));
      });
      window.location.assign(data);
    });
    terminate.payload.onTerminate = () => this.terminating = false;
    this.store.dispatch(terminate);
  }
}
