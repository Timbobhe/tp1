import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot } from '@angular/router';
import { isRetourSigElec } from '../../../authguards';
import { selectInfoClientAndCoordonneesBancaires } from '../../../reducers';
import { Store } from '@ngrx/store';
import { map, take } from 'rxjs/operators';
import { GlobalState } from '../../../reducers/global.state';

@Injectable({
  providedIn: 'root'
})
export class CoordonneesBancairesStateGuard implements CanActivateChild {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivateChild(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

    return selectInfoClientAndCoordonneesBancaires(this.store).pipe(
      take(1),
      map(x =>
        !isRetourSigElec(x.router.state)
        && !x.coordonneesBancaires.isFetched && !x.router.state.url.endsWith('/coordonnees-bancaires/consultation')
      ),
      map(failed => failed ? this.router.parseUrl('/coordonnees-bancaires') : true)
    );
  }

}
