import { Injectable } from '@angular/core';
import {
  PUSH_COORDONNEES_BANCAIRES,
  PUSH_MODIFICATION_COORDONNEES_BANCAIRES,
  PushModifierCoordonneesBancaires,
  PushSelectedCoordonneesBancaires,
  SetTrackingEnvTemplate
} from '../../actions';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CoordonneesBancaireTrackingEffects {

  @Effect({dispatch: true})
  envTempate$ = this.actions$.pipe(
    ofType(PUSH_COORDONNEES_BANCAIRES),
    map(a => a as PushSelectedCoordonneesBancaires),
    map(a => new SetTrackingEnvTemplate([a.payload.currentCoordonneesBancaires.contrat.codeSilo]))
  );

  @Effect({dispatch: true})
  envTempate2$ = this.actions$.pipe(
    ofType(PUSH_MODIFICATION_COORDONNEES_BANCAIRES),
    map(a => a as PushModifierCoordonneesBancaires),
    map(a => new SetTrackingEnvTemplate(a.payload.demandeModificationCoordonneesBancaires.map(e => e.contratSelected.codeSilo)))
  );


  constructor(private readonly actions$: Actions) {
  }
}
