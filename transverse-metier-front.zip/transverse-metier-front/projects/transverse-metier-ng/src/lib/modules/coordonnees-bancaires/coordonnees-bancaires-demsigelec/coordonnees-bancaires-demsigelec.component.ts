import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { DemandeSigElec } from '../../../actions';
import { SIGELEC_RIBA } from '../../../consts';
import { selectCurrentContratAndCoordonneesBancairesAndInfoClient } from '../../../reducers';
import { GlobalState } from '../../../reducers/global.state';

@Component({
  selector: 'mrb-coordonnees-bancaires-demsigelec',
  templateUrl: './coordonnees-bancaires-demsigelec.component.html',
  styleUrls: ['./coordonnees-bancaires-demsigelec.component.scss']
})
export class CoordonneesBancairesDemsigelecComponent implements OnInit {
  fonctionnalite = SIGELEC_RIBA;
  demandeEncours: DemandeSigElec;

  subtitleDescriptionFront = new BehaviorSubject<string>('');
  subtitleRaisonSocialeFront = new BehaviorSubject<string>('');


  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    selectCurrentContratAndCoordonneesBancairesAndInfoClient(this.store).pipe(take(1)).subscribe(x => {
      if (x.currentContrat) {
        this.subtitleDescriptionFront.next(`${x.currentContrat.description} - ${x.currentContrat.nomContrat}`);
        this.subtitleRaisonSocialeFront.next(`${x.currentContrat.raisonSociale != null ? x.currentContrat.raisonSociale : ''}`);
      }
    });
  }
}
