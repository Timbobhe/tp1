import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { filter, map } from 'rxjs/operators';
import { API, API_ERROR, API_SUCCESS, ApiAction, ApiError, ApiSuccess } from '@ag2rlamondiale/redux-api-ng';
import { UPDATE_COORDONNEES_CLIENT } from '../../actions/coordonnees-client.actions';
import { tracking } from '../../actions/tracking.action';

@Injectable({
  providedIn: 'root'
})
export class IdentiteNumTrackingEffects {

  @Effect({dispatch: true})
  modifierDonneesPerso$ = this.actions$.pipe(
    ofType(API),
    map(a => a as ApiAction),
    filter(a => a.payload.label === UPDATE_COORDONNEES_CLIENT),
    map(a => tracking(null, 'modifier-donnees-personnelles'))
  );

  @Effect({dispatch: true})
  modifierDonneesPersoSuccess$ = this.actions$.pipe(
    ofType(API_SUCCESS),
    map(a => a as ApiSuccess<any>),
    filter(a => a.payload.label === UPDATE_COORDONNEES_CLIENT),
    map(a => tracking(null, 'modifier-informations-signature', 'OK'))
  );

  @Effect({dispatch: true})
  modifierDonneesPersoError$ = this.actions$.pipe(
    ofType(API_ERROR),
    map(a => a as ApiError),
    filter(a => a.payload.label === UPDATE_COORDONNEES_CLIENT),
    map(a => tracking(null, 'modifier-informations-signature', 'KO'))
  );

  constructor(private readonly actions$: Actions) {
  }
}
