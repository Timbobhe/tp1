import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EffectsModule } from '@ngrx/effects';
import { SelectButtonModule } from 'primeng/selectbutton';
import { ToastModule } from 'primeng/toast';
import { SharedModule } from '../../shared/shared.module';
import { TransverseMetierCommonModule } from '../transverse-metier-common/transverse-metier-common.module';
import { DonneesPersonnellesComponent } from './donnees-personnelles/donnees-personnelles.component';
import { IdentiteNumRoutingModule } from './identite-num-routing.module';
import { IdentiteNumTrackingEffects } from './identite-num-tracking-effects.service';
import { IdentiteNumComponent } from './identite-num.component';
import { MatchAccountComponent } from './match-account/match-account.component';
import { PieceIdentiteComponent } from './piece-identite/piece-identite.component';
import { UploadIdentiteComponent } from './upload-identite/upload-identite.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IdentiteNumRoutingModule,
    JahiaNgModule,
    SharedModule,
    ToastModule,
    SelectButtonModule,
    EffectsModule.forFeature([IdentiteNumTrackingEffects]),
    TransverseMetierCommonModule,
  ],
  declarations: [
    IdentiteNumComponent,
    PieceIdentiteComponent,
    DonneesPersonnellesComponent,
    UploadIdentiteComponent,
    MatchAccountComponent,
  ],
  exports: [
    IdentiteNumComponent,
    PieceIdentiteComponent,
    DonneesPersonnellesComponent,
    UploadIdentiteComponent,
    MatchAccountComponent,
    ToastModule
  ]
})
export class IdentiteNumModule {}
