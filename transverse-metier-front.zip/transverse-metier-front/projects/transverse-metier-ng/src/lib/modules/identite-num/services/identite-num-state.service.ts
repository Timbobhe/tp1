import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { GlobalState } from '../../../reducers/global.state';
import { Observable } from 'rxjs';
import { selectIdentNumMatchAccount } from '../../../reducers/transverse-metier.selectors';
import { filter, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class IdentiteNumStateService {

  constructor(private readonly store: Store<GlobalState>) {
  }

  donnneesPersoConfirmees$(): Observable<boolean> {
    return this.store.select(selectIdentNumMatchAccount).pipe(
      filter(e => e.isFetched && !!e.identiteNumerique),
      map(e => e.identiteNumerique.donnneesPersoConfirmees)
    );
  }
}
