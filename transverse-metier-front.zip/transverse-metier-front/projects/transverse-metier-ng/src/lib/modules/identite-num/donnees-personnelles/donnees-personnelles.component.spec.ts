/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { DonneesPersonnellesComponent } from './donnees-personnelles.component';
import { testingModule } from '../../../test/testing-module';
import { Globals } from '../../../shared/utils/globals';
import { RouterModule } from '@angular/router';

describe('DonneesPersonnellesComponent', () => {
  let component: DonneesPersonnellesComponent;
  let fixture: ComponentFixture<DonneesPersonnellesComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [DonneesPersonnellesComponent],
      providers: [Globals]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DonneesPersonnellesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
