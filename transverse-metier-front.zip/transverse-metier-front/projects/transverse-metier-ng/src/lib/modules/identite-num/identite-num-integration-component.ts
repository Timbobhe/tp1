export interface IdentiteNumIntegrationComponent {
  setOnParcoursManuscrit(fct: () => any);
}
