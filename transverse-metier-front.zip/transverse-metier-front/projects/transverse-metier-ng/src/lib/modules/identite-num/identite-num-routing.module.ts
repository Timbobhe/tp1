import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IdentiteNumComponent } from './identite-num.component';
import { PieceIdentiteComponent } from './piece-identite/piece-identite.component';
import { UploadIdentiteComponent } from './upload-identite/upload-identite.component';

export const pieceIdentiteRoutes = [
  {
    path: 'piece-identite',
    component: PieceIdentiteComponent,
  },
  {
    path: 'upload-piece-identite',
    component: UploadIdentiteComponent,
  },
  {
    path: '**',
    redirectTo: 'piece-identite',
    pathMatch: 'full'
  }
];

const routes: Routes = [
  {
    path: '',
    component: IdentiteNumComponent,
    canActivate: [],
    children: [
      ...pieceIdentiteRoutes,
      {
        path: '**',
        redirectTo: 'bienvenue',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IdentiteNumRoutingModule {
}
