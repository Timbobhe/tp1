import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { PieceIdentiteComponent } from './piece-identite.component';
import { testingModule } from '../../../test/testing-module';
import { Globals } from '../../../shared/utils/globals';
import { RouterModule } from '@angular/router';

describe('PieceIdentiteComponent', () => {
  let component: PieceIdentiteComponent;
  let fixture: ComponentFixture<PieceIdentiteComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [PieceIdentiteComponent],
      imports: [RouterModule.forRoot([])],
      providers: [Globals]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PieceIdentiteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
