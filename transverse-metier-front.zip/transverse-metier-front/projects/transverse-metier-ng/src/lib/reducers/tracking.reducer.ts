import { ActionTester, ApiActionPayload } from '@ag2rlamondiale/redux-api-ng';
import * as tracking from '../actions/tracking.action';
import { SetTrackingEnvTemplate } from '../actions/tracking.action';
import * as global from '../actions/global.actions';
import { BaseTrackingInfo } from '../models/client/tracking.model';
import { CodeSiloType } from '../models/client/contrat.model';

export class TrackingState {
  tagCommanderDispo = false;
  info: BaseTrackingInfo;
  envTemplate?: Array<CodeSiloType | string>;
}

const initialState = new TrackingState();

export function trackingReducer(state: TrackingState = initialState, action: tracking.TrackingActions | global.GlobalActions) {
  const tester = new ActionTester(action);

  if (action.type === tracking.DISPO_TAG_COMMANDER) {
    return Object.assign(new TrackingState(), {...state, tagCommanderDispo: true});
  }

  if (tester.isSuccess(tracking.TRACKING_INFO_FETCH)) {
    const info = (action.payload as ApiActionPayload<BaseTrackingInfo>).data;
    return Object.assign(new TrackingState(), {...state, info});
  }

  if (action.type === tracking.TRACKING_SET_ENV_TEMPLATE) {
    const a = action as SetTrackingEnvTemplate;
    if (a.payload && a.payload.length > 0) {
      return Object.assign(new TrackingState(), {...state, envTemplate: Array.from(new Set(a.payload)).sort()});
    } else if (!a.payload || a.payload.length === 0) {
      return Object.assign(new TrackingState(), {...state, envTemplate: null});
    }
  }

  if (action.type === global.RESET_STATE) {
    const a = action as global.ResetStateAction<any>;
    if (a.payload.tracking) {
      if (typeof a.payload.tracking === 'function') {
        return Object.assign(new TrackingState(), a.payload.tracking(state), {tagCommanderDispo: state.tagCommanderDispo});
      } else {
        return Object.assign(new TrackingState(), a.payload.tracking, {tagCommanderDispo: state.tagCommanderDispo});
      }
    }
  }

  return state;
}
