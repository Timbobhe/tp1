import { ActionTester, ApiActionPayload } from '@ag2rlamondiale/redux-api-ng';
import * as sigElecActions from '../actions/sig-elec.actions';
import { DemandeSigElec } from '../actions/sig-elec.actions';
import { RESET_STATE, ResetStateAction } from '../actions/global.actions';
import { ActionWithPayload } from '../actions';

export class DemandeSigElecState<T = any> {
  demande: DemandeSigElec<T>;
  isFetched = false;
  loading = false;
  urlRetour: string;
}

const initialState = new DemandeSigElecState();

export function sigElecReducer(state: DemandeSigElecState = initialState, action: ActionWithPayload) {
  const apiTester = new ActionTester(action);

  if (action.type === RESET_STATE) {
    const acn = action as ResetStateAction<any>;
    if (acn.payload.sigElec) {
      return Object.assign(new DemandeSigElecState(), {...acn.payload.sigElec});
    }
  }

  if (apiTester.isStart(sigElecActions.GET_DEM_SIGELEC)) {
    return Object.assign(new DemandeSigElecState(), {...state, loading: true});
  }

  if (apiTester.isSuccess(sigElecActions.GET_DEM_SIGELEC)) {
    const result = (action.payload as ApiActionPayload<any>).data as DemandeSigElec<any>;
    return Object.assign(new DemandeSigElecState(), {...state, demande: result, isFetched: true, loading: false});
  }

  if (apiTester.isError(sigElecActions.GET_DEM_SIGELEC)) {
    return Object.assign(new DemandeSigElecState(), {...state, demande: null, loading: false, isFetched: false});
  }

  if (apiTester.isSuccess(sigElecActions.CANCEL_DEM_SIGELEC)) {
    return new DemandeSigElecState();
  }

  return state;
}
