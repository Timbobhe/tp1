import { Action } from '@ngrx/store';
import {
  ROUTER_CANCEL,
  ROUTER_ERROR,
  ROUTER_NAVIGATED,
  ROUTER_NAVIGATION,
  ROUTER_REQUEST,
  RouterAction,
} from '@ngrx/router-store';

export type NavigationEvent = 'request' | 'cancel' | 'error' | 'navigation' | 'navigated';

export interface NavigationState {
  navigationId: number,
  url: string,
  navigate: boolean;
  navigationEvent: NavigationEvent;
}

const initialState: NavigationState = {
  navigate: false, navigationEvent: undefined, navigationId: undefined, url: undefined
};

export function navigationReducer(
  state: NavigationState = initialState, action: Action): NavigationState {

  const routerAction = action as RouterAction<any>;
  if (!routerAction || !routerAction.payload || !routerAction.payload.event) {
    return state;
  }

  const navigationId = routerAction.payload.event.id;
  const url = routerAction.payload.routerState.url;

  switch (routerAction.type) {
    case ROUTER_REQUEST:
      return {navigationId, navigate: false, navigationEvent: 'request', url};

    case ROUTER_CANCEL:
      return {navigationId, navigate: false, navigationEvent: 'cancel', url};

    case ROUTER_ERROR:
      return {navigationId, navigate: false, navigationEvent: 'error', url};

    case ROUTER_NAVIGATION:
      return {navigationId, navigate: true, navigationEvent: 'navigation', url};

    case ROUTER_NAVIGATED:
      return {navigationId, navigate: true, navigationEvent: 'navigated', url};
  }

  return state;

}
