import { ActionWithPayload } from '../actions';
import { CodeSiloType, InfosBlocagesClient, PartenaireInfo } from '../models';


export interface BaseClientInfoState {
  isFetched: boolean;
  nom: string;
  prenom: string;
  impersonation: boolean;
  silos: CodeSiloType[];
  partenaire?: PartenaireInfo;
  infosBlocagesClient: InfosBlocagesClient;
}

const initialState: BaseClientInfoState = {
  nom: 'nom',
  prenom: 'prenom',
  isFetched: false,
  impersonation: false,
  silos: [],
  partenaire: null,
  infosBlocagesClient: new InfosBlocagesClient()
};

export function baseClientInfosReducer(state: BaseClientInfoState = initialState, action: ActionWithPayload): any {
  return state;
}
