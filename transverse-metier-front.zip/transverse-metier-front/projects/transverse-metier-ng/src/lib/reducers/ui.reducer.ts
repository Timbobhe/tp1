import * as ui from '../actions/ui.actions';
import { MessageModel } from '../models/message.model';
import { Action } from '@ngrx/store';
import { ActionWithPayload } from '../actions/_index';

export class BaseUiState {
  initializing = false;
  toastMessages: MessageModel[] = [];
}

const initialState = new BaseUiState();

export function acceptUiAction(action: Action) {
  return [ui.INIT_APP, ui.PUSH_TOAST_MESSAGE, ui.CLEAR_TOAST_MESSAGE].indexOf(action.type) >= 0;
}

export function baseUiReducer(state: BaseUiState = initialState, action: ActionWithPayload): any {
  if (action.type === ui.INIT_APP) {
    return Object.assign(new BaseUiState(), {...state, initializing: true});
  }

  if (action.type === ui.PUSH_TOAST_MESSAGE) {
    return Object.assign(new BaseUiState(), {...state, toastMessages: [...state.toastMessages, ...action.payload]});
  }

  if (action.type === ui.CLEAR_TOAST_MESSAGE) {
    return Object.assign(new BaseUiState(), {...state, toastMessages: []});
  }

  return state;
}
