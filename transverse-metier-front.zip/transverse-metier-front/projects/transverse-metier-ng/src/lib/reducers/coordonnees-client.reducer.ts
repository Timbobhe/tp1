import { ActionTester } from '@ag2rlamondiale/redux-api-ng';
import { CoordonneesClient } from '../models/client/coordonnees-client.model';
import * as CoordonneesActions from '../actions/coordonnees-client.actions';

export class CoordonneesClientState {
  coordonnees: CoordonneesClient;
  isFetched = false;
  updated = false;
  updateEncours = false;
}

const initialState = new CoordonneesClientState();


export function coordonneesClientReducer(
  state: CoordonneesClientState = initialState, action: CoordonneesActions.CoordonneesClientActions) {

  const tester = new ActionTester(action);

  if (tester.isSuccess(CoordonneesActions.GET_COORDONNEES_CLIENT)) {
    return Object.assign(new CoordonneesClientState(), {coordonnees: action.payload.data, isFetched: true});
  }

  if (tester.isSuccess(CoordonneesActions.CLEARCACHE_COORDONNEES_CLIENT)) {
    return new CoordonneesClientState();
  }

  if (tester.isStart(CoordonneesActions.UPDATE_COORDONNEES_CLIENT)) {
    return Object.assign(new CoordonneesClientState(), {...state, updateEncours: true});
  }

  if (tester.isEnd(CoordonneesActions.UPDATE_COORDONNEES_CLIENT)) {
    return Object.assign(new CoordonneesClientState(), {...state, updateEncours: false});
  }

  if (tester.isSuccess(CoordonneesActions.UPDATE_COORDONNEES_CLIENT)) {
    const updated = action.payload.data.result;
    const res = Object.assign(new CoordonneesClientState(), {...state, updated});

    const coordonnees = (action.payload.inputParams as CoordonneesClient);
    if (updated) {
      // Si le BACK a accepté les nouvelles coordonnées alors on met à jour les coordonnées du Front
      Object.assign(res, {coordonnees});
    }

    return res;
  }


  return state;
}
