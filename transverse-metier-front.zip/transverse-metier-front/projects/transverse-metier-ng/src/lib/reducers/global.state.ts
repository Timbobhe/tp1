import { navigationReducer, NavigationState } from './navigation.reducer';
import { routerReducer, RouterReducerState } from '@ngrx/router-store';
import { ActionReducerMap } from '@ngrx/store';
import { trackingReducer, TrackingState } from './tracking.reducer';
import { baseUiReducer, BaseUiState } from './ui.reducer';
import { baseClientInfosReducer, BaseClientInfoState } from './client-infos.reducer';
import { coordonneesClientReducer, CoordonneesClientState } from './coordonnees-client.reducer';
import { identNumMatchAccountReducer, IdentNumMatchAccountState } from './ident-num-match-account.reducer';
import { identitenumReducer, IdentiteNumState } from './identite-numerique.reducer';
import { DemandeSigElecState, sigElecReducer } from './sig-elec.reducer';
import { coordonneesBancairesReducer, CoordonneesBancairesState } from './coordonnees-bancaires.reducer';

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente le State global.
 */
export interface GlobalState {
  router: RouterReducerState;
  navigation: NavigationState;
  tracking: TrackingState;
  ui: BaseUiState;
  clientInfos: BaseClientInfoState;
  coordonneesClient: CoordonneesClientState;
  identNumMatchAccount: IdentNumMatchAccountState;
  identiteNum: IdentiteNumState;
  sigElec: DemandeSigElecState;
  coordonneesBancaires: CoordonneesBancairesState;
}

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente l ensemble des reducers.
 */
export const reducers: ActionReducerMap<GlobalState> = {
  router: routerReducer,
  navigation: navigationReducer,
  tracking: trackingReducer,
  ui: baseUiReducer,
  clientInfos: baseClientInfosReducer,
  coordonneesClient: coordonneesClientReducer,
  identNumMatchAccount: identNumMatchAccountReducer,
  identiteNum: identitenumReducer,
  sigElec: sigElecReducer,
  coordonneesBancaires: coordonneesBancairesReducer,
};

