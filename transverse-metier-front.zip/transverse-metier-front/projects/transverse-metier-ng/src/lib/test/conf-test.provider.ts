import { BackendService, ConfigService, EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { config } from './assets/config';
import { envSpecificConfig } from './assets/env-specific';

window['__app_env'] = {config: envSpecificConfig};
window['__env'] = {config};

const envSpecific = new EnvSpecificService();
// envSpecific.config = envSpecificConfig;

export const envSpecificProvider = {provide: EnvSpecificService, useValue: envSpecific};

const configService = new ConfigService(envSpecific);
configService.config = new Proxy<any>(config, {
  get(target: any, p: PropertyKey, receiver: any): any {
    // console.log('proxy config ', p);
    return target[p] || 'dummy';
  }
});

export const configServiceProvider = {provide: ConfigService, useValue: configService};

const backendService = new BackendService(configService);
export const backendServiceProvider = {provide: BackendService, useValue: backendService};

