## 10.1.3 (20/08/21)
**Implemented New Features and Enhancements:**
- Merge release/1.0.x

## 10.1.2 (20/08/21)
**Implemented New Features and Enhancements:**
- ([STYLE]) Renommer les composants ui-* to p-*
- ([SEMANTIC]) le composant p-dialog utilise p-header et p-footer (doit etre changé si passage à primeng 11)
```
<p-dialog>
  <ng-template pTemplate="header">
    <ng-content select="[title]"></ng-content>
  </ng-template>

  <ng-template>content here!</ng-template>

  <ng-template pTemplate="footer">
    <ng-content select="[title]"></ng-content>
  </ng-template>
</p-dialog>
```

## 10.1.1 (19/08/21)
**Breaking changes:**
- Migration de la version Angular de 7 à 10
- Migration de la version Primeng de 7 à 10

