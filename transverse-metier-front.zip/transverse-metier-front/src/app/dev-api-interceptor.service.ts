import { Injectable } from '@angular/core';
import { ApiAction, ApiCallerService, trace } from '@ag2rlamondiale/redux-api-ng';
import { of } from 'rxjs';
import { delay, switchMap, tap } from 'rxjs/operators';
import { ARBITRAGE_GET_QUESTION_OR_NEXT } from '@app/actions/arbitrage.action';
import { VERSEMENT_GET_QUESTION_OR_NEXT } from '@app/actions/versement.action';
import { RECHERCHER_PAIEMENT_CONSOLE } from '@app/modules/paiement-digital/action/paiement.actions';
import { GET_IDENT_NUM_MATCH_ACCOUNT } from '@ag2rlamondiale/transverse-metier-ng';

@Injectable({
  providedIn: 'root'
})
export class DevApiInterceptorService {

  constructor(private readonly apiCallService: ApiCallerService) {
  }

  prepare() {
    // this.apiCallService.registerGlobalInterceptor((action, apiCaller) => {
    //   if (action.type.startsWith('JAHIA')) {
    //     return apiCaller.basicRequest(action);
    //   }
    //   return apiCaller.basicRequest(action).pipe(delay(5000));
    // });
    trace('Preparation interceptor API');
    // this.apiCallService.registerGlobalInterceptor((action, apiCaller) => {
    //   if (action.type.startsWith('JAHIA')) {
    //     return apiCaller.basicRequest(action);
    //   }
    //   return apiCaller.basicRequest(action).pipe(delay(5000));
    // });



    // let counter = 0;
    // this.apiCallService.registerInterceptor(GET_IDENT_NUM_MATCH_ACCOUNT, (action, apiCaller) => {
    //   if (counter++ > 1) {
    //     return this.boom(apiCaller, action);
    //   } else {
    //     return apiCaller.basicRequest(action);
    //   }
    // });

    // this.apiCallService.registerInterceptor(CLAUSE_BENEFICIAIRE_START, (action, apiCaller) => {
    //   return this.boom(apiCaller, action);
    // });
    // this.apiCallService.registerInterceptor(QAD_LOAD, (action, apiCaller) => {
    //   return this.boom(apiCaller, action);
    // });
    // this.apiCallService.registerInterceptor(GET_OBJECTIFS_PAR_UTILISATEUR, (action, apiCaller) => {
    //   return this.boom(apiCaller, action);
    // });
    // this.apiCallService.registerInterceptor(ARBITRAGE_GET_QUESTION_OR_NEXT, (action, apiCaller) => {
    //   return this.boom(apiCaller, action);
    // });
    // this.apiCallService.registerInterceptor(VERSEMENT_GET_QUESTION_OR_NEXT, (action, apiCaller) => {
    //   return this.boom(apiCaller, action);
    // });
    // let counter = 0;
    // this.apiCallService.registerInterceptor(RECHERCHER_PAIEMENT_CONSOLE, (action, apiCaller) => {
    //   if (counter++ >= 2) {
    //     return this.boom(apiCaller, action);
    //   } else {
    //     return apiCaller.basicRequest(action);
    //   }
    // });
  }

  private boom(apiCaller: ApiCallerService, action: ApiAction<any>, time = 5000, message = `action ${action.payload.label} error fake`) {
    return of(1).pipe(
      delay(time),
      tap(e => {
        throw new Error(message);
      }),
      switchMap(e => apiCaller.basicRequest(action))
    );
  }
}
