import { BackendService as BackEndProvider, LoginService, MetisUser } from '@ag2rlamondiale/metis-ng';
import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { selectUi } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { TagCommanderService } from '@ag2rlamondiale/transverse-metier-ng';
import * as UrlUtils from '@ag2rlamondiale/transverse-metier-ng';
import { Store } from '@ngrx/store';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { InitApp } from '@ag2rlamondiale/transverse-metier-ng';


@Injectable()
export class AuthLoginCas implements CanActivate {

  private readonly loginUrl: string;
  private readonly loginPartenaireUrl: string;

  constructor(
    private readonly backendProvider: BackEndProvider,
    private readonly store: Store<GlobalState>,
    private readonly loginService: LoginService,
    private readonly tagCommanderService: TagCommanderService) {
    this.loginUrl = this.backendProvider.getEndpointUrl('loginUrl');
    this.loginPartenaireUrl = this.backendProvider.getEndpointUrl('loginPartenaireUrl');
  }

  canActivate(): boolean {
    trace('AuthLoginCasGuard#start');
    this.loginService.checkSecurityTokenValidity().subscribe(null, null, () => {
      const partenaireIdFromUrl: string = UrlUtils.getSearchParam('fdi');
      if (MetisUser.getInstance().authenticated) {
        this.store.select(selectUi).subscribe(ui => {
          if (!ui.initializing) {
            this.tagCommanderService.initTcContainer();
            this.store.dispatch(new InitApp());
          }
        });
      } else {
        this.redirectToAuthentication(partenaireIdFromUrl);
      }
    });
    trace('AuthLoginCasGuard#end', true);
    return true;
  }

  private redirectToAuthentication(partenaireIdFromUrl: string) {
    let redirection: string;
    if (partenaireIdFromUrl) {
      redirection = `${this.loginPartenaireUrl}?id=${partenaireIdFromUrl}`;
    } else {
      redirection = `${this.loginUrl}?service=${encodeURI(window.location.href)}`;
    }

    window.location.replace(redirection);
  }
}
