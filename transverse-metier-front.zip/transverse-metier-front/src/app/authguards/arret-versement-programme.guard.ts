import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/actions/accessibilite.actions';
import { ARRET_VERSEMENT, VERSEMENT } from '@app/consts/fonctionnalites.const';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subject, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArretVersementProgrammeGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
              private readonly router: Router) {
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    trace('ModificationVersementProgramme#start');
    const canActivate = new Subject<boolean>();
    const getAccessibilite = new GetAccessibilite(ARRET_VERSEMENT);
    const destination = state.url;
    let paramsMap = [];
    const params = destination.split('?');
    if (params && params.length > 1) {
      paramsMap = params[1].split('&');
    }
    for (let i = 0; i < paramsMap.length; i++) {
      const key = paramsMap[i].split('=')[0];
      const value = paramsMap[i].split('=')[1];
      if (!getAccessibilite.payload.url.includes('contrat') && key === 'onglet' && value) {
        getAccessibilite.addQueryParam('contrat', value);
      }
      if (!getAccessibilite.payload.url.includes('compartiment') && key === 'compartiment' && value) {
        getAccessibilite.addQueryParam('compartiment', value);
      }
    }

    getAccessibilite.payload.onSuccess = (data => {
      if (data.accessible || this.isRetourSigElec(state)) {
        canActivate.next(true);
        canActivate.complete();
      } else {
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible',
          {functionality: ARRET_VERSEMENT}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });

    this.store.dispatch(getAccessibilite);
    return canActivate.pipe(tap(r => trace('ModificationVersementProgramme#stop', r)));
  }

  isRetourSigElec(state: RouterStateSnapshot) {
    return state.url.endsWith('/signature/echouee') || state.url.endsWith('/signature/annulee') || state.url.endsWith(
      '/signature/terminee');
  }
}
