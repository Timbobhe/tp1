import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { CguDetails } from './../models/client/cgu-details.model';


export const GET_CGU = '[CGU]_GET';
export const CGU_CREATE = '[CGU]_CREATE';

export class GetCguDetails extends ApiAction<CguDetails> {

  constructor() {
    super(GET_CGU, 'backend/cguDetails', null);
  }
}

export class CreateAcceptationCgu extends ApiAction<CguDetails> {

  constructor() {
    super(CGU_CREATE, 'backend/cguAcceptation', null);
    this.payload.url = `/create`;
    this.payload.method = 'POST';
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetCguDetails | CreateAcceptationCgu | ApiActions;
