import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { OperationType } from '@app/models/client/operation.model';
import {
  CANCEL_DEM_SIGELEC,
  CancelSigElecDem as LibCancelSigElecDem,
  GET_DEM_SIGELEC,
  UrlUtils
} from '@ag2rlamondiale/transverse-metier-ng';
import { GetContrat } from './common.actions';

export { GET_DEM_SIGELEC, CANCEL_DEM_SIGELEC };

export class CancelSigElecDem extends LibCancelSigElecDem<OperationType> {
}

export class DemandeSigElec {
  idDemande: number;
  idExt: string;
  operationType: OperationType;
  idContrats: string[];
  dateCreation: Date;
  idTransaction: string;
  urlPageSignature: string;
}

export class GetSigElecDemEnCours extends GetContrat<DemandeSigElec> {
  constructor(param: OperationType) {
    super(GET_DEM_SIGELEC, 'backend/sigElec', null);
    this.addQueryParam('operation', param);
    const typeParam = UrlUtils.getHashParam('type');
    if (param === 'ARBI' && typeParam) {
      this.addQueryParam('type', typeParam);
    }
  }
}

export class PostSigelecTerminate extends ApiAction<any> {
  constructor(label: string, endpoint: string, param: any) {
    super(label, endpoint, param);
    this.payload.url = `/terminate?frame=${!!UrlUtils.getSearchParam('frame')}`;
    this.payload.method = 'POST';
  }
}

export type Actions = GetSigElecDemEnCours | CancelSigElecDem;
