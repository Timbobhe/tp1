import { Action } from '@ngrx/store';

export const PUSH_INDEX_SUJET = '[OBJECTIF]_PUSH_INDEX_SUJET';
export const PUSH_OBJECTIF_SUJETS = '[OBJECTIF]_PUSH_OBJECTIF_SUJETS';
export const CLEAR_OBJECTIF_SUJETS = '[OBJECTIF]_CLEAR_OBJECTIF_SUJETS';
export const CLEAR_OBJECTIFS = '[OBJECTIF]_CLEAR_OBJECTIFS';

export class PushIndexSujet implements Action {
  type = PUSH_INDEX_SUJET;
  constructor(public payload: number) { }
}

export class PushSelectedSubjectObjectif implements Action {
  type = PUSH_OBJECTIF_SUJETS;
  constructor(public payload: number[]) { }
}

export class ClearSubjectObjectif implements Action {
  type = CLEAR_OBJECTIF_SUJETS;
  constructor(public payload: number[]) { }
}

export type Actions = PushIndexSujet | PushSelectedSubjectObjectif | ClearSubjectObjectif;
