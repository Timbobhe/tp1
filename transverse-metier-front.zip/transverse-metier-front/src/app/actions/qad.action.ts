import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { CompartimentId, ContratId } from '@app/models/client/contrat.model';
import { ChoixQadMdp, QadProposition, QadQuestionsReponses, QadResultModel } from '@app/models/client/qad.model';
import { Action } from '@ngrx/store';

export const QAD_LOAD = '[QAD]_QAD_LOAD';
export const GET_QAD_PROPOSITION = '[QAD]_PROPOSITION_GET';
export const OPEN_QAD = '[QAD]_OPEN_QAD';
export const SAVE_HTML_CONTENT_QAD = '[QAD]_SAVE_HTML_CONTENT_QAD';
export const SET_CHOIX_QAD_MDP = '[QAD]_SET_CHOIX_QAD_MDP';
export const SET_SUPPORTS_RECOMMANDES = '[QAD]_SET_SUPPORTS_RECOMMANDES';

export type TypeQad = 'ARBITRAGE_ERE'
  | 'ARBITRAGE_MDP'
  | 'COMPLETER_BIA_ERE'
  | 'VERSEMENT_ERE';

export class QadPayload {
  contrat: ContratId;
  compartimentId?: CompartimentId;
  type: TypeQad;
  fonctionnaliteType: FonctionnaliteType;
  codeDocument: string;
  codesSupportsContrat: string[];
}

export class OpenQad implements Action {
  type = OPEN_QAD;

  constructor(public payload: QadPayload) {
  }
}

export class SaveHtmlContentQad implements Action {
  type = SAVE_HTML_CONTENT_QAD;

  constructor(public payload: string) {
  }
}

export class LoadQadQuestionnairePayload {
  contrat: ContratId;
  type: TypeQad;
}

export class LoadQadQuestionnaire extends ApiAction<QadQuestionsReponses[]> {
  constructor(body: LoadQadQuestionnairePayload) {
    super(QAD_LOAD, 'backend/qad', body);
    this.payload.url = `/qad-questions`;
    this.payload.method = 'POST';
    this.payload.requestData = body;
  }
}

export class QadResultPayload {
  contrat: ContratId;
  qadResult: QadResultModel[];
  fonctionnaliteType: FonctionnaliteType;
  codesSupportsContrat: string[];
}

export class GetQadPropositionProfil extends ApiAction<QadProposition[]> {
  constructor(body: QadResultPayload) {
    super(GET_QAD_PROPOSITION, 'backend/qad', body);
    this.payload.url = `/profil-proposition`;
    this.payload.method = 'POST';
    this.payload.requestData = body;
  }
}

export class SetChoixQadMdp implements Action {
  type = SET_CHOIX_QAD_MDP;

  constructor(public payload: ChoixQadMdp) {
  }
}

export class SetSupportsRecommandes implements Action {
  type = SET_SUPPORTS_RECOMMANDES;

  constructor(public payload: string[]) {
  }
}

export type Actions = LoadQadQuestionnaire
  | GetQadPropositionProfil
  | OpenQad
  | SaveHtmlContentQad
  | SetChoixQadMdp
  | SetSupportsRecommandes;
