import { Actions as ApiActions, ApiAction, ApiActionPayload, LEVEL_SEVERITY_MINOR } from '@ag2rlamondiale/redux-api-ng';

export const AQEA_INIT_CACHE = '[AQEA]_INIT_CACHE';
export class AqeaCache extends ApiAction<any> {

  // 'endpoint' ou 'backend/endpoint_interne'
  constructor() {
    super(new ApiActionPayload<any>(), AQEA_INIT_CACHE, 'aqea_init_cache_endpoint', null);
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = AqeaCache | ApiActions;
