import { Action } from '@ngrx/store';
import { TrackingActionPayload } from './tracking.action';

export const PUSH_SELECTED_AGE = '[SIMULATEUR_SYNTHESE]_PUSH_SELECTED_AGE';

export class PushSelectedAgePayload extends TrackingActionPayload {
  ageSelected: number;
  montant: number;
}

export class PushSelectedAge implements Action {
  type = PUSH_SELECTED_AGE;

  constructor(public payload: PushSelectedAgePayload) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = PushSelectedAge;
