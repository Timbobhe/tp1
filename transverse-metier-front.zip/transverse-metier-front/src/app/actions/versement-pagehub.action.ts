import { ApiAction, LEVEL_SEVERITY_MINOR } from '@ag2rlamondiale/redux-api-ng';
import { ContratId } from '@ag2rlamondiale/transverse-metier-ng';
import { DocumentDto } from '@app/models/client/documents.model';
import { DetailsOperationVersementDto, DetailsVersementProgramme, Echeancier, OperationVersement, VersementPageHubDonut, VersementResume } from '@app/models/client/versement-pagehub.model';
import {Contrat} from '@app/models/client/contrat.model';

export const VERSEMENT_PAGEHUB_LOAD = '[VERSEMENT]_PAGEHUB_LOAD';
export const VERSEMENT_PAGEHUB_GET_VERSEMENT_DETAILS = '[VERSEMENT]_GET_ECHEANCE_DETAILS';
export const GET_VERSEMENTS_PROGRAMMES = '[VERSEMENT]_GET_VERSEMENTS_PROGRAMMES';
export const GET_HISTORIQUE_OPERATIONS = '[VERSEMENT]_GET_HISTORIQUE_OPERATIONS';
export const VERSEMENT_PAGEHUB_GET_SYNTHESE_DONUT = '[VERSEMENT]_PAGEHUB_GET_SYNTHESE_DONUT';
export const VERSEMENT_PAGEHUB_GET_OPERATION_DETAILS = '[VERSEMENT]_GET_OPERATION_DETAILS';
export const GET_DOCUMENTS_VERSEMENT = '[VERSEMENT]_GET_DOCUMENTS_VERSEMENT';
export const GET_CONTRATS_PAGEHUB = '[VERSEMENT]_PAGEHUB_GET_CONTRATS';

export class LoadVersementPageHub extends ApiAction<VersementResume> {
  constructor() {
    super(VERSEMENT_PAGEHUB_LOAD, 'backend/versementPagehub', null);
    this.payload.url = `/start`;
    this.payload.method = 'GET';
  }
}

export class GetVersementsProgrammes extends ApiAction<Echeancier[]> {
  constructor() {
    super(GET_VERSEMENTS_PROGRAMMES, 'backend/versementPagehub', null);
    this.payload.url = `/versements-programmes`;
    this.payload.method = 'GET';
  }
}

export class GetVersementProgrammePayload {
  contratId: ContratId;
  codeDocument: string;
}
export class GetVersementProgrammeDetails extends ApiAction<DetailsVersementProgramme> {
  constructor(body: GetVersementProgrammePayload) {
    super(VERSEMENT_PAGEHUB_GET_VERSEMENT_DETAILS, 'backend/versementPagehub', body);
    this.payload.url = `/versement-details`;
    this.payload.method = 'POST';
    this.payload.requestData  = body;
  }
}

export class GetHistoriqueOperations extends ApiAction<OperationVersement[]> {
  constructor() {
    super(GET_HISTORIQUE_OPERATIONS, 'backend/versementPagehub', null);
    this.payload.url = `/versements-historique`;
    this.payload.method = 'GET';
  }
}
export class GetVersementsSyntheseDonut extends ApiAction<VersementPageHubDonut> {
  constructor() {
    super(VERSEMENT_PAGEHUB_GET_SYNTHESE_DONUT, 'backend/versementPagehub', null);
    this.payload.url = `/donut`;
    this.payload.method = 'GET';
  }
}

export class GetOperationsVersement extends ApiAction<DetailsOperationVersementDto> {

  constructor(idOperation: string, typeSilo: string) {
    super(VERSEMENT_PAGEHUB_GET_OPERATION_DETAILS, 'backend/versementPagehub', idOperation, typeSilo);
    this.payload.url = `/versement-details-operation/${idOperation}/${typeSilo}`;
  }
}

export class GetDocumentsVersement extends ApiAction<DocumentDto> {
  constructor() {
    super(GET_DOCUMENTS_VERSEMENT, 'backend/versementPagehub', null);
    this.payload.url = '/documents-versement';
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

export class GetContratsPageHub extends ApiAction<Contrat[]> {
  constructor() {
    super(GET_CONTRATS_PAGEHUB, 'backend/versementPagehub', null);
    this.payload.url = `contrats`;
    this.payload.method = 'GET';
  }
}

export type Actions =
  | LoadVersementPageHub
  | GetVersementProgrammeDetails
  | GetVersementsProgrammes
  | GetHistoriqueOperations
  | GetVersementsSyntheseDonut
  | GetOperationsVersement
  | GetDocumentsVersement
  | GetContratsPageHub;
