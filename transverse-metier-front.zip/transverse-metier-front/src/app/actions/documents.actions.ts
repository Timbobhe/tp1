import { Actions as ApiActions, ApiAction, LEVEL_SEVERITY_MINOR } from '@ag2rlamondiale/redux-api-ng';
import { ContratId, toQueryParamsContratId } from '@app/models/client/contrat.model';
import { Fiche, Fiches } from '@app/models/client/documents.model';
import { DownloadDocument } from '@app/models/client/download-document.model';

export const GET_DOCUMENT = '[DOCUMENT]_GET';
export const GET_DOCUMENTS_NIF = '[DOCUMENT]_GET_DOCUMENTS_NIF';
export const DOWNLOAD_DOCUMENT = '[DOCUMENT]_DOWNLOAD';

export class GetDocument extends ApiAction<Fiche, DocumentPayload> {
  constructor(param: DocumentPayload) {
    super(GET_DOCUMENT, 'backend/documents', param);
    this.payload.url = `/${param.codeDocument}?${toQueryParamsContratId(param.contratId)}`;
  }
}

export class GetDocumentsNIF extends ApiAction<{ fiches: Fiches }, { contratId: ContratId }> {
  constructor(param: { contratId: ContratId }) {
    super(GET_DOCUMENTS_NIF, 'backend/documentsNIF', param);
    this.payload.url = `?${toQueryParamsContratId(param.contratId)}`;
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

export class DownloadDocumentAction extends ApiAction<any, DownloadDocument> {
  constructor(param: DownloadDocument, severity: number = null) {
    super(DOWNLOAD_DOCUMENT, 'backend/documentsDownload', param);
    this.payload.method = 'POST';
    this.payload.requestData = param;
    this.payload.responseType = 'blob';
    if (severity !== null) {
      this.payload.severity = severity;
    }
  }
}

export class DocumentPayload {
  contratId: ContratId;
  codeDocument: string;
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetDocument | GetDocumentsNIF | DownloadDocumentAction | ApiActions;
