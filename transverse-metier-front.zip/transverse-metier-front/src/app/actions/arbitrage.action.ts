import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { ArbitrageModel, ArbitrageTerminateModel, ChoixDesinvestissementPayload, ChoixRepartitionSupportPayload, ChoixReponsePayload, ConsentementsMdp, EtapeArbitrage, InfoArbitrageContrat, ListQuestionResponses, RequestQuestionArbitrage } from '@app/models/client/arbitrage.model';
import { QuestionType } from '@app/models/question-responses.model';
import { Subtitle } from '@app/models/ui.model';
import * as UrlUtils from '@ag2rlamondiale/transverse-metier-ng';
import { Action } from '@ngrx/store';
import { GetContrat } from './common.actions';
import { PostSigelecTerminate } from './sig-elec.action';

export const ARBITRAGE_START = '[ARBITRAGE]_START';
export const ARBITRAGE_GET_QUESTION_OR_NEXT = '[ARBITRAGE]_GET_QUESTION_OR_NEXT';
export const PUSH_CONTRAT_SELECTED = '[ARBITRAGE]_PUSH_CONTRAT';
export const SET_SUBTITLE_ARBITRAGE = '[ARBITRAGE]_SET_SUBTITLE';
export const ARBITRAGE_TERMINATE = '[ARBITRAGE]_TERMINATE';
export const SET_PARCOURS_MANUSCRIT_ARBITRAGE = '[ARBITRAGE]_SET_PARCOURS_MANUSCRIT';
export const ARBITRAGE_PUSH_REPONSE = '[ARBITRAGE]_PUSH_REPONSE';
export const ARBITRAGE_PUSH_CHOIX_DESINVESTISSEMENT = '[ARBITRAGE]_PUSH_CHOIX_DESINVESTISSEMENT';
export const ARBITRAGE_PUSH_CHOIX_REPARTITION_SUPPORT = '[ARBITRAGE]_PUSH_CHOIX_REPARTITION_SUPPORT';
export const ARBITRAGE_MODIFIER_REPONSE = '[ARBITRAGE]_MODIFIER_REPONSE';
export const ARBITRAGE_GOTO_ETAPE = '[ARBITRAGE]_GOTO_ETAPE';
export const ARBITRAGE_SET_ARBITRAGES_CLIENT = '[ARBITRAGE]_SET_ARBITRAGES_CLIENT';
export const ARBITRAGE_SET_CONSENTEMENT_ACCEPT = '[ARBITRAGE]_SET_CONSENTEMENT_ACCEPT';


export class GetArbitrageStart extends GetContrat<ArbitrageModel> {
  constructor() {
    super(ARBITRAGE_START, 'backend/arbitrage', '/start');
    const typeParam = UrlUtils.getHashParam('type');
    if (typeParam) {
      this.addQueryParam('paramFluxStock', typeParam);
    }
  }
}

export class GetArbitrageQuestionOrNext extends ApiAction<ListQuestionResponses> {
  constructor(request: RequestQuestionArbitrage) {
    super(ARBITRAGE_GET_QUESTION_OR_NEXT, 'backend/arbitrage', request);
    const typeParam = UrlUtils.getHashParam('type');
    if (typeParam === 'flux' || typeParam === 'stock') {
      request.contexte.paramFluxStock = typeParam;
    }

    this.payload.url = '/question-or-next';
    this.payload.method = 'POST';
    this.payload.requestData = request;
  }
}

export class PushContratSelected implements Action {
  type = PUSH_CONTRAT_SELECTED;

  constructor(public payload: { info: InfoArbitrageContrat, setSubtitle: boolean }) {
  }
}

export class GoToEtapeArbitragePayload {
  etape: EtapeArbitrage;
}

export class GoToEtapeArbitrage implements Action {
  type = ARBITRAGE_GOTO_ETAPE;

  constructor(public payload: GoToEtapeArbitragePayload) {
  }
}

export class PushReponse implements Action {
  type = ARBITRAGE_PUSH_REPONSE;

  constructor(public payload: ChoixReponsePayload) {
  }
}

export class PushChoixDesinvestissement implements Action {
  type = ARBITRAGE_PUSH_CHOIX_DESINVESTISSEMENT;

  constructor(public payload: ChoixDesinvestissementPayload) {
  }
}

export class PushChoixRepartitionSupport implements Action {
  type = ARBITRAGE_PUSH_CHOIX_REPARTITION_SUPPORT;

  constructor(public payload: ChoixRepartitionSupportPayload) {
  }
}

export class ModifierReponse implements Action {
  type = ARBITRAGE_MODIFIER_REPONSE;

  constructor(public payload: { questionType: QuestionType, etape: EtapeArbitrage, deplacement: 'next' | 'prev' }) {
  }
}

export class SetSubtitleArbitrage implements Action {
  type = SET_SUBTITLE_ARBITRAGE;

  constructor(public payload: Subtitle) {
  }
}

export class PostArbitrageTerminate extends PostSigelecTerminate {
  constructor(param: ArbitrageTerminateModel) {
    super(ARBITRAGE_TERMINATE, 'backend/arbitrage', param);
    this.payload.data = param;
  }
}

export class SetParcoursManuscritArbitrage implements Action {
  type = SET_PARCOURS_MANUSCRIT_ARBITRAGE;

  constructor(public payload: boolean) {
  }
}

export class SetArbitragesClient implements Action {
  type = ARBITRAGE_SET_ARBITRAGES_CLIENT;

  constructor(public payload: ArbitrageClient[]) {
  }
}

export type SetConsentementAcceptPayload = {
  [id in keyof Partial<ConsentementsMdp>]: boolean;
}

export class SetConsentementAccept implements Action {
  type = ARBITRAGE_SET_CONSENTEMENT_ACCEPT;

  constructor(public payload: SetConsentementAcceptPayload) {
  }
}

export type Actions = GetArbitrageStart
  | GoToEtapeArbitrage
  | GetArbitrageQuestionOrNext
  | PushReponse
  | PushChoixDesinvestissement
  | PushChoixRepartitionSupport
  | ModifierReponse
  | PushContratSelected
  | SetSubtitleArbitrage
  | PostArbitrageTerminate
  | SetParcoursManuscritArbitrage
  | SetArbitragesClient
  | SetConsentementAccept;

