import { ClauseBeneficiaireModel, ClauseBeneficiaireTerminateModel } from '@app/models/client/clause-beneficiaire.model';
import { Contrat } from '@app/models/client/contrat.model';
import { ModificationClauseBeneficiaireModel } from '@app/models/client/modification-clause-beneficiaire.model';
import { Subtitle } from '@app/models/ui.model';
import { Action } from '@ngrx/store';
import { GetContrat } from './common.actions';
import { PostSigelecTerminate } from './sig-elec.action';

export const CLAUSE_BENEFICIAIRE_START = '[CLAUSE_BENEFICIAIRE]_START';
export const PUSH_CONTRAT_SELECTED = '[CLAUSE_BENEFICIAIRE]_PUSH_CONTRAT';
export const PUSH_CHOIX_CLAUSE = '[CLAUSE_BENEFICIAIRE]_PUSH_CHOIX_CLAUSE';
export const SET_SUBTITLE_CLAUSE_BENEFICIAIRE = '[CLAUSE_BENEFICIAIRE]_SET_SUBTITLE';
export const CLAUSE_BENEFICIAIRE_TERMINATE = '[CLAUSE_BENEFICIAIRE]_TERMINATE';
export const SET_PARCOURS_MANUSCRIT_CLAUSE_BENEFICIAIRE = '[CLAUSE_BENEFICIAIRE]_SET_PARCOURS_MANUSCRIT';

export class GetClauseBeneficiaireStart extends GetContrat<ModificationClauseBeneficiaireModel> {
  constructor() {
    super(CLAUSE_BENEFICIAIRE_START, 'backend/modificationclauseBeneficiaire', '/start');
  }
}

export class PushContratSelected implements Action {
  type = PUSH_CONTRAT_SELECTED;

  constructor(public payload: Contrat) {
  }
}

export class PushClauseSelected implements Action {
  type = PUSH_CHOIX_CLAUSE;

  constructor(public payload: ClauseBeneficiaireModel) {
  }
}

export class SetSubtitleModificationClauseBeneficiaire implements Action {
  type = SET_SUBTITLE_CLAUSE_BENEFICIAIRE;

  constructor(public payload: Subtitle) {
  }
}

export class PostClauseBeneficiaireTerminate extends PostSigelecTerminate {
  constructor(param: ClauseBeneficiaireTerminateModel) {
    super(CLAUSE_BENEFICIAIRE_TERMINATE, 'backend/modificationclauseBeneficiaire', param);
    this.payload.requestData = param;
  }
}

export class SetParcoursManuscritModificationClauseBeneficiaire implements Action {
  type = SET_PARCOURS_MANUSCRIT_CLAUSE_BENEFICIAIRE;

  constructor(public payload: boolean) {
  }
}

export type Actions =
  GetClauseBeneficiaireStart
  | PushContratSelected
  | PushClauseSelected
  | SetSubtitleModificationClauseBeneficiaire
  | PostClauseBeneficiaireTerminate
  | SetParcoursManuscritModificationClauseBeneficiaire;
