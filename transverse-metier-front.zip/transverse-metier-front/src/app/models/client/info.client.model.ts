import { CodeSiloType, InfosBlocagesClient, PartenaireInfo } from '@ag2rlamondiale/transverse-metier-ng';

export class InfoPersonne {
  idGdi: string;
  numeroPersonneEre: string;
  numeroPersonneMdpro: string;
  partenaire: PartenaireInfo;
  sousPartenaire: string;
  nom: string;
  nomNaissance: string;
  prenom: string;
  infosBlocagesClient: InfosBlocagesClient = new InfosBlocagesClient();

  impersonation: boolean;
  filialeACA: boolean;
  hasContratEre: boolean;
  silos: CodeSiloType[];
  dateDeNaissance: Date;
  civilite: string;
  compteDemo: boolean;

  fromObject(object: any) {
    Object.assign(this, object);
    if (object.infosBlocagesClient) {
      this.infosBlocagesClient = Object.assign(new InfosBlocagesClient(), object.infosBlocagesClient);
    }
    return this;
  }
}
