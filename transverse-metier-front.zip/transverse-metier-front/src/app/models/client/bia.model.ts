import { AffichageType, CodeSiloType, CompartimentType, MiniContrat } from '@app/models/client/contrat.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Document } from '@app/modules/ecrs-common/services/download.service';
import { ClauseBeneficiaireModel } from '@app/models/client/clause-beneficiaire.model';

export class BiaModel {
  contrats: ContratBia[];
  biaEnCours: boolean;
  biaContexte: BiaContexte;
}

export class BiaTerminateModel {
  contratSelected: ContratBia;
  clauseBeneficiaireSelected: ClauseBeneficiaireModel;
  gestionFinanciereSelected: RepartitionSupport[];
  resultatQAD: any;
  contenuBIA: Document;
  contenuQAD: Document;
}

export class ContratBia implements MiniContrat {
  nomContrat: string;
  college: string;
  identifiantAssure: string;
  description: string;
  raisonSociale: string;
  codeSilo: CodeSiloType | string;
  idAdherente: string;
  idContractante: string;
  compartimentType: CompartimentType = 'C3';
  descClauseBenef: string;
  affichageType: AffichageType;
}


export class BiaContexte {

}
