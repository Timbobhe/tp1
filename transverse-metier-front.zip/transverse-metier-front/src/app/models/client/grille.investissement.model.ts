export interface StructureInvestissement {
  id: string;
  nom: string;

  tauxRepartition: number;
  indicateurTauxDerogeable: boolean;
}


export class GrilleInvestissementModel implements StructureInvestissement {
  id: string;
  nom: string;
  tauxRepartition: number;
  indicateurTauxDerogeable: boolean;
  tauxRepartitionDefaut: number;
  defaut: boolean;
}

export class RepartitionSupport {
  id: string;
  nom: string;
  montant?: number;
  pourcentage: number;
  defaut?: boolean;
  recommande?: boolean;
  selectionned?: boolean;
}

export class InfosRepartitionSupport {
  repartitionSupport: RepartitionSupport;
  repartitionPartielle: number;
}

export class Support {
  id: string;
  nom: string;
  repartition: Repartition;
}

export class Repartition {
  montant: number;
  pourcentage: number;
}

export class InfosTrackingRepartition {
  avecChoixParDefaut: boolean;
  avecChoixRecommande: boolean;
  avecAutreChoix: boolean;

  toHuman() {
    const res = [];
    if (this.avecChoixParDefaut) {
      res.push('avecChoixSupportParDefaut');
    }
    if (this.avecChoixRecommande) {
      res.push('avecChoixSupportRecommande');
    }
    if (this.avecAutreChoix) {
      res.push('avecAutreChoixSupport');
    }
    return res.join(' | ');
  }
}
