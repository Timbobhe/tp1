import { BaseTrackingInfo } from '@ag2rlamondiale/transverse-metier-ng';

export class TrackingInfo extends BaseTrackingInfo {
  equipement_retraite_supp_details: EquipementRetraiteSupp[];
}

export class EquipementRetraiteSupp {
  type_de_contrat: string;
  assureur: string;
  appellation: string;
}
