import { Contrat } from '@app/models/client/contrat.model';
import { FileUploadModel } from '@ag2rlamondiale/transverse-metier-ng';

export class ContactReclamationTerminateModel {
  idContrat: string;
  idAssure: string;
  idPersonne: string;
  codeSilo: string;
  codeFiliale: string;
  codeQuestion: string;
  message: string;
  reclamation: boolean;
  email: string;
  telephone: string;
  raisonSociale: string;
  fichiersJoint: Array<FileUploadModel>;
}

export class ContactReclamationModel {
  contrats: Contrat[];
}

export interface ReclamationResponseModel {
  state: string;
  errorTag: string;
}

export interface Question {
  name: any;
  code: string;
}
