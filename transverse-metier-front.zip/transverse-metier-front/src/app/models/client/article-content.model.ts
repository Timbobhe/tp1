export class ArticleContentModel {
  titreContribPath?: string;
  videoContribPath?: string;
  hashtagsContribPath?: string;
  dateRedactionContribPath?: string;
  introductionContribPath?: string;
  image1ContribPath?: string;
  texte1ContribPath?: string;
  zoneGriseContribPath?: string;
  sousTitre1ContribPath?: string;
  exemple1ContribPath?: string;
  exemple2ContribPath?: string;
  texte2ContribPath?: string;
  texte3ContribPath?: string;
  titreLiensContribPath: string;
  service1ContribPath?: string;
  service2ContribPath?: string;
}

export function buildFromArticleName(name: string, repertoire: string): ArticleContentModel {
  return {
    titreContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=titre&typeUrlResource=absolute&removeComments`,
    videoContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=video&typeUrlResource=absolute&removeComments`,
    hashtagsContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=hashtags&typeUrlResource=absolute&removeComments`,
    dateRedactionContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=dateRedaction&typeUrlResource=absolute&removeComments`,
    introductionContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=introduction&typeUrlResource=absolute&removeComments`,
    image1ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=image1&typeUrlResource=absolute&removeComments`,
    texte1ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=texte1&typeUrlResource=absolute&removeComments`,
    zoneGriseContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=zoneGrise&typeUrlResource=absolute&removeComments`,
    sousTitre1ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=sousTitre1&typeUrlResource=absolute&removeComments`,
    exemple1ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=exemple1&typeUrlResource=absolute&removeComments`,
    exemple2ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=exemple2&typeUrlResource=absolute&removeComments`,
    texte2ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=texte2&typeUrlResource=absolute&removeComments`,
    texte3ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=texte3&typeUrlResource=absolute&removeComments`,
    titreLiensContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=titreLiens&typeUrlResource=absolute&removeComments`,
    service1ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=service1&typeUrlResource=absolute&removeComments`,
    service2ContribPath: `${repertoire}/${name}/body-content.apiV2.html.ajax?blockId=service2&typeUrlResource=absolute&removeComments`
  };
}
