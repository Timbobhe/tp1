import { Contrat } from '@app/models/client/contrat.model';

export class ModificationClauseBeneficiaireModel {
  contrats: Contrat[];
}
