import { CoordonneesBancaires } from '@ag2rlamondiale/transverse-metier-ng';
import { ContratParcours } from './contrat.model';
import { IdDocGedDto } from './download-document.model';

export class VersementResume {
  montantTotal: number;
  dateDernierVersement: Date;
  montantDernierVersement: number;
  dateProchainVersement: Date;
  montantProchainVersement: number;
}

export class Echeancier {
  echeancierId?: string;
  dateEffet?: Date;
  dateDebut?: Date;
  dateFin?: Date;
  prelevements: Prelevement[];
  montant: number;
  fractionnement: string;
  frequence: string;
  compartiment: ContratParcours;
  idAssure?: string;
  jourPrelevement?: number;
  dateProchaineEcheance?: Date;
  annee?: number;
}

export class Prelevement {
  prelevementId: number;
  datePrelevement: Date;
  codeSituationPrelevement: string;
  libelleSituationPrelevementSilo: string;
}

export class VersementPageHubDonut {
  montantTotalVersementDeductible: number;
  pourcentageVersementDeductible: number;
  montantTotalVersementNonDeductible: number;
  pourcentageVersementNonDeductible: number;
  montantTotalVersement: number;
  year: number;
}

export class DetailsVersementProgramme {
  coordonneesBancaires: CoordonneesBancaires;
  docGED: IdDocGedDto;
}

export class OperationVersement {
  operationId: string;
  typeOperation: string;
  montant: number;
  dateOperation: Date;
  contrat: ContratParcours;
  operationDerniers3Mois: boolean;
  deductible: boolean;
  enCoursTraitement: boolean;
}

export class OperationDetailInfoDto {
  label: string;
  montant: number;
}

export class DetailsOperationVersementDto {
  typeOperation: string;
  montantNetOperation: number;
  operationInvestissements: OperationDetailInfoDto[];
}
