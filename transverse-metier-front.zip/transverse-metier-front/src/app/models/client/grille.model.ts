export class GrilleInv {
  id: string;
  nom: string;
  tauxRepartition: number;

}
