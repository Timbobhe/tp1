import { Image } from '@app/models/header/image.model';
import { HeaderModel } from './header/header.model';
import { SyntheseImages } from './synthese.model';

export class JahiaModel {
  headerAg2r: HeaderModel;
  headerArialCNP: HeaderModel;

  headerPartenaireNie: HeaderModel;
  headerPartenaireAdding: HeaderModel;
  onboardingImage: Image;
  biaImage: Image;
  coordonneesBancairesImage: Image;
  versementImage: Image;
  contactImage: Image;
  arbitrageImage: Image;
  syntheseImages: SyntheseImages;
}
