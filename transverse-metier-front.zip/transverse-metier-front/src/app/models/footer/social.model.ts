import { CanalModel } from './canal.model';

export class SocialModel {
  title: string;
  canals: CanalModel [];
}
