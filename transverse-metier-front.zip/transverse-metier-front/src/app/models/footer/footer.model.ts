import {FooterColModel} from './footer-col.model';
import {LegalModel} from './legal.model';
import {SocialModel} from './social.model';

export class FooterModel {
  footerTitle: string;
  footerCols: FooterColModel [];
  footerLegal: LegalModel;
  footerSocial: SocialModel;

}
