import { ColModel } from './col.model';

export class LegalModel {
  cols: ColModel [];
  copyRight: string;
}
