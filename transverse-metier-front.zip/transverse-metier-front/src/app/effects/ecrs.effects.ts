import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { ApiEffects } from '@ag2rlamondiale/redux-api-ng';
import { ExecuteAction, INIT_APP } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { AqeaCache } from '@app/actions/aqea-cache.actions';
import { GetClientInfos } from '@app/actions/client-infos.actions';
import { GET_COMPARTIMENTS } from '@app/actions/compartiments.actions';
import { ContratsAssureFetch } from '@app/actions/contrats-assure.actions';
import { EVEN_CANCEL } from '@app/actions/evenement.actions';
import { LoadMenu, LOAD_MENU } from '@app/actions/menu.actions';
import { GetOnboardingStart } from '@app/actions/onboarding.action';
import { GetPersonnePhysiqueInfos } from '@app/actions/personne-physique-infos.action';
import { TrackingInfoFetch } from '@app/actions/tracking.action';
import { DynatraceService } from '@app/services/dynatrace.service';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { environment } from 'environments/environment';
import { debounceTime, switchMap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EcrsEffects {

  constructor(
    private readonly actions$: Actions,
    private readonly apiEffects: ApiEffects,
    private readonly jahia: JahiaService,
    private readonly config: ConfigService,
    private readonly dynatrace: DynatraceService) {
  }

  @Effect({dispatch: true})
  initApp$ = this.actions$.pipe(
    ofType(INIT_APP),
    switchMap(() => [
        environment.mock ? this.jahia.loadStateRemoteAction() : {type: 'NOOP'},
        new ExecuteAction(() => this.dynatrace.installScript()),
        new TrackingInfoFetch(),
        new GetClientInfos(),
        new GetPersonnePhysiqueInfos(),
        new ContratsAssureFetch(),
        new GetOnboardingStart(),
        new LoadMenu(),
        this.config.getConfig().tc_vars.env_work !== 'localhost' ? new AqeaCache() : {type: 'NOOP'}
      ])
  );

  @Effect({dispatch: true})
  loadMenu$ = this.actions$.pipe(
    ofType(LOAD_MENU),
    switchMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  fetchCompartiments$ = this.actions$.pipe(
    ofType(GET_COMPARTIMENTS),
    debounceTime(5000),
    switchMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  cancelEven$ = this.actions$.pipe(
    ofType(EVEN_CANCEL),
    switchMap(action => this.apiEffects.executeApi(action))
  );
}
