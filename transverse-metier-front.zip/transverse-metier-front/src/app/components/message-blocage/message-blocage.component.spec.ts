/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import * as fromFeature from '@app/reducers/message-blocage.reducer';
import { Store, StoreModule } from '@ngrx/store';
import { MessageModule } from 'primeng/message';
import { MessagesModule } from 'primeng/messages';
import { MessageBlocageComponent } from './message-blocage.component';

describe('MessageBlocageComponent', () => {
  let component: MessageBlocageComponent;
  let fixture: ComponentFixture<MessageBlocageComponent>;
  let store: Store<fromFeature.MessageBlocageState>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot({}), MessageModule, MessagesModule, NoopAnimationsModule],
      declarations: [MessageBlocageComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    store = TestBed.inject(Store);
    fixture = TestBed.createComponent(MessageBlocageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have messages blocages', () => {
    const message = {
      closable: true,
      data: null,
      detail: null,
      id: null,
      key: null,
      life: null,
      severity: null,
      sticky: null,
      summary: null,
    };

    component.msgs.push(message);
    const isMessageBlocageEmpty = component.isMessagesBlocagesEmpty();
    fixture.detectChanges();
    expect(isMessageBlocageEmpty).toBeFalsy();
  });

  it('should not have messages blocages', () => {
    const isMessageBlocageEmpty = component.isMessagesBlocagesEmpty();
    fixture.detectChanges();
    expect(isMessageBlocageEmpty).toBeTruthy();
  });
});
