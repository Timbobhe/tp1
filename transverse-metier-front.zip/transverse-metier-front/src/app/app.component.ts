import { ConfigService } from '@ag2rlamondiale/metis-ng';
import {
  ClearToastMessage,
  MessagesService,
  PartenaireInfo,
  selectUiToastMessage,
  ThemeService,
  ThemeType,
  UrlService,
  UrlUtils
} from '@ag2rlamondiale/transverse-metier-ng';
import { AfterContentChecked, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { getHeaderUserEre, getHeaderUserMdpro, getJahiaResponse } from '@app/consts/jahia_default_response';
import { EvenementService } from '@app/modules/ecrs-common/services/evenement.service';
import { selectAppInitialized, selectUi, selectUiError } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { environment } from 'environments/environment';
import { MessageService } from 'primeng/api';
import { InfoPersonne } from './models/client/info.client.model';
import { HeaderModel } from './models/header/header.model';
import { CompteDemoComponent } from './modules/compte-demo/compte-demo.component';
import { GlobalState } from './reducers/_index';
import { DevApiInterceptorService } from '@app/dev-api-interceptor.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy, AfterContentChecked {

  subscriptions = [];
  display = false;
  infoPersonne: InfoPersonne;
  headerData: HeaderModel;

  hasMajorError: boolean;
  routerActivate = false;
  themeSwitcherActive = false;
  Compte: CompteDemoComponent;
  hideMenu: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly configService: ConfigService,
    private readonly cd: ChangeDetectorRef,
    private readonly ecrsMessages: MessagesService,
    private readonly primeMessageService: MessageService,
    public readonly urlService: UrlService,
    private readonly themeService: ThemeService,
    private readonly evenService: EvenementService,
    private readonly devApiInterceptor: DevApiInterceptorService) {
  }

  ngOnInit() {
    this.themeSwitcherActive = this.configService.config['theme_switcher'];

    if (!environment.production) {
      this.devApiInterceptor.prepare();
    }

    this.subscriptions.push(
      selectAppInitialized(this.store).subscribe(selected => {
        this.infoPersonne = selected.infoClient;
        const isFilialeAcaFlag = this.infoPersonne.filialeACA;
        this.selectTheme(this.infoPersonne.partenaire, isFilialeAcaFlag);
        this.display = this.checkPartnerInUrl(this.infoPersonne.partenaire);
        const jahiaResponse = getJahiaResponse(this.configService);
        this.headerData = isFilialeAcaFlag ? jahiaResponse.headerArialCNP : jahiaResponse.headerAg2r;
        this.headerData.user = this.infoPersonne.hasContratEre
          ? getHeaderUserEre(isFilialeAcaFlag)
          : getHeaderUserMdpro();
      }),

      this.store.select(selectUiError).subscribe(e => {
        if (e && e.error) {
          // Ne pas afficher le Header pour les erreurs majeurs
          this.hasMajorError = e.severity === 0;
        } else {
          this.hasMajorError = false;
        }
      }),

      this.store.select(selectUiToastMessage).subscribe(messages => {
        if (messages && messages.length > 0) {
          this.ecrsMessages.addAll(messages, this.primeMessageService);
          this.clearToastMessage();
        }
      }),

      this.store.select(selectUi).subscribe(sub => {
        this.hideMenu = sub.hideMenu;
      })
    );
  }

  checkPartnerInUrl(partner: PartenaireInfo): boolean {
    const partenaireFromUrl: string = UrlUtils.getSearchParam('fdi');
    if (partner && partner.codePartenaire !== partenaireFromUrl) {
      UrlUtils.setSearchParam('fdi', partner.codePartenaire);
      return false;
    }
    if (!partner && partenaireFromUrl) {
      UrlUtils.deleteSearchParam('fdi');
      return false;
    }
    return true;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  selectTheme(partenaire: PartenaireInfo, isFilialeAcaFlag: boolean) {
    let theme: ThemeType;
    const codePartenaire = partenaire ? partenaire.codePartenaire : '';
    if (codePartenaire === '49504') {
      theme = 'adding';
    } else if (codePartenaire === '49505') {
      theme = 'nie';
    } else {
      theme = 'ag2r';
    }
    this.themeService.changeTheme(theme, isFilialeAcaFlag ? 'aca' : 'ag2r');
  }

  onRouterActivate() {
    this.routerActivate = true;
  }

  get mock() {
    return environment.mock;
  }

  ngAfterContentChecked(): void {
    this.cd.detectChanges();
  }

  clearToastMessage() {
    this.store.dispatch(new ClearToastMessage());
  }
}
