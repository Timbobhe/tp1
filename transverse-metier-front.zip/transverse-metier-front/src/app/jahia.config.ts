/**
 * Malgré les apparences les clés des PATH (contrib, dico, questionResponse, ressources) doivent être globalement unique.
 */
import { JahiaConfig } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

const PATHS = {
  common: {
    contribsPath: {
      'MA_DEMANDE_TITRE_ETAPES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=ma_demande_etapes_titre&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CONFIRMER_COORDONNEES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_confirmer_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_VALIDER_IDENTITE_NUM': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_valider_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MAJ_COORDONNEES_SIDE': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_update_coordonnees_side_component&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireCommon: '/sites/aqe/ecrs/shared/body-content/dictionnaireshared.apiDico.html.ajax',
      dictionnaireCommonAppMessagesDictionnaire: '/sites/aqe/ecrs/body-content/dictionnairecommonappmessages.apiDico.html.ajax',
    }
  },

  bia: {
    contribsPath: {
      'CONTENU_BIA_TITRE_ETAPES': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_titre_etapes&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_SAISIR_COORDONNEES': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_saisir_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_IDENT_NUM': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_creer_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_SIDE_COMPONENT': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_side_component&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CLAUSE_BENEFICIAIRE_STANDARD': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_clause_beneficiaire_standard&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CLAUSE_BENEFICIAIRE_SPECIFIQUE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_clause_beneficiaire_specifique&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CLAUSE_BENEFICIAIRE_HERITAGE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_clause_beneficiaire_heritage&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICAIRE_ACCORDION_OPEN_TITLE_BIA': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=designationBeneficiaireAccordionTitleOpen&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICAIRE_ACCORDION_CLOSE_TITLE_BIA': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=designationBeneficiaireAccordionTitleClose&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_DESIGNATION_BENEFICIAIRE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_designation_beneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_GESTION_FINANCIERE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_gestion_financiere&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RECAPITULATIF_BIA': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=recapitulatif_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BLOCAGE_BIA_EN_COURS': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=blocageBiaEnCours&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=blocageBiaModificationDeDonneesPersonnellesEnCours&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BLOCAGE_BIA_MONO_EQUIPE_MDPRO': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=blocageBiaMonoEquipeMDPRO&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BLOCAGE_BIA_SITUATION_AFFILIATION': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=blocageBiaSituationAffiliation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'GESTION_FINANCIERE_PAR_DEFAUT_CONTENU': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=gestionParDefaut&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BIA_PARCOURS_MANUSCRIT': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=parcours_manuscrit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_DEMANDE_ENCOURS': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_demande_encours&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_BIA_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/bia/body-content.apiV2.html.ajax?blockId=contenu_bia_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    questionsResponsesPath: {
      QUESTIONS_CLAUSE_BENEFICIAIRE:
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/clause-beneficiaire/area-simple-content.apiV2.html.ajax?blockId=clauseBeneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComment'
    },

    dictionnariesPath: {
      dictionnaireBia: '/sites/aqe/ecrs/bia/body-content/dictionnairebia.apiDico.html.ajax',
    }
  },

  coordonneesBancaires: {
    contribsPath: {
      'CONTENU_RIB_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=contenu_rib_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'TITLE_MODIFICATION_COORDONEES_BANCAIRES': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=title_modification_coordonees_bancaires&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MDPRO': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MDPRO&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MULTI_EQUIPE': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MULTI_EQUIPE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireCoordonneesBancaires: '/sites/aqe/ecrs/coordonneesbancaires/head-content/dictionnairecoordonneesbancaires.apiDico.html.ajax'
    }
  },

  prevalidation: {
    contribsPath: {
      'CONTENU_PREVALIDATION_DEMANDE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identite_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_SIGN_MANU': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_signature_manuscrite&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_DONNEES_PERSO': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=saisirdonneesPerso&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_IDENTITE_NUM': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identite_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_MODIF_DONNEES': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identiteNum_modif_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VOUS_PROTEGER': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=identite_Num_Vous_Proteger&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_PIECE_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_piece_identite&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VOTRE_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_votre_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_UPLOAD': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_indications_upload&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VERIFIER_DONNEES': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_verifier_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VERIFIER_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_verifier_identite&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    },

    dictionnariesPath: {
      dictionnairePrevalidation: '/sites/aqe/ecrs/identitenum/body-content/dictionnaireidentitenum.apiDico.html.ajax',
    }
  },

  identiteNum: {
    contribsPath: {
      'CONTENU_DONNEES_PERSO_INCOHERENTS': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=donneesPersoIncoherents&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_EMAIL_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_email_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_TEL_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_tel_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_EMAIL_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_email_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_TEL_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_tel_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    }
  },

  evenements: {
    contribsPath: {
      'ERE_BIA': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_CONF': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_conf&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_PND_3': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_3&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_PND_1': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_1&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_VDPP': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_vdpp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_INFO': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_info&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      eventDictionnaireDeLibelles: '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content/eventdictionnairedelibelles.apiDico.html.ajax',
    }
  },

  objectifs: {
    contribsPath: {
      'OBJECTIFS_CONTENT': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=objectifsContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },
    dictionnariesPath: {
      dictionnaireSujet: '/sites/aqe/ecrs/sujet/body-content/dictionnairesujet.apiDico.html.ajax',
    }
  },

  onboarding: {
    contribsPath: {
      /*Bienvenue */
      'bienvenueContent': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=bienvenueContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',

      /*Gestion financiere*/
      'GESTION_FINANCIERE_CONTENT': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=gestionFinanciereContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'GESTION_FINANCIERE_ACCORDION_CONTENT': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=gestionFinanciereAccordionContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'GESTION_FINANCIERE_ACCORDION_TITLE': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=gestionFinanciereAccordionTitle&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'MODIFICATION_CLAUSE_GESTION_FINANCIERE': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=modificationClauseGestionFinanciere&typeUrlResource=absolute&removeJS&removeCSS&removeComments',

      /*Clause bénéficiaire*/
      'BENEFICIAIRE_CONTENT': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=beneficiaireContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICIAIRE_ACCORDION_CONTENT': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=beneficiaireAccordionContent&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'MODIFICATION_CLAUSE_BENEFICIAIRE': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=modificationClauseBeneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICAIRE_ACCORDION_OPEN_TITLE': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=designationBeneficiaireAccordionTitleOpen&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICAIRE_ACCORDION_CLOSE_TITLE': '/sites/aqe/ecrs/onboarding/body-content.apiV2.html.ajax?blockId=designationBeneficiaireAccordionTitleClose&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireOnboarding: '/sites/aqe/ecrs/onboarding/body-content/dictionnaireonboarding.apiDico.html.ajax',
    }
  },

  synthese: {
    contribsPath: {
      /* Conditions */
      SYNTHESE_ENTETE:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      /* Synthese */
      CONTENU_C2_NIE_VIDE:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=contenuCompartimentC2NieVide&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      CONTENU_C2_NIE_NON_VIDE:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=contenuCompartimentC2NieNonVide&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'MKG_LYFE_CONTENT_CONTRIB': '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=MKG_LYFE&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      /*Guide Tour*/
      'CONTENU_ETAPE_BIENVENUE': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_bienvenue&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_VOS_ACTIONS': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_vos_actions&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_DOUGHNUT': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_doughnut&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_ENCOURS': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_encours&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_COMPARTIMENTS': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_compartiments&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_CONTRATS': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_contrats&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ETAPE_SIMULATEUR': '/sites/aqe/ecrs/guidetour/body-content.apiV2.html.ajax?blockId=contenu_etape_simulateur&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireSynthese: '/sites/aqe/ecrs/synthese/body-content/dictionnairesynthese.apiDico.html.ajax',
    }
  },

  contact: {
    contribsPath: {
      'CONTACT_TILE': '/sites/aqe/ecrs/nouscontacter/body-content.apiV2.html.ajax?blockId=contenu_contact_reclamation_header&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PHRASE_SAISIE_RECLAMATION': '/sites/aqe/ecrs/nouscontacter/body-content.apiV2.html.ajax?blockId=phrase_saisie_reclamation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PRENDRE_RDV': '/sites/aqe/ecrs/nouscontacter/body-content.apiV2.html.ajax?blockId=contenu_prendre_rdv&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaire_contact_reclamation: '/sites/aqe/ecrs/nouscontacter/body-content/dictionnairecontactreclamation.apiDico.html.ajax',
    }
  },

  versement: {
    dictionnariesPath: {
      dictionnaireVersement: '/sites/aqe/ecrs/versement/body-content/dictionnaireversement.apiDico.html.ajax',
    },
    contribsPath: {
      'CONTENU_VERSEMENT_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=contenu_versement_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_PARCOURS_MANUSCRIT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=parcours_manuscrit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERE_CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_ere_contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERE_CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_ere_contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERE_CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_ere_contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERE_CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_ere_contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_MDPRO_CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_mdpro_contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_MDPRO_CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_mdpro_contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_MDPRO_CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_mdpro_contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_MDPRO_CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_mdpro_contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERE_INTRO_ETAPE1_CHOIX_VERSEMENT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape1_choix_versement&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_INTRO_ETAPE2_CHOIX_REPARTITION': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape2_choix_repartition&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_INTRO_ETAPE3_CHOIX_PAIEMENT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape3_choix_paiement&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_INTRO_ETAPE3_CHOIX_MODE_PAIEMENT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape3_choix_moyen_paiement&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_INTRO_ETAPE3_SIGELEC_INFO_UNIVERSIGN': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape3_sigelec_universign&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ALERTE_MONTANT_DEPASSE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_alerte_montant_depasse&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_PROGRAMME_EXISTANT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_programme_existant&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_NEW_REPARTITION_TEXT': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_new_repartition_text&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_CARTE_BANCAIRE_IMG': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_carte_bancaire_img&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_CARTE_BANCAIRE_TYPES_IMG': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_carte_bancaire_types_img&typeUrlResource=absolute&removeJS&removeCSS&removeComments',

      /* Conditions */
      'VERSEMENT_ZONE_TELEPHONE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_zone_telephone&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_INTRO_ETAPE_TITLE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_intro_etape_title&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ZONE_CONFORMITE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=versement_zone_conformite&typeUrlResource=absolute&removeJS&removeCSS&removeComments',

      /*Erreur acces CB*/
      'VERSEMENT_CB_PLAFOND_DEPASSE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=VERSEMENT_CB_PLAFOND_DEPASSE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_CB_AFFECTATION_FONDS_DIFFERENTE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=VERSEMENT_CB_AFFECTATION_FONDS_DIFFERENTE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_ERREUR_CARTE_BANCAIRE_INDISPO': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=VERSEMENT_ERREUR_CARTE_BANCAIRE_INDISPO&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT_CB_DOMICILIATION_INCOMPATIBLE': '/sites/aqe/ecrs/versement/body-content.apiV2.html.ajax?blockId=VERSEMENT_CB_DOMICILIATION_INCOMPATIBLE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },
  },


  paiementDigital: {
    dictionnariesPath: {
      dictionnairePaiementDigital: '/sites/aqe/ecrs/paiementdigital/body-content/dictionnairepaiementdigital.apiDico.html.ajax',
    },
    contribsPath: {

      /*Erreur CB*/
      'PAIEMENT_DIGITAL_ERREUR_BANQUE_NON_AUTORISEE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_BANQUE_NON_AUTORISEE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_PAYS_NON_AUTORISE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_PAYS_NON_AUTORISE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_PLAFOND_ATTEINT': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_PLAFOND_ATTEINT&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_PLAFOND_DEPASSE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_PLAFOND_DEPASSE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_PENDANT_SIGNATURE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_PENDANT_SIGNATURE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_PAIEMENT_CARTE_EXPIREE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_PAIEMENT_CARTE_EXPIREE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_CARTE_PREPAYEE_NON_ACCEPTEE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_CARTE_PREPAYEE_NON_ACCEPTEE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TYPE_CARTE_NON_AUTORISE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TYPE_CARTE_NON_AUTORISE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_3DSECURE_NON_VALIDE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_3DSECURE_NON_VALIDE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TRANSACTION_REFUSEE': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TRANSACTION_REFUSEE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_COND_PAIEMENTS_AVANT_ACQUISITION': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_COND_PAIEMENTS_AVANT_ACQUISITION&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_RETRAITE_SUPP_APRES_ACQUISITION': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_RETRAITE_SUPP_APRES_ACQUISITION&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_BANCAIRE_AVANT_ACQUISITION': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_BANCAIRE_AVANT_ACQUISITION&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_BANCAIRE_APRES_ACQUISITION': '/sites/aqe/ecrs/paiementdigital/body-content.apiV2.html.ajax?blockId=PAIEMENT_DIGITAL_ERREUR_TECHNIQUE_SERVICE_BANCAIRE_APRES_ACQUISITION&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    },
  },

  arretVersement: {
    dictionnariesPath: {
      dictionnaireArretVersement: '/sites/aqe/ecrs/arretversement/body-content/dictionnairearretversement.apiDico.html.ajax'
    },

    contribsPath: {
      'CONTENU_ARRET_VERSEMENT_DEMANDE': '/sites/aqe/ecrs/arretversement/body-content.apiV2.html.ajax?blockId=contenu_arret_versement_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARRET_VERSEMENT_PARCOURS_MANUSCRIT': '/sites/aqe/ecrs/arretversement/body-content.apiV2.html.ajax?blockId=parcours_manuscrit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARRET_VERSEMENT_INTRO_ETAPE_TITLE': '/sites/aqe/ecrs/arretversement/body-content.apiV2.html.ajax?blockId=arret_versement_intro_etape_title&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    }
  },

  qad: {
    dictionnariesPath: {
      dictionnaireQad: '/sites/aqe/ecrs/qad/body-content/dictionnaireqad.apiDico.html.ajax'
    },

    contribsPath: {
      'QAD_SPLASH': '/sites/aqe/ecrs/qad/body-content.apiV2.html.ajax?blockId=splashQad&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    }

  },

  clauseBeneficiaire: {
    contribsPath: {
      'CONTENU_CLAUSE_BENEFICIAIRE_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_clausebenef_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CLAUSE_BENEFICIAIRE_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_clause_benef_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CLAUSE_BENEFICIAIRE_PARCOURS_MANUSCRIT': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=parcours_manuscrit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BLOCAGE_MODIFICATION_CLAUSE_BENEFICIAIRE_EN_COURS': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=blocageModificationClauseBeneficiaireEnCours&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CLAUSE_BENEFICIAIRE_CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CLAUSE_BENEFICIAIRE_CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CLAUSE_BENEFICIAIRE_CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CLAUSE_BENEFICIAIRE_CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'TITRE_QUESTIONS_CLAUSE_BENEFICIAIRE': '/sites/aqe/ecrs/clausebenef/body-content.apiV2.html.ajax?blockId=titre_questions_clause_beneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireClauseBenef: '/sites/aqe/ecrs/clausebenef/body-content/dictionnaireclausebenef.apiDico.html.ajax',
      dictionnaireClauseBeneficiaire: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/modifier-sa-clause-beneficiaire/area-simple-content/clausebeneficiairecommundictionn.apiDico.html.ajax'
    }
  },

  arbitrage: {
    contribsPath: {
      'CONTENU_ARBITRAGE_GESTION_FIN': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=contenu_arbitrage_gestion_fin&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_PARCOURS_MANUSCRIT': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=parcours_manuscrit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_ere_contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_ere_contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_ere_contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_ere_contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_MDPRO_CONTENU_FINALISER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_mdpro_contenu_finaliser_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_MDPRO_CONTENU_VERIFIER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_mdpro_contenu_verifier_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_MDPRO_CONTENU_IMPRIMER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_mdpro_contenu_imprimer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_MDPRO_CONTENU_ENVOYER_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arbitrage_mdpro_contenu_envoyer_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_MDPRO_RECAP_FRAIS_ARBITRAGE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=recap_frais_arbitrage&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_RECAP_FRAIS_ARBITRAGE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=recap_frais_arbitrage&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_INTRO_ETAPE1_CHOIX_ARBITRAGE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arb_intro_etape1_choix_arbitrage&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE_ERE_INTRO_ETAPE2_CHOIX_REPARTITION': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=arb_intro_etape2_choix_repartition&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_ARBITRAGE_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=contenu_arbitrage_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },
    dictionnariesPath: {
      dictionnaireArbitrage: '/sites/aqe/ecrs/arbitrage/body-content/dictionnairearbitrage.apiDico.html.ajax'
    }
  },

  shared: {
    contribsPath: {
      'MA_DEMANDE_TITRE_ETAPES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=ma_demande_etapes_titre&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CONFIRMER_COORDONNEES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_confirmer_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_VALIDER_IDENTITE_NUM': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_valider_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MAJ_COORDONNEES_SIDE': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_update_coordonnees_side_component&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },
    dictionnariesPath: {
      dictionnaireCommon: '/sites/aqe/ecrs/shared/body-content/dictionnaireshared.apiDico.html.ajax'
    }
  },
  HubVersement: {
    dictionnariesPath: {
      dictionnaireHubVersement: '/sites/aqe/ecrs/hubversement/body-content/dictionnairehubversement.apiDico.html.ajax'
    },
    contribsPath: {
      'HUB_VERSEMENT_TITLE': '/sites/aqe/ecrs/hubversement/body-content.apiV2.html.ajax?blockId=hub_versement_title&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    }

  },
  other: {
    contribsPath: {
      /*Vos Données*/
      'ENTETE_DONNEES': '/sites/aqe/home/retraite-supplementaire/synthese-des-comptes/gestion-financiere/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute',
      'QUESTIONS_FREQUENTES_TITLE': '/sites/aqe/ecrs/ensavoirplus/questionsfrequentes/body-content/area-simple-content/bloc-esclave-1.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute'
    },

    dictionnariesPath: {
      dictionnaireClauseContrat: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausecontratdictionnairedelibel.apiDico.html.ajax',
      dictionnaireClauseStandardContrat: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausestandarddictionnairedelibe.apiDico.html.ajax',
    },

    questionsResponsesPath: {
      AIDE_PACTE_VERSEMENT:
        '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content.apiV2.html.ajax?blockId=aidepacteversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      QUESTIONS_CLAUSE_BENEFICIAIRE:
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/clause-beneficiaire/area-simple-content.apiV2.html.ajax?blockId=clauseBeneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      QUESTIONS_CARACTERE_PERSONNEL:
        '/sites/aqe/home/retraite-supplementaire/mentions-legales/area-simple-content.apiV2.html.ajax?blockId=mentionscnil&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      QUESTIONS_FREQUENTES:
        '/sites/aqe/ecrs/ensavoirplus/questionsfrequentes/body-content/area-simple-content.apiV2.html.ajax?blockId=faqBlock&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  EnSavoirPlus: {
    contribsPath: {
      'EN_SAVOIR_PLUS_TITLE': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'EN_SAVOIR_PLUS_VOS_CONTRATS': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=mesFiscalites&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=lexique-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RENTE-PER-ENTREPRISE-COMPO': '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=rente-per-entreprise-compo&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  En_savoir_plus_lexique: {
    contribsPath: {
      'LEXIQUE_TITLE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-34.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ACTIF_GENERAL': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave.apiV2.html.ajax?blockId=actif-general&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'AFFILIATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-1.apiV2.html.ajax?blockId=affiliation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'AGIRC': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-2.apiV2.html.ajax?blockId=agirc&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARBITRAGE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-3.apiV2.html.ajax?blockId=arbitrage&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARRCO': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-4.apiV2.html.ajax?blockId=arrco&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ARRERAGE-DE-RENTE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-5.apiV2.html.ajax?blockId=arrerage-de-rente&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ASSURANCE-COLLECTIVE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-6.apiV2.html.ajax?blockId=assurance-collective&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-7.apiV2.html.ajax?blockId=assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ASSURE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-8.apiV2.html.ajax?blockId=assure&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'AYANT-DROIT': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-9.apiV2.html.ajax?blockId=ayant-droit&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BULLETIN-INDIVIDUEL-D-AFFILIATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-10.apiV2.html.ajax?blockId=bulletin-individuel-d-affiliation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'BENEFICIAIRE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-11.apiV2.html.ajax?blockId=beneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'COMPTE-INDIVIDUEL-RETRAITRE-SUPP': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-12.apiV2.html.ajax?blockId=compte-individuel-retraitre-supp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'COMPTE-EPARGNE-TEMPS': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-13.apiV2.html.ajax?blockId=compte-epargne-temps&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'COTISATIONS-OBLIGATOIRES': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-14.apiV2.html.ajax?blockId=cotisations-obligatoires&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'GESTION-LIBRE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-15.apiV2.html.ajax?blockId=gestion-libre&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'GESTION-PAR-HORIZON': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-16.apiV2.html.ajax?blockId=gestion-par-horizon&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'LIQUIDATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-17.apiV2.html.ajax?blockId=liquidation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'NOTE-INFORMATION-FINANCIERE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-18.apiV2.html.ajax?blockId=note-information-financiere&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'NOTICE-INFORMATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-19.apiV2.html.ajax?blockId=notice-information&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'OPC': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-20.apiV2.html.ajax?blockId=opc&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PARTICIPATION-BENEFICES': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-21.apiV2.html.ajax?blockId=participation-benefices&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PLAN-EPARGNE-RETRAITE-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-22.apiV2.html.ajax?blockId=plan-epargne-retraite-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'PLAN-EPARGNE-RETRAITE-ENTREPRISE-VIF': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-23.apiV2.html.ajax?blockId=plan-epargne-retraite-entreprise-vif&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RACHAT-EXCEPTIONNEL': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-24.apiV2.html.ajax?blockId=rachat-exceptionnel&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RELEVE-ANNUEL-DE-SITUATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-25.apiV2.html.ajax?blockId=releve-annuel-de-situation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RENTE-VIAGERE-RETRAITE-SUPP': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-26.apiV2.html.ajax?blockId=rente-viagere-retraite-supp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RETRAITE-CAPITALISATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-27.apiV2.html.ajax?blockId=retraite-capitalisation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'RETRAITE-PAR-REPARATION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-28.apiV2.html.ajax?blockId=retraite-par-reparation&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'REVERSION': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-29.apiV2.html.ajax?blockId=reversion&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'TAUX-TECHNIQUE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-30.apiV2.html.ajax?blockId=taux-technique&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'UNITES-DE-COMPTE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-31.apiV2.html.ajax?blockId=unites-de-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VALEUR-ACQUISE-COMPTE-INDIVIDUEL': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-32.apiV2.html.ajax?blockId=Valeur-acquise-compte-individuel&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'VERSEMENT-INDIVIDUEL-FACULTATIF': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content/bloc-esclave-33.apiV2.html.ajax?blockId=versement-individuel-facultatif&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    }
  },
  dossier_gestion_compte: {
    contribsPath: {
      'GESTION-COMPTE-TITLE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'BIEN-REDIGER-CLAUSE-BENEFICIAIRE-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=bien-rediger-clause-beneficiaire-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-FINANCIERE-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=gestion-financiere-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'VIDEO-GESTION-PAR-HORIZON-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=video-gestion-par-horizon-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-GESTION-COMPTE': '/sites/aqe/ecrs/ensavoirplus/dossier/la-gestion-de-mon-compte/area-simple-content.apiV2.html.ajax?blockId=lexique-gestion-compte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  dossier_fonctionnement_retraite: {
    contribsPath: {
      'FONCTIONNEMENT-RETRAITE-TITLE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'DUREE-COTISATION-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=duree-cotisation-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-PAR-REPARATION-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=retraite-par-reparation-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'DROIT-INFORMATION-RETRAITE-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=droit-information-retraite-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=lexique-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-ENJEU-DE-SOCIETE-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=retraite-enjeu-de-societe-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'REFORME-DES-RETRAITES-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=reforme-des-retraites-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ACCORD-RETRAITE-COMPLEMENTAIRE-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=accord-retraite-complementaire-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GUIDE-RETRAITE-2017-FONCTIONNEMENT-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/le-fonctionnement-de-la-retraite/area-simple-content.apiV2.html.ajax?blockId=guide-retraite-2017-fonctionnement-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  dossier_preparer_retraite: {
    contribsPath: {
      'PREPARER-RETRAITE-TITLE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=lexique-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LIQUIDER-RETRAITE-SUPPLEMENTAIRE-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=liquider-retraite-supplementaire-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'APPROCHE-RETRAITE-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=approche-retraite-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RENTE-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=rente-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'VIDEO-PREPARER-RETRAITE': '/sites/aqe/ecrs/ensavoirplus/dossier/preparer-sa-retraite/area-simple-content.apiV2.html.ajax?blockId=video-preparer-retraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  En_savoir_plus_article: {
    contribsPath: {
      'LISTE_ARTICLES_TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=liste_articles_title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLES_DOSSIERS_TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=articles_dossiers_title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'MARCHES-FINANCIERS-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=marches-financiers-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=info_loi_finances_title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-DUREE-COTISATION-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=retraite-duree-cotisation-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-ENJEU-DE-SOCIETE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=retraite-enjeu-de-societe-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTIONS-FINANCIERE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=gestions-financiere-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'REFORME-DES-RETRAITES-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=reforme-des-retraites-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'EXPATRIE-QUELLE-RETRAITE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=expatrie-quelle-retraite-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'BIEN-REDIGER-CLAUSE-BENEFICIAIRE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=bien-rediger-clause-beneficiaire-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'COMMENT-MODIFIER-GESTION-FINANCIERE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=comment-modifier-gestion-financiere-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'POURQUOI-VIF-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=pourquoi-vif-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-PAR-REPARTITION-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=retraite-par-repartition-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RETRAITE-PAR-CAPITALISATION-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=retraite-par-capitalisation-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LIQUIDER-RETRAITE-SUPPLEMENTAIRE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=liquider-retraite-supplementaire-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'APPROCHE-RETRAITE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=approche-retraite-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'OPTION-RENTE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=option-rente-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'DROIT-INFORMATION-RETRAITE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=droit-information-retraite-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ACCORD-RETRAITE-COMPLEMENTAIRE-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=accord-retraite-complementaire-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GUIDE-RETRAITE-2017-TITLE': '/sites/aqe/ecrs/ensavoirplus/article/body-content.apiV2.html.ajax?blockId=guide-retraite-2017-title&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_per_entreprise: {
    contribsPath: {
      'FISCALITE-PER-ENTREPRISE-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=lexique-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'DUREE-COTISATION-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=duree-cotisation-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RENTE-PER-ENTREPRISE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-1/area-simple-content.apiV2.html.ajax?blockId=rente-per-entreprise&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_madelin: {
    contribsPath: {
      'FISCALITE-MADELIN-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=lexique-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-MADELIN': '/sites/aqe/ecrs/ensavoirplus/fiscalite-2/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-madelin&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_madelin_agricole: {
    contribsPath: {
      'FISCALITE-MADELIN-AGRICOLE-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=lexique-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-fiscalite-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RENTE-PER-ENTREPRISE-MADELIN-AGRICOLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-3/area-simple-content.apiV2.html.ajax?blockId=rente-per-entreprise-madelin-agricole&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_assurance_vie: {
    contribsPath: {
      'FISCALITE-ASSURANCE-VIE-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=lexique-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-fiscalite-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'RENTE-PER-ENTREPRISE-ASSURANCE-VIE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-4/area-simple-content.apiV2.html.ajax?blockId=rente-per-entreprise-assurance-vie&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_perp: {
    contribsPath: {
      'FISCALITE-PERP-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=lexique-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-PERP': '/sites/aqe/ecrs/ensavoirplus/fiscalite-5/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-perp&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_article82: {
    contribsPath: {
      'FISCALITE-ARTICLE-82-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=lexique-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-ARTICLE-82': '/sites/aqe/ecrs/ensavoirplus/fiscalite-6/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-article-82&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  fiscalite_pacte: {
    contribsPath: {
      'FISCALITE-PACTE-TITLE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'FONCTIONNEMENT-RETRAITE-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=fonctionnement-retraite-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-COMPTE-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=gestion-compte-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'INFO-LOI-FINANCES-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=info-loi-finances-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'GESTION-PAR-HORIZON-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=gestion-par-horizon-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'LEXIQUE-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=lexique-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'QUESTIONS-FREQUENTES-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=questions-frequentes-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'PREPARER-RETRAITE-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=preparer-retraite-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'ARTICLE-PREPARER-RETRAITE-PACTE': '/sites/aqe/ecrs/ensavoirplus/fiscalite-7/area-simple-content.apiV2.html.ajax?blockId=article-preparer-retraite-pacte&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  simulateurFiscal: {
    contribsPath: {
      SIMULATEUR_HEADER_TEXT:
        '/sites/aqe/ecrs/simulateurfiscal/body-content.apiV2.html.ajax?blockId=contenu_simulateur_fiscal_header&typeUrlResource=absolute&removeJS&removeCSS&removeComment'
    },
    dictionnariesPath: {
      dictionnaireSimulateurFiscal:
        '/sites/aqe/ecrs/simulateurfiscal/body-content/body-content/dictionnairesimulateurfiscal.apiDico.html.ajax'
    }
  }

};


const CONTRIBS_PATH = {};
const QUESTIONS_REPONSES_PATH = {};
const DICTIONNAIRES_PATH = {};

export function cleanContentHtml(
  html: string,
  config: JahiaConfig,
  configService: ConfigService): string {
  if (!html) {
    return null;
  }

  // suppression <jahia:resource>
  // transformation lien adapter à Angular (1)
  const href1 = /#(\w.+):(\w.+)/gm;
  // transformation lien adapter à Angular (2)
  const href2 = /#(\w.+):/gm;

  // Correction des url localhost
  const jahia_files_host = configService.config[config.jahiaFiles];
  const defaultHost = /^(https?:)?\/\/localhost(:\d+)?(\/.+)/;

  const parser = new DOMParser();
  const parsedHtml = parser.parseFromString(html, 'text/html');

  const anchors = parsedHtml.getElementsByTagName('a');
  for (let i = 0; i < anchors.length; i++) {

    let tmpHref = liensEnSavoirPlus(anchors[i]);
    // href="#Dossier:preparer-sa-retraite" devient href="#/Dossier/preparer-sa-retraite"
    // tmpHref = tmpHref.replace(href1, '#/$1/$2');

    // href="#Dossier:" devient href="#/Dossier"
    // tmpHref = tmpHref.replace(href2, '#/$1');

    // Correction des URL localhost
    tmpHref = tmpHref.replace(defaultHost, `$3`);

    anchors[i].href = tmpHref;
  }

  // Correction des URL des images
  for (let i = 0; i < parsedHtml.images.length; i++) {
    const tmpSrc = parsedHtml.images[i].src.replace(defaultHost, `${jahia_files_host}$3`);
    parsedHtml.images[i].src = tmpSrc;
  }

  return parsedHtml.documentElement.innerHTML;
}

function liensEnSavoirPlus(anchor: any): string {
  let tmpHref = anchor.href;
  if (tmpHref.includes('Lexique')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/lexique';
  } else if (tmpHref.includes('ListeArticles') || anchor.innerText.includes('Voir tous nos articles et dossiers')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/articles-dossiers';
  } else if (tmpHref.includes('prelevement-a-la-so')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/article/information-loi-finances';
  } else if (tmpHref.includes('la-gestion-de-mon-contrat-dassur')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/dossier/la-gestion-de-mon-compte';
  } else if (tmpHref.includes('DossierFiscalite')) {
    const chiffre = tmpHref.indexOf('DossierFiscalite') + 16;
    tmpHref = tmpHref.replace('#DossierFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('dossierFiscalite')) {
    const chiffre = tmpHref.indexOf('dossierFiscalite') + 16;
    tmpHref = tmpHref.replace('#dossierFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('ArticleFiscalite')) {
    const chiffre = tmpHref.indexOf('ArticleFiscalite') + 16;
    tmpHref = tmpHref.replace('#ArticleFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/article/');
  } else if (tmpHref.includes('Dossier')) {
    tmpHref = tmpHref.replace('#Dossier:', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('Article')) {
    tmpHref = tmpHref.replace('#Article:', '#/en-savoir-plus/article/');
  } else if (tmpHref.includes('fiche%20pratique%20d%c3%a9c%c3%a8s.pdf')) {
    tmpHref = tmpHref.replace('live', '{workspace}');
  }
  return tmpHref;
}


export const jahiaConfig = {
  apiBase: 'jahia_endpoint',
  apiJahiaEval: 'backend/jahiaConditionEval',
  apiJahiaNgServer: 'jahia_ng_server_endpoint',
  contribsPath: CONTRIBS_PATH,
  dictionnariesPath: DICTIONNAIRES_PATH,
  questionsResponsesPath: QUESTIONS_REPONSES_PATH,
  paths: PATHS,
  cleanerContentHtml: cleanContentHtml
};
