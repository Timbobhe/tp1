import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map } from 'rxjs/operators';
import { tracking, TypeOriginAction } from '@app/actions/tracking.action';
import { PUSH_ERROR, PushError } from '@app/actions/ui.actions';
import { errorDescription } from '@app/models/client/error.model';
import { API_ERROR, ApiError } from '@ag2rlamondiale/redux-api-ng';

@Injectable({
  providedIn: 'root'
})
export class AppTrackingEffects {

  @Effect({dispatch: true})
  error$ = this.actions$.pipe(
    ofType(PUSH_ERROR),
    map(a => a as PushError),
    map(a => tracking(null, TypeOriginAction.erreurTechnique, errorDescription(a.payload)))
  );

  @Effect({dispatch: true})
  apiError$ = this.actions$.pipe(
    ofType(API_ERROR),
    map(a => a as ApiError),
    map(a => tracking(null,
      TypeOriginAction.erreurTechnique,
      errorDescription({error: a.payload.error, severity: a.payload.severity, errorType: 'API'})))
  );

  constructor(private readonly actions$: Actions) {
  }
}
