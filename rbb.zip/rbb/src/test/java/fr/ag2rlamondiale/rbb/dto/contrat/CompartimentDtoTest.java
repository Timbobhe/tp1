/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.dto.contrat;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;

/**
 * The Class CompartimentDtoTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CompartimentDtoTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(CompartimentDto.class);
	}

    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(CompartimentDto.class).suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
    
    // Testing To String
    @Test
    public void testToString() {
    	CompartimentDto maClasse = new CompartimentDto();
    	assertNotNull(maClasse.toString());
    }
}
