package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.CommonException;

import fr.ag2rlamondiale.rbb.business.IClientFacade;
import fr.ag2rlamondiale.rbb.business.IEvenementFacade;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.dto.personne.GetCoordonneesClientDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PersonneRestControllerTest {
    @Mock
    private IClientFacade clientFacade;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @InjectMocks
    PersonneRestController personneController;

    @Mock
    private IEvenementFacade evenementFacade;

    @Test
    public void should_get_coordonnees_client() throws CommonException {
        when(consulterPersPhysFacade.getCoordonneesClient(any())).thenReturn(new CoordonneesClientDto());

        assertNotNull(personneController.getCoordonneesClient(new GetCoordonneesClientDto()));
    }

    @Test
    public void should_modifier_coordonnees_client() throws CommonException {
        when(clientFacade.modifierCoordonneesClient(null)).thenReturn(new ModifierPPSiloResponseDto());

        assertNotNull(personneController.modifierCoordonneesClient(null));
    }
}
