/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.contrat;

import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;

/**
 * The Class ContratCompletTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContratCompletTest {
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		ContratComplet maClasse = new ContratComplet();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
}
