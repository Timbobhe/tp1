/*
 * Cree le 18 mai 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.api.error;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.util.Arrays;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import pl.pojo.tester.api.assertion.Method;
import utils.data.RandomData;

/**
 * The Class RestErrorTest.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration 
public class RestErrorTest {
	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();
	
	/** The level. */
	private String level = RandomData.getRandomStringSize5();
	
	/** The code. */
	private String code= RandomData.getRandomStringSize8();
	
	/** The msg. */
	private String msg = RandomData.getRandomStringSize10();
	
	/** The msg 2. */
	private String msg2 = RandomData.getRandomStringSize10();
	
	/** The additionnal messages. */
	List<String> additionnalMessages = Arrays.asList(msg,msg2);
	
	/**
	 * Test equals and hash code.
	 */
	@Test
	public void testEqualsAndHashCode() {
		EqualsVerifier.forClass(RestError.class).withRedefinedSuperclass()
		.suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
	}

	
	/**
	 * Test constructors.
	 */
	@Test
	public void testConstructors() {
		assertPojoMethodsFor(RestError.class).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	/**
	 * Test add message.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testAddMessage() throws Exception {
		RestError restError = new RestError( level,  code);
		restError.addMessage(msg);
		String value = restError.getAdditionnalMessages().get(0);
		assertEquals("wrong message",value,msg);
	}

	/**
	 * Test add messages.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testAddMessages() throws Exception {
		RestError restError = new RestError( level,  code);
		restError.addMessages(additionnalMessages);
		List<String> listeValue = restError.getAdditionnalMessages();
		assertNotNull("wrong listeValue",listeValue);
		String value = listeValue.get(0);
		assertEquals("wrong message",value,msg);
		value = listeValue.get(1);
		assertEquals("wrong message",value,msg2);
	}
}
