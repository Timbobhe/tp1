package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertEquals;

import static fr.ag2rlamondiale.rbb.business.impl.TraceHelper.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;

public class TraceHelperTest {

    private fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader createContrat(String id, String idA, String idC) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setIdAdherente(idA);
        contrat.setIdCollege(idC);
        return contrat;
    }

    private ContratHeader createContratPM(String id, String idA, String idC, String idCon) {
        ContratHeader contrat = createContrat(idC, idA, idC);
        contrat.setIdContractante(idCon);
        return contrat;
    }

    @Test
    public void getZone1ofAllContractofPPtest() {
        assertEquals("", getZone1ofAllContractofPP(null));
        List<ContratHeader> liste = new ArrayList<ContratHeader>();
        liste.add(createContrat("id1", "idA1", "idC1"));
        liste.add(createContrat("id2", "idA2", "idC2"));
        assertEquals("CT id1 | ADH idA1 | CP idC1 | CT id2 | ADH idA2 | CP idC2",
                getZone1ofAllContractofPP(liste));
    }

    @Test
    public void getZone1ofAllContractofPMtest() {
        assertEquals("", getZone1ofAllContractofPM("idPM", null));
        List<ContratHeader> liste = new ArrayList<ContratHeader>();
        liste.add(createContratPM("id1", "idA1", "idC1", "idCon"));
        liste.add(createContratPM("id2", "idA2", "idC2", "idPM"));
        assertEquals("CT idC1 | ADH idA1 | CP idC1 | CT idC2 | ADH idA2 | CP idC2",
                getZone1ofAllContractofPP(liste));
    }

    @Test
    public void getZone1ofContrattest() {
        assertEquals("CT id | ADH idA | CP idC",
                getZone1ofContrat(createContrat("id", "idA", "idC")));
    }

    @Test
    public void getZone1ofContratMDPROtest() {
        assertEquals("CT id", getZone1ofContratMDPRO(createContrat("id", "idA", "idC")));

    }

    @Test
    public void formatZone1test() {
        assertEquals("CT id | ADH idA | CP idC",formatZone1("id", "idA", "idC"));
    }

    @Test
    public void removeLastDelimitertest() {
        assertEquals("",removeLastDelimiter(""));
        assertEquals("fezfe",removeLastDelimiter("fezfe | "));
    }

    @Test
    public void replaceNullWithEmptyStringtest() {
        assertEquals("", replaceNullWithEmptyString(null));
        assertEquals(" a", replaceNullWithEmptyString("a"));
    }
}