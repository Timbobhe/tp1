/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.contrat;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataContratHeader;

/**
 * The Class ContratCompletTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContratHeaderTest {
	
	@InjectMocks
	private 	ContratHeader contratHeader = new DataContratHeader().getDataContratHeader(CompartimentType.C1);

	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		ContratHeader maClasse = new ContratHeader();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructorsWithParam() {
		assertPojoMethodsFor(contratHeader.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	/**
	 * Test getter.
	 */
	@Test
	public void testGetter() {
		assertNotNull(contratHeader.getAffichageType());
		assertNotNull(contratHeader.getCodeAssureur());
		assertNotNull(contratHeader.getCodeFiliale());
	}
	
	// Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
    	ContratHeader one = new ContratHeader();
    	ContratHeader two = new ContratHeader();
		assertEquals("These should be equal", one, two);
		int oneCode = one.hashCode();
		assertEquals("HashCodes should be equal", oneCode, two.hashCode());
		assertEquals("HashCode should not change", oneCode, one.hashCode());
    }
    
    // Testing To String
    @Test
    public void testToString() {
    	assertNotNull(contratHeader.toString());
    }
}
