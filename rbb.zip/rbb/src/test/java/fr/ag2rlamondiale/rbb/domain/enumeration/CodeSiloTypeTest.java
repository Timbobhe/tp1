/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.enumeration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
/**
 * The Class CodeSiloTypeTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CodeSiloTypeTest {
	

	@Mock
    private UserContextHolder userContextHolder;
	private UserContext userContext = new UserContext();
	
	@Before
    public void init() {
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
    }
	/**
	 * Test enum.
	 */
	@Test
	public void testCodeSiloType() {
		assertEquals("MDP", CodeSiloType.MDP.getLibelle());
		assertEquals("ERE", CodeSiloType.ERE.getLibelle());
		assertNotNull("wrong enum MDP NumeroPersonne ", CodeSiloType.MDP.getNumeroPersonne(userContext));
		assertNotNull("wrong enum MDP egesper", CodeSiloType.MDP.egesper());
		assertNotNull("wrong enum MDP ptv", CodeSiloType.MDP.ptv());
		assertNotNull("wrong enum MDP workflow", CodeSiloType.MDP.workflow());
		assertNotNull("wrong enum ERE NumeroPersonne ", CodeSiloType.ERE.getNumeroPersonne(userContext));
		assertNotNull("wrong enum ERE egesper", CodeSiloType.ERE.egesper());
		assertNotNull("wrong enum ERE ptv", CodeSiloType.ERE.ptv());
		assertNotNull("wrong enum ERE workflow", CodeSiloType.ERE.workflow());

	}
}
