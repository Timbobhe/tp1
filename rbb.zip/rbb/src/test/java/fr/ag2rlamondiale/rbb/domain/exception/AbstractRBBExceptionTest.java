package fr.ag2rlamondiale.rbb.domain.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.net.HttpURLConnection;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;
import utils.data.RandomData;

/**
 * The Class AbstractRBBExceptionTest.
 */
@RunWith(MockitoJUnitRunner.class)

public class AbstractRBBExceptionTest {
	
	/**
	 * The Class Maclass.
	 */
	private class Maclass extends AbstractRBBException{
	
	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new maclass.
	 */
	public Maclass() {
		super();
	}

	/**
	 * Instantiates a new maclass.
	 *
	 * @param code the code
	 * @param message the message
	 */
	public Maclass(String code, String message) {
		super(code, message);
	}}

	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();
	
	/** The code. */
	private String code = RandomData.getRandomStringSize5();
	
	/** The message. */
	private String message = RandomData.getRandomStringSize10();


	private String MsgError = "Erreur non documentée";
	/**
	 * Are well implemented.
	 */
	@Test
	public void testCconstructors() {
		Maclass maClasse = new Maclass();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test cconstructors all parameters.
	 */
	@Test
	public void testCconstructorsAllParameters() {
		Maclass maClasseParameter = new Maclass(code,message);
		assertPojoMethodsFor(maClasseParameter.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test ma classe getter.
	 */
	@Test
	public void testMaClasseGetter() {
		Maclass maClasse = new Maclass();

		assertEquals("wrong code", maClasse.getCode(),Integer.toString(HttpURLConnection.HTTP_INTERNAL_ERROR));
		
		assertEquals("wrong message",MsgError, maClasse.getMessage());
	}
	
	/**
	 * Test ma classe parameter getter.
	 */
	@Test
	public void testMaClasseParameterGetter() {
		Maclass maClasseParameter = new Maclass(code,message);
		Maclass maClasseParameter2 = new Maclass(code,message);
		assertEquals("wrong code", maClasseParameter.getCode(),code);
		assertEquals("wrong message", maClasseParameter.getMessage(),message);
		assertEquals("wrong message", maClasseParameter.getMessage(),maClasseParameter2.getMessage());
		assertEquals("wrong code", maClasseParameter.getCode(),maClasseParameter2.getCode());
	}
	
	/**
	 * Test ma classe equals.
	 */
	@Test
	public void testMaClasseEquals() {
		Maclass maClasse = new Maclass();
		Maclass maClasse2 = new Maclass();
		assertEquals("wrong equals", maClasse,maClasse2);
		assertTrue("wrong canEqual", maClasse.canEqual(maClasse2));
		assertTrue("wrong canEqual", maClasse2.canEqual(maClasse));
	}
	
	/**
	 * Test ma classe parameter equals.
	 */
	@Test
	public void testMaClasseParameterEquals() {
		Maclass maClasseParameter = new Maclass(code,message);
		Maclass maClasseParameter2 = new Maclass(code,message);
		assertEquals("wrong equals", maClasseParameter,maClasseParameter2);
		assertTrue("wrong canEqual", maClasseParameter.canEqual(maClasseParameter2));
		assertTrue("wrong canEqual", maClasseParameter2.canEqual(maClasseParameter));
	}
	
	/**
	 * Test ma classe paramete to string.
	 */
	@Test
	public void testMaClasseParameteToString() {
		Maclass maClasseParameter = new Maclass(code,message);
		Maclass maClasseParameter2 = new Maclass(code,message);
		assertEquals("wrong equals ToString", maClasseParameter.toString(),maClasseParameter2.toString());
	}
	
	/**
	 * Test ma classe to string.
	 */
	@Test
	public void testMaClasseToString() {
		Maclass maClasse = new Maclass();
		Maclass maClasse2 = new Maclass();
		assertEquals("wrong equals ToString", maClasse.toString(),maClasse2.toString());
	}
	
	/**
	 * Test ma classe hash code.
	 */
	@Test
	public void testMaClasseHashCode() {
		Maclass maClasse = new Maclass();
		Maclass maClasse2 = new Maclass();
		assertEquals("wrong equals HashCode", maClasse.hashCode(),maClasse2.hashCode());
	}
	
	/**
	 * Test ma classe paramete hash code.
	 */
	@Test
	public void testMaClasseParameteHashCode() {
		Maclass maClasseParameter = new Maclass(code,message);
		Maclass maClasseParameter2 = new Maclass(code,message);
		assertEquals("wrong equals HashCode", maClasseParameter.hashCode(),maClasseParameter2.hashCode());

	}
}
