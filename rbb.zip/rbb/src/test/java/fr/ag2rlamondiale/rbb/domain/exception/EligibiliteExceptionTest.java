package fr.ag2rlamondiale.rbb.domain.exception;

import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;
import utils.data.RandomData;

/**
 * The Class EligibiliteExceptionTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class EligibiliteExceptionTest {
	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();
	
	/** The code. */
	private String code = RandomData.getRandomStringSize5();
	
	/** The message. */
	private String message = RandomData.getRandomStringSize10();

	

	/**
	 * Are well implemented.
	 */
	@Test
	public void testCconstructors() {
		EligibiliteException eligibiliteException = new EligibiliteException();
		assertPojoMethodsFor(eligibiliteException.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test cconstructors all parameters.
	 */
	@Test
	public void testCconstructorsAllParameters() {
		EligibiliteException eligibiliteException = new EligibiliteException(code,message);
		assertPojoMethodsFor(eligibiliteException.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
}

