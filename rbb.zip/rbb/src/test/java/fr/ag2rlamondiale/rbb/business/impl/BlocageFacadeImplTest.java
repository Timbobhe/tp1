package fr.ag2rlamondiale.rbb.business.impl;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.rest.IBlocageRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import fr.ag2rlamondiale.trm.domain.blocage.BlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.ExceptionBlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.FonctionnaliteJson;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import com.ag2r.common.exceptions.TechnicalException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class BlocageFacadeImplTest {

    AtomicInteger atomicInteger = new AtomicInteger();

    @InjectMocks
    BlocageFacadeImpl blocageFacadeImpl;
    
    @Mock
    IContratFacade contratFacade;

    @Mock
    IPartenaireFacade partenaireFacade;

    @Mock
    IBlocageRestClient blocageRestClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Mock
    private UserContextHolder userContextHolder;

    @Before
    public void setUp() throws Exception {
        blocageFacadeImpl.setProxy(blocageFacadeImpl);
    }

    @Test
    public void testRechercherBlocages() throws Exception {
        when(blocageRestClient.rechercherBlocages(eq("P4317436"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesERE());

        when(blocageRestClient.rechercherBlocages(eq("P2224552"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesMDPRO());

        final List<BlocageJson> blocagesERE =
                blocageRestClient.rechercherBlocages("P4317436", CodeApplicationType.AQEA, new ArrayList<>());

        final List<BlocageJson> blocagesMDPRO =
                blocageRestClient.rechercherBlocages("P2224552", CodeApplicationType.AQEA, new ArrayList<>());

        assertEquals(4, blocagesERE.size());
        assertEquals("ERE", blocagesERE.get(0).getCodeSiloType());
        assertEquals(3, blocagesMDPRO.size());
        assertEquals("MDP", blocagesMDPRO.get(0).getCodeSiloType());
    }

    @Test
    public void testGetInfosBlocagesClient() throws Exception {
        when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("P4317436", "P2224552"));

        // 1er appel : ERE
        when(blocageRestClient.rechercherBlocages(eq("P4317436"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesERE());
        // 2eme appel : MDP
        when(blocageRestClient.rechercherBlocages(eq("P2224552"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesMDPRO());

        when(contratFacade.rechercherContrats(eq(CodeSiloType.MDP))).thenReturn(mockContratsMdPro());
        when(contratFacade.rechercherContrats(eq(CodeSiloType.ERE))).thenReturn(mockContratsEre());
        when(partenaireFacade.findById(anyString())).thenReturn(new PartenaireJson());
        when(partenaireFacade.findPartenaire(any(String.class), ArgumentMatchers.isNull(), any(String.class))).thenReturn(new PartenaireJson());

        final InfosBlocagesClient infosBlocagesClient = blocageFacadeImpl.getInfosBlocagesClient();
        assertFalse(infosBlocagesClient.isPersonneTotalementBloquee());
        assertTrue(infosBlocagesClient.isToutLesContratsTotalementsBloques());
        assertEquals(3, infosBlocagesClient.getFonctionnalitesBloqueesALaPersonne().size());
        assertEquals("versementProgramme", infosBlocagesClient.getFonctionnalitesBloqueesALaPersonne().iterator().next());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesPartenaire().size());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesTousContrats().size());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesContrats().size());
    }
    
    @Test(expected = Exception.class)
    public void testGetInfosBlocagesClientException() throws TechnicalException {
       blocageFacadeImpl.getInfosBlocagesClient();
    }
    
    @Test
    public void testGetInfosBlocagesClientWithParams() throws Exception {
        when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("P4317436", "P2224552"));

        // 1er appel : ERE
        when(blocageRestClient.rechercherBlocages(eq("P4317436"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesERE());
        // 2eme appel : MDP
        when(blocageRestClient.rechercherBlocages(eq("P2224552"), eq(CodeApplicationType.AQEA), any()))
                .thenReturn(mockBlocagesMDPRO());

        when(contratFacade.rechercherContrats(eq(CodeSiloType.MDP))).thenReturn(mockContratsMdPro());
        when(contratFacade.rechercherContrats(eq(CodeSiloType.ERE))).thenReturn(mockContratsEre());
        when(partenaireFacade.findById(anyString())).thenReturn(new PartenaireJson());
        when(partenaireFacade.findPartenaire(any(String.class), ArgumentMatchers.isNull(), any(String.class))).thenReturn(new PartenaireJson());

        InfosBlocagesClient infosBlocagesClient = blocageFacadeImpl.getInfosBlocagesClient(
        		"P111","P344");

        assertFalse(infosBlocagesClient.isPersonneTotalementBloquee());
        assertTrue(infosBlocagesClient.isToutLesContratsTotalementsBloques());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesALaPersonne().size());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesPartenaire().size());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesTousContrats().size());
        assertEquals(0, infosBlocagesClient.getFonctionnalitesBloqueesContrats().size());
    }
    
    @Test(expected =Exception.class)
    public void testGetInfosBlocagesClientWithParamsException() throws TechnicalException {
       blocageFacadeImpl.getInfosBlocagesClient(any(String.class),any(String.class));
    }
    
    @Test(expected = Exception.class)
    public void testGetContratsNonBloques() throws TechnicalException {
       blocageFacadeImpl.getContratsNonBloques();
    }
    
    @Test
    public void test_mockContratsEre() {
        final List<ContratHeader> contratHeaders = mockContratsEre();
        assertEquals(1, contratHeaders.size());
    }

    private List<FonctionnaliteJson> mockFonctionnalites(String codeFct) {
        List<FonctionnaliteJson> fonctionnalites = new ArrayList<>();
        FonctionnaliteJson vosDonnees = new FonctionnaliteJson();
        vosDonnees.setIdFct(2);
        vosDonnees.setTypeFct("MENU");
        vosDonnees.setCodeFct(codeFct);
        vosDonnees.setLibelleFct("libelle");
        vosDonnees.setTypeAcces("A1324");
        fonctionnalites.add(vosDonnees);
        return fonctionnalites;
    }

    private List<FonctionnaliteJson> mockFonctionnalites(List<String> codesFct) {
        List<FonctionnaliteJson> fonctionnalites = new ArrayList<>();
        codesFct.forEach(codeFct -> {
            FonctionnaliteJson vosDonnees = new FonctionnaliteJson();
            vosDonnees.setIdFct(atomicInteger.getAndIncrement());
            vosDonnees.setTypeFct("MENU");
            vosDonnees.setCodeFct(codeFct);
            vosDonnees.setLibelleFct("libelle");
            vosDonnees.setTypeAcces("A1324");
            fonctionnalites.add(vosDonnees);
        });
        return fonctionnalites;
    }

    private List<ExceptionBlocageJson> mockExceptionBlocage(PerimetreType perimetreType, String valeur) {
        List<ExceptionBlocageJson> exceptions = new ArrayList<>();
        ExceptionBlocageJson exception = new ExceptionBlocageJson();
        exception.setTypePerimetre(perimetreType);
        exception.setValeurPerimetre(valeur);
        exceptions.add(exception);
        return exceptions;
    }

    private List<BlocageJson> mockBlocagesERE() {
        List<BlocageJson> blocages = new ArrayList<>();
        BlocageJson blocagePersonne = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576599555000")
                .codeSiloType("ERE")
                .fonctionnalites(mockFonctionnalites(Arrays.asList("VosDonneesContract", "ContactFormulaire")))
                .exceptionBlocages(new ArrayList<>())
                .build();
        blocagePersonne.setTypePerimetre(PerimetreType.PERSONNE);
        blocagePersonne.setValeurPerimetre("P4317436");
        blocages.add(blocagePersonne);
        BlocageJson blocageContrat = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576587052000")
                .codeSiloType("ERE")
                .fonctionnalites(mockFonctionnalites("versementLibre"))
                .exceptionBlocages(new ArrayList<>())
                .build();
        blocageContrat.setTypePerimetre(PerimetreType.CONTRAT);
        blocageContrat.setValeurPerimetre("RG151095348");
        blocages.add(blocageContrat);
        BlocageJson blocageProduit = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576587052000")
                .codeSiloType("ERE")
                .fonctionnalites(mockFonctionnalites("VosCoordonneesBancaires"))
                .exceptionBlocages(new ArrayList<>())
                .build();
        blocageProduit.setTypePerimetre(PerimetreType.PRODUIT);
        blocageProduit.setValeurPerimetre("RG01-012-ARI");
        blocages.add(blocageProduit);
        BlocageJson blocageFiliale = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576587052000")
                .codeSiloType("ERE")
                .fonctionnalites(mockFonctionnalites("SimulateurFiscal"))
                .exceptionBlocages(mockExceptionBlocage(PerimetreType.PRODUIT, "RG01-012-ARI"))
                .build();
        blocageFiliale.setTypePerimetre(PerimetreType.FILIALE);
        blocageFiliale.setValeurPerimetre("ARI");
        blocages.add(blocageFiliale);
        return blocages;
    }

    private List<BlocageJson> mockBlocagesMDPRO() {
        List<BlocageJson> blocages = new ArrayList<>();
        BlocageJson blocagePersonne = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576599555000")
                .codeSiloType("MDP")
                .fonctionnalites(mockFonctionnalites(Arrays.asList("versementProgramme", "ContactFormulaire")))
                .exceptionBlocages(new ArrayList<>())
                .build();
        blocagePersonne.setTypePerimetre(PerimetreType.PERSONNE);
        blocagePersonne.setValeurPerimetre("P2224552");
        blocages.add(blocagePersonne);
        BlocageJson blocageProduit = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576587052000")
                .codeSiloType("MDP")
                .fonctionnalites(mockFonctionnalites(Arrays.asList("versementLibre", "SimulateurFiscal")))
                .exceptionBlocages(new ArrayList<>())
                .build();
        blocageProduit.setTypePerimetre(PerimetreType.PRODUIT);
        blocageProduit.setValeurPerimetre("RF02-V01-LMX");
        blocages.add(blocageProduit);
        BlocageJson blocageFiliale = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576587052000")
                .codeSiloType("MDP")
                .fonctionnalites(mockFonctionnalites(Arrays.asList("GestionFinanciere", "EvolutionSupport")))
                .exceptionBlocages(mockExceptionBlocage(PerimetreType.PRODUIT, "RG01-012-ARI"))
                .build();
        blocageFiliale.setTypePerimetre(PerimetreType.FILIALE);
        blocageFiliale.setValeurPerimetre("LMX");
        blocages.add(blocageFiliale);
        return blocages;
    }

    private List<ContratHeader> mockContratsEre() {
        String json =
                "[{\"id\":\"RG151095348\", \"personId\":\"P4317436\", \"raisonSocialeAdherente\":null, \"idContractante\":\"S3965904\", \"raisonSocialeContractante\":\"EDF SA\", \"college\":\"Cadres\", \"idCollege\":\"7732\", \"identifiantAssure\":\"727796\", \"vifPossible\":false, \"blocked\":false, \"blacklisted\":false, \"contractanteRepresent\":false, \"hasVersementProgrammes\":false, \"dateAffiliation\":null, \"codeSilo\":\"ERE\", \"codeProduit\":null, \"codeMentionLegale\":null, \"typeContrat\":\"RG01\", \"numGenContrat\":\"012\", \"codeFiliale\":\"ARI\", \"etatContratLabel\":\"En cours\", \"etatAffiliationLabel\":\"En cours\", \"dateEffet\":1104534000000, \"dateFinEffet\":null, \"codeSitAffil\":\"AFSBI\", \"libSitAffil\":\"Affilié en cours sans BIA\", \"dateSitAffil\":1283378400000, \"etatContrat\":\"VALIDE\", \"dateSitCtr\":null}]";
        final ContratHeader[] contratHeaders = JsonMarshaller.fromJSON(json, ContratHeader[].class, true);
        return Arrays.asList(contratHeaders);
    }

    private List<ContratHeader> mockContratsMdPro() {
        String json =
                "[{\"id\":\"RF049057071116\", \"personId\":\"P2224552\", \"raisonSocialeAdherente\":null, \"idContractante\":\"S0030944\", \"raisonSocialeContractante\":\"TOUPARGEL SURGELES\", \"college\":\"CADRES\", \"idCollege\":\"99\", \"identifiantAssure\":\"P2224552\", \"vifPossible\":false, \"blocked\":false, \"blacklisted\":false, \"contractanteRepresent\":false, \"hasVersementProgrammes\":false, \"dateAffiliation\":null, \"codeSilo\":\"MDP\", \"codeProduit\":null, \"codeMentionLegale\":null, \"typeContrat\":\"RF02\", \"numGenContrat\":\"V01\", \"codeFiliale\":\"LMX\", \"etatContratLabel\":\"En cours\", \"etatAffiliationLabel\":\"En cours\", \"dateEffet\":1104534000000, \"dateFinEffet\":null, \"codeSitAffil\":null, \"libSitAffil\":null, \"dateSitAffil\":1283378400000, \"etatContrat\":\"LIBERE_PRIME_DEMANDE\", \"dateSitCtr\":1106534000000}]";
        final ContratHeader[] contratHeaders = JsonMarshaller.fromJSON(json, ContratHeader[].class, true);
        return Arrays.asList(contratHeaders);
    }

    private UserContext createUserContextMultiEquipe(String ere, String mdPro) {
        DocumentationFacadeImplTest.MockUserContext userContext = new DocumentationFacadeImplTest.MockUserContext();
        userContext.setNumeroPersonneEre(ere);
        userContext.setNumeroPersonneMdpro(mdPro);
        Partenaire part = new Partenaire();
        part.setCodePartenaire("49504");
        userContext.setPartenaire(part);
        return userContext;
    }

}
