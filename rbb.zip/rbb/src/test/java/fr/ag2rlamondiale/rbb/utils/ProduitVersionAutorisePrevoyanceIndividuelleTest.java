package fr.ag2rlamondiale.rbb.utils;

import static org.junit.Assert.assertNotNull;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;


/**
 * 
 * The Class ProduitVersionAutorisePrevoyanceIndividuelleTest 
 *
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ProduitVersionAutorisePrevoyanceIndividuelleTest {
	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();
	
	/**
	 * Test niv certified type.
	 */
	@Test
	public void testProduitVersionAutorisePrevoyanceIndividuelle() {
		assertNotNull("wrong NivCertifiedType not null",ProduitVersionAutorisePrevoyanceIndividuelle.values());
	}
}
