/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.security;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.impl.DocumentationFacadeImplTest.MockUserContext;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.profile.RbbProfilingInterceptor;
import fr.ag2rlamondiale.trm.business.impl.TraceFacadeImpl;
import fr.ag2rlamondiale.trm.client.rest.ITraceRestClient;
import fr.ag2rlamondiale.trm.client.rest.impl.TraceRestClientImpl;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.InfoNavigateur;
import fr.ag2rlamondiale.trm.utils.MapperUtils;



/**
 * The Class RbbSecurityApplicationListenerTest.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = RbbSecurityApplicationListenerTest.class)
public class RbbSecurityApplicationListenerTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";

	@Autowired
    private RbbSecurityApplicationListener connexionListener;
	private UserContextHolder userContextHolder = mock(UserContextHolder.class);

    private InfoNavigateur infoNavigateur = mock(InfoNavigateur.class);
    private IContratFacade contratFacade = mock(IContratFacade.class);
    private ITraceRestClient traceRestClient = mock(TraceRestClientImpl.class);

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();
    
    @Bean
    InfoNavigateur infoNavigateur() {
        when(infoNavigateur.navInfo()).thenReturn("INFO NAVIGATEUR");
        return infoNavigateur;
    }
    @Bean
    RbbProfilingInterceptor profilingInterceptor() {
        return new RbbProfilingInterceptor();
    }
    
    @Bean
    TraceFacadeImpl traceFacade() {
        return new TraceFacadeImpl();
    }
	@Bean
    RbbSecurityApplicationListener rbbSecurityApplicationListener() {
        return new RbbSecurityApplicationListener();
    }
	
	@Bean
    ITraceRestClient traceRestClient() {
        when(traceRestClient.insert(any(TraceJson.class))).then(invocation -> {
            TraceJson traceJson = (TraceJson) invocation.getArguments()[0];
            assertEquals(CodeActionType.CQ_CONNEXION.name(), traceJson.getCodeAction());
            assertEquals(ID_GDI, traceJson.getIdGdi());
            assertEquals("CT CONTRAT_ERE_ID | ADH ADHERENTE_ID | CP COLLEGE_ID", traceJson.getZone1());
            return true;
        });

        return traceRestClient;
    }
	@Test
    public void test_Connexion_Event() throws Exception {
        Authentication authentication = buildAuthentication();
        AuthenticationSuccessEvent event = new AuthenticationSuccessEvent(authentication);
        connexionListener.onApplicationEvent(event);
        assertNotNull(event);
    }
	
	private Authentication buildAuthentication() {
        Authentication authentication = mock(Authentication.class);
        RbbUserDetails userDetails = rbbUserDetails();
        when(authentication.getPrincipal()).thenReturn(userDetails);
        return authentication;
    }
	
	private RbbUserDetails rbbUserDetails() {
        User user = new User(ID_GDI, "password", Collections.emptyList());
        return new RbbUserDetails(user, true);
    }
	
	@Bean
    UserContextHolder userContextHolder() {
        when(userContextHolder.get()).thenReturn(createUserContextERE());
        return userContextHolder;
    }
	
	 @Bean
	    MapperUtils mapperUtils() {
	        return new MapperUtils();
	    }

	    @Bean
	    RestTemplate restTemplate() {
	        return new RestTemplate();
	    }
	    
	    @Bean
	    IContratFacade contratFacade() {
	        try {
	            List<ContratHeader> contratsERE = new ArrayList<>();
	            ContratHeader contrat = new ContratHeader();
	            contrat.setId("CONTRAT_ERE_ID");
	            contrat.setIdAdherente("ADHERENTE_ID");
	            contrat.setIdCollege("COLLEGE_ID");
	            contratsERE.add(contrat);
	            when(contratFacade.rechercherContratsEre()).thenReturn(contratsERE);
	            when(contratFacade.rechercherContratsMdpro()).thenReturn(Collections.emptyList());
	        } catch (TechnicalException e) {
	            throw new RuntimeException(e);
	        }
	        return contratFacade;
	    }
	    
	    private UserContext createUserContextERE() {
	        MockUserContext userContext = new MockUserContext();
	        userContext.setIdGdi(ID_GDI);
	        userContext.setNumeroPersonneEre(NUM_PERS_ERE);
	        return userContext;
	    }
}
