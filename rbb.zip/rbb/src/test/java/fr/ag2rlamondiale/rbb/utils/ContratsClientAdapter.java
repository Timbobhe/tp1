package fr.ag2rlamondiale.rbb.utils;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratTechniquesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratTechnique;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import org.springframework.scheduling.annotation.AsyncResult;

import java.util.List;
import java.util.concurrent.Future;

public class ContratsClientAdapter implements IContratsClient {

    @Override
    public List<ContratHeaderDto> rechercherContratsPersonneV3(RechercherContratsDto rechercherContratsDto) throws TechnicalException {
        return null;
    }

    @Override
    public List<ContratHeaderDto> rechercherContratsRetraiteSupp(RechercherContratsDto rechercherContratsDto) throws TechnicalException {
        return null;
    }

    @Override
    public List<ContratHeaderDto> rechercherContratsEpargnePrevoyance(RechercherContratsDto rechercherContratsDto) throws TechnicalException {
        return null;
    }

    @Override
    public CompteGeneralesERE consulterCompteGeneralesERE(ConsulterCompteGeneralesEREDto dto) throws TechnicalException {
        return null;
    }

    @Override
    public void cacheEvictConsulterCompteGeneralesERE(ConsulterCompteGeneralesEREDto dto) {

    }

    @Override
    public Future<CompteGeneralesERE> consulterCompteGeneralesEREAsync(ConsulterCompteGeneralesEREDto dto) throws TechnicalException {
        return new AsyncResult<>(this.consulterCompteGeneralesERE(dto));
    }

    @Override
    public Future<ContratGeneral> consulterContratGeneralesAsync(ConsulterContratGeneralesDto dto) throws TechnicalException {
        return new AsyncResult<>(this.consulterContratGenerales(dto));
    }

    @Override
    public ContratTechnique consulterContratTechnique(ConsulterContratTechniquesDto dto) throws TechnicalException {
        return null;
    }

    @Override
    public Future<ContratTechnique> consulterContratTechniqueAsync(ConsulterContratTechniquesDto dto) throws TechnicalException {
        return new AsyncResult<>(this.consulterContratTechnique(dto));
    }

	@Override
	public ContratGeneral consulterContratGenerales(ConsulterContratGeneralesDto dto) throws TechnicalException {
		return null;
	}

	@Override
	public void forceCacheEvictRechercherContratsPersonne(RechercherContratsDto critere) {
		// TODO Auto-generated method stub
		
	}

}
