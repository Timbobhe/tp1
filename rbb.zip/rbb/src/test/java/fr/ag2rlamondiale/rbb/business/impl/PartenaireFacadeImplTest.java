package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.rest.IPartenaireRestClient;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.MettreAJourIdgdiTemporaireRequete;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.RechercherSousPartenaireRequete;

@RunWith(MockitoJUnitRunner.class)
public class PartenaireFacadeImplTest {

    @InjectMocks
    PartenaireFacadeImpl partenaireFacade;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IPartenaireRestClient partenaireRestClient;

    @Test
    public void findById() {
        when(partenaireRestClient.findById("")).thenReturn(new PartenaireJson());

        assertNotNull(partenaireFacade.findById(""));
    }

    @Test
    public void findSousPartenaire() {
        when(partenaireRestClient
                .findSousPartenaire(Matchers.any(RechercherSousPartenaireRequete.class)))
                        .thenReturn(new PartenaireJson());

        assertNotNull(partenaireFacade.findSousPartenaire("", null));
    }

    @Test
    public void updateIdgdiTemporaire() throws Exception {
        when(partenaireRestClient
                .updateIdgdiTemporaire(Matchers.any(MettreAJourIdgdiTemporaireRequete.class)))
                        .thenReturn(1);

        assertTrue(partenaireFacade.updateIdgdiTemporaire("", "", "", "").equals(1));
    }

    @Test
    public void findPartenaire() throws Exception {
        cas1();
        
        cas2();
    }

    private void cas1() throws Exception {
        when(partenaireRestClient.findById("p1")).thenReturn(new PartenaireJson());

        assertNull(partenaireFacade.findPartenaire(null, null, null));
        assertNotNull(partenaireFacade.findPartenaire("p1", null, null));

        when(partenaireRestClient
                .findSousPartenaire(Matchers.any(RechercherSousPartenaireRequete.class)))
                        .thenReturn(new PartenaireJson());
        when(contratFacade.rechercherContrats()).thenReturn(Arrays.asList(new ContratHeader()));

        assertNotNull(partenaireFacade.findPartenaire("p1", null, "numPP"));
    }

    private void cas2() throws Exception {
        when(partenaireRestClient.findById("p1")).thenReturn(null);
        when(partenaireRestClient.findById("p2")).thenReturn(null);

        assertNull(partenaireFacade.findPartenaire("p1", "p2", "numPP"));

        PartenaireJson part = new PartenaireJson();
        part.setCodePartenairePrincipal("p1");
        when(partenaireRestClient.findById("p2")).thenReturn(part);

        PartenaireJson resultat = partenaireFacade.findPartenaire("p1", "p2", "numPP");
        assertNotNull(resultat);
        assertEquals("p1", resultat.getCodePartenairePrincipal());

        part.setCodePartenairePrincipal("p2");
        when(partenaireRestClient.findById("p2")).thenReturn(part);

        assertNull(partenaireFacade.findPartenaire("p1", "p2", "numPP"));
    }
}
