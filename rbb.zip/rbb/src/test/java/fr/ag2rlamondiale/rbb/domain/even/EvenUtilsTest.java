/*
 * Cree le 10 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;

import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataEventJson;
import utils.data.DataTypeEvenementJson;
/**
 * The Class EvenUtilsTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class EvenUtilsTest {
	
	/* the evenUtils mock*/
	@InjectMocks
	private EvenUtils evenUtils;
	/* the evenements*/
	Collection<EvenementJson> evenements= new ArrayList<EvenementJson>();
	/* the typeEvenement*/
	TypeEvenementJson typeEvenement = new DataTypeEvenementJson().getDataTypeEvenementJson();
	/* the evenements*/
	List<EvenementJson> ListEvenementJson= new DataEventJson().getListDataEventJson();
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		EvenUtils maClasse = new EvenUtils();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testEvaluerEvenement() throws Exception{
		Boolean resultat = EvenUtils.pasEncorePresenteAujourdhui(evenements);
		assertNotNull("wrong null resultat",resultat);
	}
	@Test
	public void testDejaTraite() throws Exception{
		Boolean resultat = EvenUtils.dejaTraite(evenements);
		assertNotNull("wrong null resultat",resultat);
	}
	@Test
	public void testNeDepassePasNombreMaxDeclenchements() throws Exception{
		Boolean resultat = EvenUtils.neDepassePasNombreMaxDeclenchements(typeEvenement,ListEvenementJson);
		assertNotNull("wrong null resultat",resultat);
	}
	@Test
	public void testRespecteDelaiReactivation() throws Exception{
		Boolean resultat = EvenUtils.respecteDelaiReactivation(typeEvenement,evenements);
		assertNotNull("wrong null resultat",resultat);
	}
}
