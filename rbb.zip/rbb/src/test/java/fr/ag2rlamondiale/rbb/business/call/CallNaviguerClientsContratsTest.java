/*
 * Cree le 21 juillet. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.call;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.req.CritereRechercheContratDto;
import fr.ag2rlamondiale.epinlib.domain.resp.ListeClientsContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.service.INaviguerClientsContrats4Service;
import utils.ITestCallIService;
import utils.data.DataContratDto;
import utils.data.DataIdentifiantDto;
import utils.data.DataPersonnePhysiqueDto;
import utils.data.RandomData;

/**
 * The Class CallNaviguerClientsContratsTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CallNaviguerClientsContratsTest implements ITestCallIService{
	
	/** The naviguer clients contrats 4 service. */
	@Mock
	private INaviguerClientsContrats4Service naviguerClientsContrats4Service;
	
	/** The call naviguer clients contrats. */
	@InjectMocks
	private CallNaviguerClientsContrats callNaviguerClientsContrats;
	
	/** The id GDI. */
	private String idGDI = RandomData.getRandomStringSize10();
	
	/** The data personne physique dto. */
	private DataPersonnePhysiqueDto dataPersonnePhysiqueDto = new DataPersonnePhysiqueDto();
	
	/** The data contrat. */
	private DataContratDto dataContrat = new DataContratDto();
	
	/** The data identifiant dto. */
	private DataIdentifiantDto dataIdentifiantDto = new DataIdentifiantDto();
	
	/**
	 * Test call nullable.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNullable() throws Exception {
		mockNaviguerClientsContrats4ServiceCallReturnListeClientsContratDtoVide();
		ClientDto clientDto = callNaviguerClientsContrats.callNaviguerClientsContrats4(idGDI, dataPersonnePhysiqueDto.getPersonneDto());
		assertNull("wrong ClientDto not null",clientDto.getId());
	}
	
	/**
	 * Test call technical exception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = TechnicalException.class)
	public void testCallTechnicalException() throws Exception {
		mockNaviguerClientsContrats4ServiceReturnException(TechnicalException.class);
		callNaviguerClientsContrats.callNaviguerClientsContrats4(idGDI, dataPersonnePhysiqueDto.getPersonneDto());
	}
	
	/**
	 * Test call exception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = Exception.class)
	public void testCallException() throws TechnicalException {
		mockNaviguerClientsContrats4ServiceReturnException(Exception.class);
		callNaviguerClientsContrats.callNaviguerClientsContrats4(idGDI, dataPersonnePhysiqueDto.getPersonneDto());
		
	}
	
	/**
	 * Test call not null.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNotNull() throws Exception {
		mockNaviguerClientsContrats4ServiceCall();
		ClientDto clientDto = callNaviguerClientsContrats.callNaviguerClientsContrats4(idGDI, dataPersonnePhysiqueDto.getPersonneDto());
		assertNotNull("wrong ClientDto id null",clientDto.getId());
		assertNotNull("wrong ClientDto id null",clientDto.getListeContrat());

	}

	/**
	 * Mock NaviguerClientsContrats4 service.
	 *
	 * @param class1 the class 1
	 * @throws TechnicalException the technical exception
	 */
	@SuppressWarnings("unchecked")
	private void mockNaviguerClientsContrats4ServiceReturnException(Class<? extends Throwable> class1) throws TechnicalException {
		when(naviguerClientsContrats4Service.call(any(CritereRechercheContratDto.class))).thenThrow(class1);
	}
	
	
	/**
	 * Mock naviguer clients contrats 4 service call return liste clients contrat dto vide.
	 *
	 * @throws TechnicalException the technical exception
	 */
	private void mockNaviguerClientsContrats4ServiceCallReturnListeClientsContratDtoVide() throws TechnicalException {
		when(naviguerClientsContrats4Service.call(any(CritereRechercheContratDto.class))).thenAnswer(new Answer<ListeClientsContratDto>() {

			@Override
			public ListeClientsContratDto answer(InvocationOnMock invocation) throws Throwable {
	
				ListeClientsContratDto ListeClientsContratDto = new ListeClientsContratDto();
				return ListeClientsContratDto;
				
			}
		});
	}
	
	/**
	 * Mock naviguer clients contrats 4 service call.
	 *
	 * @throws TechnicalException the technical exception
	 */
	private void mockNaviguerClientsContrats4ServiceCall() throws TechnicalException {
		when(naviguerClientsContrats4Service.call(any(CritereRechercheContratDto.class)))
				.thenAnswer(new Answer<ListeClientsContratDto>() {

					@Override
					public ListeClientsContratDto answer(InvocationOnMock invocation) throws Throwable {
						
						ListeClientsContratDto ListeClientsContratDto = new ListeClientsContratDto();
						ClientDto clientDto = new ClientDto();
						List<ContratDto> listeContrat = new ArrayList<>();
						clientDto.setId(dataIdentifiantDto.getIdentifiantDto());
						listeContrat.add(dataContrat.getContratDto("RC01V01"));
						clientDto.setListeContrat(listeContrat);
						ListeClientsContratDto.getListClients().add(clientDto );
						return ListeClientsContratDto;
					}
				});
	}
}
