/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class RbbSupplierLibServiceTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class RbbSupplierLibServiceTest {
	/**The ApiConfig. */
	@Spy
	private MockSupplierLibService mockSupplierLibService;
	
	/**The rbbSupplierLibService. */
	@InjectMocks
	private RbbSupplierLibService rbbSupplierLibService;
	
	@Test
	public void testBean() {
		new BeanTester().testBean(RbbSupplierLibService.class);
	}
	
	/**
	 * Test  Get LibelleAppli.
	 */
	@Test
	public void testGetLibelleAppli() {
		assertNotNull("wrong result null",rbbSupplierLibService.getLibelleAppli());
		assertEquals(mockSupplierLibService.getLibelleAppli(), rbbSupplierLibService.getLibelleAppli());
	}
	
	/**
	 * Test  Get CodeCassiniAppli.
	 */
	@Test
	public void testGetCodeCassiniAppli() {
		assertNull("wrong result null",rbbSupplierLibService.getCodeCassiniAppli());
	}
	
	/**
	 * Test  Get UrlFront.
	 */
	@Test
	public void testGetUrlFront(){
		assertNull("wrong result null",rbbSupplierLibService.getUrlFront());
	}
	
	/**
	 * Test  Get CodeApplicationEmettriceForUniversign.
	 */
	@Test
	public void testGetCodeApplicationEmettriceForUniversign(){
		assertNull("wrong result null",rbbSupplierLibService.getCodeApplicationEmettriceForUniversign());
	}
	
}
