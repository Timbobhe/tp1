package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.dto.contrat.ContratClientDto;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContratsRestControllerTest {

    public static final String EXPECTED = "blabla";
    @Mock
    IContratFacade contratFacadeMock;

    @InjectMocks
    ContratsRestController sut;

    @Test
    public void should_get_contrats() throws TechnicalException {
        when(contratFacadeMock.rechercherContrats()).thenReturn(new ArrayList<>());
        List<ContratClientDto> expected = sut.getContrats();
        assertNotNull(expected);
    }
}
