package fr.ag2rlamondiale.rbb;

import fr.ag2rlamondiale.trm.ISupplierLibService;

public class MockSupplierLibService implements ISupplierLibService {
    @Override
    public String getCodeCassiniAppli() {
        return "A1549";
    }

    @Override
    public String getLibelleAppli() {
        return "ESPACE MDPRO RIB";
    }

    @Override
    public String getUrlFront() {
        return "http://localhost:4200";
    }

	@Override
	public String getCodeApplicationEmettriceForUniversign() {
		return "A1573";
	}
}
