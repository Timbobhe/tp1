/*
 * Cree le 21 jullet 2021.
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 *
 * @author emir
 *
 *
 */
package fr.ag2rlamondiale.rbb.utils;

import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;

/**
 * The Class ConstantesTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ConstantesTest {

	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();

	/**
	 * Test cconstructors.
	 */
	@Test
	public void testCconstructors() {
		assertPojoMethodsFor(Constantes.class).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test enum.
	 */
	@Test
	public void testEnum() {
		assertNotNull("wrong string CODE_APP_8X ", Constantes.CODE_APP_8X);
		assertNotNull("wrong string CODE_SYS_INFO_EGESPER_MDPRO", Constantes.CODE_SYS_INFO_EGESPER_MDPRO);
		assertNotNull("wrong string CODE_APPLI_EGESPER_MDPRO", Constantes.CODE_APPLI_EGESPER_MDPRO);
		assertNotNull("wrong string UTILISATEUR_NON_TROUVE", Constantes.UTILISATEUR_NON_TROUVE);
		assertNotNull("wrong string CODE_APP_REPERE", Constantes.CODE_APP_REPERE);
		assertNotNull("wrong string PREFIX_CM", Constantes.PREFIX_CM);
		assertNotNull("wrong string PRINCIPAL", Constantes.PRINCIPAL);
		assertNotNull("wrong string SECONDAIRE", Constantes.SECONDAIRE);
		assertNotNull("wrong enum stat_aut", Constantes.stat_aut.values());
		assertNotNull("wrong enum contrat_retraite_exclu", Constantes.contrat_retraite_exclu.values());

	}
}
