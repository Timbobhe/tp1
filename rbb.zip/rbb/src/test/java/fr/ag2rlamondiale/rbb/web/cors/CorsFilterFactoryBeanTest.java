/*
 * Cree le 18 mai 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.web.cors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.filter.CorsFilter;

import utils.data.RandomData;

/**
 * The Class CorsFilterFactoryBeanTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CorsFilterFactoryBeanTest {
	
	/** The allowed origins. */
	String allowedOrigins ;
	
	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();
	
	/** The cors filter factory bean. */
	@InjectMocks @Spy
	private CorsFilterFactoryBean corsFilterFactoryBean;
	
	/**
	 * Sets the up.
	 */
	@Before
	public void setUp() {
		allowedOrigins = RandomData.getRandomStringSize10();
	}
	
	/**
	 * Test get object.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetObject() throws Exception {
		ReflectionTestUtils.setField(corsFilterFactoryBean, "allowedOrigins",allowedOrigins);
		CorsFilter value = corsFilterFactoryBean.getObject();
		assertNotNull("wrong not null",value);
	}

	/**
	 * Test get object allowed origins.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetObjectAllowedOrigins() throws Exception {
		ReflectionTestUtils.setField(corsFilterFactoryBean, "allowedOrigins","");
		CorsFilter value = corsFilterFactoryBean.getObject();
		assertNotNull("wrong not null",value);
	}

	
	/**
	 * Test get object type.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testGetObjectType() throws Exception {
		Class<?> value = corsFilterFactoryBean.getObjectType();
		assertEquals("wrong getObjectType",value.getName() ,  CorsFilter.class.getName());
	}

	/**
	 * Test is singleton.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testIsSingleton() throws Exception {
		assertTrue("wrong isSingleton true",corsFilterFactoryBean.isSingleton());
	}

	/**
	 * Test set allowed origins.
	 *
	 * @throws Exception the exception
	 */
	@Test(expected = Test.None.class /* no exception expected */)
	public void testSetAllowedOrigins() throws Exception {
		corsFilterFactoryBean.setAllowedOrigins(allowedOrigins);
	}

}
