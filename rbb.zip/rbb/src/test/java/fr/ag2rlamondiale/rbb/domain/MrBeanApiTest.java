package fr.ag2rlamondiale.rbb.domain;

import fr.ag2rlamondiale.rbb.domain.even.AbstractEvenGenerator;
import fr.ag2rlamondiale.rbb.domain.even.TriggeringResult;
import fr.ag2rlamondiale.rbb.domain.even.TriggeringResults;
import fr.ag2rlamondiale.rbb.dto.contrat.ContratClientDto;
import fr.ag2rlamondiale.rbb.ApiConfig;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.testing.MrBeanTester;
import org.junit.Test;

import java.util.Collection;
import java.util.List;

import static org.junit.Assert.*;

public class MrBeanApiTest {

    @Test
    public void test_TriggeringResult() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addFactory(AbstractEvenGenerator.class, () -> new AbstractEvenGenerator() {
            @Override
            public EvenementJson generateNextEven(TriggeringResult result) {
                return null;
            }

            @Override
            public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                          Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {

            }
        });
        beanTester.fullTester(TriggeringResult.class);
        assertNotNull(beanTester);
    }

    private MrBeanTester newMrBeanTester() {
        MrBeanTester beanTester = new MrBeanTester();
       beanTester.setClassPredicate(beanTester.getClassPredicate().and(clazz -> !clazz.getSimpleName().endsWith("MapperImpl")));

        return beanTester;
    }

}
