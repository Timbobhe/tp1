/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.enumeration;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class CodeActionTypeTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CodeActionTypeTest {
	
	/**
	 * Test enum.
	 */
	@Test
	public void testEnum() {

		assertNotNull("wrong enum API_ACCESSIBILITE_FCT ", CodeActionType.API_ACCESSIBILITE_FCT);
		assertNotNull("wrong enum API_CACHE", CodeActionType.API_CACHE);
		assertNotNull("wrong enum API_COMPARTIMENTS_GET", CodeActionType.API_COMPARTIMENTS_GET);
		assertNotNull("wrong enum API_CONTACT_RECLA_CREATE ", CodeActionType.API_CONTACT_RECLA_CREATE);
		assertNotNull("wrong enum API_CONTACT_RECLA_START", CodeActionType.API_CONTACT_RECLA_START);
		assertNotNull("wrong enum API_CONTRATS_ASSURES", CodeActionType.API_CONTRATS_ASSURES);
		assertNotNull("wrong enum API_CONTRATS_COMPLETS ", CodeActionType.API_CONTRATS_COMPLETS);
		assertNotNull("wrong enum API_CONTRATS_PLUS_RECENTS", CodeActionType.API_CONTRATS_PLUS_RECENTS);
		assertNotNull("wrong enum API_COORDONNEES_BANCAIRES_GET", CodeActionType.API_COORDONNEES_BANCAIRES_GET);
		assertNotNull("wrong enum API_COORDONNEES_BANCAIRES_POST ", CodeActionType.API_COORDONNEES_BANCAIRES_POST);
		assertNotNull("wrong enum API_COORDONNEES_CLIENT_CLEARCACHE", CodeActionType.API_COORDONNEES_CLIENT_CLEARCACHE);
		assertNotNull("wrong enum API_COORDONNEES_CLIENT_GET", CodeActionType.API_COORDONNEES_CLIENT_GET);
		assertNotNull("wrong enum API_COORDONNEES_CLIENT_UPDATE ", CodeActionType.API_COORDONNEES_CLIENT_UPDATE);
		assertNotNull("wrong enum API_COORDONNEES_CLIENT_VALIDATE", CodeActionType.API_COORDONNEES_CLIENT_VALIDATE);
		assertNotNull("wrong enum API_CREATE_PIECE_IDENTITE", CodeActionType.API_CREATE_PIECE_IDENTITE);
		assertNotNull("wrong enum API_DEM_SIGELEC_DELETE ", CodeActionType.API_DEM_SIGELEC_DELETE);
		assertNotNull("wrong enum API_DEM_SIGELEC_ENCOURS_GET", CodeActionType.API_DEM_SIGELEC_ENCOURS_GET);
		assertNotNull("wrong enum API_DOCUMENT_DOWNLOAD", CodeActionType.API_DOCUMENT_DOWNLOAD);
		assertNotNull("wrong enum API_DOCUMENT_NIF_RECHERCHER ", CodeActionType.API_DOCUMENT_NIF_RECHERCHER);
		assertNotNull("wrong enum API_DOCUMENT_RECHERCHER", CodeActionType.API_DOCUMENT_RECHERCHER);
		assertNotNull("wrong enum API_DOCUMENT_VERSEMENT_RECHERCHER", CodeActionType.API_DOCUMENT_VERSEMENT_RECHERCHER);
		assertNotNull("wrong enum API_DOCUMENTS_ERE_GET ", CodeActionType.API_DOCUMENTS_ERE_GET);
		assertNotNull("wrong enum API_DOCUMENTS_MDPRO_GET", CodeActionType.API_DOCUMENTS_MDPRO_GET);
		assertNotNull("wrong enum API_EVENEMENTS_CANCEL", CodeActionType.API_EVENEMENTS_CANCEL);
		assertNotNull("wrong enum API_EVENEMENTS_NEXT ", CodeActionType.API_EVENEMENTS_NEXT);
		assertNotNull("wrong enum API_EVENEMENTS_TERMINATE", CodeActionType.API_EVENEMENTS_TERMINATE);
		assertNotNull("wrong enum API_EVENEMENTS_UPDATE", CodeActionType.API_EVENEMENTS_UPDATE);
		assertNotNull("wrong enum API_GESTION_FIN ", CodeActionType.API_GESTION_FIN);
		assertNotNull("wrong enum API_GESTION_FIN_ACTUELLE_COMPARTIMENT", CodeActionType.API_GESTION_FIN_ACTUELLE_COMPARTIMENT);
		assertNotNull("wrong enum API_GESTION_FIN_ACTUELLE_CONTRAT", CodeActionType.API_GESTION_FIN_ACTUELLE_CONTRAT);
		
		assertNotNull("wrong enum API_GESTION_FIN_SUPPORTS_COMPARTIMENT ", CodeActionType.API_GESTION_FIN_SUPPORTS_COMPARTIMENT);
		assertNotNull("wrong enum API_GESTION_FIN_SUPPORTS_CONTRAT", CodeActionType.API_GESTION_FIN_SUPPORTS_CONTRAT);
		assertNotNull("wrong enum API_INFOSCLIENT_GET", CodeActionType.API_INFOSCLIENT_GET);
		assertNotNull("wrong enum API_MATCH_ACCOUNT ", CodeActionType.API_MATCH_ACCOUNT);
		assertNotNull("wrong enum API_ONBOARDING_START", CodeActionType.API_ONBOARDING_START);
		assertNotNull("wrong enum API_ONBOARDING_TERMINATE", CodeActionType.API_ONBOARDING_TERMINATE);
		assertNotNull("wrong enum API_PARCOURSCLIENT_ENCOURS ", CodeActionType.API_PARCOURSCLIENT_ENCOURS);
		assertNotNull("wrong enum API_PREVALIDATE_PIECE_IDENTITE", CodeActionType.API_PREVALIDATE_PIECE_IDENTITE);
		assertNotNull("wrong enum API_QAD_START", CodeActionType.API_QAD_START);
		assertNotNull("wrong enum API_TRACKINGINFO_GET ", CodeActionType.API_TRACKINGINFO_GET);
		
	}
}
