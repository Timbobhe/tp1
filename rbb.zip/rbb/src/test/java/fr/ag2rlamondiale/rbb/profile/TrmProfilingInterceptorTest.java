package fr.ag2rlamondiale.rbb.profile;

import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.trm.business.ITraceFacade;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;

@Configuration
@EnableAspectJAutoProxy
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TrmProfilingInterceptorTest.class)
public class TrmProfilingInterceptorTest {

    @Autowired
    SampleService sampleService;

    @Autowired
    RbbProfilingInterceptor trmProfilingInterceptor;


    @Bean
    ITraceFacade traceFacade() {
        return Mockito.mock(ITraceFacade.class);
    }

    @Bean
    SampleService sampleService() {
        return new SampleService();
    }

    @Bean
    RbbProfilingInterceptor trmProfilingInterceptor() {
        return Mockito.spy(new RbbProfilingInterceptor());
    }

    @Test
    public void test_profile() throws Throwable {
        Mockito.reset(trmProfilingInterceptor);
        sampleService.hello();
        verify(trmProfilingInterceptor).profilingAroundAdvice(any(ProceedingJoinPoint.class), eq(CodeActionType.API_ACCESSIBILITE_FCT));
    }

    @Test
    public void test_profile_with_exception() throws Throwable {
        Mockito.reset(trmProfilingInterceptor);
        try {
            sampleService.helloFailed();
            fail();
        } catch (Exception ignore) {
        }
        verify(trmProfilingInterceptor).profilingAroundAdvice(any(ProceedingJoinPoint.class), eq(CodeActionType.API_ACCESSIBILITE_FCT));
    }
}
