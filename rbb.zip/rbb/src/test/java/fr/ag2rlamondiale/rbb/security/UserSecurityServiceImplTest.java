package fr.ag2rlamondiale.rbb.security;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.exception.WSSecurityException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserSecurityServiceImplTest {

    @Spy
    private UserSecurityContext securityContext;

    @Spy
    private UserContextHolder userContextHolder;

    @Mock
    private IContratFacade contratFacade;

    @InjectMocks
    UserSecurityServiceImpl userSecurityService;

    @Before
    public void init() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");

        when(userContextHolder.get()).thenReturn(userContext);
    }

    private void cas1() {
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(securityContext.isContextActive()).thenReturn(false);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas2() {
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(securityContext.isContextActive()).thenReturn(true);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(true);
        when(userContextHolder.get()).thenReturn(userContext);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas3() throws NoSuchMethodException, SecurityException {
        JoinPoint joinPoint = mock(JoinPoint.class);

        when(securityContext.isContextActive()).thenReturn(true);
        Set<String> set = new HashSet<>();
        set.add("arg");
        when(securityContext.getIdAssures()).thenReturn(set);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(false);
        when(userContextHolder.get()).thenReturn(userContext);
        MethodSignature signature = mock(MethodSignature.class);
        when(joinPoint.getSignature()).thenReturn(signature);
        Class[] cArg = new Class[1];
        cArg[0] = String.class;
        Method testMethod = this.getClass().getMethod("testMethod", cArg);
        when(signature.getMethod()).thenReturn(testMethod);
        ISecurityParamAccess security = mock(ISecurityParamAccess.class);
        Object[] args = Arrays.asList("arg", security).toArray();
        when(joinPoint.getArgs()).thenReturn(args);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas4() throws NoSuchMethodException, SecurityException {
        JoinPoint joinPoint = mock(JoinPoint.class);

        when(securityContext.isContextActive()).thenReturn(true);
        Set<String> set = new HashSet<>();
        set.add("IDASSURE");
        when(securityContext.getIdAssures()).thenReturn(set);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(false);
        when(userContextHolder.get()).thenReturn(userContext);
        MethodSignature signature = mock(MethodSignature.class);
        when(joinPoint.getSignature()).thenReturn(signature);
        Class[] cArg = new Class[1];
        cArg[0] = String.class;
        Method testMethod = this.getClass().getMethod("testMethod", cArg);
        when(signature.getMethod()).thenReturn(testMethod);
        ISecurityParamAccess security = mock(ISecurityParamAccess.class);
        Object[] args = Arrays.asList(security).toArray();
        when(joinPoint.getArgs()).thenReturn(args);
        when(security.secureForIdentifiantAssure()).thenReturn("IDASSURE");
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    // Exception Test
    private void cas1Fail() throws Exception {
        JoinPoint joinPoint = mock(JoinPoint.class);

        when(securityContext.isContextActive()).thenReturn(true);
        Set<String> set = new HashSet<>();
        set.add("IDASSURE");
        when(securityContext.getIdAssures()).thenReturn(set);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(false);
        when(userContextHolder.get()).thenReturn(userContext);
        MethodSignature signature = mock(MethodSignature.class);
        when(joinPoint.getSignature()).thenReturn(signature);
        Class[] cArg = new Class[1];
        cArg[0] = String.class;
        Method testMethod = this.getClass().getMethod("testMethodException", cArg);
        when(signature.getMethod()).thenReturn(testMethod);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    @Test
    public void isAuthorized() throws NoSuchMethodException, SecurityException {
        cas1();
        cas2();
        cas3();
        cas4();
    }

    @Test(expected = WSSecurityException.class)
    public void isAuthorizedFail( ) throws Exception {
        cas1Fail();
    }
    
        
    @Test
    public void initSecurityContext() throws Exception {
        init();
        PersonnePhysique personne = createPersonne();
        ContratHeader contrat = new ContratHeader();
        contrat.setCodeSilo(CodeSiloType.ERE);
        contrat.setId("id");
        contrat.setIdentifiantAssure("idAssure");
        contrat.setAffichageType(AffichageType.NORMAL);
        when(contratFacade.rechercherContrats()).thenReturn(Arrays.asList(contrat));
        userSecurityService.initSecurityContext("idGdi", personne);
        
        assertTrue("idGdi".equals(securityContext.getIdGdi()));
        assertTrue("idGdi".equals(userContextHolder.get().getIdGdi()));
        assertTrue("Nom".equals(userContextHolder.get().getNom()));
        assertTrue("Prenom".equals(userContextHolder.get().getPrenom()));
        assertTrue("NumERE".equals(securityContext.getNumeroPersonneEre()));
        assertTrue("NumERE".equals(userContextHolder.get().getNumeroPersonneEre()));
        assertTrue("NumMDP".equals(securityContext.getNumeroPersonneMdpro()));
        assertTrue("NumMDP".equals(userContextHolder.get().getNumeroPersonneMdpro()));
        assertTrue("Civilite".equals(userContextHolder.get().getCivilite()));
        assertEquals(1,securityContext.getIdContrats().size());
        assertEquals(1,securityContext.getIdAssures().size());
        assertTrue(securityContext.isContextActive());
    }

    private PersonnePhysique createPersonne() {
        PersonnePhysique personne = new PersonnePhysique();
        personne.setNom("Nom");
        personne.setPrenom("Prenom");
        personne.setNumeroPersonneEre("NumERE");
        personne.setNumeroPersonneMdpro("NumMDP");
        personne.setCivilite("Civilite");
        return personne;
    }

    @Test
    public void initSecurityContext1() throws Exception {
        UserTestManager userTestManager = new UserTestManager("idGdi", "NumERE", "NumMDP");

        userTestManager.setPersonnePhysique(createPersonne());
        userSecurityService.initSecurityContext(userTestManager);

        assertTrue("idGdi".equals(securityContext.getIdGdi()));
        assertTrue("idGdi".equals(userContextHolder.get().getIdGdi()));
        assertTrue("NumERE".equals(securityContext.getNumeroPersonneEre()));
        assertTrue("NumERE".equals(userContextHolder.get().getNumeroPersonneEre()));
        assertTrue("NumMDP".equals(securityContext.getNumeroPersonneMdpro()));
        assertTrue("NumMDP".equals(userContextHolder.get().getNumeroPersonneMdpro()));
        assertTrue(securityContext.isContextActive());
    }
    
    
    public void testMethod(@SecuredParam(paramType = SecurityParamType.IDASSURE) String s) {

    }

    public void testMethodException(String s) {

    }

}
