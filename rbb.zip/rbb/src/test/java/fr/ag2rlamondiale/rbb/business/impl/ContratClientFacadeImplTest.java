/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.epinlib.service.INaviguerClientsContrats4Service;
import fr.ag2rlamondiale.rbb.business.IVerifierEligibiliteFacade;
import fr.ag2rlamondiale.rbb.business.call.CallNaviguerClientsContrats;
import fr.ag2rlamondiale.rbb.business.call.CallRechPersPhysClient;
import fr.ag2rlamondiale.rbb.business.call.CallRechercherHabiliPers;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.MockUserContext;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import utils.data.DataClientDto;
import utils.data.DataContratDto;
import utils.data.DataListePersPhysDto;
import utils.data.RandomData;

/**
 * The Class RbbSupplierRibServiceImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContratClientFacadeImplTest {
	
	@InjectMocks
	ContratClientFacadeImpl contratClientFacadeImpl;
	
	@Mock
    private IContratsClient contratClient;
	
	@Mock
	private IVerifierEligibiliteFacade verifierEligibiliteFacadeImpl;
	
	@InjectMocks
    RechercherHabiliFacadeImpl habiliFacade;
	
	@Mock
	CallNaviguerClientsContrats callNaviguerClientsContrats;
	
	/** The naviguer clients contrats 4 service. */
	@Mock
	private INaviguerClientsContrats4Service naviguerClientsContrats4Service;
	
	private static final String IDGDI = "IDGDI";
    private static final String NUMPP = "NUMPP";

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IRechercherHabiliPersClient client;
    
    @Mock
    private CallRechPersPhysClient callRechPersPhysClient8;

    @Mock
	CallRechercherHabiliPers callRechercherHabiliPers;
    
	RechercherContratsDto critere = new RechercherContratsDto();
	
	DataListePersPhysDto dataListePersPhysDto= new DataListePersPhysDto();
	
	DataContratDto DataContratDto = new DataContratDto();
	
	/** The liste pers phys dto. */
	private ListePersPhysDto listePersPhysDto;
	
	String rechercherHabiliPersResponseDto = RandomData.getRandomStringSize10();

    private static PersonnePhysique buildPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setCivilite("Monsieur");
        pp.setIdGdi(IDGDI);
        pp.setNom("Nom");
        pp.setNumeroPersonneEre(NUMPP);
        pp.setNumeroPersonneMdpro(NUMPP);
        pp.setPrenom("Prenom");
        return pp;
    }
    
    private UserContext createUserContextMultiEquipe(String ere, String mdPro) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(ere);
        userContext.setNumeroPersonneMdpro(mdPro);
        userContext.setIdGdi("IDGDI");
        Partenaire part = new Partenaire();
        part.setCodePartenaire("49504");
        userContext.setPartenaire(part);
        return userContext;
    }
    
    private static PersonnePhysiqueDto buildPersonnePhysiqueDTO() {
		PersonnePhysiqueDto pp = new PersonnePhysiqueDto();
        pp.setNom("Nom");
        pp.setPrenom("Prenom");
        return pp;
    }
	/** The data client dto. */
	private DataClientDto dataClientDto = new DataClientDto();

	/** The client dto. */
	private ClientDto clientDto;
	
	@Before
	 public void init() {
		clientDto = dataClientDto.getClientDto();
	}
	
    @Test
    public void testGetClientIdGdi() {
        PersonnePhysique out = buildPersonnePhysique();
        when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("ere", "mdpro"));
        assertEquals(out.getIdGdi(), contratClientFacadeImpl.getClientIdGdi());
    }
    
    @Test
    public void testGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		listePP.add(buildPersonnePhysiqueDTO());
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		assertNotNull(contratClientFacadeImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test(expected = EligibiliteException.class)
    public void testEmptyListGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		assertNotNull(contratClientFacadeImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test(expected = EligibiliteException.class)
    public void testEligibiliteExceptionGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenThrow(new TechnicalException());
		assertNotNull(contratClientFacadeImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test
    public void testmappingContratsDtoToContratsHeaderDtoFullData() {
    	List<ContratHeaderDto> contratsHeaderDto = new ArrayList<ContratHeaderDto>();
		 when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("ere", "mdpro"));
        Assert.assertNotEquals(contratsHeaderDto, contratClientFacadeImpl.mappingContratsDtoToContratsHeaderDto(clientDto.getListeContrat()));
    }
    
    @Test
    public void testmappingContratsDtoToContratsHeaderDto() {
    	List<ContratHeaderDto> contratsHeaderDto = new ArrayList<ContratHeaderDto>();
    	List<ContratDto> contratsDto = new ArrayList<ContratDto>();
        Assert.assertEquals(contratsHeaderDto, contratClientFacadeImpl.mappingContratsDtoToContratsHeaderDto(contratsDto));
    }
	
    @Test
    public void testGetListContratsByUserHolder() throws EligibiliteException, TechnicalException {
		 when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("ere", "mdpro"));
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn("P10000");
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		listePP.add(buildPersonnePhysiqueDTO());
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		Mockito.doReturn(clientDto).when(callNaviguerClientsContrats).callNaviguerClientsContrats4(anyString(),any(PersonnePhysiqueDto.class));
		List<ContratHeaderDto> contratsHeaderDto = new ArrayList<ContratHeaderDto>();
		Assert.assertEquals(contratsHeaderDto, 	contratClientFacadeImpl.getListContratsByUserHolder());
    }
    
    @Test
    public void testRechercherContratsEpargnePrevoyance() throws TechnicalException, EligibiliteException{
    	when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("P4317436", "P2224552"));
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		listePersPhysDto = dataListePersPhysDto.getListePersPhysDto();
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(listePersPhysDto);
        Assert.assertNotNull("null", contratClientFacadeImpl.rechercherContratsEpargnePrevoyance(critere));
    }
	
    @Test
    public void testRechercherContratsPersonne() throws TechnicalException, EligibiliteException{
        when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("P4317436", "P2224552"));
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		listePersPhysDto = dataListePersPhysDto.getListePersPhysDto();
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(listePersPhysDto);
        Assert.assertNotNull("null", contratClientFacadeImpl.rechercherContratsPersonne(critere));
    }
    
    @Test
    public void testRechercherContratsRetraiteSuppEpargnePrevoyance() throws TechnicalException, EligibiliteException{
    	when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("P4317436", "P2224552"));
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		listePersPhysDto = dataListePersPhysDto.getListePersPhysDto();
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(listePersPhysDto);
        Assert.assertNotNull("null", contratClientFacadeImpl.rechercherContratsRetraiteSuppEpargnePrevoyance(critere));
    }
}
