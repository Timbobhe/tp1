/*
 * Cree le 29 octobre 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @emir JEMMALI
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import utils.data.DataListContratHeaderDto;

/**
 * 
 * The class VerifierEligibiliteFacadeImplTest
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class VerifierEligibiliteFacadeImplTest {
	
	@InjectMocks
	private VerifierEligibiliteFacadeImpl verifierEligibiliteFacadeImpl;
	
	private static List<ContratHeaderDto> listeContrat1 =  new ArrayList<>();
	private static List<ContratHeaderDto> listeContrat2 =  new ArrayList<>();
	static ContratHeaderDto c1, c2, c3, c4;
	
	/**
	 * Sets the up.
	 */
	
	 @BeforeClass
	public static void setUp() {
		 
	DataListContratHeaderDto dataListContratHeaderDto = new DataListContratHeaderDto();
	
	c1 = new ContratHeaderDto();
    c2 = new ContratHeaderDto();
    c3 = new ContratHeaderDto();
    c4 = new ContratHeaderDto();
    
    c1.setTypeContrat("RC01");    c1.setNumGenContrat("V01");  c1.setId("011");
    c2.setTypeContrat("RC03");    c2.setNumGenContrat("V01");	c2.setId("021");
    c3.setTypeContrat("TE15");    c3.setNumGenContrat("V01");	c3.setId("031");
    c4.setTypeContrat(" ");	c4.setId("041");
    
    listeContrat1.add(c1);
    listeContrat1.add(c2);
    listeContrat1.add(c3);
    listeContrat1.add(c4);
    
    listeContrat2.addAll(dataListContratHeaderDto.getListContratHeaderDto());   
	}  
	
	@Test
	 public void TestverifierEligibiliteVersionAutorise() throws EligibiliteException {		
		Assert.assertNotEquals(listeContrat2, verifierEligibiliteFacadeImpl.verifierEligibiliteVersionAutorise(listeContrat1));
	}
	
	 @Test(expected = EligibiliteException.class)
	 public void TestEligibiliteExceptionVerifierEligibiliteVersionAutorise() throws EligibiliteException {		
		 assertNotNull(verifierEligibiliteFacadeImpl.verifierEligibiliteVersionAutorise(listeContrat2));
	}
	
	@Test
	 public void TestcontroleProduitVersion() {		
		Assert.assertNotEquals(false, verifierEligibiliteFacadeImpl.controleProduitVersion(c1));
	}
	
}

