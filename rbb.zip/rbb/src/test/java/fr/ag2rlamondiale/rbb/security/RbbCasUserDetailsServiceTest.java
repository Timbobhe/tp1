package fr.ag2rlamondiale.rbb.security;

import com.ag2r.common.security.BundleRolesList;
import com.ag2r.common.security.RolesListFactory;
import com.ag2r.common.security.habilitations.mapping.SecurityDomainManager;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.impl.BlocageFacadeImpl;
import fr.ag2rlamondiale.rbb.business.impl.ClientFacadeImpl;
import fr.ag2rlamondiale.rbb.business.impl.PartenaireFacadeImpl;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.utils.MockUserContext;
import fr.ag2rlamondiale.trm.cache.ITrackUserCache;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapper;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.jasig.cas.client.authentication.AttributePrincipalImpl;
import org.jasig.cas.client.validation.AssertionImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RbbCasUserDetailsServiceTest {

    @InjectMocks
    RbbCasUserDetailsService rbbCasUserDetailsService = new RbbCasUserDetailsService(new String[] {"roles"});

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    UserSecurityServiceImpl userSecurityService;

    @Mock
    ClientFacadeImpl clientFacade;

    @Mock
    PartenaireFacadeImpl partenaireFacade;

    @Mock
    BlocageFacadeImpl blocageFacade;
    
    @Mock
    IContratFacade contratFacade;

    @Mock
    PartenaireMapper partenaireMapper;

    @Mock
    ITrackUserCache trackUserCache;


    @Before
    public void init() throws Exception {
        final UserContext userContextERE = createUserContextERE(MOCKDATA);
        when(userContextHolder.get()).thenReturn(userContextERE);
        when(userSecurityService.isAuthorized(any(), any())).thenReturn(true);
        when(clientFacade.rechercherPersonnePhysiqueParIdGdi(anyString())).thenReturn(createPersonnePhysique());
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString()))
                .thenReturn(createPersonnePhysique());
        
        new RolesListFactory().setFactory(new BundleRolesList());
        assertNotNull(RolesListFactory.getCurrentFactory());

        ReflectionTestUtils.setField(SecurityDomainManager.class, "instance", new SecurityDomainManager());
        assertNotNull(SecurityDomainManager.getInstance());

        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            return info;
        });
        when(partenaireFacade.updateIdgdiTemporaire(anyString(), anyString(), anyString(), anyString())).thenReturn(1);
        when(partenaireMapper.map(any())).thenReturn(new Partenaire());
        when(contratFacade.rechercherContrats()).thenReturn(createContrats());
    }
    
    private List<ContratHeader> createContrats(){
        ContratHeader contrat = new ContratHeader();
       return  Arrays.asList(contrat);
    }

    private UserContext createUserContextERE(String numPP) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setPartenaire(new Partenaire());
        return userContext;
    }
    
    private PersonnePhysique createPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setIdGdi("IDGDI");
        pp.setNom("NOM");
        pp.setPrenom("PRENOM");
        pp.setNumeroPersonneEre("NUMERE");
        pp.setNumeroPersonneMdpro("NUMMDPRO");
        return pp;
    }

    @Test
    public void loadUserDetails() {
    	UserDetails userDetails;
       // UserDetails userDetails = rbbCasUserDetailsService.loadUserDetails(cas1());
        //assertFalse(userDetails.isAccountNonLocked());
        //userDetails = rbbCasUserDetailsService.loadUserDetails(cas2());
        //assertTrue(userDetails.isAccountNonLocked());
        userDetails = rbbCasUserDetailsService.loadUserDetails(cas3());
        assertTrue(userDetails.isAccountNonLocked());
        userDetails = rbbCasUserDetailsService.loadUserDetails(cas4());
        assertTrue(userDetails.isAccountNonLocked());
    }

    private CasAssertionAuthenticationToken cas1() {
        Map<String, Object> attributes = new HashMap<>();
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }
    
    private CasAssertionAuthenticationToken cas2() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("roles", Arrays.asList("NET-Pilotage"));
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }

    private CasAssertionAuthenticationToken cas3() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        attributes.put("roles", Arrays.asList("EERE-Federation","IMP-EERE-Salarie"));
        
        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        attributes.put("fdiPerimeterName","FRANK");
        attributes.put("seeAlso","part2");
        attributes.put("businessIdMap", "{idEpargneRetraite=idEpargneRetraite}");
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }

    private CasAssertionAuthenticationToken cas4() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        attributes.put("roles", Arrays.asList("IMP-EERE-Salarie"));
        
        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }
}
