/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.contrat;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataContratHeader;

/**
 * The Class CompartimentTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CompartimentTest {
	/**The compartiment. */
	@InjectMocks
	private Compartiment compartiment;
	
	@Mock
    private CompartimentType type;
	
	@Mock
	private ContratHeader contratHeader;
    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
    	Compartiment one = new Compartiment();
    	Compartiment two = new Compartiment();
		assertEquals("These should be equal", one, two);
		int oneCode = one.hashCode();
		assertTrue("HashCodes should be equal", two.canEqual(two));
		assertEquals("HashCode should not change", oneCode, one.hashCode());
    }
    
    
    // Testing To String
    @Test
    public void testToString() {
    	Compartiment maClasse = new Compartiment();
    	assertNotNull(maClasse.toString());
    }
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		Compartiment maClasse = new Compartiment();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testIsMethod() {
		assertTrue(compartiment.is(type));
	}
	
	@Test
	public void testIsPacte() {
		assertFalse(compartiment.isPacte());
	}
	
	@Test
	public void testIsDeductible() {
		assertFalse(compartiment.isDeductible());
	}
	
	@Test
	public void testIsMDPRO() {
		assertFalse(compartiment.isMdpro());
	}
	
	@Test
	public void testIsERE() {
		assertFalse(compartiment.isERE());
	}
	
	@Test
	public void testGetDisponibility() {
		assertNull(compartiment.getDisponibilite());
	}
	/**
	 * Test GetAffichageType.
	 */
	@Test(expected = Test.None.class)
	public void testGetAffichageType() {
		compartiment.getAffichageType();
	}
	
	/**
	 * Test getCollege.
	 */
	@Test(expected = Test.None.class)
	public void testGetCollege() {
		compartiment.getCollege();
	}
	
	/**
	 * Test getLibelleEtat.
	 */
	@Test(expected = Test.None.class)
	public void testGetLibelleEtat() {
		compartiment.getLibelleEtat();
	}
	
	/**
	 * Test getContrat.
	 */
	@Test(expected = Test.None.class)
	public void testGetContrat() {
		compartiment.getContrat();
	}
	
	/**
	 * Test getContratHeader.
	 */
	@Test(expected = Test.None.class)
	public void testGetContratHeader() {
		compartiment.getContratHeader();
	}
	
	/**
	 * Test getContributionType.
	 */
	@Test(expected = Test.None.class)
	public void testGetContributionType() {
		compartiment.getContributionType();
	}
	
	/**
	 * Test getDateAffiliation.
	 */
	@Test(expected = Test.None.class)
	public void testGetDateAffiliation() {
		compartiment.getDateAffiliation();
	}
	
	/**
	 * Test getDateEffetSituationAffiliation.
	 */
	@Test(expected = Test.None.class)
	public void testGetDateEffetSituationAffiliation() {
		compartiment.getDateEffetSituationAffiliation();
	}
	
	/**
	 * Test getDisponibilite.
	 */
	@Test(expected = Test.None.class)
	public void testGetDisponibilite() {
		compartiment.getDisponibilite();
	}
	
	/**
	 * Test getEtatCompartiment.
	 */
	@Test(expected = Test.None.class)
	public void testGetEtatCompartiment() {
		compartiment.getEtatCompartiment();
	}
	
	/**
	 * Test getEtatContrat.
	 */
	@Test(expected = Test.None.class)
	public void testGetEtatContrat() {
		compartiment.getEtatContrat();
	}
	
	/**
	 * Test getIdCollege.
	 */
	@Test(expected = Test.None.class)
	public void testGetIdCollege() {
		compartiment.getIdCollege();
	}
	
	/**
	 * Test getIdentifiantAssure.
	 */
	@Test(expected = Test.None.class)
	public void testGetIdentifiantAssure() {
		compartiment.getIdentifiantAssure();
	}
	
	@Test
    public void testGetterSetterAffichageType() {
        final AffichageType affichageType = AffichageType.LECTURE_SEULE;
        final Compartiment compartimentTest = new Compartiment();
        compartimentTest.setAffichageType(AffichageType.LECTURE_SEULE);
        assertEquals(compartimentTest.getAffichageType(),affichageType);
    }
	
	@Test
    public void toStringTest(){
        assertNotNull(compartiment.toString());
    }
	
	@Test
    public void getContratHeaderTest(){
		final ContratHeader contratHeader = new DataContratHeader().getDataContratHeader(CompartimentType.C1);
        final Compartiment compartimentTest = new Compartiment();
        compartimentTest.setContratHeader(contratHeader);
        assertEquals(compartimentTest.getContratHeader(),contratHeader);
    }
	
	@Test
    public void testGetterSetterContributionType() {
        final ContributionType contributionType = ContributionType.EPARGNE_SALARIALE;
        final Compartiment compartimentTest = new Compartiment();
        compartimentTest.setContributionType(contributionType);
        assertEquals(compartimentTest.getContributionType(),contributionType);
    }
	
	@Test
    public void testGetterSetterCollege() {
        final String customer = "Koula";
        final Compartiment compartimentName = new Compartiment();
        compartimentName.setCollege("Koula");
        assertEquals(compartimentName.getCollege(),customer);
    }
}
