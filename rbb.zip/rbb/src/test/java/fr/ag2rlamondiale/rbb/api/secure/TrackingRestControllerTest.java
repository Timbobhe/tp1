package fr.ag2rlamondiale.rbb.api.secure;

import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.impl.TrackingFacadeImpl;

@RunWith(MockitoJUnitRunner.class)
public class TrackingRestControllerTest {

    @InjectMocks
    private TrackingRestController trackingRestController;

    @Mock
    private TrackingFacadeImpl trackingFacade;

    @Test
    public void getTrackingInfo() throws TechnicalException {
        trackingRestController.getTrackingInfo();
        verify(trackingFacade).getTrackingInfo();
    }
}
