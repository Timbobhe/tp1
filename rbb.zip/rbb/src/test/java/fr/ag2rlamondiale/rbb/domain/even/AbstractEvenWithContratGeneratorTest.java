/*
 * Cree le 10 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
/*
 * Cree le 10 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataEventJson;
import utils.data.DataTypeEvenementJson;
import utils.data.RandomData;


/**
 * The Class AbstractEvenWithContratGeneratorTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class AbstractEvenWithContratGeneratorTest {
	/* the abstractEvenGenerator mock*/
	@Mock
	private AbstractEvenWithContratGenerator abstractEvenWithContratGenerator;
	/* the contrat*/
	private ContratHeader contrat = new ContratHeader();
	/**
	 * The Class Maclass.
	 */
	private class Maclass extends AbstractEvenWithContratGenerator {
	
		/** The Constant serialVersionUID. */
		private static final long serialVersionUID = 1L;
	
		/**
		 * Instantiates a new maclass.
		 */
		public Maclass() {
			super();
		}

		@Override
		public boolean evaluerEvenement(ContratHeader contrat) {
			// TODO Auto-generated method stub
			return false;
		}
	}
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		Maclass maClasse = new Maclass();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testNullResultGenerateNextEven() {
		TriggeringResult triggeringResult = new TriggeringResult();
		Mockito.doReturn(null).when(abstractEvenWithContratGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenWithContratGenerator.generateNextEven(triggeringResult);
		assertNull("wrong resultat not null", resultat);
	}
	
	@Test
	public void testNotNullResultGenerateNextEven() {
		TriggeringResult triggeringResult = new TriggeringResult();
		EvenementJson newEvenement = new DataEventJson().getDataEventJson();		
		Mockito.doReturn(newEvenement).when(abstractEvenWithContratGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenWithContratGenerator.generateNextEven(triggeringResult);
		assertNotNull("wrong resultat null", resultat);
	}
	
	@Test
	public void testEvaluerEvenement() {
		Mockito.doReturn(true).when(abstractEvenWithContratGenerator).evaluerEvenement(contrat);
		Boolean resultat = abstractEvenWithContratGenerator.evaluerEvenement(contrat);
		assertTrue("wrong result true", (resultat == true));	
	}

}
