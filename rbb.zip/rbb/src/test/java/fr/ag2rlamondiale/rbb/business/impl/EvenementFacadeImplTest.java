package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.business.IBlocageFacade;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.IEvenGenerators;
import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.rbb.business.impl.DocumentationFacadeImplTest.MockUserContext;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.rest.IEvenementRestClient;
import fr.ag2rlamondiale.trm.domain.blocage.FonctionnaliteJson;
import fr.ag2rlamondiale.trm.domain.evenement.CategorieJson;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.testing.core.EntryStream;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EvenementFacadeImplTest {

    private IEvenementRestClient evenementRestClient;
    private IEvenGenerators evenGenerators;
    private UserContextHolder userContextHolder;
    private IPartenaireFacade partenaireFacade;
    private IContratFacade contratFacade;
    private IBlocageFacade blocageFacade;

    @InjectMocks
    private EvenementFacadeImpl evenementFacade;

    @Before
    public void init() throws TechnicalException {
        initEvenRestClient();
        initGenerators("ERE_CONF");
        initUserContext();

        initPartenaire();
        initContrat();
        this.blocageFacade = mock(IBlocageFacade.class);

        MockitoAnnotations.initMocks(this);
    }

    private void initContrat() throws TechnicalException {
        this.contratFacade = mock(IContratFacade.class);
        when(this.contratFacade.rechercherContratsEre()).thenAnswer(invocation -> {
            ContratHeader contrat = new ContratHeader();
            contrat.setId("IDCONTRAT");
            return Collections.singletonList(contrat);
        });
    }

    private void initPartenaire(String... fonctionnnalitesBloquees) throws TechnicalException {
        this.partenaireFacade = mock(IPartenaireFacade.class);
        when(this.partenaireFacade.findPartenaire(any(), any(), any())).thenAnswer(invocation -> {
            PartenaireJson partenaire = new PartenaireJson();
            partenaire.setIdContrats(Collections.singletonList("IDCONTRAT"));
            List<FonctionnaliteJson> blocages = Stream.of(fonctionnnalitesBloquees)
                    .map(FonctionnaliteJson::new).collect(Collectors.toList());
            partenaire.setFonctionnnalitesBloquees(blocages);
            return partenaire;
        });
    }

    private void initUserContext() {
        this.userContextHolder = mock(UserContextHolder.class);

        final UserContext userContextERE = createUserContextERE(MOCKDATA);
        when(userContextHolder.get()).thenReturn(userContextERE);
    }

    private void initUserPartenaireContext() {
        this.userContextHolder = mock(UserContextHolder.class);

        final UserContext userContextERE = createUserContextERE(MOCKDATA);
        Partenaire partenaire = new Partenaire();
        partenaire.setCodePartenaire("NIE");
        partenaire.setIdContrats(Collections.singletonList("IDCONTRAT"));
        userContextERE.setPartenaire(partenaire);
        when(userContextHolder.get()).thenReturn(userContextERE);
    }

    private void initGenerators(String codeTypeEven) {
        this.evenGenerators = mock(IEvenGenerators.class);
        when(this.evenGenerators.generateNextEven(any(), any(), any(), any(), any()))
                .thenReturn(new EvenementJson(new TypeEvenementJson(codeTypeEven)));
    }

    private void initEvenRestClient() {
        this.evenementRestClient = mock(IEvenementRestClient.class);
        when(this.evenementRestClient.rechercherTypesEvenements(any())).thenAnswer(invocation -> {
            List<TypeEvenementJson> typesEven = new ArrayList<>();
            TypeEvenementJson cgu = new TypeEvenementJson("PRT_CGU");
            typesEven.add(cgu);

            TypeEvenementJson conf = new TypeEvenementJson("ERE_CONF");
            typesEven.add(conf);

            TypeEvenementJson bia = new TypeEvenementJson("ERE_BIA");
            cgu.setLienRedirection("completerBIA");
            typesEven.add(bia);

            TypeEvenementJson vdpp = new TypeEvenementJson("ERE_VDPP");
            typesEven.add(vdpp);

            TypeEvenementJson onbr = new TypeEvenementJson(TypeEven.ONBOARDING.getCode());
            typesEven.add(onbr);


            return EntryStream.of(typesEven)
                    .map(entry -> {
                        TypeEvenementJson typeEven = entry.getValue();
                        CategorieJson categ = new CategorieJson();
                        typeEven.setCategorie(categ);
                        categ.setOrdre(entry.getKey());
                        return typeEven;
                    })
                    .collect(Collectors.toList());

        });

        when(this.evenementRestClient.rechercherEvenements(any()))
                .thenReturn(Collections.emptyList());

        when(this.evenementRestClient.insertEvenement(any()))
                .thenAnswer(invocation -> invocation.getArguments()[0]);

    }

    private UserContext createUserContextERE(String numPP) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        return userContext;
    }

    @Test
    public void test_generateNextEvenement() throws Exception {
        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
        assertNotNull(evenementJson);
        verify(this.evenementRestClient).insertEvenement(evenementJson);
    }

    @Test
    public void test_generateNextEvenement_predicate() throws Exception {
        initGenerators(TypeEven.ONBOARDING.getCode());
        MockitoAnnotations.initMocks(this);

        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate(), true);
        assertNotNull(evenementJson);
        assertEquals(TypeEven.ONBOARDING.getCode(), evenementJson.getTypeEvenement().getCodeEvenement());
        verify(this.evenementRestClient).insertEvenement(evenementJson);
    }

    @Test
    public void test_generateNextEvenement_predicate_not() throws Exception {
        initGenerators("ERE_CONF");
        MockitoAnnotations.initMocks(this);

        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
        assertNotNull(evenementJson);
        assertEquals("ERE_CONF", evenementJson.getTypeEvenement().getCodeEvenement());
        verify(this.evenementRestClient).insertEvenement(evenementJson);
    }

    @Test
    public void test_generateNextEvenement_partenaire() throws Exception {
        initUserPartenaireContext();
        initPartenaire();
        MockitoAnnotations.initMocks(this);

        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
        assertNotNull(evenementJson);
        verify(this.evenementRestClient).insertEvenement(evenementJson);
    }

    @Test
    public void test_generateNextEvenement_partenaire_avecBlocages() throws Exception {
        initUserPartenaireContext();
        initPartenaire("completerBIA");
        MockitoAnnotations.initMocks(this);

        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
        assertNotNull(evenementJson);
        verify(this.evenementRestClient).insertEvenement(evenementJson);
    }


    @Test
    public void test_typesEven_vide() throws Exception {
        when(this.evenementRestClient.rechercherTypesEvenements(any())).thenReturn(Collections.emptyList());
        MockitoAnnotations.initMocks(this);
        final EvenementJson evenementJson = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
        assertNull(evenementJson);
    }

}
