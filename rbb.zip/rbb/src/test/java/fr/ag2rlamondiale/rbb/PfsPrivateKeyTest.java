package fr.ag2rlamondiale.rbb;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class PfsPrivateKeyTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class PfsPrivateKeyTest {
	
	/**The PfsPrivateKey. */
	@InjectMocks
	private PfsPrivateKey pfsPrivateKey;
	
	@Test
	public void testBean() {
		new BeanTester().testBean(PfsPrivateKey.class);
	}
	
	/**
	 * Test To String.
	 */
	@Test
	public void testToString() {		
		assertNotNull("wrong result null",pfsPrivateKey.toString());
	}
	
	
}
