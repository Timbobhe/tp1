/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

/**
 * The Class WebSecurityConfigTest.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class WebSecurityConfigTest {
	
	/**The WebSecurityConfig. */
	@InjectMocks
	private WebSecurityConfig webSecurityConfig;
	
	
	@Test
	public void testBean() {
		new BeanTester().testBean(WebSecurityConfig.class);
	}

	/**
	 * Test To String.
	 */
	@Test
	public void testToString() {		
		assertNotNull("wrong result null",webSecurityConfig.toString());
		
	}
}
