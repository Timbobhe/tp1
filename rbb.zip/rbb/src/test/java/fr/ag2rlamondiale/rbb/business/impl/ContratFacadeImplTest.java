/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratInconnuException;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratEnum;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.SimpleAsyncTaskExecutor;

import javax.annotation.Nonnull;
import java.util.*;

import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;
/**
 * The Class ContratFacadeImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ContratFacadeImplTest {

    @Spy
    @InjectMocks
    ContratFacadeImpl contratFacadeImpl;

    @Mock
    IContratsClient contratClient;

    @Mock
    ContratClientFacadeImpl contratClientFacade;

    @Mock
    UserContextHolder userContextHolder;

    @Spy
    AsyncTaskExecutor asyncTaskExecutor = new SimpleAsyncTaskExecutor();

    @Spy
    private RequestContextHolder requestContext = new RequestContextHolder();

    @Before
    public void init() throws TechnicalException {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");

        when(userContextHolder.get()).thenReturn(userContext);

        when(contratClientFacade.rechercherContratsPersonne(rechContrat("NumERE", CodeSiloType.ERE)))
                .thenReturn(createContratHeaderList(CodeSiloType.ERE));
        when(contratClientFacade.rechercherContratsEpargnePrevoyance(rechContrat("NumMDP", CodeSiloType.MDP)))
                .thenReturn(createContratHeaderList(CodeSiloType.MDP));
        when(contratClientFacade.rechercherContratsRetraiteSuppEpargnePrevoyance(rechContrat("NumMDP", CodeSiloType.MDP)))
                .thenReturn(createContratHeaderList(CodeSiloType.MDP));
        when(contratClient.consulterCompteGeneralesERE(consulterCompteGene("idAssur")))
                .thenReturn(createCompteGeneraleERE());
        when(contratClient.consulterCompteGeneralesERE(consulterCompteGene("idAssur1")))
                .thenReturn(createCompteGeneraleERE());
    }

    private RechercherContratsDto rechContrat(String idPersonne, CodeSiloType codeSilo) {
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(codeSilo);
        rechercherContratsDto.setPersonId(idPersonne);
        return rechercherContratsDto;
    }

    private ConsulterCompteGeneralesEREDto consulterCompteGene(String idAssure) {
        return new ConsulterCompteGeneralesEREDto(idAssure);
    }

    private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        contrat.setDateSitCtr(relativeDate(-6));
        return contrat;
    }

    @Nonnull
    private Date relativeDate(int nbMois) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, nbMois);
        return calendar.getTime();
    }

    private List<ContratHeader> createContratHeaderList(CodeSiloType silo) {
        return Arrays.asList(createContratHeader("id", "idAssur", silo), createContratHeader("id1", "idAssur1", silo));
    }


    private UserContext userContextEmpty() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("");
        userContext.setNumeroPersonneEre("");
        return userContext;
    }

    private UserContext userContextpartenaire() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
        Partenaire partenaire = new Partenaire();
        partenaire.setIdContrats(Collections.singletonList("id1"));
        userContext.setPartenaire(partenaire);
        return userContext;
    }

    @Test
    public void rechercherContratParIdAssure() throws TechnicalException {
        ContratHeader res1 = contratFacadeImpl.rechercherContratParIdAssure("idAssur");
        ContratHeader res2 = contratFacadeImpl.rechercherContratParIdAssure("idAssur2");
        assertNotNull(res1);
        assertEquals("id", res1.getId());
        assertNull(res2);
    }
    
    
    @Test
    public void comparatorDateEffetSituationAffiliation() throws TechnicalException {
        assertNotNull(contratFacadeImpl.comparatorDateEffetSituationAffiliation());
    }

    @Test
    public void rechercherContratsMdpro() throws TechnicalException {
        List<ContratHeader> contrats = contratFacadeImpl.rechercherContratsMdpro();
        assertEquals(2, contrats.size());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacadeImpl.rechercherContratsMdpro().isEmpty());
    }

    @Test
    public void rechercherContratsEre() throws TechnicalException {
        List<ContratHeader> contrats = contratFacadeImpl.rechercherContratsEre();
        assertEquals(2, contrats.size());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacadeImpl.rechercherContratsEre().isEmpty());
    }

    @Test
    public void rechercherContrats() throws TechnicalException {
        List<ContratHeader> contrats = contratFacadeImpl.rechercherContrats();
        assertEquals(4, contrats.size());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextpartenaire());
        contrats = contratFacadeImpl.rechercherContrats();
        assertEquals(4, contrats.size());
    }

    @Test
    public void rechercherContratsComplets() throws TechnicalException {
        List<ContratComplet> contrats = contratFacadeImpl.rechercherContratsComplets();
        assertEquals(4, contrats.size());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextpartenaire());
        contrats = contratFacadeImpl.rechercherContratsComplets();
        assertEquals(4, contrats.size());
    }

    @Test
    public void rechercherContratsCompletsERE() throws TechnicalException {
        when(contratClient.consulterCompteGeneralesERE(any(ConsulterCompteGeneralesEREDto.class))).thenReturn(createCompteGeneraleERE());
        List<ContratComplet> contrats = contratFacadeImpl.rechercherContratsCompletsERE();
        assertEquals(2, contrats.size());
        assertNull(contrats.get(0).getEncours());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextpartenaire());
        contrats = contratFacadeImpl.rechercherContratsCompletsERE();
        assertEquals(2, contrats.size());
    }

    @Test
    public void rechercherContratsCompletsMDP() throws TechnicalException {
        when(contratClient.consulterCompteGeneralesERE(any(ConsulterCompteGeneralesEREDto.class))).thenReturn(createCompteGeneraleERE());

        List<ContratComplet> contrats = contratFacadeImpl.rechercherContratsCompletsMDP();
        assertEquals(2, contrats.size());
        assertNull(contrats.get(0).getEncours());
        /// annuler le init 
        when(userContextHolder.get()).thenReturn(userContextpartenaire());
        contrats = contratFacadeImpl.rechercherContratsCompletsERE();
        assertEquals(2, contrats.size());
    }


    private CompteGeneralesERE createCompteGeneraleERE() {
        CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setDateEffetSituationAffiliation(relativeDate(-6));
        compteGeneralesERE.setCodeEtat("A");
        return compteGeneralesERE;
    }

    @Test
    public void should_find_contrat_complet_by_id() throws TechnicalException {
        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.ERE)
                .build();

        contratFacadeImpl.rechercherContratCompletParId(contratId);

        verify(contratFacadeImpl, times(1)).recupererContratComplet(any(ContratHeader.class));
    }

    @Test(expected = ContratInconnuException.class)
    public void should_not_find_contrat_complet_by_id() throws TechnicalException {
        ContratId contratId = ContratId.builder().nomContrat("id2").codeSilo(CodeSiloType.ERE).build();
        ContratComplet actual = contratFacadeImpl.rechercherContratCompletParId(contratId);
        fail();
    }

    @Test
    public void should_find_contrat_by_code_silo_ere() throws TechnicalException {
    	contratFacadeImpl.rechercherContrats(CodeSiloType.ERE);

        verify(contratFacadeImpl, times(1)).rechercherContratsEre();
    }

    @Test
    public void should_find_contrat_by_code_silo_mdpro() throws TechnicalException {
    	contratFacadeImpl.rechercherContrats(CodeSiloType.MDP);

        verify(contratFacadeImpl, times(1)).rechercherContratsMdpro();
    }

    @Test
    public void should_find_contrat_complet_by_code_silo_ere() throws TechnicalException {
    	contratFacadeImpl.rechercherContratsComplets(CodeSiloType.ERE);

        verify(contratFacadeImpl, times(1)).rechercherContratsCompletsERE();
    }

    @Test
    public void should_find_contrat_complet_by_code_silo_mdpro() throws TechnicalException {
    	contratFacadeImpl.rechercherContratsComplets(CodeSiloType.MDP);

        verify(contratFacadeImpl, times(1)).rechercherContratsCompletsMDP();
    }

    @Test
    public void rechercherContratsEpargnePrevoyance() throws TechnicalException {
        List<ContratHeader> contrats = contratFacadeImpl.rechercherContratsEpargnePrevoyance();
        assertEquals(2, contrats.size());
        /// annuler le init
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacadeImpl.rechercherContratsEpargnePrevoyance().isEmpty());
    }

    @Test
    public void rechercherContratsRetraiteSuppEpargnePrevoyanceMdpro() throws TechnicalException {
        List<ContratHeader> contrats = contratFacadeImpl.rechercherContratsRetraiteSuppEpargnePrevoyanceMdpro();
        assertEquals(2, contrats.size());
        /// annuler le init
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacadeImpl.rechercherContratsEpargnePrevoyance().isEmpty());
    }

    @Test
    public void rechercherContratRetraireSuppEpargnePrevoyanceMDPROParId() throws TechnicalException {
        ContratHeader res1 = contratFacadeImpl.rechercherContratRetraireSuppEpargnePrevoyanceMDPROParId(ContratId.builder().nomContrat("id").codeSilo(CodeSiloType.MDP).build());
        assertEquals("id", res1.getId());
    }
}
