/*
 * Cree le 10 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;

import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;
import utils.data.RandomData;

/**
 * The Class EreMsgIndispoEvenGeneratorTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class EreMsgIndispoEvenGeneratorTest {

	/* the ereMsgIndispoEvenGenerator mock*/
	@Mock
	private EreMsgIndispoEvenGenerator ereMsgIndispoEvenGenerator;
	
	/* the numPersonne*/
	private String numPersonne = RandomData.getRandomStringSize10();
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		EreMsgIndispoEvenGenerator maClasse = new EreMsgIndispoEvenGenerator();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testEvaluerEvenement() {
		Mockito.doReturn(true).when(ereMsgIndispoEvenGenerator).evaluerEvenement(numPersonne);
		Boolean resultat = ereMsgIndispoEvenGenerator.evaluerEvenement(numPersonne);
		assertTrue("wrong result true", (resultat == true));	
	}
}
