/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.enumeration;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class CodeSiloTypeTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContratBlocageTest {
	/**
	 * Test enum.
	 */
	@Test
	public void testCodeSiloType() {
		assertNotNull("wrong enum ARB_BLOCAGE_ABSENCE_BIA", ContratBlocage.ARB_BLOCAGE_ABSENCE_BIA);
		assertNotNull("wrong enum ARB_BLOCAGE_ARBITRAGE_EN_COURS", ContratBlocage.ARB_BLOCAGE_ARBITRAGE_EN_COURS);
		assertNotNull("wrong enum ARB_BLOCAGE_CONDITIONS_CONTRAT", ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT);
		assertNotNull("wrong enum ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL", ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL);
		assertNotNull("wrong enum ARB_BLOCAGE_CONSOLE", ContratBlocage.ARB_BLOCAGE_CONSOLE);
		assertNotNull("wrong enum ARB_BLOCAGE_ETAT_COMPTE", ContratBlocage.ARB_BLOCAGE_ETAT_COMPTE);
		assertNotNull("wrong enum ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS ", ContratBlocage.ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS);
		assertNotNull("wrong enum ARB_BLOCAGE_EXTRANET_UNFINISHED_REQUEST",ContratBlocage.ARB_BLOCAGE_EXTRANET_UNFINISHED_REQUEST);
		assertNotNull("wrong enum ARB_BLOCAGE_NB_MAX_DEPASSE", ContratBlocage.ARB_BLOCAGE_NB_MAX_DEPASSE);
		assertNotNull("wrong enum ARB_BLOCAGE_OPERATIONS_EN_COURS", ContratBlocage.ARB_BLOCAGE_OPERATIONS_EN_COURS);
		assertNotNull("wrong enum ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT", ContratBlocage.ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT);
		assertNotNull("wrong enum BLOCAGE_BIA_DEJA_SAISI", ContratBlocage.BLOCAGE_BIA_DEJA_SAISI);
		assertNotNull("wrong enum BLOCAGE_BIA_EN_COURS", ContratBlocage.BLOCAGE_BIA_EN_COURS);
		assertNotNull("wrong enum BLOCAGE_BIA_MONO_EQUIPE_MDPRO", ContratBlocage.BLOCAGE_BIA_MONO_EQUIPE_MDPRO);
		assertNotNull("wrong enum BLOCAGE_BIA_SITUATION_AFFILIATION", ContratBlocage.BLOCAGE_BIA_SITUATION_AFFILIATION);
		assertNotNull("wrong enum BLOCAGE_MODIFICATION_CLAUSE_BENEFICIAIRE_EN_COURS",ContratBlocage.BLOCAGE_MODIFICATION_CLAUSE_BENEFICIAIRE_EN_COURS);
		assertNotNull("wrong enum BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS", ContratBlocage.BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS);
		assertNotNull("wrong enum CONSOLE", ContratBlocage.CONSOLE);
		assertNotNull("wrong enum HUB_VERSEMENT_ACCESS_DENIED_CONTRACT", ContratBlocage.HUB_VERSEMENT_ACCESS_DENIED_CONTRACT);
		assertNotNull("wrong enum METIER", ContratBlocage.METIER);
		assertNotNull("wrong enum METIER_ARBITRAGE_RM0X", ContratBlocage.METIER_ARBITRAGE_RM0X);
		assertNotNull("wrong enum METIER_COMPTE_CLOTURE", ContratBlocage.METIER_COMPTE_CLOTURE);
		assertNotNull("wrong enum  METIER_EVOL_ENCOURS_RM04", ContratBlocage.METIER_EVOL_ENCOURS_RM04);
		assertNotNull("wrong enum METIER_EXTRANET_BIA_UNFINISHED_REQUEST",ContratBlocage.METIER_EXTRANET_BIA_UNFINISHED_REQUEST);
		assertNotNull("wrong enum METIER_EXTRANET_CBF_MDPRO_UNAIVALABLE", ContratBlocage.METIER_EXTRANET_CBF_MDPRO_UNAIVALABLE);
		assertNotNull("wrong enum METIER_EXTRANET_CBF_UNFINISHED_REQUEST", ContratBlocage.METIER_EXTRANET_CBF_UNFINISHED_REQUEST);
		assertNotNull("wrong enum METIER_EXTRANET_LIQUIDATION_PENDING_REQUEST", ContratBlocage.METIER_EXTRANET_LIQUIDATION_PENDING_REQUEST);
		assertNotNull("wrong enum METIER_LIQUIDATION_MDPRO_UNAVAILABLE", ContratBlocage.METIER_LIQUIDATION_MDPRO_UNAVAILABLE);
		assertNotNull("wrong enum METIER_LIQUIDATION_PACTE_UNAVAILABLE", ContratBlocage.METIER_LIQUIDATION_PACTE_UNAVAILABLE);
		assertNotNull("wrong enum METIER_PERSONAL_DATA_UNCONFIRMED",ContratBlocage.METIER_PERSONAL_DATA_UNCONFIRMED);
		assertNotNull("wrong enum METIER_SCHEDULED_DEPOSIT_PENDING_REQUEST", ContratBlocage.METIER_SCHEDULED_DEPOSIT_PENDING_REQUEST);
		assertNotNull("wrong enum METIER_SCHEDULED_DEPOSIT_UNFINISHED_REQUEST", ContratBlocage.METIER_SCHEDULED_DEPOSIT_UNFINISHED_REQUEST);
		assertNotNull("wrong enum MODIFIERRIB_ACCESS_DENIED", ContratBlocage.MODIFIERRIB_ACCESS_DENIED);
		assertNotNull("wrong enum NONE", ContratBlocage.NONE);
		assertNotNull("wrong enum VERSEMENT_BLOCAGE_CONDITION_RESIDENCE ", ContratBlocage.VERSEMENT_BLOCAGE_CONDITION_RESIDENCE);
		assertNotNull("wrong enum VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT",ContratBlocage.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT);

	}
}
