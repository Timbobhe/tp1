/*
 * Cree le 15 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;


/**
 * The Class MockUserContext.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class MockUserContextTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(MockUserContext.class);
	}

    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
        MockUserContext one = new MockUserContext();
        MockUserContext two = new MockUserContext();
		assertEquals("These should be equal", one, two);
		int oneCode = one.hashCode();
		assertEquals("HashCodes should be equal", oneCode, two.hashCode());
		assertEquals("HashCode should not change", oneCode, one.hashCode());
    }
    
    
    // Testing To String
    @Test
    public void testToString() {
    	MockUserContext maClasse = new MockUserContext();
    	assertNotNull(maClasse.toString());
    }
}
