/*
 * Cree le 22 septembre 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.util.Date;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import pl.pojo.tester.api.assertion.Method;
import utils.data.RandomData;

/**
 * The Class DateUtilsTest.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration

public class DateUtilsTest {
	
	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();

	/** The date naissance est majeur. */
	//
	private Date dateNaissanceEstMajeur;
	
	/** The date naissance moins de 85 ans true. */
	private Date dateNaissanceMoinsDe85ansTrue;
	
	/** The date naissance moins de 85 ans false. */
	private Date dateNaissanceMoinsDe85ansFalse;

	/**
	 * Are well implemented.
	 */

	@Before
	public void setUp() {
		dateNaissanceEstMajeur = RandomData.getRandomDate_1999_2000();
		dateNaissanceMoinsDe85ansTrue = RandomData.getRandomDate_1960_1980();
		dateNaissanceMoinsDe85ansFalse = RandomData.getRandomDate_1900_1901();	
	}

	/**
	 * Test cconstructors.
	 */
	@Test
	public void testCconstructors() {
		assertPojoMethodsFor(DateUtils.class).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test est majeur true.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testEstMajeurTrue() throws Exception {
		boolean resultat = DateUtils.estMajeur(dateNaissanceEstMajeur);
		assertTrue("wrong estMajeur true", resultat);
	}

	/**
	 * Test est majeur false.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testEstMajeurFalse() throws Exception {
		boolean resultat = DateUtils.estMajeur(new Date());
		assertFalse("wrong estMajeur false", resultat);
	}

	/**
	 * Test moins de 85 ans true.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testMoinsDe85ansTrue() throws Exception {
		boolean resultat = DateUtils.moinsDe85ans(dateNaissanceMoinsDe85ansTrue);
		assertTrue("wrong moinsDe85ans true", resultat);
	}

	/**
	 * Test moins de 85 ans false.
	 *
	 * @throws Exception the exception
	 */
	@Test
	public void testMoinsDe85ansFalse() throws Exception {
		boolean resultat = DateUtils.moinsDe85ans(dateNaissanceMoinsDe85ansFalse);
		assertFalse("wrong moinsDe85ans false", resultat);
	}


}
