package fr.ag2rlamondiale.rbb.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;


/**
 * The Class ErrorConstantes.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ErrorConstantesTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(ErrorConstantes.class);
	}
    
}
