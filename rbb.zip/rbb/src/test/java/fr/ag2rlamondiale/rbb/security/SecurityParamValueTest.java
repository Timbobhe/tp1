/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.security;

import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import fr.ag2rlamondiale.trm.security.SecurityParamType;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import pl.pojo.tester.api.assertion.Method;

/**
 * The Class SecurityParamValueTest.
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class SecurityParamValueTest {
	
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		SecurityParamValue maClasse = new SecurityParamValue(SecurityParamType.CONTRAT,"");
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(SecurityParamValue.class).suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
    
    // Testing To String
    @Test
    public void testToString() {
    	SecurityParamValue maClasse = new SecurityParamValue(SecurityParamType.CONTRAT,"");
    	assertNotNull(maClasse.toString());
    }
}
