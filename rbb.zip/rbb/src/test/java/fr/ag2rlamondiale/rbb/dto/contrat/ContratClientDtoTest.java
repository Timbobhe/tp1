/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.dto.contrat;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;


/**
 * The Class ContratClientDtoTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContratClientDtoTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(ContratClientDto.class);
	}

    // Testing To String
    @Test
    public void testToString() {
    	ContratClientDto contratClientDto = new ContratClientDto();
    	assertNotNull(contratClientDto.toString());
    }
}
