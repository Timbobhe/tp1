/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;


import fr.ag2rlamondiale.rbb.MockSupplierLibService;
import fr.ag2rlamondiale.trm.business.ISupplierSigElecService;
import fr.ag2rlamondiale.trm.csv.CodesAssureurMapper;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;
/**
 * The Class RbbSupplierSigElecServiceTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class RbbSupplierSigElecServiceTest {

    @InjectMocks
    RbbSupplierSigElecService rbbSupplierSigElecService;

    @Spy
    CodesAssureurMapper codesAssureurMapper;

    @Spy
    MockSupplierLibService supplierLibService;

    @Mock
    UserContextHolder userContextHolder;

    @Test
    public void getProfile() {
        // Given
        DemandeCreationSigElec<? extends IContrat> demande = new DemandeCreationSigElec<>();
        demande.setCodeAssureur("LM");

        // When
        final String profile = rbbSupplierSigElecService.getProfile(demande);

        // Then
        assertNotNull(profile);
    }


    @Test
    public void getProfile_CodeAssureurNull() {
        // Given
        DemandeCreationSigElec<? extends IContrat> demande = new DemandeCreationSigElec<>();
        demande.setCodeAssureur(null);

        // When
        final String profile = rbbSupplierSigElecService.getProfile(demande);

        // Then
        assertNull(profile);
    }


    @Test
    public void getUrlRetour() {
        final String urlArbi = rbbSupplierSigElecService.getUrlRetour(OperationType.ARBI, ISupplierSigElecService.SUCCES, false, "RA1234", null);
        assertNotNull("urlArbi null",urlArbi);
    }

    @Test
    public void getUrlRetour_partenaire() {
        when(userContextHolder.get()).thenReturn(newUserContext(true));

        final String urlArbi = rbbSupplierSigElecService.getUrlRetour(OperationType.ARBI, ISupplierSigElecService.SUCCES, true, "RA1234", null);
        assertEquals("http://nie/def_int_ep/ep/aca/gestion_signature.do?contrat=RA1234&parcours=arbitrage&action=succes", urlArbi);
    }

    private UserContext newUserContext(boolean partenaire) {
        UserContext u = new UserContext();
        if (partenaire) {
            Partenaire p = new Partenaire();
            u.setPartenaire(p);
            p.setCodePartenaire(Partenaire.CODE_NIE);
            p.setBaseUrl("http://nie");
        }

        return u;
    }

    @Test
    public void buildFrameCallbackUrl() {
        final String urlArbi = rbbSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.ARBI, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlArbi);
        System.out.println(urlArbi);

        final String urlBia = rbbSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.EBIA, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlBia);
        System.out.println(urlBia);

        final String urlCbf = rbbSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.CBF, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlCbf);
        System.out.println(urlCbf);

        try {
        	rbbSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.LIQR, ISupplierSigElecService.SUCCES, "RA1234");
            fail("Parcours LIQR non prévue en IFRAME pour l'instant (08/04/21)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void inferActionFromStatus() {
        assertEquals("echec", rbbSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.ECHEC));
        assertEquals("annulation", rbbSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.ANNULATION));
        assertEquals("succes", rbbSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.SUCCES));
    }

    @Test
    public void getUrl() {
        final String urlArbi = rbbSupplierSigElecService.getUrl(OperationType.ARBI, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlArbi);
        final String urlVr = rbbSupplierSigElecService.getUrl(OperationType.VR, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlVr);
        final String urlVrli = rbbSupplierSigElecService.getUrl(OperationType.VRLI, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlVrli);
        final String urlVrPg = rbbSupplierSigElecService.getUrl(OperationType.VRPG, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlVrPg);
        final String urlArretVrPg = rbbSupplierSigElecService.getUrl(OperationType.VRPG, ISupplierSigElecService.SUCCES, "arret-versement");
        assertNotNull("urlArbi null",urlArretVrPg);
        final String urlCbf = rbbSupplierSigElecService.getUrl(OperationType.CBF, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlCbf);
        final String urlRiba = rbbSupplierSigElecService.getUrl(OperationType.RIBA, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlRiba);
        final String urlEbia = rbbSupplierSigElecService.getUrl(OperationType.EBIA, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlEbia);
        final String urlLiqr = rbbSupplierSigElecService.getUrl(OperationType.LIQR, ISupplierSigElecService.SUCCES, null);
        assertNotNull("urlArbi null",urlLiqr);
    }
}
