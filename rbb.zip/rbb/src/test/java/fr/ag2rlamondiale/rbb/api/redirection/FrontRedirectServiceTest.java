package fr.ag2rlamondiale.rbb.api.redirection;

import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FrontRedirectServiceTest {
    private static final String BAD_PARTENAIRE_URL = "http/pla-lilly-staging.adding.fr/ACACustomisationError.htl";
    private static final String PARTENAIRE_URL_ERROR = "https://pla-lilly-staging.adding.fr/ACACustomisation/Error.html";
    private static final String PARTENAIRE_ID = "49503";
    private static final String APPLICATION_URL = "http://localhost:4200";
    public static final String BAD_APPLICATION_URL = "http/localhost:/4200";
    public static final String LOCATION = "Location";
    public static final String ID_LOGOUT = "?id=LOGOUT";
    @Mock
    IPartenaireFacade partenaireFacadeMock;

    @InjectMocks
    private FrontRedirectService testedClass;

    HttpHeaders headers;

    @Test
    public void should_redirect_to_front() {
        headers = new HttpHeaders();
        headers.add(LOCATION, APPLICATION_URL);
        Assert.assertEquals(testedClass.redirectToFront(APPLICATION_URL),
                new ResponseEntity<String>(headers, HttpStatus.FOUND));
    }

    @Test
    public void should_not_redirect_to_front_and_throw_exception() {
        Assert.assertEquals(testedClass.redirectToFront(BAD_APPLICATION_URL),
                new ResponseEntity<String>(HttpStatus.BAD_REQUEST));
    }

    @Test
    public void should_redirect_to_partenaire() {
        when(partenaireFacadeMock.findById(anyString())).thenReturn(createPartenaire());

        headers = new HttpHeaders();
        headers.add(LOCATION, createPartenaire().getUrlError().concat(ID_LOGOUT));

        Assert.assertEquals(testedClass.redirectToPartenaireById(PARTENAIRE_ID),
                new ResponseEntity<String>(headers, HttpStatus.FOUND));
    }

    @Test
    public void should_not_redirect_to_partenaire() {
        when(partenaireFacadeMock.findById(anyString())).thenReturn(createPartenaireWithBadUrl());

        Assert.assertEquals(testedClass.redirectToPartenaireById(PARTENAIRE_ID),
                new ResponseEntity<String>(HttpStatus.BAD_REQUEST));
    }

    private PartenaireJson createPartenaire() {
        PartenaireJson partenaire = new PartenaireJson();
        partenaire.setUrlError(PARTENAIRE_URL_ERROR);
        return partenaire;
    }

    private PartenaireJson createPartenaireWithBadUrl() {
        PartenaireJson partenaire = new PartenaireJson();
        partenaire.setUrlError(BAD_PARTENAIRE_URL);
        return partenaire;
    }
}
