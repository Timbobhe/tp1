/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.dto.tracking;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;

/**
 * The Class EquipementRetraiteSuppDtoTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class EquipementRetraiteSuppDtoTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(EquipementRetraiteSuppDto.class);
	}

    // Testing To String
    @Test
    public void testToString() {
    	EquipementRetraiteSuppDto equipementRetraiteSuppDto = new EquipementRetraiteSuppDto();
    	assertNotNull(equipementRetraiteSuppDto.toString());
    }
    
    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(EquipementRetraiteSuppDto.class).suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
}
