package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.impl.DocumentationFacadeImplTest.MockUserContext;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.dto.tracking.EquipementRetraiteSuppDto;
import fr.ag2rlamondiale.rbb.dto.tracking.TrackingInfoDto;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.csv.SituationFamilialeType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static fr.ag2rlamondiale.trm.utils.Sets.set;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class TrackingFacadeTest {
    IContratFacade contratFacade;
    IConsulterPersonneClient consulterPersonneClient;
    UserContextHolder userContextHolder;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @InjectMocks
    private TrackingFacadeImpl trackingFacade;

    @Before
    public void init() throws TechnicalException {
        initUserContext();
        initContrat();

        MockitoAnnotations.initMocks(this);
    }

    private void initContrat(ContratHeader... contrats) throws TechnicalException {
        this.contratFacade = mock(IContratFacade.class);
        when(this.contratFacade.rechercherContrats()).thenReturn(Arrays.asList(contrats));
    }

    private void initUserContext() {
        this.userContextHolder = mock(UserContextHolder.class);

        final UserContext userContextERE = createUserContextERE(MOCKDATA);
        when(userContextHolder.get()).thenReturn(userContextERE);
    }

    private void initConsulterPersonneClient(PersonnePhysiqueConsult pp) throws TechnicalException {
        this.consulterPersonneClient = mock(IConsulterPersonneClient.class);
        when(this.consulterPersonneClient.consulterPersPhys(any())).thenReturn(pp);
    }

    private UserContext createUserContextERE(String numPP) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setSilos(set(CodeSiloType.ERE));
        return userContext;
    }

    @Test
    public void getTrackingInfo_1() throws TechnicalException {
        PersonnePhysiqueConsult pp = pp("F", 20, "75001", null);
        initConsulterPersonneClient(pp);

        initContrat(contrat("TYPECONTRAT1", "IDENTIFIANTASSURE1", "PRODUIT1"));

        MockitoAnnotations.initMocks(this);

        final TrackingInfoDto trackingInfo = trackingFacade.getTrackingInfo();
        assertEquals("Madame", trackingInfo.getClientGenre());
        assertEquals("0 \u00e0 20 ans", trackingInfo.getClientAge());
        assertEquals("inconnu", trackingInfo.getClientSituationFamiliale());
        assertEquals("75", trackingInfo.getClientPostcode());

        assertEquals(1, trackingInfo.getEquipementsRetraiteSupp().size());
        final EquipementRetraiteSuppDto equipement = trackingInfo.getEquipementsRetraiteSupp().get(0);
        assertEquals("TYPECONTRAT1", equipement.getTypeContrat());
        assertEquals("IDENTIFIANTASSURE1", equipement.getAssureur());
        assertEquals("PRODUIT1", equipement.getAppellation());
    }

    @Test
    public void getTrackingInfo_2() throws TechnicalException {
        PersonnePhysiqueConsult pp = pp("M", 35, "33001", SituationFamilialeType.M);
        initConsulterPersonneClient(pp);

        initContrat();

        MockitoAnnotations.initMocks(this);

        final TrackingInfoDto trackingInfo = trackingFacade.getTrackingInfo();
        assertEquals("Monsieur", trackingInfo.getClientGenre());
        assertEquals("31 \u00e0 35 ans", trackingInfo.getClientAge());
        assertEquals(SituationFamilialeType.M.getLibelle(), trackingInfo.getClientSituationFamiliale());
        assertEquals("33", trackingInfo.getClientPostcode());

        assertNull(trackingInfo.getEquipementsRetraiteSupp());
    }

    @Test
    public void getTrackingInfo_3() throws TechnicalException {
        PersonnePhysiqueConsult pp = pp("M", 76, "33001", SituationFamilialeType.M);
        initConsulterPersonneClient(pp);

        initContrat();

        MockitoAnnotations.initMocks(this);

        final TrackingInfoDto trackingInfo = trackingFacade.getTrackingInfo();
        assertEquals("Monsieur", trackingInfo.getClientGenre());
        assertEquals("Plus de 75 ans", trackingInfo.getClientAge());
        assertEquals(SituationFamilialeType.M.getLibelle(), trackingInfo.getClientSituationFamiliale());
        assertEquals("33", trackingInfo.getClientPostcode());

        assertNull(trackingInfo.getEquipementsRetraiteSupp());
    }

    @Test
    public void getTrackingInfo_4() throws TechnicalException {
        PersonnePhysiqueConsult pp = pp("M", 76, null, SituationFamilialeType.M);
        initConsulterPersonneClient(pp);

        initContrat();

        MockitoAnnotations.initMocks(this);

        final TrackingInfoDto trackingInfo = trackingFacade.getTrackingInfo();
        assertEquals("Monsieur", trackingInfo.getClientGenre());
        assertEquals("Plus de 75 ans", trackingInfo.getClientAge());
        assertEquals(SituationFamilialeType.M.getLibelle(), trackingInfo.getClientSituationFamiliale());
        assertNull(trackingInfo.getClientPostcode());

        assertNull(trackingInfo.getEquipementsRetraiteSupp());
    }

    private PersonnePhysiqueConsult pp(String codeSexe, int age, String codePostal,
                                       SituationFamilialeType situationFamiliale) {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setCodeSexe(codeSexe);
        pp.setAge(age);
        pp.setCodePostal(codePostal);
        pp.setSituationFamiliale(situationFamiliale);
        return pp;
    }

    private ContratHeader contrat(String typeContrat, String identifiantAssure, String produit) {
        ContratHeader header = new ContratHeader();
        header.setTypeContrat(typeContrat);
        header.setIdentifiantAssure(identifiantAssure);
        header.setDescriptionFront(produit);
        return header;
    }
}
