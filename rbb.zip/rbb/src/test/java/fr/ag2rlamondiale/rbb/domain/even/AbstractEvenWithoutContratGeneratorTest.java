package fr.ag2rlamondiale.rbb.domain.even;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataEventJson;
import utils.data.DataTypeEvenementJson;
import utils.data.RandomData;

/**
 * The Class AbstractEvenWithoutContratGeneratorTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class AbstractEvenWithoutContratGeneratorTest {
	/* the abstractEvenGenerator mock*/
	@Mock
	private AbstractEvenWithoutContratGenerator abstractEvenWithoutContratGenerator;
	/* the numPersonne*/
	private String numPersonne = RandomData.getRandomStringSize10();
	/* the typeEvenement*/
	private TypeEvenementJson typeEvenement = new DataTypeEvenementJson().getDataTypeEvenementJson();
	/* the evenementsDejaEnregistres*/
	private List<EvenementJson> evenementsDejaEnregistres = new DataEventJson().getListDataEventJson();
	
	/**
	 * The Class Maclass.
	 */
	private class Maclass extends AbstractEvenWithContratGenerator {
	
		/** The Constant serialVersionUID. */
	
		/**
		 * Instantiates a new maclass.
		 */
		public Maclass() {
			super();
		}

		@Override
		public boolean evaluerEvenement(ContratHeader contrat) {
			// TODO Auto-generated method stub
			return false;
		}
	}
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		Maclass maClasse = new Maclass();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testNullResultGenerateNextEven() {
		TriggeringResult triggeringResult = new TriggeringResult();
		Mockito.doReturn(null).when(abstractEvenWithoutContratGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenWithoutContratGenerator.generateNextEven(triggeringResult);
		assertNull("wrong resultat not null", resultat);
	}
	
	@Test
	public void testNotNullResultGenerateNextEven() {
		TriggeringResult triggeringResult = new TriggeringResult();
		EvenementJson newEvenement = new DataEventJson().getDataEventJson();		
		Mockito.doReturn(newEvenement).when(abstractEvenWithoutContratGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenWithoutContratGenerator.generateNextEven(triggeringResult);
		assertNotNull("wrong resultat null", resultat);
	}
	
	@Test
	public void testEvaluerEvenement() {
		Mockito.doReturn(true).when(abstractEvenWithoutContratGenerator).evaluerEvenement(numPersonne);
		Boolean resultat = abstractEvenWithoutContratGenerator.evaluerEvenement(numPersonne);
		assertTrue("wrong result true", (resultat == true));	
	}
	
	@Test
	public void testNullResultGetEvenementsForType() {
		Mockito.doReturn(null).when(abstractEvenWithoutContratGenerator).getEvenementsForType(typeEvenement, evenementsDejaEnregistres);
		List<EvenementJson> resultat = abstractEvenWithoutContratGenerator.getEvenementsForType(typeEvenement, evenementsDejaEnregistres);
		assertNull("wrong resultat not null", resultat);
	}
	
	@Test
	public void testNotNullResultGetEvenementsForType() {
		Mockito.doReturn(evenementsDejaEnregistres).when(abstractEvenWithoutContratGenerator).getEvenementsForType(typeEvenement, evenementsDejaEnregistres);
		List<EvenementJson> resultat = abstractEvenWithoutContratGenerator.getEvenementsForType(typeEvenement, evenementsDejaEnregistres);
		assertNotNull("wrong resultat null", resultat);
	}
}
