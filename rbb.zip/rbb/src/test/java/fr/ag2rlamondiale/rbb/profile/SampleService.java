package fr.ag2rlamondiale.rbb.profile;

import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;

public class SampleService {

    @ProfileExecution(codeAction = CodeActionType.API_ACCESSIBILITE_FCT)
    public String hello() {
        return "Hello";
    }

    @ProfileExecution(codeAction = CodeActionType.API_ACCESSIBILITE_FCT)
    public String helloFailed() {
        throw new RuntimeException("failed");
    }

}
