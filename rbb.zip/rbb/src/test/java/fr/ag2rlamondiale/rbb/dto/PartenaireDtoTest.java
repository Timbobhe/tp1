/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.dto;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.junit.MockitoJUnitRunner;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;

/**
 * The Class PartenaireDtoTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class PartenaireDtoTest {
	@Test
	public void testBean() {
		new BeanTester().testBean(PartenaireDto.class);
	}

    // Testing equals() and hashCode()
    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(PartenaireDto.class).suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
    
    // Testing To String
    @Test
    public void testToString() {
    	PartenaireDto maClasse = new PartenaireDto();
    	assertNotNull(maClasse.toString());
    }
}
