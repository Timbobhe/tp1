/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static junit.framework.TestCase.*;
/**
 * The Class RbbEvenGeneratorsTest.
 */
public class RbbEvenGeneratorsTest {

	/* the RbbEvenGenerators mock */
    @InjectMocks
    private RbbEvenGenerators generators;
    /* init */
    @Before
    public void init() {
        generators = new RbbEvenGenerators();
        MockitoAnnotations.initMocks(this);
        generators.afterPropertiesSet();
    }

    @Test
    public void test_getEvenGenerator() {
        final List<String> typesEven =
                Arrays.asList("PRT_CGU", "MDP_CONF", "MDP_PND_3", "MDP_PND_1", "MDP_VDPP");
        typesEven.forEach(type -> assertNull(generators.getEvenGenerator(type)));
        assertNull(generators.getEvenGenerator("CODE_INCONNU"));
    }

    @Test
    public void test_getEvenGenerator_sousListe() {
        final List<String> typesEven = Arrays.asList("PRT_CGU", "ERE_CONF", "ERE_VDPP");
        typesEven.forEach(type -> assertNull(generators.getEvenGenerator(type)));
        assertNull(generators.getEvenGenerator("CODE_INCONNU"));
    }

    @Test
    public void test_generate_sousListe_NULL() throws Exception {

        final List<TypeEvenementJson> typesEven =
                Stream.of("PRT_CGU", "ERE_CONF", "ERE_BIA", "ERE_VDPP").map(TypeEvenementJson::new)
                        .collect(Collectors.toList());
        MockitoAnnotations.initMocks(this);
        Collection<ContratHeader> contrats = new ArrayList<>();
        List<EvenementJson> historiqueEvens = new ArrayList<>();
        final EvenementJson even =
                generators.generateNextEven(typesEven, "idGdi", "numPersonne", contrats, historiqueEvens);
        assertNull(even);
    }

}
