/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

/**
 * The Class ApiConfigTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class ApiConfigTest {
	
	/**The ApiConfig. */
	@InjectMocks
	private ApiConfig apiConfig;
	
	@Test
	public void testBean() {
		new BeanTester().testBean(ApiConfig.class);
	}
	
	@Test(expected = Test.None.class)
    public void testMultipartResolver() {
		apiConfig.multipartResolver();
    }
}
