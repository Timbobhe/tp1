/*
 * Cree le 10 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;

import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;
import utils.data.DataTriggeringResult;


/**
 * The Class TriggeringResultTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class TriggeringResultTest {
	/** The jeux donnees. */
	private TriggeringResult triggeringResult= new DataTriggeringResult().getTriggeringResult();
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		TriggeringResult maClasse = new TriggeringResult();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructorsWithParameters() {
		assertPojoMethodsFor(triggeringResult.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
}
