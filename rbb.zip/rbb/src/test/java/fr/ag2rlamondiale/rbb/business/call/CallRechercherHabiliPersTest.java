package fr.ag2rlamondiale.rbb.business.call;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;

import org.mockito.stubbing.Answer;
import org.mockito.junit.MockitoJUnitRunner;
import com.ag2r.common.exceptions.TechnicalException;


import fr.ag2rlamondiale.epinlib.domain.resp.ListeHabilitationPersonneDto;
import fr.ag2rlamondiale.epinlib.service.IRechercherHabiliPers1;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import utils.ITestCallIService;
import utils.data.DataListeHabilitationPersonneDto;
import utils.data.RandomData;


@RunWith(MockitoJUnitRunner.Silent.class) 
public class CallRechercherHabiliPersTest implements ITestCallIService {
	
	/** The rechercherHabiliPers1Service Mock. */
	@Mock
	private IRechercherHabiliPers1 rechercherHabiliPers1Service;
	
	/** The callRechercherHabiliPers Mock. */
	@InjectMocks
	private CallRechercherHabiliPers callRechercherHabiliPers;
	
	/** The id gdi null. */
	private String idGdiNull = RandomData.getRandomStringSize10();
	
	/**
	 * Test call nullable.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNullable() throws Exception {
		// TODO Auto-generated method stub
		String result = callRechercherHabiliPers.callRechercherHabiliPersService(idGdiNull);
		assertNull("wrong result null", result);
	}
	/**
	 * Test call Technicalexception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = Exception.class)
	public void testCallTechnicalException() throws Exception {
		mockCallRechercherHabiliPers1Service(Exception.class);
		callRechercherHabiliPers.callRechercherHabiliPersService(idGdiNull);
	}
	
	/**
	 * Test call exception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = Exception.class)
	public void testCallException() throws Exception {
		// TODO Auto-generated method stub
		mockCallRechercherHabiliPers1Service(EligibiliteException.class);
		callRechercherHabiliPers.callRechercherHabiliPersService(idGdiNull);
	}
	
	/**
	 * Test call not nullable.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNotNull() throws Exception {
		mockCallRechercherHabiliPersService();
		String result = callRechercherHabiliPers.callRechercherHabiliPersService(idGdiNull);
		assertNotNull("wrong result not null",result);
	}
	
	/**
	 * Mock Habili Pers 1 Service.
	 *
	 * @param class1 the class 1
	 * @throws TechnicalException the technical exception
	 */
	@SuppressWarnings("unchecked")
	private void mockCallRechercherHabiliPers1Service(Class<? extends Throwable> class1) throws TechnicalException {
		when(rechercherHabiliPers1Service.call(idGdiNull)).thenThrow(class1);
	}
	
	/**
	 * Mock Rechercher Habili Pers Service call.
	 *
	 * @throws TechnicalException the technical exception
	 */
	 private void mockCallRechercherHabiliPersService() throws TechnicalException {
		when(rechercherHabiliPers1Service.call(any(String.class)))
				.thenAnswer(new Answer<ListeHabilitationPersonneDto>() {
					@Override
					public ListeHabilitationPersonneDto answer(InvocationOnMock invocation) throws Throwable {
						return new DataListeHabilitationPersonneDto().getListeHabilitationPersonneDto();
					}
				});
	} 
}

