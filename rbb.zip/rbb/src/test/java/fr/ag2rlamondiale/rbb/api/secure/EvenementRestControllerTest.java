package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.business.IEvenementFacade;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class EvenementRestControllerTest {
    @Mock
    private IEvenementFacade evenementFacade;

    @InjectMocks
    EvenementRestController evenementController;

    @Test
    public void should_get_NextEven() throws TechnicalException {
        when(evenementFacade.generateNextEvenement(any(), any())).thenReturn(new EvenementJson(new TypeEvenementJson("ERE_CONF")));
        Assert.assertNotNull(evenementController.getNextEven());
        assertEquals("ERE_CONF", evenementController.getNextEven().getTypeEvenement().getCodeEvenement());
    }

}
