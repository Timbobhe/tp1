package fr.ag2rlamondiale.rbb.web.filter;

import fr.ag2rlamondiale.trm.cache.RequestScopedCacheManager;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.util.ReflectionTestUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import java.io.IOException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class ThreadLocalFilterTest {

    @InjectMocks
    ThreadLocalFilter threadLocalFilter;
    
    @Mock
    UserContextHolder userContextHolder;
    
    @Mock
    RequestScopedCacheManager requestScopedCacheManager;
    
    @Test
    public void doFilter() throws IOException, ServletException {
        ReflectionTestUtils.setField(threadLocalFilter, "confHeaders", "");
        threadLocalFilter.afterPropertiesSet();
        threadLocalFilter.init(null);
        
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        doNothing().when(requestScopedCacheManager).clearCaches();
        FilterChain filterChain = mock(FilterChain.class);
        doNothing().when(filterChain).doFilter(request, response);
        threadLocalFilter.doFilter(request, response, filterChain);
        assertNotNull(filterChain);
        threadLocalFilter.destroy();
    }
}
