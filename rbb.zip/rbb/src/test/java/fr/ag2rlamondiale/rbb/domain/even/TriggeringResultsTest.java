/*
 * Cree le 11 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import utils.data.DataContratHeader;
import utils.data.DataTriggeringResult;
import utils.data.DataTypeEvenementJson;
import utils.data.RandomData;



/**
 * The Class TriggeringResultsTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class TriggeringResultsTest {
	
	/**The triggeringResults. */
	@InjectMocks
	private TriggeringResults triggeringResults;
	
	/**The List of TriggeringResult. */
    private List<TriggeringResult> list = new ArrayList<>();
	/**The generator. */
    AbstractEvenWithoutContratGenerator generator;
	/**The idGdi. */
    String idGdi = RandomData.getRandomIdGDI();
	/**The numPersonne. */
    String numPersonne = RandomData.getRandomIdGDI();
	/**The typeEvenement. */
    TypeEvenementJson typeEvenement = new DataTypeEvenementJson().getDataTypeEvenementJson();
	/**The contrat. */
    ContratHeader contrat = new DataContratHeader().getDataContratHeader(CompartimentType.C1);
	/**The consumer. */
    Consumer<AbstractEvenGenerator> consumer;
    
    /**
	 * Sets the up.
	 *
	 *
	 */
	@Before
	public void setUp() {
		list.add(new DataTriggeringResult().getTriggeringResult());
	}
	
	@Test
	public void testBean() {
		new BeanTester().testBean(TriggeringResults.class);
	}

	@Test(expected = Test.None.class)
    public void testAdd() {
        triggeringResults.add(new DataTriggeringResult().getTriggeringResult());
    }
	
	@Test(expected = Test.None.class)
    public void testAddWithoutContrat() {
        triggeringResults.add(generator, idGdi, numPersonne, typeEvenement);
    }
	
	@Test(expected = Test.None.class)
    public void testAddContrat() {
        triggeringResults.add(generator, idGdi, numPersonne, typeEvenement, contrat);
    }
	
	@Test(expected = Test.None.class)
    public void testforEachGenerator() {
        triggeringResults.forEachGenerator(consumer);
    }
	
	@Test(expected = Test.None.class)
    public void testIsEmpty() {
		assertTrue(triggeringResults.isEmpty());
    }
	
	@Test(expected = Test.None.class)
    public void testStream() {
		assertNotNull("result null", triggeringResults.stream());
    }
}
