package fr.ag2rlamondiale.rbb.business.call;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.req.CriteresRecherchePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.service.IRechPersPhysClient8Service;
import utils.ITestCallIService;
import utils.data.DataPersonnePhysiqueDto;

/**
 * The Class CallRechPersPhysClientTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class CallRechPersPhysClientTest  implements ITestCallIService{
	
	/** The rech pers phys client 8 service. */
	@Mock
	private IRechPersPhysClient8Service rechPersPhysClient8Service;
	
	/** The call rech pers phys client. */
	@InjectMocks
	private CallRechPersPhysClient callRechPersPhysClient;
	
	/** The id gdi null. */
	private String idGdiNull;
	
	/** The data personne physique dto. */
	private DataPersonnePhysiqueDto dataPersonnePhysiqueDto = new DataPersonnePhysiqueDto();
	

	/**
	 * Test call nullable.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNullable() throws Exception {
		ListePersPhysDto listePersPhysDto = callRechPersPhysClient.callRechPersPhysClient8Service(idGdiNull);
		assertNull("wrong listePersPhysDto null",listePersPhysDto);
	}

	/**
	 * Test call technical exception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = TechnicalException.class)
	public void testCallTechnicalException() throws Exception {
		mockRechPersPhysClient8Service(TechnicalException.class);
		callRechPersPhysClient.callRechPersPhysClient8Service(idGdiNull);
	}

	/**
	 * Test call exception.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test(expected = Exception.class)
	public void testCallException() throws Exception {
		mockRechPersPhysClient8Service(Exception.class);
		callRechPersPhysClient.callRechPersPhysClient8Service(idGdiNull);
		
	}

	/**
	 * Test call not null.
	 *
	 * @throws Exception the exception
	 */
	@Override
	@Test
	public void testCallNotNull() throws Exception {
		mockNaviguerClientsContrats4ServiceCall();
		ListePersPhysDto listePersPhysDto = callRechPersPhysClient.callRechPersPhysClient8Service(idGdiNull);
		assertNotNull("wrong listePersPhysDto not null",listePersPhysDto);
	}

	/**
	 * Mock rech pers phys client 8 service.
	 *
	 * @param class1 the class 1
	 * @throws TechnicalException the technical exception
	 */
	@SuppressWarnings("unchecked")
	private void mockRechPersPhysClient8Service(Class<? extends Throwable> class1) throws TechnicalException {
		when(rechPersPhysClient8Service.call(any(CriteresRecherchePersPhysDto.class))).thenThrow(class1);
	}
	
	/**
	 * Mock naviguer clients contrats 4 service call.
	 *
	 * @throws TechnicalException the technical exception
	 */
	private void mockNaviguerClientsContrats4ServiceCall() throws TechnicalException {
		when(rechPersPhysClient8Service.call(any(CriteresRecherchePersPhysDto.class)))
				.thenAnswer(new Answer<ListePersPhysDto>() {

					@Override
					public ListePersPhysDto answer(InvocationOnMock invocation) throws Throwable {
						
						ListePersPhysDto listePersPhysDto = new ListePersPhysDto();
						listePersPhysDto.getListePP().add(dataPersonnePhysiqueDto.getPersonneDto());
						return listePersPhysDto;
					}
				});
	}
	
}

