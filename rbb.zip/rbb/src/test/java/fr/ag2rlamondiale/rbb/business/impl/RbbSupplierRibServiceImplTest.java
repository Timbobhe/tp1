/*
 * Cree le 14 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Value;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.rbb.business.call.CallNaviguerClientsContrats;
import fr.ag2rlamondiale.rbb.business.call.CallRechPersPhysClient;
import fr.ag2rlamondiale.rbb.business.call.CallRechercherHabiliPers;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import fr.ag2rlamondiale.rbb.utils.MockUserContext;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.MetierContratType;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Sets;
import utils.data.DataClientDto;
import utils.data.DataContratDto;
import utils.data.DataContratHeader;

/**
 * The Class RbbSupplierRibServiceImplTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class RbbSupplierRibServiceImplTest {
	@InjectMocks
	RbbSupplierRibServiceImpl rbbSupplierRibServiceImpl;
	
	@InjectMocks
    RechercherHabiliFacadeImpl habiliFacade;
	
	@Mock
    private IRechercherHabiliPersClient client;
	
	@Mock
	CallRechercherHabiliPers callRechercherHabiliPers;
	
	@Mock
	CallRechPersPhysClient callRechPersPhysClient8;
	
	@Mock
	private UserContextHolder userContextHolder;
	
	@Mock
	CallNaviguerClientsContrats callNaviguerClientsContrats;
	
	@Mock
	@Value("#{${fr.ag2rlamondiale.produits.mdpro.libelle}}")
	Map<String, String> libelleProduitMdproMap;
	
	@Mock
	@Value("#{${fr.ag2rlamondiale.produits.retraite.libelle}}")
	Map<String, String> libelleProduitRetraiteSupMap;
	
	private ContratHeader contratHeaderC1;
	private ContratHeader contratHeaderC4;
	private ContratComplet contratCompletC1;
	private ContratComplet contratCompletC4;
	private ContratComplet contratCompletC3;
	private DataContratHeader dataContratHeader = new DataContratHeader() ;
	private static final String IDGDI = "IDGDI";
	private static final String NUMPP = "NUMPP";
	/** The data client dto. */
	private DataClientDto dataClientDto = new DataClientDto();

	/** The client dto. */
	private ClientDto clientDto;
	
	@Before
	 public void init() {
		contratHeaderC1 =	dataContratHeader.getDataContratHeader(CompartimentType.C1) ;
		contratHeaderC4 =	dataContratHeader.getDataContratHeader(CompartimentType.C4) ;

		contratCompletC1 = new ContratComplet();
		contratCompletC1.setContratHeader(contratHeaderC1);
		
		contratCompletC4 = new ContratComplet();
		contratCompletC4.setContratHeader(contratHeaderC4);
		
		contratCompletC3 = new ContratComplet();
		clientDto = dataClientDto.getClientDto();
	 }
	
	private static PersonnePhysique buildPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setCivilite("Monsieur");
        pp.setIdGdi(IDGDI);
        pp.setNom("Nom");
        pp.setNumeroPersonneEre(NUMPP);
        pp.setNumeroPersonneMdpro(NUMPP);
        pp.setPrenom("Prenom");
        return pp;
    }
	private UserContext createUserContextMultiEquipe(String ere, String mdPro) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(ere);
        userContext.setNumeroPersonneMdpro(mdPro);
        userContext.setIdGdi("IDGDI");
        Partenaire part = new Partenaire();
        part.setCodePartenaire("49504");
        userContext.setPartenaire(part);
        return userContext;
    }
	
	@Test
    public void testGetClientIdGdi() {
        PersonnePhysique out = buildPersonnePhysique();
        when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("ere", "mdpro"));
        assertEquals(out.getIdGdi(), rbbSupplierRibServiceImpl.getClientIdGdi());
    }
	
	private static PersonnePhysiqueDto buildPersonnePhysiqueDTO() {
		PersonnePhysiqueDto pp = new PersonnePhysiqueDto();
        pp.setNom("Nom");
        pp.setPrenom("Prenom");
        return pp;
    }
	
	@Test
    public void testGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		listePP.add(buildPersonnePhysiqueDTO());
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		assertNotNull(rbbSupplierRibServiceImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test(expected = EligibiliteException.class)
    public void testEmptyListGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		assertNotNull(rbbSupplierRibServiceImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test(expected = EligibiliteException.class)
    public void testEligibiliteExceptionGetPersonnePhysiqueDto() throws EligibiliteException, TechnicalException {
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn(IDGDI);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenThrow(new TechnicalException());
		assertNotNull(rbbSupplierRibServiceImpl.getPersonnePhysiqueDto(IDGDI));
    }
	
	@Test
    public void testmappingContratsDtoToContratsHeaderDto() {
    	List<ContratHeaderDto> contratsHeaderDto = new ArrayList<ContratHeaderDto>();
    	ContratDto contratDto = new DataContratDto().getContratDto("RC01V01");
    	ContratHeader contratHeaderDto = new DataContratHeader().getDataContratHeader(CompartimentType.C1);
        rbbSupplierRibServiceImpl.setLibelleContrat(contratDto, contratHeaderDto);
        rbbSupplierRibServiceImpl.setTypeVersionContrat(contratDto, contratHeaderDto);
        Assert.assertNotEquals(contratsHeaderDto, rbbSupplierRibServiceImpl.mappingContratsDtoToContratsHeaderDto(clientDto.getListeContrat()));
        Assert.assertNotNull(rbbSupplierRibServiceImpl.mappingContratsDtoToContratsHeaderDto(null));
	}
	
	@Test
    public void testGetMetierContratPrincipale() {
        Assert.assertEquals(MetierContratType.EPARGNE, rbbSupplierRibServiceImpl.getMetierContratPrincipale());
        Assert.assertNotNull("MetierContratPrincipale null", rbbSupplierRibServiceImpl.getMetierContratPrincipale());
    }
	
	@Test
    public void testGetMetiersContratSecondaires() {
        Assert.assertEquals(Sets.set(MetierContratType.RETRAITE_SUPPLEMENTAIRE), rbbSupplierRibServiceImpl.getMetiersContratSecondaires());
        Assert.assertNotNull("MetiersContratSecondaires null", rbbSupplierRibServiceImpl.getMetiersContratSecondaires());
	}
	
	@Test(expected = Exception.class)
    public void testRecupererContrats() throws TechnicalException, EligibiliteException{
        Assert.assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.EPARGNE, Constantes.PRINCIPAL));
        Assert.assertNotEquals(0, rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.EPARGNE, Constantes.PRINCIPAL).size());
    }
	
	@Test
    public void testRecupererContratsEpargne() throws TechnicalException, EligibiliteException{
		 when(userContextHolder.get()).thenReturn(createUserContextMultiEquipe("ere", "mdpro"));
		when(callRechercherHabiliPers.callRechercherHabiliPersService(anyString())).thenReturn("P10000");
		ListePersPhysDto retour = new ListePersPhysDto();
		List<PersonnePhysiqueDto> listePP = new ArrayList<>();
		listePP.add(buildPersonnePhysiqueDTO());
		retour.setListePP(listePP);
		when(callRechPersPhysClient8.callRechPersPhysClient8Service(anyString())).thenReturn(retour);
		Mockito.doReturn(clientDto).when(callNaviguerClientsContrats).callNaviguerClientsContrats4(anyString(),any(PersonnePhysiqueDto.class));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.RETRAITE_SUPPLEMENTAIRE, Constantes.SECONDAIRE));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.EPARGNE, Constantes.PRINCIPAL));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.PREVOYANCE, Constantes.PRINCIPAL));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.RETRAITE_SUPPLEMENTAIRE, Constantes.PRINCIPAL));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.CM, Constantes.PRINCIPAL));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.EPARGNE, Constantes.SECONDAIRE));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.PREVOYANCE, Constantes.SECONDAIRE));
		assertNotNull(rbbSupplierRibServiceImpl.recupererContrats(MetierContratType.CM, Constantes.SECONDAIRE));

    }
	
	@Test(expected = Exception.class)
    public void testRecupererPrincipauxContrats() throws TechnicalException {
		List<ContratHeader> ListContratHeader = new ArrayList<ContratHeader>();
        Assert.assertEquals(ListContratHeader, 
        		rbbSupplierRibServiceImpl.recupererPrincipauxContrats(MetierContratType.EPARGNE));
    }
	
	@Test(expected = Exception.class)
    public void testRecupererSecondaireContrats() throws TechnicalException {
		List<ContratHeader> ListContratHeader = new ArrayList<ContratHeader>();
        Assert.assertEquals(ListContratHeader, 
        		rbbSupplierRibServiceImpl.recupererContratsSecondaires(MetierContratType.EPARGNE));
    }
	
	@Test
    public void testIsRetraiteSupp() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isRetraiteSupp(contratHeaderC1));
        contratHeaderC1.setTypeContrat("RA01");    contratHeaderC1.setNumGenContrat("V01");
        Assert.assertFalse("isRetraiteSupp true", rbbSupplierRibServiceImpl.isRetraiteSupp(contratHeaderC1));
        Assert.assertFalse("isRetraiteSupp true", rbbSupplierRibServiceImpl.isRetraiteSupp(null));

    }
	
	@Test
    public void testIsContratsEligible() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isContratsEligible(contratHeaderC1));
    }
	
	@Test
    public void testIsContratsAuthorized() {
        Assert.assertEquals(true, rbbSupplierRibServiceImpl.isContratsAuthorized(contratHeaderC1));
    }
	
	@Test
    public void testTrueResultIsContratPacteAffichable() {
		contratCompletC3.setContratHeader(new DataContratHeader().getDataContratHeaderWithOneCompartiment(CompartimentType.C1));
        Assert.assertFalse(rbbSupplierRibServiceImpl.isContratPacteAffichable(contratCompletC3));
    }
	
	@Test
    public void testFalseResultIsContratPacteAffichable() {
		contratCompletC3.setContratHeader(new DataContratHeader().getDataContratHeaderWithoutCompartiment());
        Assert.assertFalse(rbbSupplierRibServiceImpl.isContratPacteAffichable(contratCompletC3));
    }
	
	@Test(expected = IllegalArgumentException.class)
    public void testExceptionIsContratPacteAffichable() {
        Assert.assertFalse(rbbSupplierRibServiceImpl.isContratPacteAffichable(contratCompletC1));
        Assert.assertFalse(rbbSupplierRibServiceImpl.isContratPacteAffichable(contratCompletC4));
    }
	
	@Test
    public void testIsContratEpargne() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isContratEpargne(contratHeaderC1));
        contratHeaderC1.setTypeContrat("RC01");    contratHeaderC1.setNumGenContrat("V01");
        Assert.assertEquals(true, rbbSupplierRibServiceImpl.isContratEpargne(contratHeaderC1));
    }
	
	@Test
    public void testIsContratCertificatMutualiste() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isContratCertificatMutualiste(contratHeaderC1));
        contratHeaderC1.setTypeContrat("5200");    contratHeaderC1.setNumGenContrat("V01");
        Assert.assertFalse("isContratCertificatMutualiste null", rbbSupplierRibServiceImpl.isContratCertificatMutualiste(contratHeaderC1));
    }
	
	@Test
    public void testIsContratPrevoyanceIndividuelle() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isContratPrevoyance(contratHeaderC1));
        contratHeaderC1.setTypeContrat("AN01");    contratHeaderC1.setNumGenContrat("V01");
        Assert.assertTrue("isContratPrevoyanceIndividuelle null", rbbSupplierRibServiceImpl.isContratPrevoyance(contratHeaderC1));
    }
	
	@Test
    public void testIsContratNonPacteAffichable() {
        Assert.assertEquals(false, rbbSupplierRibServiceImpl.isContratNonPacteAffichable(contratCompletC1));
        Assert.assertFalse("isContratNonPacteAffichable null", rbbSupplierRibServiceImpl.isContratNonPacteAffichable(contratCompletC1));
    }
}
