/*
 * Cree le 09 juin. 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package fr.ag2rlamondiale.rbb.domain.even;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import java.util.Collection;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import pl.pojo.tester.api.assertion.Method;
import utils.data.DataEventJson;

/**
 * The Class AbstractEvenGeneratorTest.
 */
@RunWith(MockitoJUnitRunner.class)
public class AbstractEvenGeneratorTest {
	
	/**
	 * The Class Maclass.
	 */
	private class Maclass extends AbstractEvenGenerator {
	
		/**
		 * Instantiates a new maclass.
		 */
		public Maclass() {
			super();
		}

		@Override
		public EvenementJson generateNextEven(TriggeringResult result) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
				Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
			// TODO Auto-generated method stub
			
		}
	
	}
	/* the abstractEvenGenerator mock*/
	@Mock
	private AbstractEvenGenerator abstractEvenGenerator;
	
	/**
	 * Are well implemented.
	 */
	@Test
	public void testConstructors() {
		Maclass maClasse = new Maclass();
		assertPojoMethodsFor(maClasse.getClass()).testing(Method.CONSTRUCTOR).areWellImplemented();
	}
	
	@Test
	public void testNullResultGenerateNextEven() {
		TriggeringResult triggeringResult = new TriggeringResult();
		Mockito.doReturn(null).when(abstractEvenGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenGenerator.generateNextEven(triggeringResult);
		assertNull("wrong resultat not null", resultat);
	}
	
	@Test
	public void testNotNullResultGenerateNextEven(){
		TriggeringResult triggeringResult = new TriggeringResult();
		EvenementJson newEvenement = new DataEventJson().getDataEventJson();		
		Mockito.doReturn(newEvenement).when(abstractEvenGenerator).generateNextEven(triggeringResult);
		EvenementJson resultat = abstractEvenGenerator.generateNextEven(triggeringResult);
		assertNotNull("wrong resultat null", resultat);
	}

}
