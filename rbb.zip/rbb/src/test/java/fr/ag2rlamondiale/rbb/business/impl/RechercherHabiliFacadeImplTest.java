package fr.ag2rlamondiale.rbb.business.impl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.client.RestClientException;

@RunWith(MockitoJUnitRunner.class)
public class RechercherHabiliFacadeImplTest {
    private static final String IDGDI = "IDGDI";
    private static final String NUMPP = "NUMPP";

    @InjectMocks
    RechercherHabiliFacadeImpl habiliFacade;

    @Mock
    private IRechercherHabiliPersClient client;

    @Test
    public void rechercherParIdGdi() {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setIdGdi(IDGDI);

        PersonnePhysique out = buildPersonnePhysique();

        when(client.rechercherHabilitation(in)).thenReturn(out);

        PersonnePhysique actual = habiliFacade.rechercherParIdGdi(IDGDI);

        assertEquals(out, actual);
    }

    @Test
    public void rechercherParNumPers() throws RestClientException {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setNumeroPersonne(NUMPP);
        in.setCodeSilo(CodeSiloType.ERE);

        PersonnePhysique out = buildPersonnePhysique();

        when(client.rechercherHabilitation(in)).thenReturn(out);

        PersonnePhysique actual = habiliFacade.rechercherParNumPers(NUMPP, CodeSiloType.ERE);

        assertEquals(out, actual);
    }

    private static PersonnePhysique buildPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setCivilite("Monsieur");
        pp.setIdGdi(IDGDI);
        pp.setNom("Nom");
        pp.setNumeroPersonneEre(NUMPP);
        pp.setNumeroPersonneMdpro(NUMPP);
        pp.setPrenom("Prenom");
        return pp;
    }
}
