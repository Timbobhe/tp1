package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.business.impl.DocumentationFacadeImpl;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.client.soap.IDocumentationClient;
import fr.ag2rlamondiale.trm.client.soap.config.AttachmentResponse;
import fr.ag2rlamondiale.trm.domain.CodeCategorieDocType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.document.DocumentMDProRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.documentation.DocGedEreType;
import fr.ag2rlamondiale.trm.domain.documentation.EreDocumentsSetDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.DocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.RechDocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ref.Fiche;
import fr.ag2rlamondiale.trm.domain.documentation.ref.RechercherDocsReferenceDto;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IDocumentationClientAsync;
import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Test de la classe DocumentFacadeImpl
 */
@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class DocumentationFacadeImplTest {
    @Mock
    IDocumentationClientAsync documentationClientAsync;

    @Mock
    IDocumentationClient documentationClient;

    @Mock
    IContratsClient contratsClient;

    @Mock
    IContratFacade contratFacade;

    @InjectMocks
    DocumentationFacadeImpl documentationFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Mock
    private UserContextHolder userContextHolder;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void testRechercherDocumentsEre() throws DocumentException, TechnicalException {
        // Given
        ReflectionTestUtils.setField(documentationFacade, "plusAnciennDateDocGedEreMap", new HashMap<>());
        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA));

        when(documentationClientAsync.rechercherTousDocsSharepoint(any(RechercherDocsReferenceDto.class)))
                .thenAnswer((Answer<CompletableFuture<List<Fiche>>>) invocation -> {
                    Fiche fiche = new Fiche();
                    fiche.setCodeIsin(MOCKDATA);
                    fiche.setCategorieDoc(CodeCategorieDocType.SPECIFIQUE.getLibelle());
                    fiche.setCodeProduit(MOCKDATA);
                    fiche.setCodeSupport(MOCKDATA);
                    fiche.setCodeTypeDocument(DocumentMDProRefType.CB.name());
                    fiche.setNumContrat(MOCKDATA);
                    fiche.setNumPersonne(MOCKDATA);
                    fiche.setTitre(MOCKDATA);
                    return CompletableFuture.completedFuture(Arrays.asList(fiche));
                });

        when(documentationClientAsync.rechercherDocGed(any(RechDocGEDDto.class)))
                .thenAnswer((Answer<CompletableFuture<List<DocGEDDto>>>) invocation -> {
                    DocGEDDto docGED = new DocGEDDto();
                    docGED.setIdDoc(MOCKDATA);
                    docGED.setNatureDoc(MOCKDATA);
                    docGED.setCodeSiloGED("ERE");
                    docGED.setDateCreation(new Date());
                    docGED.setDateIndexation(new Date());
                    docGED.setIdContrat(MOCKDATA);
                    docGED.setIdPersPhysique(MOCKDATA);
                    docGED.setTaille("1024");
                    return CompletableFuture.completedFuture(Arrays.asList(docGED));
                });

        /*when(contratFacade.rechercherContratParId(any(String.class))).thenAnswer(
                (Answer<ContratHeader>) invocation -> {
                    ContratHeader contrat = new ContratHeader();
                    contrat.setId(MOCKDATA);
                    return contrat;
                });*/

        when(documentationClientAsync.ajouterPropsDocGED(any(DocGEDDto.class)))
                .thenAnswer((Answer<CompletableFuture<DocGEDDto>>) invocation -> CompletableFuture.completedFuture(createDocGEDDto()));

        // When
        EreDocumentsSetDto retour = documentationFacade.rechercherDocumentsEre(buildCompartiment(CodeSiloType.ERE));

        // Then
        Assert.assertNotNull(retour);
        assertEquals(7, retour.getGestion().size());
        assertEquals(MOCKDATA,
                retour.getGestion().get(DocGedEreType.IFU).get(0).getIdDoc());
        Assert.assertTrue(retour.getSectionsEnErreur().isEmpty());
    }

    private Compartiment buildCompartiment(CodeSiloType codeSilo) {
        final Compartiment compartiment = new Compartiment();
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(codeSilo);
        contratHeader.addCompartiment(compartiment);
        return compartiment;
    }

    @Test
    public void testRechercherNoticeInformationSalarie() throws DocumentException, TechnicalException {
        // Given
        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA));
        when(documentationClient.rechercherDocsSharepoint(any(RechercherDocsReferenceDto.class)))
                .thenAnswer((Answer<Fiche>) invocation -> {
                    return createFiche();
                });

        // When
        Fiche retour = documentationFacade.rechercherNoticeInformationSalarie(createContrat());

        // Then
        Assert.assertNotNull(retour);
        assertEquals(DocumentRefType.NS.name(), retour.getCodeTypeDocument());
        assertEquals(MOCKDATA, retour.getCodeIsin());
    }

    @Test
    public void testTelechargerNoticeInformationSalarie() throws DocumentException, TechnicalException, IOException {
        // Given
        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA));

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        //InputStream in = DocumentationFacadeImplTest.class.getResourceAsStream("/fixtures/NoticeInformationsSalarie.pdf");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        //IOUtils.copy(in, baos);
        AttachmentResponse attachmentResponse = new AttachmentResponse();
        attachmentResponse.setAttachment(baos.toByteArray());

        when(documentationClient.consulterDocsSharepoint(any(CodeSiloType.class), anyString()))
                .thenAnswer((Answer<AttachmentResponse>) invocation -> attachmentResponse);

        // When
        documentationFacade.downloadDocumentSharepoint(createFiche(), outputStream);

        // Then
        assertArrayEquals(baos.toByteArray(), outputStream.toByteArray());
    }

    @Test
    public void should_find_last_document_ere() throws TechnicalException {
        documentationFacade.rechercherDernierDocumentEre(any(RechDocGEDDto.class));

        verify(documentationClient, times(1)).rechercherDernierDocGed(any());
    }

    private UserContext createUserContext(String numPP) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setNumeroPersonneMdpro(numPP);
        userContext.setCurrentCodeSilo(CodeSiloType.ERE.name());
        return userContext;
    }

    private ContratHeader createContrat() {
        ContratHeader contrat = new ContratHeader();
        contrat.setCodeSilo(CodeSiloType.ERE);
        contrat.setId(MOCKDATA);
        contrat.setCodeFiliale(MOCKDATA);
        contrat.setIdContractante(MOCKDATA);
        contrat.setCodeProduit(MOCKDATA);
        return contrat;
    }

    private Fiche createFiche() {
        Fiche fiche = new Fiche();
        fiche.setCodeIsin(MOCKDATA);
        fiche.setCategorieDoc(CodeCategorieDocType.SPECIFIQUE.getLibelle());
        fiche.setCodeProduit(MOCKDATA);
        fiche.setCodeSupport(MOCKDATA);
        fiche.setCodeTypeDocument(DocumentRefType.NS.name());
        fiche.setNumContrat(MOCKDATA);
        fiche.setNumPersonne(MOCKDATA);
        fiche.setTitre("testTelechargerNoticeInformationSalarie");
        fiche.setLien("http://gesdoc-ru.appli/centrepdf/Bibliothque de stockage des PDFs DERE/AG2R-LA-MONDIALE-notice-info-salarié-RG151887159.pdf");
        fiche.setCodeSilo(CodeSiloType.ERE);
        return fiche;
    }

    private DocGEDDto createDocGEDDto() {
        DocGEDDto docGED = new DocGEDDto();
        docGED.setIdDoc(MOCKDATA);
        docGED.setNatureDoc(MOCKDATA);
        docGED.setCodeSiloGED("MDP");
        docGED.setDateCreation(new Date());
        docGED.setDateIndexation(new Date());
        docGED.setIdContrat(MOCKDATA);
        docGED.setIdPersPhysique(MOCKDATA);
        docGED.setTaille("1024");
        return docGED;
    }

    public static class MockUserContext extends UserContext {
        private static final long serialVersionUID = 1L;
        private String numeroPersonneEre;
        private String numeroPersonneMdpro;

        @Override
        public String getNumeroPersonneEre() {
            return numeroPersonneEre;
        }

        public void setNumeroPersonneEre(String numeroPersonneEre) {
            this.numeroPersonneEre = numeroPersonneEre;
        }

        @Override
        public String getNumeroPersonneMdpro() {
            return numeroPersonneMdpro;
        }

        public void setNumeroPersonneMdpro(String numeroPersonneMdpro) {
            this.numeroPersonneMdpro = numeroPersonneMdpro;
        }
    }
}
