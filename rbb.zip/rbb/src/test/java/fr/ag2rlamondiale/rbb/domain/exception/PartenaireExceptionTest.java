package fr.ag2rlamondiale.rbb.domain.exception;

import static org.junit.Assert.assertNotNull;
import static pl.pojo.tester.api.assertion.Assertions.assertPojoMethodsFor;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;

import pl.pojo.tester.api.assertion.Method;

/**
 * 
 * The Class PartenaireExceptionTest
 *
 */
@RunWith(MockitoJUnitRunner.class)
public class PartenaireExceptionTest {

	/** The rule. */
	@Rule
	public MockitoRule rule = MockitoJUnit.rule();

	/**
	 * Test constructors.
	 */
	@Test
	public void testCconstructors() {
		assertPojoMethodsFor(PartenaireException.class).testing(Method.CONSTRUCTOR).areWellImplemented();
	}

	/**
	 * Test enum.
	 */
	@Test
	public void testEnum() {

		assertNotNull("wrong enum ErrorCode ", PartenaireException.ErrorCode.values());
	}
}
