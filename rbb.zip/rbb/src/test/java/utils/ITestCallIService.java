/*
 * Cree le 18 mai 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package utils;

/**
 * The Interface ITestCall.
 * Definition des methodes d base pour les call du type extends IService<?, ?>
 */
public interface ITestCallIService {

	/**
	 * Test call nullable.
	 *
	 * @throws Exception the exception
	 */
	public void testCallNullable() throws Exception ;
	
	/**
	 * Test call technical exception.
	 *
	 * @throws Exception the exception
	 */
	public void testCallTechnicalException() throws Exception ;
	
	/**
	 * Test call exception.
	 *
	 * @throws Exception the exception
	 */
	public void testCallException() throws Exception ;
	
	/**
	 * Test call not null.
	 *
	 * @throws Exception the exception
	 */
	public void testCallNotNull() throws Exception ;
}
