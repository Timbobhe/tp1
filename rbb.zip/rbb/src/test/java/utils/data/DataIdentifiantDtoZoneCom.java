package utils.data;

import org.junit.Ignore;


import fr.ag2rlamondiale.epinlib.domain.sub.rest.zonecom.IdentifiantDto;
import fr.ag2rlamondiale.rib.utils.Constantes;
/**
 * The Class DataIdentifiantDtoZoneCom.
 */
@Ignore("Classe de données pour les tests")
public class DataIdentifiantDtoZoneCom {
	
	/** The id. */
	private String idSilo = RandomData.getRandomStringSize10CommenceParP();
    /** The code appli. */
    private String codeAppli = Constantes.CODE_APPLI_EGESPER_MDPRO;
    
    public IdentifiantDto getIdentifiantDto() {
    	 IdentifiantDto  identifiantDto = new  IdentifiantDto();
    	 identifiantDto.setIdSilo(idSilo);
    	 identifiantDto.setCodeAppli(codeAppli);
    	 return  identifiantDto;
    }
}