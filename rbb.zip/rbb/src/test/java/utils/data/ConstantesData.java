package utils.data;

import java.util.Arrays;
import java.util.List;

import org.junit.Ignore;

/**
 * The Class ConstantesData.
 */
@Ignore("Classe de données")
public class ConstantesData {
	
	/** The Constant listPrenomsGarcon. */
	public static final List<String> listPrenomsGarcon = Arrays
			.asList(new String[] { "Gabriel", "Raphaël", "Léo", "Louis", "Adam", "Arthur", "Jules", "Hugo", "Maël",
					"Ethan", "Liam", "Paul", "Nathan", "Gabin", "Sacha", "Noah", "Tom", "Mohamed", "Théo" });

	/** The Constant listPrenomsFille. */
	public static final List<String> listPrenomsFille = Arrays.asList(
			new String[] { "Emma ", "Jade ", "Louise ", "Alice ", "Chloé ", "Inès ", "Lina ", "Léa ", "Rose ", "Léna ",
					"Anna ", "Mila ", "Mia ", "Ambre ", "Elena ", "Julia ", "Manon ", "Juliette ", "Lou ", "Zoé "

			});

	/** The Constant listNomFamille. */
	public static final List<String> listNomFamille = Arrays.asList(new String[] { "MARTIN", "BERNARD", "THOMAS",
			"PETIT", "ROBERT", "RICHARD", "DURAND", "DUBOIS", "MOREAU", "LAURENT", "SIMON", "MICHEL", "LEFEBVRE",
			"LEROY", "ROUX", "DAVID", "BERTRAND", "MOREL", "FOURNIER", "GIRARD"

	});

	/** The Constant listeRaisonSociale. */
	public static final List<String> listeRaisonSociale = Arrays.asList(new String[] { "PSA AUTOMOBILES SA", "AIRBUS",
			"RENAULT SAS", "ELECTRICITE DE FRANCE", "ENGIE", "TOTAL MARKETING FRANCE", "ORANGE",
			"TOTAL RAFFINAGE FRANCE", "CSF", "SNCF MOBILITES", "LA FRANCAISE DES JEUX", "CMA CGM", "SOCIETE AIR FRANCE",
			"ITM ALIMENTAIRE INTERNATIONAL", "CARREFOUR HYPERMARCHES", "ESSO SOCIETE ANONYME FRANCAISE", "ENEDIS",
			"AUTOMOBILES PEUGEOT", "AIRBUS OPERATIONS", "AUCHAN HYPERMARCHE" });

	/** The Constant listePays. */
	public static final List<String> listePays = Arrays.asList(new String[] { "Etats-Unis", "Chine", "Japon",
			"Allemagne", "Inde", "Royaume-Uni", "France", "Italie", "Brésil", "Canada", "Corée du Sud", "Russie",
			"Espagne", "Australie", "Mexique", "Indonésie", "Pays-Bas", "Arabie saoudite", "Suisse", "Turquie" });

	/** The Constant listeVille. */
	public static final List<String> listeVille = Arrays.asList(new String[] { "Paris", "Marseille", "Lyon", "Toulouse",
			"Nice", "Nantes", "Montpellier", "Strasbourg", "Bordeaux", "Lille13", "Rennes", "Reims", "Saint-Étienne",
			"Le Havre", "Toulon", "Grenoble", "Dijon", "Angers", "Nîmes", "Villeurbanne" });
	
	/** The Constant listeCodeAppli. */
	public static final List<String> listeCodeAppli = Arrays
			.asList(new String[] { "A1549", "A1672", "A1649", "A0346", "A1427" });

	/** The Constant listeEtabBancaire. */
	public static final List<String> listeEtabBancaire = Arrays
			.asList(new String[] { "Allianz Banque ", "AXA Banque ", "Banque Accord ", "Banque Casino ",
					"Banque de Savoie ", "Banque Fédérale Mutualiste (BFM) ", "Barclays ", "BNP Paribas ",
					"BRED (Banque populaire) ", "Caisse d'Epargne ", "CCSO ", "Cetelem ", "CIC ", "Crédit agricole ",
					"Crédit coopératif ", "Crédit du nord ", "Crédit Foncier ", "Crédit mutuel ", "Fortis Banque " });
	
	/** The Constant listeExtensionMail. */
	public static final List<String> listeExtensionMail = Arrays
			.asList(new String[] { "Neuf.fr", "Aol.com",
	"Aliceadsl.fr"
	,"Att.net"
	,"Bluewin.ch"
	,"Bouygtel.fr"
	,"Bbox.fr.fr"
	,"Club-internet.fr"
	,"Free.fr"
	,"Gmail.com"
	,"Hotmail.com"
	,"Laposte.fr"
	,"Netcourrier.com"
	,"numericable.fr"
	,"Orange.fr"
	,"Outlook.com"
	,"Sympatico.ca"
	,"sfr.fr"
	,"Tiscali.fr"
	,"Verizon.net"
	,"Voila.fr"
	,"Wanadoo.fr"
	,"Yahoo.com"
			});
	
	
	
	
}
