package utils.data;


import java.util.Date;
import java.util.Random;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.HabilitationPartDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.IdNumeriqueDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.InfoCanalDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;

/**
 * The Class RandomData.
 */
@Ignore("Classe de données pour les tests")
public class RandomData extends RandomDates{
	
	/**
	 * Gets the random HabilitationPartDto.
	 *
	 * @return the random HabilitationPartDto.
	 */
	public static HabilitationPartDto getRandomHabilitationPartDto() {
		return new DataHabilitationPartDto().getHabilitationPartDto();
	}
	
	/**
	 * Gets the random IdNumeriqueDto.
	 *
	 * @return the random IdNumeriqueDto.
	 */
	public static IdNumeriqueDto getRandomIdNumeriqueDto() {
		return new DataIdNumeriqueDto().getIdNumeriqueDto();
	}
	
	/**
	 * Gets the random InfoCanalDto.
	 *
	 * @return the random InfoCanalDto
	 */
	public static InfoCanalDto getRandomInfoCanalDto() {
		return new DataInfoCanalDto().getInfoCanalDto();
	}
	
	/**
	 * Gets the random date 2020.
	 *
	 * @return the random date 2020
	 */
	public static Date getRandomDate_2020() {
		return createRandomDate(2020);
	}
	
	/**
	 * Gets the random label value.
	 *
	 * @return the random label value
	 */
	public static LabelValue getRandomLabelValue() {
		return new LabelValue(getRandomStringSize10(),getRandomString(20));
	}
	
	/**
	 * Gets the random date 2019 2020.
	 *
	 * @return the random date 2019 2020
	 */
	public static Date getRandomDate_2019_2020() {
		return RandomData.createRandomDate(2019, 2020);
	}
	
	/**
	 * Gets the random double.
	 *
	 * @return the random double
	 */
	public static Double getRandomDouble() {
		return RandomUtils.nextDouble();
	}
	
	/**
	 * Gets the random string code appli.
	 *
	 * @return the random string code appli
	 */
	public static String getRandomStringCodeAppli() {
		int index = getRandomNumberInRange(0,ConstantesData.listeCodeAppli.size()-1);
		return ConstantesData.listeCodeAppli.get(index);
	}
	
	/**
	 * Gets the random number in range.
	 *
	 * @param min the min
	 * @param max the max
	 * @return the random number in range
	 */
	private static int getRandomNumberInRange(int min, int max) {

		Random r = new Random();
		return r.ints(min, (max + 1)).limit(1).findFirst().getAsInt();

	}

	
	/**
	 * Gets the random nom.
	 *
	 * @return the random nom
	 */
	public static String getRandomNom() {

		int index = getRandomNumberInRange(0,ConstantesData.listNomFamille.size()-1);
		return ConstantesData.listNomFamille.get(index);
	}
	
	/**
	 * Gets the random string size 10 commence par P.
	 *
	 * @return the random string size 10 commence par P
	 */
	public static String getRandomStringSize10CommenceParP() {
		// TODO Auto-generated method stub
		return "P".concat(getRandomString(9));
	}
	/**
	 * Gets the id pers phys souscripteurs.
	 *
	 * @return the id pers phys souscripteurs
	 */
	public static String getidPersPhysSouscripteurs() {
		return "idPersPhysSouscripteurs test";
	}
	
	
	/**
	 * Gets the random long.
	 *
	 * @return the random long
	 */
	public static Long getRandomLong() {
		return RandomUtils.nextLong();
	}

	/**
	 * Gets the random integer.
	 *
	 * @return the random long
	 */
	public static Integer getRandomInt() {
		return RandomUtils.nextInt();
	}

	/**
	 * Gets the random boolean.
	 *
	 * @return the random boolean
	 */
	public static Boolean getRandomBoolean() {
		return RandomUtils.nextBoolean();
	}

	/**
	 * Gets the boolean true.
	 *
	 * @return the boolean true
	 */
	public static Boolean getBooleanTrue() {
		return new Boolean(true);
	}

	/**
	 * Gets the boolean false.
	 *
	 * @return the boolean false
	 */
	public static Boolean getBooleanFalse() {
		return new Boolean(false);
	}

	/**
	 * Gets the random date 1930 1950.
	 *
	 * @return the random date 1930 1950
	 */
	public static Date getRandomDate_1930_1950() {
		return RandomData.createRandomDate(1930, 1950);
	}

	/**
	 * Gets the random date 1999 2000.
	 *
	 * @return the random date 1999 2000
	 */
	public static Date getRandomDate_1999_2000() {
		return RandomData.createRandomDate(1999, 2000);
	}
	


	/**
	 * Gets the random date 1900 1901.
	 *
	 * @return the random date 1900 1901
	 */
	public static Date getRandomDate_1900_1901() {
		return RandomData.createRandomDate(1900, 1901);
	}
	
	/**
	 * Gets the random date 2020 2021.
	 *
	 * @return the random date 2020 2021
	 */
	public static Date getRandomDate_2020_2021() {
		return RandomData.createRandomDate(2020, 2021);
	}
	
	/**
	 * Gets the random date 1960 1980.
	 *
	 * @return the random date 1960 1980
	 */
	public static Date  getRandomDate_1960_1980() {
		return RandomData.createRandomDate(1960, 1980);
	}
	/**
	 * Gets the random id GDI.
	 *
	 * @return the random id GDI
	 */
	public static String getRandomIdGDI() {
		// sur 6
		return getRandomString(6).toLowerCase();
	}
	/**
	 * Gets the random string size 5.
	 *
	 * @return the random string size 5
	 */
	public static String getRandomStringSize5() {
		return getRandomString(5);
	}
	
	/**
	 * Gets the random string size 8.
	 *
	 * @return the random string size 8
	 */
	public static String getRandomStringSize8() {
		return getRandomString(8);
	}
	
	/**
	 * Gets the random string size 10.
	 *
	 * @return the random string size 10
	 */
	public static String getRandomStringSize10() {
		return getRandomString(10);
	}
	
	/**
	 * Gets the random string.
	 *
	 * @param size the size
	 * @return the random string
	 */
	private static String getRandomString(int size) {
		return RandomStringUtils.randomAlphabetic(10);
	}
	
}
