package utils.data;

import java.util.ArrayList;
import java.util.List;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.HabilitationPartDto;

/**
 * The Class DataListHabilitationPartDto.
 */
public class DataListHabilitationPartDto {
	/**
	 * Gets the list HabilitationPartDto.
	 *
	 * @return the HabilitationPartDtoList
	 */
	public List<HabilitationPartDto> getListHabilitationPartDto() {
		List<HabilitationPartDto> liste = new ArrayList<>();
		liste.add(RandomData.getRandomHabilitationPartDto());
		liste.add(RandomData.getRandomHabilitationPartDto());
		liste.add(RandomData.getRandomHabilitationPartDto());
		return liste;
	}
}
