package utils.data;

import java.util.Date;

import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;


public class DataContratHeaderDto {

	
    private String college = RandomData.getRandomStringSize10();
    
    private String id = RandomData.getRandomStringSize10();

    private String personId = RandomData.getRandomStringSize10();

  
    private String idAdherente = RandomData.getRandomStringSize10();

    private String raisonSocialeAdherente = RandomData.getRandomStringSize10();

    
    private String idContractante = RandomData.getRandomStringSize10();


    private String raisonSocialeContractante = RandomData.getRandomStringSize10();
    private String raisonSocialeFront = RandomData.getRandomStringSize10();
    private String descriptionFront = RandomData.getRandomStringSize10();

    private String idCollege = RandomData.getRandomStringSize10();
    private String identifiantAssure = RandomData.getRandomStringSize10();
    private boolean enabled = RandomData.getRandomBoolean();
    private boolean vifPossible = RandomData.getRandomBoolean();
    private boolean deductible = RandomData.getRandomBoolean();
    private boolean blocked = RandomData.getRandomBoolean();
    private boolean classeAutreContrat = RandomData.getRandomBoolean();

    private boolean contractanteRepresent = RandomData.getRandomBoolean();
    private boolean hasVersementProgrammes = RandomData.getRandomBoolean();

    private String codeProduit = RandomData.getRandomStringSize10();
    private String libelleProduit = RandomData.getRandomStringSize10();
    private String codeMentionLegale = RandomData.getRandomStringSize10();
    private String typeContrat = RandomData.getRandomStringSize10();
    private String numGenContrat = RandomData.getRandomStringSize10();
    private String codeFiliale = RandomData.getRandomStringSize10();
    private String etatContratLabel = RandomData.getRandomStringSize10();
    private String etatAffiliationLabel = RandomData.getRandomStringSize10();
    private Date dateEffet = RandomData.getRandomDate_2020_2021();
    private Date dateFinEffet = RandomData.getRandomDateFinEffet();
    private String codeSitAffil = RandomData.getRandomStringSize10();
    private String libSitAffil = RandomData.getRandomStringSize10();
    private Date dateSitAffil = RandomData.getRandomDate_2020_2021();


    private Date dateSitCtr = RandomData.getRandomDate_2020_2021();
    private Date dateEffetSituationAffiliation = RandomData.getRandomDate_2020_2021();


    private String idContratReference = RandomData.getRandomStringSize10();
    
    
    ContratHeaderDto getContratHeaderDto() {
    	
    	ContratHeaderDto contratHeaderDto = new ContratHeaderDto();
    	
    	contratHeaderDto.setBlocked(blocked);
    	contratHeaderDto.setClasseAutreContrat(classeAutreContrat);
    	contratHeaderDto.setCodeFiliale(codeFiliale);
    	contratHeaderDto.setCodeMentionLegale(codeMentionLegale);
    	contratHeaderDto.setCodeProduit(codeProduit);
    	contratHeaderDto.setCodeSitAffil(codeSitAffil);
    	contratHeaderDto.setCollege(college);
    	contratHeaderDto.setContractanteRepresent(contractanteRepresent);
    	contratHeaderDto.setDateEffet(dateEffet);
    	contratHeaderDto.setDateEffetSituationAffiliation(dateEffetSituationAffiliation);
    	contratHeaderDto.setDateFinEffet(dateFinEffet);
    	contratHeaderDto.setDateSitAffil(dateSitAffil);
    	contratHeaderDto.setDateSitCtr(dateSitCtr);
    	contratHeaderDto.setDeductible(deductible);
    	contratHeaderDto.setDescriptionFront(descriptionFront);
    	contratHeaderDto.setEnabled(enabled);
    	contratHeaderDto.setEtatAffiliationLabel(etatAffiliationLabel);
    	contratHeaderDto.setHasVersementProgrammes(hasVersementProgrammes);
    	contratHeaderDto.setId(id);
    	contratHeaderDto.setIdAdherente(idAdherente);
    	contratHeaderDto.setIdCollege(idCollege);
    	contratHeaderDto.setIdContractante(idContractante);
    	contratHeaderDto.setIdContratReference(idContratReference);
    	contratHeaderDto.setIdentifiantAssure(identifiantAssure);
    	contratHeaderDto.setLibelleProduit(libelleProduit);
    	contratHeaderDto.setLibSitAffil(libSitAffil);
    	contratHeaderDto.setNumGenContrat(numGenContrat);
    	contratHeaderDto.setPersonId(personId);
    	contratHeaderDto.setRaisonSocialeAdherente(raisonSocialeAdherente);
    	contratHeaderDto.setRaisonSocialeContractante(raisonSocialeContractante);
    	contratHeaderDto.setRaisonSocialeFront(raisonSocialeFront);
    	contratHeaderDto.setTypeContrat(typeContrat);
    	contratHeaderDto.setVifPossible(vifPossible);
    	contratHeaderDto.setEtatContratLabel(etatContratLabel);
    	
    	return contratHeaderDto;
    	
    }
	
}
