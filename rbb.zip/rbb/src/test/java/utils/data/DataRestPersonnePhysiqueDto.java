package utils.data;

import java.util.Date;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.InfoCanalDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.PersonnePhysiqueDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.zonecom.IdentifiantDto;
/**
 * The Class DataRestPersonnePhysiqueDto.
 */
@Ignore("Classe de données pour les tests")
public class DataRestPersonnePhysiqueDto {
	/** The data IdentifiantDto. */
	private IdentifiantDto id = new DataIdentifiantDtoZoneCom().getIdentifiantDto();
	/** The data nom. */
    private String nom = RandomData.getRandomStringSize10();
	/** The data prenom. */
    private String prenom = RandomData.getRandomStringSize10();
	/** The data nomNais. */
    private String nomNais = RandomData.getRandomStringSize10();
	/** The data codeSexe. */
    private String codeSexe = RandomData.getRandomStringSize10();
	/** The data dateNais. */
	private Date dateNais = RandomData.getRandomDate_2020();
	/** The data codePostalVilNais. */
	private String codePostalVilNais = RandomData.getRandomStringSize10();
	/** The data infosCanal. */
	private List<InfoCanalDto> infosCanal = new DataListInfoCanalDto().getListeInfoCanalDto();
	
	/** The data PersonnePhysiqueDto. */
	public PersonnePhysiqueDto getPersonnePhysiqueDto() {
		PersonnePhysiqueDto personnePhysiqueDto = new PersonnePhysiqueDto();
		personnePhysiqueDto.setId(id);
		personnePhysiqueDto.setNom(nom);
		personnePhysiqueDto.setPrenom(prenom);
		personnePhysiqueDto.setNomNais(nomNais);
		personnePhysiqueDto.setCodeSexe(codeSexe);
		personnePhysiqueDto.setCodePostalVilNais(codePostalVilNais);
		personnePhysiqueDto.setDateNais(dateNais);
		personnePhysiqueDto.setInfosCanal(infosCanal);
		return personnePhysiqueDto;
	}
}
