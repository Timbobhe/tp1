/*
 * Cree le 29 octobre 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @emir JEMMALI
 * 
 * 
 */
package utils.data;

import java.util.Date;
import java.util.List;

import org.junit.Ignore;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.IdentifiantDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.SouscripteurDto;

/**
 * The Class DataContrat.
 */
@Ignore("Classe de données pour les tests")
public class DataContratDto {

	/** The id identifiant dto. */
	private String idIdentifiantDto=  RandomData.getRandomStringSize10();

	/** The code appli identifiant dto. */
	private String codeAppliIdentifiantDto =  RandomData.getRandomStringSize10();

	/** The code sys info identifiant dto. */
	private String codeSysInfoIdentifiantDto =  RandomData.getRandomStringSize10();

	/** The date fin effet. */
	private Date dateFinEffet = RandomData.getRandomDateFinEffet();

	/** The ass ctr. */
	private LabelValue assCtr = RandomData.getRandomLabelValue();

	/** The nat contrat. */
	private LabelValue natContrat= RandomData.getRandomLabelValue();

	/** The branche assur. */
	private LabelValue brancheAssur= RandomData.getRandomLabelValue();

	/** The branche assur det. */
	private LabelValue brancheAssurDet= RandomData.getRandomLabelValue();

	/** The date effet. */
	private Date dateEffet= RandomData.getRandomDate_2019_2020();

	/** The date emission. */
	private Date dateEmission= RandomData.getRandomDateFinEffet();

	/** The date sit contrat. */
	private Date dateSitContrat= RandomData.getRandomDate_2019_2020();

	/** The ofr cial lg. */
	private LabelValue ofrCialLg= RandomData.getRandomLabelValue();

	/** The ind gest tiers. */
	private Boolean indGestTiers= RandomData.getBooleanTrue();

	/** The lib cie assur. */
	private String libCieAssur=  RandomData.getRandomStringSize10();

	/** The liste souscripteur. */
	private List<SouscripteurDto> listeSouscripteur;
	
	/** The sitContrat. */
	private LabelValue sitContrat = new LabelValue("", "EC");
	
	/**
	 * Gets the contrat dto.
	 *
	 * @return the contrat dto
	 */
	public ContratDto getContratDto(String metierContratTypeValue) {
		ContratDto contratDto = new ContratDto();
		contratDto.setIdentSiloContrat(getIdentifiantDto());
		contratDto.setDateFinEffet(dateFinEffet );
		contratDto.setAssCtr(assCtr );
		contratDto.setNatContrat(natContrat);
		contratDto.setBrancheAssur(brancheAssur);
		contratDto.setBrancheAssurDet(brancheAssurDet);
	    contratDto.setDateEffet(dateEffet);
	    contratDto.setDateEmission(dateEmission);
	    contratDto.setDateSitContrat(dateSitContrat);
	    contratDto.setIdContratSource(getIdentifiantDto());
	    contratDto.setOfrCialLg(new LabelValue("", metierContratTypeValue));
	    contratDto.setIndGestTiers(indGestTiers);
	    contratDto.setLibCieAssur(libCieAssur);
	    contratDto.setListeSouscripteur(listeSouscripteur);
	    contratDto.setSitContrat(sitContrat);
	    return contratDto;
	}

	/**
	 * Gets the identifiant dto.
	 *
	 * @return the identifiant dto
	 */
	public IdentifiantDto getIdentifiantDto() {
		return new IdentifiantDto(idIdentifiantDto, codeAppliIdentifiantDto, codeSysInfoIdentifiantDto);
	}




}
