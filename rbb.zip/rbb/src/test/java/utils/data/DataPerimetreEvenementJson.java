package utils.data;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
/*
 * Cree le 9 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
@Ignore("Classe de données pour les tests")
public class DataPerimetreEvenementJson {
	/** The codeEvenement. */
	private String codeEvenement = RandomData.getRandomStringSize10();
	
	/** The operationPerimetre. */
    private OperationPerimetre operationPerimetre = OperationPerimetre.EXC;
    
    /**
	 * Gets the DataPerimetreEvenementJson.
	 *
	 * @return PerimetreEvenementJson
	 */
    public PerimetreEvenementJson getDataPerimetreEvenementJson() {
    	PerimetreEvenementJson perimetreEvenementJson = new PerimetreEvenementJson();
    	perimetreEvenementJson.setCodeEvenement(codeEvenement);
    	perimetreEvenementJson.setOperationPerimetre(operationPerimetre);
    	return perimetreEvenementJson;
    }
    
    /**
	 * Gets the List of DataPerimetreEvenementJson.
	 *
	 * @return list of PerimetreEvenementJson
	 */
    public List<PerimetreEvenementJson> getListDataPerimetreEvenementJson() {
    	List<PerimetreEvenementJson> listDataPerimetreEvenementJson =  new ArrayList<PerimetreEvenementJson>();
    	listDataPerimetreEvenementJson.add(getDataPerimetreEvenementJson());
    	listDataPerimetreEvenementJson.add(getDataPerimetreEvenementJson());
    	return listDataPerimetreEvenementJson;
    }
}
