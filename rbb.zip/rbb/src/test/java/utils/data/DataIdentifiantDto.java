package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.soap.IdentifiantDto;
import lombok.Getter;

/**
 * Gets the lib sys info.
 *
 * @return the lib sys info
 */

/**
 * Gets the lib sys info.
 *
 * @return the lib sys info
 */

/**
 * Gets the lib sys info.
 *
 * @return the lib sys info
 */

/**
 * Gets the lib sys info.
 *
 * @return the lib sys info
 */
@Getter
@Ignore("Classe de données pour les tests")
public class DataIdentifiantDto {

	/** The id pers phys souscripteurs. */
	private String idPersPhysSouscripteurs = RandomData.getidPersPhysSouscripteurs(); 
	
	/** The id. */
	private String id = RandomData.getRandomStringSize10CommenceParP();
	
	/** The nom. */
	private String nom= RandomData.getRandomNom();
    
    /** The code appli. */
    private String codeAppli= RandomData.getRandomStringCodeAppli();
    
    /** The lib appli. */
    private String libAppli= RandomData.getRandomStringSize10();
    
    /** The code sys info. */
    private String codeSysInfo= RandomData.getRandomStringSize10();
    
    /** The lib sys info. */
    private String libSysInfo= RandomData.getRandomStringSize10();
	
	
	
	
	/**
	 * Gets the identifiant dto.
	 *
	 * @return the identifiant dto
	 */
	public IdentifiantDto getIdentifiantDto() {
		IdentifiantDto identifiantDto = new IdentifiantDto();
		
		identifiantDto.setId(id);
		identifiantDto.setNom(nom);
		identifiantDto.setCodeAppli(codeAppli);
		identifiantDto.setLibAppli(libAppli);
		identifiantDto.setCodeSysInfo(codeSysInfo);
		identifiantDto.setLibSysInfo(libSysInfo);
	    
		return identifiantDto;
	}




	/**
	 * Gets the identifiant dto souscripteurs.
	 *
	 * @return the identifiant dto souscripteurs
	 */
	public IdentifiantDto getIdentifiantDtoSouscripteurs() {
IdentifiantDto identifiantDto = new IdentifiantDto();
		
		identifiantDto.setId(idPersPhysSouscripteurs);
		identifiantDto.setNom(nom);
		identifiantDto.setCodeAppli(codeAppli);
		identifiantDto.setLibAppli(libAppli);
		identifiantDto.setCodeSysInfo(codeSysInfo);
		identifiantDto.setLibSysInfo(libSysInfo);
	    
		return identifiantDto;
	}

}

