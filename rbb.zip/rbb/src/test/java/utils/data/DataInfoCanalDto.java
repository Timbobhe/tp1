package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.InfoCanalDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;
/**
 * The Class DataInfoCanalDto.
 */
@Ignore("Classe de données pour les tests")
public class DataInfoCanalDto {
	/** The data natureCanal. */
	private LabelValue natureCanal = new DataLabelValue().getLabelValue();
	/** The data numTel. */
	private String numTel = RandomData.getRandomStringSize10();
	/** The data libEmail. */
	private String libEmail = RandomData.getRandomStringSize10();
	
	/** The data InfoCanalDto. */
	public InfoCanalDto getInfoCanalDto() {
		InfoCanalDto infoCanalDto = new InfoCanalDto();
		infoCanalDto.setNatureCanal(natureCanal);
		infoCanalDto.setLibEmail(libEmail);
		infoCanalDto.setNumTel(numTel);
		return infoCanalDto;
	}
}
