package utils.data;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.trm.domain.evenement.CategorieJson;
import fr.ag2rlamondiale.trm.domain.evenement.ModeActionEvtType;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
/*
 * Cree le 9 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
@Ignore("Classe de données pour les tests")
public class DataTypeEvenementJson {
	/** The codeEvenement. */
	private String codeEvenement = RandomData.getRandomStringSize10();
	
	/** The categorie. */
    private CategorieJson categorie =  new DataCategorieJson().getDataCategorieJson();
    
	/** The ordre. */
    private int ordre = RandomData.getRandomInt();
    
	/** The dateDebut. */
    private Long dateDebut = RandomData.getRandomLong();
    
	/** The dateFin. */
    private Long dateFin = RandomData.getRandomLong();
    
	/** The nbDeclenchementsMaxPeriode. */
    private Integer nbDeclenchementsMaxPeriode = RandomData.getRandomInt();;

	/** The periodeDeclenchement. */
    private Integer periodeDeclenchement = RandomData.getRandomInt();;

	/** The delaiAvantReactivation. */
    private Integer delaiAvantReactivation = RandomData.getRandomInt();;
    
	/** The modeAction. */
    private ModeActionEvtType modeAction = ModeActionEvtType.FACU;
    
	/** The titre. */
    private String titre = RandomData.getRandomStringSize10();;
    
	/** The contenu. */
    private String contenu = RandomData.getRandomStringSize10();
    
	/** The actionTraiter. */
	private String actionTraiter = RandomData.getRandomStringSize10();
	
	/** The actionAnnuler. */
	private String actionAnnuler = RandomData.getRandomStringSize10();
	
	/** The lienRedirection. */
	private String lienRedirection = RandomData.getRandomStringSize10();
	
	/** The perimetreEvenements. */
	private List<PerimetreEvenementJson> perimetreEvenements = new DataPerimetreEvenementJson().getListDataPerimetreEvenementJson();
	
	/** The id. */
	private String libEvenement = RandomData.getRandomStringSize10();
	
	/** The id. */
	private boolean isDirty = RandomData.getRandomBoolean();

	/**
	 * Gets the DataPerimetreEvenementJson.
	 *
	 * @return PerimetreEvenementJson
	 */
    public TypeEvenementJson getDataTypeEvenementJson() {
    	TypeEvenementJson typeEvenementJson = new TypeEvenementJson();
    	typeEvenementJson.setActionAnnuler(actionAnnuler);
    	typeEvenementJson.setActionTraiter(actionTraiter);
    	typeEvenementJson.setCategorie(categorie);
    	typeEvenementJson.setCodeEvenement(codeEvenement);
    	typeEvenementJson.setContenu(contenu);
    	typeEvenementJson.setDateDebut(dateDebut);
    	typeEvenementJson.setDateFin(dateFin);
    	typeEvenementJson.setDelaiAvantReactivation(delaiAvantReactivation);
    	typeEvenementJson.setDirty(isDirty);
    	typeEvenementJson.setLibEvenement(libEvenement);
    	typeEvenementJson.setLienRedirection(lienRedirection);
    	typeEvenementJson.setModeAction(modeAction);
    	typeEvenementJson.setNbDeclenchementsMaxPeriode(nbDeclenchementsMaxPeriode);
    	typeEvenementJson.setOrdre(ordre);
    	typeEvenementJson.setPerimetreEvenements(perimetreEvenements);
    	typeEvenementJson.setPeriodeDeclenchement(periodeDeclenchement);
    	typeEvenementJson.setTitre(titre);
    	return typeEvenementJson;
    }
    
    /**
	 * Gets the DataPerimetreEvenementJson.
	 *
	 * @return PerimetreEvenementJson
	 */
    public List<TypeEvenementJson> getListDataTypeEvenementJson() {
    	List<TypeEvenementJson> typeEvenementJsonList = new ArrayList<TypeEvenementJson>();
    	typeEvenementJsonList.add(getDataTypeEvenementJson());
    	typeEvenementJsonList.add(getDataTypeEvenementJson());
    	return typeEvenementJsonList;
    }
}
