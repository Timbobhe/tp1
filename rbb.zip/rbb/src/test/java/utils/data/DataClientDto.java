/*
 * Cree le 29 octobre 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @emir JEMMALI
 * 
 * 
 */
package utils.data;

import java.util.ArrayList;
import java.util.List;

import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.IdentifiantDto;

/**
 * The Class DataClientDto.
 */
public class DataClientDto {

	/**
	 * Gets the client dto.
	 *
	 * @return the client dto
	 */
	public ClientDto getClientDto() {
		ClientDto clientDto = new ClientDto();
		DataIdentifiantDto dataIdentifiantDto = new DataIdentifiantDto();
		IdentifiantDto id = dataIdentifiantDto.getIdentifiantDto();
		clientDto.setId(id);
		DataContratDto dataContratDto = new DataContratDto();
		DataContratDto dataContratDto2 = new DataContratDto();
		
		List<ContratDto> listeContrat = new ArrayList<>();
		listeContrat.add(dataContratDto.getContratDto("RR01001"));
		listeContrat.add(dataContratDto2.getContratDto("RC01V01"));
		listeContrat.add(dataContratDto2.getContratDto("5200000"));
		listeContrat.add(dataContratDto2.getContratDto("AN01V01"));

		clientDto.setListeContrat(listeContrat);
		return clientDto;
	}

}
