package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.trm.domain.evenement.CategorieJson;

/*
 * Cree le 9 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
@Ignore("Classe de données pour les tests")
public class DataCategorieJson {
	/** The codeCategorie. */
	private String codeCategorie = RandomData.getRandomStringSize10();
	/** The codeApplication. */
    private String codeApplication = RandomData.getRandomStringSize10();
	/** The ordre. */
    private int ordre = RandomData.getRandomInt();
	/** The description. */
    private String description = RandomData.getRandomStringSize10();
    
    /**
	 * Gets the CategorieJson.
	 *
	 * @return CategorieJson
	 */
    public CategorieJson getDataCategorieJson() {
    	CategorieJson categorieJson = new CategorieJson();
    	categorieJson.setCodeApplication(codeApplication);
    	categorieJson.setCodeCategorie(codeCategorie);
    	categorieJson.setDescription(description);
    	categorieJson.setOrdre(ordre);
    	return categorieJson;
    }
}
