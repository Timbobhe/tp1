/*
 * Cree le 10 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package utils.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Ignore;

import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratEnum;

@Ignore("Classe de données pour les tests")
public class DataContratHeader {
	/** The codeSilo. */
	private CodeSiloType codeSilo = CodeSiloType.MDP;
	/** The college. */
    private String college = RandomData.getRandomStringSize10();
	/** The id. */
    private String id = RandomData.getRandomStringSize10();
	/** The personId. */
    private String personId =  RandomData.getRandomStringSize10();
	/** The idAdherente. */
    private String idAdherente = RandomData.getRandomStringSize10();
	/** The raisonSocialeAdherente. */
    private String raisonSocialeAdherente = RandomData.getRandomStringSize10();
	/** The idContractante. */
    private String idContractante = RandomData.getRandomStringSize10();
	/** The raisonSocialeContractante. */
    private String raisonSocialeContractante = RandomData.getRandomStringSize10();
	/** The raisonSocialeFront. */
    private String raisonSocialeFront = RandomData.getRandomStringSize10();
	/** The descriptionFront. */
    private String descriptionFront = RandomData.getRandomStringSize10();
	/** The idCollege. */
    private String idCollege = RandomData.getRandomStringSize10();
	/** The identifiantAssure. */
    private String identifiantAssure = RandomData.getRandomStringSize10();
	/** The affichageType. */
    private AffichageType affichageType = AffichageType.GRISE;
	/** The deductible. */
    private boolean deductible = RandomData.getBooleanTrue();
	/** The classeAutreContrat. */
    private boolean classeAutreContrat = RandomData.getBooleanTrue();
	/** The contractanteRepresent. */
    private boolean contractanteRepresent = RandomData.getBooleanTrue();
	/** The hasVersementProgrammes. */
    private boolean hasVersementProgrammes = RandomData.getBooleanTrue();
	/** The dateAffiliation. */
    private Date dateAffiliation = RandomData.getRandomDate_1900_1901();
	/** The codeAssureur. */
    private String codeAssureur = RandomData.getRandomStringSize10();
	/** The codeProduit. */
    private String codeProduit = RandomData.getRandomStringSize10();
	/** The libelleProduit. */
    private String libelleProduit = RandomData.getRandomStringSize10();
	/** The codeMentionLegale. */
    private String codeMentionLegale = RandomData.getRandomStringSize10();
	/** The typeContrat. */
    private String typeContrat = RandomData.getRandomStringSize10();
	/** The numGenContrat. */
    private String numGenContrat = RandomData.getRandomStringSize10();
	/** The codeFiliale. */
    private String codeFiliale = RandomData.getRandomStringSize10();
	/** The etatContratLabel. */
    private String etatContratLabel = RandomData.getRandomStringSize10();
	/** The etatAffiliationLabel. */
    private String etatAffiliationLabel = RandomData.getRandomStringSize10();
	/** The dateEffet. */
    private Date dateEffet = RandomData.getRandomDate_1900_1901();
	/** The dateFinEffet. */
    private Date dateFinEffet = RandomData.getRandomDate_1900_1901();
	/** The codeSitAffil. */
    private String codeSitAffil = RandomData.getRandomStringSize10();
	/** The libSitAffil. */
    private String libSitAffil = RandomData.getRandomStringSize10();
	/** The dateSitAffil. */
    private Date dateSitAffil = RandomData.getRandomDate_1900_1901();
	/** The descClauseBenef. */
    private String descClauseBenef = RandomData.getRandomStringSize10();
	/** The codeCadreFiscal. */
    private String codeCadreFiscal = RandomData.getRandomStringSize10();
	/** The libCadreFiscal. */
    private String libCadreFiscal = RandomData.getRandomStringSize10();
	/** The etatContrat. */
    private SituationContratEnum etatContrat = SituationContratEnum.ANNEE_BLANCHE;
	/** The dateSitCtr. */
    private Date dateSitCtr = RandomData.getRandomDate_1900_1901();
	/** The dateEffetSituationAffiliation. */
    private Date dateEffetSituationAffiliation = RandomData.getRandomDate_1900_1901();
	/** The partsType. */
    private Set<PartType> partsType = new HashSet<PartType>();
	/** The pacte. */
    private boolean pacte = RandomData.getBooleanTrue();
	/** The compartiments. */
    private List<Compartiment> compartiments = new ArrayList<>();
	/** The petitCollectifPTV. */
    private boolean petitCollectifPTV = RandomData.getBooleanTrue();;
	/** The idContratReference. */
    private String idContratReference = RandomData.getRandomStringSize10();
    
    /**
	 * Gets the DataContratHeader.
	 *
	 * @return the DataContratHeader
	 */
	public ContratHeader getDataContratHeader(CompartimentType c) {
		Compartiment compartimentC1 =new Compartiment();
		compartimentC1.setType(c);
		compartimentC1.setAffichageType(affichageType);
		compartiments.add(compartimentC1);
		compartiments.add(compartimentC1);
		ContratHeader contratHeader = new ContratHeader();
		contratHeader.setAffichageType(affichageType);
		contratHeader.setClasseAutreContrat(classeAutreContrat);
		contratHeader.setCodeAssureur(codeAssureur);
		contratHeader.setCodeCadreFiscal(codeCadreFiscal);
		contratHeader.setCodeFiliale(codeFiliale);
		contratHeader.setCodeMentionLegale(codeMentionLegale);
		contratHeader.setCodeProduit(codeProduit);
		contratHeader.setCodeSilo(codeSilo);
		contratHeader.setCodeSitAffil(codeSitAffil);
		contratHeader.setCollege(college);
		contratHeader.setCompartiments(compartiments);
		contratHeader.setContractanteRepresent(contractanteRepresent);
		contratHeader.setDateAffiliation(dateAffiliation);
		contratHeader.setDateEffet(dateEffet);
		contratHeader.setDateEffetSituationAffiliation(dateEffetSituationAffiliation);
		contratHeader.setDateFinEffet(dateFinEffet);
		contratHeader.setDateSitAffil(dateSitAffil);
		contratHeader.setDateSitCtr(dateSitCtr);
		contratHeader.setDeductible(deductible);
		contratHeader.setDescClauseBenef(descClauseBenef);
		contratHeader.setDescriptionFront(descriptionFront);
		contratHeader.setEtatAffiliationLabel(etatAffiliationLabel);
		contratHeader.setEtatContrat(etatContrat);
		contratHeader.setEtatContratLabel(etatContratLabel);
		contratHeader.setHasVersementProgrammes(hasVersementProgrammes);
		contratHeader.setId(id);
		contratHeader.setIdAdherente(idAdherente);
		contratHeader.setIdCollege(idCollege);
		contratHeader.setIdContractante(idContractante);
		contratHeader.setIdContratReference(idContratReference);
		contratHeader.setIdentifiantAssure(identifiantAssure);
		contratHeader.setLibCadreFiscal(libCadreFiscal);
		contratHeader.setLibelleProduit(libelleProduit);
		contratHeader.setLibSitAffil(libSitAffil);
		contratHeader.setNumGenContrat(numGenContrat);
		contratHeader.setPacte(pacte);
		contratHeader.setPartsType(partsType);
		contratHeader.setPersonId(personId);
		contratHeader.setPetitCollectifPTV(petitCollectifPTV);
		contratHeader.setRaisonSocialeAdherente(raisonSocialeAdherente);
		contratHeader.setRaisonSocialeContractante(raisonSocialeContractante);
		contratHeader.setRaisonSocialeFront(raisonSocialeFront);
		contratHeader.setTypeContrat(typeContrat);
		return contratHeader;
	}
	
	/**
	 * Gets the DataContratHeader.
	 *
	 * @return the DataContratHeader
	 */
	public ContratHeader getDataContratHeaderWithOneCompartiment(CompartimentType c) {
		Compartiment compartimentC1 =new Compartiment();
		compartimentC1.setType(c);
		compartimentC1.setAffichageType(affichageType);
		compartiments.add(compartimentC1);
		ContratHeader contratHeader = new ContratHeader();
		contratHeader.setAffichageType(affichageType);
		contratHeader.setClasseAutreContrat(classeAutreContrat);
		contratHeader.setCodeAssureur(codeAssureur);
		contratHeader.setCodeCadreFiscal(codeCadreFiscal);
		contratHeader.setCodeFiliale(codeFiliale);
		contratHeader.setCodeMentionLegale(codeMentionLegale);
		contratHeader.setCodeProduit(codeProduit);
		contratHeader.setCodeSilo(codeSilo);
		contratHeader.setCodeSitAffil(codeSitAffil);
		contratHeader.setCollege(college);
		contratHeader.setCompartiments(compartiments);
		contratHeader.setContractanteRepresent(contractanteRepresent);
		contratHeader.setDateAffiliation(dateAffiliation);
		contratHeader.setDateEffet(dateEffet);
		contratHeader.setDateEffetSituationAffiliation(dateEffetSituationAffiliation);
		contratHeader.setDateFinEffet(dateFinEffet);
		contratHeader.setDateSitAffil(dateSitAffil);
		contratHeader.setDateSitCtr(dateSitCtr);
		contratHeader.setDeductible(deductible);
		contratHeader.setDescClauseBenef(descClauseBenef);
		contratHeader.setDescriptionFront(descriptionFront);
		contratHeader.setEtatAffiliationLabel(etatAffiliationLabel);
		contratHeader.setEtatContrat(etatContrat);
		contratHeader.setEtatContratLabel(etatContratLabel);
		contratHeader.setHasVersementProgrammes(hasVersementProgrammes);
		contratHeader.setId(id);
		contratHeader.setIdAdherente(idAdherente);
		contratHeader.setIdCollege(idCollege);
		contratHeader.setIdContractante(idContractante);
		contratHeader.setIdContratReference(idContratReference);
		contratHeader.setIdentifiantAssure(identifiantAssure);
		contratHeader.setLibCadreFiscal(libCadreFiscal);
		contratHeader.setLibelleProduit(libelleProduit);
		contratHeader.setLibSitAffil(libSitAffil);
		contratHeader.setNumGenContrat(numGenContrat);
		contratHeader.setPacte(pacte);
		contratHeader.setPartsType(partsType);
		contratHeader.setPersonId(personId);
		contratHeader.setPetitCollectifPTV(petitCollectifPTV);
		contratHeader.setRaisonSocialeAdherente(raisonSocialeAdherente);
		contratHeader.setRaisonSocialeContractante(raisonSocialeContractante);
		contratHeader.setRaisonSocialeFront(raisonSocialeFront);
		contratHeader.setTypeContrat(typeContrat);
		return contratHeader;
	}
	 /**
		 * Gets the DataContratHeader.
		 *
		 * @return the DataContratHeader
		 */
		public ContratHeader getDataContratHeaderWithoutCompartiment() {
			ContratHeader contratHeader = new ContratHeader();
			contratHeader.setAffichageType(affichageType);
			contratHeader.setClasseAutreContrat(classeAutreContrat);
			contratHeader.setCodeAssureur(codeAssureur);
			contratHeader.setCodeCadreFiscal(codeCadreFiscal);
			contratHeader.setCodeFiliale(codeFiliale);
			contratHeader.setCodeMentionLegale(codeMentionLegale);
			contratHeader.setCodeProduit(codeProduit);
			contratHeader.setCodeSilo(codeSilo);
			contratHeader.setCodeSitAffil(codeSitAffil);
			contratHeader.setCollege(college);
			contratHeader.setCompartiments(compartiments);
			contratHeader.setContractanteRepresent(contractanteRepresent);
			contratHeader.setDateAffiliation(dateAffiliation);
			contratHeader.setDateEffet(dateEffet);
			contratHeader.setDateEffetSituationAffiliation(dateEffetSituationAffiliation);
			contratHeader.setDateFinEffet(dateFinEffet);
			contratHeader.setDateSitAffil(dateSitAffil);
			contratHeader.setDateSitCtr(dateSitCtr);
			contratHeader.setDeductible(deductible);
			contratHeader.setDescClauseBenef(descClauseBenef);
			contratHeader.setDescriptionFront(descriptionFront);
			contratHeader.setEtatAffiliationLabel(etatAffiliationLabel);
			contratHeader.setEtatContrat(etatContrat);
			contratHeader.setEtatContratLabel(etatContratLabel);
			contratHeader.setHasVersementProgrammes(hasVersementProgrammes);
			contratHeader.setId(id);
			contratHeader.setIdAdherente(idAdherente);
			contratHeader.setIdCollege(idCollege);
			contratHeader.setIdContractante(idContractante);
			contratHeader.setIdContratReference(idContratReference);
			contratHeader.setIdentifiantAssure(identifiantAssure);
			contratHeader.setLibCadreFiscal(libCadreFiscal);
			contratHeader.setLibelleProduit(libelleProduit);
			contratHeader.setLibSitAffil(libSitAffil);
			contratHeader.setNumGenContrat(numGenContrat);
			contratHeader.setPacte(pacte);
			contratHeader.setPartsType(partsType);
			contratHeader.setPersonId(personId);
			contratHeader.setPetitCollectifPTV(petitCollectifPTV);
			contratHeader.setRaisonSocialeAdherente(raisonSocialeAdherente);
			contratHeader.setRaisonSocialeContractante(raisonSocialeContractante);
			contratHeader.setRaisonSocialeFront(raisonSocialeFront);
			contratHeader.setTypeContrat(typeContrat);
			return contratHeader;
			
		}
		
		/**
		 * Gets the List of DataContratHeader.
		 *
		 * @return the list of DataContratHeader
		 */
		public List <ContratHeader> getDataContratHeaderList() {
			List <ContratHeader> list = new ArrayList<ContratHeader>();
			list.add(getDataContratHeader(CompartimentType.C4));
			list.add(getDataContratHeader(CompartimentType.C4));
			list.add(getDataContratHeader(CompartimentType.C1));
			list.add(getDataContratHeader(CompartimentType.C1));
			return list;
		}
}
