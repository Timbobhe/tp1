package utils.data;

import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.resp.ListeHabilitationPersonneDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.HabilitationPartDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.IdNumeriqueDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.PersonnePhysiqueDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.zonecom.IdentifiantDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;
/**
 * The Class DataListeHabilitationPersonneDto.
 */
@Ignore("Classe de données")
public class DataListeHabilitationPersonneDto {
	
	/** The data IdentifiantDto. */
	private IdentifiantDto id = new DataIdentifiantDtoZoneCom().getIdentifiantDto();
	/** The data situation. */
	private LabelValue situation = new DataLabelValue().getLabelValue();
	/** The data personnePhys. */
	private PersonnePhysiqueDto personnePhys = new DataRestPersonnePhysiqueDto().getPersonnePhysiqueDto();
	/** The data  idExtranet. */
	private String idExtranet = RandomData.getRandomStringSize10();
	/** The data idNumeriques. */
	private List<IdNumeriqueDto> idNumeriques = new DataListIdNumeriqueDto().getListeldNumeriqueDto();
	/** The data habilitationPart. */
	private List<HabilitationPartDto> habilitationPart = new DataListHabilitationPartDto().getListHabilitationPartDto();
	
	/** The data List HabilitationPersonneDto. */
	public ListeHabilitationPersonneDto getListeHabilitationPersonneDto() {
		ListeHabilitationPersonneDto listeHabilitationPersonneDto = new ListeHabilitationPersonneDto();
		listeHabilitationPersonneDto.setId(id);
		listeHabilitationPersonneDto.setSituation(situation);
		listeHabilitationPersonneDto.setPersonnePhys(personnePhys);
		listeHabilitationPersonneDto.setIdExtranet(idExtranet);
		listeHabilitationPersonneDto.setIdNumeriques(idNumeriques);
		listeHabilitationPersonneDto.setHabilitationPart(habilitationPart);
		return listeHabilitationPersonneDto;
	}
}

