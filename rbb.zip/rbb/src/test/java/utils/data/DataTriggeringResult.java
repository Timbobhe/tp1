/*
 * Cree le 10 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.even.AbstractEvenGenerator;
import fr.ag2rlamondiale.rbb.domain.even.TriggeringResult;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
@Ignore("Classe de données pour les tests")

public class DataTriggeringResult {
	/* the idGdi*/
	private String idGdi = RandomData.getRandomIdGDI();
	/* the numPersonne*/
    private String numPersonne = RandomData.getRandomIdGDI();
	/* the typeEvenement*/
    private TypeEvenementJson typeEvenement = new DataTypeEvenementJson().getDataTypeEvenementJson();
	/* the contrat*/
    private ContratHeader contrat = new DataContratHeader().getDataContratHeader(CompartimentType.C1);
	/* the generator*/
    private AbstractEvenGenerator generator;
    /**
	 * Gets the TriggeringResult.
	 *
	 * @return the TriggeringResult
	 */
	public TriggeringResult getTriggeringResult() {
		TriggeringResult triggeringResult = new TriggeringResult();
		triggeringResult.setContrat(contrat);
		triggeringResult.setGenerator(generator);
		triggeringResult.setIdGdi(idGdi);
		triggeringResult.setNumPersonne(numPersonne);
		triggeringResult.setTypeEvenement(typeEvenement);
		return triggeringResult;
	}
}
