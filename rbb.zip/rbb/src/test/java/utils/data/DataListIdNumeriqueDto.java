package utils.data;

import java.util.ArrayList;
import java.util.List;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.IdNumeriqueDto;
/**
 * The Class DataListIdNumeriqueDto.
 */
public class DataListIdNumeriqueDto {

	/**
	 * Gets the liste IdNumeriqueDto.
	 *
	 * @return the list of ldNumeriqueDto
	 */
	public List<IdNumeriqueDto> getListeldNumeriqueDto() {
		List<IdNumeriqueDto> liste = new ArrayList<>();
		liste.add(RandomData.getRandomIdNumeriqueDto());
		liste.add(RandomData.getRandomIdNumeriqueDto());
		liste.add(RandomData.getRandomIdNumeriqueDto());
		return liste;
	}
}
