package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.IdNumeriqueDto;

/**
 * The Class DataIdNumeriqueDto.
 */
@Ignore("Classe de données pour les tests")
public class DataIdNumeriqueDto {
	/** The data login. */
	private String login = RandomData.getRandomStringSize10();
	/** The data idFournisseurIdNumerique. */
	private Integer idFournisseurIdNumerique = RandomData.getRandomInt();
	
	/** The data IdNumerique DTO. */
	public IdNumeriqueDto getIdNumeriqueDto() {
		IdNumeriqueDto idNumeriqueDto = new IdNumeriqueDto();
		idNumeriqueDto.setIdFournisseurIdNumerique(idFournisseurIdNumerique);
		idNumeriqueDto.setLogin(login);
		return idNumeriqueDto;
	}
}
