package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;

/**
 * The Class DataLabelValue.
 */
@Ignore("Classe de données pour les tests")
public class DataLabelValue {
	
	/** The data label. */
	private String label = RandomData.getRandomStringSize10();
	/** The data value. */
	private String value = RandomData.getRandomStringSize10();
	
	/** The data LabelValue. */
	public LabelValue getLabelValue() {
		LabelValue labelValue = new LabelValue();
		labelValue.setLabel(label);
		labelValue.setValue(value);
		return labelValue;
	}
	
}
