package utils.data;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.InfoCanalDto;

/**
 * The Class DataListInfoCanalDto.
 */
@Ignore("Classe de données pour les tests")
public class DataListInfoCanalDto {
	
	/**
	 * Gets the liste InfoCanalDto.
	 *
	 * @return the InfoCanalDto.
	 */
	public List<InfoCanalDto> getListeInfoCanalDto() {
		List<InfoCanalDto> liste = new ArrayList<>();
		liste.add(RandomData.getRandomInfoCanalDto());
		liste.add(RandomData.getRandomInfoCanalDto());
		liste.add(RandomData.getRandomInfoCanalDto());
		return liste;
	}
}

