package utils.data;

import java.util.ArrayList;
import java.util.List;

import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;

public class DataListContratHeaderDto {

	
	public List<ContratHeaderDto> getListContratHeaderDto(){
		
		List<ContratHeaderDto> listContratHeaderDto = new ArrayList<>();
		
		DataContratHeaderDto dataContratHeaderDto1 = new DataContratHeaderDto();
		DataContratHeaderDto dataContratHeaderDto2 = new DataContratHeaderDto();
		
		listContratHeaderDto.add(dataContratHeaderDto1.getContratHeaderDto());
		listContratHeaderDto.add(dataContratHeaderDto2.getContratHeaderDto());
		
		
		return listContratHeaderDto;
		
	}
}
