package utils.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.soap.AdresseDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.DetailPersonneDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.EmailDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.IdentifiantDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.RoleContratPersonneDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.TelephoneDto;
import lombok.Getter;

/**
 * Gets the role ctr pers.
 *
 * @return the role ctr pers
 */

@Getter
@Ignore("Classe de données pour les tests")
public class DataPersonnePhysiqueDto {

	/** The ids. */
	private List<IdentifiantDto> ids = new ArrayList<IdentifiantDto>();
	
	/** The data identifiant dto. */
	private DataIdentifiantDto dataIdentifiantDto = new DataIdentifiantDto();
	
	/** The nom courant. */
	private String nomCourant = RandomData.getRandomStringSize10();

	/** The civilite. */
	private LabelValue civilite = RandomData.getRandomLabelValue();

	/** The nom. */
	private String nom = RandomData.getRandomStringSize10();

	/** The prenom. */
	private String prenom = RandomData.getRandomStringSize8();

	/** The nom jeune fille. */
	private String nomJeuneFille = RandomData.getRandomStringSize10();

	/** The sexe. */
	private LabelValue sexe = RandomData.getRandomLabelValue();

	/** The date naissance. */
	private Date dateNaissance = RandomData.getRandomDate_1930_1950();

	/** The date deces. */
	private Date dateDeces = RandomData.getRandomDate_2019_2020();

	/** The details. */
	private DetailPersonneDto details;

	/** The contact tel. */
	private List<TelephoneDto> contactTel ;
	

	/** The contact adresse. */
	private List<AdresseDto> contactAdresse ;
	
	/** The contact email. */
	private List<EmailDto> contactEmail ;
	
	/** The role ctr pers. */
	private List<RoleContratPersonneDto> roleCtrPers ;
	

	/** The date naissance majeur et moins 85 ans. */
	private Date dateNaissanceMajeurEtMoins85Ans = RandomData.getRandomDate_1960_1980();

	/**
	 * Gets the personne dto.
	 *
	 * @return the personne dto
	 */
	public PersonnePhysiqueDto getPersonneDto() {
		PersonnePhysiqueDto personneDto = new PersonnePhysiqueDto();
		ids.add(dataIdentifiantDto.getIdentifiantDtoSouscripteurs());
		personneDto.setIds(ids);
		personneDto.setNomCourant(nomCourant);
		personneDto.setCivilite(civilite);
		personneDto.setNom(nom);
		personneDto.setPrenom(prenom);
		personneDto.setNomJeuneFille(prenom);
		personneDto.setSexe(sexe);
		personneDto.setDateNaissance(dateNaissance);
		personneDto.setDateDeces(dateDeces);

		personneDto.setDetails(details);

		personneDto.setContactTel(contactTel);
		personneDto.setContactAdresse(contactAdresse);
		personneDto.setContactEmail(contactEmail);

		personneDto.setRoleCtrPers(roleCtrPers);

		return personneDto;
	}

}
