package utils.data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Ignore;

import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

/*
 * Cree le 9 juin 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author Emir
 * 
 * 
 */
@Ignore("Classe de données pour les tests")
public class DataEventJson {
	
	/** The id. */
	private Integer id = RandomData.getRandomInt();

	/** The TypeEvenementJson. */
    private TypeEvenementJson typeEvenement = new DataTypeEvenementJson().getDataTypeEvenementJson();
    
	/** The id gdi. */
    private String idGdi = RandomData.getRandomIdGDI();

	/** The numContrat. */
    private String numContrat = RandomData.getRandomStringSize10();
    
	/** The etatTraitement. */
    private EtatTraitementType etatTraitement = EtatTraitementType.ANNU;
    
	/** The dateDebut. */
    private Date dateDebut = RandomData.getRandomDate_1999_2000();
    
	/** The dateFin. */
    private Date dateFin = RandomData.getRandomDate_1999_2000();
    
    /**
	 * Gets the DataEventJson.
	 *
	 * @return the DataEventJson
	 */
	public EvenementJson getDataEventJson() {
		EvenementJson evenementJson = new EvenementJson();
		evenementJson.setId(id);
		evenementJson.setIdGdi(idGdi);
		evenementJson.setDateDebut(dateDebut);
		evenementJson.setDateFin(dateFin);
		evenementJson.setEtatTraitement(etatTraitement);
		evenementJson.setNumContrat(numContrat);
		evenementJson.setTypeEvenement(typeEvenement);
		return evenementJson;
	}
	
	/**
	 * Gets the List ofDataEventJson.
	 *
	 * @return list DataEventJson
	 */
	public List<EvenementJson> getListDataEventJson() {
		List<EvenementJson> evenementJsonList = new ArrayList<EvenementJson>();
		evenementJsonList.add(getDataEventJson());
		evenementJsonList.add(getDataEventJson());
		return evenementJsonList;
	}
}
