package utils.data;

import org.junit.Ignore;

import fr.ag2rlamondiale.epinlib.domain.sub.rest.HabilitationPartDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.zonecom.IdentifiantDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.LabelValue;
/**
 * The Class DataHabilitationPartDto.
 */
@Ignore("Classe de données pour les tests")
public class DataHabilitationPartDto {
	
	/** The data IdentifiantDto. */
	private IdentifiantDto id = new DataIdentifiantDtoZoneCom().getIdentifiantDto();	
	/** The data idHabilitationPart. */
	private String idHabilitationPart = RandomData.getRandomStringSize10();
	/** The data habilPartcl. */
	private LabelValue habilPartcl = new DataLabelValue().getLabelValue();
	
	/** The data HabilitationPartDto. */
	public HabilitationPartDto getHabilitationPartDto() {
		HabilitationPartDto habilitationPartDto = new HabilitationPartDto();
		habilitationPartDto.setHabilPartcl(habilPartcl);
		habilitationPartDto.setId(id);
		habilitationPartDto.setIdHabilitationPart(idHabilitationPart);
		return habilitationPartDto;
	}

	
}
