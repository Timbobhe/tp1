/*
 * Cree le 20 sep 2021. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author emir
 * 
 * 
 */
package utils.data;



import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;

/**
 * The Class DataListePersPhysDto.
 */

public class DataListePersPhysDto {

	/**
	 * Gets the liste pers phys dto.
	 *
	 * @return the liste pers phys dto
	 */
	public ListePersPhysDto getListePersPhysDto() {
		ListePersPhysDto ListePersPhysDto = new ListePersPhysDto();
		DataPersonnePhysiqueDto dataPersonnePhysiqueDto = new DataPersonnePhysiqueDto();
		DataPersonnePhysiqueDto dataPersonnePhysiqueDto2 = new DataPersonnePhysiqueDto();
		ListePersPhysDto.getListePP().add(dataPersonnePhysiqueDto.getPersonneDto() );
		ListePersPhysDto.getListePP().add(dataPersonnePhysiqueDto2.getPersonneDto() );
		return ListePersPhysDto;
	}


}
