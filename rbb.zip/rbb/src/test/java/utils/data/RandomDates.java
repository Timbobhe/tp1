/*
 * Cree le 25 févr. 2020. 
 *
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 * 
 * @author betton
 * 
 * 
 */
package utils.data;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

import org.junit.Ignore;

/**
 * The Class RandomDates.
 * 
 * @see https://www.logicbig.com/how-to/code-snippets/jcode-java-random-random-dates.html
 */
@Ignore("Classe de données pour les tests")
public class RandomDates {

	/**
	 * Creates the random int between.
	 *
	 * @param start the start
	 * @param end   the end
	 * @return the int
	 */
	private static int createRandomIntBetween(int start, int end) {
		return start + (int) Math.round(Math.random() * (end - start));
	}

	
	/**
	 * Creates the random date.
	 *
	 * @param Year the year
	 * @return the date
	 */
	public static Date createRandomDate(int Year) {
		return createRandomDate(Year, Year);
	}
	
	/**
	 * Creates the random date.
	 *
	 * @param startYear the start year
	 * @param endYear   the end year
	 * @return the local date
	 */
	public static LocalDate createRandomLocalDate(int startYear, int endYear) {
		int day = createRandomIntBetween(1, 28);
		int month = createRandomIntBetween(1, 12);
		int year = createRandomIntBetween(startYear, endYear);
		return LocalDate.of(year, month, day);
	}

	/**
	 * Gets the annee courante plus une.
	 *
	 * @return the annee courante plus une
	 */
	public static int getAnneeCourantePlusUne() {
		int year = Calendar.getInstance().get(Calendar.YEAR);
		return year + 1;
	}
	
	/**
	 * Gets the random date fin effet.
	 *
	 * @return the random date fin effet
	 */
	public static Date getRandomDateFinEffet() {
		int startYear = getAnneeCourantePlusUne() + 1;
		int endYear = startYear + 3;
		return createRandomDate(startYear, endYear);
	}
	
	/**
	 * Creates the random date.
	 * exemple createRandomDate(1900, 2000)
	 * @param startYear the start year
	 * @param endYear the end year
	 * @return the date
	 */
	public static Date createRandomDate(int startYear, int endYear) {
		// default time zone
		ZoneId defaultZoneId = ZoneId.systemDefault();
		LocalDate localDate = createRandomLocalDate(startYear, endYear);

		// local date + atStartOfDay() + default time zone + toInstant() = Date
		return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
	}
}
