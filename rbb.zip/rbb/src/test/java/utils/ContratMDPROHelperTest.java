package utils;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.utils.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContratMDPROHelperTest {
    @InjectMocks
    ContratMDPROHelper contratMDPROHelper;

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        ProduitJson produitDeductible = createProduitJson("RA09", "V01", "MADELIN", Boolean.TRUE);
        ProduitJson produitNonDeductible = createProduitJson("RA10", "V01", "IRC - ASS", Boolean.FALSE);
        ProduitJson produitPacteC2 = createProduitJson("RA09", "B01", null, null);
        ProduitJson produitPacteC3 = createProduitJson("RA09", "C01", null, null);

        when(paramConsoleFacade.findProduitMdpro("RA09V01")).thenReturn(produitDeductible);
        when(paramConsoleFacade.findProduitMdpro("RA10V01")).thenReturn(produitNonDeductible);
        when(paramConsoleFacade.findProduitMdpro("RA09B01")).thenReturn(produitPacteC2);
        when(paramConsoleFacade.findProduitMdpro("RA09C01")).thenReturn(produitPacteC3);
    }

    private ProduitJson createProduitJson(String typeContrat, String numGen, String fiscalite, Boolean deductible) {
        ProduitJson produit = new ProduitJson();
        produit.setCodeFiliale("LMX");
        produit.setTypeContrat(typeContrat);
        produit.setNumeroGeneration(numGen);
        produit.setLibelleFiscalite(fiscalite);
        produit.setDeductible(deductible);
        return produit;
    }

    private ContratHeader createContratHeader(String TypeContrat, String numGen) {
        ContratHeader contrat = new ContratHeader();
        contrat.setTypeContrat(TypeContrat);
        contrat.setNumGenContrat(numGen);
        return contrat;
    }

    @Test
    public void isC2PacteTest() {
        ContratHeader contrat = createContratHeader("RA00","");
        assertFalse(contratMDPROHelper.isC2Pacte(contrat));
        
        contrat = createContratHeader("RA09","");
        assertFalse(contratMDPROHelper.isC2Pacte(contrat));
        
        contrat = createContratHeader("RA09","00");
        assertFalse(contratMDPROHelper.isC2Pacte(contrat));
        
        contrat = createContratHeader("RA09","B01");
        assertTrue(contratMDPROHelper.isC2Pacte(contrat));
    }
    
    @Test
    public void isC3PacteTest() {
        ContratHeader contrat = createContratHeader("RA00","");
        assertFalse(contratMDPROHelper.isC3Pacte(contrat));
        
        contrat = createContratHeader("RA09","");
        assertFalse(contratMDPROHelper.isC3Pacte(contrat));
        
        contrat = createContratHeader("RA09","00");
        assertFalse(contratMDPROHelper.isC3Pacte(contrat));
        
        contrat = createContratHeader("RA09","C01");
        assertTrue(contratMDPROHelper.isC3Pacte(contrat));
    }
    
    @Test
    public void isContratNonPacteTest() {
        ContratHeader contrat = createContratHeader("RA00","");
        assertFalse(contratMDPROHelper.isContratNonPacte(contrat));
        
        contrat = createContratHeader("RA09","V01");
        assertTrue(contratMDPROHelper.isContratNonPacte(contrat));
        
        contrat = createContratHeader("RA09","C01");
        assertFalse(contratMDPROHelper.isContratNonPacte(contrat));
    }
    
    @Test
    public void isContratPacteTest() {
        ContratHeader contrat = createContratHeader("RA00","");
        assertFalse(contratMDPROHelper.isContratPacte(contrat));
        
        contrat = createContratHeader("RA09","");
        assertFalse(contratMDPROHelper.isContratPacte(contrat));
        
        contrat = createContratHeader("RA09","00");
        assertFalse(contratMDPROHelper.isContratPacte(contrat));
        
        contrat = createContratHeader("RA09","C01");
        assertTrue(contratMDPROHelper.isContratPacte(contrat));
    }

    @Test
    public void isContratDeductibleTest() {
        ContratHeader contrat = createContratHeader("RA00","");
        assertFalse(contratMDPROHelper.isContratDeductible(contrat));

        contrat = createContratHeader("RA09","");
        assertFalse(contratMDPROHelper.isContratDeductible(contrat));

        contrat = createContratHeader("RA09","V01");
        assertTrue(contratMDPROHelper.isContratDeductible(contrat));

        contrat = createContratHeader("RA10","V01");
        assertFalse(contratMDPROHelper.isContratDeductible(contrat));
    }

    @Test
    public void isVifPossibleTest() {
        ContratHeader contrat = createContratHeader("RA09","");
        assertFalse(contratMDPROHelper.isVifPossible(contrat));

        contrat = createContratHeader("RA09","B01");
        assertFalse(contratMDPROHelper.isVifPossible(contrat));

        contrat = createContratHeader("RA09","V01");
        assertTrue(contratMDPROHelper.isVifPossible(contrat));

        contrat = createContratHeader("RA10","V01");
        assertTrue(contratMDPROHelper.isVifPossible(contrat));
    }
}
