package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.dto.tracking.TrackingInfoDto;

public interface ITrackingFacade {
    TrackingInfoDto getTrackingInfo() throws TechnicalException;
}
