package fr.ag2rlamondiale.rbb.business.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.rbb.business.call.CallNaviguerClientsContrats;
import fr.ag2rlamondiale.rbb.business.call.CallRechPersPhysClient;
import fr.ag2rlamondiale.rbb.business.call.CallRechercherHabiliPers;
import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import fr.ag2rlamondiale.rbb.utils.Constantes.contrat_retraite_exclu;
import fr.ag2rlamondiale.rbb.utils.ErrorConstantes;
import fr.ag2rlamondiale.rbb.utils.ProduitAutorisePrevoyanceTNS;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutoriseEpargne;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutorisePrevoyanceIndividuelle;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutorisePrevoyanceTNS;
import fr.ag2rlamondiale.rib.business.ISupplierRibService;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratConstants;
import fr.ag2rlamondiale.trm.domain.contrat.MetierContratType;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Sets;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RbbSupplierRibServiceImpl implements ISupplierRibService {

	@Autowired
	CallNaviguerClientsContrats callNaviguerClientsContrats;

	@Autowired
	private UserContextHolder userContextHolder;

	@Autowired
	CallRechercherHabiliPers callRechercherHabiliPers;

	@Autowired
	CallRechPersPhysClient callRechPersPhysClient8;

	@Value("#{${fr.ag2rlamondiale.produits.mdpro.libelle}}")
	Map<String, String> libelleProduitMdproMap;

	@Value("#{${fr.ag2rlamondiale.produits.retraite.libelle}}")
	Map<String, String> libelleProduitRetraiteSupMap;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ContratHeader> recupererContrats(MetierContratType origin, String tag) throws TechnicalException {

		List<ContratHeader> contrats = new ArrayList<>();
		PersonnePhysiqueDto personnePhysiqueDto = null;

		try {
			String idGdi = getClientIdGdi();
			personnePhysiqueDto = getPersonnePhysiqueDto(idGdi);

			ClientDto clientDto = callNaviguerClientsContrats.callNaviguerClientsContrats4(idGdi, personnePhysiqueDto);
			List<ContratHeader> allContrats = new ArrayList<>();
			allContrats = mappingContratsDtoToContratsHeaderDto(clientDto.getListeContrat());
					
			contrats = allContrats.stream().filter( c ->this.isContratsEligible(c)&& this.isContratsAuthorized(c)).collect(Collectors.toList());

			log.info("Metier : " + origin);
			log.info("TAG : " + tag);
			log.info("Liste contrats : " + allContrats);

			switch (origin) {
			case EPARGNE:
				contrats = tag.equals(Constantes.PRINCIPAL)
						? contrats.stream().filter(c -> c.getMetierContratType().equals(origin)).collect(Collectors.toList())
						: contrats.stream().filter(c -> !c.getMetierContratType().equals(origin)).collect(Collectors.toList());
				break;
			case PREVOYANCE:
				contrats = tag.equals(Constantes.PRINCIPAL)
						? contrats.stream().filter(c ->
								c.getMetierContratType().equals(MetierContratType.PREVOYANCE_INDIV) ||
								c.getMetierContratType().equals(MetierContratType.PREVOYANCE_TNS))
								.collect(Collectors.toList())
						: contrats.stream().filter(c -> !(
								c.getMetierContratType().equals(MetierContratType.PREVOYANCE_INDIV) ||
								c.getMetierContratType().equals(MetierContratType.PREVOYANCE_TNS)))
								.collect(Collectors.toList());

				break;
			case CM:
				contrats = tag.equals(Constantes.PRINCIPAL)
					? contrats.stream().filter(c -> c.getMetierContratType().equals(origin)).collect(Collectors.toList())
							: contrats.stream().filter(c -> !c.getMetierContratType().equals(origin)).collect(Collectors.toList());
					break;
			case RETRAITE_SUPPLEMENTAIRE:
				contrats = tag.equals(Constantes.PRINCIPAL)
					? contrats.stream().filter(c -> c.getMetierContratType().equals(origin)).collect(Collectors.toList())
						: contrats.stream().filter(c -> !c.getMetierContratType().equals(origin)).collect(Collectors.toList());
					break;
			default:
				contrats = new ArrayList<>();
			}

		} catch (TechnicalException | EligibiliteException e) {
			log.error("ERROR sur call naviguerClientsContrats4Service {}", e);
		}
		return contrats;
	}

	public String getClientIdGdi() {
		final UserContext userContext = userContextHolder.get();
		Objects.requireNonNull(userContext);
		return userContext.getIdGdi();
	}

	public PersonnePhysiqueDto getPersonnePhysiqueDto(String idGdi) throws EligibiliteException {

		String idPersonne = callRechercherHabiliPers.callRechercherHabiliPersService(idGdi);

		ListePersPhysDto retour;

		try {
			retour = callRechPersPhysClient8.callRechPersPhysClient8Service(idPersonne);

		} catch (TechnicalException e) {
			log.error(ErrorConstantes.ERROR_RECHPERSPHYS, e);
			throw new EligibiliteException(ErrorConstantes.ERREUR_TECHNIQUE, e.getLocalizedMessage());

		}

		if (retour.getListePP().isEmpty()) {
			throw new EligibiliteException(ErrorConstantes.ELIGIBILITE_PERSONNE_CODE_KO,
					ErrorConstantes.ELIGIBILITE_PERSONNE_PHYSIQUE_INTROUVABLE);
		}

		// RG Métier
		return retour.getListePP().stream().findFirst().orElse(new PersonnePhysiqueDto());

	}

	@Override
	public MetierContratType getMetierContratPrincipale() { // TODO à changer par Epargne
		return MetierContratType.EPARGNE;
	}

	@Override
	public Set<MetierContratType> getMetiersContratSecondaires() {
		return Sets.set(MetierContratType.RETRAITE_SUPPLEMENTAIRE);
	}// TODO à changer par retraite supp selon règle métier

	public boolean isContratNonPacteAffichable(ContratComplet contratComplet) {
		return AffichageType.NORMAL.equals(contratComplet.getContratHeader().getAffichageType());
	}

	public boolean isContratPacteAffichable(ContratComplet contratComplet) {
		List<Compartiment> c1 = contratComplet.getContratHeader().compartiments(CompartimentType.C1);
		if (c1.size() > 1) {
			throw new IllegalArgumentException(
					contratComplet.getContratHeader().getId() + " est un contrat pacte et a plusieurs C1");
		}
		if (!c1.isEmpty() && c1.get(0).getAffichageType().isSelectable()) {
			return true;
		}
		List<Compartiment> c4 = contratComplet.getContratHeader().compartiments(CompartimentType.C4);
		if (c4.size() > 1) {
			throw new IllegalArgumentException(
					contratComplet.getContratHeader().getId() + " est un contrat pacte et a plusieurs C4");
		}
		if (!c4.isEmpty()) {
			return c4.get(0).getAffichageType().isSelectable();
		}
		return false;
	}

	public boolean isContratEpargne(ContratHeader x) {

		Boolean is = ProduitVersionAutoriseEpargne.contains(x.getTypeContrat(), x.getNumGenContrat());

		if (is) {
			x.setMetierContratType(MetierContratType.EPARGNE);
		}

		return is;

	}

	public boolean isContratPrevoyance(ContratHeader x) {

		Boolean isContratPrevoyanceTNS = ProduitVersionAutorisePrevoyanceTNS.contains(x.getTypeContrat(), x.getNumGenContrat())
				|| ProduitAutorisePrevoyanceTNS.contains(x.getTypeContrat());

		if (isContratPrevoyanceTNS) {
			x.setMetierContratType(MetierContratType.PREVOYANCE_TNS);
		}

		Boolean isContratPrevoyanceIndividuelle = ProduitVersionAutorisePrevoyanceIndividuelle.contains(x.getTypeContrat(), x.getNumGenContrat());

		if (isContratPrevoyanceIndividuelle) {
			x.setMetierContratType(MetierContratType.PREVOYANCE_INDIV);
		}

		Boolean isContratPrevoyance = ProduitAutorisePrevoyanceTNS.contains(x.getTypeContrat());

		if (isContratPrevoyanceIndividuelle) {
			x.setMetierContratType(MetierContratType.PREVOYANCE_INDIV);
		}
		return isContratPrevoyanceTNS || isContratPrevoyanceIndividuelle || isContratPrevoyance;

	}

	public boolean isContratCertificatMutualiste(ContratHeader x) {

		Boolean is = x.getId().startsWith(Constantes.PREFIX_CM);

		if (is) {
			x.setMetierContratType(MetierContratType.CM);
		}

		return is;

	}

	public boolean isContratsEligible(ContratHeader x) {
		return isContratEpargne(x) || isContratPrevoyance(x) || isRetraiteSupp(x) || isContratCertificatMutualiste(x);
	}
	
	public boolean isContratsAuthorized(ContratHeader x) {
		String codeContrat =  x.getTypeContrat();
		if(x.getNumGenContrat() != null  && !x.getNumGenContrat().trim().isEmpty() ) {
			codeContrat +=  x.getNumGenContrat();
		} 
		return !EnumUtils.isValidEnum(contrat_retraite_exclu.class, codeContrat);
	}
	

	public List<ContratHeader> mappingContratsDtoToContratsHeaderDto(List<ContratDto> contratsDto) {

		List<ContratHeader> contratsHeaderDto = new ArrayList<ContratHeader>();
		if (contratsDto != null) {
			for (ContratDto contratDto : contratsDto) {

				ContratHeader contratHeaderDto = new ContratHeader();

				contratHeaderDto.setId(contratDto.getIdentSiloContrat().getId());
				contratHeaderDto.setDateEffet(contratDto.getDateEffet());
				contratHeaderDto.setDateFinEffet(contratDto.getDateFinEffet());
				contratHeaderDto.setDateSitCtr(contratDto.getDateSitContrat());
				contratHeaderDto.setStatut(contratDto.getSitContrat().getValue());
				// ofrCialLg est un champ qui peut etre null dans REPERE
				if(contratDto.getIdentSiloContrat().getId().startsWith(Constantes.PREFIX_CM)) {
					contratHeaderDto.setDescriptionFront("Certificats Mutualistes");
					contratHeaderDto.setCodeAssureur(contratDto.getAssCtr().getLabel());
				}	else {
					setLibelleContrat(contratDto,contratHeaderDto);
					contratHeaderDto.setCodeAssureur(contratDto.getAssCtr().getValue());
				}
				contratHeaderDto.setLibelleProduit(contratDto.getOfrCialLg().getLabel());
				contratHeaderDto.setCodeSilo(CodeSiloType.MDP);
				contratHeaderDto.setAffichageType(null);
				contratHeaderDto.setClasseAutreContrat(false);
				contratHeaderDto.setCodeCadreFiscal(null);
				contratHeaderDto.setCodeFiliale(null);
				contratHeaderDto.setCodeMentionLegale(null);
				contratHeaderDto.setCodeProduit(null);
				contratHeaderDto.setCodeSitAffil(null);
				contratHeaderDto.setCollege(null);
				contratHeaderDto.setCompartiments(null);
				contratHeaderDto.setContractanteRepresent(false);
				contratHeaderDto.setDateAffiliation(null);
				contratHeaderDto.setDateEffetSituationAffiliation(null);
				contratHeaderDto.setDateSitAffil(null);
				contratHeaderDto.setDateSitCtr(null);
				contratHeaderDto.setDeductible(false);
				contratHeaderDto.setDescClauseBenef(null);
				contratHeaderDto.setEtatAffiliationLabel(null);
				contratHeaderDto.setEtatContrat(null);
				contratHeaderDto.setEtatContratLabel(null);
				contratHeaderDto.setHasVersementProgrammes(false);
				contratHeaderDto.setIdAdherente(null);
				contratHeaderDto.setIdCollege(null);
				contratHeaderDto.setIdContractante(null);
				contratHeaderDto.setIdContratReference(null);
				contratHeaderDto.setIdentifiantAssure(null);
				contratHeaderDto.setLibCadreFiscal(null);
				contratHeaderDto.setLibelleProduit(null);
				contratHeaderDto.setLibSitAffil(null);
				contratHeaderDto.setPacte(false);
				contratHeaderDto.setPartsType(null);
				contratHeaderDto.setPersonId(null);
				contratHeaderDto.setPetitCollectifPTV(false);
				contratHeaderDto.setRaisonSocialeAdherente(null);
				contratHeaderDto.setRaisonSocialeContractante(null);
				contratHeaderDto.setRaisonSocialeFront(null);
				contratHeaderDto.setCodeProduit(contratHeaderDto.getTypeContrat() + "-"
						+ contratHeaderDto.getNumGenContrat() + "-" + contratHeaderDto.getCodeFiliale());
				contratsHeaderDto.add(contratHeaderDto);
			}
		}

		return contratsHeaderDto;

	}
	
	public  void setTypeVersionContrat(ContratDto contratDto, ContratHeader contratHeaderDto) {
		if (contratDto.getOfrCialLg() != null && contratDto.getOfrCialLg().getValue() != null) {
			if (contratDto.getOfrCialLg().getValue().length()<7) {
				contratHeaderDto.setTypeContrat(contratDto.getOfrCialLg().getValue());
				contratHeaderDto.setNumGenContrat(null);
			}
			else {
				contratHeaderDto.setTypeContrat(contratDto.getOfrCialLg().getValue().substring(0, 4));
				contratHeaderDto.setNumGenContrat(contratDto.getOfrCialLg().getValue().substring(4, 7));
			}
			contratHeaderDto.setLibelleProduit(contratDto.getOfrCialLg().getLabel());
		}
	}
	
	public void setLibelleContrat(ContratDto contratDto, ContratHeader contratHeaderDto) {
		setTypeVersionContrat(contratDto, contratHeaderDto);
		String codeContrat =  contratHeaderDto.getTypeContrat();
		if(contratHeaderDto.getNumGenContrat() != null  && !contratHeaderDto.getNumGenContrat().trim().isEmpty() ) {
			codeContrat = contratHeaderDto.getTypeContrat() + contratHeaderDto.getNumGenContrat();
		} 
		if (libelleProduitMdproMap.get(codeContrat) != null) {
			contratHeaderDto.setDescriptionFront(libelleProduitMdproMap.get(codeContrat));
		} else if (libelleProduitRetraiteSupMap.get(codeContrat) != null) {
			contratHeaderDto.setDescriptionFront(libelleProduitRetraiteSupMap.get(codeContrat));
		} else {
			contratHeaderDto.setDescriptionFront(codeContrat);
		}
	}
	
	public boolean isRetraiteSupp(ContratHeader contrat) {
		if (contrat == null) {
			return false;
		}

		if (CodeSiloType.MDP.equals(contrat.getCodeSilo())) {
			final String prefix = contrat.getId().substring(0, 2);
			Boolean is = ContratConstants.MDPRO_PREFIX_IDCONTRAT_RETRAITE_SUPP.contains(prefix);

			if (is) {
				contrat.setMetierContratType(MetierContratType.RETRAITE_SUPPLEMENTAIRE);
			}

			return is;

		}
		log.info("contrat : " + contrat);
		return true;
	}

}
