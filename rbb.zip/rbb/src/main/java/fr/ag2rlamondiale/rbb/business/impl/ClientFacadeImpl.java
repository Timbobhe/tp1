package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IClientFacade;
import fr.ag2rlamondiale.rbb.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.rbb.domain.exception.PartenaireException;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IRechercherPPSiloClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.*;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.trm.utils.ErrorConstantes.UTILISATEUR_NON_TROUVE;

@Service
public class ClientFacadeImpl implements IClientFacade {
    @Autowired
    private IRechercherHabiliFacade habiliService;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private
    IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private IRechercherPPSiloClient rechercherPP;

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException {
        PersonnePhysique user = habiliService.rechercherParIdGdi(idGdi);
        if (null == user || null == user.getNumeroPersonneEre() && null == user.getNumeroPersonneMdpro()) {
            throw new BusinessException(UTILISATEUR_NON_TROUVE);
        }
        return user;
    }

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne)
            throws CommonException {
        IdSiloDto crit = CodeApplicationType.EGESPER_MDPRO.idSilo(numeroDePersonne);
        PersonnePhysiqueConsult ppc;
        try {
            ppc = consulterPersonneClient.consulterPersPhys(crit);
        } catch (TechnicalException e) {
            if (e.getCause().getMessage().contains("PERSONNE-PHYSIQUE-INEXISTANTE")) {
                throw new PartenaireException(PartenaireException.ErrorCode.UNKNOWN_USER);
            } else {
                throw e;
            }
        }
        PersonnePhysique user = new PersonnePhysique();
        user.setNom(ppc.getNom());
        user.setPrenom(ppc.getPrenom());
        user.setNumeroPersonneEre(numeroDePersonne);
        user.setCivilite(ppc.getCivilite());

        PersonnePhysique userHabili =
                habiliService.rechercherParNumPers(numeroDePersonne, CodeSiloType.ERE);
        user.setIdGdi(userHabili != null ? userHabili.getIdGdi() : null);
        return user;
    }

    @Override
    public ModifierPPSiloResponseDto modifierCoordonneesClient(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException {
        return modifierCoordonneesClientMDPRO(nouvellesCoordonnees);
    }

    private ModifierPPSiloResponseDto modifierCoordonneesClientMDPRO(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        // recuperer la personne physique depuis la Base
        PersonnePhysiqueConsult persPhys = consulterPersonneClient.consulterPersPhys(userContext.getIdSilo());
        persPhys.setEmailPerso(nouvellesCoordonnees.getEmail());
        persPhys.setTelPortable(nouvellesCoordonnees.getTelPortable());
        return new ModifierPPSiloResponseDto(true);
    }

    @Override
    public RechercherPPSiloResponseDto rechercherPPSilo(DemandeRecherchePP demandeRecherchePP) throws TechnicalException {
        return rechercherPP.rechercherPPSilo(demandeRecherchePP);
    }
}
