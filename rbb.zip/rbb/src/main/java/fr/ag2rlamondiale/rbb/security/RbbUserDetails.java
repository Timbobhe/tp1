/*
 * Cree le 30 janv. 2019.
 * (c) Ag2r - La Mondiale, 2019. Tous droits reserves.
 */
package fr.ag2rlamondiale.rbb.security;

import com.ag2r.common.security.acegi.dao.IUserDetailsMetis;
import com.ag2r.common.security.acegi.dao.UserDetailsImpl;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

public class RbbUserDetails extends User implements IUserDetailsMetis {

    private static final long serialVersionUID = 8508855598660303652L;

    private UserDetails userDetails;

    public RbbUserDetails(UserDetails userDetails, Boolean enable) {
        super(userDetails.getUsername(), userDetails.getPassword(), userDetails.isEnabled(),
                userDetails.isAccountNonExpired(), userDetails.isCredentialsNonExpired(),
                enable, userDetails.getAuthorities());
        this.userDetails = userDetails;
    }

    @Override
    public String getEnvironnement() {
        return null;
    }

    @Override
    public void setEnvironnement(String environnement) {
        // Nothing
    }

    @Override
    public String getCodeDelegation() {
        return null;
    }

    @Override
    public void setCodeDelegation(String codeDelegation) {
        // Nothing
    }

    @Override
    public String getUserFirstLastName() {
        if (userDetails != null) {
            return (String) ((UserDetailsImpl) userDetails).getAttributesMap().get("uid");
        }
        return null;
    }

    @Override
    public void setUserFirstLastName(String userFirstLastName) {
        // Nothing
    }

    @Override
    public String getUserMail() {
        return null;
    }

    @Override
    public void setUserMail(String userMail) {
        // Nothing
    }

    @Override
    public String getUserSn() {
        return null;
    }

    @Override
    public void setUserSn(String userSn) {
        // Nothing
    }

    @Override
    public String getUserGivenName() {
        return null;
    }

    @Override
    public void setUserGivenName(String userGivenName) {
        // Nothing
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((userDetails == null) ? 0 : userDetails.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        RbbUserDetails other = (RbbUserDetails) obj;
        if (userDetails == null) {
            if (other.userDetails != null)
                return false;
        } else if (!userDetails.equals(other.userDetails))
            return false;
        return true;
    }
}
