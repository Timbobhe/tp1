package fr.ag2rlamondiale.rbb.mapping;

import fr.ag2rlamondiale.rbb.dto.ClientDto;
import fr.ag2rlamondiale.rbb.dto.InfosBlocagesClientDto;
import fr.ag2rlamondiale.rbb.dto.PartenaireDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContext;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface ClientMapper {
    @Mapping(source = "infosBlocagesClient", target = "infosBlocagesClient", qualifiedByName = "InfosBlocagesClient")
    @Mapping(source = "partenaire", target = "partenaire", qualifiedByName = "Partenaire")
    @Mapping(source = "silos", target = "silos", qualifiedByName = "CodeSilo")
    ClientDto map(UserContext userContext);

    @Named("InfosBlocagesClient")
    InfosBlocagesClientDto map(InfosBlocagesClient infosBlocagesClient);

    @Named("Partenaire")
    PartenaireDto map(Partenaire partenaire);

    @Named("CodeSilo")
    default String map(CodeSiloType codeSiloType) {
        return codeSiloType != null ? codeSiloType.name() : null;
    }
}
