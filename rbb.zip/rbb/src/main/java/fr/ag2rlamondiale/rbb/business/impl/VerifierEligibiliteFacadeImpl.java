package fr.ag2rlamondiale.rbb.business.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.rbb.business.IVerifierEligibiliteFacade;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import fr.ag2rlamondiale.rbb.utils.ErrorConstantes;
import fr.ag2rlamondiale.rbb.utils.ProduitAutorisePrevoyanceTNS;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutoriseEpargne;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutorisePrevoyanceIndividuelle;
import fr.ag2rlamondiale.rbb.utils.ProduitVersionAutorisePrevoyanceTNS;
import fr.ag2rlamondiale.trm.domain.contrat.ContratConstants;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("verifierEligibiliteFacadeImpl")
public class VerifierEligibiliteFacadeImpl implements IVerifierEligibiliteFacade {

	@Override
	public List<ContratHeaderDto> verifierEligibiliteVersionAutorise(List<ContratHeaderDto> listeContrat)
			throws EligibiliteException {
		List<ContratHeaderDto> listeContratAutorise = listeContrat.stream().filter(this::controleProduitVersion)
				.collect(Collectors.toList());
		listeContratAutorise.forEach(x -> log.info("Contrat retenus : " + x.getTypeContrat() + x.getNumGenContrat()));

		// Si aucun contrats Eligible arrÃªter le taraitemnt avec message KO
		if (listeContratAutorise.isEmpty()) {
			throw new EligibiliteException(ErrorConstantes.ELIGIBILITE_CONTRAT_CODE_KO,
					ErrorConstantes.ELIGIBILITE_CONTRAT_MESSAGE_KO);
		} else {
			return listeContratAutorise;

		}
	}

	//extraire les contrats eligibles
	public boolean controleProduitVersion(ContratHeaderDto x) {
		final String prefixRetraiteSup = x.getId().substring(0, 2);
		return ProduitVersionAutoriseEpargne.contains(x.getTypeContrat(), x.getNumGenContrat())
					|| ProduitVersionAutorisePrevoyanceTNS.contains(x.getTypeContrat(), x.getNumGenContrat())
					|| ProduitVersionAutorisePrevoyanceIndividuelle.contains(x.getTypeContrat(), x.getNumGenContrat())
					|| ProduitAutorisePrevoyanceTNS.contains(x.getTypeContrat())
					||  x.getId().startsWith(Constantes.PREFIX_CM)
					|| ContratConstants.MDPRO_PREFIX_IDCONTRAT_RETRAITE_SUPP.contains(prefixRetraiteSup);
	}

}
