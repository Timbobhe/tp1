package fr.ag2rlamondiale.rbb.domain.even;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.rbb.domain.even.EvenUtils.*;
import static fr.ag2rlamondiale.trm.domain.CodeApplicationType.EGESPER_ERE;

public abstract class AbstractEvenWithoutContratGenerator extends AbstractEvenGenerator {

    @Autowired
    protected IConsulterPersonneClient consulterPersonneClient;

    /**
     * Evaluer l'évènement en fonction d'un user donné (numPersonne).
     *
     * @param numPersonne
     * @return true si l'évènement doit être déclenché, false sinon
     */
    protected abstract boolean evaluerEvenement(String numPersonne);

    @Override
    public EvenementJson generateNextEven(TriggeringResult result) {
        if (evaluerEvenement(result.getNumPersonne())) {
            EvenementJson newEvenement = new EvenementJson();
            newEvenement.setIdGdi(result.getIdGdi());
            newEvenement.setTypeEvenement(result.getTypeEvenement());
            newEvenement.setDateDebut(new Date());
            newEvenement.setNumContrat(null);
            return newEvenement;
        }
        return null;
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (!isPersonneAutorisee(idGdi, numPersonne, typeEven.getPerimetreEvenements())) {
            return;
        }

        List<EvenementJson> evenementsForType = getEvenementsForType(typeEven, historiqueEvens);

        if (!typeEven.isObligatoire() && !pasEncorePresenteAujourdhui(evenementsForType)) {
            return;
        }
        if (dejaTraite(evenementsForType)) {
            return;
        }
        if (!neDepassePasNombreMaxDeclenchements(typeEven, evenementsForType)) {
            return;
        }
        if (!respecteDelaiReactivation(typeEven, evenementsForType)) {
            return;
        }
        results.add(this, idGdi, numPersonne, typeEven);
    }

    /**
     * Filtre les évènements pour ne conserver que ceux associés au type passé en paramètre.
     *
     * @param typeEvenement
     * @param evenementsDejaEnregistres
     * @return
     */
    protected List<EvenementJson> getEvenementsForType(TypeEvenementJson typeEvenement,
                                                       List<EvenementJson> evenementsDejaEnregistres) {
        if (CollectionUtils.isEmpty(evenementsDejaEnregistres)) {
            return Collections.emptyList();
        }
        return evenementsDejaEnregistres.stream()
                .filter(evt -> typeEvenement.equals(evt.getTypeEvenement()))
                .collect(Collectors.toList());
    }

    @Override
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {
        super.prepare(idGdi, numPersonne, contrats);
        if (numPersonne != null) {
            consulterPersonneClient.cacheEvictConsulterPersPhys(IdSiloDto.forAppli(numPersonne, EGESPER_ERE));
        }
    }
}
