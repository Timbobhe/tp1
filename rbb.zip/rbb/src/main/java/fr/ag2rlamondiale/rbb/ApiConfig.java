package fr.ag2rlamondiale.rbb;

import fr.ag2rlamondiale.jnb.JahiaNgServerConfig;
import fr.ag2rlamondiale.rib.RibConfig;
import fr.ag2rlamondiale.trm.business.DefaultImplConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Configuration
@ComponentScan
@Import({RibConfig.class, DefaultImplConfig.class, JahiaNgServerConfig.class})
public class ApiConfig {
    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(-1); // gérer applicativement
        return multipartResolver;
    }
}
