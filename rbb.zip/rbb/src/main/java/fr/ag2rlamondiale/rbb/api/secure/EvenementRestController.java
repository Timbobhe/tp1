package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IEvenementFacade;
import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.rbb.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/secure")
public class EvenementRestController {
    @Autowired
    private IEvenementFacade evenementFacade;

    @ProfileExecution(codeAction = CodeActionType.API_EVENEMENTS_NEXT)
    @LogExecutionTime
    @GetMapping(path = "/evenements/next")
    public EvenementJson getNextEven() throws TechnicalException {
        return evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate().negate(), false);
    }
}
