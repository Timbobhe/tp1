package fr.ag2rlamondiale.rbb.domain.enumeration;

import java.util.stream.Stream;

import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.security.UserContext;
import lombok.Getter;

@Getter
public enum CodeSiloType {
    ERE("ERE") {
        @Override
        public String getNumeroPersonne(UserContext userContext) {
            return userContext.getNumeroPersonneEre();
        }

        @Override
        public CodeApplicationType workflow() {
            return CodeApplicationType.WORKFLOW_ERE;
        }

        @Override
        public CodeApplicationType ptv() {
            return CodeApplicationType.PTV_ERE;
        }

        @Override
        public CodeApplicationType egesper() {
            return CodeApplicationType.EGESPER_ERE;
        }
    }, MDP("MDP") {
        @Override
        public String getNumeroPersonne(UserContext userContext) {
            return userContext.getNumeroPersonneMdpro();
        }

        @Override
        public CodeApplicationType workflow() {
            return CodeApplicationType.WORKFLOW_MDPRO;
        }

        @Override
        public CodeApplicationType ptv() {
            return CodeApplicationType.X8_MDPRO;
        }

        @Override
        public CodeApplicationType egesper() {
            return CodeApplicationType.EGESPER_MDPRO;
        }
    };

    private String libelle;

    CodeSiloType(String libelle) {
        this.libelle = libelle;
    }

    public abstract String getNumeroPersonne(UserContext userContext);

    public abstract CodeApplicationType workflow();

    public abstract CodeApplicationType ptv();

    public abstract CodeApplicationType egesper();

    public static CodeSiloType fromLibelle(String libelle) {
        return Stream.of(values()).filter(e -> e.libelle.equals(libelle)).findFirst().orElse(null);
    }
}
