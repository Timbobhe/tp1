package fr.ag2rlamondiale.rbb.business.impl;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;

import java.util.List;

public final class TraceHelper {
    public static final String SEPARATEUR = " | ";
    public static final String CONTRAT = "CT";
    public static final String ADH = "ADH";
    public static final String CAT_PERS = "CP";

    private TraceHelper() {
        // Empty
    }

    /**
     * Concaténe le N° de contrat + N° d'adherent + N° cat perso de tous les contrats de l'Assuré.
     *
     * @param contrats
     */
    public static String getZone1ofAllContractofPP(List<ContratHeader> contrats) {
        StringBuilder zone1 = new StringBuilder();
        if (contrats != null) {
            for (ContratHeader contrat : contrats) {
                zone1.append(formatZone1(contrat.getId(), contrat.getIdAdherente(), contrat.getIdCollege()));
                zone1.append(SEPARATEUR);
            }
            return removeLastDelimiter(zone1.toString());
        } else {
            return zone1.toString();
        }
    }

    /**
     * Concaténe le N° de contrat + N° d'adherent de tous les contrats de l'Entreprise. Pas de N° de
     * cat perso quand on récupère tous les contrats de l'Entreprise.
     *
     * @param contrats
     */
    public static String getZone1ofAllContractofPM(String idPM, List<ContratHeader> contrats) {
        StringBuilder zone1 = new StringBuilder();
        if (contrats != null) {
            for (ContratHeader contrat : contrats) {
                // Connecté sur la Contractante
                if (idPM.equals(contrat.getIdContractante())) {
                    zone1.append(formatZone1(contrat.getId(), null, null));
                    // Connecté sur l'Adhérente
                } else {
                    zone1.append(formatZone1(contrat.getId(), idPM, null));
                }
                zone1.append(SEPARATEUR);
            }
            return removeLastDelimiter(zone1.toString());
        } else {
            return zone1.toString();
        }
    }

    /**
     * Concaténe le N° de contrat + N° d'adherent + N° cat perso d'un contrat.
     *
     * @param contrat
     */
    public static String getZone1ofContrat(ContratHeader contrat) {
        return formatZone1(contrat.getId(), contrat.getIdAdherente(), contrat.getIdCollege());
    }

    /**
     * MDPRO.
     *
     * @param contrat
     */
    public static String getZone1ofContratMDPRO(ContratHeader contrat) {
        return CONTRAT + replaceNullWithEmptyString(contrat.getId());
    }

    /**
     * Concaténe le N° de contrat + N° d'adherent + N° cat perso d'un contrat.
     */
    public static String formatZone1(String contratNumber, String adherenteNumber, String categoriePersNumber) {
        return CONTRAT + replaceNullWithEmptyString(contratNumber) + SEPARATEUR + ADH + replaceNullWithEmptyString(
                adherenteNumber) + SEPARATEUR + CAT_PERS + replaceNullWithEmptyString(categoriePersNumber);
    }

    /**
     * On supprime le dernier séparateur de la zone 1
     *
     * @param zone1
     * @return
     */
    public static String removeLastDelimiter(String zone1) {
        return zone1.isEmpty() ? zone1 : zone1.substring(0, zone1.length() - 3);
    }

    /**
     * Si le String est null on remplace par un caractère vide sinon on ajoute un espace avant
     *
     * @param valueAsString
     * @return
     */
    public static String replaceNullWithEmptyString(String valueAsString) {
        return valueAsString != null ? " " + valueAsString : "";
    }
}
