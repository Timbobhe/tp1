package fr.ag2rlamondiale.rbb.domain.even;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class TriggeringResults implements Iterable<TriggeringResult> {
    private List<TriggeringResult> list = new ArrayList<>();

    public void add(TriggeringResult result) {
        list.add(result);
    }

    public void add(AbstractEvenGenerator generator, String idGdi, String numPersonne,
                    TypeEvenementJson typeEvenement, ContratHeader contrat) {
        TriggeringResult result = TriggeringResult.builder()
                .generator(generator)
                .typeEvenement(typeEvenement)
                .idGdi(idGdi)
                .numPersonne(numPersonne)
                .contrat(contrat)
                .build();
        add(result);
    }

    public void add(AbstractEvenWithoutContratGenerator generator, String idGdi, String numPersonne,
            TypeEvenementJson typeEvenement) {
        this.add(generator, idGdi, numPersonne, typeEvenement, null);
    }

    public void forEachGenerator(Consumer<AbstractEvenGenerator> consumer) {
        final Set<AbstractEvenGenerator> visited = new HashSet<>();
        for (TriggeringResult result : list) {
            final AbstractEvenGenerator generator = result.getGenerator();
            if (!visited.contains(generator)) {
                visited.add(generator);
                consumer.accept(generator);
            }
        }
    }

    public Stream<TriggeringResult> stream() {
        return list.stream();
    }

    public boolean isEmpty() {
        return this.list.isEmpty();
    }

    @Override
    public Iterator<TriggeringResult> iterator() {
        return this.list.iterator();
    }
}
