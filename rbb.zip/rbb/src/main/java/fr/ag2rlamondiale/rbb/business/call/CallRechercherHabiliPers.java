package fr.ag2rlamondiale.rbb.business.call;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ag2r.common.exceptions.CommonException;

import fr.ag2rlamondiale.epinlib.domain.resp.ListeHabilitationPersonneDto;
import fr.ag2rlamondiale.epinlib.domain.sub.rest.HabilitationPartDto;
import fr.ag2rlamondiale.epinlib.service.IRechercherHabiliPers1;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CallRechercherHabiliPers {
	@Autowired IRechercherHabiliPers1 rechercherHabiliPers1Service;

	public String callRechercherHabiliPersService(String idGdi) throws EligibiliteException {

		ListeHabilitationPersonneDto habils = null;
		String result = null;
		try {
			habils = rechercherHabiliPers1Service.call(idGdi);
		} catch (CommonException e) {
			throw new EligibiliteException("Erreur sur l'appel CallRechercherHabiliPers",e.getLocalizedMessage());
		}
		if(habils != null) {
			try {
				for(HabilitationPartDto hab : habils.getHabilitationPart()) {
					if (Constantes.CODE_APPLI_EGESPER_MDPRO.equals(hab.getId().getCodeAppli())) {
						result = hab.getId().getIdSilo();
					}
				}
			} catch (Exception ex) {
				log.error("User not found{}",idGdi);
				throw new EligibiliteException(Constantes.UTILISATEUR_NON_TROUVE,idGdi);
			}
		}
		return result;

	}
}
