package fr.ag2rlamondiale.rbb.api.error;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * Erreur retournée par un service REST
 *
 * <br>Historique:
 * <br>
 *
 * @author CORNE
 */
@Data
public class RestError {
	/**
	 * Niveau de l'erreur (métier ou technique)
	 */
	@JsonProperty(value = "errorLevel")
	String level;

	
	
	/**
	 * Code de l'erreur (fixé dans l'application ou récupéré à partir de l'exception remontée du serveur)
	 */
	@JsonProperty(value = "errorCode")
	String code;

	/**
	 * Messages supplémentaires précisant l'erreur (optionnel)
	 */
	@JsonProperty(value = "additionnalMessages")
	List<String> additionnalMessages;

	/** Constructeur.
	 * @param level niveau de l'erreur
	 * @param code code de l'erreur
	 */
	public RestError(String level, String code) {
		this.level = level;
		this.code = code;
		this.additionnalMessages = new ArrayList<>();
	}

	/** Constructeur.
	 * @param level niveau de l'erreur
	 * @param code code de l'erreur
	 */
	public RestError(String level, String code, List<String> additionnalMessages) {
		this.level = level;
		this.code = code;
		this.additionnalMessages = additionnalMessages;
	}

	public void addMessage(String additionnalMessage) {
		this.additionnalMessages.add(additionnalMessage);
	}

	public void addMessages(List<String> additionnalMessages) {
		this.additionnalMessages.addAll(additionnalMessages);
	}
}
