package fr.ag2rlamondiale.rbb.mapping;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.dto.ClientDto;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;

import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring")
public class UtilisateurMapper {
    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    public ClientDto mapperPersonnePhysiqueToClientDto(ClientDto c, UserContext userContext) throws TechnicalException, EligibiliteException {
        PersonnePhysiqueConsult pp = consulterPersPhysFacade
                .consulterPersPhys(userContext.getIdSilo());
        c.setCivilite(pp.getCivilite() != null ? pp.getCivilite() : pp.getCodeCivilite());
        c.setDateDeNaissance(pp.getDateDeNaissance());
        return c;
    }
}
