package fr.ag2rlamondiale.rbb.dto.tracking;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class TrackingInfoDto {
    @JsonProperty("client_genre")
    private String clientGenre;

    @JsonProperty("client_age")
    private String clientAge;

    @JsonProperty("client_postcode")
    private String clientPostcode;

    @JsonProperty("client_situation")
    private String clientSituationFamiliale = "inconnu";

    @JsonProperty("equipement_retraite_supp_details")
    private List<EquipementRetraiteSuppDto> equipementsRetraiteSupp;

    private String impersonnation;

    private String partenaire;

    public void setImpersonnation(boolean impersonnation) {
        this.impersonnation = impersonnation ? "oui" : "non";
    }
}
