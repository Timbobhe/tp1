package fr.ag2rlamondiale.rbb.domain.even;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

public abstract class AbstractEvenGenerator {
    @Autowired
    protected UserContextHolder userContextHolder;

    /**
     * Genere un EVEN depuis le résultat de déclenchabilité
     *
     * @param result
     * @return EVEN à présenter à l'utilisateur ou NULL sinon
     */
    public abstract EvenementJson generateNextEven(TriggeringResult result);

    protected boolean isEre() {
        return userContextHolder.get().estDansSilo(CodeSiloType.ERE);
    }

    protected boolean isMdpro() {
        return userContextHolder.get().estDansSilo(CodeSiloType.MDP);
    }

    /**
     * Vérification que l'EVEN est déclenchable pour l'utilisateur indépendamment des conditions métiers, cad :<br>
     * <ul>
     *     <li>L'EVEN est autorisé pour la PP ou le CONTRAT</li>
     *     <li>L'EVEN n'a pas encore été traité</li>
     *     <li>L'EVEN faculatif n'a pas été presenté aujourd'hui à l'utilisateur</li>
     *     <li>L'EVEN ne dépasse pas le nombre de déclenchement MAX</li>
     *     <li>L'EVEN respecte le délai de réactivation</li>
     *     <li>...</li>
     * </ul>
     *  @param idGdi
     *
     * @param numPersonne
     * @param typeEven
     * @param contrats
     * @param historiqueEvens
     * @param results
     */
    public abstract void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                           Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results);

    /**
     * Méthode à surcharger pour nettoyer le cache avant évalution des evenements
     */
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {
    }
}
