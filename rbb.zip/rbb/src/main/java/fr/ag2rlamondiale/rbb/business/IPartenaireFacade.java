/*
 * Cree le 17 mai 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;

import java.util.List;

public interface IPartenaireFacade {
    PartenaireJson findById(String id);

    PartenaireJson findSousPartenaire(String primaryPartner, List<String> userContracts);

    Integer updateIdgdiTemporaire(String codePartenaire, String numPersEre, String numPersMdp, String realIdGdi);

    PartenaireJson findPartenaire(String primaryPartner, String secondaryPartner, String numPP) throws TechnicalException;
}
