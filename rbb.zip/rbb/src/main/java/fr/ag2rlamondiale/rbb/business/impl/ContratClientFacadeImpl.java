package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.rbb.business.IVerifierEligibiliteFacade;
import fr.ag2rlamondiale.rbb.business.call.CallNaviguerClientsContrats;
import fr.ag2rlamondiale.rbb.business.call.CallRechPersPhysClient;
import fr.ag2rlamondiale.rbb.business.call.CallRechercherHabiliPers;
import fr.ag2rlamondiale.rbb.business.mapping.ContratPacteMapperERE;
import fr.ag2rlamondiale.rbb.business.mapping.ContratPacteMapperMDP;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.utils.ErrorConstantes;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Lambda;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.SOAP_CACHE;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.WITH_XCALLER_KEY_GENERATOR;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;

@Slf4j
@Service
public class ContratClientFacadeImpl {
    @Autowired
    private IContratsClient contratClient;

    @Autowired
    private ContratPacteMapperERE contratPacteMapperERE;

    @Autowired
    private ContratPacteMapperMDP contratPacteMapperMDP;
    
    @Autowired
    private IVerifierEligibiliteFacade verifierEligibiliteFacadeImpl;

    @Autowired
	CallNaviguerClientsContrats callNaviguerClientsContrats;

	@Autowired
	private UserContextHolder userContextHolder;

	@Autowired
	CallRechercherHabiliPers callRechercherHabiliPers;

	@Autowired
	CallRechPersPhysClient callRechPersPhysClient8;
	
    public String getClientIdGdi() {
		UserContext userContext = userContextHolder.get();
		Objects.requireNonNull(userContext);
		return userContext.getIdGdi();
	}

	public PersonnePhysiqueDto getPersonnePhysiqueDto(String idGdi) throws EligibiliteException {

		String idPersonne = callRechercherHabiliPers.callRechercherHabiliPersService(idGdi);

		ListePersPhysDto retour;

		try {
			retour = callRechPersPhysClient8.callRechPersPhysClient8Service(idPersonne);

		} catch (TechnicalException e) {
			log.error(ErrorConstantes.ERROR_RECHPERSPHYS, e);
			throw new EligibiliteException(ErrorConstantes.ERREUR_TECHNIQUE, e.getLocalizedMessage());

		}

		if (retour.getListePP().isEmpty()) {
			throw new EligibiliteException(ErrorConstantes.ELIGIBILITE_PERSONNE_CODE_KO,
					ErrorConstantes.ELIGIBILITE_PERSONNE_PHYSIQUE_INTROUVABLE);
		}

		// RG Métier
		return retour.getListePP().stream().findFirst().orElse(new PersonnePhysiqueDto());

	}
    
	public List<ContratHeaderDto> mappingContratsDtoToContratsHeaderDto(List<ContratDto> contratsDto) {

		List<ContratHeaderDto> contratsHeaderDto = new ArrayList<ContratHeaderDto>();

		for (ContratDto contratDto : contratsDto) {

			ContratHeaderDto contratHeaderDto = new ContratHeaderDto();

			contratHeaderDto.setId(contratDto.getIdentSiloContrat().getId());
			contratHeaderDto.setDateEffet(contratDto.getDateEffet());
			contratHeaderDto.setDateFinEffet(contratDto.getDateFinEffet());
			contratHeaderDto.setDateSitCtr(contratDto.getDateSitContrat());

			// ofrCialLg est un champ qui peut etre null dans REPERE
			if (contratDto.getOfrCialLg() != null && contratDto.getOfrCialLg().getValue() != null) {
				if (contratDto.getOfrCialLg().getValue().length()<7) {
					contratHeaderDto.setTypeContrat(contratDto.getOfrCialLg().getValue());
					contratHeaderDto.setNumGenContrat(null);
				}
				else {
					contratHeaderDto.setTypeContrat(contratDto.getOfrCialLg().getValue().substring(0, 4));
					contratHeaderDto.setNumGenContrat(contratDto.getOfrCialLg().getValue().substring(4, 7));
				}
				contratHeaderDto.setLibelleProduit(contratDto.getOfrCialLg().getLabel());
			}
			contratHeaderDto.setDescriptionFront(contratHeaderDto.getTypeContrat() + contratHeaderDto.getNumGenContrat());
			contratHeaderDto.setCodeSilo(CodeSiloType.MDP);
			contratHeaderDto.setClasseAutreContrat(false);
			contratHeaderDto.setCodeFiliale(null);
			contratHeaderDto.setCodeMentionLegale(null);
			contratHeaderDto.setCodeProduit(null);
			contratHeaderDto.setCodeSitAffil(null);
			contratHeaderDto.setCollege(null);
			contratHeaderDto.setContractanteRepresent(false);
			contratHeaderDto.setDateEffetSituationAffiliation(null);
			contratHeaderDto.setDateSitAffil(null);
			contratHeaderDto.setDateSitCtr(contratDto.getDateSitContrat());
			contratHeaderDto.setDateFinEffet(contratDto.getDateFinEffet());
			contratHeaderDto.setDeductible(false);
			contratHeaderDto.setEtatAffiliationLabel(null);
			contratHeaderDto.setEtatContrat(null);
			contratHeaderDto.setEtatContratLabel(null);
			contratHeaderDto.setHasVersementProgrammes(false);
			contratHeaderDto.setIdAdherente(null);
			contratHeaderDto.setIdCollege(null);
			contratHeaderDto.setIdContractante(null);
			contratHeaderDto.setIdContratReference(null);
			contratHeaderDto.setIdentifiantAssure(null);
			contratHeaderDto.setLibelleProduit(null);
			contratHeaderDto.setLibSitAffil(null);
			contratHeaderDto.setPersonId(userContextHolder.get().getNumeroPersonneMdpro());
			contratHeaderDto.setRaisonSocialeAdherente(null);
			contratHeaderDto.setRaisonSocialeContractante(null);
			contratHeaderDto.setRaisonSocialeFront(null);
			contratHeaderDto.setCodeProduit(contratHeaderDto.getTypeContrat() + "-"
					+ contratHeaderDto.getNumGenContrat() + "-" + contratHeaderDto.getCodeFiliale());
			contratsHeaderDto.add(contratHeaderDto);
		}

		return contratsHeaderDto;

	}

	public List<ContratHeaderDto> getListContratsByUserHolder() throws TechnicalException {
		PersonnePhysiqueDto personnePhysiqueDto = null;
    	String idGdi = getClientIdGdi();
		try {
			personnePhysiqueDto = getPersonnePhysiqueDto(idGdi);
		} catch (EligibiliteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		ClientDto clientDto = callNaviguerClientsContrats.callNaviguerClientsContrats4(idGdi, personnePhysiqueDto);
		List<ContratHeaderDto> allContrats = new ArrayList<>();

		if (clientDto != null && clientDto.getListeContrat() != null) {
			allContrats = mappingContratsDtoToContratsHeaderDto(clientDto.getListeContrat());
		}
		
		List<ContratHeaderDto> contrats = new ArrayList<>();

		try {
			contrats = verifierEligibiliteFacadeImpl.verifierEligibiliteVersionAutorise(allContrats);
		} catch (EligibiliteException e) {
			log.error("Erreur verifierEligibiliteVersionAutorise {}", e);
		}
		return contrats;
	}
	
	@LogExecutionTime
    @Cacheable(cacheNames = SOAP_CACHE, keyGenerator = WITH_XCALLER_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsPersonne(RechercherContratsDto critere) throws TechnicalException {
		List<ContratHeaderDto> contrats = getListContratsByUserHolder();
        prefetchInfosContrat(contrats);
        return convertToPacte(contrats);
    }

    @LogExecutionTime
    @Cacheable(cacheNames = SOAP_CACHE, keyGenerator = WITH_XCALLER_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException {
    	List<ContratHeaderDto> contrats = getListContratsByUserHolder();
        prefetchInfosContrat(contrats);
        return convertToPacte(contrats);
    }

    @LogExecutionTime
    @Cacheable(cacheNames = SOAP_CACHE, keyGenerator = WITH_XCALLER_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsRetraiteSuppEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException {
    	List<ContratHeaderDto> contrats = getListContratsByUserHolder();
    	prefetchInfosContrat(contrats);
        return convertToPacte(contrats);
    }

    @Nonnull
    private List<ContratHeader> convertToPacte(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        final List<ContratHeader> liste = new ArrayList<>();

        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final ContratId contratId = entry.getKey();
            final List<ContratHeaderDto> contrats = entry.getValue();

            final InfosContratDto infosContratDto = retrieveInfosContrat(contratId, contrats);
            if (contratId.is(MDP)) {
                liste.addAll(contratPacteMapperMDP.convertToPacte(distinctMDP(contrats), infosContratDto));
            } else if (contratId.is(ERE)) {
                List<ContratHeader> collect = contratPacteMapperERE.convertToPacte(contrats, infosContratDto).stream()
                        .filter(contratHeader1 -> !AffichageType.MASQUE.equals(contratHeader1.getAffichageType()))
                        .collect(Collectors.toList());
                liste.addAll(collect);
            }
        }
        return liste;
    }

    @Nonnull
    private List<ContratHeaderDto> distinctMDP(List<ContratHeaderDto> contrats) {
        if (contrats.size() == 1) {
            return contrats;
        }

        final List<ContratHeaderDto> res = contrats.stream().distinct().collect(Collectors.toList());
        if (contrats.size() > res.size()) {
            log.warn("BACK 8X retourne des contrats MDP en doublon {}", contrats);
        }
        return res;
    }

    private InfosContratDto retrieveInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        InfosContratDto infosContratDto = new InfosContratDto();
        final ContratGeneral contratGeneral = this.contratClient
                .consulterContratGenerales(new ConsulterContratGeneralesDto(contratId));
        infosContratDto.setContratGeneral(contratGeneral);

        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() -> {
                    final CompteGeneralesERE cge = this.contratClient
                            .consulterCompteGeneralesERE(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()));
                    infosContratDto.add(cge);
                }));
            }
        }

        return infosContratDto;
    }

    private void prefetchInfosContrat(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final ContratId contratId = entry.getKey();
            final List<ContratHeaderDto> contratHeaderDtos = entry.getValue();
            prefetchInfosContrat(contratId, contratHeaderDtos);
        }
    }

    private void prefetchInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        this.contratClient.consulterContratGeneralesAsync(new ConsulterContratGeneralesDto(contratId));
        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() -> {
                    this.contratClient.consulterCompteGeneralesEREAsync(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()));
                }
                ));
            }
        }
    }
}
