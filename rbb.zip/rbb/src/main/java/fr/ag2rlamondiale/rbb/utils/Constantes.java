package fr.ag2rlamondiale.rbb.utils;

public class Constantes {

	public static final String CODE_APP_8X = "A0443";
	public static final String CODE_SYS_INFO_EGESPER_MDPRO = "MDP";
	public static final String CODE_APPLI_EGESPER_MDPRO = "A0406";
	public static final String UTILISATEUR_NON_TROUVE = "user-not-found";
	public static final String CODE_APP_REPERE = "A0570";
	public static final String PREFIX_CM = "52";
	public static final String PRINCIPAL = "PRINCIPAL";
	public static final String SECONDAIRE = "SECONDAIRE";
	public static final String CODE_PERSONNE_PHYSIQUE = "P";
	/** Contient la liste des statuts autorisés En cours ou En cours ss primes */
	public enum stat_aut {
		EC, ECSSPRM
	}
	
	/** Contient la liste des contrats retraite non autorisés*/
	public enum contrat_retraite_exclu {
		RA09V22, RA09V02, RA09V32 , RA09V01, RA09V21, RA09V31, RA09V41, RA09V42
	}
	
	private Constantes() {}

}
