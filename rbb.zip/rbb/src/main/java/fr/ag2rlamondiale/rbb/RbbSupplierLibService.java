package fr.ag2rlamondiale.rbb;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@Service
public class RbbSupplierLibService implements ISupplierLibService {
    @Value("${rbb.front.url}")
    private String rbbFrontUrl;
    
    @Value("${rbb.codeAppliEmettrice.universign}")
    private String codeApplicationEmettriceForUniversign;

    @Value("${rbb.codeAppli}")
    private String codeApplication;
    
    @Override
    public String getCodeCassiniAppli() {
        return codeApplication;
    }

    @Override
    public String getLibelleAppli() {
        return "ESPACE MDPRO RIB";
    }

    @Override
    public String getUrlFront() {
        return rbbFrontUrl;
    }
   
	@Override
	public String getCodeApplicationEmettriceForUniversign() {
		return codeApplicationEmettriceForUniversign;
	}
}
