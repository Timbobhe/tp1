package fr.ag2rlamondiale.rbb.domain.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.exception.CodeSiloTypeNonGereException;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.trm.utils.Sets;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratEnum;
import lombok.*;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;

@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ContratHeader implements IContrat, Comparable<ContratHeader> {
    @EqualsAndHashCode.Include
    private CodeSiloType codeSilo;
    private String college;
    @EqualsAndHashCode.Include
    private String id;

    private String personId;

    @EqualsAndHashCode.Include
    private String idAdherente;

    private String raisonSocialeAdherente;

    @EqualsAndHashCode.Include
    private String idContractante;

    private String raisonSocialeContractante;
    private String raisonSocialeFront;

    /**
     * Construit depuis :
     * <ul>
     *     <li>ERE : {@link ContratGeneral#getProduit()}</li>
     *     <li>MDP : {@link ContratHeader#getLibelleProduit()}</li>
     * </ul>
     */
    private String descriptionFront;

    private String idCollege;
    private String identifiantAssure;
    private AffichageType affichageType;
    private boolean deductible;
    private boolean classeAutreContrat;

    private boolean contractanteRepresent;
    private boolean hasVersementProgrammes;
    private Date dateAffiliation;

    private String codeAssureur;
    private String codeProduit;
    private String libelleProduit;
    private String codeMentionLegale;
    private String typeContrat;
    private String numGenContrat;
    private String codeFiliale;
    private String etatContratLabel;
    private String etatAffiliationLabel;
    private Date dateEffet;
    private Date dateFinEffet;
    private String codeSitAffil;
    private String libSitAffil;
    private Date dateSitAffil;
    private String descClauseBenef;

    // Fiscalité
    private String codeCadreFiscal;
    private String libCadreFiscal;

    // ContratResume
    private SituationContratEnum etatContrat;
    private Date dateSitCtr;
    private Date dateEffetSituationAffiliation;

    private Set<PartType> partsType;

    private boolean pacte;
    private List<Compartiment> compartiments = new ArrayList<>();

    /**
     * contrats MDPRO 8X ont été migré sur PTV (Sur contrat général : TYPCONNUMGEN = RG02 002)
     */
    private boolean petitCollectifPTV;

    /**
     * Identifiant technique NIE
     */
    private String idContratReference;
    private MetierContratType metierContratType;
    private String statut;
    
    @Override
    public int compareTo(ContratHeader o) {
        if (o == null) {
            return -1;
        }
        return id.compareTo(o.getId());
    }

    public String getCodeFiliale() {
        if (is(MDP)) {
            return "LMX";
        }
        return codeFiliale;
    }

    public boolean isFilialeACA() {
        return ContratConstants.FILIALES_ACA.contains(this.getCodeFiliale());
    }
    
    @Override
    public boolean is(CodeSiloType codeSilo) {
        return this.codeSilo.equals(codeSilo);
    }

    @Override
    public boolean isEre() {
        return this.is(ERE);
    }

    @Override
    public boolean isMdpro() {
        return this.is(MDP);
    }

    public boolean hasCompartiments() {
        return !getCompartiments().isEmpty();
    }

    public List<Compartiment> getCompartiments() {
        if (compartiments == null) {
            compartiments = new ArrayList<>();
        }
        return compartiments;
    }

    public Compartiment addCompartiment(Compartiment compartiment) {
        compartiment.setContratHeader(this);
        this.getCompartiments().add(compartiment);
        return compartiment;
    }

    public ContratId getContratId() {
        if (this.isEre()) {
            return ContratId.ere(this.id, this.idAdherente, this.idContractante);
        } else if (isMdpro()) {
            return ContratId.mdpro(this.id);
        }
        throw new CodeSiloTypeNonGereException(this.codeSilo);
    }

    public Set<String> getIdentifiantsAssures() {
        if (is(MDP)) {
            return Collections.emptySet();
        }

        if (isPacte()) {
            return this.getCompartiments().stream().map(Compartiment::getIdentifiantAssure)
                    .filter(Objects::nonNull).collect(Collectors.toSet());
        }

        return Sets.set(this.identifiantAssure);
    }

    public boolean concerneAssure(String idAssure) {
        return getIdentifiantsAssures().contains(idAssure);
    }

    @Override
    public List<Compartiment> compartiments(CompartimentType type) {
        return this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).collect(Collectors.toList());
    }

    public List<Compartiment> compartiments(List<CompartimentType> types) {
        List<Compartiment> compartimentsList = new ArrayList<>();
        for(CompartimentType type : types){
        	compartimentsList.addAll(this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).collect(Collectors.toList()));
        }
        return compartimentsList;
    }

    public Compartiment compartiment(CompartimentId compartimentId) {
        return this.getCompartiments().stream().filter(compartiment -> compartiment.is(compartimentId)).findFirst().orElse(null);
    }

    public Compartiment compartimentEre(String idAssure) {
        return this.getCompartiments().stream().filter(compartiment -> idAssure.equals(compartiment.getIdentifiantAssure())).findFirst().orElse(null);
    }

    public void compartiment(CompartimentType type, Consumer<Compartiment> consumer) {
        this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).forEach(consumer);
    }

    @Override
    public MetierContratType getMetierContrat() {
        return MetierContratType.RETRAITE_SUPPLEMENTAIRE;
    }

    @Override
    public String getIdentifiantAssureParDefaut() {
        return this.identifiantAssure;
    }

    public boolean hasCompartiments(CompartimentType type) {
        return this.getCompartiments().stream().anyMatch(compartiment -> compartiment.is(type));
    }
}
