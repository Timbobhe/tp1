package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IClientFacade;
import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.rbb.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.dto.personne.GetCoordonneesClientDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/secure")
public class PersonneRestController {
    public static final String TITRE_SOUS_SUJET_VDPP = "VALIDATION_DONNEES_PERSONNELLES";
    public static final String TITRE_SOUS_SUJET_CONF = "CONFIRMATION_DONNEES_PERSONNELLES";
    @Autowired
    private IClientFacade clientFacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @ProfileExecution(codeAction = CodeActionType.API_COORDONNEES_CLIENT_UPDATE)
    @LogExecutionTime
    @PutMapping(path = "/coordonnees-client")
    public ModifierPPSiloResponseDto modifierCoordonneesClient(@RequestBody CoordonneesClientDto coordonneesClientDto) throws TechnicalException {
        return clientFacade.modifierCoordonneesClient(coordonneesClientDto);
    }

    @ProfileExecution(codeAction = CodeActionType.API_COORDONNEES_CLIENT_GET)
    @LogExecutionTime
    @PostMapping(path = "/coordonnees-client")
    public CoordonneesClientDto getCoordonneesClient(@RequestBody GetCoordonneesClientDto param) throws CommonException {
        // On force l'éviction du cache pour la récupération des coordonnees du client depuis le Front
        // faute de mieux (visiblement la stratégie qui consiste à appeler clear-cache n'a pas suffit
        // peut-être à cause d'un changement de Container, ... au moins c'est sûr là
        if (!param.isKeepMdproData()) {
            consulterPersPhysFacade.forceCacheEvictConsulterPersPhys();
        }
        return consulterPersPhysFacade.getCoordonneesClient(param);
    }

}
