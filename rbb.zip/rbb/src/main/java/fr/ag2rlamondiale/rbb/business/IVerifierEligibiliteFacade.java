package fr.ag2rlamondiale.rbb.business;

import java.util.List;

import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;

public interface IVerifierEligibiliteFacade {

	public List<ContratHeaderDto> verifierEligibiliteVersionAutorise(List<ContratHeaderDto> listeContrat) throws EligibiliteException;	
}
