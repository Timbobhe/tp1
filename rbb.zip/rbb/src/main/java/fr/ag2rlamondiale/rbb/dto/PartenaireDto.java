package fr.ag2rlamondiale.rbb.dto;

import lombok.Data;

import java.util.List;

@Data
public class PartenaireDto {
    private String codePartenaire;
    private String codePartenairePrincipal;
    private String label;
    private String urlHeader;
    private String urlFooter;
    private String urlError;
    private String urlMenu;
    private String nomCss;
    private List<String> idContrats;
    private String baseUrl;
}
