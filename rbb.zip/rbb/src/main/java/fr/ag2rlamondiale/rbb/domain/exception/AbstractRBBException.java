package fr.ag2rlamondiale.rbb.domain.exception;

import java.io.IOException;
import java.net.HttpURLConnection;

import lombok.Data;
import lombok.EqualsAndHashCode;


@Data
@EqualsAndHashCode(callSuper=false)
public abstract class AbstractRBBException extends IOException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1153767113284082357L;

	protected final String code;
	protected final String message;

	public AbstractRBBException() {
		this.code = Integer.toString(HttpURLConnection.HTTP_INTERNAL_ERROR);
		this.message = "Erreur non documentée";
	}

	public AbstractRBBException(String code, String message) {
		this.code = code;
		this.message = message;
	}

}
