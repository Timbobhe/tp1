package fr.ag2rlamondiale.rbb.utils;

public class ErrorConstantes {

	public static final String	ELIGIBILITE_CONTRAT_CODE_KO		= "eligibilite-contrat-ko";
	public static final String	ELIGIBILITE_CONTRAT_MESSAGE_KO	= "Aucun contrat éligible trouvé";
	public static final String	ERREUR_TECHNIQUE				= "technical-error";
	public static final String ERROR_RECHPERSPHYS = "ERROR sur call rechPersPhysClient8Service {}";
	public static final String	ELIGIBILITE_PERSONNE_CODE_KO	= "eligibilite-personne-ko";
	public static final String	ELIGIBILITE_PERSONNE_PHYSIQUE_INTROUVABLE	= "Aucune personne physique n'a été trouvée ";
	public static final String ELIGIBILITE_PERSONNE_KO = "eligibilite-personne-ko";
	public static final String ELIGIBILITE_PERSONNE_MESSAGE_KO = "Personne pas éligible";
	
	private ErrorConstantes() {}

}
