package fr.ag2rlamondiale.rbb.mapping;

import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.dto.contrat.CompartimentDto;
import fr.ag2rlamondiale.rbb.dto.contrat.ContratClientDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring")
public interface ContratClientMapper {
    @Mapping(source = "compartiments", target = "compartiments", qualifiedByName = "mapListCompartiment")
    ContratClientDto map(ContratHeader contratHeader);

    CompartimentDto map(Compartiment compartiment);

    @Named("mapListCompartiment")
    default List<CompartimentDto> map(List<Compartiment> value) {
        if (value == null) {
            return new ArrayList<>();
        }
        return value.stream().map(this::map).collect(Collectors.toList());
    }
}
