package fr.ag2rlamondiale.rbb.business.impl;

import fr.ag2rlamondiale.rbb.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RechercherHabiliFacadeImpl implements IRechercherHabiliFacade {
    @Autowired
    private IRechercherHabiliPersClient rechercherHabiliPersClient;

    @Override
    public PersonnePhysique rechercherParIdGdi(String idGdi) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setIdGdi(idGdi);
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }

    @Override
    public PersonnePhysique rechercherParNumPers(String numPp, CodeSiloType silo) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setCodeSilo(silo);
        in.setNumeroPersonne(numPp);
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }
}
