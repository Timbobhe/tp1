package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.rbb.dto.contrat.ContratClientDto;
import fr.ag2rlamondiale.rbb.mapping.ContratClientMapper;
import fr.ag2rlamondiale.rbb.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation Spring du service REST pour la recherche de contrats assures
 */
@RestController
@RequestMapping(path = "/secure")
public class ContratsRestController {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ContratClientMapper contratClientMapper;

    /**
     * Méthode pour récupérer la liste des contrats assures
     *
     * @return
     * @throws TechnicalException
     */
    @ProfileExecution(codeAction = CodeActionType.API_CONTRATS_ASSURES)
    @LogExecutionTime
    @GetMapping(path = "/contrats_assures")
    public List<ContratClientDto> getContrats() throws TechnicalException {
        final List<ContratHeader> contratHeaders = contratFacade.rechercherContrats();
        return contratHeaders.stream().map(contratHeader -> contratClientMapper.map(contratHeader)).collect(Collectors.toList());
    }
}
