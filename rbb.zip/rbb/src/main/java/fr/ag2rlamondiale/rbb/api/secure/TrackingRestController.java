package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.ITrackingFacade;
import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.rbb.dto.tracking.TrackingInfoDto;
import fr.ag2rlamondiale.rbb.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/secure")
public class TrackingRestController {
    @Autowired
    private ITrackingFacade trackingFacade;

    @ProfileExecution(codeAction = CodeActionType.API_TRACKINGINFO_GET)
    @LogExecutionTime
    @GetMapping(path = "/tracking/info")
    public TrackingInfoDto getTrackingInfo() throws TechnicalException {
        return trackingFacade.getTrackingInfo();
    }
}
