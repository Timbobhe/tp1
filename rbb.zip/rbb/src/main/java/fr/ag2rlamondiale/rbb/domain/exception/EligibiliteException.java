package fr.ag2rlamondiale.rbb.domain.exception;



public class EligibiliteException extends AbstractRBBException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3292131731320566591L;

	public EligibiliteException() {
		super();
	}

	public EligibiliteException(String code, String message) {
		super(code, message);
	}

}
