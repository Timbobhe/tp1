package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IBaseContratFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;

import java.util.Comparator;
import java.util.List;

import static java.util.Comparator.*;


public interface IContratFacade extends IBaseContratFacade<ContratHeader> {
    List<ContratHeader> rechercherContratsMdpro() throws TechnicalException;

    List<ContratComplet> rechercherContratsComplets() throws TechnicalException;

    List<ContratHeader> rechercherContratsEre() throws TechnicalException;

    List<ContratHeader> rechercherContratsEpargnePrevoyance() throws TechnicalException;

    List<ContratHeader> rechercherContrats() throws TechnicalException;

    List<ContratHeader> rechercherContrats(CodeSiloType codeSilo) throws TechnicalException;

    ContratHeader rechercherContratParId(ContratId contratId) throws TechnicalException;

    /**
     * Du plus ancien au plus récent, (sans date en 1er). Le + récent est le dernier de la liste
     *
     * @return
     */
    default Comparator<Compartiment> comparatorDateEffetSituationAffiliation() {
        return nullsFirst(comparing(Compartiment::getDateEffetSituationAffiliation, nullsFirst(naturalOrder())));
    }
}
