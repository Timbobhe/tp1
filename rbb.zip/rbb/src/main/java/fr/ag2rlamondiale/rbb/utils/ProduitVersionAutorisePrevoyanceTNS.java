package fr.ag2rlamondiale.rbb.utils;

import java.util.Arrays;

public enum ProduitVersionAutorisePrevoyanceTNS  {

	AN07V12("AN07","V12"), AN07V13("AN07","V13"), AN08V03("AN08","V03"), AN09V09("AN09","V09"), AN09V10("AN09","V10"),
	AN09V11("AN09","V11"), AN09V12("AN09","V12"), AN10V03("AN10","V03"), TT02V02("TT02","V02"), TT03V02("TT03","V02"),
	TT04V02("TT04","V02"), AN07V07("AN07","V07"), AN07V08("AN07","V08"), AN07V09("AN07","V09"), AN07V10("AN07","V10"),
	AN07V11("AN07","V11"), AN09V05("AN09","V05"), AN09V06("AN09","V06"), AN09V07("AN09","V07"), AN09V08("AN09","V08"),
	TT01V01("TT01","V01"), TT01V02("TT01","V02"), TT02V01("TT02","V01"), TT03V01("TT03","V01"), TT04V01("TT04","V01"),
	AN12V01("AN12","V01"), AN02V02("AN02","V02"), AN03V02("AN03","V02"), AN07V02("AN07","V02"), AN07V03("AN07","V03"),
	AN07V04("AN07","V04"), AN07V05("AN07","V05"), AN07V06("AN07","V06"), AN08V02("AN08","V02"), AN09V02("AN09","V02"),
	AN09V03("AN09","V03"), AN09V04("AN09","V04"), AN10V02("AN10","V02"), AN11V01("AN11","V01");

	final String produit;
	final String version;
	
	private ProduitVersionAutorisePrevoyanceTNS (String produit, String version) {
		this.produit = produit;
		this.version = version;
	}
	
	public static boolean contains(String produit, String version) {
		return Arrays.stream(values()).anyMatch(v -> v.produit.equals(produit) && v.version.equals(version));
	}
	
}
