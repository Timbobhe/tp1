package fr.ag2rlamondiale.rbb.utils;

import java.util.Arrays;

/** Contient la liste des Couples Version/Produit autorisés */
public enum ProduitVersionAutoriseEpargne {
	
	RC01V01("RC01","V01"), RC03V01("RC03","V01"), RC03V02("RC03","V02"), RC03V03("RC03","V03"), RC08V09("RC08","V09"),
	RC08V01("RC08","V01"), RC08V21("RC08","V21"), RC08V41("RC08","V41"), RC08V02("RC08","V02"), RC08V22("RC08","V22"), 
	RC08V07("RC08","V07"), RC08V27("RC08","V27"), RC08V47("RC08","V47"), RC08V08("RC08","V08"), RC08V28("RC08","V28");
	
	final String produit;
	final String version;
	
	private ProduitVersionAutoriseEpargne(String produit, String version) {
		this.produit = produit;
		this.version = version;
	}
	
	public static boolean contains(String produit, String version) {
		return Arrays.stream(values()).anyMatch(v -> v.produit.equals(produit) && v.version.equals(version));
	}
}