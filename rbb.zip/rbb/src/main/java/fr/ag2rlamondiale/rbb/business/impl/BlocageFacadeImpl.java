package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IBlocageFacade;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.rbb.domain.exception.PartenaireException;
import fr.ag2rlamondiale.rbb.business.mapping.ContratHeaderMapper;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.rest.IBlocageRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.*;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.RUNTIME_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

@Service
public class BlocageFacadeImpl implements IBlocageFacade, SelfReferencingBean {
    private static final String CACHE_INFOS_BLOCAGES_CLIENT = "CACHE_INFOS_BLOCAGES_CLIENT";

    @Autowired
    private ContratHeaderMapper contratHeaderMapper;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IBlocageRestClient blocageRestClient;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IPartenaireFacade partenaireFacade;

    private BlocageFacadeImpl springProxy;

    @Override
    public InfosBlocagesClient getInfosBlocagesClient() throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        String numPersonneEre = userContext.getNumeroPersonneEre();
        String numPersonneMdPro = userContext.getNumeroPersonneMdpro();
        return springProxy.getInfosBlocagesClient(numPersonneEre, numPersonneMdPro);
    }

    @Cacheable(cacheNames = CACHE_INFOS_BLOCAGES_CLIENT, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public InfosBlocagesClient getInfosBlocagesClient(String numPersonneEre, String numPersonneMdPro) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        InfosBlocagesClient infosBlocagesClient = new InfosBlocagesClient();
        List<ProduitContratJson> contrats = new ArrayList<>();
        Set<BlocageJson> blocagesList = new HashSet<>();

        // Recuperation des contrats et des blocages ERE et MDPRO
        recupererContratsEtBlocages(numPersonneEre, CodeSiloType.ERE, infosBlocagesClient, contrats, blocagesList);
        recupererContratsEtBlocages(numPersonneMdPro, CodeSiloType.MDP, infosBlocagesClient, contrats, blocagesList);

        Blocages blocagesEffectifs = new Blocages(blocagesList);

        // Traitement des blocages a la personne
        Fonctionnalites fonctionnalitesBloqueesAlaPersonneERE = new Fonctionnalites();
        Fonctionnalites fonctionnalitesBloqueesAlaPersonneMdpro = new Fonctionnalites();

        traiterBlocagesALaPersonne(numPersonneEre, CodeSiloType.ERE, infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneERE, blocagesEffectifs, contrats);
        traiterBlocagesALaPersonne(numPersonneMdPro, CodeSiloType.MDP, infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneMdpro, blocagesEffectifs, contrats);
        infosBlocagesClient.setPersonneTotalementBloquee(infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo()
                .values().stream().allMatch(bloquee -> bloquee));
        calculerBlocagesALaPersonneReels(infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneERE, fonctionnalitesBloqueesAlaPersonneMdpro);

        // Traitement des blocages sur les contrats
        Map<String, Fonctionnalites> fonctionnalitesBloqueesContrats = blocagesEffectifs.calculerFonctionnalitesBloqueesContrats(contrats);
        infosBlocagesClient.setFonctionnalitesBloqueesContrats(Fonctionnalites.toOldSemantic(fonctionnalitesBloqueesContrats));

        calculerBlocagesSurContratsReels(infosBlocagesClient, fonctionnalitesBloqueesContrats);
        infosBlocagesClient.setToutLesContratsTotalementsBloques(fonctionnalitesBloqueesContrats.values()
                .stream().allMatch(Fonctionnalites::isToute));

        recupereBlocagePartenaire(infosBlocagesClient, userContext);
        return infosBlocagesClient;
    }

    /**
     * Calculer Fonctionnalites Bloquees Tous Contrats
     *
     * @param infosBlocagesClient
     * @param fonctionnalitesBloqueesContrats
     */
    public void calculerBlocagesSurContratsReels(InfosBlocagesClient infosBlocagesClient,
                                                  Map<String, Fonctionnalites> fonctionnalitesBloqueesContrats) {

        final Set<String> toutesFonctionnalites = Fonctionnalites.cumulFonctionnalites(fonctionnalitesBloqueesContrats.values());
        for (String fonctionnalite : toutesFonctionnalites) {
            if (fonctionnalitesBloqueesContrats.values().stream().allMatch(fonctionnalies -> fonctionnalies.contains(fonctionnalite))) {
                infosBlocagesClient.getFonctionnalitesBloqueesTousContrats().add(fonctionnalite);
            }
        }
    }

    private void calculerBlocagesALaPersonneReels(InfosBlocagesClient infosBlocagesClient,
                                                  Fonctionnalites fonctionnalitesBloqueesAlaPersonneERE,
                                                  Fonctionnalites fonctionnalitesBloqueesAlaPersonneMdpro) {

        Fonctionnalites fonctionnalitesBloqueesAlaPersonne = new Fonctionnalites();
        fonctionnalitesBloqueesAlaPersonneERE.forEach(fonc -> {
            if (fonctionnalitesBloqueesAlaPersonneERE.contains(fonc)) {
                fonctionnalitesBloqueesAlaPersonne.add(fonc);
            }
        });

        fonctionnalitesBloqueesAlaPersonneMdpro.forEach(fonc -> {
            if (fonctionnalitesBloqueesAlaPersonneMdpro.contains(fonc)) {
                fonctionnalitesBloqueesAlaPersonne.add(fonc);
            }
        });

        infosBlocagesClient.setFonctionnalitesBloqueesALaPersonne(fonctionnalitesBloqueesAlaPersonne.getDetails());
    }

    private void traiterBlocagesALaPersonne(String numPersonne, CodeSiloType silo,
                                            InfosBlocagesClient infosBlocagesClient, Fonctionnalites fonctionnalitesBloqueesAlaPersonne,
                                            Blocages blocages, List<ProduitContratJson> contrats) {
        boolean personneTotalementBloquee = blocages.isPersonneTotalementBloquee(numPersonne, contrats, silo);
        infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo().put(silo, personneTotalementBloquee);
        fonctionnalitesBloqueesAlaPersonne.setToute(personneTotalementBloquee);
        if (!personneTotalementBloquee) {
            fonctionnalitesBloqueesAlaPersonne.addAll(blocages.calculerFonctionnalitesBloqueesAlaPersonne(numPersonne, contrats, silo));
        }
    }

    private void recupererContratsEtBlocages(String numPersonne, CodeSiloType silo,
                                             InfosBlocagesClient infosBlocagesClient, List<ProduitContratJson> contrats,
                                             Set<BlocageJson> blocagesList) throws TechnicalException {
        if (StringUtils.isNotEmpty(numPersonne)) {
            // Recuperation des contrats du silo
            List<ProduitContratJson> contratsDuSilo = contratHeaderMapper != null ?
                    		contratFacade.rechercherContrats(silo).stream().map(contratHeaderMapper::mapContrat) .collect(Collectors.toList()):
                    			Collections.emptyList();	
            contrats.addAll(contratsDuSilo);

            // Recuperation des blocages du Silo
            List<BlocageJson> blocagesDuSilo = blocageRestClient.rechercherBlocages(numPersonne,
                    CodeApplicationType.AQEA, contratsDuSilo);
            blocagesList.addAll(blocagesDuSilo);
        } else {
            infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo().put(silo, true);
        }
    }

    private void recupereBlocagePartenaire(InfosBlocagesClient infosBlocagesClient, UserContext userContext)
            throws TechnicalException {
        final String primaryPartner = userContext.getPartenaire() != null
                ? userContext.getPartenaire().getCodePartenaire()
                : null;
        if (primaryPartner == null) {
            return; // Connexion directe, sans partenaire
        }

        final String secondaryPartner = userContext.getSousPartenaire();

        final String numeroPersonneEre = userContext.getNumeroPersonneEre();
        PartenaireJson partenaire = partenaireFacade.findPartenaire(primaryPartner, secondaryPartner, numeroPersonneEre);

        if (partenaire == null) {
            throw new PartenaireException(PartenaireException.ErrorCode.UNKNOWN_PARTENAIRE);
        }

        if (partenaire.getFonctionnnalitesBloquees() != null && !partenaire.getFonctionnnalitesBloquees().isEmpty()) {
            infosBlocagesClient.setFonctionnalitesBloqueesPartenaire(
                    partenaire.getFonctionnnalitesBloquees().stream().map(FonctionnaliteJson::getCodeFct)
                            .collect(Collectors.toSet()));
        }
    }

    @Override
    public Collection<ContratHeader> getContratsNonBloques() throws TechnicalException {
        InfosBlocagesClient infosBlocagesClient = this.springProxy.getInfosBlocagesClient();
        List<ContratHeader> resultats = new ArrayList<>();

        final List<ContratHeader> contratsERE = contratFacade.rechercherContratsEre();
        final List<ContratHeader> contratsMDP = contratFacade.rechercherContratsMdpro();

        final Map<String, Set<String>> fonctionnalitesBloqueesContrats =
                infosBlocagesClient.getFonctionnalitesBloqueesContrats();

        resultats.addAll(contratsERE.stream()
                .filter(contratNonBloquePredicate(fonctionnalitesBloqueesContrats))
                .collect(Collectors.toList()));

        resultats.addAll(contratsMDP.stream()
                .filter(contratNonBloquePredicate(fonctionnalitesBloqueesContrats))
                .collect(Collectors.toList()));

        return resultats;
    }

    private Predicate<ContratHeader> contratNonBloquePredicate(
            Map<String, Set<String>> fonctionnalitesBloqueesContrats) {
        return contrat -> !fonctionnalitesBloqueesContrats.containsKey(contrat.getId());
    }

    @Override
    public void setProxy(Object proxy) {
        this.springProxy = (BlocageFacadeImpl) proxy;
    }
}
