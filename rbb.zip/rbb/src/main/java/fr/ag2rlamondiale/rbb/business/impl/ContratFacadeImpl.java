package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.Compartiment;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IBaseContratFacade;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import fr.ag2rlamondiale.trm.utils.Futures;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static com.google.common.base.Preconditions.checkNotNull;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Service
@Primary
@AppImpl(implemtationOf = IBaseContratFacade.class)
public class ContratFacadeImpl implements IContratFacade {
    @Autowired
    private IContratsClient contratClient;

    @Autowired
    private ContratClientFacadeImpl contratClientFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private AsyncTaskExecutor asyncExecutor;

    @Autowired
    private RequestContextHolder requestContext;


    @Override
    public ContratHeader rechercherContratParId(ContratId contratId) throws TechnicalException {
        checkNotNull(contratId);
        for (ContratHeader contrat : rechercherContrats()) {
            // On ne prend pas en compte les contrats desactives
            if (!contrat.getAffichageType().isDisabled() && contratId.equals(contrat.getContratId())) {
                return contrat;
            }
        }
        throw new ContratInconnuException(contratId);
    }

    public ContratHeader rechercherContratParIdAssure(String idAssure) throws TechnicalException {
        checkNotNull(idAssure);
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(ERE);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneEre());
        for (ContratHeader contrat : contratClientFacade.rechercherContratsPersonne(rechercherContratsDto)) {
            if (contrat.concerneAssure(idAssure)) {
                return contrat;
            }
        }
        return null;
    }

    @Override
    public List<ContratHeader> rechercherContrats(CodeSiloType codeSilo) throws TechnicalException {
        if (ERE.equals(codeSilo)) {
            return rechercherContratsEre();
        }
        if (MDP.equals(codeSilo)) {
            return rechercherContratsMdpro();
        }

        throw new IllegalArgumentException(codeSilo + " non g\u00e9r\u00e9");
    }

    @Override
    public List<ContratHeader> rechercherContratsMdpro() throws TechnicalException {
        if (isEmpty(userContextHolder.get().getNumeroPersonneMdpro())) {
            return new ArrayList<>();
        }
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(MDP);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneMdpro());
        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsEpargnePrevoyance(rechercherContratsDto);
        return filterContratsPartenaire(contratHeaders);
    }

    @Override
    public List<ContratHeader> rechercherContratsEre() throws TechnicalException {
        if (isEmpty(userContextHolder.get().getNumeroPersonneEre())) {
            return new ArrayList<>();
        }
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(ERE);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneEre());
        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsPersonne(rechercherContratsDto);
        return filterContratsPartenaire(contratHeaders);
    }

    @Override
    public List<ContratHeader> rechercherContrats() throws TechnicalException {
        final Future<List<ContratHeader>> ere = asyncExecutor.submit(this::rechercherContratsEre);
        final Future<List<ContratHeader>> mdp = asyncExecutor.submit(this::rechercherContratsMdpro);

        List<ContratHeader> contrats = new ArrayList<>();
        contrats.addAll(Futures.get(ere));
        contrats.addAll(Futures.get(mdp));

        return contrats;
    }

    @Override
    public List<ContratComplet> rechercherContratsComplets() throws TechnicalException {
        List<ContratComplet> contratComplets = new ArrayList<>();
        Future<List<ContratComplet>> mdp = asyncExecutor.submit(this::rechercherContratsCompletsMDP);
        Future<List<ContratComplet>> ere = asyncExecutor.submit(this::rechercherContratsCompletsERE);

        contratComplets.addAll(Futures.get(mdp));
        contratComplets.addAll(Futures.get(ere));

        return contratComplets;
    }

    public List<ContratComplet> rechercherContratsComplets(CodeSiloType siloType) throws TechnicalException {
        if (ERE.equals(siloType)) {
            return rechercherContratsCompletsERE();
        }
        if (MDP.equals(siloType)) {
            return rechercherContratsCompletsMDP();
        }

        return Collections.emptyList();
    }

    public List<ContratComplet> rechercherContratsCompletsERE() throws TechnicalException {
        List<ContratHeader> contratsHeader = rechercherContratsEre();
        return contratsHeader.stream()
                .map(this::recupererContratComplet)
                .collect(Collectors.toList());
    }

    public List<ContratComplet> rechercherContratsCompletsMDP() throws TechnicalException {
        List<ContratHeader> contratsHeader = rechercherContratsMdpro();
        return contratsHeader.stream()
                .map(this::recupererContratComplet)
                .collect(Collectors.toList());
    }

    public Compartiment rechercherCompartimentEREPlusRecent(CompartimentType compartimentType) throws TechnicalException {
        final List<ContratHeader> contrats = rechercherContratsEre();

        final Comparator<Compartiment> comparator = this.comparatorDateEffetSituationAffiliation();
        return contrats.stream()
                .filter(contratHeader -> !contratHeader.getAffichageType().isDisabled())
                .flatMap(contratHeader -> contratHeader.compartiments(compartimentType).stream())
                .max(comparator)
                .orElse(null);
    }

    private List<ContratHeader> filterContratsPartenaire(List<ContratHeader> contratsHeader) {
        Partenaire partenaire = userContextHolder.get().getPartenaire();
        if (partenaire != null && partenaire.getRefExterne() != null) {
            String refExterne = partenaire.getRefExterne();
            contratsHeader = contratsHeader.stream()
                    .filter(contrat -> refExterne.equalsIgnoreCase(contrat.getIdContratReference()))
                    .collect(Collectors.toList());
        }
        return filterByRequestContext(contratsHeader);
    }

    private List<ContratHeader> filterByRequestContext(List<ContratHeader> contratsHeader) {
        if (requestContext.getContrat() != null) {
            List<ContratHeader> filteredContratsByRequestContrat =
                    filterContrat(contratsHeader, requestContext.getContrat());
            if (!filteredContratsByRequestContrat.isEmpty()) {
                return filteredContratsByRequestContrat;
            }
        }
        return contratsHeader;
    }

    private static List<ContratHeader> filterContrat(List<ContratHeader> contratsHeader,
                                                     String contratId) {
        return contratsHeader.stream().filter(ctr -> contratId.equals(ctr.getId()))
                .collect(Collectors.toList());
    }

    @SuppressWarnings("squid:S3776")
    public ContratComplet recupererContratComplet(final ContratHeader contratHeader) {
        final ContratComplet complet = new ContratComplet();
        complet.setContratHeader(contratHeader);
        final String idContrat = contratHeader.getId();
        final CodeSiloType silo = contratHeader.getCodeSilo();

        // Contrat General
        final ContratGeneral contratGenerale = getContratGenerale(idContrat, silo);
        complet.setContratGeneral(contratGenerale);

        // Compte ERE
        if (contratHeader.isEre()) {
            for (Compartiment compartiment : contratHeader.getCompartiments()) {
                if (compartiment.getIdentifiantAssure() != null) {
                    final CompteGeneralesERE compteGenerale = getCompteGenerale(compartiment.getIdentifiantAssure(), silo);
                    complet.setCompteGeneralesEre(compartiment.getCompartimentId(), compteGenerale);
                }
            }
            if (contratHeader.getIdentifiantAssure() != null) {
                final CompteGeneralesERE compteGenerale = getCompteGenerale(contratHeader.getIdentifiantAssure(), silo);
                complet.setCompteGeneralesERE(compteGenerale);
            }
        }

        return complet;
    }

    public ContratComplet rechercherContratCompletParId(ContratId contratId) throws TechnicalException {
        ContratHeader contratHeader = rechercherContratParId(contratId);
        if (contratHeader != null) {
            return recupererContratComplet(contratHeader);
        }
        return null;
    }

    @Override
    public List<ContratHeader> rechercherContratsEpargnePrevoyance() throws TechnicalException {
        return rechercherContratsMdpro();
    }

    public List<ContratHeader> rechercherContratsRetraiteSuppEpargnePrevoyanceMdpro() throws TechnicalException {
        if (isEmpty(userContextHolder.get().getNumeroPersonneMdpro())) {
            return new ArrayList<>();
        }
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(MDP);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneMdpro());
        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsRetraiteSuppEpargnePrevoyance(rechercherContratsDto);
        return filterContratsPartenaire(contratHeaders);
    }

    public ContratHeader rechercherContratRetraireSuppEpargnePrevoyanceMDPROParId(ContratId contratId) throws TechnicalException {
        checkNotNull(contratId);

        for (ContratHeader contrat : rechercherContratsRetraiteSuppEpargnePrevoyanceMdpro()) {
            // On ne prend pas en compte les contrats desactives
            if (!contrat.getAffichageType().isDisabled() && contratId.equals(contrat.getContratId())) {
                return contrat;
            }
        }
        throw new ContratInconnuException(contratId);
    }

    public CompteGeneralesERE getCompteGenerale(String idAssure, CodeSiloType silo) {
        if (ERE.equals(silo)) {
            try {
                ConsulterCompteGeneralesEREDto ccgERE = new ConsulterCompteGeneralesEREDto(idAssure);
                return contratClient.consulterCompteGeneralesERE(ccgERE);
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException(e);
            }
        }
        return null;
    }

    public ContratGeneral getContratGenerale(String idContrat, CodeSiloType silo) {
        try {
            ConsulterContratGeneralesDto ccg = new ConsulterContratGeneralesDto(idContrat, silo);
            return contratClient.consulterContratGenerales(ccg);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    public ContratGeneral rechercherContratGeneral(ContratId contratId) {
        return getContratGenerale(contratId.getNomContrat(), contratId.getCodeSilo());
    }

    public CompteGeneralesERE rechercherCompteGeneralesEre(String idAssure) {
        return getCompteGenerale(idAssure, ERE);
    }
}
