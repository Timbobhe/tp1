package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.function.Predicate;

public interface IEvenementFacade {
    EvenementJson generateNextEvenement(
            Predicate<TypeEvenementJson> typeEvenPredicate, Boolean avecImpersonation) throws TechnicalException;
    }
