package fr.ag2rlamondiale.rbb.dto.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.dto.contrat.MiniContratDto;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ContratClientDto implements MiniContratDto {
    @EqualsAndHashCode.Include
    private CodeSiloType codeSilo;
    private String college;
    @EqualsAndHashCode.Include
    private String id;

    private String personId;

    @EqualsAndHashCode.Include
    private String idAdherente;

    private String raisonSocialeAdherente;

    @EqualsAndHashCode.Include
    private String idContractante;

    private String raisonSocialeContractante;
    private String raisonSocialeFront;
    private String descriptionFront;

    private String idCollege;
    private String identifiantAssure;
    private AffichageType affichageType;

    private boolean contractanteRepresent;
    private Date dateAffiliation;

    private String codeProduit;
    private String libelleProduit;
    private String codeMentionLegale;
    private String typeContrat;
    private String numGenContrat;
    private String codeFiliale;
    private String etatContratLabel;
    private String etatAffiliationLabel;
    private Date dateEffet;
    private Date dateFinEffet;
    private String codeSitAffil;
    private String libSitAffil;
    private Date dateSitAffil;

    // ContratResume
    private SituationContratEnum etatContrat;
    private Date dateSitCtr;
    private Date dateEffetSituationAffiliation;

    private boolean pacte;

    private String descClauseBenef;

    private List<CompartimentDto> compartiments;

    private String codeCadreFiscal;

    private String libCadreFiscal;

    /**
     * contrats MDPRO 8X ont été migré sur PTV (Sur contrat général : TYPCONNUMGEN = RG02 002)
     */
    private boolean petitCollectifPTV;

    @Override
    public String getNomContrat() {
        return this.id;
    }

    @Override
    public String getDescription() {
        return this.descriptionFront;
    }

    @Override
    public String getRaisonSociale() {
        return this.raisonSocialeFront;
    }

    @Override
    public CompartimentType getCompartimentType() {
        return null;
    }
}
