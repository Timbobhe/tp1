package fr.ag2rlamondiale.rbb.profile;


import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;

import java.lang.annotation.*;

/**
 * to calculate the execution time of a method
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Inherited
@Documented
public @interface ProfileExecution {
    CodeActionType codeAction();
}
