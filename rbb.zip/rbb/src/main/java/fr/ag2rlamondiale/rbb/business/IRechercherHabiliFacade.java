package fr.ag2rlamondiale.rbb.business;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;

public interface IRechercherHabiliFacade {
    PersonnePhysique rechercherParIdGdi(String idGdi);

    PersonnePhysique rechercherParNumPers(String numPp, CodeSiloType silo);
}
