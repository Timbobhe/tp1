package fr.ag2rlamondiale.rbb.api.secure;

import com.ag2r.common.exceptions.CommonException;

import fr.ag2rlamondiale.rbb.domain.enumeration.CodeActionType;
import fr.ag2rlamondiale.rbb.domain.exception.EligibiliteException;
import fr.ag2rlamondiale.rbb.dto.ClientDto;
import fr.ag2rlamondiale.rbb.mapping.ClientMapper;
import fr.ag2rlamondiale.rbb.mapping.UtilisateurMapper;
import fr.ag2rlamondiale.rbb.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Implementation Spring du service REST pour la Recherche Client
 */
@Slf4j
@RestController
@RequestMapping(path = "/secure")
public class UtilisateurRestController {
	
    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ClientMapper clientMapper;

    @Autowired
    private UtilisateurMapper utilisateurMapper;

    /**
     * Méthode pour récupérer le client connecté
     *
     * @return ClientDto
     * @throws CommonException CommonException
     */
    @ProfileExecution(codeAction = CodeActionType.API_INFOSCLIENT_GET)
    @LogExecutionTime
    @GetMapping(path = "/get/infosclient")
    public ClientDto getClient() throws CommonException , EligibiliteException{
        UserContext userContext = userContextHolder.get();
        log.info("userContext : {}", userContext);
        ClientDto client = clientMapper.map(userContext);
        client = utilisateurMapper.mapperPersonnePhysiqueToClientDto(client, userContext);
        
        return client;
    }
}
