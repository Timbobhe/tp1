package fr.ag2rlamondiale.rbb.utils;

import java.util.Arrays;

public enum ProduitVersionAutorisePrevoyanceIndividuelle {

	AN13V01("AN13","V01"), TE15V06("TE15","V06"), TE15V01("TE15","V01"), TE15V02("TE15","V02"), TE15V03("TE15","V03"),
	TE15V04("TE15","V04"), TE15V05("TE15","V05"), TE16V06("TE16","V06"), TE16V01("TE16","V01"), TE16V03("TE16","V03"),
	TE16V05("TE16","V05"), TE17V01("TE17","V01"), TE18V01("TE18","V01"); 
	
	final String produit;
	final String version;
	
	private ProduitVersionAutorisePrevoyanceIndividuelle(String produit, String version) {
		this.produit = produit;
		this.version = version;
	}
	
	public static boolean contains(String produit, String version) {
		return Arrays.stream(values()).anyMatch(v -> v.produit.equals(produit) && v.version.equals(version));
	}
	
}
