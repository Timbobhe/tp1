package fr.ag2rlamondiale.rbb.business.impl;

import fr.ag2rlamondiale.rbb.business.IEvenGenerators;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.even.*;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class RbbEvenGenerators implements IEvenGenerators, InitializingBean {
    @Autowired
    private EreMsgIndispoEvenGenerator ereMsgIndispoEvenGenerator;

    @Autowired
    private MdpMsgIndispoEvenGenerator mdpMsgIndispoEvenGenerator;

    private Map<String, AbstractEvenGenerator> generatorMap = new HashMap<>();

    @Override
    public AbstractEvenGenerator getEvenGenerator(String codeTypeEvenement) {
        final AbstractEvenGenerator generator = generatorMap.get(codeTypeEvenement);
        if (generator == null && log.isDebugEnabled()) {
            log.debug("Le Type evenement {} n'est pas g\u00e9r\u00e9 applicativement", codeTypeEvenement);
        }

        return generator;
    }

    @Override
    public EvenementJson generateNextEven(List<TypeEvenementJson> typesEven, String idGdi, String numPersonne,
                                          Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens) {

        TriggeringResults triggeringResults = new TriggeringResults();

        // 1. On recherche les even déclenchable
        for (TypeEvenementJson typeEven : typesEven) {
            final AbstractEvenGenerator generator = getEvenGenerator(typeEven.getCodeEvenement());
            if (generator != null) {
                generator.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, triggeringResults);
            }
        }

        // 2. On prepare le déclenchement
        triggeringResults.forEachGenerator(generator -> generator.prepare(idGdi, numPersonne, contrats));

        // 3. On génére les EVEN
        for (TriggeringResult result : triggeringResults) {
            final EvenementJson even = result.getGenerator().generateNextEven(result);
            if (even != null) {
                return even;
            }
        }

        return null;
    }

    @Override
    public void afterPropertiesSet() {
        generatorMap.put("ERE_MSG_INDISPO", ereMsgIndispoEvenGenerator);
        generatorMap.put("MDP_MSG_INDISPO", mdpMsgIndispoEvenGenerator);
    }
}
