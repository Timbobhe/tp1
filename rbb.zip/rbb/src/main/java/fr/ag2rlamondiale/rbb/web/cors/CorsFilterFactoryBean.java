package fr.ag2rlamondiale.rbb.web.cors;

import java.util.Arrays;
import java.util.Collections;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import lombok.Setter;
/**
 * FactoryBean Spring du CorsFilter.
 * 
 * @author JEMMALI EMIR
 *
 */
@Configuration
@Component("corsFilter")
public class CorsFilterFactoryBean implements FactoryBean<CorsFilter>{
	@Setter
	@Value("${cors.allowedOrigins}")
	private String allowedOrigins;

	@Override
	public CorsFilter getObject() throws Exception {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowCredentials(true);
		if (StringUtils.isNotBlank(allowedOrigins)) {
			configuration.setAllowedOrigins(Arrays.asList(allowedOrigins.split(",")));
		}
		configuration.setAllowedMethods(Collections.singletonList("*"));
		configuration.setAllowedHeaders(Collections.singletonList("*"));
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return new CorsFilter(source);
	}

	@Override
	public Class<?> getObjectType() {
		return CorsFilter.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
}
