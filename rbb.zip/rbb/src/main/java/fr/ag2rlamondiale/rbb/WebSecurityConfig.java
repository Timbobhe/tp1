package fr.ag2rlamondiale.rbb;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfFilter;


/**
 * https://v7.angular.io/guide/http#security-xsrf-protection
 * <p>
 * ...
 * In order to prevent collisions in environments where multiple Angular apps share the same domain or subdomain,
 * give each application a unique cookie name.
 * ...
 */
@Configuration
public class WebSecurityConfig {
    @Value("${security.csrf.cookieName:XSRF-A1573-TOKEN}")
    private String csrfCookieName;

    @Value("${security.csrf.headerName:X-XSRF-A1573-TOKEN}")
    private String csrfHeaderName;

    @Value("${security.csrf.cookie.domain:NOT-SET}")
    private String csrfDomain;

    @Value("${security.csrf:false}")
    private boolean isCsrfTokenActivated;

    @Bean
    @Qualifier("csrfFilter")
    public CsrfFilter csrfFilter() {
        final CookieCsrfTokenRepository csrfTokenRepository = CookieCsrfTokenRepository.withHttpOnlyFalse();
        if (!"NOT-SET".equals(csrfDomain)) {
            csrfTokenRepository.setCookieDomain(csrfDomain);
        }
        csrfTokenRepository.setCookiePath("/");
        csrfTokenRepository.setCookieName(csrfCookieName);
        csrfTokenRepository.setHeaderName(csrfHeaderName);
        final CsrfFilter csrfFilter = new CsrfFilter(csrfTokenRepository);
        if (!isCsrfTokenActivated) {
            csrfFilter.setRequireCsrfProtectionMatcher(request -> false);
        }

        return csrfFilter;
    }
}
