package fr.ag2rlamondiale.rbb.security;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.security.acegi.dao.MetisCasUserDetailsService;
import com.ag2r.common.security.acegi.dao.UserDetailsImpl;
import com.google.common.base.Strings;
import fr.ag2rlamondiale.rbb.business.IBlocageFacade;
import fr.ag2rlamondiale.rbb.business.IClientFacade;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.rbb.domain.exception.PartenaireException;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapper;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.DemandeRecherchePP;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RechercherPPSiloResponseDto;
import fr.ag2rlamondiale.trm.security.AuthentificationUtils;
import fr.ag2rlamondiale.trm.security.RolesEnum;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.security.UserSecurityService;
import fr.ag2rlamondiale.trm.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import static fr.ag2rlamondiale.trm.domain.partenaire.PartenaireUtils.temporaryUserId;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Slf4j
public class RbbCasUserDetailsService extends MetisCasUserDetailsService {
    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private UserSecurityService securityService;

    @Autowired
    private IClientFacade clientFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private IPartenaireFacade partenaireFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private PartenaireMapper partenaireMapper;

    public RbbCasUserDetailsService(String[] attributesRoles) {
        super(attributesRoles);
    }

    @Override
    public UserDetails loadUserDetails(Authentication authentication) {
        long start = System.currentTimeMillis();
        log.info("Tentative de connexion avec {}", authentication);
        final UserDetails userDetails = basicLoadUserDetails(authentication);
        log.info("Connexion réussie pour {} en {} ms", userDetails, System.currentTimeMillis() - start);
        return userDetails;
    }

    private UserDetails basicLoadUserDetails(Authentication authentication) {
        try {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetailsImpl userDetails = (UserDetailsImpl) super.loadUserDetails(authentication);

            Map<String, Object> casMap = userDetails.getAttributesMap();
            PersonnePhysique personnePhysique;
            String idGdi;
            userContextHolder.get().setHasIdGdi(true);
            if (AuthentificationUtils.isUserImpersonated(userDetails)) {
                userContextHolder.get().setImpersonation(true);
                userContextHolder.get().setExternalUid(getExternalUid(userDetails));
            }
            if (AuthentificationUtils.hasRole(userDetails, RolesEnum.FEDERATION)) {
                personnePhysique = getPersonnePhysiqueDepuisFederationIndentite(casMap, userDetails);
                // Pour récupérer l'ID technique de connexion
                idGdi = personnePhysique.getIdGdi();
            } else {
                idGdi = (String) casMap.get("uid");
                Objects.requireNonNull(idGdi, "L'idGDI du jeton CAS est null");
                userContextHolder.get().setIdGdi(idGdi); // pour la traceWs
                personnePhysique = clientFacade.rechercherPersonnePhysiqueParIdGdi(idGdi);

                // Mise a jour de l'idgdi si l'utilisateur precedemment connecte par federation se
                // connecte avec un idgdi
                if (isNotEmpty(personnePhysique.getNumeroPersonneEre())) {
                    partenaireFacade.updateIdgdiTemporaire(null, personnePhysique.getNumeroPersonneEre(),
                            personnePhysique.getNumeroPersonneMdpro(), idGdi);
                }
            }
                securityService.initSecurityContext(idGdi, personnePhysique);

            if (userContextHolder.get().getPartenaire() != null) {
                List<ContratHeader> contrats = contratFacade.rechercherContrats();
                if (contrats.isEmpty()) {
                    throw new PartenaireException(PartenaireException.ErrorCode.NO_CONTRACTS);
                }
            }

            InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();
            userContextHolder.get().setInfosBlocagesClient(infosBlocagesClient);
            logBlocages(idGdi, infosBlocagesClient);

            return userDetails;
        } catch (Exception e) {
            log.error("Erreur d'authentication", e);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw new UsernameNotFoundException("Erreur d'authentication", e);
        }
    }

    private void logBlocages(String idGdi, InfosBlocagesClient infosBlocagesClient) {
        if (infosBlocagesClient.isPersonneTotalementBloquee()) {
            log.warn("Utilisateur {} totalement bloqué (blocage console)", idGdi);
        }
        if (infosBlocagesClient.isToutLesContratsTotalementsBloques()) {
            log.warn("Utilisateur {}, tous les contrats totalement bloqués (blocage console)", idGdi);
        }
        if (!infosBlocagesClient.getFonctionnalitesBloqueesContrats().isEmpty()) {
            log.warn("Utilisateur {}, a fonctionnalites bloques sur au moins un contrat {} (blocage console)", idGdi, infosBlocagesClient.getFonctionnalitesBloqueesContrats());
        }
        if (userContextHolder.get().getPartenaire() != null && !infosBlocagesClient.getFonctionnalitesBloqueesPartenaire().isEmpty()) {
            log.warn("Utilisateur {} connexion partenaire, a des fonctionnalites partenaires bloques {} (blocage console)", idGdi, infosBlocagesClient.getFonctionnalitesBloqueesPartenaire());
        }
    }

    private String getExternalUid(UserDetailsImpl userDetails) {
        return (String) userDetails.getAttributesMap().get("externalUid");
    }

    /**
     * Connexion depuis partenaire
     *
     * @param casMap
     * @param userDetails
     * @return
     * @throws CommonException
     */
    private PersonnePhysique getPersonnePhysiqueDepuisFederationIndentite(Map<String, Object> casMap,
                                                                          UserDetailsImpl userDetails) throws CommonException {
        log.info("Connexion par f\u00e9d\u00e9ration d'identit\u00e9.");
        String numPers = null;
        String refExterne = null;
        String primaryPartner = Strings.emptyToNull((String) casMap.get("fdiPerimeterName"));
        Objects.requireNonNull(primaryPartner, "Le code partenaire dans le jeton CAS est vide");
        Partenaire partenaire = partenaireMapper.map(partenaireFacade.findById(primaryPartner));
        userContextHolder.get().setPartenaire(partenaire);
        String secondaryPartner = Strings.emptyToNull((String) casMap.get("seeAlso"));
        if (secondaryPartner != null) {
            userContextHolder.get().setSousPartenaire(secondaryPartner);
        }
        Map<String, String> businessIdMap = MapUtils.parseStringMap((String) casMap.get("businessIdMap"));

        if (businessIdMap != null) {
            refExterne = Strings.emptyToNull(businessIdMap.get("refExterne"));
            partenaire.setBaseUrl(Strings.emptyToNull(businessIdMap.get("origineAcces")));
            partenaire.setRefExterne(refExterne);
            if (refExterne != null) {
                DemandeRecherchePP demandeRecherchePP = new DemandeRecherchePP(refExterne);
                RechercherPPSiloResponseDto rechercherPPSilo = clientFacade.rechercherPPSilo(demandeRecherchePP);

                if (rechercherPPSilo == null || rechercherPPSilo.getPersonnesPhysiques() == null) {
                    throw new PartenaireException(PartenaireException.ErrorCode.UNKNOWN_USER);
                } else if (rechercherPPSilo.getPersonnesPhysiques().get(0).getIdentSiloDto() != null
                        && !rechercherPPSilo.getPersonnesPhysiques().get(0).getIdentSiloDto().getListeIdSiloDto().isEmpty()) {
                    numPers = rechercherPPSilo.getPersonnesPhysiques().get(0).getIdentSiloDto().getListeIdSiloDto().get(0).getValeurId();
                }
            }

            if (numPers == null) {
                numPers = Strings.emptyToNull(businessIdMap.get("idEpargneRetraite"));
            }
        }
        Objects.requireNonNull(numPers, "Le num\u00e9ro de personne dans le jeton CAS est vide");
        PersonnePhysique personnePhysique = clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(numPers);

        final Integer idTechCnx = partenaireFacade
                .updateIdgdiTemporaire(primaryPartner, numPers, null, personnePhysique.getIdGdi());

        if (personnePhysique.getIdGdi() == null) {
            final String tempUserId = temporaryUserId(idTechCnx);
            personnePhysique.setIdGdi(tempUserId);
            userContextHolder.get().setHasIdGdi(false);
        }
        userContextHolder.get().setTemporaryId(idTechCnx);
        userContextHolder.get().setIdGdi(personnePhysique.getIdGdi());
        userDetails.setUsername(userContextHolder.get().getIdGdi());
        userDetails.setUserFirstLastName(personnePhysique.getPrenom() + ' ' + personnePhysique.getNom());

        log.info("idGdi : {}, Num\u00e9ro de personne : {}, Code partenaire : {}", userContextHolder.get().getIdGdi(),
                numPers, primaryPartner);
        return personnePhysique;
    }
}
