package fr.ag2rlamondiale.rbb.utils;

import java.util.Arrays;

public enum ProduitAutorisePrevoyanceTNS {

    AC05("AC05"), AC06("AC06"), AI01("AI01"), AN01("AN01"), AN02("AN02"), AN03("AN03"), AN04("AN04"), AN05("AN05"), AN06("AN06"),
    AN07("AN07"), AN08("AN08"), AN09("AN09"), AN10("AN10");

    final String produit;

    private ProduitAutorisePrevoyanceTNS(String produit) {
        this.produit = produit;
    }

    public static boolean contains(String produit) {
        return Arrays.stream(values()).anyMatch(v -> v.produit.equals(produit));
    }

}
