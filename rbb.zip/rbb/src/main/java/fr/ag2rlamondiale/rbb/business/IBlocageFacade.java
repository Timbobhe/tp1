package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;

import java.util.Collection;

public interface IBlocageFacade {
    InfosBlocagesClient getInfosBlocagesClient() throws TechnicalException;

    Collection<ContratHeader> getContratsNonBloques() throws TechnicalException;
}
