package fr.ag2rlamondiale.rbb.business;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.even.AbstractEvenGenerator;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.Collection;
import java.util.List;

public interface IEvenGenerators {
    AbstractEvenGenerator getEvenGenerator(String codeTypeEvenement);

    EvenementJson generateNextEven(List<TypeEvenementJson> typesEven, String idGdi, String numPersonne,
                                   Collection<ContratHeader> contrats, List<EvenementJson> evenementsDejaEnregistres);

}
