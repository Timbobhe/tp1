package fr.ag2rlamondiale.rbb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rbb.business.IContratFacade;
import fr.ag2rlamondiale.rbb.business.ITrackingFacade;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.dto.tracking.EquipementRetraiteSuppDto;
import fr.ag2rlamondiale.rbb.dto.tracking.TrackingInfoDto;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.csv.SituationFamilialeType;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Component
public class TrackingFacadeImpl implements ITrackingFacade {
    private static final int TRANCHE_AGE_EN_ANNEES = 5;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private IContratFacade contratFacade;

    @Override
    public TrackingInfoDto getTrackingInfo() throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        Objects.requireNonNull(userContext);

        TrackingInfoDto trackingInfo = new TrackingInfoDto();
        trackingInfo.setImpersonnation(userContext.isImpersonation());
        final Partenaire partenaire = userContext.getPartenaire();
        if (partenaire != null) {
            trackingInfo.setPartenaire(partenaire.getCodePartenaire());
        } else {
            trackingInfo.setPartenaire("AG2R");
        }

        appendPersonneInfo(userContext, trackingInfo);
        appendContratInfo(trackingInfo);

        return trackingInfo;
    }

    private void appendContratInfo(TrackingInfoDto trackingInfo) throws TechnicalException {
        final List<ContratHeader> contratHeaders = contratFacade.rechercherContrats();
        if (contratHeaders == null || contratHeaders.isEmpty()) {
            return;
        }

        final List<EquipementRetraiteSuppDto> equipements = contratHeaders.stream()
                .map(c -> EquipementRetraiteSuppDto.builder()
                        .typeContrat(c.getTypeContrat())
                        .assureur(c.getIdentifiantAssure())
                        .appellation(c.getDescriptionFront())
                        .build())
                .collect(Collectors.toList());

        trackingInfo.setEquipementsRetraiteSupp(equipements);
    }

    private void appendPersonneInfo(UserContext userContext, TrackingInfoDto trackingInfo) throws TechnicalException {
        IdSiloDto idSilo = userContext.getIdSilo();
        if (idSilo != null) {
            PersonnePhysiqueConsult pp = consulterPersonneClient.consulterPersPhys(idSilo);
            Objects.requireNonNull(pp);
            // Genre
            if ("F".equals(pp.getCodeSexe())) {
                trackingInfo.setClientGenre("Madame");
            } else {
                trackingInfo.setClientGenre("Monsieur");
            }

            // Tranche age
            trackingInfo.setClientAge(getTrancheAge(pp.getAge()));

            // situation familiale
            final SituationFamilialeType situationFamiliale = pp.getSituationFamiliale();
            if (situationFamiliale != null) {
                trackingInfo.setClientSituationFamiliale(situationFamiliale.getLibelle());
            } else {
                trackingInfo.setClientSituationFamiliale("inconnu");
            }

            // code postal
            trackingInfo.setClientPostcode(getCodeDepartement(pp.getCodePostal()));
        }
    }

    private String getTrancheAge(Integer age) {
        if (age == null) {
            return "age inconnu";
        }

        if (age <= 20) {
            return "0 \u00e0 20 ans";
        } else if (age > 75) {
            return "Plus de 75 ans";
        } else {
            int surplusAge = (age - 1) % TRANCHE_AGE_EN_ANNEES;
            int ageArrondi = age - surplusAge;
            return ageArrondi + " \u00e0 " + (ageArrondi + TRANCHE_AGE_EN_ANNEES - 1) + " ans";
        }
    }

    private String getCodeDepartement(final String codeDepartement) {
        if (codeDepartement != null) {
            return codeDepartement.replaceFirst("^(\\d*)\\s*\\d{3}$", "$1");
        }
        return null;
    }
}
