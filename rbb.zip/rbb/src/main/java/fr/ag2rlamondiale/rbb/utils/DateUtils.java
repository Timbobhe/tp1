package fr.ag2rlamondiale.rbb.utils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtils {
	
	private DateUtils() {
		
	}
	
	/**
	 * Verifie si une personne avec la date de naissance donnee en parametre est majeure à la date du jour
	 * @param la date de naissance
	 * @return true si la personne est majeure, faux sinon.
	 */
	public static boolean estMajeur(Date dateNaissance) {

		GregorianCalendar dateJourCal = new GregorianCalendar();
		dateJourCal.setTime(new Date());
		int backInTime = dateJourCal.get(Calendar.YEAR) - 18;
		dateJourCal.set(Calendar.YEAR, backInTime);

		return !dateNaissance.after(dateJourCal.getTime());
	}
	
	/**
	 * Vérifie si une personne moins de 85 ans par rapport à la date du jour
	 * @param dateNaissance
	 * @return true si moins de 85 ans à la date du jour, faux sinon
	 */
	public static boolean moinsDe85ans(Date dateNaissance) {

		GregorianCalendar dateJourCal = new GregorianCalendar();
		dateJourCal.setTime(new Date());
		int backInTime = dateJourCal.get(Calendar.YEAR) - 85; 
		dateJourCal.set(Calendar.YEAR, backInTime);

		return dateNaissance.after(dateJourCal.getTime());
	}
}
