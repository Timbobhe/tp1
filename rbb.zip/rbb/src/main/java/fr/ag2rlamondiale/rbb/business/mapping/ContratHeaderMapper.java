package fr.ag2rlamondiale.rbb.business.mapping;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.blocage.BlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.ProduitContratJson;
import org.mapstruct.*;

@FunctionalInterface
@Mapper(componentModel = "spring")
public interface ContratHeaderMapper {
    @Mapping(source = "id", target = "numContrat")
    @Mapping(source = ".", target = "produit", qualifiedByName = "produit")
    @Mapping(source = "codeFiliale", target = "filiale")
    @Mapping(source = "personId", target = "numPersonne")
    @Mapping(source = "codeSilo", target = "codeSiloType")
    ProduitContratJson mapContrat(ContratHeader contrat);

    @AfterMapping
    default void afterMapping(@MappingTarget ProduitContratJson type, BlocageJson blocage) {
        switch (blocage.getTypePerimetre()) {
            case CONTRAT:
                type.setNumContrat(blocage.getValeurPerimetre());
                break;
            case PERSONNE:
                type.setNumPersonne(blocage.getValeurPerimetre());
                break;
            case FILIALE:
                type.setFiliale(blocage.getValeurPerimetre());
                break;
            case PRODUIT:
                type.setProduit(blocage.getValeurPerimetre());
                break;
            default:
                break;
        }
    }

    @Named("produit")
    default String produit(ContratHeader contrat) {
        return contrat.getTypeContrat() + "-" + contrat.getNumGenContrat() + "-" + contrat.getCodeFiliale();
    }
}
