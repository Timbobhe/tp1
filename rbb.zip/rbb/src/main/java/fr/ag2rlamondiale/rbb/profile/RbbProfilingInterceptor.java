package fr.ag2rlamondiale.rbb.profile;

import fr.ag2rlamondiale.trm.profile.AbstractProfilingInterceptor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class RbbProfilingInterceptor extends AbstractProfilingInterceptor {
    @Around("@annotation(profileExecution)")
    public Object profilingAroundAdvice(ProceedingJoinPoint joinPoint, ProfileExecution profileExecution) throws Throwable {
        return profilingAroundAdvice(joinPoint, profileExecution.codeAction());
    }
}
