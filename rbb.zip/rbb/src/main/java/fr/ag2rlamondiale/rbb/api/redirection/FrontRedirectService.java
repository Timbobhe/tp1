package fr.ag2rlamondiale.rbb.api.redirection;

import fr.ag2rlamondiale.rbb.business.IPartenaireFacade;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

/**
 * Service de Redirection
 */
@Slf4j
@RestController
@RequestMapping
public class FrontRedirectService {
    @Autowired
    private IPartenaireFacade partenaireFacade;

    @LogExecutionTime
    @GetMapping(path = "/secure/redirectToFront")
    public ResponseEntity<String> redirectToFront(@RequestParam(name = "service") String service) {
        return retrieveResponseEntity(service);
    }

    @LogExecutionTime
    @GetMapping(path = "/public/redirectToPartenaireById")
    public ResponseEntity<String> redirectToPartenaireById(@RequestParam("id") String id) {
        PartenaireJson partenaire = partenaireFacade.findById(id);
        Objects.requireNonNull(partenaire);
        return retrieveResponseEntity(partenaire.getUrlError().concat("?id=LOGOUT"));
    }

    private ResponseEntity<String> retrieveResponseEntity(String url) {
        if (isInvalidURL(url)) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        HttpHeaders headers = new HttpHeaders();
        log.info("Redirection to: {}", url);
        headers.add("Location", url);
        return new ResponseEntity<>(headers, HttpStatus.FOUND);
    }

    private boolean isInvalidURL(String service) {
        try {
            new URL(service);
        } catch (MalformedURLException e) {
            return true;
        }
        return false;
    }
}
