package fr.ag2rlamondiale.rbb.domain.even;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.*;

import static fr.ag2rlamondiale.rbb.domain.even.EvenUtils.*;
import static fr.ag2rlamondiale.trm.utils.CollectionUtils.escapeNull;

public abstract class AbstractEvenWithContratGenerator extends AbstractEvenGenerator {

    /**
     * Evaluer l'évènement en fonction d'un contrat donné.
     *
     * @param contrat
     * @return true si l'évènement doit être déclenché, false sinon
     */
    public abstract boolean evaluerEvenement(ContratHeader contrat);

    @Override
    public EvenementJson generateNextEven(TriggeringResult result) {
        ContratHeader contrat = result.getContrat();
        if (evaluerEvenement(contrat)) {
            EvenementJson newEvenement = new EvenementJson();
            newEvenement.setIdGdi(result.getIdGdi());
            newEvenement.setTypeEvenement(result.getTypeEvenement());
            newEvenement.setDateDebut(new Date());
            newEvenement.setNumContrat(contrat.getId());
            return newEvenement;
        }
        return null;
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (isPersonneAutorisee(idGdi, numPersonne, typeEven.getPerimetreEvenements())) {
            Map<String, List<EvenementJson>> evtsByContratForType =
                    getEvenementsByContratForType(typeEven, historiqueEvens);

            for (ContratHeader contrat : contrats) {
                List<EvenementJson> evtsForContrat = evtsByContratForType.get(contrat.getId());
                if (isContratDeclenchable(typeEven, contrat, evtsForContrat)) {
                    results.add(this, idGdi, numPersonne, typeEven, contrat);
                }
            }
        }
    }

    private boolean isContratDeclenchable(TypeEvenementJson typeEvenement, ContratHeader contrat,
                                          List<EvenementJson> evenementsContratDejaEnregistres) {

        if (!isContratAutorise(contrat, typeEvenement.getPerimetreEvenements())) {
            return false;
        }
        if (dejaTraite(evenementsContratDejaEnregistres)) {
            return false;
        }
        if (!neDepassePasNombreMaxDeclenchements(typeEvenement, evenementsContratDejaEnregistres)) {
            return false;
        }
        if (!(typeEvenement.isObligatoire() || pasEncorePresenteAujourdhui(evenementsContratDejaEnregistres))) {
            return false;
        }

        return respecteDelaiReactivation(typeEvenement, evenementsContratDejaEnregistres);
    }

    /**
     * Filtre les évènements pour ne conserver que ceux du type passé en paramètre Ordonne le
     * résultat dans une Map avec pour clé le numero de contrat.
     *
     * @param typeEvenement
     * @param evenementsDejaEnregistres
     * @return
     */
    private Map<String, List<EvenementJson>> getEvenementsByContratForType(TypeEvenementJson typeEvenement,
                                                                           List<EvenementJson> evenementsDejaEnregistres) {
        final Map<String, List<EvenementJson>> evtsByContrat = new HashMap<>();
        for (EvenementJson evt : escapeNull(evenementsDejaEnregistres)) {
            if (typeEvenement.equals(evt.getTypeEvenement())) {
                String numContrat = evt.getNumContrat();
                evtsByContrat.computeIfAbsent(numContrat, s -> new ArrayList<>()).add(evt);
            }
        }
        return evtsByContrat;
    }
}
