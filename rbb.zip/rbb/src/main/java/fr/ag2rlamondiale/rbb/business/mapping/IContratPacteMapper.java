package fr.ag2rlamondiale.rbb.business.mapping;

import java.util.List;

import fr.ag2rlamondiale.rbb.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;

public interface IContratPacteMapper {
    List<ContratHeader> convertToPacte(List<ContratHeaderDto> contratHeaderDto, InfosContratDto infosContratDto);

    ContratHeader mapBasic(ContratHeaderDto dto);
}
