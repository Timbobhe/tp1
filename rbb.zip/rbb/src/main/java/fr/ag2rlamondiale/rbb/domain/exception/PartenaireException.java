package fr.ag2rlamondiale.rbb.domain.exception;

public class PartenaireException extends RuntimeException {
	private static final long serialVersionUID = 943924415543527050L;

	private final ErrorCode errorCode;

    public PartenaireException(ErrorCode code) {
        super(code.getLabel());
        this.errorCode = code;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }

    public enum ErrorCode {
        UNKNOWN_PARTENAIRE("Partenaire inconnu"),
        UNKNOWN_USER("Utilisateur inconnu"),
        NO_CONTRACTS("Utilisateur avec aucun contrat");

        private String label;

        ErrorCode(String label) {
            this.label = label;
        }

        public String getLabel() {
            return label;
        }
    }
}
