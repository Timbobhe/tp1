package fr.ag2rlamondiale.rbb.business;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.personne.DemandeRecherchePP;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RechercherPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;

/**
 * Interface de la Facade de récupération et agrégation des données contrat.
 */
public interface IClientFacade {
    PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException;

    PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne) throws CommonException;

    ModifierPPSiloResponseDto modifierCoordonneesClient(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException;

    RechercherPPSiloResponseDto rechercherPPSilo(DemandeRecherchePP demandeRecherchePP) throws TechnicalException;
}
