package fr.ag2rlamondiale.rbb.dto.contrat;

import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType;
import lombok.Data;

@Data
public class CompartimentDto {
    private CompartimentId compartimentId;
    private String college;
    private String identifiantAssure;
    private CompartimentType type;
    private String libelleEtat;
    private AffichageType affichageType;
    private boolean deductible;
    private DisponibiliteType disponibilite;
}
