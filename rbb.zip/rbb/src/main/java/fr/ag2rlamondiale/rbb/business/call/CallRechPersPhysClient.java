package fr.ag2rlamondiale.rbb.business.call;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ag2r.common.exceptions.TechnicalException;


import fr.ag2rlamondiale.epinlib.domain.req.CriteresRecherchePersPhysDto;
import fr.ag2rlamondiale.epinlib.domain.resp.ListePersPhysDto;
import fr.ag2rlamondiale.epinlib.service.IRechPersPhysClient8Service;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import fr.ag2rlamondiale.rbb.utils.ErrorConstantes;
import lombok.extern.slf4j.Slf4j;

/**
 * Appel du service pfs : GestPersPhys_2/RechPersPhysClient_8
 *
 */
@Slf4j
@Component
public class CallRechPersPhysClient {

	@Autowired(required = true)
	IRechPersPhysClient8Service rechPersPhysClient8Service;

	public  ListePersPhysDto callRechPersPhysClient8Service(String idPersPhys) throws TechnicalException {

		CriteresRecherchePersPhysDto frstCallCrit = new CriteresRecherchePersPhysDto(Constantes.CODE_APP_REPERE);
		frstCallCrit.getCodeApp().add(Constantes.CODE_APPLI_EGESPER_MDPRO);
		frstCallCrit.setIdPersPhys(idPersPhys);

		ListePersPhysDto retour = null;
		try {
			retour = rechPersPhysClient8Service.call(frstCallCrit);

		} catch (TechnicalException e) {
			log.error(ErrorConstantes.ERROR_RECHPERSPHYS, e);
			throw e;
		} catch (Exception ex) {
			log.error("ERROR INNATENDUE sur call rechPersPhysClient8Service {}", ex);
			throw new TechnicalException(ErrorConstantes.ERREUR_TECHNIQUE, ex.getLocalizedMessage());
		}
		return retour;
	}
	
}
