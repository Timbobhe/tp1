package fr.ag2rlamondiale.rbb.web.filter;

import com.google.common.base.Splitter;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.trm.cache.RequestScopedCacheManager;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.slf4j.MDC;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.Set;

/**
 * filter pour mettre a jour le wsContext Threadlocal
 */
@Component
public class ThreadLocalFilter implements Filter, InitializingBean {

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private RequestScopedCacheManager requestScopedCacheManager;

    @Value("${http.headers.to-mdc:user-agent}")
    private String confHeaders;

    private Set<String> headersToMDC;
    private boolean threadContextInheritable = false;

    @Override
    public void init(FilterConfig fConfig) {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    public void destroy() {
        // Empty
    	requestScopedCacheManager.clearCaches();
    	userContextHolder.clean();
        MDC.clear();
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse responseServ, FilterChain filterChain)
            throws IOException, ServletException {
        try {
            HttpServletRequest request = (HttpServletRequest) servletRequest;
            UserContext userContext = (UserContext) ((HttpServletRequest) servletRequest).getSession()
                    .getAttribute(UserContextHolder.SESSION_USER_CONTEXT);

            MDC.put("clientIp", getClientIp(request));

            if (!this.headersToMDC.contains("none")) {
                for (String header : this.headersToMDC) {
                    final String value = request.getHeader(header);
                    MDC.put("reqheader." + header, value);
                }
            }

            if (userContext != null) {
                userContextHolder.set(userContext);
            }

            requestScopedCacheManager.clearCaches();
            HttpServletResponse response = (HttpServletResponse)responseServ;
    		ServletRequestAttributes attributes = new ServletRequestAttributes(request, response);


            initContextHolders(request, attributes);
            filterChain.doFilter(request, response);
        } finally {
            requestScopedCacheManager.clearCaches();
            userContextHolder.clean();
            MDC.clear();
        }
    }

	public void setThreadContextInheritable(boolean threadContextInheritable) {
		this.threadContextInheritable = threadContextInheritable;
	}

    private void initContextHolders(HttpServletRequest request, ServletRequestAttributes requestAttributes) {
		LocaleContextHolder.setLocale(request.getLocale(), this.threadContextInheritable);
		RequestContextHolder.setRequestAttributes(requestAttributes, this.threadContextInheritable);
		
	}

    private static String getClientIp(HttpServletRequest request) {
        String remoteAddr = "";
        if (request != null) {
            remoteAddr = request.getHeader("X-FORWARDED-FOR");
            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = request.getRemoteAddr();
            }
        }

        return remoteAddr;
    }

    @Override
    public void afterPropertiesSet() {
        headersToMDC = Sets.newHashSet(Splitter.on(",").trimResults().omitEmptyStrings().split(this.confHeaders));
    }
}
