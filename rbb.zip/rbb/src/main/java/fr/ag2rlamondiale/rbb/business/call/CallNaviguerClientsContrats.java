package fr.ag2rlamondiale.rbb.business.call;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.epinlib.domain.req.CritereRechercheContratDto;
import fr.ag2rlamondiale.epinlib.domain.resp.ListeClientsContratDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.ClientDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.IdentifiantDto;
import fr.ag2rlamondiale.epinlib.domain.sub.soap.PersonnePhysiqueDto;
import fr.ag2rlamondiale.epinlib.service.INaviguerClientsContrats4Service;
import fr.ag2rlamondiale.rbb.utils.Constantes;
import fr.ag2rlamondiale.rbb.utils.ErrorConstantes;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CallNaviguerClientsContrats {

	@Autowired(required = true)
	INaviguerClientsContrats4Service naviguerClientsContrats4Service;

	public ClientDto callNaviguerClientsContrats4(String idGdi, PersonnePhysiqueDto pp) throws TechnicalException {
		
		CritereRechercheContratDto crit = new CritereRechercheContratDto(idGdi, Constantes.CODE_APP_8X);

		crit.getIds().add(new IdentifiantDto(pp.getIds().stream().findFirst().orElse(new IdentifiantDto()).getId(),
						Constantes.CODE_APPLI_EGESPER_MDPRO, Constantes.CODE_SYS_INFO_EGESPER_MDPRO));
		ListeClientsContratDto listeClientsContratDto = null;

		try {	
			listeClientsContratDto = naviguerClientsContrats4Service.call(crit);
		} catch (TechnicalException e) {
			log.error("ERROR sur call naviguerClientsContrats4Service {}", e);
			throw e;
		} catch (Exception ex) {
			log.error("ERROR INNATENDUE sur call naviguerClientsContrats4Service {}", ex);
			throw new TechnicalException(ErrorConstantes.ERREUR_TECHNIQUE, ex.getLocalizedMessage());
		} 

		return listeClientsContratDto.getListClients().stream().findFirst().orElse(new ClientDto());

	}

}
