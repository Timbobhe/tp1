export const environment = {
  production: true,
  mock: true
};
