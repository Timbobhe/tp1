import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rba-common',
  templateUrl: './rba-common.component.html',
  styleUrls: ['./rba-common.component.css']
})
export class RbaCommonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
