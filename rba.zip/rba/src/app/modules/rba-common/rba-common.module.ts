import { Ag2rlmLibModule } from '@ag2rlamondiale/ag2rlm-lib';
import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { OgiHeaderModule, OgiResponsiveModule } from '@ag2rlamondiale/ogi-lib';
import { SharedModule, TransverseMetierCommonModule } from '@ag2rlamondiale/transverse-metier-ng';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ButtonModule, ChartModule, DialogModule, InputSwitchModule, InputTextareaModule, KeyFilterModule, ProgressBarModule, SelectButtonModule, TooltipModule } from 'primeng/primeng';
import { NotEligibleContractsComponent } from './components/errors/not-eligible-contract/not-eligible-contract.component';
import { RbaErrorMajeureComponent } from './components/errors/rba-error-majeure/rba-error-majeure.component';
import { RbaErrorMineureComponent } from './components/errors/rba-error-mineure/rba-error-mineure.component';
import { RbaErrorModereeComponent } from './components/errors/rba-error-moderee/rba-error-moderee.component';
import { RbaErrorComponent } from './components/errors/rba-error/rba-error.component';
import { InfoNavigateurComponent } from './components/info-navigateur/info-navigateur.component';
import { MessageAlerteComponent } from './components/message-alerte/message-alerte.component';
import { MessageBlocageComponent } from './components/message-blocage/message-blocage.component';
import { RbaProgressBarComponent } from './components/rba-progress-bar/rba-progress-bar.component';
import { RbaProgressSpinnerComponent } from './components/rba-progress-spinner/rba-progress-spinner.component';
import { RbaCommonComponent } from './rba-common.component';

@NgModule({
  imports: [
    CommonModule,
    ProgressBarModule,
    DialogModule,
    ButtonModule,
    JahiaNgModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    Ag2rlmLibModule,
    TooltipModule,
    ProgressBarModule,
    KeyFilterModule,
    InputSwitchModule,
    InputTextareaModule,
    SelectButtonModule,
    TransverseMetierCommonModule,
    ChartModule,
    FlexLayoutModule,
    OgiHeaderModule,
    OgiResponsiveModule
  ],
  declarations: [
    RbaCommonComponent,
    RbaProgressBarComponent,
    InfoNavigateurComponent,
    RbaProgressSpinnerComponent,
    MessageAlerteComponent,
    MessageBlocageComponent,
    MessageAlerteComponent,
    RbaErrorMajeureComponent,
    RbaErrorModereeComponent,
    RbaErrorMineureComponent,
    RbaErrorComponent,
    NotEligibleContractsComponent
],
  exports: [
    RbaProgressSpinnerComponent,
    RbaProgressBarComponent,
    InfoNavigateurComponent,
    MessageBlocageComponent,
    MessageAlerteComponent,
    RbaErrorComponent,
    RbaErrorMajeureComponent,
    NotEligibleContractsComponent,
    TransverseMetierCommonModule
    ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RbaCommonModule { }
