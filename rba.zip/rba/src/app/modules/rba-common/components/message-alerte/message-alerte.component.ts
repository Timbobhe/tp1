import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-message-alerte',
  templateUrl: './message-alerte.component.html',
  styleUrls: ['./message-alerte.component.scss']
})
export class MessageAlerteComponent implements OnInit {
  @Input() show: boolean;
  @Output() onClose = new EventEmitter<boolean>();
  @Input() title: string;
  @Input() message: string;
  @Input() dictionnaire: string;
  @Input() label: string;
  constructor() { }

  ngOnInit() {
  }

  closeBloc() {
    this.onClose.emit(true);
  }
}
