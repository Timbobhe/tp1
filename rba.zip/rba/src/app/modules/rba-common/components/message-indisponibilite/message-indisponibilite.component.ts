import { Component, OnInit } from '@angular/core';
import { EvenementService } from '@app/services/evenement.service';
import { GetNextEven } from '@app/store/actions/evenement.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-message-indisponibilite',
  templateUrl: './message-indisponibilite.component.html',
  styleUrls: ['./message-indisponibilite.component.scss']
})
export class MessageIndisponibiliteComponent implements OnInit {
  show: boolean;
  title = '';
  subscriptions = [];
  dictionnaire = 'eventDictionnaireDeLibelles';
  label: string;


  constructor(private readonly store: Store<GlobalState>,
              private readonly evenService: EvenementService) { }

  ngOnInit() {
    this.subscriptions.push(this.evenService.getNextEvenIndisponibilite().subscribe(even => {
      this.label = even.typeEvenement.codeEvenement;
      this.show = true;
        this.store.dispatch(new GetNextEven());
      }
    ));
  }

  understand() {
    this.show = false;
  }
}
