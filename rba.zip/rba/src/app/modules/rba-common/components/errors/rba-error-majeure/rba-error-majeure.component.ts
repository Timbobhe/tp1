import { DynamicScriptLoaderService, HeaderOgiData } from '@ag2rlamondiale/ag2rlm-lib';
import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { InfoPersonne } from '@app/models/client/info.client.model';
import { ClearError } from '@app/store/actions/ui.actions';
import { selectAppInitialized } from '@app/store/reducers/rba.selectors';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-rba-error-majeure',
  templateUrl: './rba-error-majeure.component.html',
  styleUrls: ['./rba-error-majeure.component.scss']
})
export class RbaErrorMajeureComponent implements OnInit, OnDestroy {
  subscriptions = [];
  infoPersonne: InfoPersonne;
  originIndex: number;

  constructor(private readonly store: Store<GlobalState>,
    private readonly location: Location,
    private readonly dynamicScriptLoaderService: DynamicScriptLoaderService,
    public readonly headerOgiData: HeaderOgiData,) {

    this.dynamicScriptLoaderService.loadJahiaScript();
  }

  ngOnInit() {
    this.setOriginIndex();
    this.getInfoUserHolder();
  }

  redirect() {
    this.store.dispatch(new ClearError());
    this.location.back();
  }

  getInfoUserHolder(){
    this.subscriptions.push(
      selectAppInitialized(this.store).subscribe(selected => {
        this.infoPersonne = selected.infoClient;
      })
    );
  }

  setOriginIndex(){
    if(window.location.href.includes('consultation/prevoyance')){
      this.originIndex = 2;
    }
    else if(window.location.href.includes('consultation/epargne')) {
      this.originIndex = 0;
    }
    else if(window.location.href.includes('consultation/retraite')) {
      this.originIndex = 3;
    }
    else if(window.location.href.includes('consultation/cm')) {
      this.originIndex = 1;
    }
    else if(localStorage.getItem('dataSource').includes('prevoyance')) {
      this.originIndex = 2;
    }
    else if(localStorage.getItem('dataSource').includes('epargne')) {
      this.originIndex = 0;
    }
    else if(localStorage.getItem('dataSource').includes('retraite')) {
      this.originIndex = 3;
    }
    else if(localStorage.getItem('dataSource').includes('cm')) {
      this.originIndex = 1;
    }
  }

  retry() {
    window.location.reload();
  }

  ngOnDestroy() {
    console.log('rbaErrorMajeureComponent.ondestroy');
  }
}
