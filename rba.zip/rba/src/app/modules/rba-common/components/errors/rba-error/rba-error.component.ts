import { EventBusService, GenericErrorEvent } from '@ag2rlamondiale/metis-ng';
import { LEVEL_SEVERITY_MAJOR } from '@ag2rlamondiale/redux-api-ng';
import { HttpErrorResponse } from '@angular/common/http';
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { ErrorModel, ErrorType } from '@app/models/client/error.model';
import { PushError } from '@app/store/actions/ui.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-rba-error',
  templateUrl: './rba-error.component.html',
  styleUrls: ['./rba-error.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RbaErrorComponent implements OnInit, OnDestroy {

  errorModel: ErrorModel;
  sub: Subscription;
  constructor(private readonly store: Store<GlobalState>,
    private readonly eventBusService: EventBusService,
    private readonly cd: ChangeDetectorRef) { }

  ngOnInit() {
    this.cd.detach();
    this.sub = this.store.select('ui', 'error').subscribe(e => {
      this.errorModel = e;
      this.cd.detectChanges();
    });

    this.eventBusService.of(GenericErrorEvent).subscribe(event => {
      let errorType: ErrorType;
      if (event.cause instanceof HttpErrorResponse) {
        errorType = 'API';
      } else {
        errorType = 'FRONT';
      }
      if (/msie\s|trident\/|edge\//i.test(window.navigator.userAgent) && event.cause.message !== 'Demande d\'accès à la méthode ou aux propriétés inattendue.') {
        this.store.dispatch(new PushError({ error: event.cause, errorType, severity: LEVEL_SEVERITY_MAJOR }));
      }
    });
  }

  ngOnDestroy() {
    if (this.sub) {
      this.sub.unsubscribe();
    }
  }
}
