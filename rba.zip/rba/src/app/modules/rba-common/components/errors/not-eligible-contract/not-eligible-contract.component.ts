import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ClearError } from '@app/store/actions/ui.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-not-eligible-contract',
  templateUrl: './not-eligible-contract.component.html',
  styleUrls: ['./not-eligible-contract.component.scss']
})
export class NotEligibleContractsComponent implements OnInit {

  constructor(private readonly store: Store<GlobalState>, private readonly location: Location) {
  }

  ngOnInit() {
  }

  redirect() {
    this.store.dispatch(new ClearError());
    this.location.back();
  }

}
