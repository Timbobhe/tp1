import { Component, Input, OnInit } from '@angular/core';
import { ErrorModel } from '@app/models/client/error.model';
import { ClearError } from '@app/store/actions/ui.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Message } from 'primeng/primeng';
@Component({
  selector: 'app-rba-error-mineure',
  templateUrl: './rba-error-mineure.component.html',
  styleUrls: ['./rba-error-mineure.component.scss']
})
export class RbaErrorMineureComponent implements OnInit {

  @Input() errorModel: ErrorModel;

  msgs: Message[] = [];
  display = false;
  constructor(private readonly store: Store<GlobalState>) { }

  ngOnInit() {
    this.display = true;
    if (this.errorModel) {
      this.msgs = [];
      let resume = 'Erreur technique';
      if (this.errorModel.errorType === 'API') {
        resume = 'Erreur réseau';
      } else if (this.errorModel.errorType === 'FRONT') {
        resume = 'Erreur applicative';
      }
      this.msgs.push({
        severity: 'warn',
        summary: resume,
        detail:
          'En raison de maintenance technique, cette fonctionnalité est temporairement indisponible. Nous vous prions de nous en excuser.'
      });
    }
  }

  clearError() {
    this.msgs = [];
    this.store.dispatch(new ClearError());
  }
}
