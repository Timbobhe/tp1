import { Component, Input, OnInit } from '@angular/core';
import { ErrorModel } from '@app/models/client/error.model';
import { Message } from 'primeng/primeng';
@Component({
  selector: 'app-rba-error-moderee',
  templateUrl: './rba-error-moderee.component.html',
  styleUrls: ['./rba-error-moderee.component.scss']
})
export class RbaErrorModereeComponent implements OnInit {

  @Input() errorModel: ErrorModel;
  msgs: Message[] = [];
  display = false;

  constructor() { }

  ngOnInit() {
    this.display = true;
    if (this.errorModel) {
      this.msgs = [];
      let resume = 'Erreur technique';
      if (this.errorModel.errorType === 'API') {
        resume = 'Erreur réseau';
      } else if (this.errorModel.errorType === 'FRONT') {
        resume = 'Erreur applicative';
      }

      this.msgs.push({
        severity: 'warn',
        summary: resume,
        detail:
          'En raison de maintenance technique, cette fonctionnalité est temporairement indisponible. Nous vous prions de nous en excuser.'
      });
    }
  }

  retry() {
    window.location.reload();
  }

}
