import { Component, OnInit } from '@angular/core';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { distinctUntilKeyChanged, map } from 'rxjs/operators';

@Component({
  selector: 'app-rba-progress-bar',
  templateUrl: './rba-progress-bar.component.html',
  styleUrls: ['./rba-progress-bar.component.scss']
})
export class RbaProgressBarComponent implements OnInit {
  isLoading$: Observable<{ loading: boolean, value: number }>;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.isLoading$ = this.store.select('api').pipe(
      map(e => Object.assign({
          loading: e.alive > 0,
          value: e.alive <= 0 ? 100 : (100 / e.alive + 1)
        }
      )),
      distinctUntilKeyChanged('loading')
    );
  }
}
