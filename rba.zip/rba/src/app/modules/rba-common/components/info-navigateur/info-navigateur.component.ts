import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Component, Input, OnInit } from '@angular/core';

interface ReglesNavigateur {
  regles: Array<{ browser: string, versionMin: number }>;
}

const WARNING_DEFAULT: ReglesNavigateur = {
  regles: [
    {browser: 'CHROME', versionMin: 72},
    {browser: 'FIREFOX', versionMin: 64},
    {browser: 'IE', versionMin: 11}
  ]
};

@Component({
  selector: 'app-info-navigateur',
  templateUrl: './info-navigateur.component.html',
  styleUrls: ['./info-navigateur.component.scss']
})
export class InfoNavigateurComponent implements OnInit {
  @Input() show: boolean;
  title = 'Concernant votre navigateur';
  message = 'Afin de profiter d\'une expérience de navigation optimale,\n' +
    '                nous vous invitons à télécharger et utiliser la dernière version de votre navigateur.';

  private readonly reglesNavigateur: ReglesNavigateur;

  constructor(
    private readonly configService: ConfigService) {
    this.reglesNavigateur = this.configService.config.warning_navigator || WARNING_DEFAULT;
    this.reglesNavigateur.regles.forEach(r => r.browser = r.browser.toUpperCase());
  }

  ngOnInit() {
    try {
      this.show = this.showMessage(this.browserDetails());
    } catch (e) {
      console.error('Erreur à la récupération des informations du Browser', e);
    }
  }

  understand() {
    this.show = false;
  }


  browserDetails(): string {
    const userAgent: string = navigator.userAgent;
    let matchTest: RegExpMatchArray = userAgent.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [];

    let tem: RegExpMatchArray;

    if (/trident/i.test(matchTest[1])) {
      tem = /\brv[ :]+(\d+)/g.exec(userAgent) || [];
      return 'IE ' + (tem[1] || '');
    }

    if (matchTest[1] === 'Chrome') {
      tem = userAgent.match(/\b(OPR|Edge)\/(\d+)/);
      if (tem != null) {
        return tem.slice(1).join(' ').replace('OPR', 'Opera');
      }
    }

    matchTest = matchTest[2] ? [matchTest[1], matchTest[2]] : [navigator.appName, navigator.appVersion, '-?'];

    if ((tem = userAgent.match(/version\/(\d+)/i)) != null) {
      matchTest.splice(1, 1, tem[1]);
    }

    return matchTest.join(' ');
  }

  showMessage(browserDetails: string): boolean {
    const strings = browserDetails.split(' ');
    const browserName: string = strings[0].trim().toUpperCase();
    const browserVersion: number = Number(strings[1].trim());
    if (!!this.reglesNavigateur.regles.find(r => browserName.includes(r.browser) && browserVersion < r.versionMin)) {
      console.log('>> BROWSER : ' + browserDetails + ' => warning');
      return true;
    }
    console.log('>> BROWSER : ' + browserDetails + ' => ok');
    return false;
  }
}
