import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoNavigateurComponent } from './info-navigateur.component';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

class DummyConfigService {
  get config() {
    return {
      warning_navigator: {
        regles: [
          {browser: 'Chrome', versionMin: 72},
          {browser: 'Firefox', versionMin: 64},
          {browser: 'IE', versionMin: 12},
          {browser: 'Edge', versionMin: 18},
          {browser: 'Safari', versionMin: 12},
        ]
      }
    };
  }
}

describe('InfoNavigateurComponent', () => {
  let component: InfoNavigateurComponent;
  let fixture: ComponentFixture<InfoNavigateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InfoNavigateurComponent],
      providers: [{
        provide: ConfigService, useClass: DummyConfigService
      }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoNavigateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
