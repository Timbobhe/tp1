import { Component, OnInit } from '@angular/core';
import { selectProgressSprinner } from '@app/store/reducers/rba.selectors';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-rba-progress-spinner',
  templateUrl: './rba-progress-spinner.component.html',
  styleUrls: ['./rba-progress-spinner.component.scss']
})
export class RbaProgressSpinnerComponent implements OnInit {
  isLoading$: Observable<boolean>;
  constructor(private readonly store: Store<GlobalState>) { }

  ngOnInit() {
    this.isLoading$ = selectProgressSprinner(this.store);
  }
}
