import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { UrlService } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ORIGIN_MASTER } from '@app/consts/app.consts';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { GetAccessibilite } from '@app/store/actions/accessibilite.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-functionality-unauthorized',
  templateUrl: './functionality-unauthorized.component.html',
  styleUrls: ['./functionality-unauthorized.component.scss']
})
export class FunctionalityUnauthorizedComponent implements OnInit {
  fonctionnaliteType: FonctionnaliteType;
  functionalityTitle: string;
  raison: string;
  raisonMessage: string;
  isMonoEquipeMdpro = false;
  openTab = true;
  backgroundImageDesktop: string;
  backgroundImageMobile: string;
  jahiaDictionnary: string;
  jahiaContext: Map<string, string>;
  functionality: string;
  showReturnBtn = false;
  labelRetourAcceuil = 'LABEL_RETOUR_ACCUEIL';
  mdproAnnonceRedirect = 'MESSAGE_MDPRO_ESPACE_SOCIETAIRE';
  mdproLabelEspaceSocietaire = 'LABEL_MDPRO_ESPACE_SOCIETAIRE';
  subscriptions: Subscription[] = [];
  defaultRaisonMessage: string = "MODIFIERRIB_ACCESS_DENIED";

  constructor(
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly configService: ConfigService,
    private readonly store: Store<GlobalState>,
    private readonly urlService: UrlService) {
  }

  ngOnInit() {
    this.showReturnBtn = !this.urlService.isFrame;
    this.subscriptions.push(this.store.select('accessibilite').subscribe(data => {
      if ( !data || data.isFetched === false) {
        this.functionality = this.activeRoute.snapshot.paramMap.get('functionality');
        this.fonctionnaliteType = 'VosCoordonneesBancaires';
        this.functionalityTitle = FunctionalityTitle[this.fonctionnaliteType];
        this.jahiaDictionnary = DictionnaryFunctionalityMessage[this.fonctionnaliteType];
        this.raisonMessage = this.defaultRaisonMessage;
        this.getBackgroundImage(this.fonctionnaliteType);
        this.switchOrigin();
      } else {
        this.fonctionnaliteType = data.accesFonctionnaliteModel.fonctionnaliteType;
        this.functionalityTitle = FunctionalityTitle[this.fonctionnaliteType];
        if (this.raison === 'DEFAULT_BLOCAGE_CONSOLE') {
          this.jahiaDictionnary = 'dictionnaireCommonAppMessagesDictionnaire';
        } else {
          this.jahiaDictionnary = DictionnaryFunctionalityMessage[this.fonctionnaliteType];
        }
        this.raison = data.accesFonctionnaliteModel.raison;
        this.jahiaContext = data.accesFonctionnaliteModel.jahiaContext;
        this.isMonoEquipeMdpro = this.raison === 'BLOCAGE_BIA_MONO_EQUIPE_MDPRO';
        this.raisonMessage = this.raison;
        this.getBackgroundImage(this.fonctionnaliteType);
      }
    }));
  }

  backToSynthese() {
    //TODO à changer
    this.router.navigate(['coordonnees-bancaires']);
  }

  switchOrigin(){
    if(window.location.href.includes('consultation/epargne')){
      this.store.dispatch(new GetAccessibilite(this.functionality, ORIGIN_MASTER.EPARGNE));
    }
    else if(window.location.href.includes('consultation/cm')){
      this.store.dispatch(new GetAccessibilite(this.functionality, ORIGIN_MASTER.CM));
    }
    else if(window.location.href.includes('consultation/prevoyance')){
      this.store.dispatch(new GetAccessibilite(this.functionality, ORIGIN_MASTER.PREVOYANCE));
    }
    else if(window.location.href.includes('consultation/retraite')){
      this.store.dispatch(new GetAccessibilite(this.functionality, ORIGIN_MASTER.RETRAITE_SUPPLEMENTAIRE));
    }
  }

  redirectToEspaceSocietaire() {
    if (this.openTab) {
      window.open(this.configService.config['espace_societaire_endpoint']);
    }
  }

  getBackgroundImage(fonctionnalite: FonctionnaliteType) {
  if (fonctionnalite === 'VosCoordonneesBancaires') {
      this.backgroundImageDesktop = '--coordonnees-bancaires-desktop-url';
      this.backgroundImageMobile = '--coordonnees-bancaires-mobile-url';
    }
  }
}

export enum FunctionalityTitle {
  VosCoordonneesBancaires = 'TITLE_MODIFICATION_COORDONEES_BANCAIRES',
}

export enum DictionnaryFunctionalityMessage {
  VosCoordonneesBancaires = 'dictionnaireCoordonneesBancaires',
}
