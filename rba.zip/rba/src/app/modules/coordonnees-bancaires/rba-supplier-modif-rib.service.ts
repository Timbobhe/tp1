import { CoodonneesBancairesUiConfig, SupplierModifRibService } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RbaSupplierModifRibService extends SupplierModifRibService {

  versementProgrammeRoute(): string {
    return '/coordonnees-bancaires';
  }

  versementSyntheseRoute(): string {
    return '/coordonnees-bancaires';
  }

  //TODO à mettre false
  uiConfig(): CoodonneesBancairesUiConfig {
    return {activeVersementSyntheseRoute: false, activeVersementProgrammeRoute: false};
  }
}