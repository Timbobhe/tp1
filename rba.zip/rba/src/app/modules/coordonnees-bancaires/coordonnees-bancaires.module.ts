import { CoordonneesBancairesModule as LibCoordonneesBancairesModule, SupplierModifRibService } from '@ag2rlamondiale/transverse-metier-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RbaSupplierModifRibService } from './rba-supplier-modif-rib.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    LibCoordonneesBancairesModule
  ],
  exports: [
    LibCoordonneesBancairesModule
  ],
  providers: [
    {provide: SupplierModifRibService, useClass: RbaSupplierModifRibService}
  ]
})
export class CoordonneesBancairesModule { }
