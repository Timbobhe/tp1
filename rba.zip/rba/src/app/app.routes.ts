import { RouterModule, Routes } from "@angular/router";
import { AuthBlocageConsole } from './authguards/auth-blocage-console.guard';
import { AuthLoginCas } from './authguards/auth-login.guard';
import { CoordonneesBancairesGuard } from './authguards/coordonneesBancaires.guard';
import { COORDONNEES_BANCAIRES } from './consts/fonctionnalites.const';
import { FunctionalityUnauthorizedComponent } from './modules/functionality-unauthorized/functionality-unauthorized.component';


export const ROUTES: Routes = [
  {
    path: '',
    canActivate: [AuthLoginCas],
    canActivateChild: [AuthBlocageConsole],
    children: [
      {
        path: 'coordonnees-bancaires',
        loadChildren: './modules/coordonnees-bancaires/coordonnees-bancaires.module#CoordonneesBancairesModule',
        data: { id: [COORDONNEES_BANCAIRES] },
        canActivate: [CoordonneesBancairesGuard]
      },
      {
        path: 'fonctionnalite-inaccessible',
        component: FunctionalityUnauthorizedComponent
      },
      { path: "**", redirectTo: "coordonnees-bancaires", pathMatch: "full" }
    ]
  }
]

export const routing = RouterModule.forRoot(ROUTES, { useHash: true });
