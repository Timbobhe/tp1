import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { INIT_APP } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { GetClientInfos } from '@app/store/actions/client-infos.actions';
import { ContratsAssureFetch } from '@app/store/actions/contrats-assure.actions';
import { TrackingInfoFetch } from '@app/store/actions/tracking.action';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { environment } from 'environments/environment';
import { switchMap } from 'rxjs/operators';
import { AqeaCache } from '../actions/aqea-cache.actions';

@Injectable({
  providedIn: 'root'
})
export class RbaEffects {

  constructor(
    private readonly actions$: Actions,
    private readonly jahia: JahiaService,
    private readonly config: ConfigService) {
  }

  @Effect({dispatch: true})
  initApp$ = this.actions$.pipe(
    ofType(INIT_APP),
    switchMap(() => [
      environment.mock ? this.jahia.loadStateRemoteAction() : {type: 'NOOP'},
      new TrackingInfoFetch(),
      new GetClientInfos(),
      new ContratsAssureFetch(),
      this.config.getConfig().tc_vars.env_work !== 'localhost' ? new AqeaCache() : {type: 'NOOP'}
    ])
  );
}
