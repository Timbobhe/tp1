import { ClearToastMessage, InitApp, PushToastMessage } from '@ag2rlamondiale/transverse-metier-ng';
import { ErrorModel } from '@app/models/client/error.model';
import { Action } from '@ngrx/store';
import { TrackingActionPayload } from './tracking.action';

export const PUSH_ERROR = '[UI]_PUSH_ERROR';
export const CLEAR_ERROR = '[UI]_CLEAR_ERROR';
export const UPDATE_ORIGIN = '[UI]_UPDATE_ORIGIN';

export class PushSelectedCompartimentPayload extends TrackingActionPayload {
  compartimentSelected: string;
}

export class PushSelectedActionPayload extends TrackingActionPayload {
}

export class PushError implements Action {
  type = PUSH_ERROR;

  constructor(public payload: ErrorModel) {
  }
}

export class ClearError implements Action {
  type = CLEAR_ERROR;

  constructor(public payload = null) {
  }
}

export class PushTourStepPayload {
  stepOrder: number;
}

export class UpdateOriginAction implements Action {
  readonly type = UPDATE_ORIGIN;
  constructor(public payload = null) {
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions =
  InitApp
  | PushError
  | ClearError
  | PushToastMessage
  | UpdateOriginAction
  | ClearToastMessage;
