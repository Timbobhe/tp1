import { ChainAction, ExecuteAction, ResetStateAction as BaseResetStateAction, RESET_STATE } from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@app/store/reducers/_index';

export { RESET_STATE };

export class ResetStateAction extends BaseResetStateAction<GlobalState> {
}

export type Actions = ChainAction | ExecuteAction | ResetStateAction;


