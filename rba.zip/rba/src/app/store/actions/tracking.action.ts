import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import * as base from '@ag2rlamondiale/transverse-metier-ng';
import { SetTrackingEnvTemplate, TrackingActionPayload, TRACKING_INFO_FETCH } from '@ag2rlamondiale/transverse-metier-ng';
import { TrackingInfo } from '@app/models/client/tracking.model';

export { TrackingActionPayload, SetTrackingEnvTemplate };


export enum Categorie {
  coordonneesBancaires = 'MDP_coordonnees_bancaires',
}

export enum TypeOriginAction {
  coordonneesBancaires_modification = 'demande-modification',
  coordonneesBancaires_confirmation = 'confirmation-modification',

  clic = 'clic',
  erreurTechnique = 'erreur-technique',
}


export function tracking(
  tc_category: Categorie | string,
  tc_action: TypeOriginAction | string,
  tc_label: string = null,
  by_user = true) {
  return base.tracking<Categorie | string, TypeOriginAction | string>(tc_category, tc_action, tc_label, by_user);
}


export class TrackingInfoFetch extends ApiAction<TrackingInfo> {
  constructor() {
    super(TRACKING_INFO_FETCH, 'backend/trackingInfo', null);
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = TrackingInfoFetch | base.SetTrackingEnvTemplate | ApiActions;
