import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { Contrat, ContratId } from '@app/models/client/contrat.model';
import { GetContrat } from './common.actions';
export const CONTRAT_ASSURE_FETCH = '[CONTRAT_ASSURE]_FETCH';

export class ContratsAssureFetch extends GetContrat<Array<Contrat>> {

  constructor() {
    super(CONTRAT_ASSURE_FETCH, 'backend/contratsAssures', null);
    this.payload.transcoder = this.transcode.bind(this);
  }

  transcode(data: any) {
    if (Array.isArray(data)) {
      return data.map(e => Object.assign(new Contrat(), e));
    }
    return data;
  }

}

export class GestionFinancierePayload {
  contratId: ContratId;
  fonctionnalite: FonctionnaliteType;
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = ContratsAssureFetch | ApiActions;