import { storeApiLogger } from '@ag2rlamondiale/redux-api-ng';
import { coordonneesBancairesReducer, coordonneesClientReducer, identitenumReducer, identNumMatchAccountReducer, navigationReducer, sigElecReducer, trackingReducer, TransverseMetierState } from '@ag2rlamondiale/transverse-metier-ng';
import { environment } from '@app/../environments/environment';
import { routerReducer } from '@ngrx/router-store';
import { ActionReducer, ActionReducerMap, MetaReducer } from '@ngrx/store';
import { accessibiliteReducer, AccessibiliteState } from './accessibilite.reducer';
import { clientInfosReducer, ClientInfoState } from './client-infos.reducer';
import { ContratAssureState, contratsAssureReducer } from './contrats-assure.reducer';
import { evenReducer, EvenState } from './evenement.reducer';
import { uiReducer, UiState } from './ui.reducer';

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente le State global.
 */
export interface GlobalState extends TransverseMetierState {
  clientInfos: ClientInfoState;
  contratsAssure: ContratAssureState;
  ui: UiState;
  evenement: EvenState;
  accessibilite: AccessibiliteState;
}

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente l ensemble des reducers.
 */
export const reducers: ActionReducerMap<GlobalState> = {
  navigation: navigationReducer,
  router: routerReducer,
  tracking: trackingReducer,
  coordonneesClient: coordonneesClientReducer,
  identNumMatchAccount: identNumMatchAccountReducer,
  identiteNum: identitenumReducer,
  sigElec: sigElecReducer,
  coordonneesBancaires: coordonneesBancairesReducer,
  clientInfos: clientInfosReducer,
  contratsAssure: contratsAssureReducer,
  ui: uiReducer,
  evenement: evenReducer,
  accessibilite: accessibiliteReducer,

};

export function logger(reducer: ActionReducer<GlobalState>): ActionReducer<GlobalState> {
  return storeApiLogger(reducer);
}

export const metaReducers: MetaReducer<any>[] = !environment.production ? [logger] : [];
