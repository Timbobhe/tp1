import { ActionTester, ApiAction, ApiActionPayload } from '@ag2rlamondiale/redux-api-ng';
import { acceptUiAction, ActionWithPayload, baseUiReducer, BaseUiState } from '@ag2rlamondiale/transverse-metier-ng';
import { ErrorModel } from '@app/models/client/error.model';
import * as ui from '@app/store/actions/ui.actions';

export class UiState extends BaseUiState {
  error: ErrorModel = null;
  stackCalls = [];
  origin: String;
}

const initialState = new UiState();

// NOSONAR
export function uiReducer(state: UiState = initialState, action: ui.Actions | ApiAction): any {
  if (acceptUiAction(action)) {
    return baseUiReducer(state, action);
  }

  const apiTester = new ActionTester(action);

  if (action.type === ui.PUSH_ERROR) {
    const p = action.payload as ErrorModel;
    return Object.assign(new UiState(), {...state, error: p});
  }

  if (action.type === ui.CLEAR_ERROR) {
    return Object.assign(new UiState(), {...state, error: null});
  }

  if (apiTester.isError()) {
    const ap = action.payload as ApiActionPayload<any>;
    let severite = ap.severity;
    if (state.error != null && state.error.severity <= severite) {
      severite = state.error.severity;
    }
    return Object.assign(new UiState(), {...state, error: {error: ap.error, severity: severite, errorType: 'API'}});
  }

  if (action.type === ui.UPDATE_ORIGIN) {
    return Object.assign(new BaseUiState(), {...state, origin:action.payload, toastMessages: []});
  }

  return handleSpinner(state, action);
}

function handleSpinner(state: UiState = initialState, action: ActionWithPayload) {
  const apiTester = new ActionTester(action);
    if (apiTester.isStart()) {
      let newStack = [];
      newStack = state.stackCalls;
      if (newStack.indexOf(action.payload.label) === -1) {
        newStack.push(action.payload.label);
      }
      return Object.assign(new UiState(), {...state, stackCalls: newStack});
    }
    if (apiTester.isEnd()) {
      let newStack = [];
      newStack = state.stackCalls;
      if (newStack.indexOf(action.payload.label) > -1) {
        newStack.splice(newStack.indexOf(action.payload.label), 1);
      }
      return Object.assign(new UiState(), {...state, stackCalls: newStack});
    }
  return state;
}
