import { CoordonneesBancairesState, selectRouter, UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';
import { RouterReducerState } from '@ngrx/router-store';
import { createSelector, select } from '@ngrx/store';
import { pipe } from 'rxjs';
import { distinctUntilChanged, filter, map } from 'rxjs/operators';
import { ClientInfoState } from './client-infos.reducer';
import { UiState } from './ui.reducer';
import { GlobalState } from './_index';

export const selectInfoClient = (state: GlobalState) => state.clientInfos;

export const selectUi = (state: GlobalState) => state.ui;

export const selectUiError = (state: GlobalState) => state.ui.error;

export const selectBasicEvenement = (state: GlobalState) => state.evenement;

export const selectCoordonneesBancaires = (state: GlobalState) => state.coordonneesBancaires;


function shouldShowSpinnerIframe(x): boolean {
  return !!UrlUtils.getSearchParam('frame') && isFunctionalityLoading(x);
}

function isFunctionalityLoading(x) {
  return (
    (x.router.state.url.startsWith('/bulletin-affiliation') && x.bia.isFetched === false) ||
    (x.router.state.url.startsWith('/clause-beneficiaire') && x.cbf.isFetched === false) ||
    (x.router.state.url.startsWith('/modification-gestion-financiere') && x.arbitrage.isFetched === false)
  );
}

// Retourne un EVN à l'Observable si l'appli est initialisée
export const selectAppInitialized = pipe(
  select(
    createSelector(selectInfoClient, selectUiError, (infoClient: ClientInfoState) => {
      if (!infoClient || !infoClient.isFetched) {
        return null;
      }

      return { infoClient };
    })
  ),
  filter(x => !!x),
  distinctUntilChanged()
);

export const selectEvenement = pipe(
  select(
    createSelector(selectInfoClient, selectBasicEvenement, (infoClient, even) => {
      if (!infoClient || !infoClient.isFetched || infoClient.impersonation) {
        return null;
      }
      return even;
    })
  ),
  filter(x => !!x)
);

export const selectProgressSprinner = pipe(
  select(
    createSelector(
      selectUi,
      selectRouter,
      selectCoordonneesBancaires,
      (
        ui: UiState,
        router: RouterReducerState,
        cb: CoordonneesBancairesState
      ) => {
        return { ui, router,cb};
      }
    )
  ),
  map(
    x =>
      x.ui.initializing &&
      (!x.ui.error || x.ui.error.severity === 2) &&
      (shouldShowSpinnerIframe(x)|| (x.router.state.url === '/coordonnees-bancaires/consultation' && x.cb.isFetched === false))
  )
);
