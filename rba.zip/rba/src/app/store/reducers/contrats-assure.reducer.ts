import * as ApiAction from '@ag2rlamondiale/redux-api-ng';
import { Contrat } from '@app/models/client/contrat.model';
import * as ContratAssure from '@app/store/actions/contrats-assure.actions';

export class ContratAssureState {
  contratsAssure: Contrat[] = [];
  idDernierContratERE: string = null;
  isFetched = false;
}

const initialState = new ContratAssureState();

export function contratsAssureReducer(state: ContratAssureState = initialState, action: ContratAssure.Actions) {
  if (action.type === ApiAction.API_SUCCESS && action.payload.label === ContratAssure.CONTRAT_ASSURE_FETCH) {
    const model: Contrat[] = action.payload.data;


    // return new instance du state => le state doit etre Immutable
    return Object.assign(new ContratAssureState(), {contratsAssure: model, isFetched: true});
  }

  return state;
}
