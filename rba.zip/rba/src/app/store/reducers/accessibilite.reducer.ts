import { AccesFonctionnaliteModel } from '@app/models/client/acces-fonctionnalite.model';
import * as accessibiliteActions from '@app/store/actions/accessibilite.actions';


export class AccessibiliteState {
  accesFonctionnaliteModel: AccesFonctionnaliteModel;
  isFetched = false;
}

const initialState = new AccessibiliteState();

export function accessibiliteReducer(state: AccessibiliteState = initialState,
  action: accessibiliteActions.Actions) {

  if (action.type === accessibiliteActions.PUSH_ACCESSIBILITE) {
    const data = action.payload;

    return Object.assign(new AccessibiliteState(), { accesFonctionnaliteModel: data, isFetched: true });
  }

  return state;
}
