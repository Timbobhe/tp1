import * as ApiAction from '@ag2rlamondiale/redux-api-ng';
import { BaseClientInfoState } from '@ag2rlamondiale/transverse-metier-ng';
import { InfoPersonne } from '@app/models/client/info.client.model';
import * as ClientInfosActions from '@app/store/actions/client-infos.actions';
import { select } from '@ngrx/store';
import { pipe } from 'rxjs';
import { filter } from 'rxjs/operators';

export const selectClientInfos = pipe(
  select('clientInfos'),
  filter(clientInfos => clientInfos && clientInfos.isFetched)
);

export class ClientInfoState extends InfoPersonne implements BaseClientInfoState {
  isFetched = false;
}

const initialState = new ClientInfoState();
initialState.nom = 'nom';
initialState.prenom = 'prenom';

export function clientInfosReducer(state: ClientInfoState = initialState, action: ClientInfosActions.Actions): any {
  if (action.type === ApiAction.API_SUCCESS && action.payload.label === ClientInfosActions.GET_CLIENT_INFOS) {
    return new ClientInfoState().fromObject({...action.payload.data, isFetched: true});
  }
  return state;
}
