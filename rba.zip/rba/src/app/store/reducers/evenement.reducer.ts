import { ActionTester } from '@ag2rlamondiale/redux-api-ng';
import { Evenement } from '@app/models/client/evenement.model';
import * as evenement from '@app/store/actions/evenement.actions';


export class EvenState {
  isFetched = false;
  even: Evenement;
  enTraitement = false;
  loading = false;
}

const initialState = new EvenState();

export function evenReducer(state: EvenState = initialState, action: evenement.Actions) {
  const tester = new ActionTester(action);
  if (tester.isLoading(evenement.EVEN_GET_NEXT)) {
    const aegn = action as evenement.GetNextEven;
    const ds = aegn.payload.dataStatus;
    return Object.assign(new EvenState(), { even: ds.data, isFetched: ds.fetched, loading: ds.loading });
  }

  if (tester.isSuccess(evenement.EVEN_CANCEL)) {
    return Object.assign(new EvenState(), { even: null, isFetched: true, loading: false, enTraitement: false });
  }

  return state;
}
