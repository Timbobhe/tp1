import { DynamicScriptLoaderService, HeaderOgiData } from '@ag2rlamondiale/ag2rlm-lib';
import { PartenaireInfo, selectCoordonneesBancaires, ThemeService, ThemeType, UrlService, UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, OnDestroy, OnInit } from "@angular/core";
import { Store } from '@ngrx/store';
import { InfoPersonne } from './models/client/info.client.model';
import { selectAppInitialized, selectUiError } from './store/reducers/rba.selectors';
import { GlobalState } from './store/reducers/_index';


@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit, OnDestroy {
  subscriptions = [];
  display = false;
  infoPersonne: InfoPersonne;
  hasMajorError: boolean;
  routerActivate = false;
  originIndex: number;
  setParcours: string;
  hasPrincipalContracts: boolean = true;

  constructor(
    private readonly store: Store<GlobalState>,
    public readonly urlService: UrlService,
    private readonly themeService: ThemeService,
    private readonly dynamicScriptLoaderService: DynamicScriptLoaderService,
    public readonly headerOgiData: HeaderOgiData

  ) {
    this.dynamicScriptLoaderService.loadJahiaScript();
  }

  ngOnInit() {
    this.setOriginIndex();
    this.getData();
  }

  setOriginIndex(){
    if(window.location.href.includes('consultation/prevoyance')){
      this.originIndex = 2;
    }
    else if(window.location.href.includes('consultation/epargne')) {
      this.originIndex = 0;
    }
    else if(window.location.href.includes('consultation/retraite')) {
      this.originIndex = 3;
    }
    // out of range: on selectionne aucun onglet dans le cas des contrats cm
    else if(window.location.href.includes('consultation/cm')) {
      this.originIndex = 1;
    }
    else if(localStorage.getItem('dataSource').includes('prevoyance')) {
      this.originIndex = 2;
    }
    else if(localStorage.getItem('dataSource').includes('epargne')) {
      this.originIndex = 0;
    }
    else if(localStorage.getItem('dataSource').includes('retraite')) {
      this.originIndex = 3;
    }
    else if(localStorage.getItem('dataSource').includes('cm')) {
      this.originIndex = 1;
    }
  }

  getData(){
    this.subscriptions.push(
      selectAppInitialized(this.store).subscribe(selected => {
        this.infoPersonne = selected.infoClient;
        const isFilialeAcaFlag = this.infoPersonne.filialeACA;
        this.selectTheme(this.infoPersonne.partenaire, isFilialeAcaFlag);
        this.display = this.checkPartnerInUrl(this.infoPersonne.partenaire);
      }),
      this.store.select(selectUiError).subscribe(e => {
        if (e && e.error) {
          this.hasMajorError = e.severity === 0;
        } else {
          this.hasMajorError = false;
        }
      }),
      this.store.select(selectCoordonneesBancaires).subscribe(e => {
        if (e && e.data) {
          if(e.data.coordonneesBancairesMetierPrincipal.length == 0){
            this.hasPrincipalContracts = false;
          } else {
            this.hasPrincipalContracts = true;
          }
        }
      }),
    );
  }
  checkPartnerInUrl(partner: PartenaireInfo): boolean {
    const partenaireFromUrl: string = UrlUtils.getSearchParam('fdi');
    if (partner && partner.codePartenaire !== partenaireFromUrl) {
      UrlUtils.setSearchParam('fdi', partner.codePartenaire);
      return false;
    }
    if (!partner && partenaireFromUrl) {
      UrlUtils.deleteSearchParam('fdi');
      return false;
    }
    return true;
  }

  selectTheme(partenaire: PartenaireInfo, isFilialeAcaFlag: boolean) {
    let theme: ThemeType;
    const codePartenaire = partenaire ? partenaire.codePartenaire : '';
    if (codePartenaire === '49504') {
      theme = 'adding';
    } else if (codePartenaire === '49505') {
      theme = 'nie';
    } else {
      theme = 'ag2r';
    }
    this.themeService.changeTheme(theme, isFilialeAcaFlag ? 'aca' : 'ag2r');
  }

  onRouterActivate() {
    this.routerActivate = true;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
