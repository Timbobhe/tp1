import { TrackingConfig } from '@ag2rlamondiale/transverse-metier-ng';
import { Categorie } from '@app/store/actions/tracking.action';


/**
 * --- EVENT : pageview ----
 */
export const TC_VARS = [
  {
    path: '/coordonnees-bancaires',
    vars: {
      client_profil: 'particuliers'
    },
    children: [
      {
        path: 'consultation',
        vars: {
          notag: false,
          form_step: 'consultation'
        }
      },
      {
        path: 'modification',
        vars: {
          notag: false,
          form_step: 'modification'
        }
      },
      {
        path: 'verification-donnees-personnelles',
        vars: {
          notag: false,
          form_step: 'verification'
        }
      },
    ]
  }
];


/**
 * --- EVENT : eventGA ----
 */
export const TC_CATEGORY_URL = [
  {
    path: '/coordonnees-bancaires',
    vars: {
      category: Categorie.coordonneesBancaires
    }
  }
];

export const RbaTrackingConfig: TrackingConfig = {
  appNameContext: '/epargne_mdpro',
  varsPath: TC_VARS,
  categoriesPath: TC_CATEGORY_URL
};
