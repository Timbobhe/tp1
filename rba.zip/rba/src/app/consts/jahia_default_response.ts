import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { JahiaModel } from '../models/jahia.model';

const LABEL = 'Votre espace client';

export function getJahiaResponse(configService: ConfigService): JahiaModel {
  return {
    headerAg2r: {
      title: {
        image: {
          alt: 'AG2R LA MONDIALE',
          url: configService.config['jahia_ressources_logos_root'].concat('logo-ag2r-la-mondiale.png'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('logo-ag2r-la-mondiale-mobile.png'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerArialCNP: {
      title: {
        image: {
          alt: 'ARIAL CNP ASSURANCES',
          url: configService.config['jahia_ressources_logos_root'].concat('logo-arial-cnp-ag2r.png'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('logo-arial-cnp-ag2r-mobile.png'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    coordonneesBancairesImage: {
      alt: 'CoordonneesBancaires',
      url: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-mobile.jpg'),
      urlToRedirect: null
    }
  };
}
