export const COORDONNEES_BANCAIRES = 'VosCoordonneesBancaires';
export const MODIF_RIB = 'ModifierRIB';

export type FonctionnaliteType = 'VosCoordonneesBancaires';

export const FonctionnaliteLabel: Partial<{ [k in FonctionnaliteType]: string }> = {
  'VosCoordonneesBancaires': 'Vos coordonnées bancaires'
};

export const fonctionnalites: { [k in FonctionnaliteType]: FonctionnaliteType } = {
  VosCoordonneesBancaires: 'VosCoordonneesBancaires',
};
