import { AppConfig } from '@ag2rlamondiale/transverse-metier-ng';

export const featureMap = {
  RIBA: {
    libelle: 'coordonnées bancaires',
    dico: 'dictionnaireCoordonneesBancaires',
    image: '--coordonnees-bancaires-mobile-url'
  },
};

export const AppConfiguration: AppConfig = {
  homeRoute: '/coordonnees-bancaires',
  featureMap: featureMap
};

export const ORIGIN_MASTER = {
  RETRAITE_SUPPLEMENTAIRE: 'RETRAITE_SUPPLEMENTAIRE',
  EPARGNE: 'EPARGNE',
  CM: 'CM',
  PREVOYANCE: 'PREVOYANCE',
}
