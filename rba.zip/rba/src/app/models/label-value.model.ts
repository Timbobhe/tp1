export class LabelValueModel {
  public label = '';
  public value = '';

  constructor(label: string, value: string) {
    this.label = label;
    this.value = value;
  }
}
