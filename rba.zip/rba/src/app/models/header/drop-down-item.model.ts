export class DropDownItem {
    title: string;
    urlToRedirect: string;
    selectionColor: string;
    cssClassName: string;
}
