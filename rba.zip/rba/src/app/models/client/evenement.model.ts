export class TypeEvenement {
  codeEvenement: string;
  categorie: CategorieEvenement;
  ordre: number;
  dateDebut?: Date;
  dateFin?: Date;
  nbDeclenchementsMaxPeriode: number;
  periodeDeclenchement?: any;
  delaiAvantReactivation?: any;
  modeAction: string;
  titre: string;
  contenu: string;
  actionTraiter: string;
  actionAnnuler?: any;
  lienRedirection: string;
  perimetreEvenements: any[];
  libEvenement: string;
  dirty: boolean;
}

export class CategorieEvenement {
  codeCategorie: string;
  codeApplication: string;
  ordre: number;
  description: string;
}


export type EtatTraitement = 'TRAI' | 'ANNU';

export class Evenement {
  id?: any;
  typeEvenement: TypeEvenement;
  idGdi: string;
  numContrat?: any;
  etatTraitement?: EtatTraitement;
  dateDebut: Date;
  dateFin?: Date;
}
