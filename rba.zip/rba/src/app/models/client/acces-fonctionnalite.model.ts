import { ContratId } from './contrat.model';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
export class AccesFonctionnaliteModel {
  fonctionnaliteType: FonctionnaliteType;
  accessible: boolean;
  raison: string;
  jahiaContext: Map<string, string>;
  details: Array<DetailAccesFonctionnalite>;
}

export class DetailAccesFonctionnalite {
  contrat: ContratId;
  accessible: boolean;
  raison: string;
}

