import { Image } from '@app/models/header/image.model';
import { HeaderModel } from './header/header.model';

export class JahiaModel {
  headerAg2r: HeaderModel;
  headerArialCNP: HeaderModel;
  coordonneesBancairesImage: Image;
}
