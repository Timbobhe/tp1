/**
 * Malgré les apparences les clés des PATH (contrib, dico, questionResponse, ressources) doivent être globalement unique.
 */
import { JahiaConfig } from '@ag2rlamondiale/jahia-ng';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

const PATHS = {
  common: {
    contribsPath: {
      'MA_DEMANDE_TITRE_ETAPES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=ma_demande_etapes_titre&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CONFIRMER_COORDONNEES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_confirmer_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_VALIDER_IDENTITE_NUM': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_valider_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MAJ_COORDONNEES_SIDE': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_update_coordonnees_side_component&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireCommon: '/sites/aqe/ecrs/shared/body-content/dictionnaireshared.apiDico.html.ajax',
      dictionnaireCommonAppMessagesDictionnaire: '/sites/aqe/ecrs/body-content/dictionnairecommonappmessages.apiDico.html.ajax',
    }
  },

  coordonneesBancaires: {
    contribsPath: {
      'CONTENU_RIB_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=contenu_rib_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'TITLE_MODIFICATION_COORDONEES_BANCAIRES': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=title_modification_coordonees_bancaires&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MDPRO': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MDPRO&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MULTI_EQUIPE': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=SUBTITLE_MODIFICATION_COORDONEES_BANCAIRES_MULTI_EQUIPE&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      dictionnaireCoordonneesBancaires: '/sites/aqe/ecrs/coordonneesbancaires/head-content/dictionnairecoordonneesbancaires.apiDico.html.ajax'
    }
  },

  prevalidation: {
    contribsPath: {
      'CONTENU_PREVALIDATION_DEMANDE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identite_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_SIGN_MANU': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_signature_manuscrite&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_DONNEES_PERSO': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=saisirdonneesPerso&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_IDENTITE_NUM': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identite_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_MODIF_DONNEES': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_identiteNum_modif_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VOUS_PROTEGER': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=identite_Num_Vous_Proteger&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_PIECE_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_piece_identite&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VOTRE_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_votre_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_UPLOAD': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_indications_upload&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VERIFIER_DONNEES': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_verifier_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_PREVALIDATION_VERIFIER_IDENTITE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_prevalidation_verifier_identite&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    },

    dictionnariesPath: {
      dictionnairePrevalidation: '/sites/aqe/ecrs/identitenum/body-content/dictionnaireidentitenum.apiDico.html.ajax',
    }
  },

  identiteNum: {
    contribsPath: {
      'CONTENU_DONNEES_PERSO_INCOHERENTS': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=donneesPersoIncoherents&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_EMAIL_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_email_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MODIF_DONNEES_TEL_AG2R': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_modifier_coordonnees_tel_ag2r&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_EMAIL_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_email_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_REINIT_DONNEES_TEL_PRESTATAIRE': '/sites/aqe/ecrs/identitenum/body-content.apiV2.html.ajax?blockId=contenu_reinitialiser_coordonnees_tel_prestataire&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    }
  },

  evenements: {
    contribsPath: {
      'ERE_BIA': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_CONF': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_conf&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_PND_3': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_3&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_PND_1': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_1&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_VDPP': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_vdpp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'ERE_INFO': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_info&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      eventDictionnaireDeLibelles: '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content/eventdictionnairedelibelles.apiDico.html.ajax',
    }
  },

  shared: {
    contribsPath: {
      'MA_DEMANDE_TITRE_ETAPES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=ma_demande_etapes_titre&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_CONFIRMER_COORDONNEES': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_confirmer_coordonnees&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_VALIDER_IDENTITE_NUM': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_valider_ident_num&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'CONTENU_MAJ_COORDONNEES_SIDE': '/sites/aqe/ecrs/shared/body-content.apiV2.html.ajax?blockId=contenu_update_coordonnees_side_component&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },
    dictionnariesPath: {
      dictionnaireCommon: '/sites/aqe/ecrs/shared/body-content/dictionnaireshared.apiDico.html.ajax'
    }
  }
};

const CONTRIBS_PATH = {};
const QUESTIONS_REPONSES_PATH = {};
const DICTIONNAIRES_PATH = {};

export function cleanContentHtml(
  html: string,
  jahiaConfig: JahiaConfig,
  configService: ConfigService): string {
  if (!html) {
    return null;
  }

  // suppression <jahia:resource>
  // transformation lien adapter à Angular (1)
  const href1 = /#(\w.+):(\w.+)/gm;
  // transformation lien adapter à Angular (2)
  const href2 = /#(\w.+):/gm;

  // Correction des url localhost
  const jahia_files_host = configService.config[jahiaConfig.jahiaFiles];
  const defaultHost = /^(https?:)?\/\/localhost(:\d+)?(\/.+)/;

  const parser = new DOMParser();
  const parsedHtml = parser.parseFromString(html, 'text/html');

  const anchors = parsedHtml.getElementsByTagName('a');
  for (let i = 0; i < anchors.length; i++) {

    let tmpHref = liensEnSavoirPlus(anchors[i]);

    // Correction des URL localhost
    tmpHref = tmpHref.replace(defaultHost, `$3`);

    anchors[i].href = tmpHref;
  }

  // Correction des URL des images
  for (let i = 0; i < parsedHtml.images.length; i++) {
    const tmpSrc = parsedHtml.images[i].src.replace(defaultHost, `${jahia_files_host}$3`);
    parsedHtml.images[i].src = tmpSrc;
  }

  return parsedHtml.documentElement.innerHTML;
}

function liensEnSavoirPlus(anchor: any): string {
  let tmpHref = anchor.href;
  if (tmpHref.includes('Lexique')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/lexique';
  } else if (tmpHref.includes('ListeArticles') || anchor.innerText.includes('Voir tous nos articles et dossiers')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/articles-dossiers';
  } else if (tmpHref.includes('prelevement-a-la-so')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/article/information-loi-finances';
  } else if (tmpHref.includes('la-gestion-de-mon-contrat-dassur')) {
    tmpHref = tmpHref.substring(0, tmpHref.indexOf('#')) + '#/en-savoir-plus/dossier/la-gestion-de-mon-compte';
  } else if (tmpHref.includes('DossierFiscalite')) {
    const chiffre = tmpHref.indexOf('DossierFiscalite') + 16;
    tmpHref = tmpHref.replace('#DossierFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('dossierFiscalite')) {
    const chiffre = tmpHref.indexOf('dossierFiscalite') + 16;
    tmpHref = tmpHref.replace('#dossierFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('ArticleFiscalite')) {
    const chiffre = tmpHref.indexOf('ArticleFiscalite') + 16;
    tmpHref = tmpHref.replace('#ArticleFiscalite' + tmpHref.charAt(chiffre) + ':', '#/en-savoir-plus/article/');
  } else if (tmpHref.includes('Dossier')) {
    tmpHref = tmpHref.replace('#Dossier:', '#/en-savoir-plus/dossier/');
  } else if (tmpHref.includes('Article')) {
    tmpHref = tmpHref.replace('#Article:', '#/en-savoir-plus/article/');
  } else if (tmpHref.includes('fiche%20pratique%20d%c3%a9c%c3%a8s.pdf')) {
    tmpHref = tmpHref.replace('live', '{workspace}');
  }
  return tmpHref;
}


export const jahiaConfig = {
  apiBase: 'jahia_endpoint',
  apiJahiaEval: 'backend/jahiaConditionEval',
  apiJahiaNgServer: 'jahia_ng_server_endpoint',
  contribsPath: CONTRIBS_PATH,
  dictionnariesPath: DICTIONNAIRES_PATH,
  questionsResponsesPath: QUESTIONS_REPONSES_PATH,
  paths: PATHS,
  cleanerContentHtml: cleanContentHtml
};
