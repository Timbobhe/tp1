import { UrlService } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { Evenement } from '@app/models/client/evenement.model';
import { GetNextEven } from '@app/store/actions/evenement.actions';
import { selectEvenement } from '@app/store/reducers/rba.selectors';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { EMPTY, Observable } from 'rxjs';
import { filter, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EvenementService {

  constructor(
    private readonly store: Store<GlobalState>,
    public readonly urlService: UrlService) {
  }

  getNextEven(): Observable<Evenement> {
    if (this.urlService.isFrame) {
      return EMPTY;
    }

    return selectEvenement(this.store).pipe(
      map(evenState => {
        if (evenState.isFetched === false && evenState.loading === false) {
          this.store.dispatch(new GetNextEven());
        } else if (evenState.isFetched && !evenState.enTraitement) {
          return evenState.even;
        }
        return null;
      })
    );
  }

  getNextEvenIndisponibilite() {
    return this.getNextEven().pipe(filter(e => e && e.typeEvenement.categorie.codeCategorie === 'CAT_MESSAGE'));
  }

  getNextEvenHorsIndisponibilite() {
    return this.getNextEven().pipe(filter(e => e && e.typeEvenement.categorie.codeCategorie !== 'CAT_MESSAGE'));
  }
}
