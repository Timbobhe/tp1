import { Injectable } from '@angular/core';
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';


interface DynatraceConfig {
  active: boolean;
  script: string;
}

@Injectable({
  providedIn: 'root'
})
export class DynatraceService {

  config: DynatraceConfig;

  constructor(private readonly configService: ConfigService) {
    this.config = configService.config['dynatrace'];
  }

  installScript() {
    if (this.config && this.config.active && this.config.script) {
      this.loadScript(this.config.script);
    }
  }

  private loadScript(scriptSrc: string, htmlNode: string = 'head'): void {
    const script: HTMLScriptElement = document.createElement('script');
    script.type = 'text/javascript';
    script.src = scriptSrc;
    script.crossOrigin = 'anonymous';
    script.onload = () => trace(`DYNATRACE chargé depuis ${scriptSrc}`);
    script.onerror = () => trace('', new Error(`Erreur pendant le chargement DYNATRACE`));
    document.getElementsByTagName(htmlNode)[0].appendChild(script);
  }
}
