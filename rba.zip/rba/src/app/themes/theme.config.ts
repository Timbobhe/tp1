import { formatUrl, ThemeConfig } from '@ag2rlamondiale/transverse-metier-ng';
import { getJahiaResponse } from '@app/consts/jahia_default_response';
import { Image } from '@app/models/header/image.model';

export const RbaThemeConfig: ThemeConfig = {
  // defaultTheme: {themeType: 'ag2r', logoName: 'ag2r'},

  onInitTheme: (theme, configService) => {
    theme.variables['--coordonnees-bancaires-desktop-url'] = formatUrl(getJahiaResponse(configService).coordonneesBancairesImage.url);
    theme.variables['--coordonnees-bancaires-mobile-url'] = formatUrl(getJahiaResponse(configService).coordonneesBancairesImage.urlMobile);
  },

  onInitLogo: (logo, configService) => {
    let image: Image;
    if (logo.name === 'ag2r') {
      image = getJahiaResponse(configService).headerAg2r.title.image;
    } else if (logo.name === 'aca') {
      image = getJahiaResponse(configService).headerArialCNP.title.image;
    }

    const res = {};
    if (image) {
      res['--logo-desktop-url'] = formatUrl(image.url);
      res['--logo-mobile-url'] = formatUrl(image.urlMobile);
    }
    return res;
  }
};
