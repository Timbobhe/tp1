import {Component, EventEmitter} from '@angular/core';
import {ComponentFixture, TestBed, getTestBed} from '@angular/core/testing';
import {By} from '@angular/platform-browser';
import {Observable} from 'rxjs';
import { BehaviorSubject } from 'rxjs';
import { convertToParamMap, ParamMap, ActivatedRoute } from '@angular/router';

export class ActivatedRouteStub {

    // ActivatedRoute.paramMap is Observable
    private subject = new BehaviorSubject(convertToParamMap(this.testParamMap));
    paramMap = this.subject.asObservable();

    // Test parameters
    private _testParamMap: ParamMap;
    get testParamMap() { return this._testParamMap; }
    set testParamMap(params: {}) {
      this._testParamMap = convertToParamMap(params);
      this.subject.next(this._testParamMap);
    }

    // ActivatedRoute.snapshot.paramMap
    get snapshot() {
      return { paramMap: this.testParamMap };
    }
  }


export function getModuleProviderWithMockActivatedRoute() {
  return { provide: ActivatedRoute, useClass: ActivatedRouteStub };
}


export function getActivatedRoute() {
  const injector = getTestBed();
  const route = injector.get(ActivatedRoute);
  return route;
}

export const MockConfigService = {
  config : {
    backend_base: {
      protocol: 'http',
      host: '127.0.0.1',
      port: '3001',
    },
    backend: {
      endpoints: {
          metisUser: '/api/metis/metis-user',
          securePlace: '/securePlace'
      }
    }
  },
  getBaseUrl() {
    return 'http://127.0.0.1:3001';
  },
  getBackendBaseUrls(config: any) {
    return {
      backend_base: ''
    };
  }
};




export class AbstractMockService {

  getDatas(expectedResponse) {
    return new Observable(o => o.next(expectedResponse));
  }
}


@Component({
  selector: 'app-test-for-directive',
  template: ''
})
export class HostForDirectiveComponent {
  doSomething() {
    console.log('do');
  }
}

export function createTestComponent(template: string): ComponentFixture<HostForDirectiveComponent> {
  return TestBed
    .overrideComponent(HostForDirectiveComponent, { set: { template } })
    .createComponent(HostForDirectiveComponent);
}

export function getDirectiveInstance(fixture, Directive) {
  const directiveEl = getDirectiveEl(fixture, Directive);
  const directiveInstance = directiveEl.injector.get(Directive);
  return directiveInstance;
}

export function getDirectiveEl(fixture, Directive) {
  return fixture.debugElement.query(By.directive(Directive));
}
