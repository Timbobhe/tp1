import { Ag2rlmLibModule } from '@ag2rlamondiale/ag2rlm-lib';
import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { GlobalErrorHandler, MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { OgiHeaderModule, OgiResponsiveModule } from '@ag2rlamondiale/ogi-lib';
import { ReduxApiNgModule } from '@ag2rlamondiale/redux-api-ng';
import { APP_CONFIG, BackendService, CasService, GlobalEffects, Globals, SharedModule, TagCommanderEffect, THEME_CONFIG, TRACKING_CONFIG } from '@ag2rlamondiale/transverse-metier-ng';
import { registerLocaleData } from '@angular/common';
import localeFr from '@angular/common/locales/fr';
import { CUSTOM_ELEMENTS_SCHEMA, ErrorHandler, NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { metaReducers, reducers } from '@app/store/reducers/_index';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { ButtonModule, ChartModule, DialogModule, PanelModule } from 'primeng/primeng';
import { AppTrackingEffects } from './app-tracking-effects.service';
import { AppComponent } from './app.component';
import { routing } from './app.routes';
import { AuthBlocageConsole } from './authguards/auth-blocage-console.guard';
import { AuthLoginCas } from './authguards/auth-login.guard';
import { AppConfiguration } from './consts/app.consts';
import { RbaTrackingConfig } from './consts/tag-commander.consts';
import { jahiaConfig } from './jahia.config';
import { FunctionalityUnauthorizedComponent } from './modules/functionality-unauthorized/functionality-unauthorized.component';
import { MessageIndisponibiliteComponent } from './modules/rba-common/components/message-indisponibilite/message-indisponibilite.component';
import { RbaCommonModule } from './modules/rba-common/rba-common.module';
import { RbaEffects } from './store/effects/rba.effects';
import { RbaThemeConfig } from './themes/theme.config';

registerLocaleData(localeFr);
@NgModule({
  declarations: [
    AppComponent,
    FunctionalityUnauthorizedComponent,
    MessageIndisponibiliteComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    StoreModule.forRoot(reducers, { metaReducers }),
    StoreRouterConnectingModule,
    StoreDevtoolsModule.instrument({
      maxAge: 25 //  Retains last 25 states
    }),
    routing,
    SharedModule,
    DialogModule,
    ButtonModule,
    PanelModule,
    ChartModule,
    EffectsModule.forRoot([RbaEffects, AppTrackingEffects, GlobalEffects, TagCommanderEffect]),
    MetisNgModule.forRoot(),
    ReduxApiNgModule,
    JahiaNgModule.forRoot({ config: jahiaConfig }),
    RbaCommonModule,
    Ag2rlmLibModule,
    FlexLayoutModule,
    OgiHeaderModule,
    OgiResponsiveModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: TRACKING_CONFIG, useValue: RbaTrackingConfig },
    { provide: APP_CONFIG, useValue: AppConfiguration },
    { provide: THEME_CONFIG, useValue: RbaThemeConfig },
    BackendService,
    CasService,
    AuthLoginCas,
    AuthBlocageConsole,
    Globals
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
