import { InfosBlocagesClient } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { PushAccesFonctionnalite } from '@app/store/actions/accessibilite.actions';
import { selectClientInfos } from '@app/store/reducers/client-infos.reducer';
import { Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { GlobalState } from '../store/reducers/_index';

const DEFAULT_BLOCAGE_JAHIA = 'DEFAULT_BLOCAGE_CONSOLE';


@Injectable()
export class AuthBlocageConsole implements CanActivateChild {
  constructor(private readonly store: Store<GlobalState>, private readonly router: Router) {}

  /**
   * Vérifier le Blocage pour **une seule** fonctionnalité
   * @param b
   * @param codeFonc
   * @param route
   * @return true si bloqué, sinon false
   * @private
   */
  private static verifierBlocageUnitaire(
    b: InfosBlocagesClient,
    codeFonc: string | FonctionnaliteType,
    route: ActivatedRouteSnapshot
  ) {
    if (b.fonctionnalitesBloqueesALaPersonne.includes(codeFonc)) {
      return true;
    }

    const idContrat = route.params['onglet'];
    return idContrat && b.isFonctionnaliteBloqueePourContrat(idContrat, codeFonc);
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return selectClientInfos(this.store).pipe(
      map((c) => c.infosBlocagesClient),
      map((b) => {
        let codesFonc = route.data.id;
        if (!Array.isArray(codesFonc)) {
          codesFonc = [codesFonc];
        }

        return this.verifierBlocages(b, codesFonc, route);
      })
    );
  }

  verifierBlocages(
    b: InfosBlocagesClient,
    codesFonc: Array<string | FonctionnaliteType>,
    route: ActivatedRouteSnapshot
  ): boolean | UrlTree {

    const bloquees = codesFonc.filter((c) => AuthBlocageConsole.verifierBlocageUnitaire(b, c, route));
    if (bloquees.length < codesFonc.length) {
      return true;
    }

    const primaryFonc = codesFonc[0];
    this.store.dispatch(
      new PushAccesFonctionnalite(
        Object.assign({
          fonctionnaliteType: primaryFonc,
          accessible: false,
          raison: DEFAULT_BLOCAGE_JAHIA,
        })
      )
    );

    return this.router.parseUrl('/fonctionnalite-inaccessible?functionality=' + primaryFonc);
  }
}
