import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { ORIGIN_MASTER } from '@app/consts/app.consts';
import { COORDONNEES_BANCAIRES } from '@app/consts/fonctionnalites.const';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/store/actions/accessibilite.actions';
import { UpdateOriginAction } from '@app/store/actions/ui.actions';
import { GlobalState } from '@app/store/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subject, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CoordonneesBancairesGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly configService: ConfigService) {
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    trace('CoordonneesBancairesGuard#start');
    const canActivate = new Subject<boolean>();
    var getAccessibiliteCoordonneesBancaires;
    if (this.isRetourSigElec(state)) {
      getAccessibiliteCoordonneesBancaires = this.switchOriginFromLocalStorage();
    }
    else{
      getAccessibiliteCoordonneesBancaires = this.switchOriginFromUrl();
    }
    getAccessibiliteCoordonneesBancaires.payload.onSuccess = (data => {
      if (data.accessible || this.isRetourSigElec(state)) {
        canActivate.next(true);
        canActivate.complete();
      } else {
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible',
        {functionality: COORDONNEES_BANCAIRES}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });

     this.store.dispatch(getAccessibiliteCoordonneesBancaires);
    return canActivate.pipe(tap(r => trace('CoordonneesBancairesGuard#stop', r)));
  }

  switchOriginFromUrl(){
    if(window.location.href.includes('consultation/epargne')){
      this.store.dispatch(new UpdateOriginAction('epargne'));
      localStorage.setItem('dataSource', 'epargne');
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.EPARGNE);
    }
    else if(window.location.href.includes('consultation/cm')){
      this.store.dispatch(new UpdateOriginAction('cm'));
      localStorage.setItem('dataSource', 'cm');
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.CM);
    }
    else if(window.location.href.includes('consultation/prevoyance')){
      this.store.dispatch(new UpdateOriginAction('prevoyance'));
      localStorage.setItem('dataSource', 'prevoyance');
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.PREVOYANCE);
    }
    else if(window.location.href.includes('consultation/retraite')){
      this.store.dispatch(new UpdateOriginAction('retraite'));
      localStorage.setItem('dataSource', 'retraite');
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.RETRAITE_SUPPLEMENTAIRE);
    }
  }

  switchOriginFromLocalStorage(){
    if(localStorage.getItem('dataSource').includes('epargne')){
      this.store.dispatch(new UpdateOriginAction('epargne'));
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.EPARGNE);
    }
    else if(localStorage.getItem('dataSource').includes('cm')){
      this.store.dispatch(new UpdateOriginAction('cm'));
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.CM);
    }
    else if(localStorage.getItem('dataSource').includes('prevoyance')){
      this.store.dispatch(new UpdateOriginAction('prevoyance'));
      return new GetAccessibilite(COORDONNEES_BANCAIRES,ORIGIN_MASTER.PREVOYANCE);
    }
  }

  isRetourSigElec(state: RouterStateSnapshot) {
    return state.url.endsWith('/signature/echouee') || state.url.endsWith('/signature/annulee') || state.url.endsWith(
      '/signature/terminee');
  }
}
