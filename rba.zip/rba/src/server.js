'use strict';

var express = require('express');

var app = express();

app.set('port', process.env.PORT || 4200);

app.use('/',express.static('dist'));

app.listen(app.get('port'), function () {
  console.log('✔Express server listening on http://localhost:%d/', app.get('port'));
});
