window.__app_env = {};
window.__app_env.config = {
  backend: {
    endpoints: {
      base: '/api/secure',
      loginUrl: '/api/secure/redirectToFront',
      casClientLogout: "/api/logout",
      loginPartenaireUrl: '/api/public/redirectToPartenaireById',
      clientInfos: '/api/secure/get/infosclient',
      contratsAssures: '/api/secure/contrats_assures',
      trackingInfo: '/api/secure/tracking/info',
      matchAccount: '/api/secure/match-account',
      jahiaConditionEval: '/api/secure/jahia/condition-eval',
      jahia: '/api/secure/jahia',
      upload: '/api/secure/upload',
      prevalidatePieceIdentite: '/api/secure/prevalidate-piece-identite',
      creationPieceIdentite: '/api/secure/prevalidate-piece-identite/create',
      getCoordonneesClient: '/api/secure/coordonnees-client',
      updateCoordonneesClient: '/api/secure/coordonnees-client',
      coordonneesBancaires: '/api/secure/coordonnees-bancaires',
      sigElec : '/api/secure/demande-signature',
      evenements: '/api/secure/evenements',
    }
  }
};

objectAssignPolyfill();

Object.assign(window.__env.config, {
  timeout_delay: 120000, //Temps passé entre deux appels au back pour maintenir la session
  timeout_try: 5, // Nombre max d'appel passé au back avant d'arrêter de tenter de maintenir la session
  should_logout_cas_client: false,
  aqea_switch_even_endpoint: ['aqea_endpoint', 'switchEven'],
  jahia_ressources_root: ['jahia_endpoint'],
  jahia_ressources_logos_root: ['jahia_endpoint', '/files/live/sites/aqe/files/contributed/images/logos/'],
  jahia_ressources_logos_part_root: ['jahia_endpoint', '/files/live/sites/aqe/files/contributed/images/logoPart/'],
  jahia_ressources_coordonnees_bancaires_root: ['jahia_endpoint', '/files/live/sites/aqe/files/contributed/images/CoordonneesBancaires/'],
});

flattenConfig(window.__env.config);
