window.__env = {};
window.__env.config = {
    backend_base: {
        contextRoot: 'rbb'
    },
    theme_switcher: false,
    qad_reponse_auto: true,

    jahia_data: 'http://localhost:3085/jahia_data',
    jahia_ng_server_active: false,

    parcours_client_endpoint: 'http://esigate-dev/accueil/#/',
    master_epargne_endpoint: 'http://esigate-dev/accueil/#/MasterEpargne#epargne:',
    espace_societaire_endpoint: 'https://valid-client-professionnel.lamondiale.com/espsoc/servlet/servlet/demandes',
    jahia_header_script: '/files/live/sites/alm-angular-utils/files/javascript/angular-header-footer-dev.js',
    jahia_ogi_header_script: '/files/live/sites/aql/files/javascriptEtCSS/javascript/transverse/angular-header-footer-ogi-2021.js',
    jahia_endpoint: 'http://cdr-dev-jahia7',
    // jahia_endpoint: 'https://espace-client.ppalm.fr/',

    cas_server_logout_url: 'https://authext-asb/logout?service=http://esigate-dev/accueil',
    should_logout_cas_client: true,

    aqea_endpoint: 'http://esigate-dev/aqea/',
    // aqea_endpoint: 'http://127.0.0.1:8888/', // local setting

    lien_revocation_universign: 'https://sign.test.universign.eu/fr/revocation/',
    google_recaptcha_site_key: '6Ldgm-EUAAAAAHRl-3qK__FxryVN_qWG15Q1sfw7',

    feature_disable: {
        prevalidation: true
    },

    warning_navigator: {
        regles: [
            {browser: 'Chrome', versionMin: 72},
            {browser: 'Firefox', versionMin: 64},
            {browser: 'IE', versionMin: 12},
            {browser: 'Edge', versionMin: 18},
            {browser: 'Safari', versionMin: 12},
        ]
    },

    // Dynatrace
    // dynatrace: {
    //     active: true,
    //     script: 'https://dynatrace-managed.ag2rlamondiale.fr:443/jstag/managed/b9b2f0ba-cb79-45d5-97b2-2fef28ce9ca0/e3896b2f9c84f8b6_complete.js'
    // },

    // TAGGO
    tc_head_url: 'https://cdn.tagcommander.com/3431/uat/tc_AG2RLaMondiale_1.js',
    tc_head_iframe_url: '//redirect3431.tagcommander.com/utils/noscript.php?id=1&amp;mode=iframe',
    tc_body_url: 'https://cdn.tagcommander.com/3431/uat/tc_AG2RLaMondiale_4.js',
    tc_body_iframe_url: '//redirect3431.tagcommander.com/utils/noscript.php?id=2&amp;mode=iframe',
    tc_vars: {
        env_work: 'localhost', // dev, recette, preproduction, production
        env_metier: 'epargne_mdpro',
        page_event_manual: true
    }
};
