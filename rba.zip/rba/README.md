# Application rba AG2R LA MONDIALE
Cette application est le front de l'application, rba


-------------
Organisation des Tags et Branches :
-------------
 - Nouvelle branche release_x.x.x chaque increment.
 - chaque developpeur cree une branche feature_SCEI-number_de_la_fonctionalite a partir de la branche release en cours.
 - Nouveau tag v.x.x.x chaque iteration (sprint).
 - A la fin d un increment on merge la branche de release dans master, et on cree une nouvelle branche release.

# Commandes
-  Lancer le serveur front angular
`npm start`
- Lancer le serveur mock json-server
`npm run mock`

# Docker commands

`docker build -t rba .` to build an image from a Dockerfile situated in current location.

`docker run -it -p 4200:80 rba` to run rba image in a new container, and bind container's port 80 with host's port 4200.(-d to run as DEAMON).

`docker images` to list all images in the host.

`docker exec -ti CONTAINER_ID /bin/bash` to connect to the container.