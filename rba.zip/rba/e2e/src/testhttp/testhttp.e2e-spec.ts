import { browser } from 'protractor';
import { TesthttpPage } from './testhttp.po';

describe('appname / testhttp page', () => {
  let page: TesthttpPage;

  beforeEach(() => {
    page = new TesthttpPage();
  });

  afterEach(function() {
    browser.manage().logs().get('browser').then(function(browserLog) {
      // expect(browserLog.length).toEqual(0);
      // Uncomment to actually see the log.
      console.log('log: ' + require('util').inspect(browserLog));
    });
  });

  it('should display the title', () => {
    page.navigateTo();
    const elem = page.getPageTitleElem();
    expect(elem.isPresent()).toBeTruthy();
    expect(elem.getText()).toContain('backend');
  });

});
