import { browser, by, element } from 'protractor';

export class TesthttpPage {
  navigateTo() {
    return browser.get('/#/feature1/testhttp');
  }

  getPageTitleElem() {
    return element(by.css('app-root h4'));
  }

  getResultA() {
    return element(by.id('resultA'));
  }

}
