window.__env = {};
window.__env.config = {
  backend_base: {
    protocol: '{{default .Env.APP_BACKEND_PROTOCOL "http"}}',
    host: '{{default .Env.APP_BACKEND_HOST "localhost"}}',
    port: '{{default .Env.APP_BACKEND_PORT "80"}}',
    contextRoot: '{{default .Env.APP_BACKEND_CONTEXT_ROOT "rbb"}}'
  },
  jahia_header_script:
    '{{default .Env.JAHIA_HEADER_SCRIPT "/files/live/sites/alm-angular-utils/files/javascript/angular-header-footer-dev.js"}}',
  jahia_endpoint: '{{default .Env.JAHIA_ENDPOINT "http://cdr-dev-jahia7"}}',
  master_epargne_endpoint:
    '{{default .Env.MASTER_EPARGNE_ENDPONT "http://esigate-dev/accueil/#/MasterEpargne#epargne:"}}',
  parcourt_client_endpoint: '{{default .Env.PARCOURT_CLIENT_ENDPOINT "http://esigate-dev/accueil/#/"}}',
  jahia_ng_server_endpoint: '{{default .Env.JAHIA_NG_SERVER_ENDPOINT "http://esigate-dev/rbb/api/secure/jahia"}}',
  lien_revocation_universign: '{{default .Env.LINK_REVOCATION_UNIVERSIGN "https://sign.test.universign.eu/fr/revocation/"}}',
  google_recaptcha_site_key: '{{default .Env.GOOGLE_RECAPTCHA_SITE_KEY "6Ldgm-EUAAAAAHRl-3qK__FxryVN_qWG15Q1sfw7"}}',
  tc_head_url: '{{default .Env.TC_HEAD_URL "https://cdn.tagcommander.com/3431/uat/tc_AG2RLaMondiale_1.js"}}',
  tc_head_iframe_url: '{{default .Env.TC_HEAD_IFRAME_URL "//redirect3431.tagcommander.com/utils/noscript.php?id=1&amp;mode=iframe"}}',
  tc_body_url: '{{default .Env.TC_BODY_URL "https://cdn.tagcommander.com/3431/uat/tc_AG2RLaMondiale_4.js"}}',
  tc_body_iframe_url: '{{default .Env.TC_BODY_IFRAME_URL "//redirect3431.tagcommander.com/utils/noscript.php?id=2&amp;mode=iframe"}}',
  tc_vars: {
    env_work: '{{default .Env.TC_VARS_ENV_WORK "localhost"}}', // dev, recette, preproduction, production
    env_metier: 'epargne_mdpro',
    page_event_manual: true
  },
  cas_server_logout_url:'{{default .Env.CAS_LOGOUT_URL "https://authext-asb/logout?service=http://esigate-dev/accueil"}}',
  should_logout_cas_client: true,
  jahia_ogi_header_script: '{{default .Env.JAHIA_OGI_HEADER_SCRIPT "/files/live/sites/aql/files/javascriptEtCSS/javascript/transverse/angular-header-footer-ogi-2021.js"}}'
};
