'use strict';

exports.contextualProperties = [
  {
    "cas.service.url": "http://localhost:8080/mocked",
    "cas.url.login": "https://loginkrb1-np/cas/sso/DEV_LUTI/login",
    "cas.url.logout": "https://loginkrb1-np/cas/sso/DEV_LUTI/logout"
  }
]
