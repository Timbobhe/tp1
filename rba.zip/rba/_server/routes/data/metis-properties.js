'use strict';

exports.metisProperties = [
  {
    roles: ["ROLE_EMDPRO-Utilisateur"],
    displayName: "ALEX MOUTOUSSAMY",
    uid: "v3b52v",
    ntDomain: null,
    ou: null,
    environnement: "",
    authenticated: true,
    mail: "sophie.alliot@ag2rlamondiale.fr",
    sn: "MOUTOUSSAMY",
    givenName: "ALEX",
    rolesAsArray: ["ROLE_EMDPRO-Utilisateur"]
  }
];
