'use strict';

var _ = require('underscore');
const { version } = require('process');
var USER = require('./data/user').user;
var METIS_PROPERTIES = require('./data/metis-properties').metisProperties;
var CONTEXTUAL_PROPERTIES = require('./data/contextual-properties').contextualProperties;
var info = require('./data/user').info;
var infoClient = require("./data/user").infoClient;
var contratAssure = require("./data/user").contratAssure;
var coordonnesBancaires = require("./data/user").coordonnesBancaires;
var vosCoordonnesBancaires = require("./data/user").vosCoordonnesBancaires;


exports.getMetisUser = function (req, res) {
  return res.status(200).json(USER[0]);
};

exports.getInfo = function(req, res) {
  return res.status(200).json(info);
};


exports.getInfoClient = function(req, res) {
  return res.status(200).json(infoClient);
};

exports.getContratAssure = function(req, res) {
  return res.status(200).json(contratAssure);
};

exports.getCoordonnesBancaires = function(req, res) {
  return res.status(200).json(coordonnesBancaires);
};

exports.getVosCoordonnesBancaires = function(req, res) {
  return res.status(200).json(vosCoordonnesBancaires);
};

exports.getNext = function(req, res) {
  return res.status(200).json({});
};

exports.getDemandeSignature = function(req, res) {
  return res.status(200).json({});
};

exports.getSecurePlace = function (req, res) {
  return res.status(200);
};

exports.logout = function (req, res) {
  return res.status(200).json({});
};

exports.getMetisProperties = function (req, res) {
  return res.status(200).json(METIS_PROPERTIES[0]);
};

exports.getMetisContextualProperties = function (req, res) {
  return res.status(200).json(CONTEXTUAL_PROPERTIES[0]);
};

exports.getServiceA = function (req, res) {
  var msg = getParam(req, 'msg');
  return res.status(200).send("Result A using arg : [" + msg + "]");
};

exports.getVersion = (req, res) => res.status(200).json(version);


function getParam(req, param) {
  return req.params[param];
}

function getId(req) {
  var param = getParam(req, 'id');
  return parseInt(param);
}

function createId() {
  return new Date().getTime() + "";
}
