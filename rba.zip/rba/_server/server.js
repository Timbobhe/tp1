'use strict';

//require('colors');

var express = require('express'),
  bodyParser = require('body-parser'),
  http = require('http'),
  path = require('path'),
  api = require('./routes/api'),
  cors = require('cors');

var app = express();

app.set('port', process.env.PORT || 3001);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//CORS
var corsOptions = {
  origin: true,
  credentials: true,
  methods: ['GET', 'PUT', 'POST', 'DELETE']
}
app.use(cors(corsOptions));

// JSON API
app.get('/rbb/api/version', api.getVersion);
app.get('/rbb/api/metis/metis-user', api.getMetisUser);
app.get('/rbb/api/secure/tracking/info', api.getInfo);
app.get("/rbb/api/secure/get/infosclient", api.getInfoClient);
app.get("/rbb/api/secure/contrats_assures", api.getContratAssure);
app.get("/rbb/api/secure/coordonnees-bancaires/start", api.getCoordonnesBancaires);
app.get(
  "/rbb/api/secure/accessibilite",
  api.getVosCoordonnesBancaires
);
app.get("/rbb/api/metis/metis-user", api.getMetisUser);

app.get('/rbb/api/metis/properties', api.getMetisProperties);


app.get("/rbb/api/secure/evenements/next", api.getNext);

app.get("/rbb/api/secure/demande-signature/", api.getDemandeSignature);
//
app.get('/rbb/securePlace', api.getSecurePlace);
app.post('/rbb/j_spring_security_logout', api.logout);

app.get('/rbb/api/serviceA/:msg', api.getServiceA);

app.listen(app.get('port'), function () {
  console.log('✔Express server listening on http://localhost:%d/', app.get('port'));
});
