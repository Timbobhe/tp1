# ecrs-api

## Test connexion depuis partenaire ADDING

1. Allez sur l'application test GEDai `http://innovami:8080/testgedai/#partenaireExterne:`
1. Remplir le formulaire puis cliquer sur le bouton Obtenir le lien SSO
1. Environnement SSO cible: `dev`
1. Partenaire à simuler: `ADDING`

1. relayState (selon l'environnement):
	- Dev Mode: `http://loginalm-qualif/cas/ping/dev$alm2014/loginPing?service=http%3A%2F%2Flocalhost%3A4200`
	- DEV: `http://loginalm-qualif/cas/ping/dev$alm2014/loginPing?service=http%3A%2F%2Fesigate-dev%2Frsb`

1. Identifiant: `P4232980`

1. businessIdMap: `{idEpargneRetraite=P4232980}`

1. roles: `Acces_Client` 

1. Une pop-in avec le lien sso s'ouvre

1. Cliquer sur le lien SSO

1. L'application ECRS s'ouvre avec l'IHM d'`ADDING`

## Test connexion depuis partenaire NIE

1. Allez sur l'application test GEDai `http://innovami:8080/testgedai/#partenaireExterne:`
1. Remplir le formulaire puis cliquer sur le bouton Obtenir le lien SSO
1. Environnement SSO cible: `dev`
1. Partenaire à simuler: `NIE`

1. relayState (selon l'environnement):
	- Dev Mode: `http://loginalm-qualif/cas/ping/dev$alm2014/loginPing?service=http%3A%2F%2Flocalhost%3A4200`
	- DEV: `http://loginalm-qualif/cas/ping/dev$alm2014/loginPing?service=http%3A%2F%2Fesigate-dev%2Frsb`

1. Clic sur TransientID pour générer un UUID.

1. idPersonne {IdEpargneRetraite=...}: `{idEpargneRetraite=P4393784}`

1. roles: `Acces_Client` 

1. Une pop-in avec le lien sso s'ouvre

1. Cliquer sur le lien SSO

1. L'application ECRS s'ouvre avec l'IHM de `NIE`