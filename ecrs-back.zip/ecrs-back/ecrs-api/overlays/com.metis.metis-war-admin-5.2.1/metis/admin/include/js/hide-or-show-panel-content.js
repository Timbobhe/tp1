/**
 * Affiche le contenu de la balise div , masque le lien de 
 * fermeture et affiche le lien d'ouverture.
 * @param divId Identifiant du div 
 * @param closeLink Identifiant du lien de fermeture
 * @param openLink Identifiant du lien d'ouverture
 */
	function showPanelContent(divId, closeLink, openLink) {
				var div = document.getElementById(divId);
	var close = document.getElementById(closeLink);
	var open = document.getElementById(openLink);

	close.style.display='none';
	open.style.display='inline';
	
	div.style.display='block';
	/*div.style.height='auto';*/

}

/**
 * Masque le contenu de la balise div, affiche le lien de fermeture, 
 * masque le lien d'ouverture et positionne la hauteur du div � 1px.
 * @param divId Identifiant du div 
 * @param closeLink Identifiant du lien de fermeture
 * @param openLink Identifiant du lien d'ouverture
 */

function hidePanelContent(divId, closeLink, openLink) {
	var div = document.getElementById(divId);
	var close = document.getElementById(closeLink);
	var open = document.getElementById(openLink);

	close.style.display='inline';
	open.style.display='none';
	
	div.style.display='none';
	/*div.style.height='1px';*/

}

