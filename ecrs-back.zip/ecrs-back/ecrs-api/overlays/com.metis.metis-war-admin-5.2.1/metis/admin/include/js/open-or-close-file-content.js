function openFiles(divName, closeLink, openLink) {
	var div = document.getElementsByName(divName);
	var close = document.getElementById(closeLink);
	var open = document.getElementById(openLink);
	for (var i=0; i<div.length; i++){
		div[i].style.display='block';
		div[i].style.height='auto';
		   } 
	
	close.style.display='none';
	open.style.display='inline';
	
}

function closeFiles(divName, closeLink, openLink) {

	var div = document.getElementsByName(divName);
	var close = document.getElementById(closeLink);
	var open = document.getElementById(openLink);

	close.style.display='inline';
	open.style.display='none';
	for (var j=0; j<div.length; j++){
		div[j].style.display='none';
		div[j].style.height='1px';

		   } 

}