package fr.ag2rlamondiale.ecrs.security;

import com.google.common.base.Strings;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IClientFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IPartenaireFacade;
import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.lmt.BucketConstants;
import fr.ag2rlamondiale.ecrs.lmt.business.IBucketFacade;
import fr.ag2rlamondiale.ecrs.lmt.dto.ConsumptionException;
import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.metis.boot.security.dao.IApplicationRolesRetriever;
import fr.ag2rlamondiale.metis.boot.security.dao.MetisBootCasUserDetailsService;
import fr.ag2rlamondiale.metis.boot.security.dao.UserDetailsImpl;
import fr.ag2rlamondiale.trm.cache.ITrackUserCache;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapper;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException.ErrorCode;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import fr.ag2rlamondiale.trm.utils.MapUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.partenaire.PartenaireUtils.temporaryUserId;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Service
@Slf4j
public class EcrsCasUserDetailsService extends MetisBootCasUserDetailsService {

    private final static String FDI_PERIMETER_FRANCE_CONNECT = "49507";
    public static final String FDI_PERIMETER_NAME = "fdiPerimeterName";


    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private UserSecurityService securityService;

    @Autowired
    private IClientFacade clientFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IPartenaireFacade partenaireFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private PartenaireMapper partenaireMapper;

    @Autowired
    private PreCache preCache;

    @Autowired
    private ITrackUserCache trackUserCache;

    @Autowired
    private IUserIdentityProviderFacade userIdentityProviderFacade;

    @Autowired
    private IBucketFacade bucketFacade;

    /**
     * Constructeur
     *
     * @param applicationRolesRetriever retriever des roles applicatifs
     */
    public EcrsCasUserDetailsService(IApplicationRolesRetriever applicationRolesRetriever) {
        super(new String[]{"roles"}, applicationRolesRetriever);
    }

    @Override
    public UserDetails loadUserDetails(CasAssertionAuthenticationToken authentication) {
        long start = System.currentTimeMillis();
        log.info("Tentative de connexion avec {}", authentication);
        return userContextHolder.create(() -> {
            final UserDetails userDetails = basicLoadUserDetails(authentication);
            if (userDetails.isEnabled()) {
                preCache.start(trackUserCacheImpersonation(authentication));
                trackUserCacheImpersonation(authentication).run();
                log.info("Connexion reussie pour {} en {} ms", userDetails, System.currentTimeMillis() - start);
            } else {
                log.info("Connexion DISABLED pour {} en {} ms", userDetails, System.currentTimeMillis() - start);
            }
            return userDetails;
        });
    }

    private UserDetails basicLoadUserDetails(CasAssertionAuthenticationToken authentication) {
        Map<String, Object> casMap = null;
        try {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetailsImpl userDetails = (UserDetailsImpl) super.loadUserDetails(authentication);
            logTentativeConnexion(authentication, userDetails);
            if (userDetails.getAuthorities().isEmpty()) {
                return new EcrsUserDetails(userDetails, false);
            }
            if (AuthentificationUtils.hasRole(userDetails, RolesEnum.PILOTAGE_ERE)) {
                userContextHolder.get().setPilotage(true);
                return new EcrsUserDetails(userDetails, true);
            }
            casMap = userDetails.getAttributesMap();
            PersonnePhysique personnePhysique;
            String idGdi;
            userContextHolder.get().setHasIdGdi(true);
            if (AuthentificationUtils.isUserImpersonated(userDetails)) {
                userContextHolder.get().setImpersonation(true);
                userContextHolder.get().setExternalUid(getExternalUid(userDetails));
            }
            if (AuthentificationUtils.hasRole(userDetails, RolesEnum.FEDERATION)) {
                personnePhysique = getPersonnePhysiqueDepuisFederationIdentite(casMap, userDetails);
                // Pour récupérer l'ID technique de connexion
                idGdi = personnePhysique.getIdGdi();
                trackUserCache.clearUserCache(idGdi);
            } else if (FDI_PERIMETER_FRANCE_CONNECT.equals(casMap.get(FDI_PERIMETER_NAME))) {
                String uid = (String) casMap.get("uid");
                Objects.requireNonNull(uid, "L'idGDI du jeton CAS est null");
                userContextHolder.get().setIdGdi(uid); // affecté temporairement pour les appels pfs
                userContextHolder.get().setFranceConnect(true);
                IdentiteNumeriqueHabilitation idHabili = IdentiteNumeriqueHabilitation.builder()
                        .login(uid)
                        .identifiantFournisseurIdentiteNumerique(FDI_PERIMETER_FRANCE_CONNECT)
                        .build();
                personnePhysique = clientFacade.rechercherPersonnePhysiqueParIdHabili(idHabili);
                idGdi = personnePhysique.getIdGdi();
                userContextHolder.get().setIdGdi(idGdi);
                trackUserCache.clearUserCache(idGdi);
            } else {
                idGdi = (String) casMap.get("uid");
                Objects.requireNonNull(idGdi, "L'idGDI du jeton CAS est null");
                userContextHolder.get().setIdGdi(idGdi); // pour la traceWs
                trackUserCache.clearUserCache(idGdi);

                personnePhysique = clientFacade.rechercherPersonnePhysiqueParIdGdi(idGdi);
            }

            securityService.initSecurityContext(idGdi, personnePhysique);

            if (userContextHolder.get().getPartenaire() != null) {
                List<ContratHeader> contrats = contratFacade.rechercherContrats();
                if (contrats.isEmpty()) {
                    throw new PartenaireException(ErrorCode.NO_CONTRACTS);
                }
            }

            InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();
            userContextHolder.get().setInfosBlocagesClient(infosBlocagesClient);


            logBlocages(idGdi, infosBlocagesClient);
            userContextHolder.get().setAuthentificationUser(userDetails.getUsername());
            return new EcrsUserDetails(userDetails, !infosBlocagesClient.isPersonneTotalementBloquee());

        } catch (PartenaireException e) {
            log.error("Erreur d'authentication PartenaireException", e);
            addTokenBucket(casMap);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw e;
        } catch (ConsumptionException e) {
            log.warn("Pas de Ticket de disponible pour accepter la connexion de {} - {}", casMap, authentication);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw e;
        } catch (Exception e) {
            log.error("Erreur d'authentication", e);
            addTokenBucket(casMap);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw new UsernameNotFoundException("Erreur d'authentication", e);
        }
    }


    private void logTentativeConnexion(Authentication authentication, UserDetailsImpl userDetails) {
        Collection<String> roles = new ArrayList<>();
        if (userDetails.getAuthorities() != null) {
            roles = userDetails.getAuthorities()
                    .stream().map(GrantedAuthority::getAuthority).collect(Collectors.toList());
        }
        final Map<String, Object> casMap = userDetails.getAttributesMap();
        log.info("Detail Tentative de connexion pour {} avec {}, roles = {}", authentication, casMap, roles);
    }

    private void logBlocages(String idGdi, InfosBlocagesClient infosBlocagesClient) {
        if (infosBlocagesClient.isPersonneTotalementBloquee()) {
            log.warn("Utilisateur {} totalement bloque (blocage console)", idGdi);
        }
        if (infosBlocagesClient.isToutLesContratsTotalementsBloques()) {
            log.warn("Utilisateur {}, tous les contrats totalement bloques (blocage console)", idGdi);
        }
        if (!infosBlocagesClient.getFonctionnalitesBloqueesContrats().isEmpty()) {
            log.warn("Utilisateur {}, a fonctionnalites bloques sur au moins un contrat {} (blocage console)", idGdi, infosBlocagesClient.getFonctionnalitesBloqueesContrats());
        }
        if (userContextHolder.get().getPartenaire() != null && !infosBlocagesClient.getFonctionnalitesBloqueesPartenaire().isEmpty()) {
            log.warn("Utilisateur {} connexion partenaire, a des fonctionnalites partenaires bloques {} (blocage console)", idGdi, infosBlocagesClient.getFonctionnalitesBloqueesPartenaire());
        }
    }


    private String getExternalUid(UserDetailsImpl userDetails) {
        return (String) userDetails.getAttributesMap().get("externalUid");
    }

    /**
     * Connexion depuis partenaire
     *
     * @param casMap
     * @param userDetails
     * @return
     */
    private PersonnePhysique getPersonnePhysiqueDepuisFederationIdentite(Map<String, Object> casMap, UserDetailsImpl userDetails) {
        log.info("Connexion par federation d'identite avec {}", casMap);
        final String primaryPartner = Strings.emptyToNull((String) casMap.get(FDI_PERIMETER_NAME));
        Objects.requireNonNull(primaryPartner, "Le code partenaire dans le jeton CAS est vide");

        final UserDetailsAdapter uda = new UserDetailsAdapter(userDetails);
        bucketFacade.tryConsumeAndReturnRemaining(BucketConstants.bucketNameFromPartenaire(primaryPartner), 1L, uda);

        final UserResponseInternal userResponseInternal = userIdentityProviderFacade.identiteInterneDepuisFederation(uda);
        if (Boolean.FALSE.equals(userResponseInternal.getIsAuthorized())) {
            throw new PartenaireException(ErrorCode.UNKNOWN_USER);
        }

        if (userResponseInternal.hasCompteDemo()) {
            userContextHolder.get().setCompteDemo(userResponseInternal.getCompteDemo());
        }


        Partenaire partenaire = partenaireMapper.map(partenaireFacade.findById(primaryPartner));
        userContextHolder.get().setPartenaire(partenaire);
        final String secondaryPartner = Strings.emptyToNull((String) casMap.get("seeAlso"));
        if (secondaryPartner != null) {
            userContextHolder.get().setSousPartenaire(secondaryPartner);
        }
        Map<String, String> businessIdMap = MapUtils.parseStringMap((String) casMap.get("businessIdMap"));


        final PersonnePhysique personnePhysique = userResponseInternal.getPersonnePhysique();
        if (businessIdMap != null) {
            final String refExterne = Strings.emptyToNull(businessIdMap.get("refExterne"));
            partenaire.setBaseUrl(Strings.emptyToNull(businessIdMap.get("origineAcces")));
            partenaire.setRefExterne(refExterne);
        }

        final String numPers = personnePhysique.getNumeroPersonneEre();

        final Integer idTechCnx = partenaireFacade.updateIdgdiTemporaire(primaryPartner, numPers, null, personnePhysique.getIdGdi());

        if (personnePhysique.getIdGdi() == null) {
            final String tempUserId = temporaryUserId(idTechCnx);
            personnePhysique.setIdGdi(tempUserId);
            userContextHolder.get().setHasIdGdi(false);
        }
        userContextHolder.get().setTemporaryId(idTechCnx);
        userContextHolder.get().setIdGdi(personnePhysique.getIdGdi());
        userContextHolder.get().setIdExtranet(personnePhysique.getIdExtranet());
        userDetails.setUsername(userContextHolder.get().getIdGdi());
        userDetails.setUserFirstLastName(personnePhysique.getPrenom() + ' ' + personnePhysique.getNom());

        log.info("idGdi : {}, Num\u00e9ro de personne : {}, idExtranet : {}, Code partenaire : {}",
                 userContextHolder.get().getIdGdi(),
                 numPers,
                 userContextHolder.get().getIdExtranet(),
                 primaryPartner);
        return personnePhysique;
    }


    private Runnable trackUserCacheImpersonation(Authentication authentication) {
        final UserContext userContext = userContextHolder.get();
        final String source = authentication.getName();
        final String cible = userContext.getIdGdi();
        if (userContext.isImpersonation() && !cible.equals(source)) {
            return () -> trackUserCache.migrateTrackUserCache(source, cible);
        }
        return () -> {
        };
    }

    private void addTokenBucket(Map<String, Object> casMap) {
        if (casMap == null) {
            return;
        }
        final String primaryPartner = (String) casMap.get(FDI_PERIMETER_NAME);
        if (primaryPartner != null) {
            bucketFacade.addTokens(BucketConstants.bucketNameFromPartenaire(primaryPartner), null);
        }
    }

}
