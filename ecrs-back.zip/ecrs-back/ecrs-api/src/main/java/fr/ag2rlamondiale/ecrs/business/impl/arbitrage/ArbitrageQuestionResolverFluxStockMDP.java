package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_SOUHAIT_ARBITRER;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_QUESTION_FLUXSTOCK_TITRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK;

@Service
public class ArbitrageQuestionResolverFluxStockMDP implements ArbitrageQuestionResolver {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Override
    public QuestionResponsesDto<ResponseArbitrageFluxStockType, GestionFinanciereActuelleMdpDto> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contexte.getContratSelectionne());
        final ContratHeader contratHeader = contratComplet.getContratHeader();


        GestionFinanciereActuelleMdpDto gestFinActuelle = structureInvFacade.getInfoGestionFinanciereActuelleMdp(contratHeader);

        // PEP et PERP
        final QuestionResponsesDto<ResponseArbitrageFluxStockType, GestionFinanciereActuelleMdpDto> result = new QuestionResponsesDto<>();
        result.setData(gestFinActuelle);
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK)
                .jahiaDicoEntry(ARB_QUESTION_FLUXSTOCK_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_SOUHAIT_ARBITRER.name())
                .build());

        if (gestFinActuelle.isFiscalitePEP()) {
            ResponseDto<ResponseArbitrageFluxStockType> reponseFiscalitePEP = reponseFiscalitePEP(contexte, gestFinActuelle);
            result.add(reponseFiscalitePEP);
            if (!reponseFiscalitePEP.isDisabled()) {
                result.setDefaultValue(reponseFiscalitePEP);
                result.setShow(false);
                contexte.update(ctx -> ctx.setResponseFluxStockType(result.getDefaultValue().getValue()));
            }
            return result;
        }

        final List<ResponseArbitrageFluxStockType> reponsesFluxStock = ArbitrageMdproHelper.getTypesArbitragePossiblesFiscaliteHorsPEP(
                gestFinActuelle.getModeGestionMDPROSource(), gestFinActuelle.getIdGrilleSource(), contexte.getResponseModeGestionType());
        for (QuestionType.ResponseArbitrageFluxStockType type : reponsesFluxStock) {
            final Encours encours = contratComplet.getEncoursTotal();

            if (type == ARBITRAGE_STOCK && (encours.getMontant() == null || BigDecimal.ZERO.compareTo(encours.getMontant()) == 0)) {
                final ResponseDto<ResponseArbitrageFluxStockType> response = ResponseDto.<ResponseArbitrageFluxStockType>builder()
                        .id(ARBITRAGE_STOCK.name())
                        .value(ARBITRAGE_STOCK)
                        .disabled(true)
                        .build();
                setLabel(response);
                setWarningMessage(response);
                result.add(response);
            } else {
                result.add(reponse(type));
            }
        }

        if (result.getPropositions().size() == 1) {
            result.setDefaultValue(result.getPropositions().get(0));
            result.setShow(false);
            contexte.update(ctx -> ctx.setResponseFluxStockType(result.getDefaultValue().getValue()));
        }

        return result;
    }


    public ResponseDto<ResponseArbitrageFluxStockType> reponseFiscalitePEP(ArbitrageContexteDto contexte, GestionFinanciereActuelleMdpDto gestFinActuelle) {
        ResponseArbitrageFluxStockType type = ArbitrageMdproHelper.getTypeArbitragePourFiscalitePEP(gestFinActuelle.getIdGrilleSource());
        if (type != null) {
            return reponse(type);
        }

        final ResponseDto<ResponseArbitrageFluxStockType> response = ResponseDto.<ResponseArbitrageFluxStockType>builder()
                .disabled(true)
                .build();


        response.setWarningMessage(MessageDto.builder()
                .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MDPRO_MESSAGE_PEP_INCONNU.name())
                .build());
        return response;
    }

    public ResponseDto<ResponseArbitrageFluxStockType> reponse(ResponseArbitrageFluxStockType responseArbitrageFluxStockType) {
        final ResponseDto<ResponseArbitrageFluxStockType> response = ResponseDto.<ResponseArbitrageFluxStockType>builder()
                .id(responseArbitrageFluxStockType.name())
                .value(responseArbitrageFluxStockType)
                .build();

        return setLabel(response);
    }

    private ResponseDto<ResponseArbitrageFluxStockType> setWarningMessage(ResponseDto<ResponseArbitrageFluxStockType> response) {
        final ResponseArbitrageFluxStockType type = response.getValue();
        // Non pacte
        switch (type) {
            case ARBITRAGE_STOCK:
                response.setWarningMessage(MessageDto.builder()
                        .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MESSAGE_STOCK_ZERO_NON_PACTE.name())
                        .build());
                return response;
            default:
                throw new IllegalArgumentException(type.name());
        }
    }


    private ResponseDto<ResponseArbitrageFluxStockType> setLabel(ResponseDto<ResponseArbitrageFluxStockType> response) {
        final ResponseArbitrageFluxStockType type = response.getValue();
        switch (type) {
            case ARBITRAGE_FLUX:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX.name());
                return response;
            case ARBITRAGE_STOCK:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_STOCK.name());
                return response;
            case ARBITRAGE_FLUXSTOCK:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_STOCK.name());
                return response;
            default:
                throw new IllegalArgumentException(type.name());
        }
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getContratSelectionne().is(CodeSiloType.MDP);
    }
}
