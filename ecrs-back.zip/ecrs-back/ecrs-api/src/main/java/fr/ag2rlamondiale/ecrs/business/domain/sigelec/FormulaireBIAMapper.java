package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireBIA;
import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationStructureInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.OccurenceStructureInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.StructureInvestissementType;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring", uses = {DateMapper.class}, imports = {StringUtils.class, CodeApplicationType.class})
public abstract class FormulaireBIAMapper implements IFormulaireMapper {
    @Autowired
    private OccurenceStructureInvestissementTypeMapper occurenceStructureInvestissementTypeMapper;
    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today())")

    @Mapping(target = "identificationContratDansSilo.identifiantDansSilo", source = "contrat.id")
    @Mapping(target = "identificationContratDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationContratDansSilo.codeApplication", expression = "java(CodeApplicationType.PTV_ERE.getCode())")
    @Mapping(target = "identificationContratDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationContratDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationContratDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationAffiliationDansSilo.identifiantDansSilo", source = "identifiantAssure")
    @Mapping(target = "identificationAffiliationDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationAffiliationDansSilo.codeApplication", expression = "java(CodeApplicationType.PTV_ERE.getCode())")
    @Mapping(target = "identificationAffiliationDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationAffiliationDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationAffiliationDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationUserDansSilo.identifiantDansSilo", source = "idGdi")
    @Mapping(target = "identificationUserDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationUserDansSilo.codeApplication", expression = "java(CodeApplicationType.ECRS.getCode())")
    @Mapping(target = "identificationUserDansSilo.libelleApplication", constant = FormulaireConstantes.ESPACE_CLIENT_PARTICULIER_ERE)
    @Mapping(target = "identificationUserDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationUserDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationPersonneDansSilo.identifiantDansSilo", source = "personPhysique.id")
    @Mapping(target = "identificationPersonneDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationPersonneDansSilo.codeApplication", expression = "java(fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE.egesper().getCode())")
    @Mapping(target = "identificationPersonneDansSilo.libelleApplication", constant = FormulaireConstantes.EGESPER_ERE)
    @Mapping(target = "identificationPersonneDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationPersonneDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationDemandeDansSilo.identifiantDansSilo", source = "idDemandeWkf")
    @Mapping(target = "identificationDemandeDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationDemandeDansSilo.codeApplication", expression = "java(CodeApplicationType.ATC.getCode())")
    @Mapping(target = "identificationDemandeDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationDemandeDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationDemandeDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "informationsComplementaires.signaletiquePP.nom", source = "personPhysique.nom")
    @Mapping(target = "informationsComplementaires.signaletiquePP.prenom", source = "personPhysique.prenom")
    @Mapping(target = "informationsComplementaires.signaletiquePP.dateNaissance", source = "personPhysique.dateDeNaissance")
    @Mapping(target = "informationsComplementaires.signaletiquePP.libelleCivilite", source = "personPhysique.civilite")

    @Mapping(target = "informationsComplementaires.dossiersCommunication.emails.libelleEmail", source = "personPhysique.emailPro")

    @Mapping(target = "informationsComplementaires.informationsContrat.raisonSociale", source = "contrat.raisonSocialeFront")
    @Mapping(target = "informationsComplementaires.informationsContrat.numeroExterneContrat", source = "contrat.id")
    @Mapping(target = "informationsComplementaires.informationsContrat.libelleCategoriePersonnel", source = "contrat.college")
    @Mapping(target = "informationsComplementaires.liensPersonnes.libelleTypeLienPersonnes",constant = "")

    @Mapping(target = "affiliationContrat.dateSaisieAffiliation", source = "contrat.dateAffiliation")

    @Mapping(target = "clauseContrat.codeTypeClauseBenef", source = "clauseBeneficiaire")
    @Mapping(target = "clauseContrat.descClauseBenef", source = "clauseBeneficiaireDescription")
    @Mapping(source = "demande", target = "repartitionStructureInvestissement", qualifiedByName = "mapRepartitionStructureInvestissement")

    public abstract FormulaireBIA createFormulaireBIA(DemandeCreationSigElecBIA demande);

    @Named("mapRepartitionStructureInvestissement")
    public StructureInvestissementType createRepartitionStructureInvestissement(DemandeCreationSigElecBIA dto) {
        List<SupportFinancierDto> supports = dto.getSupports();
        StructureInvestissementType structureInvestissementType = new StructureInvestissementType();

        List<OccurenceStructureInvestissementType> occurenceStructureInvestissementTypes = new ArrayList<>();
        BigDecimal montant = null;
        if (CollectionUtils.isNotEmpty(supports)) {
            //le parent de tous les supports est toujours le même
            List<SupportFinancierDto> supportsWithParents = supports.stream()
                    .filter(support -> support.getContributionInvParent() != null)
                    .collect(Collectors.toList());
            if(CollectionUtils.isNotEmpty(supportsWithParents)){
                occurenceStructureInvestissementTypes.add(occurenceStructureInvestissementTypeMapper
                        .mapContributionInvToOccurenceStructureInvestissementType(supportsWithParents.get(0).getContributionInvParent(), montant));
            }
             supports.forEach(supportFinancierDto -> {
                if (supportFinancierDto.getContributionInvParent() != null) {
                    IdentificationStructureInvestissementType identificationStructureInvestissementType = new IdentificationStructureInvestissementType();
                    identificationStructureInvestissementType.setIdentifiantStructureInvestissement(
                            supportFinancierDto.getContributionInvParent().getCommonFields().getParentId());
                    structureInvestissementType.setIdentificationStructureInvestissement(
                            identificationStructureInvestissementType);
                }
                occurenceStructureInvestissementTypes.add(occurenceStructureInvestissementTypeMapper
                        .mapSupportFinancierDtoToOccurenceStructureInvestissementType(supportFinancierDto, montant));
            });

            structureInvestissementType.getOccurenceStructureInvestissement().addAll(occurenceStructureInvestissementTypes);

        }
        return structureInvestissementType;
    }

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireBIA formBIA = this.createFormulaireBIA((DemandeCreationSigElecBIA) demandeSigElec);
        if (formBIA.getIdentificationContratDansSilo() != null && formBIA.getIdentificationAffiliationDansSilo() != null) {
            formsMap.put(getCle(
                    formBIA.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    formBIA.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    formBIA.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormBia(formBIA));
        }
    }
}
