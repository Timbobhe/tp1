package fr.ag2rlamondiale.ecrs.dto.reclamation;

public enum State {
    OK, KO, LIMITED
}
