package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;

public interface IConfirmationEmailFacade {
    String createConfirmation(String email, String numPers, CodeSiloType coSilo);
}
