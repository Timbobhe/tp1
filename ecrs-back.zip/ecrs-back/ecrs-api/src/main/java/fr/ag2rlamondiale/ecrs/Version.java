package fr.ag2rlamondiale.ecrs;

import fr.ag2rlamondiale.trm.CoreConfig;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import java.util.Properties;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;

public class Version {
    private static final String MAVEN_GROUP_ID = "fr.ag2rlamondiale.ecrs";
    private static final String MAVEN_ARTIFACT_ID = "ecrs-api";
    public static final String UNKNOWN_VERSION = "unknown";

    private Version() {
        // ignore
    }

    public static synchronized String getVersion() {
        final Class<Version> clazz = Version.class;
        String version1 = versionFromSourcePom();
        if (version1 != null) return version1;

        // Try to get version number from maven properties in jar's META-INF
        String versionFromMavenProperties = getVersionFromMavenProperties(clazz, MAVEN_GROUP_ID, MAVEN_ARTIFACT_ID);
        if (!UNKNOWN_VERSION.equals(versionFromMavenProperties)) {
            return versionFromMavenProperties;
        }


        // Fallback to using Java API to get version from MANIFEST.MF
        String version = null;
        Package pkg = clazz.getPackage();
        if (pkg != null) {
            version = pkg.getImplementationVersion();
            if (version == null) {
                version = pkg.getSpecificationVersion();
            }
        }
        version = version == null ? "" : version.trim();
        return version.isEmpty() ? UNKNOWN_VERSION : version;
    }


    private static String versionFromSourcePom() {
        final Class<Version> clazz = Version.class;
        // Try to get version number from pom.xml (available in Eclipse)
        try {
            String className = clazz.getName();
            String classfileName = "/" + className.replace('.', '/') + ".class";
            URL classfileResource = clazz.getResource(classfileName);
            if (classfileResource != null) {
                Path absolutePackagePath = Paths.get(classfileResource.toURI())
                        .getParent();
                int packagePathSegments = className.length()
                        - className.replace(".", "").length();
                // Remove package segments from path, plus two more levels
                // for "target/classes", which is the standard location for
                // classes in Eclipse.
                Path path = absolutePackagePath;
                for (int i = 0, segmentsToRemove = packagePathSegments + 2;
                     i < segmentsToRemove; i++) {
                    path = path.getParent();
                }
                String version = getVersionFromPom(path, "/project/parent/version");
                if (version != null) return version;
            }
        } catch (Exception e) {
            // Ignore
        }
        return null;
    }

    private static String getVersionFromPom(Path path, String versionPath) throws IOException, SAXException, ParserConfigurationException, XPathExpressionException {
        Path pom = path.resolve("pom.xml");
        try (InputStream is = Files.newInputStream(pom)) {
            final DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
            df.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            df.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            Document doc = df.newDocumentBuilder().parse(is);
            doc.getDocumentElement().normalize();
            String version = (String) XPathFactory.newInstance()
                    .newXPath().compile(versionPath)
                    .evaluate(doc, XPathConstants.STRING);
            if (version != null) {
                version = version.trim();
                if (!version.isEmpty()) {
                    return version;
                }
            }
        }
        return null;
    }


    public static String getTrmVersion() {
        return getVersionFromMavenProperties(CoreConfig.class, "fr.ag2rlamondiale.transversemetier", "trm-core");
    }

    public static String getVersionFromMavenProperties(Class<?> clazz, String groupId, String artifactId) {

        final String pomPropertiesLocation = "/META-INF/maven/" + groupId + "/" + artifactId + "/pom.properties";

        // Try to get version number from maven properties in jar's META-INF
        try (InputStream is = clazz.getResourceAsStream(pomPropertiesLocation)) {
            if (is != null) {
                Properties p = new Properties();
                p.load(is);
                String version = p.getProperty("version", "").trim();
                if (!version.isEmpty()) {
                    return version;
                }
            }
        } catch (Exception ignore) {
        }

        return UNKNOWN_VERSION;
    }


}
