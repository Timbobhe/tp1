package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;

import java.util.Collection;
import java.util.List;

public interface ISujetFacade {

    List<SujetDto> getSujets();

    Collection<LectureSujetDto> getSujetsSelectionnesParUtilisateur() throws TechnicalException;

    Collection<LectureSujetDto> getObjectifsParUtilisateur() throws TechnicalException;

    Collection<LectureSujetDto> createSujetParUtilisateur(List<Integer> idSujets) throws TechnicalException;

    LectureSujetDto updateSujetLuParUtilisateur(Integer idSujet);
}
