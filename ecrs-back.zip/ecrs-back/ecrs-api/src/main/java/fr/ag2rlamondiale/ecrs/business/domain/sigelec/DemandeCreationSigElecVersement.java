package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.versement.RibStatusType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementModeDePaiementType;
import fr.ag2rlamondiale.rib.domain.sigelec.FormulaireModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public abstract class DemandeCreationSigElecVersement extends DemandeCreationSigElec<ContratHeader> {
    private RibDto coordonneesBancairesDto;
    private VersementModeDePaiementType modePaiement;
    private Date dateDebutVersement;
    private Date dateFinVersement;
    private List<SupportFinancierDto> supports;
    private RibStatusType ribStatusType;
    FormulaireModificationCoordonneesBancairesDto FormulaireModificationCoordonneesBancairesDto;
}
