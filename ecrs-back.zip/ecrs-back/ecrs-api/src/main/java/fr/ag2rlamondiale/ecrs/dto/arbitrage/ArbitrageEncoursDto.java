package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportType;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ArbitrageEncoursDto {
    private String code;
    private String nom;
    private boolean hasNif;

    private int id;
    private BigDecimal avoirEnEuro;
    private BigDecimal avoirEnPourcentage;
    private BigDecimal repartition;
    private OccurStructInvDto supportParent;
    private SupportType supportType;
    private boolean isDirty;
}
