package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.domain.SujetConstants;
import fr.ag2rlamondiale.ecrs.business.even.EreConfEvenGenerator;
import fr.ag2rlamondiale.ecrs.business.even.EreVdppEvenGenerator;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import fr.ag2rlamondiale.ecrs.mapping.SujetMapper;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.rest.ISujetRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestListJson;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Slf4j
@Service
public class SujetFacadeImpl implements ISujetFacade {

    @Autowired
    private ISujetRestClient sujetRestClient;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private SujetMapper sujetMapper;

    @Autowired
    private IBiaFacade biaFacade;

    @Autowired
    private EreVdppEvenGenerator ereVdppEvenGenerator;

    @Autowired
    private EreConfEvenGenerator ereConfEvenGenerator;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private IEvenementFacade evenementFacade;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Override
    public List<SujetDto> getSujets() {
        final Set<CodeSiloType> silos = new HashSet<>(userContextHolder.get().getSilos());
        final List<SujetJson> sujetJsonList = sujetRestClient.getSujets(silos);
        return sujetJsonList.stream().map(sujetJson -> sujetMapper.toSujetDto(sujetJson))
                .collect(Collectors.toList());
    }

    @Override
    public Collection<LectureSujetDto> getSujetsSelectionnesParUtilisateur() throws TechnicalException {
        final Map<Integer, LectureSujetDto> sujets = getSujets().stream()
                .collect(Collectors.toMap(SujetDto::getIdSujet, sujet ->
                        sujetMapper.toLectureSujetDto(sujet, userContextHolder.get().getIdGdi())));

        List<LectureSujetJson> lectureSujetJsonList = sujetRestClient.getSujetsParUtilisateur(sujetRequest(0));
        Map<Integer, LectureSujetDto> mapParent = new HashMap<>();
        for (LectureSujetJson lectureSujetJson : lectureSujetJsonList) {
            if (lectureSujetJson.getSujet().getIdSujetParent() == null) {
                // parent
                final LectureSujetDto dto = mapParent.computeIfAbsent(lectureSujetJson.getSujet().getIdSujet(),
                        i -> new LectureSujetDto());
                sujetMapper.map(lectureSujetJson, dto);
            } else {
                // enfant
                final LectureSujetDto parent = mapParent.computeIfAbsent(lectureSujetJson.getSujet().getIdSujetParent(),
                        sujets::get);
                LectureSujetDto enfant = sujetMapper.toLectureSujetDto(lectureSujetJson);
                parent.getSousSujets().add(enfant);
            }
        }
        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();

        doIfSaisieBiaPossible(blocagesClient, () -> mapParent.put(SujetConstants.ID_SUJET_REALISER_BIA, buildLectureSujetRealiserMonBIA()));

        doIfVdppOrConfNonEffectue((evenConf, evenVdpp) -> mapParent.put(SujetConstants.ID_SUJET_VERIFICATION_IDENTITE, buildLectureSujetVerificationIdentite(evenConf, evenVdpp)));

        // tri des sujets par ordre croissant des ID
        return mapParent.entrySet().stream().sorted(Map.Entry.comparingByKey()).collect(Collectors
                        .toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new))
                .values();
    }


    private void doIfSaisieBiaPossible(InfosBlocagesClient blocagesClient, Runnable runnable) {
        try {
            Compartiment compartiment =
                    contratFacade.rechercherCompartimentEREPlusRecent(CompartimentType.C3);
            if (compartiment == null) {
                return;
            }

            ContratHeader contratHeader = compartiment.getContratHeader();
            if (blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.COMPLETER_BIA)) {
                return;
            }

            boolean biaEffectue = biaFacade.isBiaEffectue(contratHeader);
            boolean modifDonneesPersoEnCours = false;
            if (userContextHolder.get().getNumeroPersonneEre() != null) {
                modifDonneesPersoEnCours = workflowFacade.hasDemandeMdpEncours(userContextHolder.get().getNumeroPersonneEre());
            }
            boolean saisieBiaPossible = !biaEffectue && !modifDonneesPersoEnCours;
            if (saisieBiaPossible) {
                runnable.run();
            }
        } catch (TechnicalException | TechnicalRuntimeException e) {
            log.error("Erreur \u00e0 la determination si BIA effectu\u00e9", e);
        }
    }

    private void doIfVdppOrConfNonEffectue(BiFunction<EvenementJson, EvenementJson, Object> consumer) throws TechnicalException {
        final EvenementJson evenementConf = evenementFacade.generateNextEvenement(TypeEven.CONFIRMATION_DONNEES_PERSO.toPredicate(), true, false);

        final EvenementJson evenementVdpp;
        if (evenementConf == null) {
            evenementVdpp = evenementFacade.generateNextEvenement(TypeEven.VALIDATION_PERIODIQUE_DONNEES_PERSO.toPredicate(), true, false);
        } else {
            evenementVdpp = null;
        }

        consumer.apply(evenementConf, evenementVdpp);
    }

    @Override
    public Collection<LectureSujetDto> getObjectifsParUtilisateur() throws TechnicalException {
        return getSujetsSelectionnesParUtilisateur().stream()
                // On enlève les sujets dont tous les sous sujets ont été lus
                .filter(lectureSujet -> !lectureSujet.getSousSujets().stream()
                        .allMatch(LectureSujetDto::estLu)).collect(Collectors.toList());
    }

    @Override
    public Collection<LectureSujetDto> createSujetParUtilisateur(List<Integer> idSujets) throws TechnicalException {
        sujetRestClient.createSujetParUtilisateur(sujetRequest(idSujets));

        return getObjectifsParUtilisateur();
    }

    @Override
    public LectureSujetDto updateSujetLuParUtilisateur(Integer idSujet) {
        final LectureSujetJson lectureSujetJson =
                sujetRestClient.updateSujetLuParUtilisateur(sujetRequest(idSujet));
        return sujetMapper.toLectureSujetDto(lectureSujetJson);
    }

    private SujetRequestJson sujetRequest(Integer idSujet) {
        return new SujetRequestJson(userContextHolder.get().getIdGdi(), idSujet);
    }

    private SujetRequestListJson sujetRequest(List<Integer> idSujets) {
        return SujetRequestListJson.builder().idGdi(userContextHolder.get().getIdGdi()).idSujets(
                        idSujets.stream().filter(buildBiaVdppConfExcludePredicate()).collect(Collectors.toList()))
                .build();
    }

    private Predicate<Integer> buildBiaVdppConfExcludePredicate() {
        return id -> !id.equals(SujetConstants.ID_SUJET_REALISER_BIA) && !id.equals(SujetConstants.ID_SOUS_SUJET_REALISER_BIA)
                && !id.equals(SujetConstants.ID_SUJET_VERIFICATION_IDENTITE) && !id.equals(SujetConstants.ID_SOUS_SUJET_VDPP)
                && !id.equals(SujetConstants.ID_SOUS_SUJET_CONF);
    }

    private LectureSujetDto buildLectureSujetRealiserMonBIA() {
        String idGdi = userContextHolder.get().getIdGdi();
        return LectureSujetDto.builder()
                .idGdi(idGdi)
                .idSujet(SujetConstants.ID_SUJET_REALISER_BIA)
                .titre(SujetConstants.TITRE_REALISER_BIA)
                .typeSujet(SujetConstants.TYPE_REALISER_BIA)
                .sousSujets(buildSousSujetRealiserMonBIA(idGdi))
                .build();
    }

    private LectureSujetDto buildLectureSujetVerificationIdentite(EvenementJson evenConf, EvenementJson evenVdpp) {
        String idGdi = userContextHolder.get().getIdGdi();
        return LectureSujetDto.builder()
                .idGdi(idGdi)
                .idSujet(SujetConstants.ID_SUJET_VERIFICATION_IDENTITE)
                .titre(SujetConstants.TITRE_VERIFICATION_IDENTITE)
                .typeSujet(SujetConstants.TYPE_VERIFICATION_IDENTITE)
                .sousSujets(buildSousSujetsVerificationIdentite(idGdi, evenConf, evenVdpp))
                .build();
    }

    private List<LectureSujetDto> buildSousSujetRealiserMonBIA(String idGdi) {
        List<LectureSujetDto> sousSujetsBIA = new ArrayList<>();
        sousSujetsBIA.add(LectureSujetDto.builder()
                .idGdi(idGdi)
                .idSujet(SujetConstants.ID_SOUS_SUJET_REALISER_BIA)
                .idSujetParent(SujetConstants.ID_SUJET_REALISER_BIA)
                .titre(SujetConstants.TITRE_SOUS_SUJET_BIA)
                .url(FonctionnaliteType.COMPLETER_BIA.getLabel())
                .typeSujet(SujetConstants.TYPE_REALISER_BIA)
                .sousSujets(new ArrayList<>())
                .build());
        return sousSujetsBIA;
    }

    public List<LectureSujetDto> buildSousSujetsVerificationIdentite(String idGdi, EvenementJson evenConf, EvenementJson evenVdpp) {
        List<LectureSujetDto> sousSujetsVerificationIdentite = new ArrayList<>();
        if (evenConf != null) {
            sousSujetsVerificationIdentite.add(LectureSujetDto.builder()
                    .idGdi(idGdi)
                    .idSujet(SujetConstants.ID_SOUS_SUJET_CONF)
                    .idSujetParent(SujetConstants.ID_SUJET_VERIFICATION_IDENTITE)
                    .titre(SujetConstants.TITRE_SOUS_SUJET_CONF)
                    .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                    .typeSujet(SujetConstants.TYPE_VERIFICATION_IDENTITE)
                    .sousSujets(new ArrayList<>())
                    .build());
        } else if (evenVdpp != null) {
            sousSujetsVerificationIdentite.add(LectureSujetDto.builder()
                    .idGdi(idGdi)
                    .idSujet(SujetConstants.ID_SOUS_SUJET_VDPP)
                    .idSujetParent(SujetConstants.ID_SUJET_VERIFICATION_IDENTITE)
                    .titre(SujetConstants.TITRE_SOUS_SUJET_VDPP)
                    .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                    .typeSujet(SujetConstants.TYPE_VERIFICATION_IDENTITE)
                    .sousSujets(new ArrayList<>())
                    .build());
        }
        return sousSujetsVerificationIdentite;
    }

}
