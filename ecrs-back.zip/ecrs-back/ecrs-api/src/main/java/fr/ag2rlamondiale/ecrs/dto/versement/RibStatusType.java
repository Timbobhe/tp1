package fr.ag2rlamondiale.ecrs.dto.versement;

public enum RibStatusType {
    KNOWN,
    NEW
}
