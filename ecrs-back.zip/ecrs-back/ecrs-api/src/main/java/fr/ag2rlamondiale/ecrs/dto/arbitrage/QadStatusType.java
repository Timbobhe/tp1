package fr.ag2rlamondiale.ecrs.dto.arbitrage;

public enum QadStatusType {
    OBLIGATOIRE,
    FACULTATIF,
    IMPOSSIBLE;
}
