package fr.ag2rlamondiale.ecrs.dto.simulateur;

import fr.ag2rlamondiale.trm.domain.FiscaliteType;

/**
 * Sous ensemble des fiscalités pour lesquelles on gère le simulateur
 */
public enum FiscaliteSimuType {

    /**
     * Uniquement ERE
     */
    ART83,

    /**
     * Uniquement MDP
     */
    PERP,

    /**
     * Uniquement MDP
     */
    MADELIN;

    public static FiscaliteSimuType from(FiscaliteType fiscaliteType) {
        if (FiscaliteType.FISCMAD.equals(fiscaliteType)) {
            return MADELIN;
        }
        if (FiscaliteType.ART83.equals(fiscaliteType)) {
            return ART83;
        }
        if (FiscaliteType.PERP.equals(fiscaliteType)) {
            return PERP;
        }
        return null;
    }

}
