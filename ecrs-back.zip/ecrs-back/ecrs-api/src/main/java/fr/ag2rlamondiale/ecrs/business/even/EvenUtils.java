package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.apache.commons.collections4.CollectionUtils;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.PerimetreType.*;
import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.EXC;
import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.INC;
import static java.time.temporal.ChronoUnit.DAYS;

public class EvenUtils {

    /**
     * Détermine si un Even a été présenté à la date du jour qq soit l'état de l'EVEN.
     *
     * @param evenements
     * @return true s'il n'y a aucun EVEN dont ld date debut ou la date de fin = TODAY
     */
    public static boolean pasEncorePresenteAujourdhui(Collection<EvenementJson> evenements) {
        if (evenements == null || evenements.isEmpty()) {
            return true;
        }

        Instant today = Instant.now().truncatedTo(DAYS);
        for (EvenementJson even : evenements) {
            final Date dateDebut = even.getDateDebut();
            if (dateDebut != null && dateDebut.toInstant().truncatedTo(DAYS).equals(today)) {
                return false;
            }

            final Date dateFin = even.getDateFin();
            if (dateFin != null && dateFin.toInstant().truncatedTo(DAYS).equals(today)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Détermine si un des évènements liés à un type a déjà été traité.
     *
     * @param evenements
     * @return
     */
    public static boolean dejaTraite(Collection<EvenementJson> evenements) {
        if (evenements != null) {
            for (EvenementJson evt : evenements) {
                if (EtatTraitementType.TRAI == evt.getEtatTraitement()) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Détermine si on n'a pas déjà atteint le nombre max de déclenchements pour un type d'évènement
     * donné.
     *
     * @param typeEvenement
     * @param evenements
     * @return
     */
    public static boolean neDepassePasNombreMaxDeclenchements(TypeEvenementJson typeEvenement,
                                                              List<EvenementJson> evenements) {
        // Il s'agit d'un type d'évènement sans Nombre de déclenchement Max
        if (typeEvenement.getNbDeclenchementsMaxPeriode() == null || evenements == null) {
            return true;
        }
        List<EvenementJson> evtsDansLaPeriodeDeDeclenchement =
                getEvenementsSurNbjoursGlissants(evenements, typeEvenement.getPeriodeDeclenchement());
        return typeEvenement.getNbDeclenchementsMaxPeriode() > evtsDansLaPeriodeDeDeclenchement.size();
    }

    /**
     * Détermine si le délai de réactivation est respecté pour le type d'évènement donné.
     *
     * @param typeEvenement
     * @param evenements
     * @return
     */
    public static boolean respecteDelaiReactivation(TypeEvenementJson typeEvenement,
            Collection<EvenementJson> evenements) {
        // Si aucun délai avant réactivation n'est paramétré pour le type d'évènement
        if (typeEvenement.getDelaiAvantReactivation() == null || evenements == null) {
            return true;
        }

        Instant today = Instant.now().truncatedTo(DAYS);
        final Instant lastDate = getLastDate(evenements);
        if (lastDate == null) {
            return true;
        }

        return today.isAfter(lastDate.plus(typeEvenement.getDelaiAvantReactivation(), DAYS));
    }

    /**
     * Renvoi la date de début la plus récente parmi celles des évènements passés en paramètre.
     *
     * @param evenements
     * @return
     */
    public static Instant getLastDate(Collection<EvenementJson> evenements) {
        Instant lastDate = null;
        if (evenements != null) {
            for (EvenementJson evt : evenements) {
                Instant dateEvenement = evt.getDateDebut().toInstant();
                if (lastDate == null || dateEvenement.isAfter(lastDate)) {
                    lastDate = dateEvenement;
                }
            }
        }
        return lastDate;
    }

    /**
     * Vérifier que le dernier EVEN n'a pa s été délenché depuis #delaiDeclenchement JOURS
     *
     * @param evts
     * @param delaiDeclenchement
     * @return true si le dernier déclenchement date de plus de XX Jours (par rapport à la date du jour), false sinon
     */
    public static boolean evenementDeclencheDepuis(List<EvenementJson> evts, Integer delaiDeclenchement) {
        if (delaiDeclenchement == null || CollectionUtils.isEmpty(evts)) {
            return true;
        }
        Instant today = Instant.now().truncatedTo(DAYS);
        final Instant lastDate = getLastDate(evts);
        if (lastDate == null) {
            return true;
        }

        return today.isAfter(lastDate.plus(delaiDeclenchement, DAYS));
    }

    /**
     * Renvoi les évènements de la liste dont la date de début est incluse dans les nbJours derniers
     * jours.
     *
     * @param evenements
     * @param nbJours
     * @return
     */
    public static List<EvenementJson> getEvenementsSurNbjoursGlissants(List<EvenementJson> evenements,
            Integer nbJours) {
        if (nbJours == null || evenements == null) {
            return evenements;
        }

        List<EvenementJson> evtsDansLaPeriode = new ArrayList<>();
        Instant today = Instant.now().truncatedTo(DAYS);
        Instant evtDateDebut;
        for (EvenementJson evt : evenements) {
            evtDateDebut = evt.getDateDebut().toInstant().truncatedTo(DAYS);
            if (evtDateDebut.plus(nbJours, DAYS).isAfter(today)) {
                evtsDansLaPeriode.add(evt);
            }
        }
        return evtsDansLaPeriode;
    }

    /**
     * Vérifie si les périmètres d'evenement concernent la PP
     *
     * @param idGdi
     * @param numPersonne
     * @param perimetresEvenements
     * @return
     */
    public static boolean isPersonneAutorisee(String idGdi, String numPersonne,
            List<PerimetreEvenementJson> perimetresEvenements) {
        if (CollectionUtils.isEmpty(perimetresEvenements)) {
            return true;
        }

        final boolean inclusPerimetrePersonne = isOperationPerimetrePersonne(INC, perimetresEvenements);
        final boolean exlusPerimetrePersonne = isOperationPerimetrePersonne(EXC, perimetresEvenements);

        if (!inclusPerimetrePersonne && !exlusPerimetrePersonne) {
            // Les périmètres ne concernent pas les Personnes
            return true;
        }

        final boolean inclusPersonne =
                inclusPerimetrePersonne && isOperationPersonneConnectee(INC, idGdi, numPersonne, perimetresEvenements);
        final boolean exclusPersonne =
                exlusPerimetrePersonne && isOperationPersonneConnectee(EXC, idGdi, numPersonne, perimetresEvenements);

        if (inclusPerimetrePersonne && exlusPerimetrePersonne) {
            return inclusPersonne;
        }

        if (!inclusPerimetrePersonne) {
            return !exclusPersonne;
        }

        return inclusPersonne;
    }

    public static boolean isOperationPersonneConnectee(OperationPerimetre operationPerimetre, String idGdi,
                                                       String numPersonne, List<PerimetreEvenementJson> perimetresEvenements) {
        return operationPerimetre.anyMatch(perimetresEvenements,
                perimetre -> perimetre.getTypePerimetre() == TOUT || PERSONNE.matchPerimetre(numPersonne, perimetre)
                        || IDGDI.matchPerimetre(idGdi, perimetre));
    }

    public static boolean isOperationPerimetrePersonne(OperationPerimetre operationPerimetre,
            List<PerimetreEvenementJson> perimetresEvenements) {
        return operationPerimetre.anyMatch(perimetresEvenements, perimete -> perimete.getTypePerimetre().isPersonne());
    }

    /**
     * Vérifie si les périmètres d'evenement concernent le Contrat
     *
     * @param contrat
     * @param perimetresEvenements
     * @return
     */
    public static boolean isContratAutorise(ContratHeader contrat, List<PerimetreEvenementJson> perimetresEvenements) {
        if (!CollectionUtils.isNotEmpty(perimetresEvenements)) {
            return true;
        }


        final boolean inclusPerimetreContrat = isOperationPerimetreContrat(INC, perimetresEvenements);
        final boolean exlusPerimetreContrat = isOperationPerimetreContrat(EXC, perimetresEvenements);

        if (!inclusPerimetreContrat && !exlusPerimetreContrat) {
            // Les périmètres ne concernent pas les Contrats
            return true;
        }

        final String filiale = contrat.getCodeFiliale();
        final String numContrat = contrat.getId();
        final String produit = contrat.getTypeContrat() + "-" + contrat.getNumGenContrat() + "-" + contrat.getCodeFiliale();

        final boolean inclusContrat =
                inclusPerimetreContrat && isOperationContrat(INC, filiale, produit, numContrat, perimetresEvenements);
        final boolean exclusContrat =
                exlusPerimetreContrat && isOperationContrat(EXC, filiale, produit, numContrat, perimetresEvenements);

        if (inclusPerimetreContrat && exlusPerimetreContrat) {
            return inclusContrat;
        }

        if (!inclusPerimetreContrat) {
            return !exclusContrat;
        }

        return inclusContrat;
    }

    public static boolean isOperationContrat(OperationPerimetre operationPerimetre, String filiale, String produit,
            String numContrat, List<PerimetreEvenementJson> perimetresEvenements) {
        return operationPerimetre.anyMatch(perimetresEvenements,
                perimetre -> perimetre.getTypePerimetre() == TOUT || FILIALE.matchPerimetre(filiale, perimetre)
                        || PRODUIT.matchPerimetre(produit, perimetre) || CONTRAT.matchPerimetre(numContrat, perimetre));
    }

    public static boolean isOperationPerimetreContrat(OperationPerimetre operationPerimetre,
            List<PerimetreEvenementJson> perimetresEvenements) {
        return operationPerimetre.anyMatch(perimetresEvenements, perimete -> perimete.getTypePerimetre().isContrat());
    }

}
