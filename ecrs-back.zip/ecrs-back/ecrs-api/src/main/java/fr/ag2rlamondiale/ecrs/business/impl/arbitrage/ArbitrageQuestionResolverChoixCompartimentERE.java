package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.business.domain.structinv.SupportsInvNiveau1Contrat;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInvHelper;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_ARBITRER;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_QUESTION_COMPARTIMENT_TITRE;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_TOUT_CONTRAT;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_WARNING_MESSAGE_CHOIX_DIFFERENTS_PLACEMENTS_FINANCIERS_PO_PF;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_WARNING_MESSAGE_CONTRAT_BLOQUE;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_WARNING_MESSAGE_EPARGNE_ACQUISE_IMPOSSIBLE;

@Service
public class ArbitrageQuestionResolverChoixCompartimentERE implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Override
    public QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        return resolve(contratHeader, contexte);
    }

    /**
     * On passe le contexte pour le mettre &agrave; jour
     *
     * @param contratHeader
     * @param contexte
     * @return
     * @throws TechnicalException
     */
    public QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolve(ContratHeader contratHeader, ArbitrageContexteDto contexte) throws TechnicalException {
        final BaseContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratHeader.getContratId());
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();

        final StructInv structInv = structureInvFacade.consulterStructInv(contratHeader);

        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT)
                .jahiaDicoEntry(ARB_QUESTION_COMPARTIMENT_TITRE.name())
                .build());
        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_ARBITRER.name())
                .build());
        result.setData(new BlocageArbitrageContratDto());

        // Construction des choix compartiments avec gestion des r&egrave;gles de blocage (StrategieFinanciereImposee, PlacementsFinanciersIdentique)
        final List<ResponseDto<ChoixCompartimentDto>> responsesCompartiments = new ArrayList<>();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            final ResponseDto<ChoixCompartimentDto> response = ResponseDto.<ChoixCompartimentDto>builder()
                    .id(compartiment.getCompartimentId().toString())
                    .label(compartiment.getLabel())
                    .value(ChoixCompartimentDto.builder()
                                   .compartiment(contratParcoursMapper.map(compartiment, true))
                                   .build())
                    .build();
            completeResponse(response, compartiment, contratGeneral, structInv, contexte);
            responsesCompartiments.add(response);
        }

        // Question bloqu&eacute;e + aucune proposition => Le contrat sera bloqu&eacute;
        if (responsesCompartiments.stream().allMatch(c -> c.getValue().isStrategieFinanciereImposee())) {
            result.getData().setContratBloque(true);
            result.setShow(false);
            result.setWarningMessage(MessageDto.builder()
                    .jahiaDicoEntry(ARB_WARNING_MESSAGE_CONTRAT_BLOQUE.name())
                    .build());

            return result;
        }

        // Gestion du Retour selon ParamFluxStock pour NIE
        if (contratHeader.isPacte() && contexte.getParamFluxStock() != null && responsesCompartiments.stream().allMatch(ResponseDto::isDisabled)) {
            result.getData().setContratBloque(true);
            result.setShow(false);
            result.setWarningMessage(MessageDto.builder()
                    .jahiaDicoEntry(ARB_WARNING_MESSAGE_EPARGNE_ACQUISE_IMPOSSIBLE.name())
                    .build());

            return result;

        } else if (ParamFluxStock.FLUX == contexte.getParamFluxStock()) {
            // ParamFluxStock = flux => On ne garde que les C3
            final List<ResponseDto<ChoixCompartimentDto>> listeC3 = responsesCompartiments.stream()
                    .filter(r -> CompartimentType.C3.equals(r.getValue().getCompartiment().getCompartimentType()))
                    .collect(Collectors.toList());

            if (listeC3.size() == 1) {
                result.setDefaultValue(listeC3.get(0));
                result.setShow(false);
                contexte.update(ctx -> ctx.setCompartimentSelectionne(listeC3.get(0).getValue().getCompartiment().toCompartimentId()));
            } else {
                result.addAll(listeC3);
            }
            return result;
        }


        // Sinon
        else if (responsesCompartiments.size() == 1) {
            final ResponseDto<ChoixCompartimentDto> defaultValue = responsesCompartiments.get(0);
            result.setDefaultValue(defaultValue);
            result.setShow(false);
            contexte.update(ctx -> ctx.setCompartimentSelectionne(defaultValue.getValue().getCompartiment().toCompartimentId()));
            return result;
        }

        final EncoursDto encoursTotal = calculerEncoursContratFacade.getEncoursDto(contratHeader);

        final String labelTousCompartiments = ARB_TOUT_CONTRAT.name();

        final ResponseDto<ChoixCompartimentDto> tousCompartiments = ResponseDto.<ChoixCompartimentDto>builder()
                .id("tous-les-compartiments")
                .value(ChoixCompartimentDto.builder()
                        .tousCompartiments(true)
                        .encours(encoursTotal)
                        .placementsFinanciersDifferentsAutorises(contratGeneral.getOptContratEpargne().isAllowDifferentInvestmentsForVif())
                        .build())
                .jahiaDicoEntry(labelTousCompartiments)
                .build();

        // si arbitrage simplifié est activé pour le contrat
        if (contexte.isParcoursSimplifie()) {
            result.setDefaultValue(tousCompartiments);
            result.setShow(false);
            contexte.update(ctx -> ctx.setTousCompartimentsSelectionnes(true));
            return result;
        }


        if (!contratGeneral.getOptContratEpargne().isAllowDifferentInvestmentsForVif()) {
            result.setDefaultValue(tousCompartiments);
            result.setShow(false);
            result.setWarningMessage(MessageDto.builder()
                    .jahiaDicoEntry(ARB_WARNING_MESSAGE_CHOIX_DIFFERENTS_PLACEMENTS_FINANCIERS_PO_PF.name())
                    .build());
            contexte.update(ctx -> ctx.setTousCompartimentsSelectionnes(true));
            return result;
        }

        // S'il y a un choix impos&eacute; alors on ne peut pas rajouter "tous les compartiments"
        if (responsesCompartiments.stream().noneMatch(c -> c.getValue().isStrategieFinanciereImposee())
                && !isPacteAvecSupportsDifferentsParCompartiment(contratHeader)) {
            result.add(tousCompartiments);
        }

        result.addAll(responsesCompartiments);

        return result;
    }

    private boolean isPacteAvecSupportsDifferentsParCompartiment(ContratHeader contratHeader) {
        if (contratHeader.isEre() && contratHeader.isPacte()) {
            final SupportsInvNiveau1Contrat premierNiveau = structureInvFacade.getGrillesProfilsPremierNiveau(contratHeader, null, false);
            return premierNiveau.getListePourCompartiments().size() >= 2;
        }

        return false;
    }

    /**
     * Construction du choix compartiment avec gestion des r&egrave;gles de blocage (StrategieFinanciereImposee, PlacementsFinanciersIdentique, {@link ParamFluxStock})
     *
     * @param response
     * @param compartiment
     * @param contratGeneral
     * @param structInv
     * @param contexte
     */
    private void completeResponse(ResponseDto<ChoixCompartimentDto> response, Compartiment compartiment, ContratGeneral contratGeneral, StructInv structInv, ArbitrageContexteDto contexte) {
        // RM11 Cependant, la question n&rsquo;est pas &agrave; poser si le contrat ne permet pas d&rsquo;effectuer
        // des choix diff&eacute;rents de placements financiers entre part obligatoire et part facultative.
        if (!compartiment.isPacte() && !contratGeneral.getOptContratEpargne().isAllowDifferentInvestmentsForVif()) {
            response.getValue().setPlacementsFinanciersIdentique(true);
            response.setDisabled(true);
            return;
        }

        // RM11&rsquo; Cette question n&rsquo;est pas &agrave; poser non plus si une des parts n&rsquo;est pas arbitrable alors que l&rsquo;autre part peut &ecirc;tre arbitr&eacute;e.
        // Il y a des contrats pour lesquels la strat&eacute;gie financi&egrave;re est impos&eacute;e sur une des parts (obligatoire ou facultative) mais &agrave; choix multiple sur l&rsquo;autre part.
        if (!compartiment.isPacte()) {
            final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), compartiment.isPacte());
            final boolean nonDerogeable = contributionTypes.stream()
                    .anyMatch(contributionType -> !StructInvHelper.isCompartimentDerogeable(structInv, contributionType));

            if (nonDerogeable) {
                response.getValue().setStrategieFinanciereImposee(true);
                response.setDisabled(true);
                response.setLabel("Les dispositions financi\u00E8res de votre contrat ne vous permettent pas de modifier les choix de placements financiers pour " + compartiment.getType().getDefaultLabel());
            }
        }

        // Si ParamFluxStock = stock alors on ne conserve que les compartiments avec un encours non vide
        if (compartiment.isPacte() && ParamFluxStock.STOCK == contexte.getParamFluxStock()) {
            final EncoursDto encours = response.getValue().getCompartiment().getEncours();
            if (encours == null || encours.estVide()) {
                response.setDisabled(true);
                response.setWarningMessage(MessageDto.builder()
                        .label(compartiment.getLabel() + " indisponible pour arbitrage du stock")
                        .build());
            }

        }
        // Si ParamFluxStock = flux alors on ne conserve que les compartiments C3
        else if (compartiment.isPacte() && ParamFluxStock.FLUX == contexte.getParamFluxStock() && !CompartimentType.C3.equals(compartiment.getType())) {
            response.setDisabled(true);
        }
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT.equals(questionType) && contexte.getContratSelectionne() != null && contexte.getContratSelectionne().is(CodeSiloType.ERE);
    }
}
