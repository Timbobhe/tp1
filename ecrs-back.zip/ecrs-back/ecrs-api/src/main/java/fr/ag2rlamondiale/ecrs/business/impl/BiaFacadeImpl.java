package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecBIA;
import fr.ag2rlamondiale.ecrs.business.impl.document.QadDocRefType;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.JahiaContextDto;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaStartDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.bia.InfoBiaContratDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.trm.business.*;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.ClauseBeneficiaireType;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.AFFILIATION_SANS_BIA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.REMIS_ENVIGEUR_SANS_BIA;

@Service
public class BiaFacadeImpl implements IBiaFacade {
    private static final Set<String> ETATS_SANS_BIA = Sets.newHashSet(AFFILIATION_SANS_BIA.getCodeValue(),
                                                                      REMIS_ENVIGEUR_SANS_BIA.getCodeValue());

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private ISigElecFacade sigElecfacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IJahiaFacade jahiaFacade;

    @Autowired
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private IDownloadDocumentFacade downloadDocumentFacade;

    @Autowired
    private IParcoursSimplifieFacade parcoursSimplifieFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Override
    public BiaStartDto startBia() throws TechnicalException {
        List<ContratHeader> contratHeaders = contratFacade.rechercherContratsEre();

        final InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();

        List<ContratCompartimentTestBia> compartimentsSansBia = contratHeaders.stream()
                .filter(c -> !infosBlocagesClient.isFonctionnaliteBloqueePourContrat(c.getId(), FonctionnaliteType.COMPLETER_BIA))
                .map(c -> handleException(() -> new ContratCompartimentTestBia(c, biaEnCours(c))))
                .filter(ct -> !ct.res.isEncours())
                .flatMap(ct -> ct.compartiments(CompartimentType.C3))
                .filter(ct -> !biaEffectue(ct.compartiment))
                .collect(Collectors.toList());

        List<InfoBiaContratDto> infoBiaContrats = compartimentsSansBia
                .stream()
                .map(ct -> handleException(() -> this.buildInfoBiaContratDto(ct.compartiment, infosBlocagesClient)))
                .collect(Collectors.toList());

        return BiaStartDto.builder()
                .bias(infoBiaContrats)
                .biaEnCours(compartimentsSansBia.stream().anyMatch(ct -> !ct.res.isSigElecEncoursNonSigne()))
                .sigElecOff(infoBiaContrats.stream().allMatch(InfoBiaContratDto::isSigElecOff))
                .build();
    }

    private InfoBiaContratDto buildInfoBiaContratDto(Compartiment compartiment, InfosBlocagesClient infosBlocagesClient) throws TechnicalException {
        final ContratHeader contratHeader = compartiment.getContratHeader();

        final boolean simplifie = parcoursSimplifieFacade.isParcoursSimplifieActivate(contratHeader.getId(), FonctionnaliteType.BIA_SIMPLIFIE);

        ContratParcoursDto contrat = contratParcoursMapper.map(compartiment);

        return InfoBiaContratDto.builder()
                .contrat(contrat)
                .isParcoursSimplifie(simplifie)
                .contextJahia(JahiaContextDto.builder().parcoursSimplifie(simplifie).build())
                .sigElecOff(infosBlocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.SIGELEC_COMPLETER_BIA))
                .build();

    }

    /**
     * Le bia est considéré effectué sur un contrat s'il a été fait sur tous les compartiments C3
     * Si le contrat ne possède pas de compartiment C3 il est également considéré comme effectué
     */
    @Override
    public ResultParcoursEffectueDto testBiaEffectue(ContratHeader contrat) throws TechnicalException {
        boolean biaEffectue = contrat.compartiments(CompartimentType.C3)
                .stream()
                .allMatch(this::biaEffectue);

        if (biaEffectue) {
            return ResultParcoursEffectueDto.builder().contratHeader(contrat).parcoursEffectue(true).build();
        }

        return biaEnCours(contrat);
    }

    private boolean biaEffectue(Compartiment compartiment) {
        return !ETATS_SANS_BIA.contains(compartiment.getEtatCompartiment().getCodeValue());
    }

    private ResultParcoursEffectueDto biaEnCours(ContratHeader contrat) throws WorkflowException {
        final ResultParcoursEffectueDto res = hasDemandeBiaInProgress(contrat);
        if (res.isEncours()) {
            return res;
        }

        return ResultParcoursEffectueDto.builder().contratHeader(contrat)
                                                  .workflowParcoursEncours(hasDemandeBiaEncours()).build();
    }

    @Override
    public boolean isBiaEffectue(ContratHeader contratHeader) throws TechnicalException {
        return testBiaEffectue(contratHeader).isParcoursEffectue();
    }


    @Override
    public String terminateBia(BiaTerminateDto biaTerminateDto, boolean isFrame)
            throws IOException, CommonException, JAXBException {
        final ContratId contratId = biaTerminateDto.getContratSelected().toContratId();
        final CompartimentId compartimentId = biaTerminateDto.getContratSelected().toCompartimentId();
        DocumentDto biaDocument = biaTerminateDto.getContenuBIA();
        DocumentDto qadDocument = biaTerminateDto.getContenuQAD();

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);

        final DocRefType docRefType = DocumentRefType.BIA_EN_LIGNE;

        DataDocumentContrat documentActeContrat = null;
        if (biaDocument != null && biaDocument.getHtmlContent() != null) {
            documentActeContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId, biaDocument, docRefType);
        }

        DataDocumentContrat documentQadContrat = null;
        if (qadDocument != null && qadDocument.getHtmlContent() != null) {
            final DocRefType qadDocRefType = QadDocRefType.getSpecificQadDoc(docRefType);
            documentQadContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId, qadDocument, qadDocRefType);
        }

        if (documentActeContrat != null) {
            DemandeCreationSigElecBIA demandeCreationSigElec = initDemandeCreationSigElecBIA(biaTerminateDto, contratHeader,
                                                                                             documentActeContrat, documentQadContrat);
            return sigElecfacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec,
                                                                          isFrame);
        } else {
            return null;
        }
    }

    private DemandeCreationSigElecBIA initDemandeCreationSigElecBIA(BiaTerminateDto biaTerminateDto, ContratHeader contratHeader,
                                                                    DataDocumentContrat documentActeContrat, DataDocumentContrat documentQadContrat)
            throws TechnicalException {

        final UserContext userContext = userContextHolder.get();

        final String numPersonne = contratHeader.getPersonId();

        DemandeCreationSigElecBIA demandeCreationSigElec = new DemandeCreationSigElecBIA();
        demandeCreationSigElec.add(documentActeContrat);

        if (documentQadContrat != null) {
            demandeCreationSigElec.add(documentQadContrat);
        }

        demandeCreationSigElec.setCodeSilo(contratHeader.getCodeSilo());
        demandeCreationSigElec.setTypeDonneeATraiter();
        demandeCreationSigElec.setCodeAssureur(contratHeader.getCodeAssureur());

        if (contratHeader.isPacte()) {
            demandeCreationSigElec.setCompartimentType(CompartimentType.C3);
        }
        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setAgrementsConventionDePreuve(documentActeContrat.getAgrementsConventionDePreuve());
        demandeCreationSigElec.setConventionDePreuveTitre(documentActeContrat.getConventionDePreuveTitre());

        demandeCreationSigElec.setIdentifiantAssure(documentActeContrat.getIdAssure());
        demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
        demandeCreationSigElec.setNumPP(numPersonne);
        demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo()));
        demandeCreationSigElec.setTypeOperation(OperationType.EBIA);
        if (biaTerminateDto.getClauseBeneficiaireSelected() != null) {
            demandeCreationSigElec.setClauseBeneficiaire(biaTerminateDto.getClauseBeneficiaireSelected().isClauseStandard()
                                                                 ? ClauseBeneficiaireType.STD.getCode() : ClauseBeneficiaireType.LIB.getCode());
            demandeCreationSigElec.setClauseBeneficiaireDescription(biaTerminateDto.getClauseBeneficiaireSelected().getContenuClause());
        }
        demandeCreationSigElec.setSupports(structureInvFacade.retrieveSupportFinancierList(
                contratHeader, Collections.singletonList(ContributionType.PART_PATRONALE), biaTerminateDto.getGestionFinanciereSelected(), FonctionnaliteType.COMPLETER_BIA, null));
        return demandeCreationSigElec;
    }

    private boolean hasDemandeBiaEncours() throws WorkflowException {
        String idPers = userContextHolder.get().getNumeroPersonneEre();
        return workflowFacade.hasDemandeEncours(idPers, DemandeWorkflowType.EXTRANET_BIA)
                || workflowFacade.hasDemandeEnCoursWithCodeAppli(idPers, DemandeWorkflowType.BIA, CodeApplicationType.ECRS.getCode());
    }

    private ResultParcoursEffectueDto hasDemandeBiaInProgress(ContratHeader contratHeader) {
        final String idGDI = userContextHolder.get().getIdGdi();
        final List<SigElecJson> demandesNonAnnules = sigElecfacade.getDemandesSigElecNonAnnule(idGDI, contratHeader.getId(), OperationType.EBIA);

        return ResultParcoursEffectueDto.builder()
                .contratHeader(contratHeader)
                .sigElecEncoursSigne(demandesNonAnnules.stream().anyMatch(dmd -> dmd.getEtatDmd().isSigne()))
                .sigElecEncoursNonSigne(demandesNonAnnules.stream().anyMatch(dmd -> !dmd.getEtatDmd().isSigne()))
                .build();
    }


    @NoArgsConstructor
    @AllArgsConstructor
    @Builder(toBuilder = true)
    @Data
    private static class ContratCompartimentTestBia {
        private ContratHeader contrat;
        private ResultParcoursEffectueDto res;
        private Compartiment compartiment;

        public ContratCompartimentTestBia(ContratHeader contrat, ResultParcoursEffectueDto res) {
            this.contrat = contrat;
            this.res = res;
        }

        Stream<ContratCompartimentTestBia> compartiments(CompartimentType compartimentType) {
            return contrat.compartiments(compartimentType)
                    .stream()
                    .map(c -> this.toBuilder().compartiment(c).build());
        }
    }
}
