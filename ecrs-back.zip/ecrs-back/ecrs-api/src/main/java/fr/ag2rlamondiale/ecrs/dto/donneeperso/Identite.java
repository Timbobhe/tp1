package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Identite {
    private String codeCivilite;
    private String civilite;
    private String nom;
    private String prenom;
    private String nomNaissance;
    private Date dateDeNaissance;
    private String lieuNaissance;
    private String departementNaissance;
    private String situationFamiliale;
}
