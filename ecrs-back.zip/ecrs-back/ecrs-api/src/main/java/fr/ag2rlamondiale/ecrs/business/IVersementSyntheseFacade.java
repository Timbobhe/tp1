package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.ecrs.dto.DocumentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.SyntheseVersementDonutDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.EcheancierDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.OperationVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementProgrammeDetailsDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementProgrammeDetailsRequestDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementSyntheseDto;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;

import java.util.List;

public interface IVersementSyntheseFacade {
	VersementSyntheseDto getResumeVersement() throws TechnicalException;

	VersementProgrammeDetailsDto getVersProgrammeDetails(VersementProgrammeDetailsRequestDto dto) throws TechnicalException;

	List<EcheancierDto> getVersementsProgrammes() throws TechnicalException;

	List<OperationVersementDto> getVersementsHistorique() throws TechnicalException;

	SyntheseVersementDonutDto retrieveSyntheseVersement() throws TechnicalException;

    DocumentDto rechercherDocumentsVersement() throws TechnicalException;

    List<ContratParcoursDto> getContrats() throws TechnicalException;
}
