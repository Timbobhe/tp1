package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;

public interface ISimulateurFiscalFacade {

	SimulateurStartDto startSimulateur() throws TechnicalException;

	ResultatCalculEpargne calculerDisponibleFiscal(DemandeCalculEpargne demande) throws TechnicalException;


}
