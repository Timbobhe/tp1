package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SyntheseVersementDonutDto {
    private BigDecimal montantTotalVersementDeductible;
    private BigDecimal pourcentageVersementDeductible;
    private BigDecimal montantTotalVersementNonDeductible;
    private BigDecimal pourcentageVersementNonDeductible;
    private BigDecimal montantTotalVersement;
    private int year;
}
