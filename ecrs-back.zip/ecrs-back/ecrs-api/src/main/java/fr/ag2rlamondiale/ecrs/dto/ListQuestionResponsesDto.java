package fr.ag2rlamondiale.ecrs.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ListQuestionResponsesDto {
    private QuestionType questionTypeDisplayed;
    private List<QuestionResponsesDto<Object, Object>> questionResponsesList = new ArrayList<>();

    public void add(QuestionResponsesDto<Object, Object> questionResponses) {
        this.questionResponsesList.add(questionResponses);
    }
}
