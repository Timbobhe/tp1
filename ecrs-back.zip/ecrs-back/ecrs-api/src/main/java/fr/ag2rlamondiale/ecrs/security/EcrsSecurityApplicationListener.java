package fr.ag2rlamondiale.ecrs.security;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.impl.TraceHelper;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.ITraceFacade;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.authentication.event.LogoutSuccessEvent;
import org.springframework.security.web.session.HttpSessionDestroyedEvent;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

import static java.util.Objects.requireNonNull;

/**
 * listener sur les evenements de l'application {@link ApplicationEvent}
 */
@Slf4j
@Component
public class EcrsSecurityApplicationListener implements ApplicationListener<ApplicationEvent> {

	@Autowired
	private ITraceFacade traceFacade;

	@Autowired
	private IContratFacade contratFacade;

	@Autowired
	private UserContextHolder userContextHolder;

	@Override
	public void onApplicationEvent(ApplicationEvent appEvent) {
		
		if (appEvent instanceof AuthenticationSuccessEvent) {
			AuthenticationSuccessEvent event = (AuthenticationSuccessEvent) appEvent;
			EcrsUserDetails userDetails = (EcrsUserDetails) event.getAuthentication().getPrincipal();

			
			UserContext userContext = userContextHolder.get();
			requireNonNull(userDetails, "Le Jeton CAS est null !!");
			requireNonNull(userContext, "Le Jeton CAS ne contient pas d'utilisateur.");
			log.info("Reception authentication Success event : utilisateur {}", userDetails.getUsername());
			// Pour un utilisateur admin on ne fait pas ce traitement
			if (userContext.isPilotage()) {
				return;
			}

			ConnexionPersonneSilo cnx = testConnexionPourSilo(userContext, CodeSiloType.ERE);
			if (cnx == null) {
				cnx = testConnexionPourSilo(userContext, CodeSiloType.MDP);
			}

			requireNonNull(cnx, "On suppose que l'utilisateur a au moins un contrat ERE ou MDPRO");

			String traceContratId = cnx.contrat.getId();
			String traceZone1 = TraceHelper.getZone1ofContrat(cnx.contrat);

			// Trace dans la BD, la connexion de l'utilisateur.
			final TraceJson traceJson = traceFacade.buildTrace(CodeActionType.CQ_CONNEXION, new Date(), null,
					cnx.numeroPersonne, traceContratId, traceZone1, cnx.codeSilo);
			traceFacade.insertAsync(traceJson);
		}
		
		
	}

	private ConnexionPersonneSilo testConnexionPourSilo(UserContext userContext, CodeSiloType codeSilo) {
		try {
			final List<ContratHeader> contratHeaders;
			if (CodeSiloType.ERE.equals(codeSilo)) {
				contratHeaders = contratFacade.rechercherContratsEre();
			} else {
				contratHeaders = contratFacade.rechercherContratsMdpro();
			}
			if (contratHeaders != null && !contratHeaders.isEmpty()) {
				ConnexionPersonneSilo res = new ConnexionPersonneSilo();
				res.setCodeSilo(codeSilo);
				res.setNumeroPersonne(codeSilo.getNumeroPersonne(userContext));
				res.setContrat(contratHeaders.get(0));
				return res;
			}
			return null;
		} catch (TechnicalException e) {
			throw new TechnicalRuntimeException(e);
		}
	}

	@Data
	private static class ConnexionPersonneSilo {
		private CodeSiloType codeSilo;
		private String numeroPersonne;
		private ContratHeader contrat;
	}
}
