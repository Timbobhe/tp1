package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageEncoursDto;
import fr.ag2rlamondiale.formulaire.actesenligne.ContributionInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.GrilleInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.HorizonInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.OccurenceStructureInvestissementType;
import fr.ag2rlamondiale.formulaire.actesenligne.ProfilInvestissementType;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.math.BigDecimal;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class OccurenceStructureInvestissementTypeMapper {

    static final String CURRENCY_CODE = "EUR";

    @Mapping(source = "supportFinancierDto.commonFields.id", target = "identifiantOccurenceStructureInvestissement")
    @Mapping(source = "supportFinancierDto.commonFields.parentId", target = "identifiantOccurenceParentStructureInvestissement")
    @Mapping(source = "supportFinancierDto.commonFields.natureSupport.codeNatureSupport", target = "codeNatureSupportInvestissement")
    @Mapping(source = "supportFinancierDto.commonFields.libeNatureSupport", target = "libelleNatureSupportInvestissement")
    @Mapping(source = "supportFinancierDto.commonFields.codeNatureSupportInvSilo", target = "codeNatureSupportInvestissementSilo")
    @Mapping(source = "supportFinancierDto.commonFields.libeNatureSupportInvSilo", target = "libelleNatureSupportInvestissementSilo")
    @Mapping(expression = "java(montant != null ? montant.multiply(supportFinancierDto.getTaux()) : montant)", target = "montantOccurenceStructureInvestissement")
    @Mapping(expression = "java( montant != null ? CURRENCY_CODE : null)", target = "codeDeviseOccurenceStructureInvestissement")
    @Mapping(source = "supportFinancierDto.contributionInvParent", target = "contributionInvestissement", ignore = true)
    public abstract OccurenceStructureInvestissementType mapSupportFinancierDtoToOccurenceStructureInvestissementType(SupportFinancierDto supportFinancierDto, BigDecimal montant);

    @Mapping(source = "contributionInv.commonFields.id", target = "identifiantOccurenceStructureInvestissement")
    @Mapping(source = "contributionInv.commonFields.parentId", target = "identifiantOccurenceParentStructureInvestissement")
    @Mapping(expression = "java(montant)", target = "montantOccurenceStructureInvestissement")
    @Mapping(expression = "java( montant != null ? CURRENCY_CODE : null)", target = "codeDeviseOccurenceStructureInvestissement")
    @Mapping(source = "contributionInv.commonFields.natureSupport.codeNatureSupport", target = "codeNatureSupportInvestissement")
    @Mapping(source = "contributionInv.commonFields.libeNatureSupport", target = "libelleNatureSupportInvestissement")
    @Mapping(source = "contributionInv.commonFields.codeNatureSupportInvSilo", target = "codeNatureSupportInvestissementSilo")
    @Mapping(source = "contributionInv.commonFields.libeNatureSupportInvSilo", target = "libelleNatureSupportInvestissementSilo")
    @Mapping(source = "contributionInv", target = "contributionInvestissement")
    public abstract OccurenceStructureInvestissementType mapContributionInvToOccurenceStructureInvestissementType(ContributionInv contributionInv, BigDecimal montant);

    @Mapping(source = "id", target = "identifiantContributionInvestissement")
    @Mapping(source = "type.code", target = "codeContributionInvestissement")
    @Mapping(source = "libelleContributionInv", target = "libelleContributionInvestissement")
    @Mapping(source = "libelleContributionInvSilo", target = "libelleContributionInvestissementSilo")
    @Mapping(source = "tauxRepartitionContribution", target = "tauxRepartitionContribution")
    @Mapping(source = "indicateurTauxDerogeable", target = "indicateurTauxDerogeableContributionInvestissement")
    @Mapping(source = "idAssureCompartiment", target = "identifiantDansSilo")
    public abstract ContributionInvestissementType mapContributionInvDtoToType(ContributionInv contributionInv);

    @Mapping(source = "arbitrageEncoursDto.code", target = "identifiantOccurenceStructureInvestissement")
    @Mapping(source = "arbitrageEncoursDto.supportParent.idOccurStructInv", target = "identifiantOccurenceParentStructureInvestissement")
    public abstract OccurenceStructureInvestissementType mapArbitrageEncoursDtoToOccurenceStructureInvestissementType(ArbitrageEncoursDto arbitrageEncoursDto);

    @Mapping(source = "idOccurStructInv", target = "identifiantOccurenceStructureInvestissement")
    @Mapping(source = "idOccurParentStructInv", target = "identifiantOccurenceParentStructureInvestissement")
    @Mapping(source = "codeNatureSupportInv", target = "codeNatureSupportInvestissement")
    @Mapping(source = "libNatureSupportInv", target = "libelleNatureSupportInvestissement")
    @Mapping(source = "codeNatureSupportInvSilo", target = "codeNatureSupportInvestissementSilo")
    @Mapping(source = "libNatureSupportInvSilo", target = "libelleNatureSupportInvestissementSilo")
    @Mapping(source = "occurStructInvDto", target = "contributionInvestissement")
    public abstract OccurenceStructureInvestissementType mapOccurStructInvDtoToOccurenceStructureInvestissementType(OccurStructInvDto occurStructInvDto);

    @Mapping(source = "idOccurStructInv", target = "identifiantContributionInvestissement")
    @Mapping(source = "contributionInv.codeContributionInv", target = "codeContributionInvestissement")
    @Mapping(source = "contributionInv.libContributionInv", target = "libelleContributionInvestissement")
    @Mapping(source = "contributionInv.libContributionInvSilo", target = "libelleContributionInvestissementSilo")
    @Mapping(source = "contributionInv.txRepartitionContribution", target = "tauxRepartitionContribution")
    @Mapping(source = "contributionInv.indicTxDerogeableContributionInv", target = "indicateurTauxDerogeableContributionInvestissement")
    public abstract ContributionInvestissementType mapOccurStructInvDtoToType(OccurStructInvDto occurStructInvDto);

    @Mapping(source = "code", target = "identifiantGrilleInvestissement")
    @Mapping(source = "nom", target = "nomGrilleInvestissement")
    @Mapping(source = "taux", target = "tauxRepartitionGrilleInvestissement")
    @Mapping(source = "tauxModifiable", target = "indicateurTauxDerogeableGrilleInvestissement")
    public abstract GrilleInvestissementType mapSupportToGrilleInvestissementType(SupportFinancierDto supportFinancierDto);

    @Mapping(source = "code", target = "identifiantProfilInvestissement")
    @Mapping(source = "nom", target = "nomProfilInvestissement")
    @Mapping(source = "taux", target = "tauxRepartitionProfilInvestissement")
    @Mapping(source = "tauxModifiable", target = "indicateurTauxDerogeableProfilInvestissement")
    public abstract ProfilInvestissementType mapSupportToProfilInvestissementType(SupportFinancierDto supportFinancierDto);

    @Mapping(source = "nom", target = "nomProfilInvestissement")
    @Mapping(source = "code", target = "identifiantProfilInvestissement")
    @Mapping(expression = "java(arbitrageEncoursDto.getRepartition().divide(BigDecimal.valueOf(100)))", target = "tauxRepartitionProfilInvestissement")
    protected abstract ProfilInvestissementType mapArbitrageEncoursToProfilInvestissementType(ArbitrageEncoursDto arbitrageEncoursDto);

    @Mapping(source = "nom", target = "nomGrilleInvestissement")
    @Mapping(source = "code", target = "identifiantGrilleInvestissement")
    @Mapping(expression = "java(arbitrageEncoursDto.getRepartition().divide(BigDecimal.valueOf(100)))", target = "tauxRepartitionGrilleInvestissement")
    protected abstract GrilleInvestissementType mapArbitrageEncoursToGrilleInvestissementType(ArbitrageEncoursDto arbitrageEncoursDto);

    @Mapping(source = "nom", target = "nomHorizonInvestissement")
    @Mapping(source = "code", target = "identifiantHorizonInvestissement")
    @Mapping(source = "supportParent.horizonInv.borneMinDeplacerCapitalInvesti", target = "borneMinDeplacerCapitalInvesti")
    @Mapping(source = "supportParent.horizonInv.borneMaxDeplacerCapitalInvesti", target = "borneMaxDeplacerCapitalInvesti")
    @Mapping(source = "supportParent.horizonInv.borneMinVersementInv", target = "borneMinVersementInvestissement")
    @Mapping(source = "supportParent.horizonInv.borneMaxVersementInv", target = "borneMaxVersementInvestissement")
    protected abstract HorizonInvestissementType mapArbitrageEncoursToHorizonInvestissementType(ArbitrageEncoursDto arbitrageEncoursDto);

    @AfterMapping
    protected void mapGrilleProfil(@MappingTarget OccurenceStructureInvestissementType occurenceStructureInv,
                                   SupportFinancierDto supportFinancierDto, BigDecimal montant) {
        switch (supportFinancierDto.getSupportType()) {
            case GRILLE:
                occurenceStructureInv.setGrilleInvestissement(mapSupportToGrilleInvestissementType(supportFinancierDto));
                break;
            case PROFIL:
                occurenceStructureInv.setProfilInvestissement(mapSupportToProfilInvestissementType(supportFinancierDto));
                break;
            default:
                break;
        }
    }

    @AfterMapping
    protected void mapGrilleProfilHorizon(@MappingTarget OccurenceStructureInvestissementType occurenceStructureInvestissementType,
                                          ArbitrageEncoursDto arbitrageEncoursDto) {
        switch (arbitrageEncoursDto.getSupportType()) {
            case GRILLE:
                occurenceStructureInvestissementType.setGrilleInvestissement(mapArbitrageEncoursToGrilleInvestissementType(arbitrageEncoursDto));
                break;
            case PROFIL:
                occurenceStructureInvestissementType.setProfilInvestissement(mapArbitrageEncoursToProfilInvestissementType(arbitrageEncoursDto));
                break;
            case HORIZON:
                occurenceStructureInvestissementType.setHorizonInvestissement(mapArbitrageEncoursToHorizonInvestissementType(arbitrageEncoursDto));
                break;
            default:
                break;
        }
    }
}
