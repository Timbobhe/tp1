package fr.ag2rlamondiale.ecrs.dto;

import lombok.Data;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Data
public class InfosBlocagesClientDto {

    private boolean isPersonneTotalementBloquee;
    private boolean isToutLesContratsTotalementsBloques;
    private Set<String> fonctionnalitesBloqueesALaPersonne = new HashSet<>();
    private Set<String> fonctionnalitesBloqueesPartenaire = new HashSet<>();
    private Set<String> fonctionnalitesBloqueesTousContrats = new HashSet<>();
    private Map<String, Set<String>> fonctionnalitesBloqueesContrats = new HashMap<>();
}
