package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.structinv.*;
import fr.ag2rlamondiale.ecrs.mapping.GestionFinanciereContratDetailMapper;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.*;

/**
 * Implementation Spring du service REST pour la recherche de documents
 */
@RestController
@RequestMapping(path = "/secure")
public class GestionFinanciereRestController {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private GestionFinanciereContratDetailMapper gestionFinanciereContratDetailMapper;


    @ProfileExecution(codeAction = API_GESTION_FIN_SUPPORTS_COMPARTIMENT)
    @LogExecutionTime
    @PostMapping(path = "/gestion-financiere/compartiment")
    @Secure
    public ResponseEntity<GestionFinanciereDto> getGestionFinanciereCompartiment(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    GestionFinRequestDto request) throws TechnicalException {

        final ContratId id = request.getContratId();

        final CompartimentId cid = request.getCompartimentId() != null ? request.getCompartimentId().clean(id.getCodeSilo()) : null;
        if (cid == null) {
            return ResponseEntity.badRequest().build();
        }

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(id);

        final Compartiment compartiment = contratHeader.compartiment(cid);
        final GestionFinRequest gfr = GestionFinRequest.from(request, contratHeader.getCodeSilo(), contratHeader.isPacte());
        return ResponseEntity.ok(structureInvFacade.getGestionFinanciere(compartiment, gfr));
    }

    @ProfileExecution(codeAction = API_GESTION_FIN_SUPPORTS_CONTRAT)
    @LogExecutionTime
    @PostMapping(path = "/gestion-financiere/contrat")
    @Secure
    public ResponseEntity<GestionFinanciereContratDto> getGestionFinanciereContrat(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    GestionFinRequestDto request) throws TechnicalException {

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(request.getContratId());

        final GestionFinRequest gfr = GestionFinRequest.from(request, contratHeader.getCodeSilo(), contratHeader.isPacte());
        return ResponseEntity.ok(structureInvFacade.getGestionFinanciere(contratHeader, gfr));
    }

    @ProfileExecution(codeAction = API_GESTION_FIN_ACTUELLE_CONTRAT)
    @LogExecutionTime
    @PostMapping(path = "/gestion-financiere/actuelle/contrat")
    @Secure
    public ResponseEntity<GestionFinanciereActuelleContratDto> getGestionFinanciereActuelleContrat(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    GestionFinActuelleRequestDto dto) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(dto.getContratId());
        return ResponseEntity.ok(structureInvFacade.getGestionFinanciereActuelle(contratHeader, dto));
    }

    @ProfileExecution(codeAction = API_GESTION_FIN_ACTUELLE_COMPARTIMENT)
    @LogExecutionTime
    @PostMapping(path = "/gestion-financiere/actuelle/compartiment")
    @Secure
    public ResponseEntity<GestionFinanciereActuelleCompartimentsDto> getGestionFinanciereActuelleCompartiment(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    GestionFinActuelleRequestDto dto) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(dto.getContratId());
        final Compartiment compartiment = contratHeader.compartiment(dto.getCompartimentId());
        return ResponseEntity.ok(structureInvFacade.getGestionFinanciereActuelle(compartiment, dto));
    }
}
