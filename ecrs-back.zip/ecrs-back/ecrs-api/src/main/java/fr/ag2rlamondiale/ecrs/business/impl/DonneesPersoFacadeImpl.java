package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IDonneesPersoFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.business.domain.SujetConstants;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoInfo;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursType;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursValidation;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.ModificationsIdentiteInfo;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.domain.workflow.*;
import fr.ag2rlamondiale.trm.domain.workflow.ecriture.FormulaireModificationDonneesPersonnellesDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class DonneesPersoFacadeImpl implements IDonneesPersoFacade {

    @Autowired
    private UserContextHolder userContextHolder;
    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;
    @Autowired
    private IWorkflowFacade workflowFacade;
    @Autowired
    private IContratFacade contratFacade;
    @Autowired
    private IEvenementFacade evenementFacade;

    @Autowired
    private IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private IModifierPPSiloClient modifierPPSiloClient;

    @Override
    public DonneesPersoInfo getDonnesPerso() throws TechnicalException {
        final UserContext userContext = userContextHolder.get();

        PersonnePhysiqueConsult ppConsult = consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo());
        boolean demandeEncours = workflowFacade.hasDemandeEncours(userContext.getNumeroPersonne(CodeSiloType.ERE),
                DemandeWorkflowType.MODIF_DONNEES_PERSO_SALARIE);

        return DonneesPersoInfo.builder()
                .identiteInfoValidee(fillDonneesPerso(ppConsult))
                .donneesPersonnellesConfirmees(ppConsult.isDonneesPersonnellesConfirmees())
                .modificationEnCours(demandeEncours)
                .build();
    }

    private ModificationsIdentiteInfo fillDonneesPerso(PersonnePhysiqueConsult ppConsult) {
        String codeCivilite = ppConsult.getCivilite().equals("Monsieur") ? "Mr" : "Mme";
        return ModificationsIdentiteInfo.builder()
                .civilite(ppConsult.getCivilite())
                .codeCivilite(codeCivilite)
                .nom(ppConsult.getNom())
                .nomNaissance(ppConsult.getNomNaissance())
                .prenom(ppConsult.getPrenom())
                .dateDeNaissance(DateUtils.dateToString(ppConsult.getDateDeNaissance()))
                .lieuNaissance(ppConsult.getLieuNaissance())
                .build();
    }

    @Override
    public ModifierPPSiloResponseDto validerModifDonnesPerso(DonneesPersoParcoursValidation donneesPerso)
            throws TechnicalException {
        PersonnePhysiqueConsult pp = consulterPersPhysFacade.consulterPersPhys(userContextHolder.get().getIdSilo());

        PersonnePhysiqueConsult newPersonnePhys = pp.toBuilder().build();

        FormulaireModificationDonneesPersonnellesDto demandeWorkflow = createModificationDonneesPersonnellesToFormulaire(
                pp, newPersonnePhys, donneesPerso, CodeSiloType.ERE);
        final IdDemSilo idDemSilo = workflowFacade.creerDemandeWorkflow(demandeWorkflow);

        // Actualiser le cache
        consulterPersonneClient.forceCacheEvictConsulterPersPhys(userContextHolder.get().getIdSilo());

        // traiter les sujets confirmation des dp et validation periodique des dp
        if (idDemSilo != null) {
            if (SujetConstants.TITRE_SOUS_SUJET_CONF.equals(donneesPerso.getTitreSujet())) {
                evenementFacade.saveEvenementUtilisateurTraite(TypeEven.CONFIRMATION_DONNEES_PERSO);

            } else if (SujetConstants.TITRE_SOUS_SUJET_VDPP.equals(donneesPerso.getTitreSujet())) {
                evenementFacade.saveEvenementUtilisateurTraite(TypeEven.VALIDATION_PERIODIQUE_DONNEES_PERSO);
            }
        }

        ModifierPPSiloDto modifierPPSiloDto;

        if (donneesPerso.getDonneesPersoParcoursType().equals(DonneesPersoParcoursType.MODIFICATION)) {
            getNewPersonnePhys(newPersonnePhys, donneesPerso);
            modifierPPSiloDto = ModifierPPSiloDto.builder()
                    .personnePhysique(newPersonnePhys)
                    .idSiloDto(userContextHolder.get().getIdSilo())
                    .build();
        } else {
            modifierPPSiloDto = ModifierPPSiloDto.builder()
                    .personnePhysique(newPersonnePhys)
                    .idSiloDto(userContextHolder.get().getIdSilo())
                    .build();
        }
        return modifierPPSiloClient.modifierPPSilo1(modifierPPSiloDto);
    }

    private FormulaireModificationDonneesPersonnellesDto createModificationDonneesPersonnellesToFormulaire(
            PersonnePhysiqueConsult oldPersonne, PersonnePhysiqueConsult newPersonnePhys,
            DonneesPersoParcoursValidation donneesPerso, CodeSiloType codeSiloType) throws TechnicalException {
        List<PieceJointe> pieceJointes = null;
        final ContratComplet contratComplet = contratFacade.rechercherContratsCompletsERE().get(0);

        StatutDemandeWorkflowType typeAction;

        if (donneesPerso.getDonneesPersoParcoursType().equals(DonneesPersoParcoursType.MODIFICATION)) {
            typeAction = StatutDemandeWorkflowType.STANDARD;
            pieceJointes = preparePiecewithType(donneesPerso.getPieceJointes());
            getNewPersonnePhys(newPersonnePhys, donneesPerso);
        } else {
            typeAction = StatutDemandeWorkflowType.ARCHIVE;
            newPersonnePhys.setDonneesPersonnellesConfirmees(true);
        }
        String idDemandeWkf = workflowFacade.genererIdDemFront(CodeActionType.DEM_MODIFDONNEESPERSO, contratComplet.getContratHeader().getPersonId(),
                contratComplet.getContratHeader().getNomContrat(), codeSiloType);
        return FormulaireModificationDonneesPersonnellesDto.builder()
                .codeFiliale(contratComplet.getContratHeader().getCodeFiliale())
                .date(new Date())
                .idPersonne(userContextHolder.get().getNumeroPersonne(codeSiloType))
                .raisonSocialeAdherente(contratComplet.getContratHeader().getRaisonSocialeAdherente())
                .raisonSocialeContractante(contratComplet.getContratGeneral().getContractante())
                .referenceExterne(contratComplet.getContratGeneral().getReferenceExterne())
                .idDemande(idDemandeWkf)
                .demandeWorkflowType(DemandeWorkflowType.MODIF_DONNEES_PERSO_SALARIE)
                .donneesActuelles(oldPersonne)
                .donneesModifiees(newPersonnePhys)
                .piecesJointes(pieceJointes)
                .typeAction(typeAction.name())
                .silo(codeSiloType)
                .idContrat(contratComplet.getContratGeneral().getId())
                .build();
    }

    private void getNewPersonnePhys(PersonnePhysiqueConsult newPersonnePhys, DonneesPersoParcoursValidation donneesPerso) {
        newPersonnePhys.setNom(donneesPerso.getModificationsIdentiteInfo().getNom());
        newPersonnePhys.setPrenom(donneesPerso.getModificationsIdentiteInfo().getNom());
        newPersonnePhys.setPrenom(donneesPerso.getModificationsIdentiteInfo().getPrenom());
        newPersonnePhys.setDateDeNaissance(DateUtils.createTimelessDate((donneesPerso.getModificationsIdentiteInfo().getDateDeNaissance())));
        newPersonnePhys.setLieuNaissance(donneesPerso.getModificationsIdentiteInfo().getLieuNaissance());
        newPersonnePhys.setDonneesPersonnellesConfirmees(true);
    }

    private List<PieceJointe> preparePiecewithType(List<UploadFileDto> pieceJointes) {
        List<PieceJointe> listPieces = new ArrayList<>();
        if (pieceJointes.size() == 1) {
            listPieces.add(PieceJointe.builder().contenuBase64(pieceJointes.get(0).getFileContent()).type(CodeTypePieceJointeWorkflowEnum.CARTE_D_IDENTITE).build());
        } else if (pieceJointes.size() == 2) {
            listPieces.add(PieceJointe.builder().contenuBase64(pieceJointes.get(0).getFileContent()).type(CodeTypePieceJointeWorkflowEnum.CARTE_D_IDENTITE).build());
            listPieces.add(PieceJointe.builder().contenuBase64(pieceJointes.get(1).getFileContent()).type(CodeTypePieceJointeWorkflowEnum.CARTE_D_IDENTITE).build());
        }
        return listPieces;
    }

}
