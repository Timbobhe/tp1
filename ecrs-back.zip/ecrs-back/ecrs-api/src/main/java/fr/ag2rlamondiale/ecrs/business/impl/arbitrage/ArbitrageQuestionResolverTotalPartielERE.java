package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageTotalPartielType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_ARBITRAGE_PARTIEL;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_ARBITRAGE_TOTAL;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_SOUHAIT_ARBITRER;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_QUESTION_PARTIELTOTAL_TITRE;

@Service
public class ArbitrageQuestionResolverTotalPartielERE implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Override
    public QuestionResponsesDto<ResponseArbitrageTotalPartielType, ?> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<ResponseArbitrageTotalPartielType, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL)
                .jahiaDicoEntry(ARB_QUESTION_PARTIELTOTAL_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_SOUHAIT_ARBITRER.name())
                .build());

        if (contexte.getResponseFluxStockType().isFlux() || isStrategieFinanciereImposee(contexte)) {
            result.setShow(false);
            result.setDefaultValue(reponseTotal());
            contexte.update(ctx -> ctx.setResponseTotalPartielType(ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL));
            return result;
        }

        result.add(reponseTotal());

        result.add(reponsePartiel());


        return result;
    }

    public ResponseDto<ResponseArbitrageTotalPartielType> reponsePartiel() {
        return ResponseDto.<ResponseArbitrageTotalPartielType>builder()
                .id(ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL.name())
                .value(ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL)
                .jahiaDicoEntry(ARB_ARBITRAGE_PARTIEL.name())
                .build();
    }

    public ResponseDto<ResponseArbitrageTotalPartielType> reponseTotal() {
        return ResponseDto.<ResponseArbitrageTotalPartielType>builder()
                .id(ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL.name())
                .value(ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL)
                .jahiaDicoEntry(ARB_ARBITRAGE_TOTAL.name())
                .build();
    }

    private boolean isStrategieFinanciereImposee(ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        final StructInv structInv = structureInvFacade.consulterStructInv(contratHeader);

        if (contratHeader.isPacte()) {
            return true;
        }

        if (contexte.isTousCompartimentsSelectionnes()) {
            return contratHeader.getCompartiments().stream().anyMatch(compartiment -> this.isStrategieFinanciereImposee(structInv, compartiment));
        }

        Compartiment compartiment = contratHeader.compartiment(contexte.getCompartimentSelectionne());
        return isStrategieFinanciereImposee(structInv, compartiment);
    }

    private boolean isStrategieFinanciereImposee(StructInv structInv, Compartiment compartiment) {
        final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), compartiment.isPacte());

        return contributionTypes.stream()
                .map(structInv::getContribution)
                .filter(Objects::nonNull)
                .flatMap(contributionInv -> contributionInv.getProfilsEtGrilles().stream())
                .allMatch(pg -> Boolean.FALSE.equals(pg.getIndicateurTauxDerogeable()));
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL.equals(questionType) && contexte.getContratSelectionne() != null && contexte.getContratSelectionne().is(CodeSiloType.ERE);
    }
}
