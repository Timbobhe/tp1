package fr.ag2rlamondiale.ecrs.dto.versement;

import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MoyenPaiementDto {
    private QuestionType.ResponseVersementMoyenPaiementType moyenPaiementType;
    private CoordonneesBancairesDto coordonneesBancairesDto;
}
