package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IParcoursSimplifieFacade;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ParcoursSimplifieFacadeImpl implements IParcoursSimplifieFacade {

    @Autowired
    private IBlocageFacade blocageFacade;

    @Override
    public boolean isParcoursSimplifieActivate(String idContrat, FonctionnaliteType fonctionnaliteType) throws TechnicalException {
        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
        return blocagesClient.isFonctionnaliteBloqueePourContrat(idContrat, fonctionnaliteType) ||
                blocagesClient.isFonctionnaliteBloqueePourContrat(idContrat,FonctionnaliteType.TOUT_PARCOURS_SIMPLIFIE);
    }
}
