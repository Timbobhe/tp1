package fr.ag2rlamondiale.ecrs.mapping;

import com.ag2r.common.security.habilitations.model.IAuthorizationData;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import fr.ag2rlamondiale.metis.boot.security.dao.UserDetailsImpl;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class UserSecurityRequestMapper {

    @Mapping(source = ".", target = "uid", qualifiedByName = "mapUid")
    @Mapping(source = "userSn", target = "attributes.sn", qualifiedByName = "wrapToList")
    @Mapping(source = "userGivenName", target = "attributes.givenName", qualifiedByName = "wrapToList")
    @Mapping(source = ".", target = "attributes.agCodeSexe", qualifiedByName = "mapCodeSexe")
    @Mapping(source = ".", target = "attributes.roles", qualifiedByName = "mapRoles")
    @Mapping(source = ".", target = "attributes.businessIdMap", qualifiedByName = "mapBusinessIdMap")
    @Mapping(source = ".", target = "attributes.personIdMap", qualifiedByName = "mapPersonIdMap")
    @Mapping(source = ".", target = "attributes.compteDemo", qualifiedByName = "mapCompteDemo")
    public abstract UserRequestDto map(UserDetailsImpl userDetails);

    @Named("mapUid")
    public String mapUid(UserDetailsImpl userDetails) {
        return (String) userDetails.getAttributesMap().get("uid");
    }

    @Named("mapCodeSexe")
    public List<String> mapCodeSexe(UserDetailsImpl userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("agCodeSexe"));
    }

    @Named("mapBusinessIdMap")
    public List<String> mapBusinessIdMap(UserDetailsImpl userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("businessIdMap"));
    }

    @Named("mapPersonIdMap")
    public List<String> mapPersonIdMap(UserDetailsImpl userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("personIdMap"));
    }

    @Named("mapCompteDemo")
    public List<Boolean> mapCompteDemo(UserDetailsImpl userDetails) {
        final Object compteDemo = userDetails.getAttributesMap().get("compteDemo");
        return wrapToList(compteDemo != null && (boolean) compteDemo);
    }

    @Named("wrapToList")
    protected <T> List<T> wrapToList(T e) {
        return WrapListUtils.wrapToList(e);
    }

    @Named("mapRoles")
    public Set<String> mapRoles(UserDetailsImpl userDetails) {
        return userDetails.getAuthorities().stream()
                .map(grantedAuthority -> {
                    final String authority = grantedAuthority.getAuthority();
                    if (authority.startsWith(IAuthorizationData.ROLE_PREFIX)) {
                        return authority.substring(IAuthorizationData.ROLE_PREFIX.length());
                    }
                    return authority;
                })
                .collect(Collectors.toSet());
    }
}
