package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.versement.RequestQuestionVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementTerminateDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface IVersementFacade {
    VersementStartDto startVersement() throws TechnicalException;

    //TODO refacto si il y a les memes methodes de l'arbitrage et du rib, les extraires
    boolean isAssureOrSouscripteurMajeur(ContratGeneral contratGeneral);

    boolean isSouscripteurIsAssureAndPersonnePhysiqueMDP(ContratGeneral contratGeneral);

    <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionVersementDto request) throws TechnicalException;

    ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionVersementDto request) throws TechnicalException;

    String terminate(VersementTerminateDto versementTerminateDto, boolean isFrame) throws TechnicalException, IOException, JAXBException;
}
