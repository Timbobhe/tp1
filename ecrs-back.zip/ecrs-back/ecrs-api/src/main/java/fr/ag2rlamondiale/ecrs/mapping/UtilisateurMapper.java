package fr.ag2rlamondiale.ecrs.mapping;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.ClientDto;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public class UtilisateurMapper {

    @Autowired
    IConsulterPersPhysFacade consulterPersPhysFacade;

    public ClientDto mapperPersonnePhysiqueToClientDto(ClientDto c, UserContext userContext) throws TechnicalException {
        PersonnePhysiqueConsult pp = consulterPersPhysFacade
                .consulterPersPhys(userContext.getIdSilo());
        c.setCivilite(pp.getCivilite() != null ? pp.getCivilite() : pp.getCodeCivilite());
        c.setDateDeNaissance(pp.getDateDeNaissance());
        c.setNomNaissance(pp.getNomNaissance());
        return c;
    }

    public ClientDto mapperPersonnePhysiqueConsultToClientDto(ClientDto c, UserContext userContext) throws TechnicalException {
        PersonnePhysiqueConsult pp = consulterPersPhysFacade
                .consulterPersPhys(userContext.getIdSilo());
        c.setCivilite(pp.getCivilite() != null ? pp.getCivilite() : pp.getCodeCivilite());
        c.setDateDeNaissance(pp.getDateDeNaissance());
        c.setNomNaissance(pp.getNomNaissance());
        c.setNom(pp.getNom());
        c.setPrenom(pp.getPrenom());
        return c;
    }
}
