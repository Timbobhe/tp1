package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArbitrageAccessibilitySupplier;
import fr.ag2rlamondiale.ecrs.business.IArbitrageFacade;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocageComparator;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteJahiaContextDto;
import fr.ag2rlamondiale.trm.domain.accessibilite.DetailAccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.*;

@Component
public class ArbitrageAccessibilitySupplier implements IFunctionalityAccessibilitySupplier<Object>, IArbitrageAccessibilitySupplier {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IArbitrageFacade arbitrageFacade;

    private static final ContratBlocageComparator RaisonArbitrageComparator = ContratBlocageComparator.selonOrdre(
            NONE, ARB_BLOCAGE_CONSOLE, ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS, BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS,
            ARB_BLOCAGE_ETAT_COMPTE, ARB_BLOCAGE_CONDITIONS_CONTRAT,
            ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL, ARB_BLOCAGE_NB_MAX_DEPASSE, ARB_BLOCAGE_ARBITRAGE_EN_COURS, ARB_BLOCAGE_OPERATIONS_EN_COURS);

    @Override
    public boolean accept(FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.ARBITRAGE.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto<Object> check() throws TechnicalException {
        AccesFonctionnaliteDto<Object> accesFonctionnalite = new AccesFonctionnaliteDto<>(FonctionnaliteType.ARBITRAGE);
        final List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();
        final InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();

        boolean accessible = false;
        ContratBlocage raison;
        Map<String, String> contexteJahia = new HashMap<>();

        if (!contratComplets.isEmpty()) {
            for (ContratComplet contratComplet : contratComplets) {
                ContratHeader contratHeader = contratComplet.getContratHeader();
                DetailAccesFonctionnaliteDto detail = new DetailAccesFonctionnaliteDto(contratHeader.getContratId());
                accesFonctionnalite.addDetail(detail);

                if (infosBlocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.ARBITRAGE)) {
                    detail.setAccessible(false, ARB_BLOCAGE_CONSOLE.name());
                } else if (hasDemandeMdpEncours()) {
                    detail.setAccessible(false, BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS.name());
                } else if (contratComplet.is(CodeSiloType.ERE)) {
                    AccesFonctionnaliteJahiaContextDto accesFonctionnaliteJahiaContextDto = detailEre(contratComplet, AccesFonctionnaliteJahiaContextDto.builder()
                            .accesFonctionnalite(accesFonctionnalite)
                            .detail(detail)
                            .contexteJahia(contexteJahia)
                            .build());
                    detail = accesFonctionnaliteJahiaContextDto.getDetail();
                    contexteJahia = accesFonctionnaliteJahiaContextDto.getContexteJahia();
                    accesFonctionnalite = accesFonctionnaliteJahiaContextDto.getAccesFonctionnalite();
                } else if (contratComplet.is(CodeSiloType.MDP)) {
                    AccesFonctionnaliteJahiaContextDto accesFonctionnaliteJahiaContextDto = detailMdpro(contratComplet, AccesFonctionnaliteJahiaContextDto.builder()
                            .detail(detail)
                            .build());
                    detail = accesFonctionnaliteJahiaContextDto.getDetail();
                } else {
                    detail.setAccessible(true, NONE.name());
                }

                accessible = accessible || detail.isAccessible();
            }

            raison = accesFonctionnalite.getDetails().stream()
                    .map(DetailAccesFonctionnaliteDto::getRaison)
                    .map(ContratBlocage::valueOf)
                    .min(RaisonArbitrageComparator)
                    .orElse(NONE);
        } else {
            raison = METIER;
        }
        accesFonctionnalite.setAccessible(accessible);
        accesFonctionnalite.setRaison(raison.name());
        return accesFonctionnalite;
    }

    public boolean isArbitrageAccessible(ContratId contratId) throws TechnicalException {

        final InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();

        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratId);
        ContratHeader contratHeader = contratComplet.getContratHeader();
        DetailAccesFonctionnaliteDto detail = new DetailAccesFonctionnaliteDto(contratHeader.getContratId());

        if (infosBlocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.ARBITRAGE)) {
            detail.setAccessible(false, ARB_BLOCAGE_CONSOLE.name());
        } else if (hasDemandeMdpEncours()) {
            detail.setAccessible(false, BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS.name());
        } else if (contratComplet.is(CodeSiloType.ERE)) {
            detail = detailEre(contratComplet, AccesFonctionnaliteJahiaContextDto.builder()
                    .detail(detail)
                    .build()).getDetail();
        } else if (contratComplet.is(CodeSiloType.MDP)) {
            AccesFonctionnaliteJahiaContextDto accesFonctionnaliteJahiaContextDto = detailMdpro(contratComplet, AccesFonctionnaliteJahiaContextDto.builder()
                    .detail(detail)
                    .build());
            detail = accesFonctionnaliteJahiaContextDto.getDetail();
        } else {
            detail.setAccessible(true, NONE.name());
        }

        return detail.isAccessible();
    }

    private boolean hasDemandeMdpEncours() throws WorkflowException {
        if (userContextHolder.get().getNumeroPersonneEre() != null) {
            return workflowFacade.hasDemandeMdpEncours(userContextHolder.get().getNumeroPersonneEre());
        }
        return false;
    }

    private AccesFonctionnaliteJahiaContextDto<Object> detailEre(ContratComplet contratComplet, AccesFonctionnaliteJahiaContextDto<Object> accesFonctionnaliteJahiaContextDto) throws TechnicalException {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        DetailAccesFonctionnaliteDto detail = accesFonctionnaliteJahiaContextDto.getDetail();
        AccesFonctionnaliteDto<Object> accesFonctionnalite = accesFonctionnaliteJahiaContextDto.getAccesFonctionnalite();
        Map<String, String> contexteJahia = accesFonctionnaliteJahiaContextDto.getContexteJahia();

        final ResultParcoursEffectueDto resAcces = arbitrageFacade.arbitrageContratEnCoursERE(contratHeader);
        if (resAcces.isParcoursEffectue()) {
            detail.setAccessible(false, ARB_BLOCAGE_ETAT_COMPTE.name());
        } else if (resAcces.isEncours() && !resAcces.isSigElecEncoursNonSigne()) {
            detail.setAccessible(false, ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS.name());
        } else if (arbitrageFacade.isMonoSupport(contratHeader) || arbitrageFacade.isPartsNonArbitrablesERE(contratHeader)) {
            detail.setAccessible(false, ARB_BLOCAGE_CONDITIONS_CONTRAT.name());
        } else if (arbitrageFacade.isArbitrageEnLigneInterdit(contratComplet)) {
            detail.setAccessible(false, ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL.name());
        } else if (arbitrageFacade.isNbeArbitrageAnnReachedERE(contratComplet)) {
            detail.setAccessible(false, ARB_BLOCAGE_NB_MAX_DEPASSE.name());
            contexteJahia.put("dateArbitragePossible", DateUtils.dateToString(arbitrageFacade.getNewDateForArbitragePossible()));
            accesFonctionnalite.setJahiaContext(contexteJahia);
        } else if (arbitrageFacade.isArbitrageEnAttenteValorisationERE(contratComplet)) {
            detail.setAccessible(false, ARB_BLOCAGE_OPERATIONS_EN_COURS.name());
        } else {
            detail.setAccessible(true, NONE.name());
        }
        return accesFonctionnaliteJahiaContextDto;
    }

    private AccesFonctionnaliteJahiaContextDto<Object> detailMdpro(ContratComplet contratComplet, AccesFonctionnaliteJahiaContextDto<Object> accesFonctionnaliteJahiaContextDto) {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        ContratGeneral contratGeneral = contratComplet.getContratGeneral();
        DetailAccesFonctionnaliteDto detail = accesFonctionnaliteJahiaContextDto.getDetail();

        if (!arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(contratComplet)
                || !arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(contratHeader)) {
            detail.setAccessible(false, ARB_BLOCAGE_ETAT_COMPTE.name());
        } else if (arbitrageFacade.isMonoSupport(contratHeader)) {
            detail.setAccessible(false, ARB_BLOCAGE_CONDITIONS_CONTRAT.name());
        } else if (!arbitrageFacade.isAssureOrSouscripteurMajeur(contratGeneral)) {
            detail.setAccessible(false, ARB_BLOCAGE_ETAT_COMPTE.name());
        } else {
            detail.setAccessible(true, NONE.name());
        }

        return accesFonctionnaliteJahiaContextDto;
    }
}
