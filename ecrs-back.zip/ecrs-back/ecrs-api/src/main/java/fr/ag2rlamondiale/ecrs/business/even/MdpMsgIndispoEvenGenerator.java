package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;

/**
 * <p>
 * l’événement doit être déclenché
 * </p>
 */
@Component
@Slf4j
public class MdpMsgIndispoEvenGenerator extends AbstractEvenWithoutContratGenerator {

    @Override
    protected boolean evaluerEvenement(String numPersonne) {
        return true;
    }

    @Override
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {
        // aucune preparation necessaire
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (!isMdpro()) {
            return;
        }
        super.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, results);
    }
}
