package fr.ag2rlamondiale.ecrs.dto.bia;

import lombok.Data;

@Data
public class ClauseBeneficiaireDto {
    private boolean clauseStandard;
    private String typeClause;
    private String contenuClause;
}
