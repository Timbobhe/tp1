package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;

public abstract class AbstractEvenGenerator {
    @Autowired
    protected UserContextHolder userContextHolder;

    /**
     * Genere un EVEN depuis le r&eacute;sultat de d&eacute;clenchabilit&eacute;
     *
     * @param result
     * @return EVEN &agrave; pr&eacute;senter &agrave; l'utilisateur ou NULL sinon
     */
    public abstract EvenementJson generateNextEven(TriggeringResult result);

    protected boolean isEre() {
        return userContextHolder.get().estDansSilo(CodeSiloType.ERE);
    }

    protected boolean isMdpro() {
        return userContextHolder.get().estDansSilo(CodeSiloType.MDP);
    }

    /**
     * V&eacute;rification que l'EVEN est d&eacute;clenchable pour l'utilisateur ind&eacute;pendamment des conditions m&eacute;tiers, cad :<br>
     * <ul>
     *     <li>L'EVEN est autoris&eacute; pour la PP ou le CONTRAT</li>
     *     <li>L'EVEN n'a pas encore &eacute;t&eacute; trait&eacute;</li>
     *     <li>L'EVEN faculatif n'a pas &eacute;t&eacute; present&eacute; aujourd'hui &agrave; l'utilisateur</li>
     *     <li>L'EVEN ne d&eacute;passe pas le nombre de d&eacute;clenchement MAX</li>
     *     <li>L'EVEN respecte le d&eacute;lai de r&eacute;activation</li>
     *     <li>...</li>
     * </ul>
     *  @param idGdi
     *
     * @param numPersonne
     * @param typeEven
     * @param contrats
     * @param historiqueEvens
     * @param results
     */
    public abstract void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                           Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results);

    /**
     * M&eacute;thode &agrave; surcharger pour nettoyer le cache avant &eacute;valution des evenements
     */
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {

    }
}
