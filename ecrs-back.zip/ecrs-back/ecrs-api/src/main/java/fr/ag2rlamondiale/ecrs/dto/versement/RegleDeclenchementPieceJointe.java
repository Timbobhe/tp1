package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RegleDeclenchementPieceJointe {
    private List<NatureOdfType> sommeNaturesODF;
    private int pourcentageMontantInvesti;
    private BigDecimal montantMinInvesti;
    private boolean declencher;

}
