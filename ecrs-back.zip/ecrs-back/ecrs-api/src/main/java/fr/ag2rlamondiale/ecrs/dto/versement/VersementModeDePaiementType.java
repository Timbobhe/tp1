package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.annotation.Nonnull;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum VersementModeDePaiementType {
    // Cheque Bancaire
    CHEQUE_BANCAIRE("CHEQ", "Chèque Bancaire"),
    // Prélèvement automatique
    PRELEVEMENT_AUTOMATIQUE("PREL","Prélèvement automatique"),
    // Carte bancaire
    CARTE_BANCAIRE("CB","Carte Bancaire");

    private String cle;

    private String libelle;

    public static VersementModeDePaiementType fromLibelle(@Nonnull String libelle) {
        for (VersementModeDePaiementType mode : values()) {
            if (libelle.equals(mode.getLibelle())) {
                return mode;
            }
        }
        return null;
    }
}
