package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.simulateur.dto.Context;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.operation.OperationDetailDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.structinv.IdDansSiloDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_PASS;
import static fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum.DISPONIBLE_FISCAL_GLOBAL;

public abstract class BaseSimulateurFiscalCalcul {

    @Autowired
    private IParamConsoleFacade paramConsoleFacade;

    @Autowired
    private IOperationsClient operationClient;

    protected Context<EconomieFiscaleContextKeyEnum, Object> initContextSimulateurFiscal(DemandeCalculEpargne demande) {
        Context<EconomieFiscaleContextKeyEnum, Object> context = new Context<>();
        context.put(EconomieFiscaleContextKeyEnum.REVENU_IMPOSABLE, demande.getRevenuImposable());
        context.put(EconomieFiscaleContextKeyEnum.ABONDEMENT, demande.getAbondement());
        context.put(EconomieFiscaleContextKeyEnum.COTISATION, demande.getCotisation());
        context.put(EconomieFiscaleContextKeyEnum.TMI, demande.getTmi());
        // pour la version ECRS pas de Versement programme a saisir au moment de la
        // simulation
        // context.put(EconomieFiscaleContextKeyEnum.VL_SAISI_1, demande.getVersementLibre1());
        context.put(EconomieFiscaleContextKeyEnum.YEAR, demande.getYear() + 1);
        final Optional<ParametreDto> pass = paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente);
        context.put(EconomieFiscaleContextKeyEnum.PASS, new BigDecimal(pass.orElseThrow().getValeur1()));
        context.put(EconomieFiscaleContextKeyEnum.VLB_COMP, BigDecimal.ZERO);
        context.put(EconomieFiscaleContextKeyEnum.VPB_COMP, BigDecimal.ZERO);

        return context;
    }

    protected BigDecimal additionnerMontantBrutsOperations(List<Operation> operations, CodeSiloType codeSilo) {

        BigDecimal montantOperations = BigDecimal.ZERO;

        for (Operation operation : operations) {
            IdDansSiloDto idDansSiloDto = new IdDansSiloDto();
            idDansSiloDto.setValeurId(operation.getId());
            idDansSiloDto.setCodeSystemeInformation(codeSilo);
            OperationDetailDto operationDetailDto;
            try {
                operationDetailDto = operationClient.consulterStructInvestOperations(idDansSiloDto);
                montantOperations = montantOperations.add(operationDetailDto.getMontantBrut());
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException();
            }

        }

        return montantOperations;
    }

    protected ResultatCalculEpargne buildResultatCalculEpargnefromContext(
            Context<EconomieFiscaleContextKeyEnum, Object> context) {
        ResultatCalculEpargne resultat = new ResultatCalculEpargne();
        resultat.setDisponibleFiscal(context.getBigDecimal(DISPONIBLE_FISCAL_GLOBAL));
        resultat.setMontantEpargne(context.getBigDecimal(EconomieFiscaleContextKeyEnum.ECONOMIE_FISCALE));
        resultat.setPartGain(context.getBigDecimal(EconomieFiscaleContextKeyEnum.ECONOMIE_FISCALE));
        resultat.setPartEffort(context.getBigDecimal(EconomieFiscaleContextKeyEnum.EFFORT_EPARGNE_REEL));
        resultat.setPlafondVersement(context.getBigDecimal(EconomieFiscaleContextKeyEnum.PLAFOND_VERSEMENT));
        resultat.setVersementsDeductibles(context.getBigDecimal(EconomieFiscaleContextKeyEnum.VERSEMENTS_DEDUCTIBLES_SANS_VL_SAISI));
        resultat.setDejaVerse(context.getBigDecimal(EconomieFiscaleContextKeyEnum.TOTAL_DEJA_VERSE));
        resultat.setResteAverser(BigDecimal.ZERO.max(resultat.getPlafondVersement().subtract(resultat.getDejaVerse())));
        return resultat;
    }
}
