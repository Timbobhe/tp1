package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.ISimulateurFiscalFacade;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.DictionnaireSimulateurFiscalJahia;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.SimulateurFiscalCalculArt83;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.SimulateurFiscalCalculMadelin;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.SimulateurFiscalCalculPerp;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.simulateur.FiscaliteSimuType;
import fr.ag2rlamondiale.ecrs.dto.simulateur.InfoSimulateurContratDto;
import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.parametre.ParametreMapper;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FiscaliteType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_TMI;
import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Service
public class SimulateurFiscalFacadeImpl implements ISimulateurFiscalFacade {

    @Autowired
    private IContratFacade contratFacade;


    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private RequestContextHolder requestContextHolder;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private ContratVifHelper contratVifHelper;

    @Autowired
    private IParamConsoleFacade paramConsoleFacade;

    @Autowired
    private ParametreMapper parametreMapper;

    @Autowired
    private SimulateurFiscalCalculArt83 simulateurFiscalCalculArt83;

    @Autowired
    private SimulateurFiscalCalculPerp simulateurFiscalCalculPerp;

    @Autowired
    private SimulateurFiscalCalculMadelin simulateurFiscalCalculMadelin;

    @Override
    public SimulateurStartDto startSimulateur() throws TechnicalException {
        List<InfoSimulateurContratDto> simulateurs = rechercherContratsSimulateurs();
        final List<ParametreDto> parametresTMI = paramConsoleFacade.getParametres(TYPE_TMI, Annee.Precedente);
        return SimulateurStartDto.builder()
                .simulateurs(simulateurs)
                .parametresTMI(parametreMapper.map(parametresTMI))
                .build();
    }

    public List<InfoSimulateurContratDto> rechercherContratsSimulateurs() throws TechnicalException {
        List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();
        contratComplets = filterDisabledContratsAndContratsWithoutC1C4(contratComplets);

        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
        boolean existContratMadelinNotBlocked = contratComplets.stream()
                .filter(c -> c.getContratGeneral().getCodeCadreFiscal().equals(FiscaliteType.FISCMAD.name()))
                .anyMatch(c -> !isContratBloqueOrNotAcceptable(blocagesClient, c));
        return contratComplets.stream()
                .map(c -> handleException(() -> this.buildSimulateurContrat(c, blocagesClient, existContratMadelinNotBlocked)))
                .collect(Collectors.toList());

    }

    private List<ContratComplet> filterDisabledContratsAndContratsWithoutC1C4(List<ContratComplet> contratComplets) {
        return contratComplets.stream()
                .filter(c -> !c.getContratHeader().getAffichageType().isDisabled())
                .filter(c -> c.getContratHeader().hasCompartiments(CompartimentType.C1)
                        || c.getContratHeader().hasCompartiments(CompartimentType.C4))
                .filter(c -> requestContextHolder.getContrat() == null
                        || c.getContratHeader().getId().equals(requestContextHolder.getContrat()))
                .collect(Collectors.toList());
    }

    private boolean isContratBloqueOrNotAcceptable(InfosBlocagesClient blocagesClient, ContratComplet contratComplet) {
        // Fiscalites gérées
        final FiscaliteSimuType fiscaliteSimuType = FiscaliteSimuType.from(
                FiscaliteType.getFiscaliteFromCode(contratComplet.getContratGeneral().getCodeCadreFiscal()));

        final boolean accept = contratComplet.is(CodeSiloType.MDP)
                && (FiscaliteSimuType.PERP.equals(fiscaliteSimuType) || FiscaliteSimuType.MADELIN.equals(fiscaliteSimuType))
                || contratComplet.is(CodeSiloType.ERE) && FiscaliteSimuType.ART83.equals(fiscaliteSimuType);

        // blocage
        final boolean bloque = blocagesClient.isFonctionnaliteBloqueePourContrat(
                contratComplet.getContratHeader().getId(), FonctionnaliteType.SIMULATEUR_FISCAL)
                || contratComplet.getContratHeader().getCompartiments()
                .stream()
                .noneMatch(compartiment -> contratVifHelper.isVifPossible(contratComplet, compartiment.getCompartimentId()));

        return bloque || !accept;
    }


    public InfoSimulateurContratDto buildSimulateurContrat(
            ContratComplet contratComplet, InfosBlocagesClient blocagesClient, boolean existContratMadelin) throws TechnicalException {

        final ContratHeader contratHeader = contratComplet.getContratHeader();

        final FiscaliteSimuType fiscaliteSimuType = FiscaliteSimuType.from(
                FiscaliteType.getFiscaliteFromCode(contratComplet.getContratGeneral().getCodeCadreFiscal()));

        final boolean bloqueOrNotAcceptable = isContratBloqueOrNotAcceptable(blocagesClient, contratComplet);


        MessageDto raisonBlocage = null;
        if (bloqueOrNotAcceptable) {
            raisonBlocage = MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireSimulateurFiscalJahia.SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name())
                    .build();
        }

        BigDecimal montantCotisationVersementAnneePrecedente = null;
        if (FiscaliteSimuType.MADELIN.equals(fiscaliteSimuType)) {
            montantCotisationVersementAnneePrecedente = simulateurFiscalCalculMadelin.calculMontantCotisationsVersementsMadelin(contratHeader, Annee.Precedente);
        }


        return InfoSimulateurContratDto.builder()
                .contrat(contratParcoursMapper.map(contratHeader, true))
                .fiscaliteSimuType(fiscaliteSimuType)
                .bloque(bloqueOrNotAcceptable)
                .raisonBlocage(raisonBlocage)
                .showAlertMadelin(FiscaliteSimuType.PERP.equals(fiscaliteSimuType) && existContratMadelin)
                .montantCotisationVersementAnneePrecedente(montantCotisationVersementAnneePrecedente)
                .build();
    }


    @Override
    public ResultatCalculEpargne calculerDisponibleFiscal(DemandeCalculEpargne demande) throws TechnicalException {
        ContratId contratId = demande.getContrat();
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratId);

        final FiscaliteType fiscaliteType = FiscaliteType.getFiscaliteFromCode(contratComplet.getContratGeneral()
                                                                                             .getCodeCadreFiscal());

        final FiscaliteSimuType fiscaliteSimuType = FiscaliteSimuType.from(fiscaliteType);

        Objects.requireNonNull(fiscaliteSimuType, "Fiscalite " + fiscaliteType + " non supportée");

        switch (fiscaliteSimuType) {
            case ART83:
                return simulateurFiscalCalculArt83.calculerDisponibleFiscal(demande);
            case PERP:
                return simulateurFiscalCalculPerp.calculerDisponibleFiscal(demande);
            case MADELIN:
                return simulateurFiscalCalculMadelin.calculerDisponibleFiscal(demande);
            default:
                throw new IllegalStateException("Fiscalite non implémentée");
        }
    }

}
