package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.function.Consumer;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class ArbitrageContexteDto implements ISecurityParamAccess {
    private ContratId contratSelectionne;
    private CompartimentId compartimentSelectionne;
    private boolean tousCompartimentsSelectionnes = false;
    private QuestionType.ResponseArbitrageFluxStockType responseFluxStockType;
    private QuestionType.ResponseArbitrageTotalPartielType responseTotalPartielType;
    private QuestionType.ResponseArbitrageEurosPourcentageType responseEurosPourcentageType;
    private ModeGestionMdproType responseModeGestionType;
    private boolean parcoursSimplifie;

    /**
     * Force le type d'arbitrage en mode iFrame
     */
    private ParamFluxStock paramFluxStock;

    public void setParamFluxStock(ParamFluxStock param) {
        this.paramFluxStock = param;
    }

    @JsonProperty
    private void setParamFluxStock(String param) {
        this.paramFluxStock = ParamFluxStock.fromString(param);
    }

    @Override
    public String secureForNumContrat() {
        return contratSelectionne.getNomContrat();
    }

    @Override
    public String secureForIdentifiantAssure() {
        return compartimentSelectionne != null ? compartimentSelectionne.getIdAssure() : null;
    }

    /**
     * Permet d'identifier dans le Code les mises &agrave; jour du Contexte (+ explicit)
     *
     * @param consumer
     */
    public void update(Consumer<ArbitrageContexteDto> consumer) {
        consumer.accept(this);
    }
}
