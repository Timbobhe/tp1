package fr.ag2rlamondiale.ecrs.dto.versementsynthese;

import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VersementProgrammeDetailsRequestDto implements ISecurityParamAccess {

    private String codeDocument;
    private ContratId contratId;

    @Override
    public String secureForNumContrat() {
        return contratId != null ? contratId.getNomContrat() : null;
    }
}
