package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportFinancierDto;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.GrilleInvestissementType;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.OccurenceStructureInvestissementType;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.ProfilInvestissementType;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.math.BigDecimal;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class OccurenceStructureInvestissementTypeMdproMapper {

    public abstract OccurenceStructureInvestissementType mapSupportFinancierDtoToOccurenceStructureInvestissementType(SupportFinancierDto supportFinancierDto, BigDecimal montant);

    @Mapping(source = "code", target = "identifiantGrilleInvestissement")
    @Mapping(source = "nom", target = "nomGrilleInvestissement")
    @Mapping(source = "taux", target = "tauxRepartitionGrilleInvestissement")
    @Mapping(source = "tauxModifiable", target = "indicateurTauxDerogeableGrilleInvestissement")
    public abstract GrilleInvestissementType mapSupportToGrilleInvestissementType(SupportFinancierDto supportFinancierDto);

    @Mapping(source = "code", target = "identifiantProfilInvestissement")
    @Mapping(source = "nom", target = "nomProfilInvestissement")
    @Mapping(source = "tauxRepartitionDefaut", target = "tauxRepartitionProfilInvestissement")
    @Mapping(source = "tauxModifiable", target = "indicateurTauxDerogeableProfilInvestissement")
    public abstract ProfilInvestissementType mapSupportToProfilInvestissementType(SupportFinancierDto supportFinancierDto);

    @AfterMapping
    protected void mapGrilleProfil(@MappingTarget OccurenceStructureInvestissementType occurenceStructureInv,
                                   SupportFinancierDto supportFinancierDto, BigDecimal montant) {
        switch (supportFinancierDto.getSupportType()) {
            case GRILLE:
                occurenceStructureInv.setIdentifiantOccurenceStructureInvestissement(supportFinancierDto.getCommonFields().getParentId());
                occurenceStructureInv.setGrilleInvestissement(mapSupportToGrilleInvestissementType(supportFinancierDto));
                break;
            case PROFIL:
                occurenceStructureInv.setIdentifiantOccurenceParentStructureInvestissement(supportFinancierDto.getCommonFields().getParentId());
                occurenceStructureInv.setIdentifiantOccurenceStructureInvestissement(supportFinancierDto.getCommonFields().getId());
                occurenceStructureInv.setProfilInvestissement(mapSupportToProfilInvestissementType(supportFinancierDto));
                break;
            default:
                break;
        }
    }
}
