package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.FormulaireActeEnLigneMapperLocator;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@FormulaireActeEnLigneMapperLocator(FormulaireArbitrageMapper.class)
@EqualsAndHashCode(callSuper = true)
@Data
public class DemandeCreationsigElecArbitrage extends DemandeCreationSigElec<ContratHeader> {
    private QuestionType.ResponseArbitrageFluxStockType responseArbitrageFluxStock;
    private List<SupportFinancierDto> oldRepartition;
    private List<SupportFinancierDto> newRepartition;
    private List<SupportFinancierDto> desinvestissementRepartition;
    private Compartiment compartiment;
    private BigDecimal montant;
    private String deviseEncours;
    private Date dateEncours;
    private boolean pacte;
}
