package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import fr.ag2rlamondiale.ecrs.dto.versement.VersementProgrammeDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ArretVersementDto {
    private VersementProgrammeDto versementProgramme;
    private ContratParcoursDto compartimentSelected;
}
