package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.Getter;

import java.util.List;

@Getter
public enum NatureOdfType {

    REVENU,
    PATRIMOINE,
    PATRIMOINE_HERITAGE,
    PATRIMOINE_DONATION,
    PATRIMOINE_CESSION_IMMO,
    PATRIMOINE_ACTIF_PROFESSIONNEL,
    GAIN_JEU,
    EPARGNE,
    AUTRES;

    public static final List<NatureOdfType> PATRIMOINES = List.of(PATRIMOINE_HERITAGE, PATRIMOINE_DONATION, PATRIMOINE_CESSION_IMMO, PATRIMOINE_ACTIF_PROFESSIONNEL);
}
