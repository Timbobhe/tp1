package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class RepartionActuelleDto {
    private List<RepartitionSupportDto> repartitions;
}
