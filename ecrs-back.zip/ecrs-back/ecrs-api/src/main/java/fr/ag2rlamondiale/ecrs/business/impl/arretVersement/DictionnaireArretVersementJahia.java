package fr.ag2rlamondiale.ecrs.business.impl.arretVersement;

import lombok.Getter;

@SuppressWarnings("squid:S1192")
@Getter
public enum DictionnaireArretVersementJahia {
    MODIF_VERSEMENT_QUESTION_ARRET_MODIF_TITRE("Souhaitez vous arr\u00EAter ou modifier votre versement ?"),
    MODIF_VERSEMENT_ARRET_MODIF_MESSAGE_SOUHAIT("Vous souhaitez :"),
    MODIF_VERSEMENT_ARRET("Arr\u00EAter votre versement"),
    MODIF_VERSEMENT_MODIFICATION("Modifier votre versement");

    private final String label;

    DictionnaireArretVersementJahia(String label) {
        this.label = label;
    }
}
