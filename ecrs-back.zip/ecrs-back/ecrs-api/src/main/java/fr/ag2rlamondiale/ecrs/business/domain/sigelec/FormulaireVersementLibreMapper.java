package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.ecrs.dto.versement.RibStatusType;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireVersementLibre;
import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationAffiliationDansSiloType;
import fr.ag2rlamondiale.formulaire.modificationcoordonneesbancaires.FormulaireModificationCoordonneesBancaires;
import fr.ag2rlamondiale.rib.domain.sigelec.FormulaireModificationCoordonneesBancairesMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.Map;

@Mapper(componentModel = "spring",
        uses = {DateMapper.class, IdentificationContratDansSiloMapper.class,
                IdentificationUserDansSiloMapper.class, IdentificationPersonneDansSiloMapper.class,
                IdentificationDemandeDansSiloMapper.class, InformationsComplementairesMapper.class},
        imports = {StringUtils.class, DateMapper.class}, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class FormulaireVersementLibreMapper extends FormulaireVersementMapper implements IFormulaireMapper {

    @Autowired
    FormulaireModificationCoordonneesBancairesMapper formRIBMapper;

    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today())")
    @Mapping(target = "identificationContratDansSilo", source = "contrat")
    @Mapping(target = "identificationUserDansSilo", source = ".")
    @Mapping(target = "identificationPersonneDansSilo", source = ".")
    @Mapping(target = "identificationDemandeDansSilo", source = ".")
    @Mapping(target = "informationsComplementaires", source = "demande")
    @Mapping(source = "demande", target = "versement", qualifiedByName = "mapVersement")
    @Mapping(source = "demande", target = "repartitionSupportInvestissement", qualifiedByName = "mapRepartitionSupportInvestissement")
    public abstract FormulaireVersementLibre createFormulaireVersementLibre(DemandeCreationSigElecVersementLibre demande);

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireVersementLibre formVRLI = this.createFormulaireVersementLibre((DemandeCreationSigElecVersementLibre) demandeSigElec);

        this.afterMapping(formVRLI, (DemandeCreationSigElecVersementLibre) demandeSigElec);
        if (CodeSiloType.ERE.equals(demandeSigElec.getCodeSilo())
                && formVRLI.getIdentificationContratDansSilo() != null && formVRLI.getIdentificationAffiliationDansSilo() != null) {
            formsMap.put(getCle(
                    formVRLI.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    formVRLI.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    formVRLI.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementLibre(formVRLI));
        } else if (CodeSiloType.MDP.equals(demandeSigElec.getCodeSilo())
                && formVRLI.getIdentificationContratDansSilo() != null && formVRLI.getIdentificationPersonneDansSilo() != null ) {
            formsMap.put(getCle(
                    formVRLI.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    CodeSiloType.MDP.getLibelle(),
                    formVRLI.getIdentificationPersonneDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementLibre(formVRLI));

            if(RibStatusType.NEW.equals(((DemandeCreationSigElecVersementLibre) demandeSigElec).getRibStatusType())) {
                final FormulaireModificationCoordonneesBancaires form = formRIBMapper.createFormulaireModifDonneesBancaires(((DemandeCreationSigElecVersementLibre) demandeSigElec).getFormulaireModificationCoordonneesBancairesDto());
                formsMap.put(getCle(
                        form.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                        form.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                        formVRLI.getIdentificationPersonneDansSilo().getIdentifiantDansSilo(),
                        OperationType.RIBA.name()),
                        marshallFormModificationDonneesBancaires(form));
            }
        }
    }

    private String marshallFormModificationDonneesBancaires(FormulaireModificationCoordonneesBancaires form) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(FormulaireModificationCoordonneesBancaires.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        StringWriter sw = new StringWriter();
        marshaller.marshal(form, sw);
        return sw.toString();
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget FormulaireVersementLibre target, DemandeCreationSigElecVersementLibre demande) {
        if (CodeSiloType.ERE.equals(demande.getCodeSilo())) {
            IdentificationAffiliationDansSiloType identificationAffiliationDansSiloType = new IdentificationAffiliationDansSiloType();
            identificationAffiliationDansSiloType.setIdentifiantDansSilo(demande.getIdentifiantAssure());
            identificationAffiliationDansSiloType.setLibelleNomSilo(FormulaireConstantes.ERE_PTV2_3);
            identificationAffiliationDansSiloType.setCodeApplication(CodeApplicationType.PTV_ERE.getCode());
            identificationAffiliationDansSiloType.setLibelleApplication(FormulaireConstantes.PTV);
            identificationAffiliationDansSiloType.setCodeSystemeInformation(FormulaireConstantes.ERE);
            identificationAffiliationDansSiloType.setLibelleSystemeInformation(FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER);
            target.setIdentificationAffiliationDansSilo(identificationAffiliationDansSiloType);
        }
    }
}
