package fr.ag2rlamondiale.ecrs.business.impl.versement;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.versement.DetailsVersementEREType;
import fr.ag2rlamondiale.ecrs.dto.versement.DetailsVersementMDPROType;
import fr.ag2rlamondiale.ecrs.dto.versement.MontantPossibleDto;
import fr.ag2rlamondiale.ecrs.dto.versement.TypeVersement;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;

@Service
public class VersementGestionMontantService {


    @Autowired
    private IParamConsoleFacade paramConsoleFacade;

    public MontantPossibleDto retrieveMontantsPossibles(ContratHeader contratHeader, TypeVersement typeVersement) {

        final int minMontant;
        final int maxMontant;
        if (contratHeader.isEre()) {
            DetailsVersementEREType detailVersement = DetailsVersementEREType.getDetailFromContratAndType(contratHeader.getNomContrat(), typeVersement, contratHeader.isPacte());
            minMontant = detailVersement.getMinMontantPossible();
            maxMontant = detailVersement.getMaxMontantPossible();
        } else {
            ProduitJson produit = paramConsoleFacade.findProduitMdpro(contratHeader.getTypeContrat(), contratHeader.getNumGenContrat());
            DetailsVersementMDPROType detailVersement = DetailsVersementMDPROType.getDetailFromFiscalite(produit != null ? produit.getLibelleFiscalite() : null);
            minMontant = detailVersement.getMinMontantPossible();
            maxMontant = detailVersement.getMaxMontantPossible();
        }

        return MontantPossibleDto.builder()
                .minMontantPossible(minMontant)
                .maxMontantPossible(maxMontant)
                .build();
    }

    /**
     * Retourne true si le montant est autorise
     *
     * @param contratHeader
     * @param typeVersement
     * @param montant
     * @return
     */
    public boolean verifierMontant(ContratHeader contratHeader, TypeVersement typeVersement, BigDecimal montant) {
        final MontantPossibleDto montantPossible = retrieveMontantsPossibles(contratHeader, typeVersement);
        return montantPossible.getMinMontantPossible() <= montant.intValue()
                && montant.intValue() <= montantPossible.getMaxMontantPossible();

    }
}
