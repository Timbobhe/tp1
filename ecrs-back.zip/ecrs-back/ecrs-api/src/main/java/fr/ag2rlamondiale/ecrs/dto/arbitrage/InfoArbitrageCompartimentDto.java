package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class InfoArbitrageCompartimentDto {
    private ContratParcoursDto compartiment;
    private boolean bloque;
    private MessageDto raisonBlocage;
}
