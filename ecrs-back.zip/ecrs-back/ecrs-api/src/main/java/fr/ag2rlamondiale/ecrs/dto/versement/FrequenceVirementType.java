package fr.ag2rlamondiale.ecrs.dto.versement;

import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.annotation.Nonnull;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum FrequenceVirementType {
    MENSUELLE("mois", "M", "mensuelle", 1, 12),
    TRIMESTRIELLE("trimestre", "T", "trimestrielle", 3, 4),
    SEMESTRIELLE("semestre", "S", "semestrielle", 6, 2),
    ANNUELLE("an", "A", "annuelle", 12, 1);

    private String libelle;
    private String codeFractionnement;
    private String periodicite;
    private int months;
    private int nombreDePeriodesDansUnAn;

    public static FrequenceVirementType forEcheancier(@Nonnull Echeancier echeancier) {
        return FrequenceVirementType.fromCodeFractionnement(echeancier.getCodeFractionnement());
    }

    /**
     * @return le {@link FrequenceVirementType} correspondant au codeFractionnement donné
     */
    public static FrequenceVirementType fromCodeFractionnement(@Nonnull String codeFractionnement) {
        for (FrequenceVirementType frequenceVirementType : values()) {
            if (frequenceVirementType.getCodeFractionnement().equals(codeFractionnement)) {
                return frequenceVirementType;
            }
        }
        throw new RuntimeException("codeFractionnement inconnu: " + codeFractionnement);
    }
}
