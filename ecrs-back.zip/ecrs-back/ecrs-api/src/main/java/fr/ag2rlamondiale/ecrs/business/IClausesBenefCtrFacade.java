package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireStartDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireTerminateDto;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;


public interface IClausesBenefCtrFacade {
    ConsulterClausesBenefCtrResponseDto consulterClausesBenefCtr(String numContrat,
            CodeSiloType silo) throws TechnicalException;

    ClauseBeneficiaireStartDto startModificationClauseBeneficiaire() throws TechnicalException;

    List<ContratHeader> retrieveContractsforModificationClauseBeneficiaire() throws TechnicalException;

    String terminateModificationClauseBeneficiaire(ClauseBeneficiaireTerminateDto dto,
            boolean isFrame) throws CommonException, IOException, JAXBException;
}
