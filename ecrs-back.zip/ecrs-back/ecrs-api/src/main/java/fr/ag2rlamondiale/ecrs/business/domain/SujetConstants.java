package fr.ag2rlamondiale.ecrs.business.domain;

public class SujetConstants {
    public static final int ID_SUJET_REALISER_BIA = -14;
    public static final int ID_SOUS_SUJET_REALISER_BIA = -15;
    public static final String TITRE_REALISER_BIA = "SUJET_COMPLETER_BIA";
    public static final String TITRE_SOUS_SUJET_BIA = "RENSEIGNER_GESTION_FI_ET_CLAUSE";
    public static final String TYPE_REALISER_BIA = "BIA";
    public static final int ID_SUJET_VERIFICATION_IDENTITE = -16;
    public static final String TITRE_VERIFICATION_IDENTITE = "SUJET_VERIFICATION_IDENTITE";
    public static final String TYPE_VERIFICATION_IDENTITE = "VERIFICATIONIDENTITE";
    public static final int ID_SOUS_SUJET_VDPP = -17;
    public static final String TITRE_SOUS_SUJET_VDPP = "VALIDATION_DONNEES_PERSONNELLES";
    public static final int ID_SOUS_SUJET_CONF = -18;
    public static final String TITRE_SOUS_SUJET_CONF = "CONFIRMATION_DONNEES_PERSONNELLES";

    private SujetConstants() {
        // constants
    }
}
