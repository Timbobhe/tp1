package fr.ag2rlamondiale.ecrs.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MetisConfig {

    /**
     * Permet de désactiver (programmativement) le MetisBootResponseEntityExceptionHandler de Metis déjà géré par ECRS
     * via {@link fr.ag2rlamondiale.ecrs.api.error.RestExceptionHandler}
     * <p>
     * <p>
     * Depuis la config :
     * <p>
     * <p>
     * metis.default-response-entity-exception-handler-enable: "false"
     *
     * @return
     * @since metis-boot-1.5.3
     */
    @Bean("metisBootResponseEntityExceptionHandler")
    public Object metisBootResponseEntityExceptionHandler() {
        return "metisBootResponseEntityExceptionHandler";
    }

    /**
     * Permet de désactiver (programmativement) les interceptors Metis : [LoggingUserHandlerInterceptor, LoggingRequestIdHandlerInterceptor] gérées différemments par ECRS
     * puisque l'IDREQ provient du FRONT alors que celui de METIS n'existe que sur le BACK
     * <p>
     * <p>
     * Depuis la config :
     * <p>
     * <p>
     * metis.default-interceptors-web-mvc-configurer-enable: "false"
     *
     * @return
     * @since metis-boot-1.5.3
     */
    @Bean("defaultInterceptorsWebMvcConfigurer")
    public Object defaultInterceptorsWebMvcConfigurer() {
        return "defaultInterceptorsWebMvcConfigurer";
    }
}
