package fr.ag2rlamondiale.ecrs.dto.verificationCaptcha;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Reponse de L'API Google Recaptcha sous forme d'objet JSON
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VerificationCaptchaResponseJson {
	private Boolean success;
	private String challenge_ts;
	private String hostname;
}
