package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.business.even.EvenUtils.*;
import static fr.ag2rlamondiale.trm.domain.CodeApplicationType.EGESPER_ERE;

/**
 * Classe permettant de d&eacute;terminer si la condition relative &agrave; l'&eacute;v&egrave;nement ERE_CONF est v&eacute;rifi&eacute;e.
 */
@Slf4j
@Component
public class EreConfEvenGenerator extends AbstractEvenWithoutContratGenerator {
    @Autowired
    private IWorkflowFacade workflowFacade;

    @Override
    public boolean evaluerEvenement(String numPersonne) {
        try {
            PersonnePhysiqueConsult pp =
                    consulterPersonneClient.consulterPersPhys(IdSiloDto.forAppli(numPersonne, EGESPER_ERE));
            return !pp.isDonneesPersonnellesConfirmees() && !workflowFacade.hasDemandeMdpEncours(numPersonne);
        } catch (Exception e) {
            log.error("Erreur pendant l'evaluation de l'evenement CONF", e);
            return false;
        }
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (!isEre()) {
            return;
        }
        if (!isPersonneAutorisee(idGdi, numPersonne, typeEven.getPerimetreEvenements())) {
            return;
        }

        List<EvenementJson> evenementsForType = getEvenementsForType(typeEven, historiqueEvens).stream()
                .filter(evenementJson -> EtatTraitementType.TRAI.equals(evenementJson.getEtatTraitement()))
                .collect(Collectors.toList());

        if (dejaTraite(evenementsForType)) {
            return;
        }

        if (!respecteDelaiReactivation(typeEven, evenementsForType)) {
            return;
        }
        results.add(this, idGdi, numPersonne, typeEven);
    }
}
