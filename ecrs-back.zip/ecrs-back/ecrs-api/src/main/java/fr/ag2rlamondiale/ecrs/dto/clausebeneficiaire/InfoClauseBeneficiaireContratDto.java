package fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire;

import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class InfoClauseBeneficiaireContratDto extends BasicInfoParcoursDto {
    private ContratParcoursDto contrat;
}
