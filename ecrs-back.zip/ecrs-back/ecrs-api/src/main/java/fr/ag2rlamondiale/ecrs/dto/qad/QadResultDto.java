package fr.ag2rlamondiale.ecrs.dto.qad;

import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.qad.QadResultData;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QadResultDto implements ISecurityParamAccess {
    private ContratId contrat;
    private List<QadResultData> qadResult;
    private FonctionnaliteType fonctionnaliteType;
    private Set<String> codesSupportsContrat;

    @Override
    public String secureForNumContrat() {
        return contrat != null ? contrat.getNomContrat() : null;
    }
}
