package fr.ag2rlamondiale.ecrs.web.security;

import fr.ag2rlamondiale.ecrs.web.EcrsWebConstants;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;
import org.springframework.security.web.csrf.CsrfFilter;
import org.springframework.security.web.util.matcher.AndRequestMatcher;
import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import java.util.List;

import static org.springframework.security.web.csrf.CsrfFilter.DEFAULT_CSRF_MATCHER;


/**
 * https://v7.angular.io/guide/http#security-xsrf-protection
 * <p>
 * ...
 * In order to prevent collisions in environments where multiple Angular apps share the same domain or subdomain,
 * give each application a unique cookie name.
 * ...
 */
@Configuration
public class CsrfConfig {

    @Value("${security.csrf.cookieName:XSRF-A1573-TOKEN}")
    private String csrfCookieName;

    @Value("${security.csrf.headerName:X-XSRF-A1573-TOKEN}")
    private String csrfHeaderName;

    @Value("${security.csrf.cookie.domain:NOT-SET}")
    private String csrfDomain;

    @Setter
    @Value("${security.csrf:false}")
    private boolean isCsrfTokenActivated;

    @Setter
    @Value("${security.csrf.custom.exclude.urls:/**/j_spring_cas_security_check, /**/j_spring_security_logout}")
    private List<String> customExcludeUrlList;

    @Bean(name = "csrfFilter")
    public FilterRegistrationBean<CsrfFilter> csrfFilter() {
        final CookieCsrfTokenRepository csrfTokenRepository = CookieCsrfTokenRepository.withHttpOnlyFalse();
        if (!"NOT-SET".equals(csrfDomain)) {
            csrfTokenRepository.setCookieDomain(csrfDomain);
        }
        csrfTokenRepository.setCookiePath("/");
        csrfTokenRepository.setCookieName(csrfCookieName);
        csrfTokenRepository.setHeaderName(csrfHeaderName);
        final CsrfFilter csrfFilter = new CsrfFilter(csrfTokenRepository);
        if (!isCsrfTokenActivated) {
            csrfFilter.setRequireCsrfProtectionMatcher(request -> false);
        } else {
            csrfFilter.setRequireCsrfProtectionMatcher(activeRequireCsrfProtectionMatcher());
        }

        FilterRegistrationBean<CsrfFilter> frb = new FilterRegistrationBean<>(csrfFilter);
        frb.setEnabled(isCsrfTokenActivated);
        frb.setOrder(EcrsWebConstants.ORDER_FILTER_CRSFR);
        return frb;
    }



    public RequestMatcher activeRequireCsrfProtectionMatcher() {
        RequestMatcher exclude = new AntPathConfig(customExcludeUrlList).toRequestMatcher();
        if (exclude != null) {
            return new AndRequestMatcher(
                    new NegatedRequestMatcher(exclude),
                    DEFAULT_CSRF_MATCHER
            );
        }
        return DEFAULT_CSRF_MATCHER;
    }
}
