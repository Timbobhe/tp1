package fr.ag2rlamondiale.ecrs.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.ag2rlamondiale.ecrs.lmt.security.LimiteConnexionFilter;
import fr.ag2rlamondiale.ecrs.security.PartenaireExceptionFilter;
import fr.ag2rlamondiale.ecrs.web.filter.ClientRequestTracking;
import fr.ag2rlamondiale.ecrs.web.filter.RestoreUserContextSessionFilter;
import fr.ag2rlamondiale.ecrs.web.filter.ThreadLocalFilter;
import fr.ag2rlamondiale.jnb.JahiaNgServerConfig;
import fr.ag2rlamondiale.rib.RibConfig;
import fr.ag2rlamondiale.trm.business.DefaultImplConfig;
import fr.ag2rlamondiale.trm.cas.CasMockConfig;
import fr.ag2rlamondiale.trm.paiementdigital.PaiementDigitalConfig;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.filter.OrderedRequestContextFilter;
import org.springframework.context.annotation.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.method.HandlerTypePredicate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.util.HttpSessionMutexListener;

import static fr.ag2rlamondiale.ecrs.web.EcrsWebConstants.ORDER_REQUEST_CONTEXT_FILTER;

@Configuration
@ComponentScan
@Import({RibConfig.class, DefaultImplConfig.class, JahiaNgServerConfig.class, PaiementDigitalConfig.class, CasMockConfig.class})
public class ApiConfig implements WebMvcConfigurer {

    static {
        SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
    }


    @Bean
    public HttpSessionMutexListener httpSessionMutexListener() {
        return new HttpSessionMutexListener();
    }


    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }

    @Bean(name = "partenaireExceptionFilter")
    public PartenaireExceptionFilter partenaireExceptionFilter() {
        return new PartenaireExceptionFilter();
    }

    @Bean(name = "limiteConnexionFilter")
    public LimiteConnexionFilter limiteConnexionFilter() {
        return new LimiteConnexionFilter();
    }

    @Bean(name = "theadLocalFilter")
    public ThreadLocalFilter threadLocalFilter() {
        return new ThreadLocalFilter();
    }

    @Bean(name = "restoreUserContextSessionFilter")
    public RestoreUserContextSessionFilter restoreUserContextSessionFilter() {
        return new RestoreUserContextSessionFilter();
    }

    @Bean(name = "clientRequestFilter")
    public ClientRequestTracking clientRequestTracking() {
        return new ClientRequestTracking();
    }

    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(-1); // g&eacute;rer applicativement
        return multipartResolver;
    }

    /**
     * https://reflectoring.io/configuring-localdate-serialization-spring-boot/
     * https://docs.spring.io/spring-boot/docs/current-SNAPSHOT/reference/htmlsingle/#howto.spring-mvc.customize-jackson-objectmapper
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return mapper;
    }

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.addPathPrefix("/api", HandlerTypePredicate.forAnnotation(RestController.class));
    }
}
