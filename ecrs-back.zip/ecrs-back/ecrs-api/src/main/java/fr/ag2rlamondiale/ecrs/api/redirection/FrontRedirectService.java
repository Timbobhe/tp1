package fr.ag2rlamondiale.ecrs.api.redirection;

import fr.ag2rlamondiale.ecrs.business.IPartenaireFacade;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.UrlUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Objects;

/**
 * Service de Redirection
 */
@Slf4j
@RestController
@RequestMapping
public class FrontRedirectService {// NOSONAR

    @Autowired
    private IPartenaireFacade partenaireFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @LogExecutionTime
    @GetMapping(path = "/secure/redirectToFront")
    public ResponseEntity<String> redirectToFront(@RequestParam(name = "service") String service) {
        return retrieveResponseEntity(service);
    }

    @LogExecutionTime
    @GetMapping(path = "/secure/swagger")
    public ResponseEntity<String> redirectToSwagger(HttpServletRequest request) {
        final int serverPort = request.getServerPort();
        String url;
        if ((serverPort == 80) || (serverPort == 443)) {
            url = String.format("%s://%s%s/%s", request.getScheme(), request.getServerName(), request.getContextPath(), "api/swagger-ui.html");
        } else {
            url = String.format("%s://%s:%s%s/%s", request.getScheme(), request.getServerName(), serverPort, request.getContextPath(), "api/swagger-ui.html");
        }
        return retrieveResponseEntity(url);
    }

    @LogExecutionTime
    @GetMapping(path = "/public/redirectToPartenaireById")
    public ResponseEntity<String> redirectToPartenaireById(@RequestParam("id") String id) {
        PartenaireJson partenaire = partenaireFacade.findById(id);
        Objects.requireNonNull(partenaire);
        return retrieveResponseEntity(partenaire.getUrlError().concat("?id=LOGOUT"));
    }

    private ResponseEntity<String> retrieveResponseEntity(String url) {
        if (isInvalidURL(url)) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } else {
            final UserContext userContext = userContextHolder.get();
            if(userContext != null && userContext.getPartenaire() != null) {
                final String codePartenaire = userContext.getPartenaire().getCodePartenaire();
                url = UrlUtils.appendQueryParams(url, "fdi", codePartenaire);
            }

            HttpHeaders headers = new HttpHeaders();
            log.info("Redirection to: {}", url);
            headers.add("Location", url);
            return new ResponseEntity<>(headers, HttpStatus.FOUND);

        }
    }

    private boolean isInvalidURL(String service) {
        try {
            new URL(service).toURI();
        } catch (MalformedURLException | URISyntaxException e) {
            return true;
        }
        return false;
    }
}
