/*
 * Cree le 13 sept. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.api.secure;

import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_CACHE;

/**
 * Implementation Spring  service REST pour cache.
 * On ne fait rien de spécial ici; on laisse la partie connexion {@link fr.ag2rlamondiale.ecrs.security.EcrsCasUserDetailsService} qui va charger les contrats de l'assuré connecté.
 */
@RestController
@RequestMapping(path = "/secure")
public class InitCacheRestController {

    @ProfileExecution(codeAction = API_CACHE)
    @LogExecutionTime
    @GetMapping(path = "/cache")
    public Map<String, Object> getCache() {
        Map<String, Object> info = new HashMap<>();
        info.put("App " + CodeApplicationType.AQEA.getCode(), "Create cache for Aquea!");
        return info;
    }
}
