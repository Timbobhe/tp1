package fr.ag2rlamondiale.ecrs.api.secure;

import fr.ag2rlamondiale.trm.business.ICompteDemoFacade;
import fr.ag2rlamondiale.trm.domain.comptedemo.FindCompteDemoRequestDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.PrintWriter;
import java.io.StringWriter;

@RestController
@RequestMapping(path = "/secure/supervision")
public class SupervisionRestController {

    @Autowired(required = false)
    private ICompteDemoFacade compteDemoFacade;

    // http://localhost:8080/ecrs/api/secure/supervision/compte-demo
    // http://localhost:8080/ecrs/api/secure/supervision/compte-demo?refExterne=990000000000000002
    @GetMapping(path = "/compte-demo")
    public ResponseEntity compteDemo(
            @RequestParam(value = "refExterne", required = false) String refExterne,
            @RequestParam(value = "numPersonne", required = false) String numPersonne) {

        if (compteDemoFacade == null || !compteDemoFacade.isActive()) {
            return ResponseEntity.ok("Compte Demo inactif");
        }

        if (refExterne == null && numPersonne == null) {
            refExterne = "990000000000000001";
        }

        final FindCompteDemoRequestDto findReq = FindCompteDemoRequestDto.builder()
                .numReferenceExterne(refExterne)
                .numPersonne(numPersonne)
                .build();

        try {
            return ResponseEntity.ok(compteDemoFacade.findCompteDemo(findReq));
        } catch (Exception e) {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            e.printStackTrace(pw);
            return ResponseEntity.ok("ERREUR => \n" + sw);
        }
    }
}
