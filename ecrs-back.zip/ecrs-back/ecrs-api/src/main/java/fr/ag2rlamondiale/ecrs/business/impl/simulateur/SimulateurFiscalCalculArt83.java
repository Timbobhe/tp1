package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.simulateur.dto.Context;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum.*;

@Service
public class SimulateurFiscalCalculArt83 extends BaseSimulateurFiscalCalcul implements ISimulateurFiscalCalcul {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IEcheancierFacade echeancierFacade;

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private CalculDisponibleCommand calculDispoFiscalCommand;

    @Autowired
    private CalculVersementsComplementairesCommand calculVersComplCommand;

    @Autowired
    private CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Autowired
    private CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Autowired
    private CalculEconomieFiscaleCommand calculGainFiscalCommand;

    @Override
    public ResultatCalculEpargne calculerDisponibleFiscal(DemandeCalculEpargne demande) throws TechnicalException {
        ContratId contratId = demande.getContrat();
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratId);

        // précision pour le param Annee ( on fait la simulation pour savoir le gain
        // fiscal de l'année n+1 )
        demande.setYear(Annee.Courante.getYear());
        final Context<EconomieFiscaleContextKeyEnum, Object> context = initContextSimulateurFiscal(demande);

        ContratHeader contratHeader = contratComplet.getContratHeader();

        // on recupere les cotisations de l'année n-1
        final Annee.BorneAnnee anneeCotisations = Annee.Precedente.borneAnnee();


        final BigDecimal totalCotisationsCET = contratHeader
                .getCompartiments()
                .stream()
                .map(Compartiment::getIdentifiantAssure)
                .distinct()
                .map(idAssure -> calculMontantCotisationsBrutsCET(idAssure, anneeCotisations.toFirstDate(), anneeCotisations.toLastDate()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        final BigDecimal totalCotisationsBrutes = contratHeader
                .getCompartiments()
                .stream()
                .map(Compartiment::getIdentifiantAssure)
                .distinct()
                .map(idAssure -> calculMontantCotisationsBruts(idAssure, anneeCotisations.toFirstDate(), anneeCotisations.toLastDate()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        context.put(COTISATIONS_BRUTES, totalCotisationsBrutes);
        context.put(COTB_CET_NDED, totalCotisationsCET);


        // Appel Moteur Calcul <=> Disponible PERP BRUT
        final BigDecimal plafondVIF = calculDispoFiscalCommand.calculerPlafondVersement(context);
        context.put(EconomieFiscaleContextKeyEnum.PLAFOND_VERSEMENT, plafondVIF);

        // represente le B dans le doc de simulateur
        final BigDecimal cotisationsDeductibles = calculDispoFiscalCommand.calculerMontantCotisationsDeductiblesAvecAbondement(context);

        // VPVL_ANF => les VIFS déjà effectués dans Année N
        // définir les dates bornes de Calcul
        final Annee.BorneAnnee anneeCalcul = Annee.fromYear(demande.getYear())
                                                  .borneAnnee();

        final BigDecimal vifBrutsAnneeFiscale = contratHeader
                .getCompartiments()
                .stream()
                .map(Compartiment::getIdentifiantAssure)
                .distinct()
                .map(idAssure -> getTotalVIFs(idAssure, anneeCalcul.toFirstDate(), anneeCalcul.toLastDate()))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Echeancier echeancier = getVersementsProgrammes(contratId);
        context.put(EconomieFiscaleContextKeyEnum.VERSEMENTS_ECHEANCIER, echeancier);

        context.put(EconomieFiscaleContextKeyEnum.VPVL_ANF, vifBrutsAnneeFiscale);
        calculVersComplCommand.calculVersementLibreSaisiComplEtVersemetsProgrammesEcheancier(context);

        final BigDecimal plafondSecuSociale = context.getBigDecimal(PASS);
        final BigDecimal aVariable = plafondSecuSociale.multiply(new BigDecimal("0.1"));

        final BigDecimal disponibleFiscalGlobal = BigDecimal.ZERO.max(aVariable.subtract(cotisationsDeductibles))
                                                           .max(plafondVIF.subtract(vifBrutsAnneeFiscale));

        context.put(DISPONIBLE_FISCAL_GLOBAL, disponibleFiscalGlobal);

        // US 15692 => somme des versements qui imputent la jauge
        final BigDecimal montantDejaVerse = context.getBigDecimal(VPVL_ANF)
                                             .add(context.getBigDecimal(SOMME_COTISATIONS_AVEC_ABONDEMENT))
                                             .add(context.getBigDecimal(VP_AND_ECHEANCIER));
        context.put(TOTAL_DEJA_VERSE, montantDejaVerse);

        final BigDecimal resteAsaisir = BigDecimal.ZERO.max(plafondVIF.subtract(montantDejaVerse));
        context.put(VLB_COMP, resteAsaisir);

        // Calcul du montant déductible
        calculMontantDeductibleCommand.execute(context);

        // Calcul GainFiscal Annee n+1
        calculGainFiscalCommand.execute(context);

        // effort Epargne reel
        calculEffortEpargneReelCommand.execute(context);

        return buildResultatCalculEpargnefromContext(context);
    }


    private BigDecimal calculMontantCotisationsBrutsCET(String idAssure, Date dateDebut, Date dateFin) {
        List<Operation> operationsCotisationsBrutesCET = operationFacade.getOperationsCotisationsCETERE(idAssure, dateDebut, dateFin);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutesCET, CodeSiloType.ERE);
    }

    private BigDecimal calculMontantCotisationsBruts(String idAssure, Date dateDebut, Date dateFin) {
        List<Operation> operationsCotisationsBrutes = operationFacade.getOperationsCotisationsBrutesERE(idAssure, dateDebut, dateFin);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutes, CodeSiloType.ERE);
    }

    private BigDecimal getTotalVIFs(String idAssure, Date dateDebut, Date dateFin) {
        List<Operation> operationsList = operationFacade.getOperationsVIFERE(idAssure, dateDebut, dateFin);
        return additionnerMontantBrutsOperations(operationsList, CodeSiloType.ERE);
    }

    private Echeancier getVersementsProgrammes(ContratId contratId) throws TechnicalException {
        ContratHeader contratRecherche = contratFacade.rechercherContratParId(contratId);

        List<Echeancier> versementsProgrammes = new ArrayList<>();
        // les versement programme ERE

        if (contratRecherche.is(CodeSiloType.ERE)) {
            for (Compartiment compartiment : contratRecherche.getCompartiments()) {
                List<Echeancier> echanciersSansDetails = echeancierFacade.rechercherEcheanciers(compartiment);
                getEcheanciersDetails(versementsProgrammes, compartiment, echanciersSansDetails);
            }
        }

        if (versementsProgrammes.isEmpty()) {
            return null;
        }
        // On recupère le premier élement car la liste retournée triée par ordre
        // décroissant
        return versementsProgrammes.get(0);
    }

    private void getEcheanciersDetails(List<Echeancier> versementsProgrammes, Compartiment compartiment, List<Echeancier> echanciersSansDetails) throws TechnicalException {
        for (Echeancier e : echanciersSansDetails) {
            if (e.getDateFin() == null || e.getDateFin()
                                           .after(new Date())) {
                Echeancier echeancier = echeancierFacade.consulterEcheancier(compartiment, String.valueOf(e.getEcheancierId()));
                versementsProgrammes.add(echeancier);
            }
        }
    }
}
