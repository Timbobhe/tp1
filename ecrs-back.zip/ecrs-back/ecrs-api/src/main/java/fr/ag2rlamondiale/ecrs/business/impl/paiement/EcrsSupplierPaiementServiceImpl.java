package fr.ag2rlamondiale.ecrs.business.impl.paiement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementGestionMontantService;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.versement.TypeVersement;
import fr.ag2rlamondiale.trm.paiementdigital.business.ISupplierPaiementService;
import fr.ag2rlamondiale.trm.paiementdigital.business.impl.SupplierPaiementDefaultServiceImpl;
import fr.ag2rlamondiale.trm.paiementdigital.dto.ErrorVerificationPaiement;
import fr.ag2rlamondiale.trm.paiementdigital.dto.VerificationPaiementDto;
import fr.ag2rlamondiale.trm.paiementdigital.dto.VerificationPaiementRequestDto;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Primary
@Service
@AppImpl(implemtationOf = ISupplierPaiementService.class)
public class EcrsSupplierPaiementServiceImpl extends SupplierPaiementDefaultServiceImpl {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private VersementGestionMontantService versementGestionMontantService;

    @Override
    public VerificationPaiementDto verifierPaiement(VerificationPaiementRequestDto verifRequest) throws TechnicalException {
        if (verifRequest.getMontant() == null
                || verifRequest.getMontant().compareTo(BigDecimal.ZERO) <= 0) {

            return VerificationPaiementDto.builder()
                    .possible(false)
                    .codeError(ErrorVerificationPaiement.PAIEMENT_DIGITAL_ERREUR_MONTANT_MINIMUM)
                    .build();
        }

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(verifRequest.getContratId());
        if (!versementGestionMontantService.verifierMontant(contratHeader, TypeVersement.VL, verifRequest.getMontant())) {

            return VerificationPaiementDto.builder()
                    .possible(false)
                    .codeError(ErrorVerificationPaiement.PAIEMENT_DIGITAL_ERREUR_MONTANT_MINIMUM)
                    .build();
        }

        return VerificationPaiementDto.builder()
                .possible(true)
                .build();
    }
}
