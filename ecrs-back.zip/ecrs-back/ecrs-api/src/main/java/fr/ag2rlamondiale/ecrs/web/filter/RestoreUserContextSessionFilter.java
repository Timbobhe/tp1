package fr.ag2rlamondiale.ecrs.web.filter;

import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.ecrs.security.EcrsUserDetails;
import fr.ag2rlamondiale.ecrs.web.EcrsWebConstants;
import fr.ag2rlamondiale.trm.security.AuthentificationUtils;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Objects;

@Slf4j
public class RestoreUserContextSessionFilter implements Filter, Ordered {

    @Value("${restore.userContext.activeFailFast:true}")
    private boolean activeFailFast = true;

    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public void init(FilterConfig filterConfig) {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        try {
            final HttpServletRequest request = (HttpServletRequest) servletRequest;
            final HttpServletResponse response = (HttpServletResponse) servletResponse;


            final HttpSession session = request.getSession(false);
            UserContext userContext = null;
            if (session != null) {
                userContext = (UserContext) session.getAttribute(UserContextHolder.SESSION_USER_CONTEXT);
            }

            if (userContext != null) {
                SecurityContext securityContext = SecurityContextHolder.getContext();
                Authentication auth = securityContext != null ? securityContext.getAuthentication() : null;
                if (auth != null) {
                    final EcrsUserDetails principal = (EcrsUserDetails) auth.getPrincipal();
                    if (!Objects.equals(userContext.getAuthentificationUser(), principal.getUsername())) {
                        log.warn("Desynchronisation entre le USERCONTEXT={} et le SECURITYCONTEXT={} de Spring (sessionID={})",
                                 userContext.getAuthentificationUser(), principal.getUsername(), session.getId());

                        if (activeFailFast) {
                            throw new SecurityException(String.format("Desynchronisation entre le USERCONTEXT=%s et le SECURITYCONTEXT=%s de Spring (sessionID=%s)",
                                                                      userContext.getAuthentificationUser(), principal.getUsername(), session.getId()));
                        }
                    }
                }

                userContextHolder.set(userContext);

                MDC.put(FrmkLogKeys.IDENTIFIANT_UTILISATEUR, userContext.getIdGdi());
            }


            filterChain.doFilter(request, response);
        } finally {
            userContextHolder.clean();
        }
    }

    @Override
    public int getOrder() {
        return EcrsWebConstants.ORDER_FILTER_RESTORE_USER_CONTEXTE_SESSION;
    }

}
