package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.mandat.FormulaireCoordonneesBancairesDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;

@Data
@EqualsAndHashCode
@SuperBuilder
@NoArgsConstructor
public class FormulaireModificationCoordonneesBancairesDto {

	private Date date;
	private String idGdi;
	private String idDemandeWkf;
	private String idPersonne;
	private String idContrat;
	private CodeSiloType silo;

	private String nom;
	private String prenom;
	private String email;

	private String codeFiliale; // Utilisé pour l'envoie de mail

	private String idAssure; // @Nullable
	private String raisonSocialeContractante; // contratHeader.getContratGeneral().getContractante()
	private String raisonSocialeAdherente; // @Nullable contratHeader.getAdherente()
	private String referenceExterne; // @Nullable contratHeader.getContratGeneral().getReferenceExterne()

	private FormulaireCoordonneesBancairesDto coordonneesBancairesActuelles;
	private FormulaireCoordonneesBancairesDto coordonneesBancairesModifiees;
}
