package fr.ag2rlamondiale.ecrs.dto.versementsynthese;

import fr.ag2rlamondiale.ecrs.dto.versement.VersementProgrammeDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class VersementSyntheseDto {
    private double montantTotal;
    private Date dateDernierVersement;
    private double montantDernierVersement;
    private Date dateProchainVersement;
    private double montantProchainVersement;
    private VersementProgrammeDto versementProgrammeDto;
}
