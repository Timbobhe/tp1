package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.tracking.TrackingInfoDto;

public interface ITrackingFacade {

    TrackingInfoDto getTrackingInfo() throws TechnicalException;

}
