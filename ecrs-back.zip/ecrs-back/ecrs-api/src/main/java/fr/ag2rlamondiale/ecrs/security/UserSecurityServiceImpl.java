package fr.ag2rlamondiale.ecrs.security;

import com.ag2r.common.exceptions.TechnicalException;
import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratHelper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Slf4j
@Service
public class UserSecurityServiceImpl extends BaseUserSecurityServiceImpl implements UserSecurityService {
    @Autowired
    private IContratFacade contratFacade;


    @Override
    public void initSecurityContext(String idGdi, PersonnePhysique personnePhysique) throws TechnicalException {
        final UserContext userContext = basicInitSecurityContext(idGdi, personnePhysique);

        List<ContratHeader> contrats = contratFacade.rechercherContrats();
        Set<CodeSiloType> silos = new HashSet<>();
        Set<String> idContrats = new HashSet<>();
        Set<String> idAssures = new HashSet<>();
        contrats.forEach(contratHeader -> {
            silos.add(contratHeader.getCodeSilo());
            idContrats.add(contratHeader.getId());
            idAssures.addAll(contratHeader.getIdentifiantsAssures());
        });

        userContext.setSilos(silos);
        userContext.setFilialeACA(ContratHelper.isFilialeACA(contrats));
        userContext.setHasContratEre(ContratHelper.containsEre(contrats));

        securityContext.setIdContrats(idContrats);
        securityContext.setIdAssures(idAssures);

        securityContext.setContextActive(true);
        log.info("Fin initialisation {}", securityContext);
    }


}
