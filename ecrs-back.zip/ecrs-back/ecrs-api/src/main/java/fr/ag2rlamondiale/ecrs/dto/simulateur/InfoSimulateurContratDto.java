package fr.ag2rlamondiale.ecrs.dto.simulateur;

import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class InfoSimulateurContratDto {
    private ContratParcoursDto contrat;
    private boolean bloque;
    private MessageDto raisonBlocage;
    private FiscaliteSimuType fiscaliteSimuType;
    private boolean showAlertMadelin;
    private BigDecimal montantCotisationVersementAnneePrecedente;
}
