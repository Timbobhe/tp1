package fr.ag2rlamondiale.ecrs.dto.sujet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LectureSujetDto {
    private static final long serialVersionUID = -2652841805921974864L;

    private String idGdi;
    private Integer idSujet;
    private Integer idSujetParent;
    private Date dateLecture;
    private String titre;
    private String url;
    private String typeSujet;
    private List<LectureSujetDto> sousSujets;

    public List<LectureSujetDto> getSousSujets() {
        if (sousSujets == null) {
            sousSujets = new ArrayList<>();
        }
        return sousSujets;
    }

    public boolean estLu() {
        return getDateLecture() != null;
    }
}
