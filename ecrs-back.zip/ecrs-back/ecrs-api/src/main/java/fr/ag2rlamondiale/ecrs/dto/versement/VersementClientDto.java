package fr.ag2rlamondiale.ecrs.dto.versement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.NouvelleRepartitionDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.RepartionActuelleDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class VersementClientDto implements ISecurityParamAccess {
    private ContratParcoursDto contrat;
    private CompartimentId compartimentId;
    private BigDecimal montantVersement;
    private FrequenceVirementType periodiciteVersement;
    private Date dateVersement;

    private RibDto coordonneesBancaires;
    private UploadFileDto fichiercoordonneesBancaires;

    private RibStatusType ribStatus;

    private String idTransactionPaiementCB;

    private NouvelleRepartitionDto nouvelleRepartition;

    private RepartionActuelleDto repartitionActuelle;

    private BigDecimal montantVersementActuel;
    private FrequenceVirementType periodiciteVersementActuel;

    private QuestionType.ResponseVersementDeductibiliteType deductibilite;
    private QuestionType.ResponseVersementModeType modeVersement;
    private QuestionType.ResponseVersementMoyenPaiementType moyenPaiement;

    private boolean odfRenseigne;
    private List<UploadFileDto> fichierOriginesFonds;

    @Override
    public void secureAppendIdentifiantsAssure(Set<String> appender) {
        if (compartimentId != null && compartimentId.getIdAssure() != null) {
            appender.add(compartimentId.getIdAssure());
        }
    }
}
