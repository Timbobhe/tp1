package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.ISimulateurFiscalFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.dto.simulateur.InfoSimulateurContratDto;
import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;

@Component
public class SimulateurFiscalAccessibilitySupplier implements IFunctionalityAccessibilitySupplier<SimulateurStartDto> {

    @Autowired
    private ISimulateurFiscalFacade simulateurFiscalFacade;

    @Override
    public boolean accept(FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.SIMULATEUR_FISCAL.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto<SimulateurStartDto> check() throws TechnicalException {
        AccesFonctionnaliteDto<SimulateurStartDto> accesFonctionnalite = new AccesFonctionnaliteDto<>(FonctionnaliteType.SIMULATEUR_FISCAL);

        final SimulateurStartDto simulateurStart = simulateurFiscalFacade.startSimulateur();
        List<InfoSimulateurContratDto> simulateurs = simulateurStart.getSimulateurs();

        boolean isAccessible = CollectionUtils.isNotEmpty(simulateurs)
                && simulateurs.stream().anyMatch(v -> !v.isBloque());
        accesFonctionnalite.setAccessible(isAccessible);
        if (!isAccessible) {
            accesFonctionnalite.setRaison(ContratBlocage.SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name());
        } else {
            accesFonctionnalite.setStartData(simulateurStart);
        }

        return accesFonctionnalite;
    }
}
