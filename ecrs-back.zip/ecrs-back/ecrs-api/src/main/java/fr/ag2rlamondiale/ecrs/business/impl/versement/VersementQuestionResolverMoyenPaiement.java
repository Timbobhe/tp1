package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.dto.versement.MoyenPaiementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleProfilInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.trm.paiementdigital.dto.ConditionsPaiementRequestDto;
import fr.ag2rlamondiale.trm.paiementdigital.dto.ParametrageLabDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementMoyenPaiementType.*;

@Service
public class VersementQuestionResolverMoyenPaiement implements VersementQuestionResolver {

    @Autowired
    private IGestionMandatFacade gestionMandatFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IPaiementFacade paiementFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Override
    public QuestionResponsesDto<MoyenPaiementDto, ?> resolve(QuestionType questionType, VersementContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<MoyenPaiementDto, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.VERSEMENT_CHOIX_PAIEMENT)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_QUESTION_MODE_PAIEMENT_TITRE.name())
                .build());
        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_MODE_PAIEMENT_CHOISI.name())
                .build());
        result.add(reponsePrelevement(contexte));
        if (contexte.isParcoursManuscrit()) {
            result.add(reponseCheque());
        } else if (VERSEMENT_PROGRAMME.equals(contexte.getReponseModeVersementType())) {
            result.setShow(false);
            result.setDefaultValue(reponsePrelevement(contexte));
            contexte.update(ctx -> ctx.setResponseModePaiementType(PRELEVEMENT_AUTOMATIQUE));
        } else {
            try {
                final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
                boolean bloque = blocagesClient.isFonctionnaliteBloqueePourContrat(contexte.getContratSelectionne().getNomContrat(), FonctionnaliteType.CARTE_BANCAIRE);
                if (!bloque) {
                    final ParametrageLabDto paiementDigitalEnabled = paiementFacade.isPaiementDigitalEnabled(contexte.getContratSelectionne(), ConditionsPaiementRequestDto.builder()
                            .montantVersement(contexte.getMontantVersement())
                            .build());
                    if (paiementDigitalEnabled.isAutorise()) {
                        result.add(reponseCarteBancaire(contexte, paiementDigitalEnabled));
                    }
                }
            } catch (Exception e) {
                carteBancaireIndisponible(result);
            }
        }


        if (result.getPropositions().size() == 1) {
            result.setShow(false);
            final ResponseDto<MoyenPaiementDto> defaultResponse = result.getPropositions().get(0);
            result.setDefaultValue(defaultResponse);
            contexte.update(ctx -> ctx.setResponseModePaiementType(Arrays.stream(values()).filter(responseVersementMoyenPaiementType -> responseVersementMoyenPaiementType.name().equals(defaultResponse.getId())).findFirst().orElse(null)));
        }
        return result;
    }

    private void carteBancaireIndisponible(QuestionResponsesDto<MoyenPaiementDto, ?> result) {
        result.add(ResponseDto.<MoyenPaiementDto>builder()
                .id(CARTE_BANCAIRE.name())
                .disabled(true)
                .warningMessage(MessageDto.builder()
                        .jahiaContribId(DictionnaireVersementJahia.VERSEMENT_ERREUR_CARTE_BANCAIRE_INDISPO.name())
                        .build())
                .jahiaDicoEntry(DictionnaireVersementJahia.CARTE_BANCAIRE.name())
                .build());
    }

    private ResponseDto<MoyenPaiementDto> reponseCheque() {
        MoyenPaiementDto moyenPaiementDto = MoyenPaiementDto.builder()
                .moyenPaiementType(CHEQUE_BANCAIRE)
                .build();
        return ResponseDto.<MoyenPaiementDto>builder()
                .id(CHEQUE_BANCAIRE.name())
                .value(moyenPaiementDto)
                .jahiaDicoEntry(DictionnaireVersementJahia.CHEQUE_BANCAIRE.name())
                .build();
    }

    private ResponseDto<MoyenPaiementDto> reponsePrelevement(VersementContexteDto contexte) throws TechnicalException {
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contexte.getContratSelectionne());
        MoyenPaiementDto moyenPaiementDto = MoyenPaiementDto.builder()
                .moyenPaiementType(PRELEVEMENT_AUTOMATIQUE)
                .coordonneesBancairesDto(gestionMandatFacade.consulterCoordonneesBancairesContrat(contratComplet.getContratHeader()))
                .build();
        return ResponseDto.<MoyenPaiementDto>builder()
                .id(PRELEVEMENT_AUTOMATIQUE.name())
                .value(moyenPaiementDto)
                .jahiaDicoEntry(DictionnaireVersementJahia.PRELEVEMENT_AUTOMATIQUE.name())
                .build();
    }

    private ResponseDto<MoyenPaiementDto> reponseCarteBancaire(VersementContexteDto contexte, ParametrageLabDto parametrageLab) throws TechnicalException {
        if (!parametrageLab.isDomiciliationAutorisee()) {
            return ResponseDto.<MoyenPaiementDto>builder()
                    .id(CARTE_BANCAIRE.name())
                    .disabled(true)
                    .warningMessage(MessageDto.builder()
                            .jahiaContribId(DictionnaireVersementJahia.VERSEMENT_CB_DOMICILIATION_INCOMPATIBLE.name())
                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.CARTE_BANCAIRE.name())
                    .build();
        } else if (parametrageLab.isPlafondDepasse()) {
            return ResponseDto.<MoyenPaiementDto>builder()
                    .id(CARTE_BANCAIRE.name())
                    .disabled(true)
                    .warningMessage(MessageDto.builder()
                            .jahiaContribId(DictionnaireVersementJahia.VERSEMENT_CB_PLAFOND_DEPASSE.name())
                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.CARTE_BANCAIRE.name())
                    .build();
        } else if (!isStrategieFinanciereParDefaut(contexte)) {
            return ResponseDto.<MoyenPaiementDto>builder()
                    .id(CARTE_BANCAIRE.name())
                    .disabled(true)
                    .warningMessage(MessageDto.builder()
                            .jahiaContribId(DictionnaireVersementJahia.VERSEMENT_CB_AFFECTATION_FONDS_DIFFERENTE.name())
                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.CARTE_BANCAIRE.name())
                    .build();
        }
        return ResponseDto.<MoyenPaiementDto>builder()
                .id(CARTE_BANCAIRE.name())
                .value(MoyenPaiementDto.builder().moyenPaiementType(CARTE_BANCAIRE).build())
                .jahiaDicoEntry(DictionnaireVersementJahia.CARTE_BANCAIRE.name())
                .build();
    }


    private boolean isStrategieFinanciereParDefaut(VersementContexteDto contexte) throws TechnicalException {
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contexte.getContratSelectionne());

        Compartiment compartiment = contratComplet.getContratHeader().compartiment(contexte.getCompartimentSelectionne());

        final StructInv structInv = contratComplet.compteGeneralesEre(compartiment.getCompartimentId()).getStructInv();

        final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), compartiment.isPacte());
        List<RepartitionSupportDto> repartitionSupportSelectionnes = contexte.getRepartitions();

        if (CollectionUtils.isEmpty(repartitionSupportSelectionnes)) {
            return true;
        }

        boolean isStrategieFinanciereParDefaut = true;
        for (RepartitionSupportDto repartitionSupportSelectionne : repartitionSupportSelectionnes) {
            List<GrilleProfilInv> grilleProfilInvs = contributionTypes.stream()
                    .map(structInv::getContribution)
                    .filter(Objects::nonNull)
                    .flatMap(contributionInv -> contributionInv.getProfilsEtGrilles()
                            .stream()
                            .filter(pg -> (repartitionSupportSelectionne.getId().equalsIgnoreCase(pg.getId()))
                                    && repartitionSupportSelectionne.getPourcentage().compareTo(BigDecimal.valueOf(100).multiply(pg.getTauxRepartition())) == 0))
                    .collect(Collectors.toList());
            isStrategieFinanciereParDefaut = CollectionUtils.isNotEmpty(grilleProfilInvs) && isStrategieFinanciereParDefaut;
        }

        return isStrategieFinanciereParDefaut;
    }

    @Override
    public boolean accept(QuestionType questionType, VersementContexteDto contexte) {
        return QuestionType.VERSEMENT_CHOIX_PAIEMENT.equals(questionType) && contexte.getContratSelectionne() != null;
    }
}
