package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationsigElecArbitrage;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportFinancierDto;
import fr.ag2rlamondiale.ecrs.business.impl.arbitrage.*;
import fr.ag2rlamondiale.ecrs.business.impl.document.QadDocRefType;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterClausesBenefCtrClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ClausesContratDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentMDProRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInvHelper;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK;
import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.*;


@Service
@Slf4j
public class ArbitrageFacadeImpl implements IArbitrageFacade, ApplicationContextAware, InitializingBean {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Autowired
    private ISigElecFacade sigElecfacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ArbitrageQuestionResolverChoixCompartimentERE choixCompartimentERE;

    @Autowired
    private ArbitrageQuestionResolverChoixCompartimentMDP choixCompartimentMDP;

    @Autowired
    private IConsulterClausesBenefCtrClient clausesBenefCtrClient;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Autowired
    private IQadFacade qadFacade;

    @Autowired
    private ContratMDPROHelper contratMDPROHelper;

    @Autowired
    private IParcoursSimplifieFacade parcoursSimplifieFacade;

    private ApplicationContext applicationContext;

    private Collection<ArbitrageQuestionResolver> questionResolvers = new ArrayList<>();

    private static final Set<SituationContratEnum> ETATS_CONTRATS_ENCOURS = Sets.newHashSet(
            SituationContratEnum.EN_COURS, SituationContratEnum.EN_COURS_SANS_PRIME,
            SituationContratEnum.LIBERE_PRIME_OFFICE, SituationContratEnum.LIBERE_PRIME_DEMANDE);

    private static final Set<String> CODES_ETAT_EN_COURS_ERE = Sets.newHashSet(AFFILIATION_SANS_BIA.getCodeValue(),
            AFFILIATION_AVEC_BIA.getCodeValue(), REMIS_ENVIGEUR_SANS_BIA.getCodeValue(),
            REMIS_ENVIGEUR_AVEC_BIA.getCodeValue(), LIBERE.getCodeValue());

    @Override
    public ArbitrageStartDto startModificationArbitrage(ParamFluxStock paramFluxStock) throws TechnicalException {
        List<InfoArbitrageContratDto> infos = rechercherContratsArbitrables(paramFluxStock);

        return ArbitrageStartDto.builder()
                .arbitrages(infos)
                .sigElecOff(infos.stream().allMatch(InfoArbitrageContratDto::isSigElecOff))
                .build();
    }

    @Override
    public <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionArbitrageDto request) throws TechnicalException {
        final QuestionType questionType = request.getQuestionType();
        final ArbitrageContexteDto contexte = request.getContexte();
        final ArbitrageQuestionResolver questionResolver = questionResolvers.stream()
                .filter(resolver -> resolver.accept(questionType, contexte))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Impossible de retrouver le Resolver pour " + questionType + " et " + contexte));
        return questionResolver.resolve(questionType, contexte);
    }

    @Override
    public ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionArbitrageDto request) throws TechnicalException {
        final List<QuestionType> questionTypeList = request.getQuestionTypeList();

        List<QuestionType> aTraiter = Collections.singletonList(request.getQuestionType());
        if (questionTypeList != null && !questionTypeList.isEmpty() && questionTypeList.contains(request.getQuestionType())) {
            aTraiter = questionTypeList.subList(questionTypeList.indexOf(request.getQuestionType()), questionTypeList.size());
        }

        final ListQuestionResponsesDto result = new ListQuestionResponsesDto();
        for (QuestionType questionType : aTraiter) {
            final QuestionResponsesDto<Object, Object> qr = resolveQuestion(request.toBuilder().questionType(questionType).build());
            result.add(qr);
            if (qr.isShow()) {
                result.setQuestionTypeDisplayed(questionType);
                break;
            }
        }

        return result;
    }

    @Override
    public String terminate(ArbitrageTerminateDto arbitrageTerminateDto, boolean isFrame) throws TechnicalException, IOException, JAXBException {
        final ContratId contratId = arbitrageTerminateDto.getContratSelected();
        final CompartimentId compartimentId = getCompartimentIdFromArbitragesClient(arbitrageTerminateDto.getArbitragesClient());
        DocumentDto arbitrageDocument = arbitrageTerminateDto.getContenuArbitrage();
        DocumentDto qadDocument = arbitrageTerminateDto.getContenuQad();

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);
        final Compartiment compartiment = compartimentId != null ? contratHeader.compartiment(compartimentId) : null;

        final DocRefType docRefType = contratHeader.is(CodeSiloType.ERE) ?
                DocumentRefType.ARBITRAGE_EN_LIGNE :
                DocumentMDProRefType.ARBITRAGE_MDPRO_EN_LIGNE;

        DataDocumentContrat documentActeContrat = null;
        if (arbitrageDocument != null && arbitrageDocument.getHtmlContent() != null) {
            documentActeContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId, arbitrageDocument, docRefType);
        }

        DataDocumentContrat documentQadContrat = null;
        if (qadDocument != null && qadDocument.getHtmlContent() != null) {
            final DocRefType qadDocRefType = QadDocRefType.getSpecificQadDoc(docRefType);
            documentQadContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId, qadDocument, qadDocRefType);
        }

        if (documentActeContrat != null) {
            DemandeCreationsigElecArbitrage demandeCreationSigElec = initDemandeCreationSigElecArbitrage(arbitrageTerminateDto, contratHeader,
                    documentActeContrat, documentQadContrat, compartiment);
            return sigElecfacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec,
                    isFrame);
        } else {
            return null;
        }
    }

    private DemandeCreationsigElecArbitrage initDemandeCreationSigElecArbitrage(ArbitrageTerminateDto arbitrageTerminateDto,
                                                                                ContratHeader contratHeader, DataDocumentContrat documentActeContrat,
                                                                                DataDocumentContrat documentQadContrat, Compartiment compartiment) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();

        final String numPersonne = contratHeader.getPersonId();

        DemandeCreationsigElecArbitrage demandeCreationSigElec = new DemandeCreationsigElecArbitrage();
        demandeCreationSigElec.add(documentActeContrat);
        CompteEncours compteEncours = null;
        Encours encoursCompartimentNonPacte = null;
        if (compartiment != null) {
            if (!contratHeader.isPacte() && contratHeader.is(CodeSiloType.ERE)) {
                encoursCompartimentNonPacte = calculerEncoursContratFacade.getEncoursCompartimentEreNonPacte(compartiment);
            } else {
                compteEncours = calculerEncoursContratFacade.getCompteEncoursCompartiment(compartiment);
            }
        }
        if (compteEncours != null) {

            demandeCreationSigElec.setMontant(compteEncours.getMontantEncours());
            demandeCreationSigElec.setDeviseEncours(compteEncours.getDeviseEncours());
            demandeCreationSigElec.setDateEncours(compteEncours.getDateValeur());
        }
        if (encoursCompartimentNonPacte != null) {
            demandeCreationSigElec.setMontant(encoursCompartimentNonPacte.getMontant());
            demandeCreationSigElec.setDateEncours(encoursCompartimentNonPacte.getDate());
        }

        if (documentQadContrat != null) {
            demandeCreationSigElec.add(documentQadContrat);
        }

        demandeCreationSigElec.setCodeAssureur(contratHeader.getCodeAssureur());

        demandeCreationSigElec.setCodeSilo(contratHeader.getCodeSilo());
        demandeCreationSigElec.setTypeDonneeATraiter();

        demandeCreationSigElec.setCompartimentType(compartiment != null ? compartiment.getType() : null);


        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setAgrementsConventionDePreuve(documentActeContrat.getAgrementsConventionDePreuve());
        demandeCreationSigElec.setConventionDePreuveTitre(documentActeContrat.getConventionDePreuveTitre());

        demandeCreationSigElec.setIdentifiantAssure(documentActeContrat.getIdAssure());
        demandeCreationSigElec.setPacte(contratHeader.isPacte());
        demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
        demandeCreationSigElec.setNumPP(numPersonne);
        demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo()));
        demandeCreationSigElec.setTypeOperation(OperationType.ARBI);
        demandeCreationSigElec.setResponseArbitrageFluxStock(arbitrageTerminateDto.getArbitragesClient().get(0).getTypeArbitrage().getValue());
        setOldRepartitionAndDesinvestissementList(arbitrageTerminateDto, contratHeader, demandeCreationSigElec);
        setNewRepartitionList(arbitrageTerminateDto, contratHeader, demandeCreationSigElec);

        return demandeCreationSigElec;
    }

    private void setNewRepartitionList(ArbitrageTerminateDto arbitrageTerminateDto,
                                       ContratHeader contratHeader,
                                       DemandeCreationsigElecArbitrage demandeCreationSigElec) {
        List<SupportFinancierDto> newRepartitionSupportList = new ArrayList<>();
        if (arbitrageTerminateDto.getArbitragesClient() != null) {
            arbitrageTerminateDto.getArbitragesClient().forEach(arbitrageClientDto -> {
                CompartimentId compartimentId = getCompartimentIdFromArbitrageClient(arbitrageClientDto);
                if (compartimentId != null) {
                    fillNewSupportFinancierDtoList(contratHeader, newRepartitionSupportList, arbitrageClientDto, compartimentId);
                } else if (contratHeader.isPacte() && contratHeader.isEre()) {
                    arbitrageClientDto.getCompartimentIds().forEach(compartimentId1 ->
                            fillNewSupportFinancierDtoList(contratHeader, newRepartitionSupportList, arbitrageClientDto, compartimentId1));
                }
            });
        }
        demandeCreationSigElec.setNewRepartition(newRepartitionSupportList);
    }

    private void fillNewSupportFinancierDtoList(ContratHeader contratHeader,
                                                List<SupportFinancierDto> newRepartitionSupportList,
                                                ArbitrageClientDto arbitrageClientDto,
                                                CompartimentId compartimentId1) {
        Compartiment compartiment1 = contratHeader.compartiment(compartimentId1);
        try {
            newRepartitionSupportList.addAll(structureInvFacade.retrieveSupportFinancierList(
                    contratHeader, ContributionType.forCompartiment(compartiment1.getType(),
                            compartiment1.isPacte()), arbitrageClientDto.getNouvelleRepartition().getRepartitions().stream().filter(RepartitionSupportDto::isSelectionned).collect(Collectors.toList()), FonctionnaliteType.ARBITRAGE, compartimentId1));
            normalizePourcentage(newRepartitionSupportList);
        } catch (TechnicalException e) {
            log.error("Erreur lors de la recuperation des supports de la nouvelle repartion du contrat {} de {}", contratHeader.getId(), contratHeader.getPersonId());
        }
    }

    private void setOldRepartitionAndDesinvestissementList(ArbitrageTerminateDto arbitrageTerminateDto,
                                                           ContratHeader contratHeader,
                                                           DemandeCreationsigElecArbitrage demandeCreationSigElec) {
        List<SupportFinancierDto> oldRepartitionSupportList = new ArrayList<>();
        List<SupportFinancierDto> desinvestissementRepartitionSupportList = new ArrayList<>();
        if (arbitrageTerminateDto.getArbitragesClient() != null) {
            arbitrageTerminateDto.getArbitragesClient().forEach(arbitrageClientDto -> {
                CompartimentId compartimentId = getCompartimentIdFromArbitrageClient(arbitrageClientDto);
                if (compartimentId != null) {
                    fillOldSupportFinancierDtoListAndDesinvestissement(contratHeader,
                            oldRepartitionSupportList,
                            desinvestissementRepartitionSupportList,
                            arbitrageClientDto,
                            compartimentId);
                } else if (contratHeader.isPacte() && contratHeader.isEre()) {
                    arbitrageClientDto.getCompartimentIds().forEach(compartimentId1 ->
                            fillOldSupportFinancierDtoListAndDesinvestissement(contratHeader,
                                    oldRepartitionSupportList,
                                    desinvestissementRepartitionSupportList,
                                    arbitrageClientDto,
                                    compartimentId1));
                }
            });
        }
        demandeCreationSigElec.setOldRepartition(oldRepartitionSupportList);
        demandeCreationSigElec.setDesinvestissementRepartition(desinvestissementRepartitionSupportList);
    }

    private void fillOldSupportFinancierDtoListAndDesinvestissement(ContratHeader contratHeader,
                                                                    List<SupportFinancierDto> oldRepartitionSupportList,
                                                                    List<SupportFinancierDto> desinvestissementRepartitionSupportList,
                                                                    ArbitrageClientDto arbitrageClientDto,
                                                                    CompartimentId compartimentId) {
        Compartiment compartiment1 = contratHeader.compartiment(compartimentId);
        try {
            if (arbitrageClientDto.getDesinvestissement().getDesinvestissementsSupport() != null
                    && !arbitrageClientDto.getDesinvestissement().getDesinvestissementsSupport().isEmpty()) {
                desinvestissementRepartitionSupportList.addAll(structureInvFacade.retrieveSupportFinancierList(
                        contratHeader, ContributionType.forCompartiment(compartiment1.getType(),
                                compartiment1.isPacte()), arbitrageClientDto.getDesinvestissement().getDesinvestissementsSupport(), FonctionnaliteType.ARBITRAGE, compartimentId));
                normalizePourcentage(desinvestissementRepartitionSupportList);
            }
            oldRepartitionSupportList.addAll(structureInvFacade.retrieveSupportFinancierList(
                    contratHeader, ContributionType.forCompartiment(compartiment1.getType(),
                            compartiment1.isPacte()), arbitrageClientDto.getRepartitionActuelle().getRepartitions(), FonctionnaliteType.ARBITRAGE, compartimentId));

        } catch (TechnicalException e) {
            log.error("Erreur lors de la recuperation des supports de la repartition actuelle du contrat {} de {}", contratHeader.getId(), contratHeader.getPersonId());
        }
    }

    private void normalizePourcentage(List<SupportFinancierDto> repartitionSupportList) {
        repartitionSupportList.forEach(supportFinancierDto -> {
            if (supportFinancierDto.getTaux().compareTo(BigDecimal.ONE) > 0) {
                supportFinancierDto.setTaux(supportFinancierDto.getTaux().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
            }
        });
    }

    private List<InfoArbitrageContratDto> rechercherContratsArbitrables(ParamFluxStock paramFluxStock) throws TechnicalException {
        List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();

        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();

        return contratComplets.stream()
                .filter(c -> !isCompteCloture(c.getContratHeader()))
                .filter(c -> !contratMDPROHelper.isAutreContrat(c.getContratHeader()))
                .filter(c -> c.getContratHeader().getAffichageType().isSelectable())
                .map(c -> handleException(() -> buildInfoArbitrageContrat(c, paramFluxStock, blocagesClient)))
                .collect(Collectors.toList());
    }

    private InfoArbitrageContratDto buildInfoArbitrageContrat(ContratComplet contratComplet, ParamFluxStock paramFluxStock, InfosBlocagesClient blocagesClient) throws TechnicalException {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        ContratParcoursDto contratParcours = contratParcoursMapper.map(contratHeader, true);

        final boolean bloque = blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.ARBITRAGE);
        final boolean simplifie = parcoursSimplifieFacade.isParcoursSimplifieActivate(contratHeader.getId(), FonctionnaliteType.ARBITRAGE_SIMPLIFIE);
        final InfoArbitrageContratDto result = InfoArbitrageContratDto.builder()
                .contrat(contratParcours)
                .bloque(bloque)
                .isParcoursSimplifie(simplifie)
                .contextJahia(JahiaContextDto.builder().parcoursSimplifie(simplifie).build())
                .qadStatus(QadStatusType.IMPOSSIBLE)
                .nbArbitrageAnnee(contratComplet.getContratGeneral().getOptContratEpargne().getNbeArbitrageAnn())
                .sigElecOff(blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.SIGELEC_ARBITRAGE))
                .build();

        if (bloque) {
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_CONSOLE.name())
                    .build());
            return result;
        }

        return contratComplet.is(CodeSiloType.ERE)
                ? buildInfoArbitrageContratERE(contratComplet, result, paramFluxStock)
                : buildInfoArbitrageContratMDPRO(contratComplet, result);
    }

    private InfoArbitrageContratDto buildInfoArbitrageContratERE(ContratComplet contratComplet, InfoArbitrageContratDto result, ParamFluxStock paramFluxStock) throws TechnicalException {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        final ArbitrageContexteDto mock = new ArbitrageContexteDto();
        mock.setContratSelectionne(contratHeader.getContratId());
        mock.setParamFluxStock(paramFluxStock);
        mock.setParcoursSimplifie(result.isParcoursSimplifie());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> qr = choixCompartimentERE.resolve(contratHeader, mock);
        result.setChoixCompartimentERE(qr);

        if (qr.getData().isContratBloque()) {
            // On n'affiche pas la question et il n'y a pas de proposition => Contrat bloqu&eacute;
            result.setBloque(true);
            result.setRaisonBlocage(qr.getWarningMessage());
        } else if (arbitrageContratEnCoursERE(contratHeader).isParcoursEffectue()) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_ETAT_COMPTE.name())
                    .build());
        } else if (arbitrageContratEnCoursERE(contratHeader).isEncours() && !arbitrageContratEnCoursERE(contratHeader).isSigElecEncoursNonSigne()) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS.name())
                    .build());
        } else if (isMonoSupport(contratHeader) || isPartsNonArbitrablesERE(contratHeader)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_CONDITIONS_CONTRAT.name())
                    .build());
        } else if (isArbitrageEnLigneInterdit(contratComplet)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL.name())
                    .build());
        } else if (isNbeArbitrageAnnReachedERE(contratComplet)) {
            Map<String, String> dateArbitragePossible = new HashMap<>();
            dateArbitragePossible.put("dateArbitragePossible", DateUtils.dateToString(getNewDateForArbitragePossible()));
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_NB_MAX_DEPASSE.name())
                    .jahiaContext(dateArbitragePossible)
                    .build());
        } else if (isArbitrageEnAttenteValorisationERE(contratComplet)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_OPERATIONS_EN_COURS.name())
                    .build());
        }

        return result;
    }

    private InfoArbitrageContratDto buildInfoArbitrageContratMDPRO(ContratComplet contratComplet, InfoArbitrageContratDto result) throws TechnicalException {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        final ArbitrageContexteDto mock = new ArbitrageContexteDto();
        mock.setContratSelectionne(contratHeader.getContratId());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> qr = choixCompartimentMDP.resolve(contratHeader, mock);
        result.setChoixCompartimentERE(qr);
        ContratGeneral contratGeneral = contratComplet.getContratGeneral();

        if (qr.getData().isContratBloque()) {
            // On n'affiche pas la question et il n'y a pas de proposition => Contrat bloqu&eacute;
            result.setBloque(true);
            result.setRaisonBlocage(qr.getWarningMessage());
        } else if (!isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(contratComplet)
                || !isCompteEpargneAssureLibereOrEnCoursMDPRO(contratHeader)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_ETAT_COMPTE.name())
                    .build());
        } else if (isMonoSupport(contratHeader)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_CONDITIONS_CONTRAT.name())
                    .build());
        } else if (!isAssureOrSouscripteurMajeur(contratGeneral)) {
            result.setBloque(true);
            result.setRaisonBlocage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_BLOCAGE_ETAT_COMPTE.name())
                    .build());
        }

        if (result.isBloque()) {
            return result;
        }

        final GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdp = structureInvFacade.getInfoGestionFinanciereActuelleMdp(contratHeader);
        result.setGestionFinanciereActuelleMdp(gestionFinanciereActuelleMdp);

        if (gestionFinanciereActuelleMdp.isFiscalitePEP()) {
            result.setQadStatus(QadStatusType.IMPOSSIBLE);
        } else {
            result.setQadStatus(QadStatusType.OBLIGATOIRE);
        }
        return result;
    }

    @Override
    public ResultParcoursEffectueDto arbitrageContratEnCoursERE(ContratHeader contratHeader) {
        boolean arbitrageEnCours = contratHeader.getCompartiments().stream()
                .allMatch(this::isCompteEpargneAssureLibereOrEnCoursERE);

        if (arbitrageEnCours) {
            return ResultParcoursEffectueDto.builder().contratHeader(contratHeader).parcoursEffectue(true).build();
        }

        try {
            return arbitrageEnCours(contratHeader);
        } catch (WorkflowException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    private boolean isCompteEpargneAssureLibereOrEnCoursERE(Compartiment compartiment) {
        //RM02_1 ERE
        return !CODES_ETAT_EN_COURS_ERE.contains(compartiment.getEtatCompartiment().getCodeValue());
    }

    private boolean isCompteCloture(ContratHeader contratHeader) {
        //RM02_2 ERE
        return contratHeader.getAffichageType().isDisabled();
    }

    @Override
    public boolean isMonoSupport(ContratHeader contrat) {
        //RM03 ERE et MDPRO
        try {
            StructInv structureInvt = structureInvFacade.consulterStructInv(contrat);
            return StructInvHelper.isSFMonoSupport(structureInvt);
        } catch (TechnicalException e) {
            return true;
        }
    }

    @Override
    public boolean isPartsNonArbitrablesERE(ContratHeader contratHeader) {
        //RM03 ERE
        // Cas multisupport, on controle si tous les compartiments ont un
        // taux obligatoire de 100%
        StructInv structureInvt;
        try {
            structureInvt = structureInvFacade.consulterStructInv(contratHeader);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }

        return contratHeader.getCompartiments()
                .stream()
                .flatMap(compartiment -> ContributionType.forCompartiment(compartiment.getType(), compartiment.isPacte()).stream())
                .noneMatch(contributionType -> StructInvHelper.isSupportsDerogeables(structureInvt, contributionType));
    }

    @Override
    public boolean isArbitrageEnLigneInterdit(ContratComplet contratComplet) {
        //RM04 ERE
        return contratComplet.getContratGeneral().getOptContratEpargne().isIndicRefusArbitrageInternet();
    }

    /**
     * Verifie si le nombre d'arbitrage max autoris&eacute;, papier ou en ligne confondu, sur l'ann&eacute;e
     * civile en cours a &eacute;t&eacute; atteint.<br/>
     * On ne comptabilise que les arbitrages suite &agrave; la demande de l'assur&eacute; (Type GARB_A)
     *
     * @param contratComplet
     * @return
     */
    @Override
    public boolean isNbeArbitrageAnnReachedERE(ContratComplet contratComplet) {
        //RM05 ERE
        // Recuperation du nombre max d'arbitrages sur l'annee en cours
        final int nbeArbitrageAnn = contratComplet.getContratGeneral().getOptContratEpargne().getNbeArbitrageAnn();

        if (nbeArbitrageAnn == OptContratEpargne.NB_ARBITRAGE_ILLIMITE) {
            return false;
        }

        // Recuperation des operations arbitrages effectu&eacute; sur l'annee en cours
        // On considere que la limite est atteinte si au moins la limite a &eacute;t&eacute; atteinte pour un compartiment
        return contratComplet.getContratHeader().getCompartiments().stream()
                .map(Compartiment::getIdentifiantAssure)
                .distinct()
                .anyMatch(idAssure -> {
                    final List<Operation> operations = operationFacade.getOperationsForArbitrageERE(idAssure);
                    return operations != null && nbeArbitrageAnn <= operations.size();
                });
    }

    /**
     * Le nombre maximum d'arbitrage(s) autoris&eacute;(s) par periode est atteint.<br/>
     * Donne la date &agrave; partir de laquelle un arbitrage est de nouveau possible.<br/>
     * <p>
     * NB: Aujourd'hui periode annuelle donc 01/01/(year + 1)
     *
     * @return
     */
    @Override
    public Date getNewDateForArbitragePossible() {
        final LocalDate now = LocalDate.now();
        return DateUtils.createDate(1, 1, now.getYear() + 1);
    }

    /**
     * Verifie si une operation d'arbitrage est en cours durant l'annee courante On ne comptabilise
     * que les arbitrages suite &agrave; la demande de l'assur&eacute; (Type GARB_A)
     *
     * @param contratComplet
     * @return
     */
    @Override
    public boolean isArbitrageEnAttenteValorisationERE(ContratComplet contratComplet) {
        // Rechercher les op arbitrages effectues sur l'annee en cours
        return contratComplet.getContratHeader().getCompartiments().stream()
                .map(Compartiment::getIdentifiantAssure)
                .distinct()
                .anyMatch(idAssure -> {
                    final List<Operation> operations = operationFacade.getOperationsEnCoursERE(idAssure).stream()
                            .filter(this::isOperationEnAttenteValorisation)
                            .collect(Collectors.toList());
                    return CollectionUtils.isNotEmpty(operations);
                });
    }

    private boolean isOperationEnAttenteValorisation(Operation operation) {
        return operation.getCodeSituationOperationSilo().equalsIgnoreCase("C") ||
                operation.getCodeSituationOperationSilo().equalsIgnoreCase("P") ||
                operation.getCodeSituationOperationSilo().equalsIgnoreCase("M") ||
                operation.getCodeSituationOperationSilo().equalsIgnoreCase("E");
    }

    private ResultParcoursEffectueDto arbitrageEnCours(ContratHeader contrat) throws WorkflowException {
        final ResultParcoursEffectueDto res = hasDemandeArbitrageInProgress(contrat);
        if (res.isEncours()) {
            return res;
        }

        return ResultParcoursEffectueDto.builder().contratHeader(contrat)
                .workflowParcoursEncours(hasDemandeWorkflowArbitrageEncours()).build();
    }

    /**
     * En v&eacute;rifiant par rapport &agrave; la SIGELEC
     *
     * @param contratHeader
     * @return
     */
    private ResultParcoursEffectueDto hasDemandeArbitrageInProgress(ContratHeader contratHeader) {
        //RM06 ERE
        final String idGDI = userContextHolder.get().getIdGdi();
        final List<SigElecJson> demandesNonAnnules = sigElecfacade.getDemandesSigElecNonAnnule(idGDI, contratHeader.getId(), OperationType.ARBI);

        return ResultParcoursEffectueDto.builder()
                .contratHeader(contratHeader)
                .sigElecEncoursSigne(demandesNonAnnules.stream().anyMatch(dmd -> dmd.getEtatDmd().isSigne()))
                .sigElecEncoursNonSigne(demandesNonAnnules.stream().anyMatch(dmd -> !dmd.getEtatDmd().isSigne()))
                .build();
    }

    /**
     * Verifie s'il existe d&eacute;j&agrave; une demande d'arbitrage en ligne en cours (demande dans le workflow
     * ni cl&ocirc;tur&eacute;e, ni annul&eacute;e).
     *
     * @return
     */
    private boolean hasDemandeWorkflowArbitrageEncours() throws WorkflowException {
        //RM06 ERE
        String idPers = userContextHolder.get().getNumeroPersonneEre();
        return workflowFacade.hasDemandeEncours(idPers, DemandeWorkflowType.EXTRANET_ARBITRAGE)
                || workflowFacade.hasDemandeEnCoursWithCodeAppli(idPers, DemandeWorkflowType.ARBITRAGE, CodeApplicationType.ECRS.getCode());
    }

    @Override
    public boolean isAssureOrSouscripteurMajeur(ContratGeneral contratGeneral) {
        //RM08 MDPRO
        // souscripteurs ou assur&eacute;s mineurs = date de naissance du souscripteur ou de l'assur&eacute;
        // inf&eacute;rieure &agrave; 18 ans
        return DateUtils.estMajeur(contratGeneral.getDateNaissanceContractante())
                && DateUtils.estMajeur(contratGeneral.getDateNaissanceAssurePrincipal());
    }

    @Override
    public boolean isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(ContratComplet contratComplet) {
        //RM01 + RM10 + RM11 MDPRO
        ConsulterClausesBenefCtrResponseDto dto = consulterClausesBenefCtrMDP(contratComplet.getContratHeader().getId());
        return dto != null && (dto.getClausesContrat().isEmpty()
                || (!isCodeTypeBenefPresent(dto.getClausesContrat(), "DGN")
                && !isCodeTypeBenefPresent(dto.getClausesContrat(), "ACC")))
                && isContratMDPROAutorise(contratComplet);
    }

    private boolean isCodeTypeBenefPresent(List<ClausesContratDto> clausesContratDtos,
                                           String codeTypeBenef) {
        for (ClausesContratDto dto : clausesContratDtos) {
            if (codeTypeBenef.equals(dto.getCodeTypeBenef()) && (dto.getDateFinClauseBenef() == null
                    || dto.getDateFinClauseBenef().after(new Date()))) {
                return true;
            }
        }
        return false;
    }

    private ConsulterClausesBenefCtrResponseDto consulterClausesBenefCtrMDP(String numContrat) {
        ConsulterClausesBenefCtrDto dto = new ConsulterClausesBenefCtrDto(CodeSiloType.MDP, numContrat);
        try {
            return clausesBenefCtrClient.consulterClausesBenefCtr(dto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public boolean isCompteEpargneAssureLibereOrEnCoursMDPRO(ContratHeader contratHeader) {
        // RM02 MDPRO
        return ETATS_CONTRATS_ENCOURS.contains(contratHeader.getEtatContrat());
    }

    private boolean isContratMDPROAutorise(ContratComplet contratComplet) {
        ContratHeader contratHeader = contratComplet.getContratHeader();
        ContratGeneral contratGeneral = contratComplet.getContratGeneral();
        if ("PEP".equalsIgnoreCase(contratGeneral.getCodeCadreFiscal())) {
            return contratMDPROHelper.isContratAutoriseNonPacteArbitrage(contratHeader);
        } else {
            return CollectionUtils.isNotEmpty(qadFacade.getPropositionParProduit(contratHeader));
        }
    }

    private CompartimentId getCompartimentIdFromArbitragesClient(List<ArbitrageClientDto> arbitragesClient) {
        List<ArbitrageClientDto> arbitragesClientPossibles = arbitragesClient.stream()
                .filter(arbitrageClientDto -> !(arbitrageClientDto.isImpossible() && arbitrageClientDto.getTypeArbitrage().getValue().equals(ARBITRAGE_STOCK)))
                .collect(Collectors.toList());
        final List<CompartimentId> compartimentIds = arbitragesClientPossibles.stream()
                .map(ArbitrageClientDto::getCompartimentIds)
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
        if (arbitragesClientPossibles.size() == 1 && compartimentIds.size() == 1) {
            return compartimentIds.get(0);
        }
        return null;
    }

    private CompartimentId getCompartimentIdFromArbitrageClient(ArbitrageClientDto arbitrageClient) {
        if (arbitrageClient.isImpossible() && arbitrageClient.getTypeArbitrage().getValue().equals(ARBITRAGE_STOCK)) {
            return null;
        }
        final List<CompartimentId> compartimentIds = arbitrageClient.getCompartimentIds();
        if (compartimentIds.size() == 1) {
            return compartimentIds.get(0);
        }
        return null;
    }

    @Override
    public void setApplicationContext(@Nonnull ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void afterPropertiesSet() {
        final Map<String, ArbitrageQuestionResolver> beansOfType = this.applicationContext.getBeansOfType(ArbitrageQuestionResolver.class);
        this.questionResolvers = beansOfType.values();
    }
}
