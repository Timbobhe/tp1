package fr.ag2rlamondiale.ecrs.dto.versementsynthese;

import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.IdDocGedDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class VersementProgrammeDetailsDto {

	private CoordonneesBancairesDto coordonneesBancaires;
	private IdDocGedDto docGED;
}
