package fr.ag2rlamondiale.ecrs.dto.donneeperso;

public enum DonneesPersoParcoursType {
    CONFIRMATION, MODIFICATION
}
