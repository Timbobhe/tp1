/*
 * Cree le 30 mai 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IPartenaireFacade;
import fr.ag2rlamondiale.trm.client.rest.IPartenaireRestClient;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.MettreAJourIdgdiTemporaireRequete;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.RechercherSousPartenaireRequete;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class PartenaireFacadeImpl implements IPartenaireFacade {

    @Autowired
    private IPartenaireRestClient partenaireRestClient;
    
    @Autowired
    private IContratFacade contratFacade;

    @Override
    public PartenaireJson findById(String id) {
        return partenaireRestClient.findById(id);
    }

    @Override
    public PartenaireJson findSousPartenaire(String primaryPartner, List<String> userContracts) {
        RechercherSousPartenaireRequete requete = new RechercherSousPartenaireRequete();
        requete.setIdContratsPers(userContracts);
        requete.setIdPartenairePrincial(primaryPartner);
        return partenaireRestClient.findSousPartenaire(requete);
    }

    @Override
    public Integer updateIdgdiTemporaire(String codePartenaire, String numPersEre, String numPersMdp, String realIdGdi) {
        MettreAJourIdgdiTemporaireRequete requete = new MettreAJourIdgdiTemporaireRequete();
        requete.setCodePartenaire(codePartenaire);
        requete.setNumPersEre(numPersEre);
        requete.setNumPersMdp(numPersMdp);
        requete.setIdGdi(realIdGdi);
        return partenaireRestClient.updateIdgdiTemporaire(requete);
    }

    @Override
    public PartenaireJson findPartenaire(String primaryPartner, String secondaryPartner, String numPP) throws TechnicalException {
        PartenaireJson partenaire = null;
        if (primaryPartner != null) {
            if (secondaryPartner != null) {
                partenaire = findById(secondaryPartner);
                if (partenaire == null) {
                    log.warn("Le sous-partenaire {}, transmis par le partenaire {} est inconnu.", secondaryPartner,
                            primaryPartner);
                } else if (!primaryPartner.equals(partenaire.getCodePartenairePrincipal())) {
                    partenaire = null;
                    log.warn("Le partenaire {} n'est pas le partenaire principal du sous-partenaire {}.", primaryPartner,
                            secondaryPartner);
                }
                if (partenaire == null) {
                    partenaire = findById(primaryPartner);
                }
            } else if(numPP == null) {
                partenaire = findById(primaryPartner);
            } else {
                partenaire = findSousPartenaire(primaryPartner,
                        contratFacade.rechercherContrats().stream().map(ContratHeader::getId).collect(Collectors.toList()));
            }
        }
        return partenaire;
    }
}
