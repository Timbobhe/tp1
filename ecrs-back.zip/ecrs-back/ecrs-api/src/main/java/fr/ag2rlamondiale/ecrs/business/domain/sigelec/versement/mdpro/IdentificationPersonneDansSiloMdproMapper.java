package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.formulaire.formulaireversementlibre.IdentificationDansSiloType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", imports = {CodeApplicationType.class})
public abstract class IdentificationPersonneDansSiloMdproMapper {

    @Named("mapIdentificationPersonneDansSilo")
    @Mapping(target = "identifiantDansSilo", source = "personPhysique.id")
    @Mapping(target = "libelleNomSilo", source = "contrat.codeSilo", qualifiedByName = "libelleNomSilo")
    @Mapping(target = "codeApplication", source = "contrat.codeSilo", qualifiedByName = "codeApplicationEgesper")
    @Mapping(target = "libelleApplication", source = "contrat.codeSilo", qualifiedByName = "libelleApplicationEgesper")
    @Mapping(target = "codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)
    public abstract IdentificationDansSiloType mapToIdentificationPersonneDansSilo(DemandeCreationSigElec demande);

    @Named("libelleNomSilo")
    protected String libelleNomSilo(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getLibelle();
    }

    @Named("codeApplicationEgesper")
    protected String codeApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getCode();
    }

    @Named("libelleApplicationEgesper")
    protected String libelleApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getLibelle();
    }
}
