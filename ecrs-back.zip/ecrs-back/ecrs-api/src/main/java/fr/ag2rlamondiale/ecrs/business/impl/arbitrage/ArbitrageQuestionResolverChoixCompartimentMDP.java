package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ChoixCompartimentDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.*;

@Service
public class ArbitrageQuestionResolverChoixCompartimentMDP implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Override
    public QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        return resolve(contratHeader, contexte);
    }

    public QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolve(ContratHeader contratHeader, ArbitrageContexteDto contexte) throws TechnicalException {

        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT)
                .jahiaDicoEntry(ARB_QUESTION_COMPARTIMENT_TITRE.name())
                .build());
        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_ARBITRER.name())
                .build());
        result.setData(new BlocageArbitrageContratDto());
        result.setShow(false);

        final EncoursDto encoursTotal = calculerEncoursContratFacade.getEncoursDto(contratHeader);

        final String labelTousCompartiments = contratHeader.isPacte() ?
                ARB_TOUT_CONTRAT.name():
                DictionnaireArbitrageJahia.ARB_TOUT_CONTRAT.name();

        final ResponseDto<ChoixCompartimentDto> tousCompartiments = ResponseDto.<ChoixCompartimentDto>builder()
                .id("tous-les-compartiments")
                .value(ChoixCompartimentDto.builder()
                        .tousCompartiments(true)
                        .encours(encoursTotal)
                        .build())
                .jahiaDicoEntry(labelTousCompartiments)
                .build();
        result.setDefaultValue(tousCompartiments);
        result.add(tousCompartiments);

        return result;
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getContratSelectionne().is(CodeSiloType.MDP);
    }
}
