package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersement;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersementProgramme;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportFinancierDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementModeDePaiementType;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.*;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public abstract class FormulaireVersementMdproMapper implements IFormulaireMapper {
    private static final String DEVISE_EUR = "EUR";

    @Autowired
    private OccurenceStructureInvestissementTypeMdproMapper occurenceStructureInvestissementTypeMapper;

    @Named("mapVersement")
    public VersementType mapVersement(DemandeCreationSigElecVersement dto) {
        RibDto coordonneesbancairesIn = dto.getCoordonneesBancairesDto();
        VersementType versementType = new VersementType();
        if (VersementModeDePaiementType.PRELEVEMENT_AUTOMATIQUE == dto.getModePaiement()) {
            CoordonneesBancairesInternationaleType coordonneesBancairesInternationale = new CoordonneesBancairesInternationaleType();
            coordonneesBancairesInternationale.setTitulaireCompte(coordonneesbancairesIn.getTitulaire());
            coordonneesBancairesInternationale.setCodeBIC(coordonneesbancairesIn.getBic());
            coordonneesBancairesInternationale.setCodeIBAN(coordonneesbancairesIn.getIban());
            versementType.setCoordonneesBancairesInternationale(coordonneesBancairesInternationale);
        }
        if (dto.getModePaiement() != null) {
            versementType.setModePaiementVersement(dto.getModePaiement().getCle());
        }
        if (dto.getMontant() != null) {
            versementType.setMontantVersement(dto.getMontant());
        }
        versementType.setDeviseVersement(DEVISE_EUR);
        versementType.setDateVersement(DateMapper.map(dto.getDateDebutVersement()));
        if (dto instanceof DemandeCreationSigElecVersementProgramme) {
            versementType.setCodePeriodicite(((DemandeCreationSigElecVersementProgramme) dto).getFrequenceVersement().getCodeFractionnement());
            versementType.setLibellePeriodicite(((DemandeCreationSigElecVersementProgramme) dto).getFrequenceVersement().getPeriodicite());
        }
        versementType.setDelaiTraitementIndicatif(new BigDecimal(5));
        return versementType;
    }

    @Named("mapStructureInvestissementType")
    public StructureInvestissementType mapRepartitionSupportInvestissement(DemandeCreationSigElecVersement dto) {
        List<SupportFinancierDto> supports = dto.getSupports();
        StructureInvestissementType supportInvestissementType = new StructureInvestissementType();

        List<OccurenceStructureInvestissementType> occurenceStructureInvestissementTypes = new ArrayList<>();
        BigDecimal montant = null;
        if (CollectionUtils.isNotEmpty(supports)) {
            supports.forEach(supportFinancierDto -> {
                if (supportFinancierDto.getContributionInvParent() != null) {
                    IdentificationStructureInvestissementType identificationStructureInvestissementType = new IdentificationStructureInvestissementType();
                    identificationStructureInvestissementType.setIdentifiantStructureInvestissement(
                            supportFinancierDto.getCommonFields().getParentId());
                    supportInvestissementType.setIdentificationStructureInvestissement(identificationStructureInvestissementType);
                }
                occurenceStructureInvestissementTypes.add(occurenceStructureInvestissementTypeMapper
                        .mapSupportFinancierDtoToOccurenceStructureInvestissementType(supportFinancierDto, montant));
            });

            supportInvestissementType.getOccurenceStructureInvestissement().addAll(occurenceStructureInvestissementTypes);

        }
        return supportInvestissementType;
    }
}
