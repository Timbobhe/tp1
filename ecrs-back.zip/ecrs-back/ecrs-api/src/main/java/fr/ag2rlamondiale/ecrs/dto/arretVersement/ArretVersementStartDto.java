package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ArretVersementStartDto {
    private List<InfoArretVersementContrat> infos;
    private boolean sigElecOff;
}
