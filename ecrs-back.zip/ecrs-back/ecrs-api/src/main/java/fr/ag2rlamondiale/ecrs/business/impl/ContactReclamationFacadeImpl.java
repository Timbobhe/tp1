package fr.ag2rlamondiale.ecrs.business.impl;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContactReclamationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ReclamationResponseDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.IdDemSilo;
import fr.ag2rlamondiale.trm.domain.workflow.StatutDemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.ecriture.FormulaireContactDto;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demandes;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.dto.reclamation.State.*;

@Slf4j
@Service
public class ContactReclamationFacadeImpl implements IContactReclamationFacade {
    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IConsulterPersPhysFacade persPhysFacade;

    @Autowired
    private CommunicationClientFacadeImpl communicationClientFacade;

    @Autowired
    private ContratFacadeImpl contratFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Override
    public List<ContratParcoursDto> start() throws TechnicalException {
        List<ContratHeader> contratHeaders = contratFacade.rechercherContrats();

        return contratHeaders.stream()
                .filter(c -> c.getAffichageType().isSelectable())
                .map(c -> contratParcoursMapper.map(c))
                .collect(Collectors.toList());
    }

    @Override
    public ReclamationResponseDto createDemande(ContactReclamationDto dto) throws TechnicalException {
        if (dto == null) {
            return new ReclamationResponseDto(KO, "requete null");
        }
        ContratHeader contratHeader = contratFacade.rechercherContratParId(dto.getIdContrat());
        dto.setIdPersonne(contratHeader.getPersonId());
        if (isLimiteCinqDemandesParJourAtteinte(dto)) {
            return new ReclamationResponseDto(LIMITED, "limite atteinte");
        }
        ReclamationResponseDto retour = new ReclamationResponseDto(OK, null);
        final CodeSiloType codeSilo = getCodeSilo(dto);
        if (CodeSiloType.ERE == codeSilo) {
            dto.setCodeFiliale(contratHeader.getCodeFiliale());
            FormulaireContactDto formulaireContactDto = mapperContactReclamationToFormulaireContact(dto);
            IdDemSilo result = workflowFacade.creerDemandeWorkflow(formulaireContactDto);
            if (result == null) {
                retour.setState(KO);
                retour.setErrorTag("erreur envoi demande workflow");
            }
            boolean mailClient = communicationClientFacade.creerMailNotificationContact(Collections.singletonList(dto.getEmail()), dto.getCodeFiliale());
            if (!mailClient) {
                log.warn("L'envoi de mail d'information a échoué");
            }
        } else if (CodeSiloType.MDP == codeSilo) {
            boolean res = communicationClientFacade.creerDemandeEmailContactAkio(dto);
            if (!res) {
                retour.setState(KO);
                retour.setErrorTag("erreur envoi de mail");
            }
        } else {
            throw new TechnicalException("Code silo erroné");
        }
        return retour;
    }

    @Override
    public boolean isLimiteCinqDemandesParJourAtteinte(ContactReclamationDto dto) throws WorkflowException {
        if (CodeSiloType.MDP.equals(dto.getCodeSilo())) {
            // MDP -> toujours false car pas de moyen de le savoir
            return false;
        }
        RechDemFront rechDemFront = new RechDemFront();
        rechDemFront.setIdPers(dto.getIdPersonne());
        List<String> opeDem = new ArrayList<>();
        opeDem.add(DemandeWorkflowType.QUESTION_VIF_SALARIE.name());
        opeDem.add(DemandeWorkflowType.QUESTION_GESTION_SALARIE.name());
        opeDem.add(DemandeWorkflowType.QUESTION_FONCT_SITE_SALARIE.name());
        Date dateMin = DateUtils.getTodayTimelessDate();
        rechDemFront.setDateDemMin(dateMin);
        rechDemFront.setOpeDem(opeDem);
        Demandes demandes = workflowFacade.rechercherDemandes(rechDemFront);
        return demandes.size() >= 5;
    }

    private CodeSiloType getCodeSilo(ContactReclamationDto dto) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(dto.getIdContrat());
        if (contratHeader.isMdpro() || contratHeader.isPetitCollectifPTV()) {
            return CodeSiloType.MDP;
        }

        return contratHeader.getCodeSilo();
    }

    public FormulaireContactDto mapperContactReclamationToFormulaireContact(ContactReclamationDto dto) throws TechnicalException {
        PersonnePhysiqueConsult personne = persPhysFacade.consulterPersPhys(userContextHolder.get().getIdSilo());

        final DemandeWorkflowType demandeWorkflowType = getDemandeWorkflowType(dto);
        // Pas de Workflow MDP => demandeWorkflowType = null, on considere getCodeQuestion = libelle = themeMessage
        final String libelleTypeQuestion = demandeWorkflowType != null ? demandeWorkflowType.getLibelle() : dto.getCodeQuestion();


        return FormulaireContactDto.builder()
                .idGdi(userContextHolder.get().getIdGdi())
                .typeAction(StatutDemandeWorkflowType.STANDARD.name())
                .demandeWorkflowType(demandeWorkflowType)
                .date(Calendar.getInstance().getTime())
                .idPersonne(dto.getIdPersonne())
                .idContrat(dto.getIdContrat())
                .silo(dto.getCodeSilo())
                .codeTypeQuestion(dto.getCodeQuestion())
                .libelleTypeQuestion(libelleTypeQuestion)
                .message(dto.getMessage())
                .reclamation(dto.isReclamation())
                .idAssure(dto.getIdAssure())
                .nom(userContextHolder.get().getNom())
                .prenom(userContextHolder.get().getPrenom())
                .dateNaissance(personne.getDateDeNaissance())
                .civilite(personne.getCivilite())
                .emailPro(dto.getEmail())
                .raisonSociale(dto.getRaisonSociale())
                .build();
    }

    public DemandeWorkflowType getDemandeWorkflowType(ContactReclamationDto form) {
        if (CodeSiloType.MDP == form.getCodeSilo()) {
            return null;
        }

        if (StringUtils.equals("1", form.getCodeQuestion())) {
            return DemandeWorkflowType.QUESTION_GESTION_SALARIE;
        } else if (StringUtils.equals("2", form.getCodeQuestion())) {
            return DemandeWorkflowType.QUESTION_FONCT_SITE_SALARIE;
        } else if (StringUtils.equals("3", form.getCodeQuestion())) {
            return DemandeWorkflowType.QUESTION_VIF_SALARIE;
        } else {
            throw new UnsupportedOperationException("CodeQuestion " + form + " inconnu");
        }
    }
}
