package fr.ag2rlamondiale.ecrs.business.impl.versement;

import lombok.Getter;

@SuppressWarnings("squid:S1192")
@Getter
public enum DictionnaireVersementJahia {
    VERSEMENT_BLOCAGE_CONSOLE("Pour des raisons techniques, l&amp;#039;acc\u00E8s au contrat est momentan\u00E9ment indisponible."),
    VERSEMENT_BLOCAGE_ETAT_COMPTE("L\u2019\u00E9tat de ce compte de retraite ne vous permet pas de r\u00E9aliser un versement."),
    VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT("Les conditions de votre contrat ne vous permettent pas d&amp;#039;acc\u00E9der \u00E0 cette fonctionnalit\u00E9."),
    VERSEMENT_BLOCAGE_VERSEMENT_EN_COURS("Une demande de versement est d\u00E9j\u00E0 en cours de traitement par nos services. Vous devez attendre son traitement avant de proc\u00E9der \u00E0 un nouveau versement."),
    VERSEMENT_BLOCAGE_DONNEES_PERSO_EN_COURS("Vous avez des modifications de donn\u00E9es personnelles en cours. Pour pouvoir faire votre acte en ligne, vos modifications de donn\u00E9es personnelles doivent \u00EAtre valid\u00E9es."),
    VERSEMENT_BLOCAGE_STATUT("Le statut de votre contrat ne vous permet pas d\u2019acc\u00E9der \u00E0 cette fonctionnalit\u00E9"),
    VERSEMENT_CB_DOMICILIATION_INCOMPATIBLE("Domiciliation incompatible avec paiement CB."),
    VERSEMENT_CB_PLAFOND_DEPASSE("Plafond autoris\u00E9 par le groupe d\u00E9pass\u00E9."),
    VERSEMENT_CB_AFFECTATION_FONDS_DIFFERENTE("Affectation des fonds diff\u00E9rente de celle par d\u00E9faut."),
    VERSEMENT_ERREUR_CARTE_BANCAIRE_INDISPO("Le paiement par carte bancaire est temporairement indisponible"),

    VERSEMENT_QUESTION_DEDUCTIBILITE_TITRE("Choisissez votre type de versement"),
    VERSEMENT_DEDUCTIBILITE_MESSAGE_SOUHAIT("Type de versement :"),
    VERSEMENT_DEDUCTIBLE("D\u00E9ductible"),
    VERSEMENT_NON_DEDUCTIBLE("Non d\u00E9ductible"),

    VERSEMENT_QUESTION_MODE_TITRE("Choisissez votre mode de versement"),
    VERSEMENT_MODE_MESSAGE_SOUHAIT("Mode de versement :"),
    VERSEMENT_LIBRE("Libre"),
    VERSEMENT_PROGRAMME("Programm\u00E9"),
    VERSEMENT_PROGRAMME_EN_COURS("Vous avez d\u00E9j\u00E0 un versement programm\u00E9 sur ce contrat"),

    VERSEMENT_QUESTION_MODE_PAIEMENT_TITRE("Choisissez votre mode de paiement"),
    VERSEMENT_MODE_PAIEMENT_CHOISI("Mode de paiement choisi :"),
    CHEQUE_BANCAIRE("Ch\u00E8que"),
    PRELEVEMENT_AUTOMATIQUE("Pr\u00E9l\u00E8vement automatique"),
    CARTE_BANCAIRE("Carte bancaire");

    private final String label;

    DictionnaireVersementJahia(String label) {
        this.label = label;
    }
}
