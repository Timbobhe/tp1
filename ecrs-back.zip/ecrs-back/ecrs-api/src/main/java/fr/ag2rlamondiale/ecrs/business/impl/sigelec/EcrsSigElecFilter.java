package fr.ag2rlamondiale.ecrs.business.impl.sigelec;

import fr.ag2rlamondiale.trm.business.sigelec.ISigElecFilter;
import fr.ag2rlamondiale.trm.business.sigelec.SigElecParamsHolder;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.DonneeATraiterJson;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireArbitrage;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class EcrsSigElecFilter implements ISigElecFilter {

    @Override
    public boolean filter(SigElecJson demande, SigElecParamsHolder params) {
        final String type = params.getType();
        final ParamFluxStock paramFluxStock = ParamFluxStock.fromString(type);
        if (paramFluxStock == null) {
            return true;
        }

        return filtreTypeArbitrageNie(demande, params.getOperation(), paramFluxStock);
    }

    private boolean filtreTypeArbitrageNie(SigElecJson demande, OperationType operationType, ParamFluxStock type) {
        if (!OperationType.ARBI.equals(operationType) || type == null) {
            return true;
        }

        if (demande.getDonneeATraiters() != null) {
            Optional<DonneeATraiterJson> donneeATraiterJsonOptional = demande.getDonneeATraiters().stream().findFirst();
            if (donneeATraiterJsonOptional.isPresent()) {
                String contenu = donneeATraiterJsonOptional.get().getContenu();
                FormulaireArbitrage formulaireArbitrage = XmlMarshaller.fromXml(contenu, FormulaireArbitrage.class);
                if (ParamFluxStock.FLUX.equals(type)) {
                    return formulaireArbitrage.getArbitrageFlux() != null;
                } else if (ParamFluxStock.STOCK.equals(type)) {
                    return formulaireArbitrage.getArbitrageStock() != null;
                }
                return true;
            }
            return true;
        }
        return true;
    }

}
