package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
public class SujetMapper {

    public void map(LectureSujetJson lectureSujetJson, LectureSujetDto res) {
        res.setIdGdi(lectureSujetJson.getIdGdi());
        res.setIdSujet(lectureSujetJson.getSujet().getIdSujet());
        res.setIdSujetParent(lectureSujetJson.getSujet().getIdSujetParent());
        res.setDateLecture(lectureSujetJson.getDateLecture());
        res.setTitre(lectureSujetJson.getSujet().getTitre());
        res.setUrl(lectureSujetJson.getSujet().getUrl());
        res.setTypeSujet(lectureSujetJson.getSujet().getTypeSujet());
    }

    public SujetDto toSujetDto(SujetJson sujetJson) {
        return SujetDto.builder()
                .idSujet(sujetJson.getIdSujet())
                .titre(sujetJson.getTitre())
                .typeSujet(sujetJson.getTypeSujet())
                .url(sujetJson.getUrl())
                .sousSujets(sujetJson.getSousSujets().stream()
                        .map(SujetJson::getIdSujet)
                        .collect(Collectors.toList()))
                .build();
    }

    public LectureSujetDto toLectureSujetDto(SujetDto sujet, String idGdi){
        LectureSujetDto lecture = new LectureSujetDto();
        lecture.setIdGdi(idGdi);
        lecture.setIdSujet(sujet.getIdSujet());
        lecture.setTypeSujet(sujet.getTypeSujet());
        lecture.setTitre(sujet.getTitre());
        lecture.setUrl(sujet.getUrl());
        return lecture;
    }

    public LectureSujetDto toLectureSujetDto(LectureSujetJson lectureSujetJson) {
        LectureSujetDto res = new LectureSujetDto();
        map(lectureSujetJson, res);
        return res;
    }
}
