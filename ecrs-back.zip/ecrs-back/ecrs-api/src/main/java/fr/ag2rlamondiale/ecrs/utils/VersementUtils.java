package fr.ag2rlamondiale.ecrs.utils;

import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.PrelevementCodeSituationType;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public final class VersementUtils {
    /**
     * @return {@code true} si des versements programmés sont en cours pour l'échéancier donné
     */
    public static boolean hasVersementsProgrammes(Echeancier echeancier) {
        if (echeancier == null) {
            return false;
        }

        Date today = new Date();
        Date debut = echeancier.getDateDebut();
        Date fin = echeancier.getDateFin();
        return today.after(debut) && (fin == null || fin.after(today));
    }

    public static Date getPremiereDateVersementPossible(Echeancier echeancier, Integer delaiTeletransmission) {
        return getPremiereDateVersementPossible(echeancier, delaiTeletransmission, false);
    }

    /**
     * La date retournée peut être modifiée librement.
     *
     * @return la première date possible pour un versement programmé
     */
    public static Date getPremiereDateVersementPossible(Echeancier echeancier, Integer delaiTeletransmission, boolean isPourListeDates) {
        // L'échéancier est non-null s'il y a des versements programmés en cours
        if (echeancier == null) {
            return getPremiereDateSansEcheancier(delaiTeletransmission);
        }

        final List<Prelevement> prelevements = echeancier.getPrelevements();

        // Si aucune date de prélèvement n'est trouvée, on prend par défaut la date début
        if (CollectionUtils.isEmpty(prelevements)) {
            return getPremiereDateSansEcheancier(delaiTeletransmission);
        }

        // Recuperation et tri des dates des prélèvement ayant la situation 'TRANS'
        final List<Date> transPrelevementDates = echeancier.getPrelevements().stream()
                .filter(p -> p.getCodeSituationPrelevement().equals(PrelevementCodeSituationType.TRANS.name()))
                .map(Prelevement::getDatePrelevement)
                .sorted()
                .collect(Collectors.toList());

        // Si aucune date de prélèvement n'est trouvée ayant la situation 'TRANS', on prend par défaut la date début
        if (CollectionUtils.isEmpty(transPrelevementDates)) {
            return getPremiereDateSansEcheancier(delaiTeletransmission);
        }

        // Si des prélèvements ont été effectués, on écrase la date début par la dernière date de prélèvement
        if (CollectionUtils.isNotEmpty(transPrelevementDates)) {
            return getPremiereDateSansEcheancier(delaiTeletransmission);
        }

        Date dernierPOWithPeriodicityDate = addMonthsToDate(transPrelevementDates.get(0), FrequenceVirementType
                .fromCodeFractionnement(echeancier.getCodeFractionnement()).getMonths());

        Date premiereDateVersementPossible = null;

        if (!isPourListeDates) {
            return addMonthsToDate(transPrelevementDates.get(0), FrequenceVirementType
                    .fromCodeFractionnement(echeancier.getCodeFractionnement()).getMonths());
        } else {
            return getPremiereDateSansEcheancier(delaiTeletransmission);
        }
    }

    private static Date getPremiereDateSansEcheancier(Integer delaiTeletransmission) {
        return addDaysToDate(new Date(), delaiTeletransmission);
    }

    public static Date addDaysToDate(Date date, int days) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DATE, days);
        return c.getTime();
    }

    public static Date addMonthsToDate(Date date, int months) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.MONTH, months);
        return c.getTime();
    }
}
