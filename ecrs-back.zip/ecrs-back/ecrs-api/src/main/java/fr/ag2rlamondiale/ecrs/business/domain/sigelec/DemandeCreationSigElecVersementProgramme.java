package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.trm.domain.sigelec.FormulaireActeEnLigneMapperLocator;
import lombok.Data;
import lombok.EqualsAndHashCode;

@FormulaireActeEnLigneMapperLocator(FormulaireVersementProgrammeMapper.class)
@EqualsAndHashCode(callSuper = true)
@Data
public class DemandeCreationSigElecVersementProgramme extends DemandeCreationSigElecVersement {
    private FrequenceVirementType frequenceVersement;
}
