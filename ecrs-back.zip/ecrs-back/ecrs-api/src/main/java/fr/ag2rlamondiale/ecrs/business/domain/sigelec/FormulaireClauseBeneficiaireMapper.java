package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireClauseBenef;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import javax.xml.bind.JAXBException;
import java.util.Map;

@Mapper(componentModel = "spring", uses = {DateMapper.class}, imports = {DateMapper.class, CodeApplicationType.class})
public abstract class FormulaireClauseBeneficiaireMapper implements IFormulaireMapper {
    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today())")

    @Mapping(target = "identificationContratDansSilo.identifiantDansSilo", source = "contrat.id")
    @Mapping(target = "identificationContratDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationContratDansSilo.codeApplication", expression = "java(CodeApplicationType.PTV_ERE.getCode())")
    @Mapping(target = "identificationContratDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationContratDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationContratDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationAffiliationDansSilo.identifiantDansSilo", source = "identifiantAssure")
    @Mapping(target = "identificationAffiliationDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationAffiliationDansSilo.codeApplication", expression = "java(CodeApplicationType.PTV_ERE.getCode())")
    @Mapping(target = "identificationAffiliationDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationAffiliationDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationAffiliationDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationUserDansSilo.identifiantDansSilo", source = "idGdi")
    @Mapping(target = "identificationUserDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationUserDansSilo.codeApplication", expression = "java(CodeApplicationType.ECRS.getCode())")
    @Mapping(target = "identificationUserDansSilo.libelleApplication", constant = FormulaireConstantes.ESPACE_CLIENT_PARTICULIER_ERE)
    @Mapping(target = "identificationUserDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationUserDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationPersonneDansSilo.identifiantDansSilo", source = "personPhysique.id")
    @Mapping(target = "identificationPersonneDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE_PTV2_3)
    @Mapping(target = "identificationPersonneDansSilo.codeApplication", expression = "java(fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE.egesper().getCode())")
    @Mapping(target = "identificationPersonneDansSilo.libelleApplication", constant = FormulaireConstantes.EGESPER_ERE)
    @Mapping(target = "identificationPersonneDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationPersonneDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationDemandeDansSilo.identifiantDansSilo", source = "idDemandeWkf")
    @Mapping(target = "identificationDemandeDansSilo.libelleNomSilo", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationDemandeDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationDemandeDansSilo.codeSystemeInformation", constant = FormulaireConstantes.ERE)
    @Mapping(target = "identificationDemandeDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "clauseContrat.codeTypeClauseBenef", source = "clauseBeneficiaire")
    @Mapping(target = "clauseContrat.descClauseBenef", source = "clauseBeneficiaireDescription")

    public abstract FormulaireClauseBenef createFormulaireClauseBeneficiaire(DemandeCreationSigElecClauseBeneficiaire demande);

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireClauseBenef formulaireClauseBenef = this.createFormulaireClauseBeneficiaire((DemandeCreationSigElecClauseBeneficiaire) demandeSigElec);
        if (formulaireClauseBenef.getIdentificationContratDansSilo() != null && formulaireClauseBenef.getIdentificationAffiliationDansSilo() != null) {
            formsMap.put(getCle(
                    formulaireClauseBenef.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    formulaireClauseBenef.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    formulaireClauseBenef.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormClauseBeneficiaire(formulaireClauseBenef));
        }
    }
}
