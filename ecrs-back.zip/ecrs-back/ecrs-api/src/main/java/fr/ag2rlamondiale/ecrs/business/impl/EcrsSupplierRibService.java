package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.MetierContratType;
import fr.ag2rlamondiale.trm.utils.Sets;
import fr.ag2rlamondiale.rib.business.ISupplierRibService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class EcrsSupplierRibService implements ISupplierRibService {
    @Autowired
    private IContratFacade contratFacade;

    @Override
    public MetierContratType getMetierContratPrincipale() {
        return MetierContratType.RETRAITE_SUPPLEMENTAIRE;
    }

    @Override
    public Set<MetierContratType> getMetiersContratSecondaires() {
        return Sets.set(MetierContratType.EPARGNE);
    }

    @Override
    public List<ContratHeader> recupererContrats(MetierContratType metierContrat) throws TechnicalException {
        return MetierContratType.EPARGNE.equals(metierContrat) ?
                contratFacade.rechercherContratsEpargnePrevoyance() :
                contratFacade.rechercherContratsComplets().stream()
                        .filter(contratComplet -> (!contratComplet.isPacte() && isContratNonPacteAffichable(contratComplet))
                                || isContratPacteAffichable(contratComplet)).map(BaseContratComplet::getContratHeader)
                        .collect(Collectors.toList());
    }

    private boolean isContratNonPacteAffichable(ContratComplet contratComplet) {
        return AffichageType.NORMAL.equals(contratComplet.getContratHeader().getAffichageType());
    }

    private boolean isContratPacteAffichable(ContratComplet contratComplet) {
        List<Compartiment> c1 =
                contratComplet.getContratHeader().compartiments(CompartimentType.C1);
        if (c1.size() > 1) {
            throw new IllegalArgumentException(contratComplet.getContratHeader().getId()
                    + " est un contrat pacte et a plusieurs C1");
        }
        if (!c1.isEmpty() && c1.get(0).getAffichageType().isSelectable()) {
            return true;
        }
        List<Compartiment> c4 =
                contratComplet.getContratHeader().compartiments(CompartimentType.C4);
        if (c4.size() > 1) {
            throw new IllegalArgumentException(contratComplet.getContratHeader().getId()
                    + " est un contrat pacte et a plusieurs C4");
        }
        if (!c4.isEmpty()) {
            return c4.get(0).getAffichageType().isSelectable();
        }
        return false;
    }


}
