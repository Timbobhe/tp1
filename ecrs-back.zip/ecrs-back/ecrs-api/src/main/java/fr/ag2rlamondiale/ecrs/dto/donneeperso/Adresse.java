package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Adresse {
    private String etageAppt;
    private String batiment;
    private String numVoie;
    private String lieuDit;
    private String codePostal;
    private String ville;
    private String pays;
    private String paysResidenceFiscale;
}
