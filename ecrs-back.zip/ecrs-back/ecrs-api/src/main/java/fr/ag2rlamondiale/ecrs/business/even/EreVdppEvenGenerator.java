package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.business.even.EvenUtils.*;

@Component
@Slf4j
public class EreVdppEvenGenerator extends AbstractEvenWithoutContratGenerator {
    @Autowired
    private IWorkflowFacade workflowFacade;

    @Setter
    @Value("${ere.evt.vdpp.delai.declenchement}")
    // FIXME Utiliser TypeEvenementJson#delaiAvantReactivation au lieu de la CONF
    private Integer delaiDeclenchement;

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {

        if (!isEre()) {
            return;
        }

        if (!isPersonneAutorisee(idGdi, numPersonne, typeEven.getPerimetreEvenements())) {
            return;
        }

        List<EvenementJson> evenementsForType = getEvenementsForType(typeEven, historiqueEvens);

        if (respecteDelaiReactivation(typeEven, evenementsForType)) {

            List<EvenementJson> evenementsVDPPDejaEnregistres = getEvenementsForType(typeEven, historiqueEvens).stream()
                    .filter(evenementJson -> EtatTraitementType.TRAI.equals(evenementJson.getEtatTraitement()))
                    .collect(Collectors.toList());

            if (evenementDeclencheDepuis(evenementsVDPPDejaEnregistres, delaiDeclenchement)) {
                results.add(this, idGdi, numPersonne, typeEven);
            }
        }

    }

    public boolean evaluerEvenement(String idPersonne) {
        try {
            return !workflowFacade.hasDemandeMdpEncours(idPersonne);
        } catch (Exception e) {
            log.error("Erreur pendant l'evaluation de l'evenement VDPP", e);
            return false;
        }
    }

}
