package fr.ag2rlamondiale.ecrs.config;

import fr.ag2rlamondiale.trm.supervision.BaseTestManager;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Profile;

@Profile(BaseTestManager.PROFILE_TESTMANAGER)
@Configuration
@ImportResource("classpath:data-fixtures.xml")
public class TestManagerConfig {
}
