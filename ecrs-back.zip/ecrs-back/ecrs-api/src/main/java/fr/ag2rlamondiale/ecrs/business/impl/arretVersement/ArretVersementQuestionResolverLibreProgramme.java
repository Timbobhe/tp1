package fr.ag2rlamondiale.ecrs.business.impl.arretVersement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.impl.versement.DictionnaireVersementJahia;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementContexteDto;
import fr.ag2rlamondiale.ecrs.dto.versement.*;
import fr.ag2rlamondiale.ecrs.utils.VersementUtils;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME;

@Service
public class ArretVersementQuestionResolverLibreProgramme implements ArretVersementQuestionResolver {

    @Autowired
    private IEcheancierFacade echeancierFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Setter
    @Value("${ere.delai.teletransmission.versement:15}")
    private Integer delaiTeletransmission;

    @Override
    public QuestionResponsesDto<ModeVersementDto, ?> resolve(QuestionType questionType, ArretVersementContexteDto contexte) throws TechnicalException {
        final boolean pacte = contratFacade.rechercherContratParId(contexte.getContratSelectionne()).isPacte();
        final QuestionResponsesDto<ModeVersementDto, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.VERSEMENT_CHOIX_MODE_TYPE)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_QUESTION_MODE_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_MODE_MESSAGE_SOUHAIT.name())
                .build());

        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
        result.setDefaultValue(reponseProgramme(contexte, blocagesClient, pacte));
        result.setShow(false);
        return result;
    }

    private boolean isFonctionnaliteBloque(ContratId contratId, FonctionnaliteType fct, InfosBlocagesClient blocagesClient) {
        return blocagesClient.isFonctionnaliteBloqueePourContrat(contratId.getNomContrat(), fct);
    }

    public ResponseDto<ModeVersementDto> reponseProgramme(ArretVersementContexteDto contexte, InfosBlocagesClient blocagesClient, boolean pacte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        final Compartiment compartiment = contratHeader.compartiment(contexte.getCompartimentSelectionne());

        final boolean sigElecOff = isFonctionnaliteBloque(contexte.getContratSelectionne(), FonctionnaliteType.SIGELEC_VERSEMENT_PROGRAMME, blocagesClient);

        DetailsVersementEREType detailVersement = DetailsVersementEREType.getDetailFromContratAndType(contexte.getContratSelectionne().getNomContrat(), TypeVersement.PO, pacte);
        ModeVersementDto modeVersementDto = ModeVersementDto.builder()
                .minMontantPossible(detailVersement.getMinMontantPossible())
                .maxMontantPossible(detailVersement.getMaxMontantPossible())
                .modeType(VERSEMENT_PROGRAMME)
                .sigElecOff(sigElecOff)
                .versementProgramme(getVersementProgramme(compartiment))
                .build();
        return ResponseDto.<ModeVersementDto>builder()
                .id(VERSEMENT_PROGRAMME.name())
                .value(modeVersementDto)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_PROGRAMME.name())
                .build();
    }

    @Override
    public boolean accept(QuestionType questionType, ArretVersementContexteDto contexte) {
        return QuestionType.VERSEMENT_CHOIX_MODE_TYPE.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getCompartimentSelectionne() != null;
    }

    public VersementProgrammeDto getVersementProgramme(Compartiment compartiment) throws TechnicalException {
        Echeancier echeancier = echeancierFacade.getProchainEcheancier(compartiment);
        if (echeancier != null && (echeancier.getDateFin() == null || echeancier.getDateFin().after(new Date()))) {
            return VersementProgrammeDto.builder()
                    .montantActuel(echeancier.getMontant().intValue())
                    .minDateDebutPrelevement(VersementUtils.addDaysToDate(new Date(), delaiTeletransmission))
                    .frequence(FrequenceVirementType.forEcheancier(echeancier))
                    .datePremierVersement(VersementUtils.getPremiereDateVersementPossible(echeancier, delaiTeletransmission))
                    .build();
        }
        return null;
    }
}
