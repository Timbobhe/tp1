package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageEurosPourcentageType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_REPARTIR;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_REPARTITION_EN_EUROS;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_REPARTITION_EN_POURCENTAGE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_EUROS;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL;

@Service
public class ArbitrageQuestionResolverEurosPourcentMDP implements ArbitrageQuestionResolver {


    @Override
    public QuestionResponsesDto<ResponseArbitrageEurosPourcentageType, ?> resolve(QuestionType questionType, ArbitrageContexteDto contexte) {
        final QuestionResponsesDto<ResponseArbitrageEurosPourcentageType, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT)
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_REPARTIR.name())
                .build());

        if (contexte.getResponseFluxStockType().isFlux()
                || contexte.getResponseTotalPartielType().equals(ARBITRAGE_TOTAL)) {
            result.setShow(false);
            result.setDefaultValue(reponsePourcentage());
            contexte.update(ctx -> ctx.setResponseEurosPourcentageType(ARBITRAGE_POURCENTAGE));

            return result;
        }

        result.add(reponseEuros());
        result.add(reponsePourcentage());
        return result;
    }

    public ResponseDto<ResponseArbitrageEurosPourcentageType> reponseEuros() {
        return ResponseDto.<ResponseArbitrageEurosPourcentageType>builder()
                .value(ARBITRAGE_EUROS)
                .jahiaDicoEntry(ARB_REPARTITION_EN_EUROS.name())
                .build();
    }

    public ResponseDto<ResponseArbitrageEurosPourcentageType> reponsePourcentage() {
        return ResponseDto.<ResponseArbitrageEurosPourcentageType>builder()
                .value(ARBITRAGE_POURCENTAGE)
                .jahiaDicoEntry(ARB_REPARTITION_EN_POURCENTAGE.name())
                .build();
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getContratSelectionne().is(CodeSiloType.MDP);
    }
}
