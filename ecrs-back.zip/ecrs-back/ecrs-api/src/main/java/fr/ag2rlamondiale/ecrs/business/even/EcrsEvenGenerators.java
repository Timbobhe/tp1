package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class EcrsEvenGenerators implements IEvenGenerators, InitializingBean {

    @Autowired
    private EreConfEvenGenerator ereConfEvenGenerator;

    @Autowired
    private ErePND3EvenGenerator erePND3EvenGenerator;

    @Autowired
    private ErePND1EvenGenerator erePND1EvenGenerator;

    @Autowired
    private EreVdppEvenGenerator ereVdppEvenGenerator;

    @Autowired
    private CguEvenGenerator cguEvenGenerator;

    @Autowired
    private EreMsgIndispoEvenGenerator ereMsgIndispoEvenGenerator;

    @Autowired
    private MdpMsgIndispoEvenGenerator mdpMsgIndispoEvenGenerator;

    @Autowired
    private OnboardingEvenGenerator onboardingEvenGenerator;

    private Map<String, AbstractEvenGenerator> generatorMap = new HashMap<>();

    @Override
    public AbstractEvenGenerator getEvenGenerator(String codeTypeEvenement) {
        final AbstractEvenGenerator generator = generatorMap.get(codeTypeEvenement);
        if (generator == null && log.isDebugEnabled()) {
            log.debug("Le Type evenement {} n'est pas g\u00e9r\u00e9 applicativement", codeTypeEvenement);
        }

        return generator;
    }

    @Override
    public EvenementJson generateNextEven(List<TypeEvenementJson> typesEven, String idGdi, String numPersonne,
                                          Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens) {

        TriggeringResults triggeringResults = new TriggeringResults();

        // 1. On recherche les even d&eacute;clenchable
        for (TypeEvenementJson typeEven : typesEven) {
            final String codeEvenement = typeEven.getCodeEvenement();
            final AbstractEvenGenerator generator = getEvenGenerator(codeEvenement);
            if (generator != null) {
                generator.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, triggeringResults);
            }
        }

        // 2. On prepare le d&eacute;clenchement
        triggeringResults.forEachGenerator(generator -> generator.prepare(idGdi, numPersonne, contrats));

        // 3. On g&eacute;n&eacute;re les EVEN
        for (TriggeringResult result : triggeringResults) {
            final EvenementJson even = result.getGenerator().generateNextEven(result);
            if (even != null) {
                return even;
            }
        }

        return null;
    }

    @Override
    public void afterPropertiesSet() {
        generatorMap.put(TypeEven.CGU.getCode(), cguEvenGenerator);
        generatorMap.put(TypeEven.PND3.getCode(), erePND3EvenGenerator);
        generatorMap.put(TypeEven.PND1.getCode(), erePND1EvenGenerator);
        generatorMap.put(TypeEven.CONFIRMATION_DONNEES_PERSO.getCode(), ereConfEvenGenerator);
        generatorMap.put(TypeEven.VALIDATION_PERIODIQUE_DONNEES_PERSO.getCode(), ereVdppEvenGenerator);
        generatorMap.put(TypeEven.INDISPO_ERE.getCode(), ereMsgIndispoEvenGenerator);
        generatorMap.put(TypeEven.INDISPO_MDP.getCode(), mdpMsgIndispoEvenGenerator);
        generatorMap.put(TypeEven.ONBOARDING.getCode(), onboardingEvenGenerator);
    }
}
