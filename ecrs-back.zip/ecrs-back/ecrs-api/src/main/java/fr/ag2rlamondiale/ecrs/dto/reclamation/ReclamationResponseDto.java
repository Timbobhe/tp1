package fr.ag2rlamondiale.ecrs.dto.reclamation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReclamationResponseDto implements Serializable {
	private static final long serialVersionUID = -8695535421487668456L;
	private State state;
	private String errorTag;
}
