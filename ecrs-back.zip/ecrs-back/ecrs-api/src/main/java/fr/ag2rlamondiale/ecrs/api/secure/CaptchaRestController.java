package fr.ag2rlamondiale.ecrs.api.secure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.business.ICaptchaFacade;
import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseDto;

@RestController
@RequestMapping(path = "/secure")
public class CaptchaRestController {

	@Autowired
	private ICaptchaFacade captchaFacade;

	@LogExecutionTime
	@PostMapping(path = "/verifyCaptcha")
	public ResponseEntity<VerificationCaptchaResponseDto> verifyRequest(@RequestBody String token) {
		final VerificationCaptchaResponseDto res = captchaFacade.verifyToken(token);
		return ResponseEntity.ok(res);
	}
}
