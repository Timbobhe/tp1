package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.function.Predicate;

public interface IEvenementFacade {

    EvenementJson generateNextEvenement(
            Predicate<TypeEvenementJson> typeEvenPredicate, boolean avecImpersonation, boolean insertEvenGene) throws TechnicalException;

    EvenementJson saveEvenementUtilisateurTraite(TypeEven typeEven) throws TechnicalException;

    EvenementJson updateEvenement(EvenementJson evtJson);

    EvenementJson insertEvenement(EvenementJson evtJson);
}
