package fr.ag2rlamondiale.ecrs.dto.verificationCaptcha;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VerificationCaptchaResponseDto {
	private int status;
	private String message;
}
