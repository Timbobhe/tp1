package fr.ag2rlamondiale.ecrs.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.PropertySource;

@Profile("local")
@Configuration
@PropertySource({"classpath:webservices-pfs.properties", "classpath:webservices-rest.properties"})
public class LocalPropertyConfig {
	
}
