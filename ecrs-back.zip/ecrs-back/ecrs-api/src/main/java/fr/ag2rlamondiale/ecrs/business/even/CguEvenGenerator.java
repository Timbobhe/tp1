package fr.ag2rlamondiale.ecrs.business.even;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICguFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.IConsulterIdentiteClient;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import fr.ag2rlamondiale.trm.security.UserContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * Classe permettant de déterminer si l'assuré d'un partenaire a déjà accepter les CGUs ou non.<br>
 * Uniquement depuis NIE.
 */
@Slf4j
@Component
public class CguEvenGenerator extends AbstractEvenWithoutContratGenerator {

    @Autowired
    private ICguFacade cguFacade;

    @Autowired
    private IConsulterIdentiteClient consulterIdentiteClient;

    @Override
    protected boolean evaluerEvenement(String numPersonne) {
        try {
            return userContextHolder.get().isPartenaireNIE() && !hasAcceptedCgu();
        } catch (Exception e) {
            log.error("Acceptation des CGU non \u00e9valu\u00e9e : ", e);
        }
        return false;
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                  Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (!userContextHolder.get().isPartenaireNIE()) {
            return;
        }
        super.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, results);
    }

    private boolean hasAcceptedCgu() throws TechnicalException {
        UserContext user = userContextHolder.get();
        Integer idCxp = user.getTemporaryId();
        final CguDetails details = cguFacade.getCguDetails();
        Objects.requireNonNull(details, "CGU est NULL");
        return user.isHasIdGdi() && cguFacade.getAcceptedGguIds(user.getIdGdi()).contains(details.getIdCgu())
                || cguFacade.getAcceptedGguIds(idCxp).contains(details.getIdCgu());
    }

    @Override
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {
        super.prepare(idGdi, numPersonne, contrats);
        if (idGdi != null) {
            consulterIdentiteClient.cacheEvictConsulterIdentite(idGdi);
        }
    }
}
