package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@Data
public class RequestQuestionArretVersementDto implements ISecurityParamAccess {
    private QuestionType questionType;
    private ArretVersementContexteDto contexte;

    /**
     * Liste contenant toutes les questions dans l'ordre
     */
    private List<QuestionType> questionTypeList;

    @Override
    public String secureForNumContrat() {
        return contexte != null ? contexte.secureForNumContrat() : null;
    }

    @Override
    public String secureForIdentifiantAssure() {
        return contexte != null ? contexte.secureForIdentifiantAssure() : null;
    }
}
