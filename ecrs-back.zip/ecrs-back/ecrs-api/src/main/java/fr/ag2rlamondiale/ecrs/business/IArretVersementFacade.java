package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.RequestQuestionArretVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementProgrammeDto;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface IArretVersementFacade {
    ArretVersementStartDto startArretVersement() throws TechnicalException;

    VersementProgrammeDto getVersementProgramme(Compartiment compartiment) throws TechnicalException;

    <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionArretVersementDto request) throws TechnicalException;

    ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionArretVersementDto request) throws TechnicalException;

    String terminate(ArretVersementTerminateDto arretVersementTerminateDto, boolean isFrame) throws TechnicalException, IOException, JAXBException;
}
