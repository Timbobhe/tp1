package fr.ag2rlamondiale.ecrs.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ResponseDto<T> {
    private String id;
    private String label;
    private String jahiaDicoEntry;
    private T value;
    private MessageDto warningMessage;
    private boolean disabled = false;
    private boolean preSelected = false;
}
