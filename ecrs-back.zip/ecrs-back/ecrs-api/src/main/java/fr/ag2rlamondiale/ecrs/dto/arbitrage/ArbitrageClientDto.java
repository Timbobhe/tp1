package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class ArbitrageClientDto implements ISecurityParamAccess {

    private int ordre;
    private ContratParcoursDto contrat;
    private List<CompartimentId> compartimentIds;
    private BigDecimal montantEncours;
    private RepartionActuelleDto repartitionActuelle;
    private DesinvestissementDto desinvestissement;
    private NouvelleRepartitionDto nouvelleRepartition;
    private QuestionType.ResponseArbitrageEurosPourcentageType unite;
    private ResponseDto<ResponseArbitrageFluxStockType> typeArbitrage;

    private BigDecimal montantARepartir;
    private boolean impossible;

    @Override
    public void secureAppendIdentifiantsAssure(Set<String> appender) {
        if (compartimentIds != null) {
            compartimentIds.stream()
                    .map(CompartimentId::getIdAssure)
                    .filter(Objects::nonNull)
                    .forEach(appender::add);
        }
    }
}
