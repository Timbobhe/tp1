package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class ArretVersementClientDto {
    private ContratParcoursDto contrat;
    private CompartimentId compartimentId;
    private BigDecimal montantVersement;
    private FrequenceVirementType periodiciteVersement;
    private Date dateVersement;
    private Date dateFinVersement;
    private QuestionType.ResponseVersementDeductibiliteType deductibilite;
    private QuestionType.ResponseVersementModeType modeVersement;
}
