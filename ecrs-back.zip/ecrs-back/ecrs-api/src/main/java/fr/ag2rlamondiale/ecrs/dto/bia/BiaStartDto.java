package fr.ag2rlamondiale.ecrs.dto.bia;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BiaStartDto {
    private List<InfoBiaContratDto> bias;
    private boolean biaEnCours;
    private BiaContexte biaContexte;
    private boolean sigElecOff;
}
