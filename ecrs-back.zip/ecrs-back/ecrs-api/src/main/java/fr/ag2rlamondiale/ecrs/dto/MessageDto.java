package fr.ag2rlamondiale.ecrs.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class MessageDto {
    private String label;
    private String jahiaDicoEntry;
    private String jahiaContribId;
    private Map<String, String> jahiaContext = new HashMap<>();
}
