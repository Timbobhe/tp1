package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import lombok.Data;

@Data
public class ChoixArbitrage<T> {

    private T keyChoice;

    private String labelChoice;
}
