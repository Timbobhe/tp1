package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.*;

public class ArbitrageMdproHelper {
    private static final String ID_GRILLE_HORIZON_PRUDENT = "65";
    private static final String ID_GRILLE_100POURCENT_ACTIFGENERAL_PEP = "11";
    private static final String ID_GRILLE_GESTION_PILOTEE_PEP = "12";
    private static final String ID_GRILLE_TERME_PEP = "91";

    private ArbitrageMdproHelper() {
    }

    public static QuestionType.ResponseArbitrageFluxStockType getTypeArbitragePourFiscalitePEP(String idGrilleSource) {
        if (ID_GRILLE_100POURCENT_ACTIFGENERAL_PEP.equals(idGrilleSource) || ID_GRILLE_TERME_PEP.equals(idGrilleSource)) {
            return ARBITRAGE_FLUX;
        } else if (ID_GRILLE_GESTION_PILOTEE_PEP.equals(idGrilleSource)) {
            return ARBITRAGE_FLUXSTOCK;
        }
        return null;
    }

    // A supprimer quand incorporé dans le Front
//    public static boolean isFormulaireDeDechargeAAfficher(boolean isFiscalitePERP, ModeGestionMdproType modeGestionCible) {
//        boolean aPourGestionCibleLaGestionDynamisation =
//                ModeGestionMdproType.DYNAMISATION == modeGestionCible;
//        boolean aPourGestionCibleLaGestionLibre =
//                ModeGestionMdproType.LIBRE == modeGestionCible;
//        return isFiscalitePERP && (aPourGestionCibleLaGestionDynamisation || aPourGestionCibleLaGestionLibre);
//    }
//
//    public static boolean isPerteDuPrincipeDeGestionPilotee(ModeGestionMdproType modeGestionSource, ModeGestionMdproType modeGestionCible, QuestionType.ResponseArbitrageFluxStockType arbitrageFluxStock) {
//        boolean aPourGestionSourceUneGestionPilotee =
//                ModeGestionMdproType.LIBRE != modeGestionSource;
//        boolean aPourGestionCibleLaGestionLibre =
//                ModeGestionMdproType.LIBRE == modeGestionCible;
//        boolean estunArbitrageDeFluxUniquement =
//                QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX == arbitrageFluxStock;
//        return estunArbitrageDeFluxUniquement && aPourGestionSourceUneGestionPilotee
//                && aPourGestionCibleLaGestionLibre;
//    }

    /**
     * @param modeGestionSource      (Libre, Pilotee, Horizon, Dynamisation)
     * @param reponseModeGestion (Libre, Pilotee, Horizon, Dynamisation)
     * @return ResponseArbitrageFluxStockType correspondant à Stock, Flux ou Mixte
     */
    public static List<QuestionType.ResponseArbitrageFluxStockType> getTypesArbitragePossiblesFiscaliteHorsPEP(
            ModeGestionMdproType modeGestionSource, String idGrilleSource, ModeGestionMdproType reponseModeGestion) {
        if (ModeGestionMdproType.LIBRE != reponseModeGestion || ModeGestionMdproType.TERME == modeGestionSource) {
            // Pour tout autre gestion cible que la gestion libre, on impose un arbitrage mixte
            // Pour un arbitrage à partir d'une gestion terme, on impose un arbitrage mixte
            return Collections.singletonList(ARBITRAGE_FLUXSTOCK);
        } else {
            return getTypesArbitragePossiblesPourCibleEnGestionLibre(modeGestionSource, idGrilleSource);
        }
    }

    private static List<QuestionType.ResponseArbitrageFluxStockType> getTypesArbitragePossiblesPourCibleEnGestionLibre(
            ModeGestionMdproType modeGestionSource, String idGrilleSource) {
        switch (modeGestionSource) {
            case LIBRE:
                return Arrays.asList(
                        ARBITRAGE_FLUXSTOCK,
                        ARBITRAGE_STOCK,
                        ARBITRAGE_FLUX);
            case PILOTEE:
                return Arrays.asList(
                        ARBITRAGE_FLUXSTOCK,
                        ARBITRAGE_FLUX);
            case HORIZON:
                return getTypesArbitragePossiblesPourGestionHorizonVersLibre(idGrilleSource);
            case DYNAMISATION:
            default:
                // Forcage mixte
                return Collections.singletonList(ARBITRAGE_FLUXSTOCK);
        }
    }

    private static List<QuestionType.ResponseArbitrageFluxStockType> getTypesArbitragePossiblesPourGestionHorizonVersLibre(String idGrilleSource) {
        if (ID_GRILLE_HORIZON_PRUDENT.equals(idGrilleSource)) { // Cas particulier de la Gestion Horizon Prudent
            return Collections.singletonList(ARBITRAGE_FLUXSTOCK); // Forcage mixte
        } else {
            return Arrays.asList(ARBITRAGE_FLUXSTOCK, ARBITRAGE_FLUX);
        }
    }
}
