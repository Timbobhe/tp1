package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaStartDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaTerminateDto;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;

import java.io.IOException;

import javax.xml.bind.JAXBException;

public interface IBiaFacade {
    BiaStartDto startBia() throws TechnicalException;

    ResultParcoursEffectueDto testBiaEffectue(ContratHeader contrat) throws TechnicalException;

    boolean isBiaEffectue(ContratHeader contratHeader) throws TechnicalException;

    String terminateBia(BiaTerminateDto biaTerminateDto, boolean isFrame)
            throws IOException, CommonException, JAXBException;
}
