package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArretVersementFacade;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.InfoArretVersementContrat;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT;

@Component
public class ArretVersementAccessibilitySupplier implements IFunctionalityAccessibilitySupplier {

    @Autowired
    IArretVersementFacade arretVersementFacade;

    @Override
    public boolean accept(FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.ARRET_VERSEMENT_PROGRAMME.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto check() throws TechnicalException {
        AccesFonctionnaliteDto accesFonctionnalite = new AccesFonctionnaliteDto(FonctionnaliteType.ARRET_VERSEMENT_PROGRAMME);
        ArretVersementStartDto arretVersementStartDto = arretVersementFacade.startArretVersement();
        boolean isAccessible = arretVersementStartDto != null && !arretVersementStartDto.getInfos().isEmpty();

        if (!isAccessible) {
            accesFonctionnalite.setAccessible(false);
            accesFonctionnalite.setRaison(ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name());
        } else {
            List<InfoArretVersementContrat> contratsBloques = arretVersementStartDto.getInfos().stream()
                    .filter(InfoArretVersementContrat::isBloque)
                    .collect(Collectors.toList());
            if (contratsBloques != null) {
                isAccessible = contratsBloques.size() < arretVersementStartDto.getInfos().size();

                if (!isAccessible) {
                    accesFonctionnalite.setRaison(contratsBloques.get(0).getRaisonBlocage().getJahiaDicoEntry());
                }
            }

        }
        accesFonctionnalite.setAccessible(isAccessible);
        return accesFonctionnalite;
    }

}
