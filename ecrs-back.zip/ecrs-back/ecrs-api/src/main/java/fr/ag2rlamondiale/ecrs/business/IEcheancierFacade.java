package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;

import java.util.List;

public interface IEcheancierFacade {

    List<Echeancier> rechercherEcheanciers(Compartiment compartiment) throws TechnicalException;

    Echeancier consulterEcheancier(Compartiment compartiment, String idEcheancier) throws TechnicalException;

    Echeancier getProchainEcheancier(Compartiment compartiment) throws TechnicalException;
}
