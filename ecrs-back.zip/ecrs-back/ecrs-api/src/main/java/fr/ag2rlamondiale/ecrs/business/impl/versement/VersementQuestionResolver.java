package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;

public interface VersementQuestionResolver {

    /**
     *
     * @param questionType
     * @param contexte Le Contexte est mis &agrave; jour par le Resolver
     * @param <R>
     * @param <Q>
     * @return
     * @throws TechnicalException
     */
    <R, Q> QuestionResponsesDto<R, Q> resolve(QuestionType questionType, VersementContexteDto contexte) throws TechnicalException;

    boolean accept(QuestionType questionType, VersementContexteDto contexte);
}
