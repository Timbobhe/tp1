package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.simulateur.dto.Context;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationMDPType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum.*;

@Service
public class SimulateurFiscalCalculPerp extends BaseSimulateurFiscalCalcul implements ISimulateurFiscalCalcul {

    private static final List<CodeTypeOperationMDPType> CODES_TYPE_OPERATION_COTISATIONS_VERSEMENTS_PERP = Arrays
            .asList(CodeTypeOperationMDPType.AP, CodeTypeOperationMDPType.NL, CodeTypeOperationMDPType.VL);

    private static final List<CodeTypeOperationMDPType> CODES_TYPE_OPERATIONS_VERSEMENTS_PERP = Arrays
            .asList(CodeTypeOperationMDPType.NL, CodeTypeOperationMDPType.VL);

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private CalculDisponibleCommand calculDispoFiscalCommand;

    @Autowired
    private CalculVersementsComplementairesCommand calculVersComplCommand;

    @Autowired
    private CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Autowired
    private CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Autowired
    private CalculEconomieFiscaleCommand calculGainFiscalCommand;


    @Override
    public ResultatCalculEpargne calculerDisponibleFiscal(DemandeCalculEpargne demande) throws TechnicalException {
        ContratId contratId = demande.getContrat();
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratId);

        // précision pour le param Annee ( on fait la simulation pour savoir le gain
        // fiscal de l'année n+1 )
        demande.setYear(Annee.Courante.getYear());
        final Context<EconomieFiscaleContextKeyEnum, Object> context = initContextSimulateurFiscal(demande);

        ContratHeader contratHeader = contratComplet.getContratHeader();

        // on recupere les cotisations de l'année n-1
        final Annee.BorneAnnee anneeCotisations = Annee.Precedente.borneAnnee();


        final BigDecimal totalCotisationsEtVersements = calculMontantCotisationsPERP(contratHeader, anneeCotisations.toFirstDate(), anneeCotisations.toLastDate());

        context.put(COTISATIONS_BRUTES, totalCotisationsEtVersements);
        context.put(COTB_CET_NDED, BigDecimal.ZERO);


        // Appel Moteur Calcul <=> Disponible PERP BRUT
        final BigDecimal plafondVIF = calculDispoFiscalCommand.calculerPlafondVersement(context);
        context.put(EconomieFiscaleContextKeyEnum.PLAFOND_VERSEMENT, plafondVIF);

        // represente le B dans le doc de simulateur
        final BigDecimal cotisationsDeductibles = calculDispoFiscalCommand
                .calculerMontantCotisationsDeductiblesAvecAbondement(context);

        // VPVL_ANF => les VIFS déjà effectués dans Année N
        // définir les dates bornes de Calcul
        final Annee.BorneAnnee anneeCalcul = Annee.fromYear(demande.getYear())
                                                  .borneAnnee();

        // US 16687
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();

        final BigDecimal mntTotalAnnCotisPeriodiques = contratGeneral.getMontantAnneePrimeTTC();

        BigDecimal vifBrutsAnneeFiscale = calculMontantVersementsPERP(contratHeader, anneeCalcul.toFirstDate(), DateUtils.getTodayTimelessDate());


        context.put(EconomieFiscaleContextKeyEnum.VPVL_ANF, vifBrutsAnneeFiscale.add(mntTotalAnnCotisPeriodiques));
        calculVersComplCommand.calculVersementLibreSaisiComplEtVersemetsProgrammesEcheancier(context);

        final BigDecimal plafondSecuSociale = context.getBigDecimal(PASS);
        final BigDecimal aVariable = plafondSecuSociale.multiply(new BigDecimal("0.1"));

        final BigDecimal disponibleFiscalGlobal = BigDecimal.ZERO.max(aVariable.subtract(cotisationsDeductibles))
                                                                 .max(plafondVIF.subtract(vifBrutsAnneeFiscale));

        context.put(DISPONIBLE_FISCAL_GLOBAL, disponibleFiscalGlobal);

        // US 15692 => somme des versements qui imputent la jauge
        final BigDecimal montantDejaVerse = context.getBigDecimal(VPVL_ANF)
                                                   .add(context.getBigDecimal(SOMME_COTISATIONS_AVEC_ABONDEMENT));
        
        context.put(TOTAL_DEJA_VERSE, montantDejaVerse);

        final BigDecimal resteAsaisir = BigDecimal.ZERO.max(plafondVIF.subtract(montantDejaVerse));
        context.put(VLB_COMP, resteAsaisir);

        // Calcul du montant déductible
        calculMontantDeductibleCommand.execute(context);

        // Calcul GainFiscal Annee n+1
        calculGainFiscalCommand.execute(context);

        // effort Epargne reel
        calculEffortEpargneReelCommand.execute(context);

        return buildResultatCalculEpargnefromContext(context);
    }

    private BigDecimal calculMontantVersementsPERP(ContratHeader contratHeader, Date dateDebut, Date dateFin) {
        List<Operation> operationsCotisationsBrutesCET = operationFacade
                .getOperationsCotisationsEtVersementsSimulateurs(contratHeader, dateDebut, dateFin, CODES_TYPE_OPERATIONS_VERSEMENTS_PERP);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutesCET, CodeSiloType.MDP);
    }

    private BigDecimal calculMontantCotisationsPERP(ContratHeader contratHeader, Date dateDebut, Date dateFin) {
        List<Operation> operationsCotisationsBrutesCET = operationFacade.getOperationsCotisationsEtVersementsSimulateurs(
                contratHeader, dateDebut, dateFin, CODES_TYPE_OPERATION_COTISATIONS_VERSEMENTS_PERP);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutesCET, CodeSiloType.MDP);
    }
}
