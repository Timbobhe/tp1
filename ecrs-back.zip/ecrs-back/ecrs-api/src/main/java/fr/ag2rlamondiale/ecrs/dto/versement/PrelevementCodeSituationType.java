package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum PrelevementCodeSituationType {
    TRANS("TRANS"),
    ATRANS("ATRANS"),
    INVAL("INVAL"),
    ATRAIT("ATRAIT"),
    IMPAYE("IMPAYE"),
    ANNULE("ANNULE");

    private String code;
}
