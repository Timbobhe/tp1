package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModificationsIdentiteInfo {
    private String codeCivilite;
    private String civilite;
    private String nom;
    private String nomNaissance;
    private String prenom;
    private String dateDeNaissance;
    private String lieuNaissance;
}
