package fr.ag2rlamondiale.ecrs.dto.versement;

import java.util.List;

import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModeVersementDto {
    private int minMontantPossible;
    private int maxMontantPossible;
    private VersementProgrammeDto versementProgramme;
    private QuestionType.ResponseVersementModeType modeType;
    private boolean sigElecOff;
    private int montantMinODF;
    private boolean afficherODF;
    private List<RegleDeclenchementPieceJointe> regleDeclenchementPJ;
    
}
