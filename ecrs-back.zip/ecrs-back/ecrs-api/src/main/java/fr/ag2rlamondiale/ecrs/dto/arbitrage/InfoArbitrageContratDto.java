package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class InfoArbitrageContratDto extends BasicInfoParcoursDto {
    private ContratParcoursDto contrat;
    private QuestionResponsesDto<ChoixCompartimentDto, ?> choixCompartimentERE;
    private boolean bloque;
    private MessageDto raisonBlocage;
    private QadStatusType qadStatus;
    private GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdp;
    private int nbArbitrageAnnee;
}
