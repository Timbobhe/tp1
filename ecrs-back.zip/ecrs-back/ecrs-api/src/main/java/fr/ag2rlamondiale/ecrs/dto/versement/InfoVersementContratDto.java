package fr.ag2rlamondiale.ecrs.dto.versement;

import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.HashMap;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class InfoVersementContratDto extends BasicInfoParcoursDto {
    private ContratParcoursDto contrat;
    private QuestionResponsesDto<ChoixCompartimentDto, ?> choixCompartiment;
    private boolean bloque;
    private MessageDto raisonBlocage;
    private GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdp;
    private String idJahiaNumeroContact;
    private String fiscalite;
    private String codeFiliale;
}
