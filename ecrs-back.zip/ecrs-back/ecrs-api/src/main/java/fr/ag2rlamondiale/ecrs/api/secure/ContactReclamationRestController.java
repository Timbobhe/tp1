package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContactReclamationFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ReclamationResponseDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import fr.ag2rlamondiale.trm.business.IUploadFileFacade;
import fr.ag2rlamondiale.trm.domain.upload.OptionValidationPJ;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_CONTACT_RECLA_CREATE;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_CONTACT_RECLA_START;
import static fr.ag2rlamondiale.ecrs.dto.reclamation.State.KO;

@RestController
@RequestMapping(path = "/secure")
public class ContactReclamationRestController {

    @Autowired
    private IContactReclamationFacade contactReclamationFacade;

    @Autowired
    private IUploadFileFacade uploadFileFacade;

    @ProfileExecution(codeAction = API_CONTACT_RECLA_CREATE)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/contact")
    public ResponseEntity<ReclamationResponseDto> createReclamation(
            @RequestBody
            @SecuredParam(paramType = SecurityParamType.CONTRAT) ContactReclamationDto dto) throws TechnicalException {

        final ResponseEntity<ReclamationResponseDto> ko = uploadFileFacade.validPiecesJointes(dto.getFichiersJoint(),
                OptionValidationPJ.builder().obligatoire(false).maxFiles(dto.getCodeSilo() == CodeSiloType.ERE ? 0 : 5).build(),
                erreur -> ResponseEntity.ok(new ReclamationResponseDto(KO, erreur)));
        if (ko != null) {
            return ko;
        }

        ReclamationResponseDto res = contactReclamationFacade.createDemande(dto);
        return ResponseEntity.ok(res);
    }

    @ProfileExecution(codeAction = API_CONTACT_RECLA_START)
    @LogExecutionTime
    @GetMapping(path = "/contact-reclamation/start")
    public List<ContratParcoursDto> start() throws TechnicalException {
        return contactReclamationFacade.start();
    }
}
