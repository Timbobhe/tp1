package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import lombok.Data;

import java.util.List;

@Data
public class Justificatif {
    private List<UploadFileDto> pieceDidendite; //3 choix possibles:=> recto, verso cni / passport / recto, verso titreSejour */
    private String type;
}
