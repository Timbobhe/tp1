package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ITrackingFacade;
import fr.ag2rlamondiale.ecrs.dto.tracking.TrackingInfoDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_TRACKINGINFO_GET;

@RestController
@RequestMapping(path = "/secure")
public class TrackingRestController {

    @Autowired
    private ITrackingFacade trackingFacade;

    @ProfileExecution(codeAction = API_TRACKINGINFO_GET)
    @LogExecutionTime
    @GetMapping(path = "/tracking/info")
    public TrackingInfoDto getTrackingInfo() throws TechnicalException {
        return trackingFacade.getTrackingInfo();
    }
}
