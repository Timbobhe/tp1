package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersement;
import fr.ag2rlamondiale.trm.domain.sigelec.FormulaireActeEnLigneMapperLocator;
import lombok.Data;
import lombok.EqualsAndHashCode;


@FormulaireActeEnLigneMapperLocator(FormulaireVersementLibreMdproMapper.class)
@EqualsAndHashCode(callSuper = true)
@Data
public class DemandeCreationSigElecVersementLibreMdpro extends DemandeCreationSigElecVersement {
}
