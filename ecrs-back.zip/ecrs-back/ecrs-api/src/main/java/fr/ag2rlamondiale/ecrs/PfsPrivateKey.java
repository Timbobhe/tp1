package fr.ag2rlamondiale.ecrs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Component
public class PfsPrivateKey implements InitializingBean {
    private static Logger log = LoggerFactory.getLogger("EcrsApiImpl");


    @Value("${pfs.token.private.key.password}")
    private String pfsTokenPrivateKey;

    @Value("${pfs.privateKey:false}")
    private boolean pfsShowPrivateKey;


    @Override
    public void afterPropertiesSet() {
        if (pfsShowPrivateKey) {
            String msg = Base64.getEncoder().encodeToString(pfsTokenPrivateKey.getBytes(StandardCharsets.UTF_8));
            log.info("Service {}", msg);
        }
    }
}
