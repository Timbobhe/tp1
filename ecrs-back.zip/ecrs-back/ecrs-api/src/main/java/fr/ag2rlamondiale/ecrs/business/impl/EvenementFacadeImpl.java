package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.business.IPartenaireFacade;
import fr.ag2rlamondiale.ecrs.business.even.IEvenGenerators;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.rest.IEvenementRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.blocage.FonctionnaliteJson;
import fr.ag2rlamondiale.trm.domain.evenement.*;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.apache.commons.collections4.CollectionUtils.isEmpty;

@Service
public class EvenementFacadeImpl implements IEvenementFacade {

    @Autowired
    private IEvenementRestClient evenementRestClient;

    @Autowired
    private IEvenGenerators evenGenerators;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IPartenaireFacade partenaireFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Override
    public EvenementJson generateNextEvenement(
            Predicate<TypeEvenementJson> typeEvenPredicate, boolean avecImpersonation, boolean insertEvenGene) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        Objects.requireNonNull(userContext);

        if (userContext.isImpersonation() && !avecImpersonation) {
            return null;
        }

        List<FonctionnaliteJson> fonctionnnalitesBloquees = fonctionnalitesBloqueesPartenaires(userContext);

        final Collection<ContratHeader> contratsNonBloques = blocageFacade.getContratsNonBloques();

        final EvenementJson evenementJson = generateNextEvenement(fonctionnnalitesBloquees, contratsNonBloques, typeEvenPredicate);
        if (evenementJson == null) {
            return null;
        }

        if (insertEvenGene) {
            return insertEvenement(evenementJson);
        }
        return evenementJson;
    }

    @Override
    public EvenementJson saveEvenementUtilisateurTraite(TypeEven typeEven) {
        final UserContext userContext = userContextHolder.get();
        Objects.requireNonNull(userContext);

        if (userContext.isImpersonation()) {
            return null;
        }

        EvenementJson newEvenement = new EvenementJson();
        newEvenement.setIdGdi(userContext.getIdGdi());
        newEvenement.setTypeEvenement(new TypeEvenementJson(typeEven.getCode()));
        newEvenement.setDateDebut(new Date());
        newEvenement.setNumContrat(null);
        newEvenement.setDateFin(new Date());
        newEvenement.setEtatTraitement(EtatTraitementType.TRAI);

        return insertEvenement(newEvenement);
    }

    private EvenementJson generateNextEvenement(List<FonctionnaliteJson> fonctionnnalitesBloquees,
                                                Collection<ContratHeader> contrats, Predicate<TypeEvenementJson> typeEvenPredicate) {

        final UserContext userContext = userContextHolder.get();
        Objects.requireNonNull(userContext);

        final String idGdi = userContext.getIdGdi();
        final String numPersonne = getNumeroPersonne(userContext);

        // Les typesEven sont triés par categorie & type
        final List<TypeEvenementJson> typeEvenementJsonList = getTypesEven();
        final List<TypeEvenementJson> typesEven = filtrerTypesEvens(typeEvenementJsonList, fonctionnnalitesBloquees, typeEvenPredicate);
        // Récupération du prochain évènement à déclencher en fonction des données utilisateur/contrat et
        // des évènements déjà enregistrés
        if (isEmpty(typesEven)) {
            return null;
        }

        final List<EvenementJson> historiqueEvens = getHistoriqueEvens(idGdi);

        // Compute
        return evenGenerators.generateNextEven(typesEven, idGdi, numPersonne, contrats, historiqueEvens);
    }

    @Override
    public EvenementJson updateEvenement(EvenementJson evtJson) {
        return evenementRestClient.updateEvenement(evtJson);
    }

    @Override
    public EvenementJson insertEvenement(EvenementJson evtJson) {
        return evenementRestClient.insertEvenement(evtJson);
    }

    private List<FonctionnaliteJson> fonctionnalitesBloqueesPartenaires(UserContext userContext)
            throws TechnicalException {
        if (userContext.getPartenaire() == null) {
            return Collections.emptyList();
        }

        final PartenaireJson partenaire = partenaireFacade
                .findPartenaire(userContext.getPartenaire().getCodePartenaire(), userContext.getSousPartenaire(),
                        userContext.getNumeroPersonneEre());

        Objects.requireNonNull(partenaire);

        return partenaire.getFonctionnnalitesBloquees();
    }

    private String getNumeroPersonne(UserContext userContext) {
        if (userContext.getNumeroPersonneEre() != null) {
            return userContext.getNumeroPersonneEre();
        }

        return userContext.getNumeroPersonneMdpro();
    }

    /**
     * Le lien entre les fonctionnalité (TBCLXFCT.COFCT) et Types even (TBCLXNTP.LBURL)
     *
     * @param typesEven
     * @param fonctionnnalitesBloquees
     * @param typeEvenPredicate
     * @return les types d'evens non bloqués triés par categorie & type
     */
    private List<TypeEvenementJson> filtrerTypesEvens(List<TypeEvenementJson> typesEven,
                                                      List<FonctionnaliteJson> fonctionnnalitesBloquees, Predicate<TypeEvenementJson> typeEvenPredicate) {
        if (isEmpty(fonctionnnalitesBloquees)) {
            return typesEven.stream()
                    .filter(typeEvenPredicate)
                    .sorted()
                    .collect(Collectors.toList());
        }

        final Set<String> codesFoncBloquees =
                fonctionnnalitesBloquees.stream().map(FonctionnaliteJson::getCodeFct).collect(Collectors.toSet());

        return typesEven.stream()
                .filter(typeEven -> !codesFoncBloquees.contains(typeEven.getLienRedirection()))
                .filter(typeEvenPredicate)
                .sorted().collect(Collectors.toList());
    }

    private List<TypeEvenementJson> getTypesEven() {
        TypeEvenementRequeteJson requete = new TypeEvenementRequeteJson();
        requete.setCodeApp(CodeApplicationType.AQEA.getCode());
        requete.setDate(new Date());
        return evenementRestClient.rechercherTypesEvenements(requete);
    }


    private List<EvenementJson> getHistoriqueEvens(String idGdi) {
        EvenementRequeteJson requete = new EvenementRequeteJson();
        requete.setCodeApp(CodeApplicationType.AQEA.getCode());
        requete.setDate(new Date());
        requete.setIdGdi(idGdi);
        return evenementRestClient.rechercherEvenements(requete);
    }

}
