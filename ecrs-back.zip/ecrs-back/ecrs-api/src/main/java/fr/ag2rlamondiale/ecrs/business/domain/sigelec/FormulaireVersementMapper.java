package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.dto.versement.VersementModeDePaiementType;
import fr.ag2rlamondiale.formulaire.actesenligne.*;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public abstract class FormulaireVersementMapper implements IFormulaireMapper {
    private static final String DEVISE_EUR = "EUR";

    @Autowired
    private OccurenceStructureInvestissementTypeMapper occurenceStructureInvestissementTypeMapper;

    @Named("mapVersement")
    public VersementType mapVersement(DemandeCreationSigElecVersement dto) {
        RibDto coordonneesbancairesIn = dto.getCoordonneesBancairesDto();
        VersementType versementType = new VersementType();
        if (VersementModeDePaiementType.PRELEVEMENT_AUTOMATIQUE == dto.getModePaiement()) {
            CoordonneesBancairesInternationaleType coordonneesBancairesInternationale = new CoordonneesBancairesInternationaleType();
            coordonneesBancairesInternationale.setTitulaireCompte(coordonneesbancairesIn.getTitulaire());
            coordonneesBancairesInternationale.setCodeBIC(coordonneesbancairesIn.getBic());
            coordonneesBancairesInternationale.setCodeIBAN(coordonneesbancairesIn.getIban());
            versementType.setCoordonneesBancairesInternationale(coordonneesBancairesInternationale);
        }
        if (dto.getModePaiement() != null) {
            versementType.setModePaiementVersement(dto.getModePaiement().getLibelle());
        }
        if (dto.getMontant() != null) {
            versementType.setMontantVersement(dto.getMontant().intValue());
        }
        versementType.setDeviseVersement(DEVISE_EUR);
        versementType.setDateVersement(DateMapper.map(dto.getDateDebutVersement()));
        if (dto instanceof DemandeCreationSigElecVersementProgramme) {
            versementType.setCodePeriodicite(((DemandeCreationSigElecVersementProgramme) dto).getFrequenceVersement().getCodeFractionnement());
            versementType.setLibellePeriodicite(((DemandeCreationSigElecVersementProgramme) dto).getFrequenceVersement().getPeriodicite());
            if (dto.getDateFinVersement() != null) {
                versementType.setDatePrevueFinVersement(DateMapper.map(dto.getDateFinVersement()));
            }
        }
        versementType.setDelaiTraitementIndicatif(5);
        return versementType;
    }

    @Named("mapRepartitionSupportInvestissement")
    public RepartitionSupportInvestissementType mapRepartitionSupportInvestissement(DemandeCreationSigElecVersement dto) {
        List<SupportFinancierDto> supports = dto.getSupports();
        RepartitionSupportInvestissementType supportInvestissementType = new RepartitionSupportInvestissementType();

        List<OccurenceStructureInvestissementType> occurenceStructureInvestissementTypes = new ArrayList<>();
        BigDecimal montant = null;
        if (CollectionUtils.isNotEmpty(supports)) {
            supports.forEach(supportFinancierDto -> {
                if (supportFinancierDto.getContributionInvParent() != null) {
                    IdentificationStructureInvestissementType identificationStructureInvestissementType = new IdentificationStructureInvestissementType();
                    identificationStructureInvestissementType.setIdentifiantStructureInvestissement(
                            supportFinancierDto.getContributionInvParent().getCommonFields().getParentId());
                    supportInvestissementType.setIdentifiantStructureInvestissement(supportFinancierDto.getContributionInvParent().getCommonFields().getParentId());
                    occurenceStructureInvestissementTypes.add(occurenceStructureInvestissementTypeMapper
                            .mapContributionInvToOccurenceStructureInvestissementType(supportFinancierDto.getContributionInvParent(), montant));
                }
                occurenceStructureInvestissementTypes.add(occurenceStructureInvestissementTypeMapper
                        .mapSupportFinancierDtoToOccurenceStructureInvestissementType(supportFinancierDto, montant));
            });

            supportInvestissementType.getOccurenceStructureInvestissement().addAll(occurenceStructureInvestissementTypes);

        }
        return supportInvestissementType;
    }
}
