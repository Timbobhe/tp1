package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum DetailsVersementEREType {
    DEFAUT_PO(Constants.DEFAUT, TypeVersement.PO, 50, 500000, false),
    DEFAUT_VL(Constants.DEFAUT, TypeVersement.VL, 300, 999999, false),
    DEFAUT_PO_PACTE(Constants.DEFAUT, TypeVersement.PO, 50, 8000, true),
    DEFAUT_VL_PACTE(Constants.DEFAUT, TypeVersement.VL, 300, 999999, true),
    RG151411374("RG151411374", TypeVersement.VL, 100, 999999, false),
    RG151411471("RG151411471", TypeVersement.VL, 100, 999999, false),
    RG151411665("RG151411665", TypeVersement.VL, 100, 999999, false),
    RG151564440("RG151564440", TypeVersement.VL, 50, 999999, false),
    RG152201245("RG152201245", TypeVersement.VL, 50, 999999, false),
    RG152180293("RG152180293", TypeVersement.VL, 50, 999999, false),
    RG152285247("RG152285247", TypeVersement.VL, 50, 999999, false),
    RG151921594("RG151921594", TypeVersement.VL, 50, 999999, false),
    RG123554526("RG123554526", TypeVersement.VL, 300, 999999, false),
    RG151252488("RG151252488", TypeVersement.VL, 50, 999999, false),
    RG150063753("RG150063753", TypeVersement.VL, 100, 999999, false);

    private String contrat;
    private TypeVersement type;
    private int minMontantPossible;
    private int maxMontantPossible;
    private boolean pacte;

    public static DetailsVersementEREType getDetailFromContratAndType(String contrat, TypeVersement type, boolean pacte) {
        for (DetailsVersementEREType detailVersement : values()) {
            if (detailVersement.getType().equals(type) && detailVersement.getContrat().equals(contrat)) {
                return detailVersement;
            }
        }
        return TypeVersement.PO.equals(type) ? getPO(pacte) : getVL(pacte);
    }

    private static DetailsVersementEREType getVL(boolean pacte) {
        return pacte ? DEFAUT_VL_PACTE : DEFAUT_VL;
    }

    private static DetailsVersementEREType getPO(boolean pacte) {
        return pacte ? DEFAUT_PO_PACTE : DEFAUT_PO;
    }

    private static class Constants {
        public static final String DEFAUT = "Defaut";
    }
}
