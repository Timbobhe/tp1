package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IClientFacade;
import fr.ag2rlamondiale.ecrs.business.ICommunicationClientFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.client.soap.IRecherchePersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.StatutDemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.ecriture.FormulaireModificationDonneesPersonnellesDto;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Service
public class ClientFacadeImpl extends RechercheClientFacadeImpl implements IClientFacade {
    @Autowired
    private IRecherchePersonneClient recherchePersonneClient;

    @Autowired
    private IModifierPPSiloClient modifierPPSiloClient;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private ICommunicationClientFacade communicationFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IRechercherHabiliFacade habiliService;



    @Override
    public ModifierPPSiloResponseDto modifierCoordonneesClient(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        return userContext.estUniquementDansSilo(CodeSiloType.MDP) ? modifierCoordonneesClientMDPRO(nouvellesCoordonnees)
                : modifierCoordonneesClientERE(nouvellesCoordonnees);
    }

    private ModifierPPSiloResponseDto modifierCoordonneesClientMDPRO(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        // recuperer la personne physique depuis la Base
        PersonnePhysiqueConsult persPhys = consulterPersonneClient.consulterPersPhys(userContext.getIdSilo());
        persPhys.setEmailPerso(nouvellesCoordonnees.getEmail());
        persPhys.setTelPortable(nouvellesCoordonnees.getTelPortable());
        return new ModifierPPSiloResponseDto(true);
    }


    private ModifierPPSiloResponseDto modifierCoordonneesClientERE(CoordonneesClientDto nouvellesCoordonnees)
            throws TechnicalException {
        ContratComplet contratComplet;
        ContratHeader contratHeader;
        String idAssure;
        String oldEmail = Strings.EMPTY;
        final UserContext userContext = userContextHolder.get();
        // recuperer la personne physique depuis la Base
        PersonnePhysiqueConsult oldPersonnePhys = consulterPersonneClient.consulterPersPhys(userContext.getIdSilo());
        PersonnePhysiqueConsult newPersonnePhys = oldPersonnePhys.toBuilder().build(); // clone

        // mettre à jour juste les proprietés ( prevenant du front <=> proprieté !=
        // null)
        if (isNotBlank(nouvellesCoordonnees.getEmail())) {
            if (userContext.estDansSilo(CodeSiloType.ERE)) {
                oldEmail = oldPersonnePhys.getEmailPro();
                newPersonnePhys.setEmailPro(nouvellesCoordonnees.getEmail());
            } else {
                oldEmail = oldPersonnePhys.getEmailPerso();
                newPersonnePhys.setEmailPerso(nouvellesCoordonnees.getEmail());
            }
        }

        if (isNotBlank(nouvellesCoordonnees.getTelPortable())) {
            newPersonnePhys.setTelPortable(extractNumTelForEgesper(nouvellesCoordonnees.getTelPortable()));
        }

        if (userContext.estDansSilo(CodeSiloType.ERE)) {
            contratComplet = contratFacade.rechercherContratsCompletsERE().get(0);
            contratHeader = contratComplet.getContratHeader();

            if (contratHeader.isPacte()) {
                idAssure = contratHeader.getCompartiments().get(0).getIdentifiantAssure();
            } else {
                idAssure = contratHeader.getIdentifiantAssure();
            }

        } else {
            contratComplet = contratFacade.rechercherContratsCompletsMDP().get(0);
            contratHeader = contratComplet.getContratHeader();
            idAssure = contratHeader.getIdentifiantAssure();
        }

        createModificationDonneesPersonnellesDemandeWorkflow(contratComplet, oldPersonnePhys, newPersonnePhys,
                idAssure);

        // On fait la modification
        ModifierPPSiloDto modifierPPSiloDto = ModifierPPSiloDto.builder().personnePhysique(newPersonnePhys)
                .idSiloDto(userContext.getIdSilo()).build();
        ModifierPPSiloResponseDto result = modifierPPSiloClient.modifierPPSilo1(modifierPPSiloDto);

        consulterPersonneClient.forceCacheEvictConsulterPersPhys(userContext.getIdSilo());

        communicationFacade.sendConfirmationEmail(oldEmail, nouvellesCoordonnees.getEmail(), newPersonnePhys.getId(),
                contratHeader.getCodeFiliale(), contratHeader.getCodeSilo());

        return result;
    }

    private void createModificationDonneesPersonnellesDemandeWorkflow(ContratComplet contratComplet,
                                                                      PersonnePhysiqueConsult oldPersonnePhys, PersonnePhysiqueConsult newPersonnePhys, String idAssure)
            throws WorkflowException {

        ContratHeader contratHeader = contratComplet.getContratHeader();
        // Creation de l'objet demande
        FormulaireModificationDonneesPersonnellesDto donneesPersonnellesDemandeDto = FormulaireModificationDonneesPersonnellesDto
                .builder().idGdi(userContextHolder.get().getIdGdi())
                .typeAction(StatutDemandeWorkflowType.ARCHIVE.name())
                .demandeWorkflowType(DemandeWorkflowType.MODIF_DONNEES_PERSO_SALARIE).date(new Date())
                .idPersonne(oldPersonnePhys.getId()).idContrat(contratHeader.getId()).silo(CodeSiloType.ERE)
                .piecesJointes(null).donneesActuelles(oldPersonnePhys).donneesModifiees(newPersonnePhys)
                .codeMotifTraitement(null).libelleMotifTraitement("Adresse Ok")
                .codeFiliale(contratHeader.getCodeFiliale()).idAssure(idAssure)
                .raisonSocialeContractante(contratComplet.getContratGeneral().getContractante())
                .raisonSocialeAdherente(contratHeader.getRaisonSocialeAdherente())
                .referenceExterne(contratComplet.getContratGeneral().getReferenceExterne()).build();
        if (workflowFacade.creerDemandeWorkflow(donneesPersonnellesDemandeDto) == null) {
            throw new WorkflowException("La demande modification des données personnelles a échoué");
        }
    }

    private static String extractNumTelForEgesper(String numTel) {
        String result = numTel;
        if (numTel != null) {
            if (result.startsWith("+")) {
                result = "00" + result.substring(1);
            }
            if (!result.startsWith("0")) {
                result = "00" + result;
            }
        }
        return result;
    }
}
