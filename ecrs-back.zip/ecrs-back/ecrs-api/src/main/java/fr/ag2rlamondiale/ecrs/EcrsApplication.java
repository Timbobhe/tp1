package fr.ag2rlamondiale.ecrs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.task.TaskSchedulingAutoConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@EnableAspectJAutoProxy
@SpringBootApplication(exclude = {TaskSchedulingAutoConfiguration.class})
public class EcrsApplication {
    public static void main(String[] args) {
        SpringApplication.run(EcrsApplication.class, args);
    }
}
