package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ArretVersementTerminateDto implements ISecurityParamAccess {
    private ContratId contratSelected;
    private ArretVersementClientDto arretVersementClient;
    private DocumentDto contenuVersement;
    private String baseUrl;

    @Override
    public String secureForNumContrat() {
        return contratSelected.getNomContrat();
    }
}
