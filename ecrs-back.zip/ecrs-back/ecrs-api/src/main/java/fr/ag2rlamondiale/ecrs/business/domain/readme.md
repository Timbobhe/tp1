Ce package contient des objets **métiers** et <u>non des **DTO**</u>.

Les **DTO** sont dans le package **fr.ag2rlamondiale.ecrs.dto**.
