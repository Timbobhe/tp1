package fr.ag2rlamondiale.ecrs.domain.parametre;

public class ParametreConstantes {

    public static final String TYPE_TMI = "TMI";
    public static final String TYPE_PASS = "PASS";
    public static final String TYPE_ODF = "ODF";

    private ParametreConstantes() {
        // utils
    }
}
