package fr.ag2rlamondiale.ecrs.mapping.parametre;

import fr.ag2rlamondiale.ecrs.dto.simulateur.TmiDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public abstract class ParametreMapper {

    @Mapping(expression = "java(convert(parametre.getCodeParam()))", target = "taux")
    @Mapping(expression = "java(convert(parametre.getValeur1()))", target = "montantMin")
    @Mapping(expression = "java(convert(parametre.getValeur2()))", target = "montantMax")
    public abstract TmiDto map(ParametreDto parametre);

    public abstract List<TmiDto> map(List<ParametreDto> parametres);

    static Integer convert(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        return Integer.parseInt(value);
    }
}
