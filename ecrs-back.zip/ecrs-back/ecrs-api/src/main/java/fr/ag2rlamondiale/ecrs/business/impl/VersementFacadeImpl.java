package fr.ag2rlamondiale.ecrs.business.impl;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementMoyenPaiementType.CARTE_BANCAIRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementMoyenPaiementType.PRELEVEMENT_AUTOMATIQUE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Sets;

import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IParcoursSimplifieFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.business.IVersementFacade;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersement;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersementLibre;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersementProgramme;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportFinancierDto;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro.DemandeCreationSigElecVersementLibreMdpro;
import fr.ag2rlamondiale.ecrs.business.impl.document.QadDocRefType;
import fr.ag2rlamondiale.ecrs.business.impl.versement.BlocageVersementContratDto;
import fr.ag2rlamondiale.ecrs.business.impl.versement.DictionnaireVersementJahia;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementGestionMontantService;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementQuestionResolver;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementQuestionResolverChoixCompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.JahiaContextDto;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.DetailsVersementMDPROType;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.InfoVersementContratDto;
import fr.ag2rlamondiale.ecrs.dto.versement.RequestQuestionVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.RibStatusType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementClientDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementModeDePaiementType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementTerminateDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.rib.domain.sigelec.FormulaireModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.ModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.Adherente;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.RolePersonneContrat;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentMDProRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.mandat.FormulaireCoordonneesBancairesDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.sigelec.DocumentRIB;
import fr.ag2rlamondiale.trm.domain.sigelec.DocumentType;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.TypeDonneeATraiter;
import fr.ag2rlamondiale.trm.domain.sigelec.json.DocumentJson;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.trm.paiementdigital.dto.PaiementCbConsole;
import fr.ag2rlamondiale.trm.paiementdigital.dto.RechercherPaiementConsoleRequestDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.contrats.RolePersonneContratEnum;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VersementFacadeImpl implements IVersementFacade, ApplicationContextAware, InitializingBean {
	@Autowired
	private ContratParcoursMapper contratParcoursMapper;

	@Autowired
	private IBlocageFacade blocageFacade;

	@Autowired
	private IContratFacade contratFacade;

	@Autowired
	private ContratVifHelper contratVifHelper;

	@Autowired
	private UserContextHolder userContextHolder;

	@Autowired
	private IConsulterPersPhysFacade consulterPersPhysFacade;

	@Autowired
	private IStructureInvFacade structureInvFacade;

	@Autowired
	private VersementQuestionResolverChoixCompartiment choixCompartiment;

	@Autowired
	private IDataDocumentContratFacade dataDocumentContratFacade;

	@Autowired
	private ISigElecFacade sigElecfacade;

	@Autowired
	private IParamConsoleFacade paramConsoleFacade;

	@Autowired
	private IWorkflowFacade demandeWorkflowFacade;

	@Autowired
	private IPaiementFacade paiementFacade;

	@Autowired
	private RequestContextHolder requestContextHolder;

	@Autowired
	private VersementGestionMontantService versementGestionMontantService;

	@Autowired
	private IParcoursSimplifieFacade parcoursSimplifieFacade;

	private Collection<VersementQuestionResolver> questionResolvers = new ArrayList<>();

	private ApplicationContext applicationContext;

	@Value("${gps.versement.mdpro.active:false}")
	private boolean gpsVersementMdproActive;

	private static final Set<SituationContratEnum> ETATS_CONTRATS_ENCOURS = Sets.newHashSet(
			SituationContratEnum.EN_COURS, SituationContratEnum.EN_COURS_SANS_PRIME,
			SituationContratEnum.LIBERE_PRIME_OFFICE, SituationContratEnum.LIBERE_PRIME_DEMANDE);

	private static final Set<String> V51_A_V54 = Sets.newHashSet("V51", "V52", "V53", "V54");

	@Override
	public VersementStartDto startVersement() throws TechnicalException {
		List<InfoVersementContratDto> infos = rechercherContratsVersements();
		boolean sigElecOff;
		UserContext uc = userContextHolder.get();
		PersonnePhysiqueConsult personnePhysiqueConsult = consulterPersPhysFacade.consulterPersPhys(uc.getIdSilo());
		String paysResidence = personnePhysiqueConsult.getPays();
		String paysResidenceFisc = personnePhysiqueConsult.getPaysResidenceFiscale();

		if (!((paysResidence == null || "FRANCE".equalsIgnoreCase(paysResidence))
				&& (paysResidenceFisc == null || "FRANCE".equalsIgnoreCase(paysResidenceFisc)))) {
			sigElecOff = true;
		} else {
			sigElecOff = infos.stream().filter(infoVersementContratDto -> !infoVersementContratDto.isBloque())
					.allMatch(InfoVersementContratDto::isSigElecOff);
		}
		return VersementStartDto.builder().versements(infos).sigElecOff(sigElecOff).build();
	}

	private List<InfoVersementContratDto> rechercherContratsVersements() throws TechnicalException {
		List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();
		final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();

		return contratComplets.stream().filter(c -> !c.getContratHeader().getAffichageType().isDisabled())
				.filter(c -> c.getContratHeader().hasCompartiments(CompartimentType.C1)
						|| c.getContratHeader().hasCompartiments(CompartimentType.C4))
				.filter(c -> {
					if (requestContextHolder.getContrat() != null) {
						return c.getContratHeader().getId().equals(requestContextHolder.getContrat());
					}
					return true;
				}).map(c -> handleException(() -> this.buildInfoVersementContrat(c, blocagesClient)))
				.collect(Collectors.toList());
	}

	private InfoVersementContratDto buildInfoVersementContrat(ContratComplet contratComplet,
			InfosBlocagesClient blocagesClient) throws TechnicalException {
		boolean bloque = blocagesClient.isFonctionnaliteBloqueePourContrat(contratComplet.getContratHeader().getId(),
				FonctionnaliteType.VERSEMENT_LIBRE)
				&& blocagesClient.isFonctionnaliteBloqueePourContrat(contratComplet.getContratHeader().getId(),
						FonctionnaliteType.VERSEMENT_PROGRAMME);
		boolean simplifie = parcoursSimplifieFacade.isParcoursSimplifieActivate(
				contratComplet.getContratHeader().getId(), FonctionnaliteType.VERSEMENT_SIMPLIFIE);
		final InfoVersementContratDto result = InfoVersementContratDto.builder()
				.contrat(contratParcoursMapper.map(contratComplet.getContratHeader(), true,
						Arrays.asList(CompartimentType.C1, CompartimentType.C4)))
				.codeFiliale(contratComplet.getContratHeader().getCodeFiliale()).bloque(bloque)
				.isParcoursSimplifie(simplifie)
                .sigElecOff(blocagesClient.isFonctionnaliteBloqueePourContrat(contratComplet.getContratHeader().getId(), FonctionnaliteType.SIGELEC_VERSEMENT))
                .contextJahia(JahiaContextDto.builder().parcoursSimplifie(simplifie).build()).build();

		if (bloque) {
			return buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE);
		}

		return contratComplet.is(CodeSiloType.ERE) ? buildInfoVersementContratERE(contratComplet, result)
				: buildInfoVersementContratMDPRO(contratComplet, result, blocagesClient);
	}

	private InfoVersementContratDto buildInfoVersementContratBlocage(InfoVersementContratDto result,
			DictionnaireVersementJahia jahiaDicoEntry) {
		result.setBloque(true);
		result.setRaisonBlocage(MessageDto.builder().jahiaDicoEntry(jahiaDicoEntry.name()).build());
		return result;
	}

	private InfoVersementContratDto buildInfoVersementContratERE(ContratComplet contratComplet,
			InfoVersementContratDto result) throws TechnicalException {
		ContratHeader contratHeader = contratComplet.getContratHeader();
		final VersementContexteDto mock = new VersementContexteDto();
		mock.setContratSelectionne(contratHeader.getContratId());
		final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> qr = choixCompartiment
				.resolve(contratHeader, mock);
		result.setChoixCompartiment(qr);

		if (qr.getData().isContratBloque()) {
			// On n'affiche pas la question et il n'y a pas de proposition => Contrat
			// bloqu&eacute;
			result.setBloque(true);
			result.setRaisonBlocage(qr.getWarningMessage());
		} else if (!contratVifHelper.isVifPossibleByListCompartimentTypes(contratComplet,
				Arrays.asList(CompartimentType.C1, CompartimentType.C4))) {
			result.setBloque(true);
			result.setRaisonBlocage(MessageDto.builder()
					.jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name()).build());
		}

		return result;
	}

	private InfoVersementContratDto buildInfoVersementContratMDPRO(ContratComplet contratComplet,
			InfoVersementContratDto result, InfosBlocagesClient blocagesClient) throws TechnicalException {
		ContratHeader contratHeader = contratComplet.getContratHeader();
		ContratGeneral contratGeneral = contratComplet.getContratGeneral();
		final SituationContratEnum situationContrat = contratHeader.getEtatContrat();
		final VersementContexteDto ctx = new VersementContexteDto();
		ctx.setContratSelectionne(contratHeader.getContratId());
		final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> qr = choixCompartiment
				.resolve(contratHeader, ctx);
		result.setChoixCompartiment(qr);

		result.setSigElecOff(contratGeneral.getCoordonneesCmptBanc() == null);

		if (qr.getData().isContratBloque()) {
			// On n'affiche pas la question et il n'y a pas de proposition => Contrat
			// bloqu&eacute;
			result.setBloque(true);
			result.setRaisonBlocage(qr.getWarningMessage());
			return result;
		}

		if (modeVersementBloque(contratHeader, FonctionnaliteType.VERSEMENT_LIBRE, blocagesClient)) {
			result.setBloque(true);
			result.setRaisonBlocage(MessageDto.builder()
					.jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name()).build());
			return result;
		}

		if (!ETATS_CONTRATS_ENCOURS.contains(situationContrat)) {
			buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT);
			return result;
		}

		final GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdp = structureInvFacade
				.getInfoGestionFinanciereActuelleMdp(contratHeader);
		result.setGestionFinanciereActuelleMdp(gestionFinanciereActuelleMdp);

		final ProduitJson produitMdpro = paramConsoleFacade.findProduitMdpro(contratHeader.getTypeContrat(),
				contratHeader.getNumGenContrat());
		buildInfoVersementByProductMdpro(result, situationContrat, produitMdpro);
		result.setFiscalite(produitMdpro != null ? produitMdpro.getLibelleFiscalite() : null);

		if (!isSouscripteurIsAssureAndPersonnePhysiqueMDP(contratGeneral)
				|| !isAssureOrSouscripteurMajeur(contratGeneral) || !isDonneesPersonnellesConfirmees()
				|| isTiersPayeur(contratGeneral)) {
			result.setSigElecOff(true);
			return result;
		}
		return result;
	}

	private void buildInfoVersementByProductMdpro(InfoVersementContratDto result, SituationContratEnum situationContrat,
			ProduitJson produitMdpro) {
		if (produitMdpro == null || produitMdpro.getDeductible() == null) {
			buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT);
		} else if (DetailsVersementMDPROType.MADELIN.isFiscalite(produitMdpro.getLibelleFiscalite())) {
			if (SituationContratEnum.EN_COURS.isDifferent(situationContrat)) {
				buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT);
			}
		} else if ("RA09".equalsIgnoreCase(produitMdpro.getTypeContrat())
				&& V51_A_V54.contains(produitMdpro.getNumeroGeneration())) {
			if (SituationContratEnum.EN_COURS.isDifferent(situationContrat)) {
				buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT);
			}
		} else if (SituationContratEnum.LIBERE_PRIME_OFFICE.isDifferent(situationContrat)
				&& SituationContratEnum.LIBERE_PRIME_DEMANDE.isDifferent(situationContrat)
				&& SituationContratEnum.EN_COURS.isDifferent(situationContrat)
				&& SituationContratEnum.EN_COURS_SANS_PRIME.isDifferent(situationContrat)) {
			buildInfoVersementContratBlocage(result, DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT);
		}
	}

	private boolean modeVersementBloque(ContratHeader contratHeader, FonctionnaliteType fct,
			InfosBlocagesClient blocagesClient) {
		return blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), fct);
	}

	@Override
	public boolean isAssureOrSouscripteurMajeur(ContratGeneral contratGeneral) {
		// RM08 MDPRO
		// souscripteurs ou assur&eacute;s mineurs = date de naissance du souscripteur
		// ou de l'assur&eacute;
		// inf&eacute;rieure &agrave; 18 ans
		return DateUtils.estMajeur(contratGeneral.getDateNaissanceContractante())
				&& DateUtils.estMajeur(contratGeneral.getDateNaissanceAssurePrincipal());
	}

	@Override
	public boolean isSouscripteurIsAssureAndPersonnePhysiqueMDP(ContratGeneral contratGeneral) {
		// RM07 + RM09 MDPRO
		if (StringUtils.isBlank(contratGeneral.getIdContractante())) {
			return true;
		}
		return StringUtils.isNotBlank(contratGeneral.getIdContractante())
				&& contratGeneral.getIdContractante().startsWith("P")
				&& contratGeneral.getIdContractante().equals(contratGeneral.getIdAssurePrincipal());
	}

	private boolean isDonneesPersonnellesConfirmees() {
		try {
			return consulterPersPhysFacade.consulterPersPhys(userContextHolder.get().getIdSilo())
					.isDonneesPersonnellesConfirmees();
		} catch (TechnicalException e) {
			return false;
		}
	}

	private boolean isTiersPayeur(ContratGeneral contratGeneral) {
		List<RolePersonneContrat> rolePersonneContrats = contratGeneral.getRolePersonnes();
		if (CollectionUtils.isEmpty(rolePersonneContrats)) {
			return false;
		}
		String codeSouscripteur = contratGeneral.getIdContractante();

		for (RolePersonneContrat rolePersonne : rolePersonneContrats) {
			if (RolePersonneContratEnum.TIERS_PAYEUR.getCodeValue().equalsIgnoreCase(rolePersonne.getCodeRolePersCtr())
					&& StringUtils.isNotBlank(codeSouscripteur)
					&& !codeSouscripteur.equalsIgnoreCase(rolePersonne.getIdPers().getIdSilo())) {
				return true;
			}
		}
		return false;
	}

	@Override
	public <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionVersementDto request)
			throws TechnicalException {
		final QuestionType questionType = request.getQuestionType();
		final VersementContexteDto contexte = request.getContexte();
		final VersementQuestionResolver questionResolver = questionResolvers.stream()
				.filter(resolver -> resolver.accept(questionType, contexte)).findFirst()
				.orElseThrow(() -> new IllegalArgumentException(
						"Impossible de retrouver le Resolver pour " + questionType + " et " + contexte));
		return questionResolver.resolve(questionType, contexte);
	}

	@Override
	public ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionVersementDto request)
			throws TechnicalException {
		final List<QuestionType> questionTypeList = request.getQuestionTypeList();

		List<QuestionType> aTraiter = Collections.singletonList(request.getQuestionType());
		if (questionTypeList != null && !questionTypeList.isEmpty()
				&& questionTypeList.contains(request.getQuestionType())) {
			aTraiter = questionTypeList.subList(questionTypeList.indexOf(request.getQuestionType()),
					questionTypeList.size());
		}

		final ListQuestionResponsesDto result = new ListQuestionResponsesDto();
		for (QuestionType questionType : aTraiter) {
			final QuestionResponsesDto<Object, Object> qr = resolveQuestion(
					request.toBuilder().questionType(questionType).build());
			result.add(qr);
			if (qr.isShow()) {
				result.setQuestionTypeDisplayed(questionType);
				break;
			}
		}

		return result;
	}

	@Override
	public String terminate(VersementTerminateDto versementTerminate, boolean isFrame)
			throws TechnicalException, IOException, JAXBException {
		revalidateVersement(versementTerminate);

		final ContratId contratId = versementTerminate.getContratSelected();
		final CompartimentId compartimentId = versementTerminate.getVersementClient().getCompartimentId();
		DocumentDto versementDocument = versementTerminate.getContenuVersement();
		DocumentDto qadDocument = versementTerminate.getContenuQad();

		final ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);
		final Compartiment compartiment = contratHeader.compartiment(compartimentId);

		final DocRefType docRefType = getDocRefType(versementTerminate);

		DataDocumentContrat<ContratHeader> documentActeContrat = null;
		if (versementDocument != null && versementDocument.getHtmlContent() != null) {
			documentActeContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId,
					versementDocument, docRefType, dataDocumentContrat -> dataDocumentContrat
							.setRib(toDocumentRIB(versementTerminate.getVersementClient().getCoordonneesBancaires())));
		}

		DataDocumentContrat<ContratHeader> documentQadContrat = null;
		if (qadDocument != null && qadDocument.getHtmlContent() != null) {
			final DocRefType qadDocRefType = QadDocRefType.getSpecificQadDoc(docRefType);
			documentQadContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId,
					qadDocument, qadDocRefType);
		}

		DataDocumentContrat<ContratHeader> documentActeRibContrat = null;
		if (contratHeader.isMdpro()
				&& RibStatusType.NEW.equals(versementTerminate.getVersementClient().getRibStatus())) {
			final DocRefType docRefTypeRib = DocumentMDProRefType.MODIFICATION_RIB_MDPRO;
			documentActeRibContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId, null,
					docRefTypeRib, dataDocumentContrat -> {
						DocumentRIB documentRIB = new DocumentRIB();
						documentRIB.setBic(versementTerminate.getVersementClient().getCoordonneesBancaires().getBic());
						documentRIB
								.setIban(versementTerminate.getVersementClient().getCoordonneesBancaires().getIban());
						documentRIB.setTitulaire(
								versementTerminate.getVersementClient().getCoordonneesBancaires().getTitulaire());
						dataDocumentContrat.setRib(documentRIB);
					});
		}

		if (documentActeContrat != null) {
			DemandeCreationSigElecVersement demandeCreationSigElec = initDemandeCreationSigElecVersement(
					versementTerminate, contratHeader, documentActeContrat, documentQadContrat, documentActeRibContrat,
					compartiment);
			return sigElecfacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec, isFrame);
		} else {
			return null;
		}
	}

	private void revalidateVersement(VersementTerminateDto versementTerminate) throws TechnicalException {
		Objects.requireNonNull(versementTerminate);
		Objects.requireNonNull(versementTerminate.getVersementClient());
		if (CARTE_BANCAIRE.equals(versementTerminate.getVersementClient().getMoyenPaiement())
				&& paiementFacade.isPaiementDigitalEnabled()) {
			final PaiementCbConsole paiementCbConsole = paiementFacade
					.rechercherPaiementConsole(
							RechercherPaiementConsoleRequestDto.builder()
									.idTransactionPaiementCB(
											versementTerminate.getVersementClient().getIdTransactionPaiementCB())
									.build());

			Objects.requireNonNull(paiementCbConsole);
			if (!paiementCbConsole.getEtat().isIndicateurSucces()) {
				throw new TechnicalException("Etat du paiement anormal => " + paiementCbConsole.getEtat());
			}
		} else {
			final BigDecimal montantVersement = versementTerminate.getVersementClient().getMontantVersement();
			final ContratHeader contratHeader = contratFacade
					.rechercherContratParId(versementTerminate.getContratSelected());
			if (!versementGestionMontantService.verifierMontant(contratHeader,
					versementTerminate.getVersementClient().getModeVersement().getTypeVersement(), montantVersement)) {
				throw new TechnicalException("Montant du versement anormal => " + montantVersement);
			}
		}
	}

	private DocRefType getDocRefType(VersementTerminateDto versementTerminate) {
		boolean isERE = CodeSiloType.ERE.equals(versementTerminate.getContratSelected().getCodeSilo());
		DocRefType docType;
		// Mandat SEPA nouveau ou modifi&eacute;
		if (RibStatusType.NEW.equals(versementTerminate.getVersementClient().getRibStatus())) {
			docType = isERE ? DocumentRefType.DEMANDE_EN_LIGNE_SEPA : DocumentMDProRefType.DEMANDE_EN_LIGNE_SEPA_MDPRO;
		} else {
			// Mandat SEPA deja connu
			docType = isERE ? DocumentRefType.VERSEMENT_EN_LIGNE : DocumentMDProRefType.VERSEMENT_EN_LIGNE_MDPRO;
		}
		return docType;
	}

	private DocumentRIB toDocumentRIB(RibDto dto) {
		if (dto == null) {
			return null;
		}

		return new DocumentRIB(dto.getTitulaire(), dto.getBic(), dto.getIban());
	}

	private DemandeCreationSigElecVersement initDemandeCreationSigElecVersement(
			VersementTerminateDto versementTerminateDto, ContratHeader contratHeader,
			DataDocumentContrat<ContratHeader> documentActeContrat,
			DataDocumentContrat<ContratHeader> documentQadContrat,
			DataDocumentContrat<ContratHeader> documentActeRibContrat, Compartiment compartiment)
			throws TechnicalException {
		final UserContext userContext = userContextHolder.get();
		final String numPersonne = contratHeader.getPersonId();
		final VersementClientDto versementClientDto = versementTerminateDto.getVersementClient();

		DemandeCreationSigElecVersement demandeCreationSigElec;
		BigDecimal montant = versementClientDto.getMontantVersement();
		demandeCreationSigElec = getDemandeCreationSigElecTypeVersement(contratHeader, versementClientDto, montant);

		demandeCreationSigElec.add(documentActeContrat);

		if (documentQadContrat != null) {
			demandeCreationSigElec.add(documentQadContrat);
		}

		demandeCreationSigElec.setCodeAssureur(contratHeader.getCodeAssureur());

		if (contratHeader.isEre()) {
			demandeCreationSigElec.setCodeSilo(ERE);
			demandeCreationSigElec.setTypeDonneeATraiter(TypeDonneeATraiter.WORK);
		} else {
			demandeCreationSigElec.setCodeSilo(MDP);
			demandeCreationSigElec
					.setTypeDonneeATraiter(gpsVersementMdproActive ? TypeDonneeATraiter.WORK : TypeDonneeATraiter.MAIL);
		}
		demandeCreationSigElec.setCompartimentType(compartiment.getType());

		demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
		demandeCreationSigElec.setAgrementsConventionDePreuve(documentActeContrat.getAgrementsConventionDePreuve());
		demandeCreationSigElec.setConventionDePreuveTitre(documentActeContrat.getConventionDePreuveTitre());

		demandeCreationSigElec.setIdentifiantAssure(documentActeContrat.getIdAssure());
		demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
		demandeCreationSigElec.setNumPP(numPersonne);
		demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo()));

		demandeCreationSigElec.setDateDebutVersement(versementClientDto.getDateVersement());

		if (PRELEVEMENT_AUTOMATIQUE.equals(versementClientDto.getMoyenPaiement())) {
			demandeCreationSigElec.setCoordonneesBancairesDto(versementClientDto.getCoordonneesBancaires());
			demandeCreationSigElec.setModePaiement(VersementModeDePaiementType.PRELEVEMENT_AUTOMATIQUE);
		} else if (CHEQUE_BANCAIRE.equals(versementClientDto.getMoyenPaiement())) {
			demandeCreationSigElec.setModePaiement(VersementModeDePaiementType.CHEQUE_BANCAIRE);
		} else if (CARTE_BANCAIRE.equals(versementClientDto.getMoyenPaiement())) {
			demandeCreationSigElec.setModePaiement(VersementModeDePaiementType.CARTE_BANCAIRE);
			demandeCreationSigElec.setIdTransactionPaiementCB(versementClientDto.getIdTransactionPaiementCB());
		}

		if (CollectionUtils.isNotEmpty(versementClientDto.getNouvelleRepartition().getRepartitions())) {
			setNewRepartitionList(versementClientDto.getNouvelleRepartition().getRepartitions(), contratHeader,
					compartiment, demandeCreationSigElec);
		} else {
			List<RepartitionSupportDto> repartitionsActuelles = versementClientDto.getRepartitionActuelle()
					.getRepartitions();
			repartitionsActuelles.forEach(repartitionSupportDto -> repartitionSupportDto.setSelectionned(true));
			setNewRepartitionList(repartitionsActuelles, contratHeader, compartiment, demandeCreationSigElec);
		}

		if (RibStatusType.NEW.equals(versementClientDto.getRibStatus())) {
			final List<DocumentJson> documents = getUploadedRibs(versementClientDto.getFichiercoordonneesBancaires());
			demandeCreationSigElec.setUploadedDocuments(documents);
			demandeCreationSigElec.setRibStatusType(versementClientDto.getRibStatus());
		}
		if (versementClientDto.isOdfRenseigne()) {
			List<DocumentJson> documentsDejaUploaded = demandeCreationSigElec.getUploadedDocuments();
			// Rajouter les documents Pieces justificatives ODF
			List<DocumentJson> documentsODF = getUploadedODFPieces(versementClientDto.getFichierOriginesFonds());
			demandeCreationSigElec.setUploadedDocuments(
					Stream.concat(documentsDejaUploaded.stream(), documentsODF.stream()).collect(Collectors.toList()));
		}

		if (contratHeader.isMdpro() && RibStatusType.NEW.equals(versementClientDto.getRibStatus())) {
			ModificationCoordonneesBancairesDto mcb = new ModificationCoordonneesBancairesDto();
			mcb.setCoordonneesBancairesModifiees(map(versementClientDto.getCoordonneesBancaires()));
			mcb.setFichiersJoint(Collections.singletonList(versementClientDto.getFichiercoordonneesBancaires()));

			demandeCreationSigElec.setFormulaireModificationCoordonneesBancairesDto(
					mapperCoordonneesBancairesToFormulaire(mcb, contratHeader, compartiment.getCompartimentId()));
			demandeCreationSigElec.add(documentActeRibContrat);
		}

		return demandeCreationSigElec;
	}

	private DemandeCreationSigElecVersement getDemandeCreationSigElecTypeVersement(ContratHeader contratHeader,
			VersementClientDto versementClientDto, BigDecimal montant) {
		DemandeCreationSigElecVersement demandeCreationSigElec;
		if (VERSEMENT_LIBRE.equals(versementClientDto.getModeVersement())) {
			demandeCreationSigElec = contratHeader.isMdpro() ? new DemandeCreationSigElecVersementLibreMdpro()
					: new DemandeCreationSigElecVersementLibre();
			demandeCreationSigElec.setTypeOperation(OperationType.VRLI);
			demandeCreationSigElec.setMontant(montant);
		} else if (VERSEMENT_PROGRAMME.equals(versementClientDto.getModeVersement())) {
			demandeCreationSigElec = new DemandeCreationSigElecVersementProgramme();
			demandeCreationSigElec.setTypeOperation(OperationType.VRPG);
			BigDecimal montantActuel = versementClientDto.getMontantVersementActuel();
			FrequenceVirementType frequence = versementClientDto.getPeriodiciteVersement();
			FrequenceVirementType frequenceActuel = versementClientDto.getPeriodiciteVersementActuel();
			((DemandeCreationSigElecVersementProgramme) demandeCreationSigElec).setFrequenceVersement(frequence);
			BigDecimal montantMensuel = montant.divide(BigDecimal.valueOf(frequence.getMonths()), 2,
					BigDecimal.ROUND_HALF_UP);
			BigDecimal montantMensuelActuel = BigDecimal.ZERO;
			if (montantActuel != null && frequenceActuel != null) {
				montantMensuelActuel = montantActuel.divide(BigDecimal.valueOf(frequenceActuel.getMonths()), 2,
						BigDecimal.ROUND_HALF_UP);
			}
			demandeCreationSigElec.setMontant(montantMensuel.subtract(montantMensuelActuel));
		} else {
			throw new IllegalArgumentException("Mode de versement inconnu : " + versementClientDto.getModeVersement());
		}
		return demandeCreationSigElec;
	}

	private FormulaireCoordonneesBancairesDto map(RibDto ribDto) {
		FormulaireCoordonneesBancairesDto fcb = new FormulaireCoordonneesBancairesDto();
		fcb.setCodeBIC(ribDto.getBic());
		fcb.setCodeIBAN(ribDto.getIban());
		fcb.setTitulaireCompte(ribDto.getTitulaire());
		return fcb;
	}

	private FormulaireModificationCoordonneesBancairesDto mapperCoordonneesBancairesToFormulaire(
			ModificationCoordonneesBancairesDto dto, IContrat contrat, CompartimentId compartimentId)
			throws WorkflowException {
		final ContratGeneral contratGeneral;
		try {
			contratGeneral = contratFacade.rechercherContratGeneral(contrat.getContratId());
		} catch (TechnicalException e) {
			throw new TechnicalRuntimeException(e);
		}

		// get Adherente
		Optional<Adherente> adherente = contratGeneral.getAdherentes().stream()
				.filter(adh -> adh.getId().equals(contrat.getIdAdherente())).findFirst();
		String adherenteRS = adherente.isPresent() ? adherente.get().getRaisonSociale() : "";

		String idDemandeWkf = demandeWorkflowFacade.genererIdDemFront(CodeActionType.DEM_RIBA, contrat.getPersonId(),
				contrat.getNomContrat(), contrat.getContratId().getCodeSilo());

		final String idAssure = compartimentId != null ? compartimentId.getIdAssure() : null;

		return FormulaireModificationCoordonneesBancairesDto.builder().idGdi(userContextHolder.get().getIdGdi())
				.idPersonne(contrat.getPersonId()).idContrat(contrat.getContratId().getNomContrat())
				.silo(contrat.getContratId().getCodeSilo()).idAssure(idAssure).nom(userContextHolder.get().getNom())
				.prenom(userContextHolder.get().getPrenom()).codeFiliale(contratGeneral.getCodeFiliale())
				.coordonneesBancairesActuelles(dto.getCoordonneesBancairesActuelles())
				.coordonneesBancairesModifiees(dto.getCoordonneesBancairesModifiees())
				.raisonSocialeContractante(contratGeneral.getContractante()).raisonSocialeAdherente(adherenteRS)
				.idDemandeWkf(idDemandeWkf).referenceExterne(contratGeneral.getReferenceExterne()).build();
	}

	@Nonnull
	private List<DocumentJson> getUploadedRibs(UploadFileDto uploadRib) {
		if (uploadRib != null && uploadRib.getFileContent() != null) {
			final DocumentJson doc = DocumentJson.builder().type(DocumentType.RIB).contenu(uploadRib.getFileContent())
					.build();
			return Arrays.asList(doc);
		}
		return Collections.emptyList();
	}

	private List<DocumentJson> getUploadedODFPieces(List<UploadFileDto> uploadPiecesJointes) {
		List<DocumentJson> docsJson = new ArrayList<>();
		for (UploadFileDto pieceJointe : uploadPiecesJointes) {
			if (pieceJointe != null && pieceJointe.getFileContent() != null) {
				final DocumentJson doc = DocumentJson.builder().type(DocumentType.JOF)
						.contenu(pieceJointe.getFileContent()).build();
				docsJson.add(doc);
			}
		}
		return docsJson;
	}

	private void setNewRepartitionList(List<RepartitionSupportDto> repartitionSupportDtos, ContratHeader contratHeader,
			Compartiment compartiment, DemandeCreationSigElecVersement demandeCreationSigElec) {
		List<SupportFinancierDto> supports = new ArrayList<>();
		fillNewSupportFinancierDtoList(contratHeader, supports, repartitionSupportDtos, compartiment);
		demandeCreationSigElec.setSupports(supports);
	}

	private void fillNewSupportFinancierDtoList(ContratHeader contratHeader, List<SupportFinancierDto> supports,
			List<RepartitionSupportDto> repartitionSupportDtos, Compartiment compartiment) {
		List<RepartitionSupportDto> repartitionSupports = contratHeader.isMdpro()
				? repartitionSupportDtos.stream().filter(RepartitionSupportDto::isSelectionned)
						.collect(Collectors.toList())
				: repartitionSupportDtos;

        try {
            supports.addAll(structureInvFacade.retrieveSupportFinancierList(
                    contratHeader, ContributionType.forCompartiment(compartiment.getType(),
                            compartiment.isPacte()), repartitionSupports, FonctionnaliteType.VERSEMENT, null));
            normalizePourcentage(supports, contratHeader);
        } catch (TechnicalException e) {
            log.error("Erreur lors de la recuperation des supports de la nouvelle repartion du contrat {} de {}", contratHeader.getId(), contratHeader.getPersonId());
        }
    }

	private void normalizePourcentage(List<SupportFinancierDto> repartitionSupportList, ContratHeader contratHeader) {
		repartitionSupportList.forEach(supportFinancierDto -> {
			if (supportFinancierDto.getTaux().compareTo(BigDecimal.ONE) <= 0 && contratHeader.isMdpro()) {
				supportFinancierDto.setTaux(BigDecimal.valueOf(100).multiply(supportFinancierDto.getTaux()));
			} else if (supportFinancierDto.getTaux().compareTo(BigDecimal.ONE) > 0 && contratHeader.isEre()) {
				supportFinancierDto.setTaux(
						supportFinancierDto.getTaux().divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
			}
		});
	}

	@Override
	public void setApplicationContext(@Nonnull ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	@Override
	public void afterPropertiesSet() {
		final Map<String, VersementQuestionResolver> beansOfType = this.applicationContext
				.getBeansOfType(VersementQuestionResolver.class);
		this.questionResolvers = beansOfType.values();
	}
}
