package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.ecrs.business.ICguFacade;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_CGU_ACCEPTATION_CREATE;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_CGU_DETAILS_GET;

@RestController
@RequestMapping(path = "/secure")
public class CguRestController {

    @Autowired
    private ICguFacade cguFacade;

    @ProfileExecution(codeAction = API_CGU_DETAILS_GET)
    @LogExecutionTime
    @GetMapping(path = "/cgu_details")
    public CguDetails getCguDetails() {
        return cguFacade.getCguDetails();
    }

    @ProfileExecution(codeAction = API_CGU_ACCEPTATION_CREATE)
    @LogExecutionTime
    @PostMapping(path = "/cgu_acceptation/create")
    public boolean createAcceptationCgu() throws TechnicalException {
        return cguFacade.createAcceptationCgu(getCguDetails().getIdCgu());
    }
}
