package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageEurosPourcentageType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageTotalPartielType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_REPARTIR;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_REPARTITION_EN_EUROS;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_REPARTITION_EN_POURCENTAGE;
@Service
public class ArbitrageQuestionResolverEurosPourcentERE implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Override
    public QuestionResponsesDto<ResponseArbitrageEurosPourcentageType, ?> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<ResponseArbitrageEurosPourcentageType, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT)
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_REPARTIR.name())
                .build());

        if (contexte.getResponseFluxStockType().isFlux()
                || contexte.getResponseTotalPartielType().equals(ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL)
                || isPartObligatoireAvecPPetPS(contexte)) {
            result.setShow(false);
            result.setDefaultValue(reponsePourcentage());
            contexte.update(ctx -> ctx.setResponseEurosPourcentageType(ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE));

            return result;
        }

        result.add(reponseEuros());
        result.add(reponsePourcentage());
        return result;
    }

    public ResponseDto<ResponseArbitrageEurosPourcentageType> reponseEuros() {
        return ResponseDto.<ResponseArbitrageEurosPourcentageType>builder()
                .value(ResponseArbitrageEurosPourcentageType.ARBITRAGE_EUROS)
                .jahiaDicoEntry(ARB_REPARTITION_EN_EUROS.name())
                .build();
    }

    public ResponseDto<ResponseArbitrageEurosPourcentageType> reponsePourcentage() {
        return ResponseDto.<ResponseArbitrageEurosPourcentageType>builder()
                .value(ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE)
                .jahiaDicoEntry(ARB_REPARTITION_EN_POURCENTAGE.name())
                .build();
    }

    private boolean isPartObligatoireAvecPPetPS(ArbitrageContexteDto contexte) throws TechnicalException {
        if (contexte.isTousCompartimentsSelectionnes()
                || CompartimentType.C3.equals(contexte.getCompartimentSelectionne().getCompartimentType())) {

            final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
            return contratHeader.getPartsType().containsAll(Sets.set(PartType.PP, PartType.PS));
        }

        return false;
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT.equals(questionType) && contexte.getContratSelectionne() != null && contexte.getContratSelectionne().is(CodeSiloType.ERE);
    }
}
