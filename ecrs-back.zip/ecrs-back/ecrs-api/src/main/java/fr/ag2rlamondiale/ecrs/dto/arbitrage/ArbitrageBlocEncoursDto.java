package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import lombok.Data;

import java.util.Date;
import java.util.List;

@Data
public class ArbitrageBlocEncoursDto {
    private int id;
    private Date encoursDate;
    private boolean encoursEstime;
    private List<ArbitrageEncoursDto> encours;
}
