package fr.ag2rlamondiale.ecrs.api.secure;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_DOCUMENT_VERSEMENT_RECHERCHER;

import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.business.IVersementSyntheseFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.dto.DocumentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.SyntheseVersementDonutDto;
import fr.ag2rlamondiale.ecrs.dto.DetailsOperationDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.EcheancierDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.OperationVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementProgrammeDetailsDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementProgrammeDetailsRequestDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementSyntheseDto;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;

import com.ag2r.common.exceptions.TechnicalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;


@RestController
@RequestMapping(path = "/secure")
public class VersementSyntheseRestController {
    @Autowired
    IVersementSyntheseFacade versementSyntheseFacade;

    @Autowired
    IOperationFacade operationFacade;


    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_START)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/start")
    public VersementSyntheseDto getVersementSynthese() throws TechnicalException {
        return versementSyntheseFacade.getResumeVersement();
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_ECHEANCIERS_GET_DETAILS)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/versement-synthese/versement-details")
    public VersementProgrammeDetailsDto getVersementProgrammeDetails(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) VersementProgrammeDetailsRequestDto dto) throws TechnicalException {
        return versementSyntheseFacade.getVersProgrammeDetails(dto);
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_ECHEANCIERS_GET)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/versements-programmes")
    public List<EcheancierDto> getVersementsProgrammes() throws TechnicalException {
        return versementSyntheseFacade.getVersementsProgrammes();
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_HISTORIQUE_VERSEMENTS_GET)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/versements-historique")
    public List<OperationVersementDto> getHistoriqueVersements() throws TechnicalException {
        return versementSyntheseFacade.getVersementsHistorique();
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_ECHEANCIERS_GET)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/donut")
    public SyntheseVersementDonutDto getSyntheseVersementDonut() throws TechnicalException {
        return versementSyntheseFacade.retrieveSyntheseVersement();
    }


    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_OPERATION_GET)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/versement-details-operation/{idOperation}/{codeSiloType}")
    public DetailsOperationDto getDetailsOperationVersement(@PathVariable("idOperation") String idOperation, @PathVariable("codeSiloType") String codeSiloType) throws TechnicalException {
        return operationFacade.getOperationsDetailsForVersementSynthese(idOperation, codeSiloType);
    }

    /**
     * Recherche du dernier document PRUN ou AC
     *
     * @throws TechnicalException
     */
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/documents-versement")
    @ProfileExecution(codeAction = API_DOCUMENT_VERSEMENT_RECHERCHER)
    public DocumentDto rechercherDocumentsVersement() throws TechnicalException {
        return versementSyntheseFacade.rechercherDocumentsVersement();
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENTSYNTHESE_CONTRATS_GET)
    @LogExecutionTime
    @GetMapping(path = "/versement-synthese/contrats")
    public List<ContratParcoursDto> getContrats() throws TechnicalException {
        return versementSyntheseFacade.getContrats();
    }

}
