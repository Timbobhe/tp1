package fr.ag2rlamondiale.ecrs.dto.simulateur;

import lombok.Data;

@Data
public class TmiDto {
    private int taux;
    private Integer montantMin;
    private Integer montantMax;
}
