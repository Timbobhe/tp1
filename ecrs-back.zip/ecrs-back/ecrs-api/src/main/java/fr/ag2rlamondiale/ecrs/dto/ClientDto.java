package fr.ag2rlamondiale.ecrs.dto;

import lombok.Data;

import java.util.Date;
import java.util.Set;

@Data
public class ClientDto {

    private String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
    private String sousPartenaire;
    private String nom;
    private String prenom;
    private boolean impersonation;
    /**
     * Top Impersonnation
     */
    private String externalUid;

    private boolean filialeACA;

    private boolean hasContratEre;

    private PartenaireDto partenaire;

    private InfosBlocagesClientDto infosBlocagesClient;

    private Set<String> silos;
    private Date dateDeNaissance;
    private String civilite;
    private String nomNaissance;

    private boolean compteDemo;

    private boolean franceConnect;
}
