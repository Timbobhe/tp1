package fr.ag2rlamondiale.ecrs.dto.versement;

public enum ModePlacementVersementType {
    MEME_PLACEMENT_COTISATION_OBLIGATOIRES,
    /**
     * parcours simplifie
     */
    NON_MODIFIABLE_PARCOURS_SIMPLIFIE,

    SELON_DISPOSITIONS_CONTRACTUELLES,

    LIBRE_CHOIX_CLIENT;

}
