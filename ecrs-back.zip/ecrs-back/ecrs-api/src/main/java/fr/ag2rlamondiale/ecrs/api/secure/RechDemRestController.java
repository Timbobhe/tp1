/*
 * Cree le 13 sept. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.api.secure;

import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demande;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Implementation Spring du service REST pour la Recherche Client
 */
@RestController
@RequestMapping(path = "/secure")
public class RechDemRestController {
    @Autowired
    private IWorkflowFacade facade;

	@Autowired
	private UserContextHolder userContextHolder;

    /**
     * Méthode pour récupérer un client et sa liste de demandes
     *
     * @return
     * @throws
     */
    @LogExecutionTime
    @GetMapping(path = "/get/demandes")
    public List<Demande> getADemande() throws WorkflowException {
    	RechDemFront critereParPersonne = new RechDemFront();
    	critereParPersonne.setIdPers(userContextHolder.get().getNumeroPersonneEre());
    	return facade.rechercherDemandes(critereParPersonne).getDemandes();
    }
}
