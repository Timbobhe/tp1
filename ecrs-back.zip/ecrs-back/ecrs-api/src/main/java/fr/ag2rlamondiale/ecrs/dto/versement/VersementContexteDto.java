package fr.ag2rlamondiale.ecrs.dto.versement;

import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Consumer;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class VersementContexteDto implements ISecurityParamAccess {
    private ContratId contratSelectionne;
    private CompartimentId compartimentSelectionne;
    private QuestionType.ResponseVersementModeType reponseModeVersementType;
    private QuestionType.ResponseVersementMoyenPaiementType responseModePaiementType;
//    private GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdpDto;

    private boolean parcoursManuscrit;

    // Ajouter pour le paiement CB
    private BigDecimal montantVersement;
    private List<RepartitionSupportDto> repartitions;
    @Override
    public String secureForNumContrat() {
        return contratSelectionne.getNomContrat();
    }

    @Override
    public String secureForIdentifiantAssure() {
        return compartimentSelectionne != null ? compartimentSelectionne.getIdAssure() : null;
    }

    /**
     * Permet d'identifier dans le Code les mises à jour du Contexte (+ explicit)
     *
     * @param consumer
     */
    public void update(Consumer<VersementContexteDto> consumer) {
        consumer.accept(this);
    }
}
