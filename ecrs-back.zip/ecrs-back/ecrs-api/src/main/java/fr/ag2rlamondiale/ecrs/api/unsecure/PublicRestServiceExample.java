package fr.ag2rlamondiale.ecrs.api.unsecure;

import fr.ag2rlamondiale.ecrs.Version;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * Example of a public rest service(not secured by CAS)
 */
@RestController
@RequestMapping(path = "/public")
public class PublicRestServiceExample {
    @GetMapping(path = "/public_example")
    public Map<String, Object> hello() {
        Map<String, Object> map = new HashMap<>();
        map.put("msg", "hello world v5");
        return map;
    }

}
