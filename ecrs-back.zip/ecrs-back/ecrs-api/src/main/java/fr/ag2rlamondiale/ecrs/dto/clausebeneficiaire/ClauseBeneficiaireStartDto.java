package fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ClauseBeneficiaireStartDto {
    private List<InfoClauseBeneficiaireContratDto> clauseBeneficiaireContrats;
    private boolean sigElecOff;
}
