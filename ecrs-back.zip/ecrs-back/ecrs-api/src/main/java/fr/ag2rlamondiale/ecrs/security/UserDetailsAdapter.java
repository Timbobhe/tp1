package fr.ag2rlamondiale.ecrs.security;

import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.metis.boot.security.dao.UserDetailsImpl;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;

public class UserDetailsAdapter implements IUserDetails {

    private final UserDetailsImpl userDetails;

    public UserDetailsAdapter(UserDetailsImpl userDetails) {
        Objects.requireNonNull(userDetails);
        this.userDetails = userDetails;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return userDetails.getAuthorities();
    }

    @Override
    public String getUserSn() {
        return userDetails.getUserSn();
    }

    @Override
    public String getUserGivenName() {
        return userDetails.getUserGivenName();
    }

    @Override
    public Map<String, Object> getAttributesMap() {
        return userDetails.getAttributesMap();
    }

    @Override
    public String toString() {
        return "UserDetailsAdapter{" +
                "userDetails=" + userDetails +
                ", attributesMap=" + getAttributesMap() +
                '}';
    }
}
