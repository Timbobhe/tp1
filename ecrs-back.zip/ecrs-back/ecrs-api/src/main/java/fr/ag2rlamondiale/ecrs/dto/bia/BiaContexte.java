package fr.ag2rlamondiale.ecrs.dto.bia;

public class BiaContexte {
}
