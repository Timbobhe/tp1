package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.function.Consumer;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class ArretVersementContexteDto implements ISecurityParamAccess {
    private ContratId contratSelectionne;
    private CompartimentId compartimentSelectionne;
    private boolean parcoursManuscrit;

    @Override
    public String secureForNumContrat() {
        return contratSelectionne.getNomContrat();
    }

    @Override
    public String secureForIdentifiantAssure() {
        return compartimentSelectionne != null ? compartimentSelectionne.getIdAssure() : null;
    }

    /**
     * Permet d'identifier dans le Code les mises à jour du Contexte (+ explicit)
     *
     * @param consumer
     */
    public void update(Consumer<ArretVersementContexteDto> consumer) {
        consumer.accept(this);
    }
}
