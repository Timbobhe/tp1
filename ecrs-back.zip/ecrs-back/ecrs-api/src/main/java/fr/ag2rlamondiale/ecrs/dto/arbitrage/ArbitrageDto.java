package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.ecrs.business.domain.sigelec.SupportFinancierDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

@Data
public class ArbitrageDto {
    private ContratId contratId;

    private boolean indicTypeArbitrageAutorise;
    private boolean choixCompartimentAutorise;
    private boolean partObligatoireArbitrable;
    private boolean partFacultatifArbitrable;
    private boolean isPPAndPSPresent;

    private ChoixArbitrage<OptionChoixArbitrageType> choixArbitrageStockOuFlux;
    private ChoixArbitrage<OptionChoixArbitrageType> choixArbitrageCompartiment;
    private ChoixArbitrage<OptionChoixArbitrageType> choixArbitragePartielouTotal;
    private ChoixArbitrage<OptionChoixArbitrageType> choixEuroOuPourcentage;
    private ChoixArbitrage<Compartiment> choixPacteCompartiment;

    private BigDecimal montantTotalEncours;
    private Date dateValeurEncours;
    private String deviseEncours;

    // Represente les encours des Parts Obligatoires et Mixte (PO et PF dans un meme tableau)
    private ArbitrageBlocEncoursDto encoursPO;
    // Represente les encours des Parts Facultatives
    private ArbitrageBlocEncoursDto encoursPF;

    private List<SupportFinancierDto> supportsPO;
    private List<SupportFinancierDto> supportsPF;

    // Liens NIF des supports
    private HashMap<String, String> lienNiF;

    // Page 0
    private Boolean isNoticeInformationSalarieAcceptee;

    /**
     * Le nombre maximum d'arbitrage(s) autorisé(s) par periode est atteint.<br/>
     * Date à partir de laquelle un arbitrage sera possible de nouveau.
     */
    private Date dateArbitragePossible;

    // Flag indiquant si les details de l'arbitrage sont initialisés (supports, liens NIF)
    private boolean hasDetails;
}
