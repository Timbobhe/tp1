package fr.ag2rlamondiale.ecrs.business.impl.arretVersement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.impl.versement.BlocageVersementContratDto;
import fr.ag2rlamondiale.ecrs.business.impl.versement.DictionnaireVersementJahia;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementContexteDto;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementProgrammeDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.utils.VersementUtils;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Service
@Slf4j
public class ArretVersementQuestionResolverChoixCompartiment implements ArretVersementQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    IEcheancierFacade echeancierFacade;

    @Autowired
    RequestContextHolder requestContextHolder;

    @Setter
    @Value("${ere.delai.teletransmission.versement:15}")
    private Integer delaiTeletransmission;

    @Override
    public QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolve(QuestionType questionType, ArretVersementContexteDto contexte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        return resolve(contratHeader, contexte);
    }

    public QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolve(ContratHeader contratHeader, ArretVersementContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = new QuestionResponsesDto<>();

        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_QUESTION_DEDUCTIBILITE_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_DEDUCTIBILITE_MESSAGE_SOUHAIT.name())
                .build());
        result.setData(new BlocageVersementContratDto());

        if (contexte.getCompartimentSelectionne() == null) {
            List<Compartiment> compartiments = contratHeader.getCompartiments().stream()
                    .filter(compart -> compart.is(CompartimentType.C4) || compart.is(CompartimentType.C1))
                    .filter(compart -> handleException(() -> hasVersementProgramme(compart)))
                    .filter(compartiment -> {
                        if (requestContextHolder.getContrat() != null && requestContextHolder.getCompartiment() != null) {
                            return compartiment.getIdentifiantAssure().equals(requestContextHolder.getCompartiment());
                        }
                        return true;
                    })
                    .collect(Collectors.toList());
            if (compartiments.size() == 1) {
                result.setShow(false);
                result.setDefaultValue(buildReponse(compartiments.get(0)));
                contexte.update(ctx -> ctx.setCompartimentSelectionne(compartiments.get(0).getCompartimentId()));
                return result;
            }
            final List<ResponseDto<ChoixCompartimentDto>> propositions = new ArrayList<>();
            compartiments.forEach(compart -> propositions.add(buildReponse(compart)));
            result.setShow(true);
            result.setPropositions(propositions);
            return result;
        }
        result.setShow(false);
        result.setDefaultValue(buildReponse(contratHeader.compartiment(contexte.getCompartimentSelectionne())));
        return result;
    }

    private boolean hasVersementProgramme(Compartiment compartiment) throws TechnicalException {
        return getVersementProgramme(compartiment) != null;
    }

    private ResponseDto<ChoixCompartimentDto> buildReponse(Compartiment compartiment) {
        return ResponseDto.<ChoixCompartimentDto>builder()
                .id(compartiment.getCompartimentId().toString())
                .label(getLabelDeductible(compartiment))
                .value(ChoixCompartimentDto.builder().compartiment(contratParcoursMapper.map(compartiment, true)).build())
                .build();
    }

    private String getLabelDeductible(Compartiment compartiment) {
        if (CompartimentType.C1.equals(compartiment.getType())) {
            return "D\u00E9ductible";
        } else if (CompartimentType.C4.equals(compartiment.getType())) {
            return "Non D\u00E9ductible";
        }
        throw new IllegalArgumentException("Unexpected compartiment: " + compartiment);
    }

    @Override
    public boolean accept(QuestionType questionType, ArretVersementContexteDto contexte) {
        return QuestionType.VERSEMENT_CHOIX_COMPARTIMENT.equals(questionType) && contexte.getContratSelectionne() != null;
    }

    public VersementProgrammeDto getVersementProgramme(Compartiment compartiment) throws TechnicalException {
        Echeancier echeancier = echeancierFacade.getProchainEcheancier(compartiment);
        if (echeancier != null && (echeancier.getDateFin() == null || echeancier.getDateFin().after(new Date()))) {
            return VersementProgrammeDto.builder()
                    .montantActuel(echeancier.getMontant().intValue())
                    .minDateDebutPrelevement(VersementUtils.addDaysToDate(new Date(), delaiTeletransmission))
                    .frequence(FrequenceVirementType.forEcheancier(echeancier))
                    .datePremierVersement(VersementUtils.getPremiereDateVersementPossible(echeancier, delaiTeletransmission))
                    .build();
        }
        return null;
    }
}
