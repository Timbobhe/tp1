package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;

public interface IParcoursSimplifieFacade {
    boolean isParcoursSimplifieActivate(String idContrat, FonctionnaliteType fonctionnaliteType) throws TechnicalException;
}
