package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;

import java.util.Collection;
import java.util.List;

public interface IEvenGenerators {

    AbstractEvenGenerator getEvenGenerator(String codeTypeEvenement);

    /**
     * Generateurs d'EVEN automatique = Mode Popin et en Sequence
     *
     * @param typesEven
     * @param idGdi
     * @param numPersonne
     * @param contrats
     * @param evenementsDejaEnregistres
     * @return
     */
    EvenementJson generateNextEven(List<TypeEvenementJson> typesEven, String idGdi, String numPersonne,
                                   Collection<ContratHeader> contrats, List<EvenementJson> evenementsDejaEnregistres);

}
