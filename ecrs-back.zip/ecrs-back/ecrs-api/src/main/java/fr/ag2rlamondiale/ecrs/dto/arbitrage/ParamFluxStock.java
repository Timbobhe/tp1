package fr.ag2rlamondiale.ecrs.dto.arbitrage;

@SuppressWarnings("squid:S00115")
public enum ParamFluxStock {
    FLUX, STOCK;

    public static ParamFluxStock fromString(String type) {
        if (type == null) {
            return null;
        }
        try {
            return valueOf(type.toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
