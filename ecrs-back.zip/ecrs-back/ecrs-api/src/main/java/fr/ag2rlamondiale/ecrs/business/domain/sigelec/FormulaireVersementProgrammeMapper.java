package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireVersementRegulier;
import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationAffiliationDansSiloType;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import javax.xml.bind.JAXBException;
import java.util.Map;

@Mapper(componentModel = "spring",
        uses = {DateMapper.class, IdentificationContratDansSiloMapper.class,
                IdentificationUserDansSiloMapper.class, IdentificationPersonneDansSiloMapper.class,
                IdentificationDemandeDansSiloMapper.class, InformationsComplementairesMapper.class},
        imports = {StringUtils.class, DateMapper.class})
public abstract class FormulaireVersementProgrammeMapper extends FormulaireVersementMapper implements IFormulaireMapper {

    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today())")
    @Mapping(target = "identificationContratDansSilo", source = "contrat")
    @Mapping(target = "identificationUserDansSilo", source = ".")
    @Mapping(target = "identificationPersonneDansSilo", source = ".")
    @Mapping(target = "identificationDemandeDansSilo", source = ".")
    @Mapping(target = "informationsComplementaires", source = "demande")
    @Mapping(source = "demande", target = "versement", qualifiedByName = "mapVersement")
    @Mapping(source = "demande", target = "repartitionSupportInvestissement", qualifiedByName = "mapRepartitionSupportInvestissement")
    public abstract FormulaireVersementRegulier createFormulaireVersementProgramme(DemandeCreationSigElecVersementProgramme demande);

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireVersementRegulier formVRP = this.createFormulaireVersementProgramme((DemandeCreationSigElecVersementProgramme) demandeSigElec);
        this.afterMapping(formVRP, (DemandeCreationSigElecVersementProgramme) demandeSigElec);
        if (CodeSiloType.ERE.equals(demandeSigElec.getCodeSilo())
                && formVRP.getIdentificationContratDansSilo() != null && formVRP.getIdentificationAffiliationDansSilo() != null) {
            formsMap.put(getCle(
                    formVRP.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    formVRP.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    formVRP.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementProgramme(formVRP));
        } else if (CodeSiloType.MDP.equals(demandeSigElec.getCodeSilo())
                && formVRP.getIdentificationContratDansSilo() != null && formVRP.getIdentificationPersonneDansSilo() != null) {
            formsMap.put(getCle(
                    formVRP.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    CodeSiloType.MDP.getLibelle(),
                    formVRP.getIdentificationPersonneDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementProgramme(formVRP));
        }
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget FormulaireVersementRegulier target, DemandeCreationSigElecVersementProgramme demande) {
        if (CodeSiloType.ERE.equals(demande.getCodeSilo())) {
            IdentificationAffiliationDansSiloType identificationAffiliationDansSiloType = new IdentificationAffiliationDansSiloType();
            identificationAffiliationDansSiloType.setIdentifiantDansSilo(demande.getIdentifiantAssure());
            identificationAffiliationDansSiloType.setLibelleNomSilo(FormulaireConstantes.ERE_PTV2_3);
            identificationAffiliationDansSiloType.setCodeApplication(CodeApplicationType.PTV_ERE.getCode());
            identificationAffiliationDansSiloType.setLibelleApplication(FormulaireConstantes.PTV);
            identificationAffiliationDansSiloType.setCodeSystemeInformation(FormulaireConstantes.ERE);
            identificationAffiliationDansSiloType.setLibelleSystemeInformation(FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER);
            target.setIdentificationAffiliationDansSilo(identificationAffiliationDansSiloType);
        }
    }
}
