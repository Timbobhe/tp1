package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArretVersementFacade;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersement;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecVersementProgramme;
import fr.ag2rlamondiale.ecrs.business.impl.arretVersement.ArretVersementQuestionResolver;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.*;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementProgrammeDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.utils.VersementUtils;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.rest.ISigElecRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentMDProRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.Setter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS;
import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.BLOCAGE_DEM_ARRET_VERSEMENT_INIT;
import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Service
public class ArretVersementFacadeImpl implements IArretVersementFacade, ApplicationContextAware, InitializingBean {

    @Autowired
    IContratFacade contratFacade;

    @Autowired
    ContratParcoursMapper contratParcoursMapper;

    @Autowired
    IEcheancierFacade echeancierFacade;

    @Autowired
    RequestContextHolder requestContext;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private ISigElecFacade sigElecfacade;

    @Autowired
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Autowired
    private IWorkflowFacade demandeWorkflowFacade;

    @Autowired
    private ISigElecRestClient sigElecConsoleService;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Setter
    @Value("${ere.delai.teletransmission.versement:15}")
    private Integer delaiTeletransmission;

    private Collection<ArretVersementQuestionResolver> questionResolvers = new ArrayList<>();

    private ApplicationContext applicationContext;

    @Override
    public ArretVersementStartDto startArretVersement() throws TechnicalException {
        List<ContratHeader> contratHeaders = contratFacade.rechercherContratsComplets().stream()
                .filter(c -> !c.getContratHeader().getAffichageType().isDisabled())
                .filter(c -> !c.getContratHeader().isClasseAutreContrat())
                .filter(c -> c.getContratHeader().hasCompartiments(CompartimentType.C1) || c.getContratHeader().hasCompartiments(CompartimentType.C4))
                .map(BaseContratComplet::getContratHeader).collect(Collectors.toList());

        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
        boolean sigElecOff = false;
        UserContext uc = userContextHolder.get();
        PersonnePhysiqueConsult personnePhysiqueConsult = consulterPersPhysFacade.consulterPersPhys(uc.getIdSilo());
        String paysResidence = personnePhysiqueConsult.getPays();
        String paysResidenceFisc = personnePhysiqueConsult.getPaysResidenceFiscale();
        if (!((paysResidence == null || "FRANCE".equalsIgnoreCase(paysResidence))
                && (paysResidenceFisc == null || "FRANCE".equalsIgnoreCase(paysResidenceFisc)))) {
            sigElecOff = true;
        }
        if (requestContext.getContrat() != null && requestContext.getCompartiment() != null) {
            final String idAssure = requestContext.getCompartiment();
            List<InfoArretVersementContrat> list = contratHeaders.stream()
                    .map(c -> handleException(() -> buildInfoArretVersementContrat(c, idAssure, blocagesClient)))
                    .collect(Collectors.toList());
            if (list.get(0) == null) {
                return null;
            }
            return ArretVersementStartDto.builder().infos(Collections.singletonList(list.get(0))).sigElecOff(sigElecOff)
                    .build();
        }

        return ArretVersementStartDto.builder()
                .infos(contratHeaders.stream().filter(this::hasVersementProgramme)
                        .map(contrat -> handleException(() -> buildInfoArretVersementContrat(contrat)))
                        .collect(Collectors.toList()))
                .sigElecOff(sigElecOff).build();
    }

    private boolean hasVersementProgramme(ContratHeader contratHeader) {
        return contratHeader.getCompartiments().stream()
                .filter(compartiment -> compartiment.is(CompartimentType.C4) || compartiment.is(CompartimentType.C1))
                .anyMatch(compartiment -> handleException(() -> hasVersementProgramme(compartiment)));
    }

    @Override
    public VersementProgrammeDto getVersementProgramme(Compartiment compartiment) throws TechnicalException {
        Echeancier echeancier = echeancierFacade.getProchainEcheancier(compartiment);
        if (echeancier != null && (echeancier.getDateFin() == null || echeancier.getDateFin().after(new Date()))) {
            return VersementProgrammeDto.builder().montantActuel(echeancier.getMontant().intValue())
                    .minDateDebutPrelevement(VersementUtils.addDaysToDate(new Date(), delaiTeletransmission))
                    .frequence(FrequenceVirementType.forEcheancier(echeancier)).datePremierVersement(
                            VersementUtils.getPremiereDateVersementPossible(echeancier, delaiTeletransmission))
                    .build();
        }
        return null;
    }

    @Override
    public <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionArretVersementDto request)
            throws TechnicalException {
        final QuestionType questionType = request.getQuestionType();
        final ArretVersementContexteDto contexte = request.getContexte();
        final ArretVersementQuestionResolver questionResolver = questionResolvers.stream()
                .filter(resolver -> resolver.accept(questionType, contexte)).findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "Impossible de retrouver le Resolver pour " + questionType + " et " + contexte));
        return questionResolver.resolve(questionType, contexte);
    }

    @Override
    public ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionArretVersementDto request)
            throws TechnicalException {
        final List<QuestionType> questionTypeList = request.getQuestionTypeList();

        List<QuestionType> aTraiter = Collections.singletonList(request.getQuestionType());
        if (questionTypeList != null && !questionTypeList.isEmpty()
                && questionTypeList.contains(request.getQuestionType())) {
            aTraiter = questionTypeList.subList(questionTypeList.indexOf(request.getQuestionType()),
                    questionTypeList.size());
        }

        final ListQuestionResponsesDto result = new ListQuestionResponsesDto();
        for (QuestionType questionType : aTraiter) {
            final QuestionResponsesDto<Object, Object> qr = resolveQuestion(
                    request.toBuilder().questionType(questionType).build());
            result.add(qr);
            if (qr.isShow()) {
                result.setQuestionTypeDisplayed(questionType);
                break;
            }
        }

        return result;
    }

    private InfoArretVersementContrat buildInfoArretVersementContrat(ContratHeader contratHeader, String idAssure, InfosBlocagesClient blocagesClient) throws TechnicalException {
        Compartiment compartiment = contratHeader.compartimentEre(idAssure);
        ArretVersementDto arretVersementDto = buildArretVersements(compartiment);
        if (arretVersementDto.getVersementProgramme() != null) {
            return InfoArretVersementContrat.builder()
                    .contrat(contratParcoursMapper.map(contratHeader, true,
                            Arrays.asList(CompartimentType.C1, CompartimentType.C4)))
                    .sigElecOff(blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.SIGELEC_VERSEMENT_PROGRAMME))
                    .arretVersements(Collections.singletonList(arretVersementDto)).build();
        }
        return null;
    }

    private InfoArretVersementContrat buildInfoArretVersementContrat(ContratHeader contratHeader)
            throws TechnicalException {
        String idPers = userContextHolder.get().getNumeroPersonneEre();

        if (contratHeader != null) {
            List<ArretVersementDto> arretVersements = contratHeader.getCompartiments().stream()
                    .filter(compartiment -> handleException(() -> hasVersementProgramme(compartiment)))
                    .map(compartiment -> handleException(() -> buildArretVersements(compartiment)))
                    .collect(Collectors.toList());

            boolean hasDemWorkflowEnCours = demandeWorkflowFacade.hasDemandeEnCoursByContrat(idPers, contratHeader,
                    DemandeWorkflowType.EXTRANET_VERREG);


            SigElecJson demande = hasDemandeArretVersementInitiee(contratHeader);
            String raisonBlocage = null;
            boolean contratBloque = false;

            if (hasDemWorkflowEnCours) {
                contratBloque = true;
                raisonBlocage = BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS.name();
            } else if (demande != null) {
                raisonBlocage = BLOCAGE_DEM_ARRET_VERSEMENT_INIT.name();
            }

            return InfoArretVersementContrat.builder()
                    .contrat(contratParcoursMapper.map(contratHeader, true,Arrays.asList(CompartimentType.C1, CompartimentType.C4)))
                    .bloque(contratBloque).raisonBlocage(MessageDto.builder().jahiaDicoEntry(raisonBlocage).build())
                    .demandeExistante(demande).arretVersements(arretVersements)
                    .build();
        }
        return null;
    }

    private SigElecJson hasDemandeArretVersementInitiee(ContratHeader contratHeader) {
        List<SigElecJson> demandes = sigElecConsoleService.getDmdSigElecParEtats(userContextHolder.get().getIdGdi(),
                contratHeader.getNomContrat(), Arrays.asList(EtatSigELec.INIT), OperationType.VRPG);
        if (demandes != null) {
            Optional<SigElecJson> demandeInitiee = demandes.stream()
                    .filter(d -> d.getMontant().compareTo(BigDecimal.ZERO) < 0).findAny();
            if (demandeInitiee.isPresent()) {
                return demandeInitiee.get();
            }
        }
        return null;
    }

    private ArretVersementDto buildArretVersements(Compartiment compartiment) throws TechnicalException {
        return ArretVersementDto.builder().compartimentSelected(contratParcoursMapper.map(compartiment))
                .versementProgramme(getVersementProgramme(compartiment)).build();
    }

    private boolean hasVersementProgramme(Compartiment compartiment) throws TechnicalException {
        if (CodeSiloType.MDP.equals(compartiment.getCodeSilo())) {
            return false;
        }
        return getVersementProgramme(compartiment) != null;
    }

    @Override
    public String terminate(ArretVersementTerminateDto arretVersementTerminate, boolean isFrame)
            throws TechnicalException, IOException, JAXBException {
        final ContratId contratId = arretVersementTerminate.getContratSelected();
        final CompartimentId compartimentId = arretVersementTerminate.getArretVersementClient().getCompartimentId();
        DocumentDto arretVersementDocument = arretVersementTerminate.getContenuVersement();

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);
        final Compartiment compartiment = contratHeader.compartiment(compartimentId);

        final DocRefType docRefType = contratHeader.isEre() ? DocumentRefType.VERSEMENT_EN_LIGNE
                : DocumentMDProRefType.VERSEMENT_EN_LIGNE_MDPRO;

        DataDocumentContrat documentActeContrat = null;
        if (arretVersementDocument != null && arretVersementDocument.getHtmlContent() != null) {
            documentActeContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, compartimentId,
                    arretVersementDocument, docRefType);
        }

        if (documentActeContrat != null) {
            DemandeCreationSigElecVersement demandeCreationSigElec = initDemandeCreationSigElecArretVersement(
                    arretVersementTerminate, contratHeader, documentActeContrat, compartiment);
            demandeCreationSigElec.setBaseUrl(arretVersementTerminate.getBaseUrl());
            return sigElecfacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec, isFrame);
        } else {
            return null;
        }
    }

    private DemandeCreationSigElecVersement initDemandeCreationSigElecArretVersement(
            ArretVersementTerminateDto arretVersementTerminateDto, ContratHeader contratHeader,
            DataDocumentContrat documentActeContrat, Compartiment compartiment) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        final String numPersonne = contratHeader.getPersonId();
        final ArretVersementClientDto arretVersementClient = arretVersementTerminateDto.getArretVersementClient();

        DemandeCreationSigElecVersement demandeCreationSigElec;
        BigDecimal montant = BigDecimal.ZERO.subtract(arretVersementClient.getMontantVersement());
        demandeCreationSigElec = new DemandeCreationSigElecVersementProgramme();
        demandeCreationSigElec.setTypeOperation(OperationType.VRPG);
        FrequenceVirementType frequence = arretVersementClient.getPeriodiciteVersement();
        ((DemandeCreationSigElecVersementProgramme) demandeCreationSigElec).setFrequenceVersement(frequence);
        BigDecimal montantMensuel = montant.divide(BigDecimal.valueOf(frequence.getMonths()), 2,
                BigDecimal.ROUND_HALF_UP);
        demandeCreationSigElec.setMontant(montantMensuel);
        demandeCreationSigElec.setDateFinVersement(arretVersementClient.getDateFinVersement());

        demandeCreationSigElec.add(documentActeContrat);

        demandeCreationSigElec.setCodeAssureur(contratHeader.getCodeAssureur());

        demandeCreationSigElec.setCodeSilo(contratHeader.getCodeSilo());
        demandeCreationSigElec.setTypeDonneeATraiter();
        demandeCreationSigElec.setCompartimentType(compartiment.getType());

        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setAgrementsConventionDePreuve(documentActeContrat.getAgrementsConventionDePreuve());
        demandeCreationSigElec.setConventionDePreuveTitre(documentActeContrat.getConventionDePreuveTitre());

        demandeCreationSigElec.setIdentifiantAssure(documentActeContrat.getIdAssure());
        demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
        demandeCreationSigElec.setNumPP(numPersonne);
        demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo()));

        demandeCreationSigElec.setDateDebutVersement(arretVersementClient.getDateVersement());
        return demandeCreationSigElec;
    }

    @Override
    public void setApplicationContext(@Nonnull ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Override
    public void afterPropertiesSet() {
        final Map<String, ArretVersementQuestionResolver> beansOfType = this.applicationContext
                .getBeansOfType(ArretVersementQuestionResolver.class);
        this.questionResolvers = beansOfType.values();
    }
}
