package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICommunicationClientFacade;
import fr.ag2rlamondiale.ecrs.business.IConfirmationEmailFacade;
import fr.ag2rlamondiale.trm.client.soap.ICommunicationClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.creerdemcom.CreerDemComDto;
import fr.ag2rlamondiale.trm.domain.creerdemcom.DocumentJoint;
import fr.ag2rlamondiale.trm.domain.creerdemcom.ObjetMailType;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.trm.pdf.PDFUtils;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import fr.ag2rlamondiale.trm.business.IBaseCommunicationClientFacade;
import fr.ag2rlamondiale.trm.business.impl.BaseCommunicationClientFacadeImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Service
@Slf4j
@Primary
@AppImpl(implemtationOf = IBaseCommunicationClientFacade.class)
public class CommunicationClientFacadeImpl extends BaseCommunicationClientFacadeImpl implements ICommunicationClientFacade {

    private static final String CONFIRMATION_EMAIL_PATH = "validationEmail";
    private static final String ERROR_MSG_MAIL = "Une erreur est survenue lors de l'envoi du mail de confirmation des données personnelles";


    @Value("${ere.emailconf.activate}")
    private String isEmailConfActivated;

    @Value("${ere.esigate.url}")
    private String inscriptionProperty;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ICommunicationClient communicationClient;

    @Autowired
    private IConfirmationEmailFacade confEmailFacade;

    @Autowired
    private PDFUtils pdfUtils;

    @Override
    public boolean creerMailNotificationContact(List<String> adresseDestinataire, String filiale) throws TechnicalException {
        return creerMailNotification(adresseDestinataire, filiale, ObjetMailType.NOTIF_FORMULAIRE_CONTACT);
    }

    @Override
    public boolean creerMailNotificationModifDonneesPerso(List<String> adresseDestinataire, String filiale) throws TechnicalException {
        return creerMailNotification(adresseDestinataire, filiale, ObjetMailType.NOTIF_MODIFICATION_DONNEES_PERSO);
    }

    public boolean creerMailNotificationModifDonneesPersoWithActivation(String newEmail, String idPers, String filiale,
                                                                        CodeSiloType codeSilo) throws TechnicalException {

        // envoyer lien d'activation à la nouvelle adresse email
        CreerDemComDto dto = CreerDemComDto.builder().nom(userContextHolder.get().getNom())
                .prenom(userContextHolder.get().getPrenom()).civilite(userContextHolder.get().getCivilite())
                .filiale(filiale).adressesMailDestinataires(Arrays.asList(newEmail))
                .objetMailType(ObjetMailType.NOTIF_MODIFICATION_DONNEES_PERSO)
                .urlConfirmation(
                        buildUrlConfirmation(newEmail, confEmailFacade.createConfirmation(newEmail, idPers, codeSilo)))
                .metaInterne(idPers).build();
        return creerDemandeCommunication(dto);
    }

    private String buildUrlConfirmation(String email, String token) {
        return UriComponentsBuilder.fromHttpUrl(inscriptionProperty).path(CONFIRMATION_EMAIL_PATH)
                .queryParam("email", email).queryParam("token", token).toUriString();
    }

    @Override
    public boolean sendConfirmationEmail(String oldEmail, String newEmail, String idPers, String filiale,
                                         CodeSiloType codeSilo) throws TechnicalException {

        if (isNotBlank(newEmail) && !newEmail.equalsIgnoreCase(oldEmail)) {
            boolean isNotifEmailDone;
            // nouvelle adresse email
            if (Boolean.parseBoolean(isEmailConfActivated)) {
                isNotifEmailDone = creerMailNotificationModifDonneesPersoWithActivation(newEmail, idPers, filiale,
                        codeSilo);
            } else {
                isNotifEmailDone = creerMailNotificationModifDonneesPerso(Collections.singletonList(newEmail), filiale);
            }
            if (!isNotifEmailDone) {
                log.warn(ERROR_MSG_MAIL);
            }
        }

        // notifier l'ancienne adresse email
        if (isNotBlank(oldEmail)) {
            return creerMailNotificationModifDonneesPerso(Collections.singletonList(oldEmail), filiale);
        }
        return true;
    }

    @Override
    public boolean creerDemandeEmailContactAkio(ContactReclamationDto contactReclamationDto) throws TechnicalException {
        CreerDemComDto dto = CreerDemComDto.builder()
                .nom(userContextHolder.get().getNom())
                .prenom(userContextHolder.get().getPrenom())
                .civilite(userContextHolder.get().getCivilite())
                .objetMailType(contactReclamationDto.isReclamation() ? ObjetMailType.RECLAMATION_AKIO : ObjetMailType.CONTACT_AKIO)
                .adresseMailExpediteur(contactReclamationDto.getEmail())
                .telephone(contactReclamationDto.getTelephone())
                .numClient(contactReclamationDto.getIdPersonne())
                .numContrat(contactReclamationDto.getIdContrat())
                .themeMessage(contactReclamationDto.getCodeQuestion())
                .message(contactReclamationDto.getMessage())
                .listeDocuments(buildListeDocument(contactReclamationDto.getFichiersJoint()))
                .build();
        return creerDemandeCommunication(dto);
    }

    private List<DocumentJoint> buildListeDocument(List<UploadFileDto> fichiersJoint) {
        if (CollectionUtils.isEmpty(fichiersJoint)) {
            return new ArrayList<>();
        }

        final List<DocumentJoint> list = new ArrayList<>();
        for (UploadFileDto fichierJoint : fichiersJoint) {
            final String nomDoc = FilenameUtils.removeExtension(fichierJoint.getFileName()) + ".pdf";

            DocumentJoint build = DocumentJoint.builder()
                    .nomDoc(nomDoc)
                    .typeDoc("application/pdf")
                    .contenuDoc(pdfUtils.convertPdfContent(fichierJoint.getFileContent()))
                    .build();
            list.add(build);
        }
        return list;

    }
}
