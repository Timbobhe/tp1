package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.evenement.TypologieAffichageEven;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.*;

@RestController
@RequestMapping(path = "/secure")
public class EvenementRestController {
    @Autowired
    private IEvenementFacade evenementFacade;

    @ProfileExecution(codeAction = API_EVENEMENTS_NEXT)
    @LogExecutionTime
    @GetMapping(path = "/evenements/next")
    public EvenementJson getNextEven(@RequestParam(name = "typologie", required = false) TypologieAffichageEven typologieEven) throws TechnicalException {
        if (typologieEven == null) { // pour la compatibilité Front/Back
            typologieEven = TypologieAffichageEven.POPIN;
        }

        return evenementFacade.generateNextEvenement(typologieEven.toPredicate(), false, true);
    }

    @ProfileExecution(codeAction = API_EVENEMENTS_UPDATE)
    @LogExecutionTime
    @PostMapping(path = "/evenements/update")
    @Secure
    public EvenementJson update(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) EvenementJson evenementJson) {
        return evenementFacade.updateEvenement(evenementJson);
    }

    @ProfileExecution(codeAction = API_EVENEMENTS_CANCEL)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/evenements/cancel")
    public EvenementJson cancel(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) EvenementJson evenementJson) {
        evenementJson.setDateFin(new Date());
        evenementJson.setEtatTraitement(EtatTraitementType.ANNU);
        return evenementFacade.updateEvenement(evenementJson);
    }

    @ProfileExecution(codeAction = API_EVENEMENTS_TERMINATE)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/evenements/terminate")
    public EvenementJson terminate(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) EvenementJson evenementJson) {
        evenementJson.setDateFin(new Date());
        evenementJson.setEtatTraitement(EtatTraitementType.TRAI);
        return evenementFacade.updateEvenement(evenementJson);
    }
}
