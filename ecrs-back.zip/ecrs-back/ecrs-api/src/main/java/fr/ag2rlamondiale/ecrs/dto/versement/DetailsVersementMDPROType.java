package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import static fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper.FISCALITE_MADELIN;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum DetailsVersementMDPROType {
    DEFAUT("", 300, 999999),
    MADELIN(FISCALITE_MADELIN, 300, 999999),
    PERP("PERP", 300, 999999),
    ART83("ART 83", 300, 999999);

    private String fiscalite;
    private int minMontantPossible;
    private int maxMontantPossible;

    public static DetailsVersementMDPROType getDetailFromFiscalite(String fiscalite) {
        for (DetailsVersementMDPROType detailVersement : values()) {
            if (detailVersement.getFiscalite().equals(fiscalite)) {
                return detailVersement;
            }
        }
        return DEFAUT;
    }

    public boolean isFiscalite(String fiscalite) {
        return this.fiscalite.equals(fiscalite);
    }
}
