package fr.ag2rlamondiale.ecrs.api.unsecure;

import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseInternalDto;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserResponseInternalMapper;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/public/identity-provider")
public class UserIdentityProviderRestController {

    @Autowired
    private IUserIdentityProviderFacade userIdentityProviderFacade;

    @Autowired
    private UserResponseInternalMapper mapper;


    @ProfileExecution(codeAction = CodeActionType.API_EXT_CAS_IDPRO_TOEXTERNAL_USER)
    @PostMapping("/to-external-user")
    public UserResponseExternalDto userIdentityExternal(@RequestBody UserRequestDto userRequest) {
        return userIdentityProviderFacade.identiteExterne(userRequest);
    }

    @ProfileExecution(codeAction = CodeActionType.API_EXT_CAS_IDPRO_FDI_TOINTERNAL_USER)
    @PostMapping("/to-internal-user-from-federation")
    public UserResponseInternalDto userIdentityInternal(@RequestBody UserRequestDto userRequest) {
        final UserResponseInternal in = userIdentityProviderFacade.identiteInterneDepuisFederation(userRequest, UserRequestOptionsDto.builder()
                .createHabili(true)
                .build());
        return mapper.map(in);
    }

}
