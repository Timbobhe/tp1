package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseDto;

public interface ICaptchaFacade {
	VerificationCaptchaResponseDto verifyToken(String token);
}
