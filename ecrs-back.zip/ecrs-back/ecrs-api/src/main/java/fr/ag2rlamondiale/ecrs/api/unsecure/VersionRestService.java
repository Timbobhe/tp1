package fr.ag2rlamondiale.ecrs.api.unsecure;

import fr.ag2rlamondiale.ecrs.Version;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import static fr.ag2rlamondiale.ecrs.Version.UNKNOWN_VERSION;

@Slf4j
@RestController
@RequestMapping(path = "/public")
public class VersionRestService implements InitializingBean {

    private Map<String, String> versions;

    @GetMapping(path = "/version")
    public String version() {
        return versions != null ? versions.toString() : UNKNOWN_VERSION;
    }


    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            versions = new HashMap<>();
            versions.put("ecrs", Version.getVersion());
            versions.put("trm", Version.getTrmVersion());
            log.info("Versions : {}", versions);
        } catch (Exception e) {
            log.error("Erreur pour recuperer la version", e);
        }
    }
}
