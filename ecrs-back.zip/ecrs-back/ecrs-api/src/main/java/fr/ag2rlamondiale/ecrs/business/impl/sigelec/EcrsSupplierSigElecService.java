package fr.ag2rlamondiale.ecrs.business.impl.sigelec;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.business.ISupplierSigElecService;
import fr.ag2rlamondiale.trm.csv.CodesAssureurMapper;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.exception.UnknownEnumerationValueException;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
@AppImpl(implemtationOf = ISupplierSigElecService.class)
public class EcrsSupplierSigElecService implements ISupplierSigElecService {

    @Autowired
    private CodesAssureurMapper codesAssureurMapper;

    @Autowired
    private ISupplierLibService supplierLibService;

    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public <C extends IContrat> String getProfile(DemandeCreationSigElec<C> demandeCreationSigElec) {
        if (demandeCreationSigElec.getCodeAssureur() == null) {
            return null;
        }
        return codesAssureurMapper.getCodesAssureurs(demandeCreationSigElec.getCodeAssureur()).getProfileSignatureElectronique();
    }

    @Override
    public String getUrlRetour(OperationType typeOpe, String status, boolean isFrame, String numContrat, String baseUrl) {
        if (isFrame) {
            Partenaire partenaire = userContextHolder.get().getPartenaire();
            if (partenaire != null && Partenaire.CODE_NIE.equals(partenaire.getCodePartenaire())
                    && partenaire.getBaseUrl() != null) {
                return buildFrameCallbackUrl(partenaire.getBaseUrl(), typeOpe, status, numContrat);
            }
        }
        return this.supplierLibService.getUrlFront() + getUrl(typeOpe, status, baseUrl);
    }

    public static String buildFrameCallbackUrl(String baseUrl, OperationType typeOpe,
                                               String status, String numContrat) {
        StringBuilder url = new StringBuilder(baseUrl);
        url.append("/def_int_ep/ep/aca/gestion_signature.do?contrat=");
        url.append(numContrat);
        url.append("&parcours=");
        switch (typeOpe) {
            case ARBI:
                url.append("arbitrage");
                break;

            case EBIA:
                url.append("bia");
                break;

            case CBF:
                url.append("clause_benef");
                break;

            default:
                throw new UnknownEnumerationValueException(OperationType.class,
                        "[SigElec] Type operation inconnu");
        }
        return url.append("&action=").append(inferActionFromStatus(status)).toString();
    }

    public static String inferActionFromStatus(String status) {
        switch (status) {
            case ANNULATION:
                return "annulation";

            case ECHEC:
                return "echec";

            case SUCCES:
                return "succes";
            default:
                return null;
        }
    }

    public static String getUrl(OperationType operationType, String status, String baseUrlOverride) {
        String baseUrl = null;
        if (baseUrlOverride != null) {
            baseUrl = "/#/" + baseUrlOverride;
        } else {
            switch (operationType) {
                case ARBI:
                    baseUrl = "/#/modification-gestion-financiere";
                    break;
                case VR:
                case VRLI:
                case VRPG:
                    baseUrl = "/#/versement";
                    break;
                case CBF:
                    baseUrl = "/#/clause-beneficiaire";
                    break;
                case RIBA:
                    baseUrl = "/#/coordonnees-bancaires";
                    break;
                case EBIA:
                    baseUrl = "/#/bulletin-affiliation";
                    break;
                case LIQR:
                    baseUrl = "/#/liquidation";
                    break;
            }
        }

        return baseUrl + "/signature/" + status;
    }

    @Override
    public String getCodeApplicationEmettrice() {
        return supplierLibService.getCodeCassiniAppli();
    }
}
