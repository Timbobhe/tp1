package fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire;

import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.ecrs.dto.bia.ClauseBeneficiaireDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import lombok.Data;

@Data
public class ClauseBeneficiaireTerminateDto implements ISecurityParamAccess {
    private ContratId contratSelected;
    private ClauseBeneficiaireDto clauseBeneficiaire;
    private DocumentDto contenuClauseBeneficiaire;

    @Override
    public String secureForNumContrat() {
        return this.contratSelected.getNomContrat();
    }
}
