package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.formulaire.formulaireversementlibre.IdentificationDansSiloType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", imports = {CodeApplicationType.class})
public abstract class IdentificationUserDansSiloMdproMapper {

    @Named("mapIdentificationUserDansSilo")
    @Mapping(target = "identifiantDansSilo", source = "idGdi")
    @Mapping(target = "libelleNomSilo", source = "contrat.codeSilo.libelle")
    @Mapping(target = "codeApplication", expression = "java(CodeApplicationType.ECRS.getCode())")
    @Mapping(target = "libelleApplication", constant = FormulaireConstantes.ESPACE_CLIENT_PARTICULIER_ERE)
    @Mapping(target = "codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)
    public abstract IdentificationDansSiloType mapToIdentificationUserDansSilo(DemandeCreationSigElec demande);
}
