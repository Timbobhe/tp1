package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IClausesBenefCtrFacade;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireStartDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireTerminateDto;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@RestController
@RequestMapping(path = "/secure")
public class ClauseBeneficiaireRestController {

    @Autowired
    private IClausesBenefCtrFacade clausesBenefCtrFacade;

    @ProfileExecution(codeAction = CodeActionType.API_CLAUSE_BENEFICIAIRE_START)
    @LogExecutionTime
    @GetMapping(path = "/clause-beneficiaire/start")
    public ClauseBeneficiaireStartDto start() throws TechnicalException {
        return clausesBenefCtrFacade.startModificationClauseBeneficiaire();
    }

    @PostMapping(path = "/clause-beneficiaire/terminate")
    @Secure
    public String terminate(
            @RequestBody @SecuredParam(
                    paramType = SecurityParamType.CONTRAT) ClauseBeneficiaireTerminateDto dto,
            @RequestParam boolean frame) throws IOException, JAXBException, CommonException {
        return clausesBenefCtrFacade.terminateModificationClauseBeneficiaire(dto, frame);
    }
}
