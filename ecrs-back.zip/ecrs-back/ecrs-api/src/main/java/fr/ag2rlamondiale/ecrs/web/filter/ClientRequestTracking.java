package fr.ag2rlamondiale.ecrs.web.filter;

import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.trm.security.AuthentificationUtils;
import org.slf4j.MDC;
import org.springframework.core.Ordered;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Random;

import static fr.ag2rlamondiale.ecrs.web.EcrsWebConstants.ORDER_FILTER_REQUEST_ID;

public class ClientRequestTracking implements Filter, Ordered {

    public static final String REQUEST_ID = "fr.ag2rlamondiale.idReq";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        String requeteId = getRequeteId(request);
        MDC.put(FrmkLogKeys.IDENTIFIANT_REQUETE, requeteId);


        request.setAttribute(REQUEST_ID, requeteId);
        filterChain.doFilter(request, response);
    }

    private static String getRequeteId(HttpServletRequest request) {
        String requeteId = request.getHeader("X-ID-REQ");
        if (requeteId == null) {
            requeteId = generateRequestId();
        }
        return requeteId;
    }

    private static String generateRequestId() {
        Random randnumber = new Random();
        int number = randnumber.nextInt(100000) + 1000000;
        return 'C' + Integer.toString(number);
    }


    @Override
    public int getOrder() {
        return ORDER_FILTER_REQUEST_ID;
    }
}

