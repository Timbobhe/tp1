package fr.ag2rlamondiale.ecrs.business.impl;

import static com.google.common.base.Preconditions.checkNotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.ecrs.business.IConfirmationEmailFacade;
import fr.ag2rlamondiale.trm.client.rest.IConfirmationEmailRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.emailconf.ConfirmationEmailJson;
import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import fr.ag2rlamondiale.trm.utils.SecurityUtils;

@Service
public class ConfirmationEmailFacadeImpl implements IConfirmationEmailFacade {

	@Autowired
	private IConfirmationEmailRestClient confEmailClient;

	@Override
	public String createConfirmation(String email, String numPers, CodeSiloType coSilo) {
		checkNotNull(email);
		checkNotNull(numPers);
		checkNotNull(coSilo);
		ConfirmationEmailJson confirmation = new ConfirmationEmailJson();
		confirmation.setCodeSilo(coSilo);
		confirmation.setCodeApplication(getCodeApplication());
		confirmation.setNumeroPersonne(numPers);
		confirmation.setEmail(email);
		String token = generateToken();
		confirmation.setToken(SecurityUtils.sha512(token));
		confirmation = confEmailClient.createConfirmation(confirmation);
		return confirmation != null ? token : null;
	}

	private AccesApp getCodeApplication() {
		return AccesApp.valueOf(CodeApplicationType.AQEA.getCode());
	}

	private static String generateToken() {
		return SecurityUtils.randomUuid();
	}
}
