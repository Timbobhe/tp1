package fr.ag2rlamondiale.ecrs.dto.onboarding;

import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.Data;

import java.util.List;

@Data
public class OnboardingTerminateDto implements ISecurityParamAccess {

    EvenementJson evenement;

    List<Integer> idSujets;

    @Override
    public String secureForNumContrat() {
        return evenement != null ? evenement.secureForNumContrat() : null;
    }
}
