package fr.ag2rlamondiale.ecrs.security;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.business.ISyntheseCompartimentFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;

import java.util.List;

import static fr.ag2rlamondiale.trm.utils.Times.timeSpent;

@Slf4j
@Component
public class PreCache {

    @Autowired
    private AsyncTaskExecutor asyncTaskExecutor;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ISyntheseCompartimentFacade compartimentFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;


    void start(Runnable onTerminate) {
        final UserContext userContext = userContextHolder.get();
        log.info("Start pre-cache pour {}", userContext);

        asyncTaskExecutor.submit(() -> timeSpent(() -> {
                    try {
                        log.info("pre-cache start consulterStructInv pour {}", userContext);
                        final List<ContratHeader> contratHeaders = contratFacade.rechercherContrats();
                        for (ContratHeader contrat : contratHeaders) {
                            try {
                                structureInvFacade.consulterStructInv(contrat);
                            } catch (TechnicalException e) {
                                log.error("pre-cache : Erreur consulterStructInv({})", contrat.getId(), e);
                            }
                        }
                        return null;
                    } finally {
                        if (onTerminate != null) {
                            onTerminate.run();
                        }
                    }
                },
                duree -> log.info("pre-cache consulterStructInv termin\u00e9 en {} ms - {}", duree, userContext))
        );

        asyncTaskExecutor.submit(() -> timeSpent(() -> {
                    try {
                        log.info("pre-cache start rechercherCompartiments pour {}", userContext);
                        return compartimentFacade.calculerSyntheseCompartiments();
                    } finally {
                        if (onTerminate != null) {
                            onTerminate.run();
                        }
                    }
                },
                duree -> log.info("pre-cache rechercherCompartiments termin\u00e9 en {} ms - {}", duree, userContext))
        );
    }

}
