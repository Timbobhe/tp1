package fr.ag2rlamondiale.ecrs.business.even;

import static fr.ag2rlamondiale.trm.domain.CodeApplicationType.EGESPER_ERE;

import java.util.Collection;
import java.util.List;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public abstract class ErePNDEvenGenerator extends AbstractEvenWithoutContratGenerator {
    @Override
    protected boolean evaluerEvenement(String numPersonne) {
        try {
            PersonnePhysiqueConsult pp =
                    consulterPersonneClient.consulterPersPhys(IdSiloDto.forAppli(numPersonne, EGESPER_ERE));
            return retour(pp, numPersonne);
        } catch (Exception e) {
            log.error("Erreur pendant l'evaluation de l'evenement {}", getTypePND(), e);
            return false;
        }
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
            Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {
        if (!isEre()) {
            return;
        }
        super.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, results);
    }

    protected abstract String getTypePND();

    public abstract boolean retour(PersonnePhysiqueConsult pp, String idPers) throws WorkflowException;
}
