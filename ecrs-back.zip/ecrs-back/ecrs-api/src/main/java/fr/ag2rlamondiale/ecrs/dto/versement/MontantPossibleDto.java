package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MontantPossibleDto {
    private int minMontantPossible;
    private int maxMontantPossible;
}
