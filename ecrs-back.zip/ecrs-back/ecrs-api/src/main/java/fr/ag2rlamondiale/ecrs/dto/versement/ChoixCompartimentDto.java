package fr.ag2rlamondiale.ecrs.dto.versement;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChoixCompartimentDto {
    private ContratParcoursDto compartiment;
    private ModePlacementVersementType modePlacementVersement;
}
