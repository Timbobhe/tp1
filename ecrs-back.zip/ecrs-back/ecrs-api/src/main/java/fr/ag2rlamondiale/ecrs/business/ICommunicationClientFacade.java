package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.creerdemcom.DocumentJoint;
import fr.ag2rlamondiale.trm.business.IBaseCommunicationClientFacade;

import java.util.List;

public interface ICommunicationClientFacade extends IBaseCommunicationClientFacade {
    boolean creerMailNotificationContact(List<String> adresseDestinataire, String filiale) throws TechnicalException;

    boolean creerMailNotificationModifDonneesPerso(List<String> adresseDestinataire, String filiale) throws TechnicalException;

    boolean creerMailNotificationModifRIB(List<String> adresseDestinataire, String filiale) throws TechnicalException;

    boolean creerDemandeEmailContactAkio(ContactReclamationDto contactReclamationDto) throws TechnicalException;

    boolean creerDemandeMailGestionMDPRO(String objetMail, List<DocumentJoint> piecesJointes) throws TechnicalException;

    boolean sendConfirmationEmail(String oldEmail, String newEmail, String idPers, String filiale, CodeSiloType codeSilo) throws TechnicalException;

}
