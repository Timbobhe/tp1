package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ISujetFacade;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.*;

@RestController
@RequestMapping(path = "/secure")
public class SujetRestController {
    @Autowired
    private ISujetFacade sujetFacade;

    @ProfileExecution(codeAction = API_SUJETS_GET)
    @LogExecutionTime
    @GetMapping(path = "/sujets")
    public List<SujetDto> getSujets() {
        return sujetFacade.getSujets();
    }

    @ProfileExecution(codeAction = API_SUJETS_UTILISATEUR_GET)
    @LogExecutionTime
    @GetMapping(path = "/sujets-utilisateur")
    public Collection<LectureSujetDto> getSujetsSelectionnesParUtilisateur() throws TechnicalException {
        return sujetFacade.getSujetsSelectionnesParUtilisateur();
    }

    @ProfileExecution(codeAction = API_OBJECTIFS_UTILISATEUR_GET)
    @LogExecutionTime
    @GetMapping(path = "/objectifs-utilisateur")
    public Collection<LectureSujetDto> getObjectifsParUtilisateur() throws TechnicalException {
        return sujetFacade.getObjectifsParUtilisateur();
    }

    @ProfileExecution(codeAction = API_SUJETS_UTILISATEUR_CREATE)
    @LogExecutionTime
    @PostMapping(path = "/sujets-utilisateur/create")
    public Collection<LectureSujetDto> createSujetParUtilisateur(@RequestBody List<Integer> idSujets) throws TechnicalException {
        return sujetFacade.createSujetParUtilisateur(idSujets);
    }

    @ProfileExecution(codeAction = API_SUJETS_UTILISATEUR_UPDATE)
    @LogExecutionTime
    @PostMapping(path = "/sujets-utilisateur/update")
    public LectureSujetDto updateSujetLuParUtilisateur(@RequestBody Integer idSujet) {
        return sujetFacade.updateSujetLuParUtilisateur(idSujet);
    }
}
