package fr.ag2rlamondiale.ecrs.dto.tracking;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class EquipementRetraiteSuppDto {
    @JsonProperty("type_de_contrat")
    private String typeContrat;

    private String assureur;

    private String appellation;
}
