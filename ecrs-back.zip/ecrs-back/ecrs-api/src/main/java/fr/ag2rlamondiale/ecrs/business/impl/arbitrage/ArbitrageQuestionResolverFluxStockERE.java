package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.stream.Stream;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_SOUHAIT_ARBITRER;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_QUESTION_FLUXSTOCK_TITRE;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_WARNING_MESSAGE_EPARGNE_ACQUISE_IMPOSSIBLE_MONTANT_NUL;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK;

@Service
public class ArbitrageQuestionResolverFluxStockERE implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Override
    public QuestionResponsesDto<ResponseArbitrageFluxStockType, ?> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contexte.getContratSelectionne());
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();
        final CompartimentId compartimentId = contexte.getCompartimentSelectionne();
        final ContratHeader contratHeader = contratComplet.getContratHeader();

        final QuestionResponsesDto<ResponseArbitrageFluxStockType, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK)
                .jahiaDicoEntry(ARB_QUESTION_FLUXSTOCK_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_SOUHAIT_ARBITRER.name())
                .build());

        // Certains contrats ne permettent de ne procéder qu’à un arbitrage mixte.
        // Ceux-ci sont identifiés dans les contraintes d’arbitrages de PTV par la coche « Arbitrage autorisé sur flux ou sur stock ou sur flux et stock ».
        if (!contratGeneral.getOptContratEpargne().isIndicTypeArbitrageAutorise()) {
            result.setShow(false);
            result.setDefaultValue(reponse(contexte, contratHeader, ARBITRAGE_FLUXSTOCK));
            contexte.update(ctx -> ctx.setResponseFluxStockType(ARBITRAGE_FLUXSTOCK));
            return result;
        }

        // Stock selon l'encours
        final Encours encours;
        if (contexte.isTousCompartimentsSelectionnes()) {
            encours = contratComplet.getEncoursTotal();
        } else {
            encours = contratComplet.encours(compartimentId).getValue();
        }

        if (ParamFluxStock.FLUX == contexte.getParamFluxStock()) {
            result.setShow(false);
            result.setDefaultValue(reponse(contexte, contratHeader, ARBITRAGE_FLUX));
            contexte.update(ctx -> ctx.setResponseFluxStockType(ARBITRAGE_FLUX));
            return result;

        } else if (ParamFluxStock.STOCK == contexte.getParamFluxStock() && !encours.estVide()) {
            result.setShow(false);
            result.setDefaultValue(reponse(contexte, contratHeader, ARBITRAGE_STOCK));
            contexte.update(ctx -> ctx.setResponseFluxStockType(ARBITRAGE_STOCK));
            return result;

        } else if (ParamFluxStock.STOCK == contexte.getParamFluxStock() && encours.estVide()) {
            result.setWarningMessage(MessageDto.builder()
                    .jahiaDicoEntry(ARB_WARNING_MESSAGE_EPARGNE_ACQUISE_IMPOSSIBLE_MONTANT_NUL.name())
                    .build());
            return result;
        }

        // Flux toujours autorisé
        result.add(reponse(contexte, contratHeader, ARBITRAGE_FLUX));

        if (encours.estVide()) {
            Stream.of(ARBITRAGE_STOCK, ARBITRAGE_FLUXSTOCK)
                    .map(e -> ResponseDto.<ResponseArbitrageFluxStockType>builder()
                            .value(e)
                            .disabled(true)
                            .build())
                    .map(response -> this.setLabel(response, contexte, contratHeader))
                    .map(response -> this.setWarningMessage(response, contexte, contratHeader))
                    .forEach(result::add);
        } else {
            Stream.of(ARBITRAGE_STOCK, ARBITRAGE_FLUXSTOCK)
                    .map(e -> reponse(contexte, contratHeader, e)).forEach(result::add);
        }

        return result;
    }

    public ResponseDto<ResponseArbitrageFluxStockType> reponse(ArbitrageContexteDto contexte, ContratHeader contratHeader, ResponseArbitrageFluxStockType arbitrageFlux) {
        final ResponseDto<ResponseArbitrageFluxStockType> response = ResponseDto.<ResponseArbitrageFluxStockType>builder()
                .id(arbitrageFlux.name())
                .value(arbitrageFlux)
                .build();

        return setLabel(response, contexte, contratHeader);
    }

    @SuppressWarnings("squid:S1301")
    private ResponseDto<ResponseArbitrageFluxStockType> setWarningMessage(ResponseDto<ResponseArbitrageFluxStockType> response, ArbitrageContexteDto contexte, ContratHeader contratHeader) {
        final ResponseArbitrageFluxStockType type = response.getValue();

        if (contratHeader.isPacte()) {
            if (contexte.isTousCompartimentsSelectionnes()) {
                switch (type) {
                    case ARBITRAGE_STOCK:
                    case ARBITRAGE_FLUXSTOCK:
                        response.setWarningMessage(MessageDto.builder()
                                .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MESSAGE_STOCK_ZERO_PACTE.name())
                                .build());
                        return response;
                    default:
                        throw new IllegalArgumentException(type.name());
                }
            } else if (CompartimentType.C3.equals(contexte.getCompartimentSelectionne().getCompartimentType())) {
                switch (type) {
                    case ARBITRAGE_STOCK:
                    case ARBITRAGE_FLUXSTOCK:
                        response.setWarningMessage(MessageDto.builder()
                                .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MESSAGE_STOCK_ZERO_PACTE_C3.name())
                                .build());
                        return response;
                    default:
                        throw new IllegalArgumentException(type.name());
                }
            }

            // C1, C2, C4
            switch (type) {
                case ARBITRAGE_STOCK:
                case ARBITRAGE_FLUXSTOCK:
                    response.setWarningMessage(MessageDto.builder()
                            .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MESSAGE_STOCK_ZERO_PACTE_C1.name())
                            .build());
                    return response;
                default:
                    throw new IllegalArgumentException(type.name());
            }
        }

        // Non pacte
        switch (type) {
            case ARBITRAGE_STOCK:
            case ARBITRAGE_FLUXSTOCK:
                response.setWarningMessage(MessageDto.builder()
                        .jahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MESSAGE_STOCK_ZERO_NON_PACTE.name())
                        .build());
                return response;
            default:
                throw new IllegalArgumentException(type.name());
        }
    }

    private ResponseDto<ResponseArbitrageFluxStockType> setLabel(ResponseDto<ResponseArbitrageFluxStockType> response, ArbitrageContexteDto contexte, ContratHeader contratHeader) {
        final ResponseArbitrageFluxStockType type = response.getValue();
        if (contratHeader.isPacte()) {
            if (contexte.isTousCompartimentsSelectionnes()) {
                return jahiaDicoEntrySetter(response,type,contexte);
            } else if (CompartimentType.C3.equals(contexte.getCompartimentSelectionne().getCompartimentType())) {
                switch (type) {
                    case ARBITRAGE_FLUX:
                        response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_PACTE_C3.name());
                        return response;
                    case ARBITRAGE_STOCK:
                        response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_STOCK.name());
                        return response;
                    case ARBITRAGE_FLUXSTOCK:
                        response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_STOCK_PACTE_C3.name());
                        return response;
                    default:
                        throw new IllegalArgumentException(type.name());
                }
            }

            // C1, C2, C4
            switch (type) {
                case ARBITRAGE_FLUX:
                    response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_PACTE_C1_C2_C4.name());
                    return response;
                case ARBITRAGE_STOCK:
                    response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_STOCK.name());
                    return response;
                case ARBITRAGE_FLUXSTOCK:
                    response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_STOCK_PACTE_C1_C2_C4.name());
                    return response;
                default:
                    throw new IllegalArgumentException(type.name());
            }
        }

        // Non pacte
        return jahiaDicoEntrySetter(response,type,contexte);
    }
    private ResponseDto<ResponseArbitrageFluxStockType> jahiaDicoEntrySetter(ResponseDto<ResponseArbitrageFluxStockType> response, ResponseArbitrageFluxStockType type, ArbitrageContexteDto contexte){
        switch (type) {
            case ARBITRAGE_FLUX:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX.name());
                return response;
            case ARBITRAGE_STOCK:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_STOCK.name());
                return response;
            case ARBITRAGE_FLUXSTOCK:
                response.setJahiaDicoEntry(contexte != null && contexte.isParcoursSimplifie() ?
                        DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_STOCK_PARCOURS_SIMPLIFIE.name() :
                        DictionnaireArbitrageJahia.ARB_CHOIX_ARBITRAGE_FLUX_STOCK.name());
                return response;
            default:
                throw new IllegalArgumentException(type.name());
        }
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getContratSelectionne().is(CodeSiloType.ERE);
    }
}
