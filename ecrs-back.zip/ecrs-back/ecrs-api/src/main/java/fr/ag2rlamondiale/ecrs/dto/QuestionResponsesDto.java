package fr.ag2rlamondiale.ecrs.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class QuestionResponsesDto<R, Q> {
    private QuestionDto question;

    /**
     * Forme affirmative de la question (pour afficher dans le r&eacute;sum&eacute;)
     */
    private MessageDto affirmativeMessage;

    private List<ResponseDto<R>> propositions = new ArrayList<>();
    private boolean isMultipleChoice = false;
    private boolean show = true;
    private MessageDto warningMessage;
    private ResponseDto<R> defaultValue;

    private Q data;

    public void add(ResponseDto<R> response) {
        response.setId(question.getId() + "-" + this.propositions.size());
        this.propositions.add(response);
    }

    public void addAll(Collection<? extends ResponseDto<R>> c) {
        c.forEach(this::add);
    }

    public void setDefaultValue(ResponseDto<R> defaultValue) {
        if (defaultValue != null) {
            defaultValue.setId(question.getId() + "-imposee");
        }
        this.defaultValue = defaultValue;
    }
}
