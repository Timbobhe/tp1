package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireArbitrage;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireBIA;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireClauseBenef;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireLiquidation;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireVersementLibre;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireVersementRegulier;
import fr.ag2rlamondiale.formulaire.modificationcoordonneesbancaires.FormulaireModificationCoordonneesBancaires;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.StringReader;
import java.io.StringWriter;

public final class XmlMarshallerUtils {


    private XmlMarshallerUtils() {
    }

    public static FormulaireArbitrage unMarshallFormArbitrage(String xml) throws JAXBException {
        final FormulaireArbitrage formulaireArbitrage;
        formulaireArbitrage = new XmlMarshaller<>(FormulaireArbitrage.class).unMarshall(xml);
        return formulaireArbitrage;
    }

    public static FormulaireVersementLibre unMarshallFormVersementLibre(String xml) throws JAXBException {
        return new XmlMarshaller<>(FormulaireVersementLibre.class).unMarshall(xml);
    }

    public static FormulaireVersementRegulier unMarshallFormVersementProgrammeFromXml(String xml) throws JAXBException {
        return new XmlMarshaller<>(FormulaireVersementRegulier.class).unMarshall(xml);
    }

    public static String marshallFormArbitrage(FormulaireArbitrage form) throws JAXBException {
        String marshall;
        marshall = new XmlMarshaller<>(FormulaireArbitrage.class).marshall(form);
        return marshall;
    }

    public static String marshallFormVersementLibre(FormulaireVersementLibre form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireVersementLibre.class).marshall(form);
    }

    public static String marshallFormVersementProgramme(FormulaireVersementRegulier form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireVersementRegulier.class).marshall(form);
    }

    public static FormulaireBIA unMarshallFormBia(String xml) throws JAXBException {
        return new XmlMarshaller<>(FormulaireBIA.class).unMarshall(xml);
    }

    public static String marshallFormBia(FormulaireBIA form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireBIA.class).marshall(form);
    }

    public static String marshallFormModificationDonneesBancaires(FormulaireModificationCoordonneesBancaires form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireModificationCoordonneesBancaires.class).marshall(form);
    }

    public static FormulaireClauseBenef unMarshallFormClauseBeneficiaire(String xml) throws JAXBException {
        return new XmlMarshaller<>(FormulaireClauseBenef.class).unMarshall(xml);
    }

    public static String marshallFormClauseBeneficiaire(FormulaireClauseBenef form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireClauseBenef.class).marshall(form);
    }

    public static FormulaireLiquidation unMarshallFormLiquidation(String xml) throws JAXBException {
        return new XmlMarshaller<>(FormulaireLiquidation.class).unMarshall(xml);
    }

    public static String marshallFormLiquidation(FormulaireLiquidation form) throws JAXBException {
        return new XmlMarshaller<>(FormulaireLiquidation.class).marshall(form);
    }

    public static fr.ag2rlamondiale.formulaire.formulaireversementlibre.FormulaireVersementLibre unMarshallFormVersementLibreV7(String xml) throws JAXBException {
        return new XmlMarshaller<>(fr.ag2rlamondiale.formulaire.formulaireversementlibre.FormulaireVersementLibre.class).unMarshall(xml);
    }

    public static String marshallFormVersementLibreV7(fr.ag2rlamondiale.formulaire.formulaireversementlibre.FormulaireVersementLibre form) throws JAXBException {
        return new XmlMarshaller<>(fr.ag2rlamondiale.formulaire.formulaireversementlibre.FormulaireVersementLibre.class).marshall(form);
    }

    public static class XmlMarshaller<T> {
        private final JAXBContext jaxbContext;

        public XmlMarshaller(Class<T> formulaireClass) throws JAXBException {
            try {
                jaxbContext = JAXBContext.newInstance(formulaireClass);
            } catch (JAXBException e) {
                throw new JAXBException("XmlParser JAXBException", e);
            }
        }

        @SuppressWarnings("unchecked")
        public T unMarshall(String formXml) throws JAXBException {
            T formulaire;
            try {
                Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
                StringReader stringReader = new StringReader(formXml);
                InputSource inputSource = new InputSource(stringReader);
                formulaire = (T) jaxbUnmarshaller.unmarshal(inputSource);
            } catch (JAXBException e) {
                throw new JAXBException("method parseFormXml ()", e);
            }
            return formulaire;
        }

        public String marshall(T formulaire) throws JAXBException {
            StringWriter sw = new StringWriter();
            try {
                Marshaller marshaller = jaxbContext.createMarshaller();
                marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
                marshaller.marshal(formulaire, sw);
            } catch (JAXBException e) {
                throw new JAXBException("xmlToString JAXBException", e);
            }
            return sw.toString();
        }
    }
}
