package fr.ag2rlamondiale.ecrs.dto;

import fr.ag2rlamondiale.ecrs.dto.versement.TypeVersement;
import lombok.Getter;

public enum QuestionType {
    ARBITRAGE_CHOIX_COMPARTIMENT,
    ARBITRAGE_CHOIX_MODEGESTION,
    ARBITRAGE_CHOIX_FLUXSTOCK,
    ARBITRAGE_CHOIX_TOTALPARTIEL,
    ARBITRAGE_CHOIX_EUROSPOURCENT,
    VERSEMENT_CHOIX_COMPARTIMENT,
    VERSEMENT_PROGRAMME_ARRET_MODIFICATION,

    /**
     * Ponctuel ou Programmé
     */
    VERSEMENT_CHOIX_MODE_TYPE,

    /**
     * Moyen de paiement : prelevement/cheque/cb
     */
    VERSEMENT_CHOIX_PAIEMENT;


    public enum ResponseArbitrageFluxStockType {
        ARBITRAGE_FLUX {
            @Override
            public boolean isFlux() {
                return true;
            }

            @Override
            public boolean isStock() {
                return false;
            }
        },
        ARBITRAGE_STOCK {
            @Override
            public boolean isFlux() {
                return false;
            }

            @Override
            public boolean isStock() {
                return true;
            }

        },
        ARBITRAGE_FLUXSTOCK {
            @Override
            public boolean isFlux() {
                return true;
            }

            @Override
            public boolean isStock() {
                return true;
            }
        };

        public abstract boolean isFlux();

        public abstract boolean isStock();
    }

    public enum ResponseArbitrageTotalPartielType {
        ARBITRAGE_TOTAL,
        ARBITRAGE_PARTIEL,
    }

    public enum ResponseArbitrageEurosPourcentageType {
        ARBITRAGE_EUROS,
        ARBITRAGE_POURCENTAGE,
    }

    public enum ResponseVersementDeductibiliteType {
        DEDUCTIBLE,
        NON_DEDUCTIBLE,
    }

    @Getter
    public enum ResponseVersementModeType {
        VERSEMENT_LIBRE(TypeVersement.VL),
        VERSEMENT_PROGRAMME(TypeVersement.PO);

        final private TypeVersement typeVersement;

        ResponseVersementModeType(TypeVersement typeVersement) {
            this.typeVersement = typeVersement;
        }
    }

    public enum ResponseVersementMoyenPaiementType {
        CHEQUE_BANCAIRE,
        PRELEVEMENT_AUTOMATIQUE,
        CARTE_BANCAIRE
    }

    public enum ResponseVersementArretModificationType {
        ARRET,
        MODIFICATION
    }
}
