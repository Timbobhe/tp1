package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IVersementFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.versement.RequestQuestionVersementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementTerminateDto;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.business.IUploadFileFacade;
import fr.ag2rlamondiale.trm.domain.upload.OptionValidationPJ;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.List;

/**
 * Implementation Spring du service REST pour le versement
 */
@RestController
@RequestMapping(path = "/secure")
public class VersementRestController {

    @Autowired
    private IVersementFacade versementFacade;

    @Autowired
    private IUploadFileFacade uploadFileFacade;

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENT_START)
    @LogExecutionTime
    @GetMapping(path = "/versement/start")
    public VersementStartDto start() throws TechnicalException {
        return versementFacade.startVersement();
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENT_QUESTION)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/versement/question")
    public QuestionResponsesDto<Object, Object> question(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    RequestQuestionVersementDto req) throws TechnicalException {
        return versementFacade.resolveQuestion(req);
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENT_QUESTION_OR_NEXT)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/versement/question-or-next")
    public ListQuestionResponsesDto resolveQuestionOrNext(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
            RequestQuestionVersementDto req) throws TechnicalException {
        return versementFacade.resolveQuestionOrNext(req);
    }

    @ProfileExecution(codeAction = CodeActionType.API_VERSEMENT_TERMINATE)
    @Secure
    @LogExecutionTime
    @PostMapping(path = "/versement/terminate")
    public String terminate(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE}) VersementTerminateDto versementTerminate,
            @RequestParam("frame") boolean frame) throws TechnicalException, IOException, JAXBException {
        final UploadFileDto rib = versementTerminate.getVersementClient().getFichiercoordonneesBancaires();
        if (rib != null) {
            uploadFileFacade.validPiecesJointes(
                    List.of(rib), OptionValidationPJ.builder()
                            .obligatoire(true)
                            .maxFiles(1)
                            .build(), s -> {
                        throw new RuntimeException(s);
                    });
        }

        return versementFacade.terminate(versementTerminate, frame);
    }
}
