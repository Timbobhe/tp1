package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IDonneesPersoFacade;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoInfo;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursValidation;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_DONNEE_PERSO_INFO;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_DONNEE_PERSO_MODIFICATION_END;

@RestController
//@Conditional(value = ToggleFeaturesCondition.class)
@RequestMapping(path = "/secure/donnees-perso")
public class ValidationDonneesPersoController {


    @Autowired
    private IDonneesPersoFacade donneePersoFacade;

    @ProfileExecution(codeAction = API_DONNEE_PERSO_INFO)
    @LogExecutionTime
    @GetMapping(path = "/get-donnees-perso")
    public DonneesPersoInfo info() throws TechnicalException {
        return donneePersoFacade.getDonnesPerso();
    }

    @ProfileExecution(codeAction = API_DONNEE_PERSO_MODIFICATION_END)
    @LogExecutionTime
    @PostMapping(path = "/validation-donnees-perso")
    public ModifierPPSiloResponseDto validationModifDonnesPerso(@RequestBody DonneesPersoParcoursValidation donneePersoModification) throws TechnicalException {
        return donneePersoFacade.validerModifDonnesPerso(donneePersoModification);
    }
}
