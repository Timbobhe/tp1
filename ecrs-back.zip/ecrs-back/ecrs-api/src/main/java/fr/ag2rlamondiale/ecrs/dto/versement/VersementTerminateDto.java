package fr.ag2rlamondiale.ecrs.dto.versement;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.Data;

import java.util.Set;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class VersementTerminateDto implements ISecurityParamAccess {
    private ContratId contratSelected;
    private VersementClientDto versementClient;
    private DocumentDto contenuVersement;
    private DocumentDto contenuQad;

    @Override
    public String secureForNumContrat() {
        return contratSelected.getNomContrat();
    }

    @Override
    public void secureAppendIdentifiantsAssure(Set<String> appender) {
        if (versementClient != null) {
            versementClient.secureAppendIdentifiantsAssure(appender);
        }
    }
}
