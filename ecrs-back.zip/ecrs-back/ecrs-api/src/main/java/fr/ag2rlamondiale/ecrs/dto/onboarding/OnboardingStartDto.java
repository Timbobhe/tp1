package fr.ag2rlamondiale.ecrs.dto.onboarding;

import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.ecrs.dto.structinv.GrilleProfilInvDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class OnboardingStartDto extends BasicInfoParcoursDto {

    private boolean onboardingDejaEffectue;

    private EvenementJson evenement;

    private ContratId idDernierContratERE;

    private GrilleProfilInvDto grilleInvParDefaut;

    private List<SujetDto> sujets;

    private String descClauseBenef;

    // Si le client a déja fait son BIA, on l'embarque directement dans l'étape choix des sujets
    private boolean biaEffectue;
}
