/*
 * Cree le 30 mai 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICguFacade;
import fr.ag2rlamondiale.trm.client.rest.ICguRestClient;
import fr.ag2rlamondiale.trm.client.soap.IConsulterIdentiteClient;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class CguFacadeImpl implements ICguFacade {
    @Autowired
    private IConsulterIdentiteClient consulterIdentiteClient;

    @Autowired
    private ICguRestClient cguRestClient;

    @Autowired
    private UserContextHolder userContextHolder;

    @Cacheable("cguCache")
    @Override
    public CguDetails getCguDetails() {
        return cguRestClient.getCguDetails();
    }

    @Override
    public List<String> getAcceptedGguIds(String idGdi) throws TechnicalException {
        Objects.requireNonNull(idGdi);
        return consulterIdentiteClient.consulterIdentite(idGdi).getIdCguValides();
    }

    @Override
    public List<String> getAcceptedGguIds(Integer idCxp) {
        Objects.requireNonNull(idCxp);
        return cguRestClient.getAcceptedGguIds(idCxp);
    }

    @Override
    public boolean createAcceptationCgu(String idCgu) {
        Objects.requireNonNull(idCgu);
        return cguRestClient.createAcceptationCgu(
                userContextHolder.get().getTemporaryId(), idCgu);
    }
}
