package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;

import java.util.List;

public interface ICguFacade {
    CguDetails getCguDetails();

    /**
     * Vérification depuis la PFS pour les utilisateurs qui ont un ID GDI
     *
     * @param idGdi
     * @return
     * @throws TechnicalException
     */
    List<String> getAcceptedGguIds(String idGdi) throws TechnicalException;

    /**
     * Vérification depuis la console (BDD) à partir de l'ID technique pour les utilisateurs qui n'ont pas d'ID GDI
     *
     * @param idCxp
     * @return
     * @throws TechnicalException
     */
    List<String> getAcceptedGguIds(Integer idCxp) throws TechnicalException;

    /**
     * L'acceptation des CGU est sauvegardé dans la console (BDD). La PFS ne disposant pas d'endroit pour les sauvegarder chez eux.
     *
     * @param idCgu
     * @return
     * @throws TechnicalException
     */
    boolean createAcceptationCgu(String idCgu) throws TechnicalException;
}
