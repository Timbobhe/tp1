package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IClausesBenefCtrFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationSigElecClauseBeneficiaire;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireStartDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.InfoClauseBeneficiaireContratDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterClausesBenefCtrClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.dto.sigelec.ResultatEtatDemandesDto;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Service
public class ClausesBenefCtrFacadeImpl implements IClausesBenefCtrFacade {

    @Autowired
    private IConsulterClausesBenefCtrClient clausesBenefCtrClient;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ISigElecFacade sigElecfacade;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Autowired
    private IJahiaFacade jahiaFacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Override
    public ConsulterClausesBenefCtrResponseDto consulterClausesBenefCtr(String numContrat,
                                                                        CodeSiloType silo) throws TechnicalException {
        Objects.requireNonNull(numContrat);
        ConsulterClausesBenefCtrDto dto = new ConsulterClausesBenefCtrDto(silo, numContrat);
        return clausesBenefCtrClient.consulterClausesBenefCtr(dto);
    }

    @Override
    public ClauseBeneficiaireStartDto startModificationClauseBeneficiaire()
            throws TechnicalException {
        List<ContratHeader> contrats = retrieveContractsforModificationClauseBeneficiaire();

        List<InfoClauseBeneficiaireContratDto> infos = contrats.stream()
                .map(c -> handleException(() -> this.buildInfoVersementContrat(c)))
                .collect(Collectors.toList());

        return ClauseBeneficiaireStartDto.builder()
                .clauseBeneficiaireContrats(infos)
                .sigElecOff(infos.stream().allMatch(InfoClauseBeneficiaireContratDto::isSigElecOff))
                .build();
    }

    private InfoClauseBeneficiaireContratDto buildInfoVersementContrat(ContratHeader contratHeader) throws TechnicalException {
        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();

        return InfoClauseBeneficiaireContratDto.builder()
                .contrat(contratParcoursMapper.map(contratHeader))
                .sigElecOff(blocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.SIGELEC_MODIFIER_CLAUSE_BENEF))
                .build();

    }

    @Override
    public List<ContratHeader> retrieveContractsforModificationClauseBeneficiaire() throws TechnicalException {
        List<ContratHeader> contratHeaders = contratFacade.rechercherContratsEre()
                .stream()
                .filter(contratHeader -> !contratHeader.getAffichageType().isDisabled())
                .collect(Collectors.toList());
        return contratHeaders.stream()
                .filter(contratHeader -> handleException(() -> !isModifClauseBeneficiaireBloqueePourContrat(contratHeader)))
                .filter(contratHeader -> handleException(() -> {
                    final ResultParcoursEffectueDto resultParcoursEffectueDto = modificationClauseBeneficiaireEnCours(contratHeader);
                    return !resultParcoursEffectueDto.isEncours() || resultParcoursEffectueDto.isSigElecEncoursNonSigne();
                }))
                .collect(Collectors.toList());
    }

    private boolean isModifClauseBeneficiaireBloqueePourContrat(ContratHeader c) throws TechnicalException {
        final InfosBlocagesClient infosBlocagesClient = blocageFacade.getInfosBlocagesClient();
        return infosBlocagesClient.isFonctionnaliteBloqueePourContrat(c.getId(), FonctionnaliteType.MODIFICATION_CLAUSE_BENEFICIAIRE);
    }

    @Override
    public String terminateModificationClauseBeneficiaire(ClauseBeneficiaireTerminateDto dto,
                                                          boolean isFrame) throws CommonException, IOException, JAXBException {
        ContratId contratId = dto.getContratSelected();
        DocumentDto clauseBeneficiaireDocument = dto.getContenuClauseBeneficiaire();

        ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);

        final DocRefType docRefType = DocRefType.getDocumentRefType(DocumentRefType.MODIFICATION_CLAUSE_BENEFICIAIRE_EN_LIGNE.name(), contratHeader.getCodeSilo());
        DataDocumentContrat documentActeContrat = null;
        if (clauseBeneficiaireDocument != null && clauseBeneficiaireDocument.getHtmlContent() != null) {
            documentActeContrat = dataDocumentContratFacade.buildDocumentContrat(contratHeader, null, clauseBeneficiaireDocument, docRefType);
        }

        if (documentActeContrat != null) {
            DemandeCreationSigElec demandeCreationSigElec =
                    initDemandeCreationSigElec(dto, contratHeader, documentActeContrat);
            return sigElecfacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec,
                                                                          isFrame);
        } else {
            return null;
        }
    }

    private DemandeCreationSigElecClauseBeneficiaire initDemandeCreationSigElec(ClauseBeneficiaireTerminateDto dto,
                                                                                ContratHeader contratHeader,
                                                                                DataDocumentContrat documentActeContrat) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        String numPersonne = contratHeader.getPersonId();

        DemandeCreationSigElecClauseBeneficiaire demandeCreationSigElec = new DemandeCreationSigElecClauseBeneficiaire();
        demandeCreationSigElec.add(documentActeContrat);

        demandeCreationSigElec.setCodeSilo(contratHeader.getCodeSilo());
        demandeCreationSigElec.setTypeDonneeATraiter();
        demandeCreationSigElec.setCodeAssureur(contratHeader.getCodeAssureur());

        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setAgrementsConventionDePreuve(documentActeContrat.getAgrementsConventionDePreuve());
        demandeCreationSigElec.setConventionDePreuveTitre(documentActeContrat.getConventionDePreuveTitre());

        demandeCreationSigElec.setClauseBeneficiaire(dto.getClauseBeneficiaire().getTypeClause());
        demandeCreationSigElec.setClauseBeneficiaireDescription(dto.getClauseBeneficiaire().getContenuClause());

        demandeCreationSigElec.setIdentifiantAssure(contratHeader.getIdentifiantAssure());
        demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
        demandeCreationSigElec.setNumPP(numPersonne);
        demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo()));
        demandeCreationSigElec.setTypeOperation(OperationType.CBF);
        return demandeCreationSigElec;
    }

    private ResultParcoursEffectueDto modificationClauseBeneficiaireEnCours(ContratHeader contrat) throws WorkflowException {
        final ResultParcoursEffectueDto res = hasDemandeModificationClauseBeneficiaireInProgress(contrat);
        if (res.isEncours()) {
            return res;
        }

        return ResultParcoursEffectueDto.builder()
                .contratHeader(contrat)
                .workflowParcoursEncours(hasDemandeModificationClauseBeneficiaire(contrat))
                .build();
    }

    private boolean hasDemandeModificationClauseBeneficiaire(ContratHeader contratHeader) throws WorkflowException {
        String idPers = userContextHolder.get().getNumeroPersonneEre();
        return workflowFacade.hasDemandeEnCoursByContrat(idPers, contratHeader, DemandeWorkflowType.EXTRANET_CLAUSE_BENEF);
    }

    private ResultParcoursEffectueDto hasDemandeModificationClauseBeneficiaireInProgress(ContratHeader contratHeader) {
        String idGDI = userContextHolder.get().getIdGdi();
        final ResultatEtatDemandesDto resEtat = sigElecfacade.verifierEtatDemandes(idGDI, contratHeader.getId(), OperationType.CBF);

        return ResultParcoursEffectueDto.builder()
                .contratHeader(contratHeader)
                .sigElecEncoursSigne(resEtat.isSigElecEncoursSigne())
                .sigElecEncoursNonSigne(resEtat.isSigElecEncoursNonSigne())
                .build();
    }

}
