package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IQadFacade;
import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.qad.QadRequestDto;
import fr.ag2rlamondiale.ecrs.dto.qad.QadResultDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinRequest;
import fr.ag2rlamondiale.trm.domain.qad.CodeProfilType;
import fr.ag2rlamondiale.trm.domain.qad.PropositionJson;
import fr.ag2rlamondiale.trm.domain.qad.PropositionRequest;
import fr.ag2rlamondiale.trm.domain.qad.QadResultData;
import fr.ag2rlamondiale.trm.domain.qad.QadType;
import fr.ag2rlamondiale.trm.domain.qad.QuestionJson;
import fr.ag2rlamondiale.trm.domain.qad.TypeProfilJson;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class QadFacadeImpl implements IQadFacade {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IQadRestClient qadRestClient;

    @Override
    public List<QuestionJson> getQadQuestRep(QadRequestDto qadRequest) throws TechnicalException {
        QadType qadType = qadRequest.getType();
        ContratHeader contratHeader = contratFacade.rechercherContratParId(qadRequest.getContrat());
        if (contratHeader == null) {
            return Collections.emptyList();
        } else {
            qadType = qadType.getTypeforPacte(contratHeader.isPacte());
        }
        return qadRestClient.getQuesRepByProfil(qadType.getListeCodeProfil());
    }

    /**
     * @param qadResultDto (QAD Results & Contrat infos)
     * @return Liste de propositons selon contrat ERE/MDP
     */

    @Override
    public List<PropositionJson> getTypesPropositionGrille(QadResultDto qadResultDto) throws TechnicalException {
        List<PropositionJson> propositionsProfil = new ArrayList<>();
        if (CodeSiloType.ERE.equals(qadResultDto.getContrat().getCodeSilo())) {
            propositionsProfil = getTypePropositionGrilleERE(qadResultDto);
        } else if (CodeSiloType.MDP.equals(qadResultDto.getContrat().getCodeSilo())) {
            propositionsProfil = getTypesPropositionGrilleKeyMDP(qadResultDto);
        }
        return propositionsProfil;
    }


    private List<PropositionJson> getTypePropositionGrilleERE(QadResultDto qadResultDto) throws TechnicalException {
        List<PropositionJson> resultPropositions = new ArrayList<>();
        ContratHeader contratHeader = contratFacade.rechercherContratParId(qadResultDto.getContrat());

        GestionFinRequest request = GestionFinRequest.from(qadResultDto.getFonctionnaliteType(),
                contratHeader.getCodeSilo(), contratHeader.isPacte());

        int score = QadResultData.getScoreFromResults(qadResultDto.getQadResult(),
                request.getQadType().getListeCodeProfil().iterator().next());
        Set<String> codesSupportsContrat = qadResultDto.getCodesSupportsContrat();
        List<TypeProfilJson> profils = getTypesProfilParProfils(request.getQadType().getListeCodeProfil(), codesSupportsContrat);
        CodeProfilType codeProfil = contratHeader.isPacte() ? CodeProfilType.PACTE : CodeProfilType.PART;
        TypeProfilJson typeProfil = selectGrilleSupport(getTypesProfilParProfil(codeProfil, profils), score);
        if (typeProfil != null) {
            PropositionJson proposition = new PropositionJson();
            proposition.setNumeroProposition(resultPropositions.size() + 1);
            proposition.setTypeProfilERE(typeProfil);
            resultPropositions.add(proposition);
        }

        return resultPropositions;

    }

    /**
     * @param qadResultDto
     * @return
     * @throws TechnicalException
     */
    private List<PropositionJson> getTypesPropositionGrilleKeyMDP(QadResultDto qadResultDto) throws TechnicalException {
        ContratHeader contratHeader = contratFacade.rechercherContratParId(qadResultDto.getContrat());

        GestionFinRequest request = GestionFinRequest.from(qadResultDto.getFonctionnaliteType(),
                contratHeader.getCodeSilo(), contratHeader.isPacte());

        List<TypeProfilJson> profils = qadRestClient.getTypesProfilParProfils(request.getQadType().getListeCodeProfil());

        List<QadResultData> qadResult = qadResultDto.getQadResult();

        TypeProfilJson typeProfilEpargnant = selectGrilleSupport(getTypesProfilParProfil(CodeProfilType.EPAR, profils),
                QadResultData.getScoreFromResults(qadResult, CodeProfilType.EPAR));

        TypeProfilJson typeProfilInvestissement = selectGrilleSupport(
                getTypesProfilParProfil(CodeProfilType.INVEST, profils),
                QadResultData.getScoreFromResults(qadResult, CodeProfilType.INVEST));

        List<PropositionJson> propositions = getPropositionParProduit(contratHeader);
        List<PropositionJson> resultPropositions = new ArrayList<>();

        for (PropositionJson proposition : propositions) {
            if (typeProfilEpargnant != null && proposition.getTypeProfilEpargnant().getIdTypPfl() == typeProfilEpargnant.getIdTypPfl()
                    && typeProfilInvestissement != null && proposition.getTypeProfilInvestissement().getIdTypPfl() == typeProfilInvestissement.getIdTypPfl()) {
                resultPropositions.add(proposition.toBuilder().numeroProposition(resultPropositions.size() + 1).build());
            }
        }

        return resultPropositions;
    }

    @Override
    public List<PropositionJson> getPropositionParProduit(ContratHeader contratHeader) {
        PropositionRequest requete = new PropositionRequest();
        requete.setNumGenContrat(contratHeader.getNumGenContrat());
        requete.setTypeContrat(contratHeader.getTypeContrat());
        return qadRestClient.getPropositionsParProduit(requete);
    }

    private TypeProfilJson selectGrilleSupport(List<TypeProfilJson> profils, int score) {
        TypeProfilJson entryToSelect = getSupportWithMaxWeightInferiorTo(profils, score);

        // Si tous les poids des supports sont supérieurs au poids calculé
        if (entryToSelect == null) {
            entryToSelect = getSupportWithMinWeight(profils);
        }
        return entryToSelect;
    }

    private TypeProfilJson getSupportWithMinWeight(List<TypeProfilJson> result) {
        TypeProfilJson entryToSelect = null;

        for (TypeProfilJson entry : result) {
            int currentWeight = entry.getScoreInf();
            if (entryToSelect == null || currentWeight < entryToSelect.getScoreInf()) {
                entryToSelect = entry;
            }
        }
        return entryToSelect;
    }

    private TypeProfilJson getSupportWithMaxWeightInferiorTo(List<TypeProfilJson> result, int weight) {
        TypeProfilJson entryToSelect = null;
        for (TypeProfilJson entry : result) {
            int currentWeight = entry.getScoreInf();
            if (currentWeight <= weight && (entryToSelect == null || currentWeight > entryToSelect.getScoreInf())) {
                entryToSelect = entry;
            }
        }
        return entryToSelect;
    }

    private ArrayList<TypeProfilJson> getTypesProfilParProfil(CodeProfilType codeProfilType,
                                                              List<TypeProfilJson> typesProfil) {
        ArrayList<TypeProfilJson> typesProfilParProfil = new ArrayList<>();

        for (TypeProfilJson json : typesProfil) {
            if (json.getCodeProfil() == codeProfilType) {
                typesProfilParProfil.add(json);
            }
        }
        return typesProfilParProfil;
    }

    @Override
    public List<TypeProfilJson> getTypesProfilParProfils(Set<CodeProfilType> profils,
                                                         Set<String> codesSupportsContrat) {
        final List<TypeProfilJson> typesProfil = qadRestClient.getTypesProfilParProfils(profils);
        if (CollectionUtils.isEmpty(codesSupportsContrat)) {
            return typesProfil;
        }

        return typesProfil.stream().filter(typeProfil -> codesSupportsContrat.contains(typeProfil.getCodeSupport()))
                .collect(Collectors.toList());
    }
}
