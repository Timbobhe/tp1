package fr.ag2rlamondiale.ecrs.dto;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import lombok.*;

@NoArgsConstructor
@Getter
@Builder(toBuilder = true)
@AllArgsConstructor
@ToString
public class ResultParcoursEffectueDto {
    private ContratHeader contratHeader;
    private boolean parcoursEffectue;
    private boolean sigElecEncoursSigne;
    private boolean sigElecEncoursNonSigne;
    private boolean workflowParcoursEncours;

    public boolean isEncours() {
        return sigElecEncoursNonSigne || sigElecEncoursSigne || workflowParcoursEncours;
    }

}
