package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IParcoursSimplifieFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.business.domain.structinv.SupportsInvNiveau1;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.ModePlacementVersementType;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleProfilInv;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VersementQuestionResolverChoixCompartiment implements VersementQuestionResolver {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private ContratVifHelper contratVifHelper;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private RequestContextHolder requestContextHolder;

    @Autowired
    private IParcoursSimplifieFacade parcoursSimplifieFacade;

    @Override
    public QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolve(QuestionType questionType, VersementContexteDto contexte) throws TechnicalException {
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        return resolve(contratHeader, contexte);
    }

    public QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolve(ContratHeader contratHeader, VersementContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = new QuestionResponsesDto<>();
        final ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratHeader.getContratId());
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();

        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_QUESTION_DEDUCTIBILITE_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_DEDUCTIBILITE_MESSAGE_SOUHAIT.name())
                .build());
        result.setData(new BlocageVersementContratDto());


        final List<ResponseDto<ChoixCompartimentDto>> responsesCompartiments = new ArrayList<>();
        List<Compartiment> compartiments = contratHeader.getCompartiments().stream()
                .filter(compart -> compart.is(CompartimentType.C4) || compart.is(CompartimentType.C1))
                .filter(compartiment -> {
                    if (requestContextHolder.getContrat() != null && !compartiment.getContrat().getId().equals(requestContextHolder.getContrat())) {
                        return false;
                    }
                    if (requestContextHolder.getCompartiment() != null && compartiment.isERE()) {
                        return compartiment.getIdentifiantAssure().equals(requestContextHolder.getCompartiment());
                    }
                    return true;
                })
                .collect(Collectors.toList());
        for (Compartiment compartiment : compartiments) {
            SupportsInvNiveau1 grillesProfilsPremierNiveau = structureInvFacade.getGrillesProfilsPremierNiveau(compartiment);
            final ResponseDto<ChoixCompartimentDto> response = ResponseDto.<ChoixCompartimentDto>builder()
                    .id(compartiment.getCompartimentId().toString())
                    .label(getLabelDeductible(compartiment))
                    .value(ChoixCompartimentDto.builder().compartiment(contratParcoursMapper.map(compartiment, true)).build())
                    .build();
            if (compartiment.isERE()) {
                buildModePlacementVersement(response, contratComplet,grillesProfilsPremierNiveau);
            }
            completeResponse(response, compartiment, contratComplet);
            responsesCompartiments.add(response);
        }

        if (contratHeader.isPacte() && responsesCompartiments.stream().allMatch(ResponseDto::isDisabled)) {
            result.getData().setContratBloque(true);
            result.setShow(false);
            result.setWarningMessage(MessageDto.builder()
                    .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_BLOCAGE_ETAT_COMPTE.name())
                    .build());
            return result;
        }

        if (contratHeader.isPacte() && responsesCompartiments.size() > 1) {
            result.addAll(responsesCompartiments);
            return result;
        } else {
            result.setShow(false);
            result.setDefaultValue(responsesCompartiments.get(0));
            contexte.update(ctx -> ctx.setCompartimentSelectionne(responsesCompartiments.get(0).getValue().getCompartiment().toCompartimentId()));
            return result;
        }
    }

    private void buildModePlacementVersement(ResponseDto<ChoixCompartimentDto> response, ContratComplet contratComplet,
                                             SupportsInvNiveau1 grillesProfilsPremierNiveau) throws TechnicalException {
        final boolean selonDispositionsContractuelles = isVersementInvestiSelonDispositionContractuelles(grillesProfilsPremierNiveau); //RM18
        final boolean memePlacementCotisationObligatoires = !contratComplet.getContratGeneral().getOptContratEpargne().isAllowDifferentInvestmentsForVif(); //RM20
        final boolean simplifie = parcoursSimplifieFacade.isParcoursSimplifieActivate(contratComplet.getContratHeader().getId(), FonctionnaliteType.VERSEMENT_SIMPLIFIE);
        if(simplifie){
            response.getValue().setModePlacementVersement(ModePlacementVersementType.NON_MODIFIABLE_PARCOURS_SIMPLIFIE);
        }else if(selonDispositionsContractuelles){
            response.getValue().setModePlacementVersement(ModePlacementVersementType.SELON_DISPOSITIONS_CONTRACTUELLES);
        }else if(memePlacementCotisationObligatoires){
            response.getValue().setModePlacementVersement(ModePlacementVersementType.MEME_PLACEMENT_COTISATION_OBLIGATOIRES);
        }else {
            response.getValue().setModePlacementVersement(ModePlacementVersementType.LIBRE_CHOIX_CLIENT);
        }
    }

    private boolean isVersementInvestiSelonDispositionContractuelles(SupportsInvNiveau1 grillesProfilsPremierNiveau) {
        if (grillesProfilsPremierNiveau.getSupports().size() == 1) {
            //RM17 Il ne faut pas tableau de repartition si le compartiment VL ne comporte qu&rsquo;un seul profil ou qu&rsquo;une seule grille
            return true;
        }
        //RM17'
        BigDecimal sommeTauxRepartitionNonDerogeables = grillesProfilsPremierNiveau.getSupports().stream()
                .filter(grilleProfilInv -> !grilleProfilInv.getIndicateurTauxDerogeable())
                .map(GrilleProfilInv::getTauxRepartition)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return sommeTauxRepartitionNonDerogeables.compareTo(BigDecimal.ONE) == 0;
    }

    private String getLabelDeductible(Compartiment compartiment) {
        return compartiment.isDeductible() ? "D\u00E9ductible" : "Non D\u00E9ductible";
    }

    private void completeResponse(ResponseDto<ChoixCompartimentDto> response, Compartiment compartiment, ContratComplet contratComplet) {
        if (!contratVifHelper.isVifPossible(contratComplet, compartiment.getCompartimentId())) {
            response.setDisabled(true);
            response.setWarningMessage(MessageDto.builder()
                    .label(compartiment.getLabel() + " indisponible pour faire un vif")
                    .build());
        }
    }

    @Override
    public boolean accept(QuestionType questionType, VersementContexteDto contexte) {
        return QuestionType.VERSEMENT_CHOIX_COMPARTIMENT.equals(questionType) && contexte.getContratSelectionne() != null;
    }
}
