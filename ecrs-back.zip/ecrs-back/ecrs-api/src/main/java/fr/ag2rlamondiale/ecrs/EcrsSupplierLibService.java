package fr.ag2rlamondiale.ecrs;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@Service
public class EcrsSupplierLibService implements ISupplierLibService {

    @Value("${ecrs.front.url}")
    private String ecrsFrontUrl;

    @Override
    public String getCodeCassiniAppli() {
        return CodeApplicationType.ECRS.getCode();
    }

    @Override
    public String getLibelleAppli() {
        return "ESPACE CLIENT RETRAITE SUPPLEMENTAIRE";
    }

    @Override
    public String getUrlFront() {
        return ecrsFrontUrl;
    }
}
