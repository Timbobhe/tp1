package fr.ag2rlamondiale.ecrs.business.impl.versement;

import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;

import java.util.Comparator;
import java.util.Date;

/**
 * Trie les echeanciers en se basant sur le prélévement le plus récent
 */
public class ComparatorEcheancierSelonPrelevement implements Comparator<Echeancier> {
    @Override
    public int compare(Echeancier o1, Echeancier o2) {
        final Prelevement p1 = prochainPrelevementApresDateJour(o1);
        final Prelevement p2 = prochainPrelevementApresDateJour(o2);
        if (p1 == null && p2 == null) {
            return 0;
        }

        if (p1 == null) {
            return 1;
        }

        if (p2 == null) {
            return 1;
        }

        return p1.getDatePrelevement().compareTo(p2.getDatePrelevement());
    }

    public Prelevement prochainPrelevementApresDateJour(Echeancier echeancier) {
        final Date today = new Date();
        return echeancier.getPrelevements().stream()
                .filter(prelevement -> prelevement.getDatePrelevement().compareTo(today) > 0)
                .min(Comparator.comparing(Prelevement::getDatePrelevement))
                .orElse(null);
    }
}
