package fr.ag2rlamondiale.ecrs.api.error;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

import static fr.ag2rlamondiale.ecrs.web.filter.ClientRequestTracking.REQUEST_ID;

@ConditionalOnProperty(value = "custom.server.error.active")
@Slf4j
@Controller
public class CustomErrorController implements ErrorController, InitializingBean {
    //    @RequestMapping({"/error", "/error/{code}"})
    @RequestMapping({"${server.error.path:${error.path:/error}}", "${server.error.path:${error.path:/error}}/{code}"})
    public ModelAndView handleError(HttpServletRequest request, @PathVariable(value = "code", required = false) Integer code) {
        int statusCode = -1;
        Map<String, Object> model = new HashMap<String, Object>();
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String idreq = (String) request.getAttribute(REQUEST_ID);
        model.put("idRequest", idreq);
        if (status != null) {
            statusCode = Integer.parseInt(status.toString());
        } else if (code != null) {
            statusCode = code;
        }

        if (statusCode == HttpStatus.NOT_FOUND.value()) {
            return new ModelAndView("error-404", model);
        } else if (statusCode == HttpStatus.UNAUTHORIZED.value()) {
            return new ModelAndView("error-401", model);
        } else if (statusCode == HttpStatus.UNAVAILABLE_FOR_LEGAL_REASONS.value()) {
            return new ModelAndView("error-451", model);
        } else if (statusCode == HttpStatus.SERVICE_UNAVAILABLE.value()) {
            return new ModelAndView("error-503", model);
        } else if (statusCode == HttpStatus.INTERNAL_SERVER_ERROR.value()) {
            return new ModelAndView("error-500", model);
        }
        return new ModelAndView("error-base", model);

    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("CustomErrorController active");
    }
}
