package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.mapping.StructInvMapper;
import fr.ag2rlamondiale.ecrs.dto.versement.*;
import fr.ag2rlamondiale.ecrs.utils.VersementUtils;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.*;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleProfilInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_ODF;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME;
import static java.util.List.of;

@Service
public class VersementQuestionResolverLibreProgramme implements VersementQuestionResolver {
    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private StructInvMapper structInvMapper;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IEcheancierFacade echeancierFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IBlocageFacade blocageFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private VersementGestionMontantService versementGestionMontantService;

    @Setter
    @Value("${ere.delai.teletransmission.versement:15}")
    private Integer delaiTeletransmission;

    @Autowired
    private IParamConsoleFacade paramConsoleFacade;

    @Setter
    @Value("${odf.activate:false}")
    private boolean odfActivated;

    @Override
    public QuestionResponsesDto<ModeVersementDto, GestionFinanciereResponseDto> resolve(QuestionType questionType,
                                                                                        VersementContexteDto contexte) throws TechnicalException {
        final QuestionResponsesDto<ModeVersementDto, GestionFinanciereResponseDto> result = new QuestionResponsesDto<>();
        completerGestionFinanciere(contexte, result);
        result.setQuestion(QuestionDto.builder()
                                   .id(QuestionType.VERSEMENT_CHOIX_MODE_TYPE)
                                   .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_QUESTION_MODE_TITRE.name())
                                   .build());

        result.setAffirmativeMessage(MessageDto.builder()
                                             .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_MODE_MESSAGE_SOUHAIT.name())
                                             .build());

        final InfosBlocagesClient blocagesClient = blocageFacade.getInfosBlocagesClient();
        if (contexte.getContratSelectionne().is(CodeSiloType.MDP)) {
            result.setShow(false);
            result.setDefaultValue(reponseLibre(contexte, blocagesClient));
            contexte.update(ctx -> ctx.setReponseModeVersementType(VERSEMENT_LIBRE));
            return result;
        } else if (hasDemandeWorkflowVersementProgrammeEncours()) {
            result.add(reponseLibre(contexte, blocagesClient));
            final ResponseDto<ModeVersementDto> response = ResponseDto.<ModeVersementDto>builder()
                    .id(VERSEMENT_PROGRAMME.name()).disabled(true)
                    .warningMessage(MessageDto.builder()
                                            .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_PROGRAMME_EN_COURS.name())
                                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_PROGRAMME.name()).build();
            result.add(response);
        } else {
            result.add(reponseLibre(contexte, blocagesClient));
            result.add(reponseProgramme(contexte, blocagesClient));
        }

        return result;
    }

    private void completerGestionFinanciere(VersementContexteDto contexte,
                                            QuestionResponsesDto<ModeVersementDto, GestionFinanciereResponseDto> result) throws TechnicalException {
        final GestionFinanciereResponseDto res = new GestionFinanciereResponseDto();
        result.setData(res);

        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        final Compartiment compartiment = contratHeader.compartiment(contexte.getCompartimentSelectionne());
        final GestionFinActuelleRequestDto gfar = GestionFinActuelleRequestDto.builder()
                .contratId(contexte.getContratSelectionne()).compartimentId(contexte.getCompartimentSelectionne())
                .placementsFinanciersDifferentsAutorises(false).tousCompartimentsSelected(false).build();
        final GestionFinanciereActuelleCompartimentsDto gestionFinanciereActuelle = structureInvFacade
                .getGestionFinanciereActuelle(compartiment, gfar);
        res.setGestionFinanciereActuelleCompartiment(gestionFinanciereActuelle);

        if (contratHeader.isEre()) {
            final GestionFinRequestDto request = GestionFinRequestDto.builder()
                    .contratId(contexte.getContratSelectionne()).compartimentId(contexte.getCompartimentSelectionne())
                    .fonctionnalite(FonctionnaliteType.VERSEMENT).build();

            res.setGestionFinanciereCompartiment(gestionFinForVersement(request, contratHeader, compartiment));

        } else if (contratHeader.isMdpro()) {
            final GestionFinanciereActuelleMdpDto gestionFinanciereActuelleMdp = structureInvFacade
                    .getInfoGestionFinanciereActuelleMdp(contratHeader);
            if (gestionFinanciereActuelleMdp != null
                    && ModeGestionMdproType.LIBRE.equals(gestionFinanciereActuelleMdp.getModeGestionMDPROSource())) {
                // Possibilité de choisir une gestion financiere pour MDP uniquement si c'est
                // une gestion LIBRE
                final GestionFinRequestDto request = GestionFinRequestDto.builder()
                        .contratId(contexte.getContratSelectionne())
                        .compartimentId(contexte.getCompartimentSelectionne())
                        .fonctionnalite(FonctionnaliteType.VERSEMENT).build();

                final GestionFinRequest gfr = GestionFinRequest.from(request, contratHeader.getCodeSilo(),
                                                                     contratHeader.isPacte());
                final GestionFinanciereDto gestionFinanciere = structureInvFacade.getGestionFinanciere(compartiment,
                                                                                                       gfr);
                res.setGestionFinanciereCompartiment(gestionFinanciere);
            }
        }
    }

    private GestionFinanciereDto gestionFinForVersement(GestionFinRequestDto request, ContratHeader contratHeader,
                                                        Compartiment compartiment) {
        ContratComplet contratComplet = contratFacade.recupererContratComplet(contratHeader);
        final StructInv structInvFromCompteGenerale = contratComplet
                .compteGeneralesEre(compartiment.getCompartimentId()).getStructInv();
        final List<ContributionType> contributionTypesFromCompteGenerale = ContributionType
                .forCompartiment(compartiment.getType(), compartiment.isPacte());

        final GestionFinRequest gfr = GestionFinRequest.from(request, contratHeader.getCodeSilo(),
                                                             contratHeader.isPacte());
        final GestionFinanciereDto gestionFinanciere = structureInvFacade.getGestionFinanciere(compartiment, gfr);
        Collection<GrilleProfilInvDto> supportsForVersement = new ArrayList<>();

        for (GrilleProfilInvDto support : gestionFinanciere.getGrillesProfilsNiveau1()) {
            support.setDefaut(false);

            Optional<GrilleProfilInv> grilleProfilInvsFromCompteGeneraleByDefault = contributionTypesFromCompteGenerale
                    .stream().map(structInvFromCompteGenerale::getContribution).filter(Objects::nonNull)
                             .flatMap(contributionInv -> contributionInv.getProfilsEtGrilles()
                                     .stream()
                                     .filter(pg -> (support.getId().equalsIgnoreCase(pg.getId()))))
                             .findFirst();

            if (grilleProfilInvsFromCompteGeneraleByDefault.isPresent()) {
                support.setCommonFields(grilleProfilInvsFromCompteGeneraleByDefault.get().getCommonFields());
                support.setTauxRepartition(
                        structInvMapper.buildTauxRepartition(grilleProfilInvsFromCompteGeneraleByDefault.get()));
                support.setDefaut(true);
            }

            supportsForVersement.add(support);
        }

        Optional<GrilleProfilInvDto> defaultLibre = supportsForVersement.stream()
                .filter(s -> s.isDefaut() &&
                        ModeGestionType.LIBRE.getCodeValue().equals(s.getCommonFields().getCodeModeGestion()))
                .findAny();
        if (defaultLibre.isPresent()) {
            supportsForVersement.forEach(s -> {
                if (s.isDefaut()
                        && !ModeGestionType.LIBRE.getCodeValue().equals(s.getCommonFields().getCodeModeGestion())) {
                    s.setDefaut(false);
                }
            });
        }
        gestionFinanciere.setGrillesProfilsNiveau1(supportsForVersement);

        return gestionFinanciere;
    }

    private boolean isFonctionnaliteBloque(ContratId contratId, FonctionnaliteType fct,
                                           InfosBlocagesClient blocagesClient) {
        return blocagesClient.isFonctionnaliteBloqueePourContrat(contratId.getNomContrat(), fct);
    }

    public ResponseDto<ModeVersementDto> reponseLibre(VersementContexteDto contexte, InfosBlocagesClient blocagesClient)
            throws TechnicalException {

        if (isFonctionnaliteBloque(contexte.getContratSelectionne(), FonctionnaliteType.VERSEMENT_LIBRE,
                                   blocagesClient)) {
            return ResponseDto.<ModeVersementDto>builder()
                    .id(VERSEMENT_LIBRE.name())
                    .disabled(true)
                    .warningMessage(MessageDto.builder()
                                            .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name())
                                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_LIBRE.name())
                    .build();
        }

        ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        ContratComplet contratComplet = contratFacade.recupererContratComplet(contratHeader);

        FiscaliteType fiscaliteType = FiscaliteType
                .getFiscaliteFromCode(contratComplet.getContratGeneral().getCodeCadreFiscal());

        final MontantPossibleDto montantPossible = versementGestionMontantService
                .retrieveMontantsPossibles(contratHeader, TypeVersement.VL);

        final boolean sigElecOff = isFonctionnaliteBloque(contexte.getContratSelectionne(),
                                                          FonctionnaliteType.SIGELEC_VERSEMENT_LIBRE, blocagesClient);

        final ParametreDto montantMinODF = paramConsoleFacade.getParametre(TYPE_ODF, "ODF", Annee.Courante)
                                                             .orElseThrow();

        ModeVersementDto modeVersementDto = ModeVersementDto.builder()
                .minMontantPossible(montantPossible.getMinMontantPossible())
                .maxMontantPossible(montantPossible.getMaxMontantPossible()).modeType(VERSEMENT_LIBRE)
                .sigElecOff(sigElecOff).montantMinODF(Integer.parseInt(montantMinODF.getValeur1()))
                .regleDeclenchementPJ(odfActivated ? buildReglesDeclenchementPJ(fiscaliteType) : new ArrayList<>())
                .afficherODF(odfActivated && contratHeader.isPacte() && !"LMO".equals(contratHeader.getCodeFiliale()))
                .build();
        return ResponseDto.<ModeVersementDto>builder()
                .id(VERSEMENT_LIBRE.name())
                .value(modeVersementDto)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_LIBRE.name())
                .build();
    }

    private List<RegleDeclenchementPieceJointe> buildReglesDeclenchementPJ(FiscaliteType fiscaliteType) {
        List<RegleDeclenchementPieceJointe> reglesPJ = new ArrayList<>();
        RegleDeclenchementPieceJointe regleCommuneGainJeu = RegleDeclenchementPieceJointe.builder()
                .declencher(true)
                .sommeNaturesODF(of(NatureOdfType.GAIN_JEU))
                .build();
        RegleDeclenchementPieceJointe regleCommuneAutres = RegleDeclenchementPieceJointe.builder()
                .declencher(true)
                .sommeNaturesODF(of(NatureOdfType.AUTRES))
                .build();

        if (FiscaliteType.PACTE.equals(fiscaliteType)) {
            // Regles PERO/PER
            RegleDeclenchementPieceJointe regleRevenu = RegleDeclenchementPieceJointe.builder()
                    .montantMinInvesti(BigDecimal.valueOf(42000))
                    .sommeNaturesODF(of(NatureOdfType.REVENU))
                    .build();

            List<NatureOdfType> patimoinesEtRevenu = new ArrayList<>(NatureOdfType.PATRIMOINES);
            patimoinesEtRevenu.add(NatureOdfType.EPARGNE);

            RegleDeclenchementPieceJointe reglePatrimoinesEtRevenu = RegleDeclenchementPieceJointe.builder()
                    .montantMinInvesti(BigDecimal.valueOf(42000))
                    .sommeNaturesODF(patimoinesEtRevenu)
                    .build();

            reglesPJ.addAll(of(regleRevenu, reglePatrimoinesEtRevenu, regleCommuneGainJeu, regleCommuneAutres));
        } else if (FiscaliteType.FISCMAD.equals(fiscaliteType)) {
            // Regles PERI
            RegleDeclenchementPieceJointe regleRevenu = RegleDeclenchementPieceJointe.builder()
                    .pourcentageMontantInvesti(50)
                    .sommeNaturesODF(of(NatureOdfType.REVENU))
                    .build();
            RegleDeclenchementPieceJointe reglePatrimoines = RegleDeclenchementPieceJointe.builder()
                    .pourcentageMontantInvesti(50)
                    .sommeNaturesODF(NatureOdfType.PATRIMOINES)
                    .build();
            RegleDeclenchementPieceJointe regleDon = RegleDeclenchementPieceJointe.builder()
                    .montantMinInvesti(BigDecimal.valueOf(15000))
                    .sommeNaturesODF(of(NatureOdfType.PATRIMOINE_DONATION))
                    .build();
            reglesPJ.addAll(of(regleRevenu, reglePatrimoines, regleDon, regleCommuneGainJeu, regleCommuneAutres));
        }

        return reglesPJ;
    }

    public ResponseDto<ModeVersementDto> reponseProgramme(VersementContexteDto contexte,
                                                          InfosBlocagesClient blocagesClient) throws TechnicalException {
        if (isFonctionnaliteBloque(contexte.getContratSelectionne(), FonctionnaliteType.VERSEMENT_PROGRAMME,
                                   blocagesClient)) {
            return ResponseDto.<ModeVersementDto>builder()
                    .id(VERSEMENT_PROGRAMME.name())
                    .disabled(true)
                    .warningMessage(MessageDto.builder()
                                            .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name())
                                            .build())
                    .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_PROGRAMME.name())
                    .build();
        }
        final ContratHeader contratHeader = contratFacade.rechercherContratParId(contexte.getContratSelectionne());
        final Compartiment compartiment = contratHeader.compartiment(contexte.getCompartimentSelectionne());

        final boolean sigElecOff = isFonctionnaliteBloque(contexte.getContratSelectionne(),
                                                          FonctionnaliteType.SIGELEC_VERSEMENT_PROGRAMME, blocagesClient);

        final MontantPossibleDto montantPossible = versementGestionMontantService
                .retrieveMontantsPossibles(contratHeader, TypeVersement.PO);

        ModeVersementDto modeVersementDto = ModeVersementDto.builder()
                .minMontantPossible(montantPossible.getMinMontantPossible())
                .maxMontantPossible(montantPossible.getMaxMontantPossible()).modeType(VERSEMENT_PROGRAMME)
                .sigElecOff(sigElecOff).versementProgramme(getVersementProgramme(compartiment)).build();
        return ResponseDto.<ModeVersementDto>builder()
                .id(VERSEMENT_PROGRAMME.name())
                .value(modeVersementDto)
                .jahiaDicoEntry(DictionnaireVersementJahia.VERSEMENT_PROGRAMME.name())
                .build();
    }

    @Override
    public boolean accept(QuestionType questionType, VersementContexteDto contexte) {
        return QuestionType.VERSEMENT_CHOIX_MODE_TYPE.equals(questionType) && contexte.getContratSelectionne() != null;
    }

    /**
     * Verifie s'il existe déjà une demande de versement programmé en ligne en cours
     * (demande dans le workflow ni clôturée, ni annulée).
     *
     * @return
     */
    private boolean hasDemandeWorkflowVersementProgrammeEncours() throws WorkflowException {
        String idPers = userContextHolder.get().getNumeroPersonneEre();
        return workflowFacade.hasDemandeEncours(idPers, DemandeWorkflowType.EXTRANET_VERREG);
    }

    private VersementProgrammeDto getVersementProgramme(Compartiment compartiment) throws TechnicalException {
        Echeancier echeancier = echeancierFacade.getProchainEcheancier(compartiment);
        if (echeancier != null && (echeancier.getDateFin() == null || echeancier.getDateFin().after(new Date()))) {
            ComparatorEcheancierSelonPrelevement comparator = new ComparatorEcheancierSelonPrelevement();
            final Prelevement prelevement = comparator.prochainPrelevementApresDateJour(echeancier);

            return VersementProgrammeDto.builder().montantActuel(echeancier.getMontant().intValue())
                                                  .minDateDebutPrelevement(VersementUtils.addDaysToDate(new Date(), delaiTeletransmission))
                                                  .frequence(FrequenceVirementType.forEcheancier(echeancier))
                                                  .datePremierVersement(prelevement != null ? prelevement.getDatePrelevement()
                                                                                : VersementUtils.addDaysToDate(new Date(), delaiTeletransmission))
                                                  .build();
        }
        return null;
    }

}
