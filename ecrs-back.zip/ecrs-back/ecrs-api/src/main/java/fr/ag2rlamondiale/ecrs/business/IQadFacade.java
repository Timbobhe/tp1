package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.qad.CodeProfilType;
import fr.ag2rlamondiale.trm.domain.qad.PropositionJson;
import fr.ag2rlamondiale.trm.domain.qad.QuestionJson;
import fr.ag2rlamondiale.trm.domain.qad.TypeProfilJson;
import fr.ag2rlamondiale.ecrs.dto.qad.QadRequestDto;
import fr.ag2rlamondiale.ecrs.dto.qad.QadResultDto;

import java.util.List;
import java.util.Set;

public interface IQadFacade {

    List<QuestionJson> getQadQuestRep(QadRequestDto dto) throws TechnicalException;

    List<PropositionJson> getPropositionParProduit(ContratHeader contratHeader);

    List<TypeProfilJson> getTypesProfilParProfils(Set<CodeProfilType> profils, Set<String> codesSupportsContrat);
    
    List<PropositionJson> getTypesPropositionGrille(QadResultDto qadResultDto) throws TechnicalException;


}
