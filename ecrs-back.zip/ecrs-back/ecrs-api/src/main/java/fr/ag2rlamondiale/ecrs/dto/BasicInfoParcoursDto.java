package fr.ag2rlamondiale.ecrs.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.HashMap;
import java.util.Map;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class BasicInfoParcoursDto {
    protected boolean isParcoursSimplifie;
    protected boolean sigElecOff;
    @Builder.Default
    protected JahiaContextDto contextJahia = new JahiaContextDto(false);
}
