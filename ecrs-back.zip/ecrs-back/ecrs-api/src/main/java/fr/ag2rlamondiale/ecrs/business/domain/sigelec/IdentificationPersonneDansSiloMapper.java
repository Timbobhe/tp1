package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationPersonneDansSiloType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", imports = {CodeApplicationType.class}, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class IdentificationPersonneDansSiloMapper {

    @Mapping(target = "identifiantDansSilo", source = "personPhysique.id")
    @Mapping(target = "libelleNomSilo", source = "contrat.codeSilo", qualifiedByName = "libelleNomSilo")
    @Mapping(target = "codeApplication", source = "contrat.codeSilo", qualifiedByName = "codeApplicationEgesper")
    @Mapping(target = "libelleApplication", source = "contrat.codeSilo", qualifiedByName = "libelleApplicationEgesper")
    @Mapping(target = "codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)
    public abstract IdentificationPersonneDansSiloType mapToIdentificationPersonneDansSilo(DemandeCreationSigElec demande);

    @Named("libelleNomSilo")
    protected String libelleNomSilo(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getLibelle();
    }

    @Named("codeApplicationEgesper")
    protected String codeApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getCode();
    }

    @Named("libelleApplicationEgesper")
    protected String libelleApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getLibelle();
    }
}
