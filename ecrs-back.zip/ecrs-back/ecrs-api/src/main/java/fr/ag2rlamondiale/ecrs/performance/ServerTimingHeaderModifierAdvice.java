package fr.ag2rlamondiale.ecrs.performance;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

/**
 * https://w3c.github.io/server-timing/
 *
 * <pre>
 * This section is non-normative.
 *
 * EXAMPLE 1
 * > GET /resource HTTP/1.1
 * > Host: example.com
 *
 *
 * < HTTP/1.1 200 OK
 * < Server-Timing: miss, db;dur=53, app;dur=47.2
 * < Server-Timing: customView, dc;desc=atl
 * < Server-Timing: cache;desc="Cache Read";dur=23.2
 * < Trailer: Server-Timing
 * < (... snip response body ...)
 * < Server-Timing: total;dur=123.4
 * Name	Duration	Description
 * miss
 * db	53
 * app	47.2
 * customView
 * dc		atl
 * cache	23.2	Cache Read
 * total	123.4
 * The above header fields communicate six distinct metrics that illustrate all the possible ways for the server to communicate data to the user agent: metric name only, metric with value, metric with value and description, and metric with description. For example, the above metrics may indicate that for example.com/resource.jpg fetch:
 *
 * There was a cache miss.
 * The request was routed through the "atl" datacenter ("dc").
 * The database ("db") time was 53 ms.
 * A cache read took 23.2 ms.
 * The application server ("app") took 47.2ms to process "customView" template or function.
 * The total time for the request-response cycle on the server was 123.4ms, which is recorded at the end of the response and delivered via a trailer field.
 * </pre>
 */
@Slf4j
@ControllerAdvice({"fr.ag2rlamondiale"})
public class ServerTimingHeaderModifierAdvice implements ResponseBodyAdvice<Object>, InitializingBean, IServerTimingSupport {

    public static final String HEADER_NAME_REQ_SERVER_TIME = "Server-Timing";

    @Setter
    @Getter
    @Value("${server-timing.header.active:true}")
    private boolean active;

    @Setter
    @Getter
    @Value("${server-timing.header.name:rsb}")
    private String serverName;

    @Override
    public boolean supports(MethodParameter returnType, Class<? extends HttpMessageConverter<?>> converterType) {
        return true;
    }

    @Override
    public Object beforeBodyWrite(Object body, MethodParameter returnType, MediaType selectedContentType, Class<? extends HttpMessageConverter<?>> selectedConverterType, ServerHttpRequest request, ServerHttpResponse response) {
        if (active && request instanceof ServletServerHttpRequest) {
            ServletServerHttpRequest req = (ServletServerHttpRequest) request;
            final Long start = (Long) req.getServletRequest().getAttribute(ATTRIBUTE_NAME_START_REQ_TIME);
            if (start != null) {
                long time = System.currentTimeMillis() - start;
                response.getHeaders().add(HEADER_NAME_REQ_SERVER_TIME, serverName + ";dur=" + time);
                if (log.isDebugEnabled()) {
                    log.debug("{} {}\t{} ms", req.getURI(), HEADER_NAME_REQ_SERVER_TIME, time);
                }
            }

        }
        return body;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("server-timing.header.active={}", active);
        log.info("server-timing.header.name={}", serverName);
    }
}
