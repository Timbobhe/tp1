package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.ecrs.business.ICaptchaFacade;
import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseDto;
import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;

@Slf4j
@Service
public class CaptchaFacadeImpl implements ICaptchaFacade, InitializingBean {

    @Value("${google.recaptcha.secret.key:6Ldgm-EUAAAAAPoYUDiiR0HIM9pX1rc3g4Nv5AOw}")
    public String recaptchaSecret;

    @Value("${google.recaptcha.verify.url:https://www.google.com/recaptcha/api/siteverify}")
    public String recaptchaVerifyUrl;

    @Value("${google.proxy.active:false}")
    private boolean proxyActive;

    @Value("${google.proxy.host:192.168.230.5}")
    private String proxyHost;

    @Value("${google.proxy.port:8080}")
    private int proxyPort;

    @Autowired
    private RestTemplate restTemplate;

    private RestTemplate proxyRestTemplate;

    @Override
    public VerificationCaptchaResponseDto verifyToken(String token) {
        VerificationCaptchaResponseDto res = new VerificationCaptchaResponseDto();
        if (!isValid(token)) {
            res.setMessage("Invalid captcha");
            res.setStatus(400);
            return res;
        }
        res.setMessage("Success");
        res.setStatus(200);
        return res;
    }

    public boolean isValid(String response) {
        MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
        param.add("secret", recaptchaSecret);
        param.add("response", response);
        VerificationCaptchaResponseJson v;
        try {
            v = restTemplate().postForObject(recaptchaVerifyUrl, param, VerificationCaptchaResponseJson.class);
        } catch (Exception e) {
            throw new RestClientException("Can't verify the token", e);
        }
        return (v != null && v.getSuccess() != null && v.getSuccess());
    }


    public RestTemplate restTemplate() {
        if (!proxyActive) {
            return restTemplate;
        }
        return proxyRestTemplate;
    }


    @Override
    public void afterPropertiesSet() {
        log.info("Captcha Google proxyActive = {}, proxyHost = {}, proxyPort = {}", proxyActive, proxyHost, proxyPort);
        if (proxyActive) {
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            Proxy proxy = new Proxy(Proxy.Type.HTTP, InetSocketAddress.createUnresolved(proxyHost, proxyPort));
            requestFactory.setProxy(proxy);
            this.proxyRestTemplate = new RestTemplate(requestFactory);
        }
    }
}
