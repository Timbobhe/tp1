package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import lombok.Getter;

@Getter
public enum DictionnaireSimulateurFiscalJahia {

    SIMULATEUR_FISCAL_BLOCAGE_ETAT_CONTRAT("L\u2019\u00E9tat de ce compte de retraite ne vous permet pas de r\u00E9aliser une simulation."),
    SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT("Les conditions de votre contrat ne vous permettent pas d'accéder à cette fonctionnalité.");

    private final String label;

    DictionnaireSimulateurFiscalJahia(String label) {
        this.label = label;
    }
}
