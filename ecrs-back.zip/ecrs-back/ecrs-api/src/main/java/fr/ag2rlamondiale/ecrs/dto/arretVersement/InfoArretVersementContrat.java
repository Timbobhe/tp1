package fr.ag2rlamondiale.ecrs.dto.arretVersement;

import java.util.List;

import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class InfoArretVersementContrat extends BasicInfoParcoursDto {
    private ContratParcoursDto contrat;
    private List<ArretVersementDto> arretVersements;
    private boolean bloque;
    private MessageDto raisonBlocage;
    private SigElecJson demandeExistante;
}
