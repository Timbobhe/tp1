package fr.ag2rlamondiale.ecrs.dto.evenement;

import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.Getter;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

import static fr.ag2rlamondiale.trm.domain.evenement.TypeEven.*;

@Getter
public enum TypologieAffichageEven {
    POPIN(CGU, PND3, PND1),
    INDISPO(INDISPO_ERE, INDISPO_MDP),
    OBJECTIF(CONFIRMATION_DONNEES_PERSO, VALIDATION_PERIODIQUE_DONNEES_PERSO);

    private final Set<TypeEven> typesEven;

    TypologieAffichageEven(TypeEven... typesEven) {
        this.typesEven = new HashSet<>(Arrays.asList(typesEven));
    }

    public Predicate<TypeEvenementJson> toPredicate() {
        return typeEvenementJson -> typesEven.stream().map(TypeEven::getCode).anyMatch(code -> code.equals(typeEvenementJson.getCodeEvenement()));
    }
}
