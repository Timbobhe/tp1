package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.arbitrage.ArbitrageQuestionResolver;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.Date;
import java.util.function.Consumer;

public interface IArbitrageFacade {
    ArbitrageStartDto startModificationArbitrage(ParamFluxStock paramFluxStock) throws TechnicalException;

    <T> QuestionResponsesDto<T, Object> resolveQuestion(RequestQuestionArbitrageDto request) throws TechnicalException;

    /**
     * Traite la question courante puis, si elle n'est pas affichable, la suivante affichable.<br>
     * Le {@link ArbitrageQuestionResolver} met à jour le Contexte avec {@link ArbitrageContexteDto#update(Consumer)} pour simuler la MAJ du contexte depuis le Front.
     *
     * @param request
     * @return
     * @throws TechnicalException
     */
    ListQuestionResponsesDto resolveQuestionOrNext(RequestQuestionArbitrageDto request) throws TechnicalException;

    String terminate(ArbitrageTerminateDto arbitrageTerminateDto, boolean isFrame) throws TechnicalException, IOException, JAXBException;

    boolean isArbitrageEnLigneInterdit(ContratComplet contratComplet);

    boolean isNbeArbitrageAnnReachedERE(ContratComplet contratComplet) throws TechnicalException;

    Date getNewDateForArbitragePossible();

    boolean isArbitrageEnAttenteValorisationERE(ContratComplet contratComplet) throws TechnicalException;

    boolean isAssureOrSouscripteurMajeur(ContratGeneral contratGeneral);

    boolean isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(ContratComplet contratComplet);

    boolean isCompteEpargneAssureLibereOrEnCoursMDPRO(ContratHeader contratHeader);

    ResultParcoursEffectueDto arbitrageContratEnCoursERE(ContratHeader contratHeader);

    boolean isMonoSupport(ContratHeader contrat);

    boolean isPartsNonArbitrablesERE(ContratHeader contrat);
}
