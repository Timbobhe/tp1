package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ErePND1EvenGenerator extends ErePNDEvenGenerator {
    @Autowired
    private IWorkflowFacade workflowFacade;
    
    @Override
    protected String getTypePND() {
        return "PND1";
    }

    @Override
    public boolean retour(PersonnePhysiqueConsult pp, String idPers) throws WorkflowException {
        return pp.isNpai() && !pp.isPndDefinitif() && !workflowFacade.hasDemandeMdpEncours(idPers);
    }
}
