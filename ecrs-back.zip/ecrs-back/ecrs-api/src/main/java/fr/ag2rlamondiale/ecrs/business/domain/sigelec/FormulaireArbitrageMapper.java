package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import fr.ag2rlamondiale.formulaire.actesenligne.*;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.*;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Mapper(componentModel = "spring", uses = {DateMapper.class}, imports = {StringUtils.class, CodeApplicationType.class})
public abstract class FormulaireArbitrageMapper implements IFormulaireMapper {
    @Autowired
    private OccurenceStructureInvestissementTypeMapper occurenceStructureInvestissementTypeMapper;

    @Mapping(target = "instantInitialisationDemande", expression = "java(fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper.today())")

    @Mapping(target = "identificationContratDansSilo.identifiantDansSilo", source = "contrat.id")
    @Mapping(target = "identificationContratDansSilo.libelleNomSilo", source = "contrat.codeSilo", qualifiedByName = "libelleNomSilo")
    @Mapping(target = "identificationContratDansSilo.codeApplication", source = "contrat.codeSilo", qualifiedByName = "codeApplication")
    @Mapping(target = "identificationContratDansSilo.libelleApplication", source = "contrat.codeSilo", qualifiedByName = "libelleApplication")
    @Mapping(target = "identificationContratDansSilo.codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationContratDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationUserDansSilo.identifiantDansSilo", source = "idGdi")
    @Mapping(target = "identificationUserDansSilo.libelleNomSilo", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationUserDansSilo.codeApplication", expression = "java(fr.ag2rlamondiale.trm.domain.CodeApplicationType.ECRS.getCode())")
    @Mapping(target = "identificationUserDansSilo.libelleApplication", constant = FormulaireConstantes.ESPACE_CLIENT_PARTICULIER_ERE)
    @Mapping(target = "identificationUserDansSilo.codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationUserDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationPersonneDansSilo.identifiantDansSilo", source = "personPhysique.id")
    @Mapping(target = "identificationPersonneDansSilo.libelleNomSilo", source = "contrat.codeSilo", qualifiedByName = "libelleNomSilo")
    @Mapping(target = "identificationPersonneDansSilo.codeApplication", source = "contrat.codeSilo", qualifiedByName = "codeApplicationEgesper")
    @Mapping(target = "identificationPersonneDansSilo.libelleApplication", source = "contrat.codeSilo", qualifiedByName = "libelleApplicationEgesper")
    @Mapping(target = "identificationPersonneDansSilo.codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationPersonneDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationDemandeDansSilo.identifiantDansSilo", source = "idDemandeWkf")
    @Mapping(target = "identificationDemandeDansSilo.libelleNomSilo", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationDemandeDansSilo.libelleApplication", source = "contrat.codeSilo", qualifiedByName = "libelleApplication")
    @Mapping(target = "identificationDemandeDansSilo.codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "identificationDemandeDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "informationsComplementaires.signaletiquePP.nom", source = "personPhysique.nom")
    @Mapping(target = "informationsComplementaires.signaletiquePP.prenom", source = "personPhysique.prenom")
    @Mapping(target = "informationsComplementaires.signaletiquePP.dateNaissance", source = "personPhysique.dateDeNaissance")
    @Mapping(target = "informationsComplementaires.signaletiquePP.libelleCivilite", source = "personPhysique.civilite")

    @Mapping(target = "informationsComplementaires.dossiersCommunication.emails.libelleEmail", source = "personPhysique.emailPro")

    @Mapping(target = "informationsComplementaires.informationsContrat.raisonSociale", source = "contrat.raisonSocialeFront")
    @Mapping(target = "informationsComplementaires.informationsContrat.numeroExterneContrat", source = "contrat.id")
    @Mapping(target = "informationsComplementaires.informationsContrat.libelleCategoriePersonnel", source = "contrat.college")
    @Mapping(target = "informationsComplementaires.liensPersonnes.libelleTypeLienPersonnes", constant = "")

    @Mapping(target = "informationsComplementaires.proprietesSignature.dossierSignature.codeApplicationEmettrice", expression = "java(CodeApplicationType.ECRS.getCode())")

    @Mapping(target = "arbitrageFlux", source = "demande", qualifiedByName = "mapArbitrageFlux")
    @Mapping(target = "arbitrageStock", source = "demande", qualifiedByName = "mapArbitrageStock")

    @Mapping(target = "encoursEpargne", source = "demande", qualifiedByName = "mapRepartitionStructureInvestissement")
    public abstract FormulaireArbitrage createFormulaireArbitrage(DemandeCreationsigElecArbitrage demande);

    @Named("codeApplication")
    protected String codeApplication(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getCode();
    }

    @Named("libelleNomSilo")
    protected String libelleNomSilo(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getLibelle();
    }

    @Named("codeApplicationEgesper")
    protected String codeApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getCode();
    }

    @Named("libelleApplicationEgesper")
    protected String libelleApplicationEgesper(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getLibelle();
    }

    @Named("libelleApplication")
    protected String libelleApplication(CodeSiloType codeSiloType) {
        return CodeSiloType.ERE.equals(codeSiloType) ? FormulaireConstantes.PTV : FormulaireConstantes.GESTION_8X;
    }

    @Named("mapArbitrageFlux")
    public ArbitrageFluxType createArbitrageFlux(DemandeCreationsigElecArbitrage demandeCreationsigElecArbitrage) {
        ArbitrageFluxType arbitrageFluxType = new ArbitrageFluxType();
        if (demandeCreationsigElecArbitrage.getResponseArbitrageFluxStock().isFlux()) {
            arbitrageFluxType.setRepartitionSupportFuture(mapSupportFinancierDtoToStructureInvestissementType(
                    demandeCreationsigElecArbitrage.getNewRepartition(), null));
        }
        return arbitrageFluxType;
    }

    @Named("mapArbitrageStock")
    public ArbitrageStockType createArbitrageStock(DemandeCreationsigElecArbitrage demandeCreationsigElecArbitrage) {
        ArbitrageStockType arbitrageStockType = new ArbitrageStockType();
        if (demandeCreationsigElecArbitrage.getResponseArbitrageFluxStock().isStock()) {
            arbitrageStockType.setMontantTotal(demandeCreationsigElecArbitrage.getMontant());
            arbitrageStockType.setDeviseTotal(demandeCreationsigElecArbitrage.getDeviseEncours());
            arbitrageStockType.setDateValeurTotal(DateUtils.dateTimeToXmlCalendar(demandeCreationsigElecArbitrage.getDateEncours()));

            if (demandeCreationsigElecArbitrage.getDesinvestissementRepartition().isEmpty()) {
                arbitrageStockType.setRepartitionSupportADesinvestir(mapSupportFinancierDtoToStructureInvestissementType
                        (demandeCreationsigElecArbitrage.getOldRepartition(), demandeCreationsigElecArbitrage.getMontant()));
            } else {
                arbitrageStockType.setRepartitionSupportADesinvestir(mapSupportFinancierDtoToStructureInvestissementType
                        (demandeCreationsigElecArbitrage.getDesinvestissementRepartition(), demandeCreationsigElecArbitrage.getMontant()));
            }


            arbitrageStockType.setRepartitionSupportAInvestir(mapSupportFinancierDtoToStructureInvestissementType(
                    demandeCreationsigElecArbitrage.getNewRepartition(), null));
        }
        return arbitrageStockType;
    }

    private void setStructureInvestissementTypeFromListSupportFinancier(BigDecimal montant, StructureInvestissementType structInvAInvestir, IdentificationStructureInvestissementType identificationStructureinvestissement, Map<ContributionInv, List<SupportFinancierDto>> supportArbitrageDtoMap) {
        if (!supportArbitrageDtoMap.isEmpty()) {
            for (Map.Entry<ContributionInv, List<SupportFinancierDto>> entry : supportArbitrageDtoMap.entrySet()) {
                final ContributionInv contributionInv = entry.getKey();
                final List<SupportFinancierDto> supportFinancierDtoList = entry.getValue();

                identificationStructureinvestissement.setIdentifiantStructureInvestissement(contributionInv.getCommonFields().getParentId());

                structInvAInvestir.setIdentificationStructureInvestissement(identificationStructureinvestissement);

                addParentToSupportList(structInvAInvestir, contributionInv);

                addChildrenToSupportList(montant, structInvAInvestir, supportFinancierDtoList);
            }
        }
    }

    private void addParentToSupportList(StructureInvestissementType structInvAInvestir, ContributionInv contributionInv) {
        structInvAInvestir.getOccurenceStructureInvestissement()
                .add(occurenceStructureInvestissementTypeMapper
                        .mapContributionInvToOccurenceStructureInvestissementType(contributionInv, null));
    }

    private void addChildrenToSupportList(BigDecimal montant, StructureInvestissementType structInvAInvestir, List<SupportFinancierDto> supportFinancierDtoList) {
        supportFinancierDtoList.forEach(supportFinancierDto -> structInvAInvestir.getOccurenceStructureInvestissement()
                .add(occurenceStructureInvestissementTypeMapper
                        .mapSupportFinancierDtoToOccurenceStructureInvestissementType(supportFinancierDto,
                                montant)));
    }

    private void groupSupportByCompartiment(List<SupportFinancierDto> supportsAInvestir, Map<ContributionInv, List<SupportFinancierDto>> supportArbitrageDtoMap) {
        supportsAInvestir.forEach(supportFinancierDto -> {
            ContributionInv contributionInvParent = supportFinancierDto.getContributionInvParent();
            contributionInvParent.setIdAssureCompartiment(supportFinancierDto.getIdAssureCompartiment());
            if (!supportArbitrageDtoMap.containsKey(contributionInvParent)) {
                supportArbitrageDtoMap.put(contributionInvParent, new ArrayList<>());
            }
            supportArbitrageDtoMap.get(contributionInvParent).add(supportFinancierDto);
        });
    }


    public StructureInvestissementType mapSupportFinancierDtoToStructureInvestissementType(List<SupportFinancierDto> supports, BigDecimal montant) {
        StructureInvestissementType structureInvestissementType = new StructureInvestissementType();
        IdentificationStructureInvestissementType identificationStructureinvestissement = new IdentificationStructureInvestissementType();
        if (CollectionUtils.isNotEmpty(supports)) {
            Map<ContributionInv, List<SupportFinancierDto>> supportArbitrageDtoMap = new HashMap<>();

            groupSupportByCompartiment(supports, supportArbitrageDtoMap);

            setStructureInvestissementTypeFromListSupportFinancier(montant, structureInvestissementType, identificationStructureinvestissement, supportArbitrageDtoMap);
        }
        return structureInvestissementType;
    }

    @Named("mapRepartitionStructureInvestissement")
    public EncoursEpargneType createRepartitionStructureInvestissement(DemandeCreationsigElecArbitrage dto) {
        EncoursEpargneType encoursEpargneType = new EncoursEpargneType();
        encoursEpargneType.setRepartitionSupportSouscrit(
                mapSupportFinancierDtoToStructureInvestissementType(dto.getOldRepartition(), null));
        return encoursEpargneType;
    }

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireArbitrage formulaireArbitrage = this.createFormulaireArbitrage((DemandeCreationsigElecArbitrage) demandeSigElec);
        if (CodeSiloType.ERE.equals(demandeSigElec.getCodeSilo())
                && formulaireArbitrage.getIdentificationContratDansSilo() != null) {
            formsMap.put(getCle(
                            formulaireArbitrage.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                            formulaireArbitrage.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                            formulaireArbitrage.getIdentificationAffiliationDansSilo() != null ? formulaireArbitrage.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo() : null),
                    XmlMarshallerUtils.marshallFormArbitrage(formulaireArbitrage));

        } else if (CodeSiloType.MDP.equals(demandeSigElec.getCodeSilo())
                && formulaireArbitrage.getIdentificationContratDansSilo() != null && formulaireArbitrage.getIdentificationPersonneDansSilo() != null) {
            formsMap.put(getCle(
                            formulaireArbitrage.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                            formulaireArbitrage.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                            formulaireArbitrage.getIdentificationPersonneDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormArbitrage(formulaireArbitrage));
        }
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget FormulaireArbitrage target, DemandeCreationsigElecArbitrage demande) {
        if (CodeSiloType.ERE.equals(demande.getCodeSilo()) && !demande.isPacte()) {
            IdentificationDansSiloType identificationDansSiloType = new IdentificationDansSiloType();
            identificationDansSiloType.setIdentifiantDansSilo(demande.getIdentifiantAssure());
            identificationDansSiloType.setLibelleNomSilo(FormulaireConstantes.ERE_PTV2_3);
            identificationDansSiloType.setCodeApplication(CodeApplicationType.PTV_ERE.getCode());
            identificationDansSiloType.setLibelleApplication(FormulaireConstantes.PTV);
            identificationDansSiloType.setCodeSystemeInformation(FormulaireConstantes.ERE);
            identificationDansSiloType.setLibelleSystemeInformation(FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER);
            target.setIdentificationAffiliationDansSilo(identificationDansSiloType);
        }
    }
}
