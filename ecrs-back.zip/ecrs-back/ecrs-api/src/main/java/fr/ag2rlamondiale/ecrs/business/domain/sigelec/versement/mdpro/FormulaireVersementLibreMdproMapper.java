package fr.ag2rlamondiale.ecrs.business.domain.sigelec.versement.mdpro;

import fr.ag2rlamondiale.ecrs.business.impl.XmlMarshallerUtils;
import fr.ag2rlamondiale.ecrs.dto.versement.RibStatusType;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.FormulaireVersementLibre;
import fr.ag2rlamondiale.formulaire.formulaireversementlibre.IdentificationDansSiloType;
import fr.ag2rlamondiale.formulaire.modificationcoordonneesbancaires.FormulaireModificationCoordonneesBancaires;
import fr.ag2rlamondiale.rib.domain.sigelec.FormulaireModificationCoordonneesBancairesMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.IFormulaireMapper;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.Map;

@Mapper(componentModel = "spring",
        uses = {DateMapper.class, IdentificationContratDansSiloMdproMapper.class,
                IdentificationUserDansSiloMdproMapper.class, IdentificationPersonneDansSiloMdproMapper.class,
                IdentificationDemandeDansSiloMdproMapper.class, InformationsComplementairesMdproMapper.class},
        imports = {StringUtils.class, DateMapper.class})
public abstract class FormulaireVersementLibreMdproMapper extends FormulaireVersementMdproMapper implements IFormulaireMapper {

    @Autowired
    FormulaireModificationCoordonneesBancairesMapper formRIBMapper;

    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today().toString())")
    @Mapping(target = "identificationContratDansSilo", source = "contrat", qualifiedByName = "mapIdentificationContratDansSilo")
    @Mapping(target = "identificationUserDansSilo", source = ".", qualifiedByName = "mapIdentificationUserDansSilo")
    @Mapping(target = "identificationPersonneDansSilo", source = ".", qualifiedByName = "mapIdentificationPersonneDansSilo")
    @Mapping(target = "identificationDemandeDansSilo", source = ".", qualifiedByName = "mapIdentificationDemandeDansSilo")
    @Mapping(target = "informationsComplementaires", source = "demande")
    @Mapping(source = "demande", target = "versement", qualifiedByName = "mapVersement")
    @Mapping(source = "demande", target = "structureInvestissement", qualifiedByName = "mapStructureInvestissementType")
    public abstract FormulaireVersementLibre createFormulaireVersementLibre(DemandeCreationSigElecVersementLibreMdpro demande);

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        final FormulaireVersementLibre formVRLI = this.createFormulaireVersementLibre((DemandeCreationSigElecVersementLibreMdpro) demandeSigElec);

        this.afterMapping(formVRLI, (DemandeCreationSigElecVersementLibreMdpro) demandeSigElec);
        if (CodeSiloType.ERE.equals(demandeSigElec.getCodeSilo())
                && formVRLI.getIdentificationContratDansSilo() != null && formVRLI.getIdentificationAffiliationDansSilo() != null) {
            formsMap.put(getCle(
                    formVRLI.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    formVRLI.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    formVRLI.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementLibreV7(formVRLI));
        } else if (CodeSiloType.MDP.equals(demandeSigElec.getCodeSilo())
                && formVRLI.getIdentificationContratDansSilo() != null && formVRLI.getIdentificationPersonneDansSilo() != null ) {
            formsMap.put(getCle(
                    formVRLI.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    CodeSiloType.MDP.getLibelle(),
                    formVRLI.getIdentificationPersonneDansSilo().getIdentifiantDansSilo()),
                    XmlMarshallerUtils.marshallFormVersementLibreV7(formVRLI));

            if(RibStatusType.NEW.equals(((DemandeCreationSigElecVersementLibreMdpro) demandeSigElec).getRibStatusType())) {
                final FormulaireModificationCoordonneesBancaires form = formRIBMapper.createFormulaireModifDonneesBancaires(((DemandeCreationSigElecVersementLibreMdpro) demandeSigElec).getFormulaireModificationCoordonneesBancairesDto());
                formsMap.put(getCle(
                        form.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                        form.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                        formVRLI.getIdentificationPersonneDansSilo().getIdentifiantDansSilo(),
                        OperationType.RIBA.name()),
                        marshallFormModificationDonneesBancaires(form));
            }
        }
    }

    private String marshallFormModificationDonneesBancaires(FormulaireModificationCoordonneesBancaires form) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(FormulaireModificationCoordonneesBancaires.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        StringWriter sw = new StringWriter();
        marshaller.marshal(form, sw);
        return sw.toString();
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget FormulaireVersementLibre target, DemandeCreationSigElecVersementLibreMdpro demande) {
        if (CodeSiloType.ERE.equals(demande.getCodeSilo())) {
            IdentificationDansSiloType identificationAffiliationDansSiloType = new IdentificationDansSiloType();
            identificationAffiliationDansSiloType.setIdentifiantDansSilo(demande.getIdentifiantAssure());
            identificationAffiliationDansSiloType.setLibelleNomSilo(FormulaireConstantes.ERE_PTV2_3);
            identificationAffiliationDansSiloType.setCodeApplication(CodeApplicationType.PTV_ERE.getCode());
            identificationAffiliationDansSiloType.setLibelleApplication(FormulaireConstantes.PTV);
            identificationAffiliationDansSiloType.setCodeSystemeInformation(FormulaireConstantes.ERE);
            identificationAffiliationDansSiloType.setLibelleSystemeInformation(FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER);
            target.setIdentificationAffiliationDansSilo(identificationAffiliationDansSiloType);
        }
    }
}
