package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IClausesBenefCtrFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.*;

@Component
public class ModificationClauseBeneficiaireAccessibilitySupplier implements IFunctionalityAccessibilitySupplier {

    @Autowired
    private IClausesBenefCtrFacade clausesBenefCtrFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Override
    public boolean accept(fr.ag2rlamondiale.trm.domain.FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.MODIFICATION_CLAUSE_BENEFICIAIRE.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto check() throws TechnicalException {
        AccesFonctionnaliteDto accesFonctionnaliteDto = new AccesFonctionnaliteDto(FonctionnaliteType.MODIFICATION_CLAUSE_BENEFICIAIRE);
        boolean hasContractsForModificationClauseBeneficiaire = !clausesBenefCtrFacade.retrieveContractsforModificationClauseBeneficiaire().isEmpty();
        boolean hasDemandeMdpEncours = hasDemandeMdpEncours();
        boolean isAccessible = userContextHolder.get().isHasContratEre() && hasContractsForModificationClauseBeneficiaire && !hasDemandeMdpEncours;
        accesFonctionnaliteDto.setAccessible(isAccessible);

        if (!isAccessible) {
            if (!hasContractsForModificationClauseBeneficiaire) {
                accesFonctionnaliteDto.setRaison(CLAUSE_BENEF_ACCES_IMPOSSIBLE.name());
            } else if (!userContextHolder.get().isHasContratEre()) {
                accesFonctionnaliteDto.setRaison(BLOCAGE_BIA_MONO_EQUIPE_MDPRO.name());
            } else if (hasDemandeMdpEncours) {
                accesFonctionnaliteDto.setRaison(BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS.name());
            } else {
                accesFonctionnaliteDto.setRaison(BLOCAGE_MODIFICATION_CLAUSE_BENEFICIAIRE_EN_COURS.name());
            }
        }
        return accesFonctionnaliteDto;
    }

    private boolean hasDemandeMdpEncours() throws WorkflowException {
        if (userContextHolder.get().getNumeroPersonneEre() != null) {
            return workflowFacade.hasDemandeMdpEncours(userContextHolder.get().getNumeroPersonneEre());
        }
        return false;
    }
}
