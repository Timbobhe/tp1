package fr.ag2rlamondiale.ecrs.mapping;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import fr.ag2rlamondiale.ecrs.dto.versementsynthese.OperationVersementDto;
import fr.ag2rlamondiale.trm.domain.operation.Operation;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class OperationToOperationVersementDtoMapper {

    @Mapping(source = "montant", target = "montant")
    @Mapping(source = "date", target = "dateOperation")
    @Mapping(source = "id", target = "operationId")
    @Mapping(source = "codeTypeOperation", target = "typeOperation")
    public abstract OperationVersementDto operationToDto(Operation op);

    @AfterMapping
    protected void completeInfosOperation(@MappingTarget OperationVersementDto operation) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate today = LocalDate.now();
        Date dateAvant3Mois = Date.from(today.minus(3, ChronoUnit.MONTHS).atStartOfDay(defaultZoneId).toInstant());
        if (operation.getDateOperation().after(dateAvant3Mois)) {
            operation.setOperationDerniers3Mois(true);
        }
    }
}
