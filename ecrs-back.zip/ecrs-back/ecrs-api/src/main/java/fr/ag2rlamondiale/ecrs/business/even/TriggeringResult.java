package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TriggeringResult {
    private String idGdi;
    private String numPersonne;
    private TypeEvenementJson typeEvenement;
    private ContratHeader contrat;

    private AbstractEvenGenerator generator;
}
