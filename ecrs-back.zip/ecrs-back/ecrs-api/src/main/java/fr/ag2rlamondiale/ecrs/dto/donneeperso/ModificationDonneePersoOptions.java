package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import lombok.Data;

import java.util.List;

@Data
public class ModificationDonneePersoOptions {
    List<String> departementOptions;
    List<String> situationFamilialeOption;
    List<String> paysOptions;
}
