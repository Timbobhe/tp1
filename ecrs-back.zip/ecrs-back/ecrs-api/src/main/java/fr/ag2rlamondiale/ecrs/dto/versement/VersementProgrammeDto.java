package fr.ag2rlamondiale.ecrs.dto.versement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VersementProgrammeDto {
    private Integer montantActuel;
    private FrequenceVirementType frequence;
    private Date minDateDebutPrelevement;
    private Date datePremierVersement;
    private Date dateFinVersement; //TODO utilit&eacute; de cette variable ??
}
