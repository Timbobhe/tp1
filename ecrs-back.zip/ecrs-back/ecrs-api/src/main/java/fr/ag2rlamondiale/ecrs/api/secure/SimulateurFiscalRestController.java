package fr.ag2rlamondiale.ecrs.api.secure;

import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.ISimulateurFiscalFacade;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;


@RestController
@RequestMapping(path = "/secure")
public class SimulateurFiscalRestController {
    @Autowired
    ISimulateurFiscalFacade simulateurFiscalFacade;

    @ProfileExecution(codeAction = CodeActionType.API_SIMULATEUR_START)
    @LogExecutionTime
    @GetMapping(path = "/simulateur-fiscal/start")
    public SimulateurStartDto start() throws TechnicalException {
        return simulateurFiscalFacade.startSimulateur();
    }

    @Secure
    @LogExecutionTime
    @PostMapping(path = "/simulateur-fiscal/calcul-disponible-fiscal")
    public ResultatCalculEpargne calculerDisponibleFiscal(
            @RequestBody
            @SecuredParam(paramType = SecurityParamType.CONTRAT)
            DemandeCalculEpargne demande) throws TechnicalException {
        return simulateurFiscalFacade.calculerDisponibleFiscal(demande);
    }

}
