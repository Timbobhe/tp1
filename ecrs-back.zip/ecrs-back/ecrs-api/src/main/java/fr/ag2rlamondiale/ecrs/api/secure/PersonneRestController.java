package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.domain.SujetConstants;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.ecrs.business.IClientFacade;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.dto.personne.GetCoordonneesClientDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_COORDONNEES_CLIENT_CLEARCACHE;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_COORDONNEES_CLIENT_GET;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_COORDONNEES_CLIENT_UPDATE;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_COORDONNEES_CLIENT_VALIDATE;

@RestController
@RequestMapping(path = "/secure")
public class PersonneRestController {

    @Autowired
    private IClientFacade clientFacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private IEvenementFacade evenementFacade;

    @ProfileExecution(codeAction = API_COORDONNEES_CLIENT_UPDATE)
    @LogExecutionTime
    @PutMapping(path = "/coordonnees-client")
    public ModifierPPSiloResponseDto modifierCoordonneesClient(@RequestBody CoordonneesClientDto coordonneesClientDto) throws TechnicalException {
        return clientFacade.modifierCoordonneesClient(coordonneesClientDto);
    }

    @ProfileExecution(codeAction = API_COORDONNEES_CLIENT_GET)
    @LogExecutionTime
    @PostMapping(path = "/coordonnees-client")
    public CoordonneesClientDto getCoordonneesClient(@RequestBody GetCoordonneesClientDto param) throws CommonException {
        // On force l'éviction du cache pour la récupération des coordonnees du client depuis le Front
        // faute de mieux (visiblement la stratégie qui consiste à appeler clear-cache n'a pas suffit
        // peut-être à cause d'un changement de Container, ... au moins c'est sûr là
        if (!param.isKeepMdproData()) {
            consulterPersPhysFacade.forceCacheEvictConsulterPersPhys();
        }
        return consulterPersPhysFacade.getCoordonneesClient(param);
    }

    @ProfileExecution(codeAction = API_COORDONNEES_CLIENT_CLEARCACHE)
    @LogExecutionTime
    @GetMapping(path = "/coordonnees-client/clear-cache")
    public void clearCacheCoordonneesClient() {
//        consulterPersPhysFacade.forceCacheEvictConsulterPersPhys();
    }

    @ProfileExecution(codeAction = API_COORDONNEES_CLIENT_VALIDATE)
    @LogExecutionTime
    @PostMapping(path = "/coordonnees-client/validate")
    public void validateCoordonneesClient(@RequestBody LectureSujetDto lectureSujet) throws TechnicalException {
        if (FonctionnaliteType.MODIFDONNEESPERSO.getLabel().equals(lectureSujet.getUrl())) {
            if (SujetConstants.TITRE_SOUS_SUJET_CONF.equals(lectureSujet.getTitre())) {
                evenementFacade.saveEvenementUtilisateurTraite(TypeEven.CONFIRMATION_DONNEES_PERSO);

            } else if (SujetConstants.TITRE_SOUS_SUJET_VDPP.equals(lectureSujet.getTitre())) {
                evenementFacade.saveEvenementUtilisateurTraite(TypeEven.VALIDATION_PERIODIQUE_DONNEES_PERSO);
            }
        }
    }
}
