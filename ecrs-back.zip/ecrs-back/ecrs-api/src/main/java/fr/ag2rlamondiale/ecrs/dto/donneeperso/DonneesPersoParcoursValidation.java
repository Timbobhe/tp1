package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class DonneesPersoParcoursValidation {
    private ModificationsIdentiteInfo modificationsIdentiteInfo;
    private DonneesPersoParcoursType donneesPersoParcoursType;
    private String titreSujet;
    private List<UploadFileDto> pieceJointes;
}
