package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.trm.client.soap.IConsulterEcheancierClient;
import fr.ag2rlamondiale.trm.client.soap.IEcheancierClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.echeancier.ConsulterEcheancierDto;
import fr.ag2rlamondiale.trm.domain.echeancier.DemandeSiloRequestDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.RechercherEcheanciersDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class EcheancierFacadeImpl implements IEcheancierFacade {

    @Autowired
    private IEcheancierClient echeancierClient;

    @Autowired
    private IConsulterEcheancierClient consulterEcheancierClient;

    @Override
    public List<Echeancier> rechercherEcheanciers(Compartiment compartiment) throws TechnicalException {
        Objects.requireNonNull(compartiment);
        RechercherEcheanciersDto rechercherEcheanciers = null;
        if (compartiment.isERE()) {
            DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
            demande.setCodeSiloType(CodeSiloType.ERE);
            demande.setIdAssure(compartiment.getIdentifiantAssure());
            rechercherEcheanciers = new RechercherEcheanciersDto(demande);
        } else if (compartiment.isMdpro()) {
            DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
            demande.setCodeSiloType(CodeSiloType.MDP);
            demande.setIdContrat(compartiment.getContratHeader().getId());
            rechercherEcheanciers = new RechercherEcheanciersDto(demande);
        }

        Objects.requireNonNull(rechercherEcheanciers);
        return echeancierClient.rechercherEcheanciers(rechercherEcheanciers);
    }


    @Override
    public Echeancier consulterEcheancier(Compartiment compartiment, String idEcheancier) throws TechnicalException {
        Objects.requireNonNull(compartiment);
        DemandeSiloRequestDto demande = null;
        if (compartiment.isERE()) {
            demande = new DemandeSiloRequestDto();
            demande.setCodeSiloType(CodeSiloType.ERE);
            demande.setIdAssure(compartiment.getIdentifiantAssure());
        } else if (compartiment.isMdpro()) {
            demande = new DemandeSiloRequestDto();
            demande.setCodeSiloType(CodeSiloType.MDP);
            demande.setIdContrat(compartiment.getContratHeader().getId());
        }

        Objects.requireNonNull(demande);
        ConsulterEcheancierDto consulterEcheancier = new ConsulterEcheancierDto(demande, idEcheancier);
        return consulterEcheancierClient.consulterEcheancier(consulterEcheancier);
    }

    @Override
    public Echeancier getProchainEcheancier(Compartiment compartiment) throws TechnicalException {
        Optional<Echeancier> echeancier = rechercherEcheanciers(compartiment).stream().max(Comparator.comparing(Echeancier::getEcheancierId));

        return echeancier.isPresent() ? consulterEcheancier(compartiment, echeancier.get().getEcheancierId().toString()) : null;
    }
}
