package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.formulaire.actesenligne.InformationsComplementairesType;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {DateMapper.class}, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class InformationsComplementairesMapper {

    @Mapping(target = "signaletiquePP.nom", source = "personPhysique.nom")
    @Mapping(target = "signaletiquePP.prenom", source = "personPhysique.prenom")
    @Mapping(target = "signaletiquePP.dateNaissance", source = "personPhysique.dateDeNaissance")
    @Mapping(target = "signaletiquePP.libelleCivilite", source = "personPhysique.civilite")

    @Mapping(target = "dossiersCommunication.emails.libelleEmail", source = "personPhysique.emailPro")

    @Mapping(target = "informationsContrat.raisonSociale", source = "contrat.raisonSocialeFront")
    @Mapping(target = "informationsContrat.numeroExterneContrat", source = "contrat.id")
    @Mapping(target = "informationsContrat.libelleCategoriePersonnel", source = "contrat.college")
    public abstract InformationsComplementairesType mapToInformationsComplementaires(DemandeCreationSigElec<ContratHeader> demande);
}
