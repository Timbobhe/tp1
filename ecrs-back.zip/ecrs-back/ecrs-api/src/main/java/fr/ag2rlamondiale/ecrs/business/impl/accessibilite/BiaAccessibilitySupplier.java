package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBiaFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocageComparator;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.trm.business.IDocumentationFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.accessibilite.DetailAccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.documentation.ref.Fiche;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.*;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;

@Component
public class BiaAccessibilitySupplier implements IFunctionalityAccessibilitySupplier<Void> {

    private static final ContratBlocageComparator RaisonBiaComparator = ContratBlocageComparator.selonOrdre(
            NONE, ARB_BLOCAGE_CONSOLE, BLOCAGE_BIA_EN_COURS, BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS, BLOCAGE_BIA_SITUATION_AFFILIATION, BLOCAGE_BIA_DEJA_SAISI);

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IBiaFacade biaFacade;

    @Autowired
    private IDocumentationFacade documentationFacade;

    @Autowired
    private IWorkflowFacade workflowFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public boolean accept(fr.ag2rlamondiale.trm.domain.FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.COMPLETER_BIA.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto<Void> check() throws TechnicalException {
        evictCacheRechercherContratsPersonne();
        List<ContratHeader> contratHeaders = contratFacade.rechercherContratsEre();

        AccesFonctionnaliteDto<Void> accesFonctionnalite = new AccesFonctionnaliteDto<>(FonctionnaliteType.COMPLETER_BIA);

        boolean accessible = false;
        ContratBlocage raison;
        if (!contratHeaders.isEmpty()) {
            for (ContratHeader contratHeader : contratHeaders) {
                final ResultParcoursEffectueDto resAcces = biaFacade.testBiaEffectue(contratHeader);
                DetailAccesFonctionnaliteDto detail = new DetailAccesFonctionnaliteDto(contratHeader.getContratId());
                accesFonctionnalite.addDetail(detail);
                if (resAcces.isParcoursEffectue()) {
                    detail.setAccessible(false, BLOCAGE_BIA_DEJA_SAISI.name());
                } else if (resAcces.isEncours() && !resAcces.isSigElecEncoursNonSigne()) {
                    detail.setAccessible(false, BLOCAGE_BIA_EN_COURS.name());
                } else if (hasDemandeMdpEncours()) {
                    detail.setAccessible(false, BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS.name());
                } else if (isNoticeInformationSalarieMissing(contratHeader)) {
                    detail.setAccessible(false, BLOCAGE_BIA_SITUATION_AFFILIATION.name());
                } else {
                    detail.setAccessible(true, NONE.name());
                }

                accessible = accessible || detail.isAccessible();
            }

            raison = accesFonctionnalite.getDetails().stream()
                    .map(DetailAccesFonctionnaliteDto::getRaison)
                    .map(ContratBlocage::valueOf)
                    .min(RaisonBiaComparator)
                    .orElse(NONE);
        } else {
            raison = BLOCAGE_BIA_MONO_EQUIPE_MDPRO;
        }
        accesFonctionnalite.setAccessible(accessible);
        accesFonctionnalite.setRaison(raison.name());
        return accesFonctionnalite;
    }

    private void evictCacheRechercherContratsPersonne() {
        String numeroPersonneEre = userContextHolder.get().getNumeroPersonneEre();
        if(numeroPersonneEre != null ) {
            RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
            rechercherContratsDto.setCodeSilo(ERE);
            rechercherContratsDto.setPersonId(numeroPersonneEre);
            contratFacade.forceCacheEvictRechercherContratsPersonne(rechercherContratsDto);
        }
    }

    private boolean isNoticeInformationSalarieMissing(ContratHeader contratHeader) {
        try {
            Fiche fiche = documentationFacade.rechercherNoticeInformationSalarie(contratHeader);
            return fiche == null;
        } catch (DocumentException e) {
            return true;
        }
    }

    private boolean hasDemandeMdpEncours() throws WorkflowException {
        if (userContextHolder.get().getNumeroPersonneEre() != null) {
            return workflowFacade.hasDemandeMdpEncours(userContextHolder.get().getNumeroPersonneEre());
        }
        return false;
    }
}
