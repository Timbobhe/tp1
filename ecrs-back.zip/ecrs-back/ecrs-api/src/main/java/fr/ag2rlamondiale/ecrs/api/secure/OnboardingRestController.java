package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.JahiaContextDto;
import fr.ag2rlamondiale.ecrs.dto.onboarding.OnboardingStartDto;
import fr.ag2rlamondiale.ecrs.dto.onboarding.OnboardingTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.mapping.StructInvMapper;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleProfilInv;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_ONBOARDING_START;
import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_ONBOARDING_TERMINATE;

@RestController
@RequestMapping(path = "/secure")
public class OnboardingRestController {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private IEvenementFacade evenementFacade;

    @Autowired
    private ISujetFacade sujetFacade;

    @Autowired
    private IBiaFacade biaFacade;

    @Autowired
    private StructInvMapper structInvMapper;

    @Autowired
    private IParcoursSimplifieFacade parcoursSimplifieFacade;


    @ProfileExecution(codeAction = API_ONBOARDING_START)
    @LogExecutionTime
    @GetMapping(path = "/onboarding/start")
    public OnboardingStartDto start() throws Exception {
        OnboardingStartDto onboardingStart = new OnboardingStartDto();

        final EvenementJson evenement = evenementFacade.generateNextEvenement(TypeEven.ONBOARDING.toPredicate(), true, true);
        if (evenement == null) {
            onboardingStart.setOnboardingDejaEffectue(true);
            return onboardingStart;
        }

        onboardingStart.setEvenement(evenement);
        onboardingStart.setSujets(sujetFacade.getSujets());

        Compartiment compartiment = contratFacade.rechercherCompartimentEREPlusRecent(CompartimentType.C3);
        if (compartiment != null) {
            ContratHeader contratHeader = compartiment.getContratHeader();
            onboardingStart.setIdDernierContratERE(contratHeader.getContratId());
            onboardingStart.setDescClauseBenef(contratHeader.getDescClauseBenef());

            onboardingStart.setBiaEffectue(biaFacade.isBiaEffectue(contratHeader));

            final boolean simplifie = parcoursSimplifieFacade.isParcoursSimplifieActivate(contratHeader.getId(), FonctionnaliteType.ONBOARDING_SIMPLIFIE);

            onboardingStart.setParcoursSimplifie(simplifie);
            onboardingStart.setContextJahia(JahiaContextDto.builder().parcoursSimplifie(simplifie).build());

            if (!onboardingStart.isBiaEffectue()) {
                final GrilleProfilInv defaultGrille = structureInvFacade.getCompartimentDefaultGrilleProfil(compartiment);
                onboardingStart.setGrilleInvParDefaut(structInvMapper.map(defaultGrille));
            }
        } else {
            onboardingStart.setBiaEffectue(true);
        }
        return onboardingStart;
    }

    @ProfileExecution(codeAction = API_ONBOARDING_TERMINATE)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/onboarding/terminate")
    public void terminate(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) OnboardingTerminateDto onboardingTerminate) throws TechnicalException {
        sujetFacade.createSujetParUtilisateur(onboardingTerminate.getIdSujets());
        final EvenementJson evenementJson = onboardingTerminate.getEvenement();
        evenementJson.setDateFin(new Date());
        evenementJson.setEtatTraitement(EtatTraitementType.TRAI);
        evenementFacade.updateEvenement(evenementJson);
    }
}
