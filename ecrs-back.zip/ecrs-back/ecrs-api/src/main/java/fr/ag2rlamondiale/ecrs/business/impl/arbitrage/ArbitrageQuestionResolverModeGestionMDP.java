package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInvHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MDPRO_QUESTION_MODE_GESTION_TITRE;
import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_MESSAGE_SOUHAIT_ARBITRER;
import static fr.ag2rlamondiale.trm.domain.ModeGestionMdproType.*;

@Service
public class ArbitrageQuestionResolverModeGestionMDP implements ArbitrageQuestionResolver {

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IStructureInvFacade structureInvFacade;

    @Autowired
    private IParamConsoleFacade produitFacade;

    @Override
    public QuestionResponsesDto<ModeGestionMdproType, ?> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException {
        final ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contexte.getContratSelectionne());
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();

        final QuestionResponsesDto<ModeGestionMdproType, ?> result = new QuestionResponsesDto<>();
        result.setQuestion(QuestionDto.builder()
                .id(QuestionType.ARBITRAGE_CHOIX_MODEGESTION)
                .jahiaDicoEntry(ARB_MDPRO_QUESTION_MODE_GESTION_TITRE.name())
                .build());

        result.setAffirmativeMessage(MessageDto.builder()
                .jahiaDicoEntry(ARB_MESSAGE_SOUHAIT_ARBITRER.name())
                .build());

        if (ContratMDPROHelper.CODE_FISCALITE_PEP.equalsIgnoreCase(contratGeneral.getCodeCadreFiscal())) {
            result.setDefaultValue(ResponseDto.<ModeGestionMdproType>builder()
                    .id(PEP.name())
                    .value(PEP)
                    .label(PEP.name())
                    .build());
            result.setShow(false);
            return result;
        }

        final StructInv structInv = structureInvFacade.consulterStructInv(contratComplet.getContratHeader());

        if (isModeGestionPresent(structInv, DYNAMISATION)) {
            result.add(reponse(DYNAMISATION));
        }

        if (isModeGestionPresent(structInv, PILOTEE)) {
            result.add(reponse(PILOTEE));
        }

        if (isModeGestionPresent(structInv, HORIZON)) {
            result.add(reponse(HORIZON));
        }

        if (isModeGestionPresent(structInv, LIBRE)) {
            result.add(reponse(LIBRE));
        }

        if (result.getPropositions().size() == 1) {
            result.setShow(false);
            result.setDefaultValue(result.getPropositions().get(0));
        }

        return result;
    }


    private boolean isModeGestionPresent(StructInv structInv, ModeGestionMdproType modeGestion) {
        return StructInvHelper.getCodesProfilsAndGrilles(structInv).stream().anyMatch(code -> {
            SupportInvestissementJson supportsInvestissement = produitFacade.getSupportsInvestissement(code);
            return supportsInvestissement != null && modeGestion.name()
                    .equals(supportsInvestissement.getModeGestion());
        });
    }

    public ResponseDto<ModeGestionMdproType> reponse(ModeGestionMdproType arbitrageModeGestion) {
        final ResponseDto<ModeGestionMdproType> response = ResponseDto.<ModeGestionMdproType>builder()
                .id(arbitrageModeGestion.name())
                .value(arbitrageModeGestion)
                .build();

        return setLabel(response);
    }

    private ResponseDto<ModeGestionMdproType> setLabel(ResponseDto<ModeGestionMdproType> response) {
        final ModeGestionMdproType type = response.getValue();
        switch (type) {
            case PILOTEE:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MDPRO_QUESTION_MODE_GESTION_PILOTEE.name());
                return response;
            case HORIZON:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MDPRO_QUESTION_MODE_GESTION_HORIZON.name());
                return response;
            case DYNAMISATION:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MDPRO_QUESTION_MODE_GESTION_DYNAMISATION.name());
                return response;
            case LIBRE:
                response.setJahiaDicoEntry(DictionnaireArbitrageJahia.ARB_MDPRO_QUESTION_MODE_GESTION_LIBRE.name());
                return response;
            default:
                throw new IllegalArgumentException(type.name());
        }
    }

    @Override
    public boolean accept(QuestionType questionType, ArbitrageContexteDto contexte) {
        return QuestionType.ARBITRAGE_CHOIX_MODEGESTION.equals(questionType) && contexte.getContratSelectionne() != null
                && contexte.getContratSelectionne().is(CodeSiloType.MDP);
    }
}
