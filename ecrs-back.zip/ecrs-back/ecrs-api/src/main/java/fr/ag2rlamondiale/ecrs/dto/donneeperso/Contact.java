package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class Contact {
    private String telPortable;
    private String telPersonnel;
    private String telPro;
    private String emailPro;
    //private String emailPerso;
}
