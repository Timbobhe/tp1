package fr.ag2rlamondiale.ecrs.config;

import fr.ag2rlamondiale.trm.thread.NewThreadFutureTaskExecutor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.annotation.EnableAsync;

@Configuration
@EnableAsync
public class AsyncConfig extends AsyncConfigurerSupport {

    @Bean
    @Override
    public AsyncTaskExecutor getAsyncExecutor() {
        return new NewThreadFutureTaskExecutor();
    }
}
