package fr.ag2rlamondiale.ecrs.dto.arbitrage;

public enum OptionChoixArbitrageType {
    // Arbitrage stock
    ARB_QUESTION_RM07_CHOIX_1,
    // arbitrage flux => repartition finale
    ARB_QUESTION_RM07_CHOIX_2,
    ARB_QUESTION_RM07_CHOIX_21,
    ARB_QUESTION_RM07_CHOIX_22,
    // arbitrage flux et stock => repartition finale
    ARB_QUESTION_RM07_CHOIX_3,
    ARB_QUESTION_RM07_CHOIX_31,
    ARB_QUESTION_RM07_CHOIX_32,
    // Compartiment
    ARB_QUESTION_RM09_CHOIX_1,
    // Compartiment Facultatif
    ARB_QUESTION_RM09_CHOIX_2,
    // Compartiment
    ARB_QUESTION_RM09_CHOIX_3,
    // partiel
    ARB_QUESTION_RM12_CHOIX_1,
    // Total
    ARB_QUESTION_RM12_CHOIX_2,
    // En pourcentage
    ARB_QUESTION_RM15_CHOIX_1,
    // En euro
    ARB_QUESTION_RM15_CHOIX_2;
}
