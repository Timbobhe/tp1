package fr.ag2rlamondiale.ecrs.dto.versementsynthese;

import java.util.Date;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OperationVersementDto {
	private String operationId;
    private String typeOperation;
    private double montant;
    private Date dateOperation;
    private ContratParcoursDto contrat;
    private boolean operationDerniers3Mois;
    private boolean deductible;
    private Boolean enCoursTraitement;
}
