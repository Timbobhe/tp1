package fr.ag2rlamondiale.ecrs.dto.versementsynthese;

import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.List;

@Data
public class EcheancierDto {
	private BigInteger echeancierId;
	private Date dateEffet;
	private Date dateDebut;
	private Date dateFin;
	private BigDecimal montant;
	private String codeFractionnement;
	private String fractionnement;
    private String frequence;
	private List<Prelevement> prelevements;
	private String idAssure;
	private int jourPrelevement;
	private Date dateProchaineEcheance;
	private int annee;
	private ContratParcoursDto compartiment;
}
