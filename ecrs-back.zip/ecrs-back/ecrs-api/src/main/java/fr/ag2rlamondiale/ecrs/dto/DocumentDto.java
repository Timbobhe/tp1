package fr.ag2rlamondiale.ecrs.dto;

import fr.ag2rlamondiale.trm.domain.contrat.ContratId;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class DocumentDto {

    private String code;
    private String name;
    private String date;
    private ContratId contratId;

}
