package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.business.impl.versement.ComparatorEcheancierSelonPrelevement;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.EcheancierDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import org.mapstruct.AfterMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class EcheancierToEcheancierDtoMapper {


    @Mapping(source = ".", target = ".")
    public abstract EcheancierDto echeancierToDto(Echeancier echancier);

    @AfterMapping
    protected void completeInfosEcheancier(@MappingTarget EcheancierDto result, Echeancier echancier) {
        if (!echancier.getPrelevements().isEmpty()) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(echancier.getPrelevements().get(0).getDatePrelevement());
            result.setJourPrelevement(cal.get(Calendar.DAY_OF_MONTH));
            result.setAnnee(cal.get(Calendar.YEAR));
            result.setPrelevements(new ArrayList<>(echancier.getPrelevements()));
            result.getPrelevements().sort(Comparator.comparing(Prelevement::getDatePrelevement));

            ComparatorEcheancierSelonPrelevement comparator = new ComparatorEcheancierSelonPrelevement();
            final Prelevement prelevement = comparator.prochainPrelevementApresDateJour(echancier);
            result.setDateProchaineEcheance(prelevement.getDatePrelevement());
        }
    }
}
