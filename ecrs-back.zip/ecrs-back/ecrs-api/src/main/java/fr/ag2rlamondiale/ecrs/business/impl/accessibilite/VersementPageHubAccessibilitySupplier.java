package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class VersementPageHubAccessibilitySupplier implements IFunctionalityAccessibilitySupplier {
    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private ContratVifHelper contratVifHelper;

    @Override
    public boolean accept(FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.VOS_DONNEES_VERSEMENT.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto check() throws TechnicalException {
        AccesFonctionnaliteDto accesFonctionnalite = new AccesFonctionnaliteDto(FonctionnaliteType.VOS_DONNEES_VERSEMENT);
        boolean accessible;

        List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets().stream()
                .filter(contrat -> !contrat.getContratHeader().getAffichageType().equals(AffichageType.MASQUE) && !contrat.getContratHeader().getAffichageType().equals(AffichageType.GRISE))
                .filter(contrat -> !contrat.getContratHeader().isClasseAutreContrat())
                .filter(contrat -> contrat.getContratHeader().isEre() || (contrat.getContratHeader().isMdpro() &&
                        (contrat.getContratHeader().getCompartiments().stream()
                                .anyMatch(compartiment -> compartiment.is(CompartimentType.C1) || compartiment.is(CompartimentType.C4)))))
                .filter(contratComplet -> contratComplet.getContratHeader().getCompartiments().stream()
                        .anyMatch(compartiment -> contratVifHelper.isVifPossible(contratComplet, compartiment.getCompartimentId())))
                .collect(Collectors.toList());

        accessible = !contratComplets.isEmpty();
        accesFonctionnalite.setAccessible(accessible);
        if (!accessible) {
            accesFonctionnalite.setRaison(ContratBlocage.HUB_VERSEMENT_ACCESS_DENIED_CONTRACT.name());
        }

        return accesFonctionnalite;
    }
}
