package fr.ag2rlamondiale.ecrs.dto.reclamation;

import fr.ag2rlamondiale.ecrs.business.impl.ContactReclamationFacadeImpl;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ContactReclamationDto implements ISecurityParamAccess {
    private String idContrat;
    private String idAssure;
    private String idPersonne;
    private CodeSiloType codeSilo;
    private String codeFiliale;

    /**
     * <ul>
     *     <li>ERE = <b>1,2,3</b> => DemandeWorkflowType {@link ContactReclamationFacadeImpl#getDemandeWorkflowType(ContactReclamationDto)}</li>
     *     <li>MDP = <b>directement le libelle</b> {@link fr.ag2rlamondiale.ecrs.domain.creerdemcom.CreerDemComDto.CreerDemComDtoBuilder#themeMessage} </li>
     * </ul>
     */
    private String codeQuestion;
    private String message;
    private boolean reclamation;
    private String email;
    private String telephone;
    private String raisonSociale;
    private List<UploadFileDto> fichiersJoint;

    @Override
    public String secureForNumContrat() {
        return this.idContrat;
    }
}
