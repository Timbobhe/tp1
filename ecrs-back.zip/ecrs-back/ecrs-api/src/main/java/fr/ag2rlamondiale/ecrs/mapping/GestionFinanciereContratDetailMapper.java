package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.dto.SupportDetailContratDto;
import fr.ag2rlamondiale.trm.domain.encours.ProfilInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import org.mapstruct.*;

import java.math.BigDecimal;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class GestionFinanciereContratDetailMapper {

    @Mapping(target = "valeurPart", ignore = true)
    @Mapping(target = "nombreParts", ignore = true)
    @Mapping(target = "montant", ignore = true)
    @Mapping(target = "codeISIN", ignore = true)
    @Mapping(source = "nomProfilInv", target = "libelle")
    @Mapping(source = "txRepartitionProfilInv", target = "pourcentageRepartition")
    public abstract SupportDetailContratDto map(ProfilInvDto profil);


    @Mapping(target = "pourcentageRepartition", ignore = true)
    @Mapping(source = "supportInvDto.nomSupportInv", target = "libelle")
    @Mapping(source = "supportInvDto.codeISIN", target = "codeISIN")
    @Mapping(source = "supportInvDto.nbePartFonds", target = "nombreParts")
    @Mapping(source = "supportInvDto.valeurLiquidativeFond", target = "valeurPart")
    @Mapping(source = "supportInvDto", target = "montant", qualifiedByName = "mapMontant")
    public abstract SupportDetailContratDto map(SupportInvDto supportInvDto, BigDecimal montantEncours);

    @Named("mapMontant")
    public BigDecimal mapToMontant(SupportInvDto supportInvDto) {
        return supportInvDto.getValeurLiquidativeFond().multiply(supportInvDto.getNbePartFonds());
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget SupportDetailContratDto supportDetailContratDto, BigDecimal montantEncours) {
        supportDetailContratDto.setPourcentageRepartition(supportDetailContratDto.getMontant().multiply(BigDecimal.valueOf(100))
                .divide(montantEncours));
    }
}
