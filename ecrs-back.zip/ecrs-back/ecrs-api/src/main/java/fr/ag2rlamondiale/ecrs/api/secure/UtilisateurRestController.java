package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.ecrs.dto.ClientDto;
import fr.ag2rlamondiale.ecrs.mapping.ClientMapper;
import fr.ag2rlamondiale.ecrs.mapping.UtilisateurMapper;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.*;

/**
 * Implementation Spring du service REST pour la Recherche Client
 */
@Slf4j
@RestController
@RequestMapping(path = "/secure")
public class UtilisateurRestController {
    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ClientMapper clientMapper;

    @Autowired
    UtilisateurMapper utilisateurMapper;

    /**
     * Méthode pour récupérer le client conntecté
     *
     * @return ClientDto
     * @throws CommonException CommonException
     */
    @ProfileExecution(codeAction = API_INFOSCLIENT_GET)
    @LogExecutionTime
    @GetMapping(path = "/get/infosclient")
    public ClientDto getClient() throws CommonException {
        UserContext userContext = userContextHolder.get();
        log.info("userContext : {}", userContext);
        ClientDto client = clientMapper.map(userContext);
        client = utilisateurMapper.mapperPersonnePhysiqueToClientDto(client, userContext);
        return client;
    }

    /**
     * Méthode pour récupérer les infos de la personne physique
     *
     * @return ClientDto
     * @throws CommonException CommonException
     */
    @ProfileExecution(codeAction = API_PERSONNE_PHYSIQUE_INFOS_GET)
    @LogExecutionTime
    @GetMapping(path = "/get/personnePhysiqueInfos")
    public ClientDto getPersonnePhysiqueInfos() throws CommonException {
        UserContext userContext = userContextHolder.get();
        log.info("userContext : {}", userContext);
        ClientDto client = clientMapper.map(userContext);
        client = utilisateurMapper.mapperPersonnePhysiqueConsultToClientDto(client, userContext);
        return client;
    }
}
