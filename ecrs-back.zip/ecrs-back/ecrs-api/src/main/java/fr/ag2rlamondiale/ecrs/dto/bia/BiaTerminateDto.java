package fr.ag2rlamondiale.ecrs.dto.bia;

import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import lombok.Data;

import java.util.List;

@Data
public class BiaTerminateDto implements ISecurityParamAccess {
    private ContratParcoursDto contratSelected;
    private ClauseBeneficiaireDto clauseBeneficiaireSelected;
    private List<RepartitionSupportDto> gestionFinanciereSelected;
    private String resultatQAD;
    private DocumentDto contenuQAD;
    private DocumentDto contenuBIA;

    @Override
    public String secureForNumContrat() {
        return this.contratSelected.getNomContrat();
    }
}
