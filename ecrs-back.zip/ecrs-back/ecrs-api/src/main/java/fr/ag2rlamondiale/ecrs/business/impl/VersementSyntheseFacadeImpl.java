package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.business.IVersementSyntheseFacade;
import fr.ag2rlamondiale.ecrs.business.domain.operation.OperationCompartiment;
import fr.ag2rlamondiale.ecrs.business.impl.versement.ComparatorEcheancierSelonPrelevement;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.DocumentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.SyntheseVersementDonutDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.*;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.EcheancierToEcheancierDtoMapper;
import fr.ag2rlamondiale.ecrs.mapping.OperationToOperationVersementDtoMapper;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.trm.business.IDocumentationFacade;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.documentation.ged.DocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.IdDocGedDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.RechDocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.RechDocGEDResponseDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Service
@Slf4j
public class VersementSyntheseFacadeImpl implements IVersementSyntheseFacade {

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IEcheancierFacade echeancierFacade;

    @Autowired
    private IDocumentationFacade documentationFacade;

    @Autowired
    private IGestionMandatFacade gestionMandatFacade;

    @Autowired
    private EcheancierToEcheancierDtoMapper echeancierMapper;


    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private OperationToOperationVersementDtoMapper operationMapper;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IOperationsClient operationsClient;


    @Override
    public VersementSyntheseDto getResumeVersement() throws TechnicalException {
        List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();
        VersementSyntheseDto versementSynthese = new VersementSyntheseDto();
        final LocalDate now = LocalDate.now();
        final Date minDate = DateUtils.createDate(1, 1, now.getYear());
        final Date maxDate = DateUtils.createDate(now.getDayOfMonth(), now.getMonth().getValue(), now.getYear());
        List<Operation> operations = contratComplets.stream()
                .map(contrat -> contrat.getContratHeader()
                                       .getCompartiments()
                        .stream()
                        .filter(compartiment -> compartiment.is(CompartimentType.C1) || compartiment.is(CompartimentType.C4))
                        .collect(Collectors.toList()))
                .map(listCompartiments -> getOperations(listCompartiments, minDate, maxDate))
                .flatMap(List::stream)
                .map(OperationCompartiment::getOperation)
                .filter(operation -> Boolean.FALSE.equals(operation.getEnCoursTraitement()))
                .sorted(Comparator.comparing(Operation::getDate))
                .collect(Collectors.toList());
        if (!operations.isEmpty()) {
            double montantTotal = operations.stream().map(Operation::getMontant)
                                                     .reduce(BigDecimal.ZERO, BigDecimal::add).doubleValue();
            final Operation derniereOperation = operations.get(operations.size() - 1);
            versementSynthese.setMontantTotal(montantTotal);
            versementSynthese.setDateDernierVersement(derniereOperation.getDate());
            versementSynthese.setMontantDernierVersement(derniereOperation.getMontant().doubleValue());
        }
        final ComparatorEcheancierSelonPrelevement comparatorEcheancier = new ComparatorEcheancierSelonPrelevement();
        Echeancier echeancierWithClosetPrelevement = contratComplets.stream()
                .filter(contrat -> contrat.getContratHeader().isEre())
                .map(contrat -> contrat.getContratHeader().getCompartiments())
                .map(compartiments -> handleException(() -> getEcheanciers(compartiments)))
                .flatMap(List::stream)
                .min(comparatorEcheancier)
                .orElse(null);

        if (echeancierWithClosetPrelevement != null) {
            versementSynthese.setMontantProchainVersement(echeancierWithClosetPrelevement.getMontant().doubleValue());
            final Prelevement prochainPrelevementApresDateJour = comparatorEcheancier
                    .prochainPrelevementApresDateJour(echeancierWithClosetPrelevement);
            if (prochainPrelevementApresDateJour != null) {
                versementSynthese.setDateProchainVersement(prochainPrelevementApresDateJour.getDatePrelevement());
            }
        }

        return versementSynthese;
    }

    private List<Echeancier> getEcheanciers(List<Compartiment> compartiments) throws TechnicalException {
        List<Echeancier> echeanciers = new ArrayList<>();
        for (Compartiment compartiment : compartiments) {
            List<Echeancier> echanciersSansDetails = echeancierFacade.rechercherEcheanciers(compartiment);
            for (Echeancier ech : echanciersSansDetails) {
                if (ech.getDateFin() == null || ech.getDateFin().after(new Date())) {
                    Echeancier echancier = echeancierFacade.consulterEcheancier(compartiment,
                                                                                String.valueOf(ech.getEcheancierId()));
                    echeanciers.add(echancier);
                }
            }
        }
        return echeanciers;
    }

    private List<OperationCompartiment> getOperations(List<Compartiment> compartiments, Date dateMin, Date dateMax) {
        return compartiments.stream()
                .filter(compartiment -> compartiment.is(CompartimentType.C1) || compartiment.is(CompartimentType.C4))
                .map(compartiment -> {
                    final List<Operation> operations = operationFacade.getOperationsForVersementSynthese(compartiment, dateMin, dateMax);
                    return operations.stream()
                            .map(o -> new OperationCompartiment(o, compartiment))
                            .collect(Collectors.toList());
                })
                .flatMap(List::stream)
                .collect(Collectors.toList());

    }

    @Override
    public VersementProgrammeDetailsDto getVersProgrammeDetails(VersementProgrammeDetailsRequestDto dto) throws TechnicalException {
        ContratId contratId = dto.getContratId();

        final DocRefType docRefType = DocRefType.getDocumentRefType(dto.getCodeDocument(), contratId.getCodeSilo());
        RechDocGEDDto in = RechDocGEDDto.prepareRechDocGEDDto(contratId, docRefType.name(),
                                                              userContextHolder.get().getNumeroPersonneEre());

        RechDocGEDResponseDto dernierDocEcheancier = documentationFacade.rechercherDernierDocumentEre(in);

        IdDocGedDto docGEDDto = null;
        if (dernierDocEcheancier != null && dernierDocEcheancier.getDocGED() != null
                && !dernierDocEcheancier.getDocGED().isEmpty()) {
            DocGEDDto docGED = dernierDocEcheancier.getDocGED().get(0);
            docGEDDto = IdDocGedDto.builder().idDocGED(docGED.getIdDoc()).codeSilo(CodeSiloType.ERE).build();
        }

        ContratHeader contratHeader = contratFacade.rechercherContratParId(contratId);
        CoordonneesBancairesDto coordonnesBancaires = gestionMandatFacade.consulterCoordonneesBancairesContrat(contratHeader);

        return VersementProgrammeDetailsDto.builder()
                .coordonneesBancaires(coordonnesBancaires)
                .docGED(docGEDDto)
                .build();
    }

    @Override
    public List<EcheancierDto> getVersementsProgrammes() throws TechnicalException {
        List<ContratHeader> contratsHeaders = contratFacade.rechercherContrats();
        List<EcheancierDto> versementsProgrammes = new ArrayList<>();
        // pour le moment on gere les versement programme que pour ERE
        for (ContratHeader contrat : contratsHeaders) {
            if (contrat.is(CodeSiloType.ERE)) {
                for (Compartiment compartiment : contrat.getCompartiments()) {
                    List<Echeancier> echanciersSansDetails = echeancierFacade.rechercherEcheanciers(compartiment);
                    echeanciersByCompartiment(versementsProgrammes, compartiment, echanciersSansDetails);
                }
            }
        }

        return versementsProgrammes.stream().filter(distinctByKey(EcheancierDto::getEcheancierId))
                                            .collect(Collectors.toList());
    }

    private void echeanciersByCompartiment(List<EcheancierDto> versementsProgrammes, Compartiment compartiment, List<Echeancier> echanciersSansDetails) throws TechnicalException {
        for (Echeancier e : echanciersSansDetails) {
            if (e.getDateFin() == null || e.getDateFin().after(new Date())) {
                Echeancier echeancier = echeancierFacade.consulterEcheancier(compartiment,
                                                                             String.valueOf(e.getEcheancierId()));
                EcheancierDto echancierToAdd = echeancierMapper.echeancierToDto(echeancier);
                echancierToAdd.setFrequence(FrequenceVirementType.forEcheancier(echeancier).getLibelle());
                echancierToAdd.setIdAssure(compartiment.getIdentifiantAssure());
                echancierToAdd.setCompartiment(contratParcoursMapper.map(compartiment, false));
                versementsProgrammes.add(echancierToAdd);
            }
        }
    }

    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }

    @Override
    public List<OperationVersementDto> getVersementsHistorique() throws TechnicalException {
        List<OperationVersementDto> operationsDto = new ArrayList<>();

        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate today = LocalDate.now();
        Date dateFin = Date.from(today.atStartOfDay(defaultZoneId).toInstant());

        LocalDate dateMin = today.minus(2, ChronoUnit.YEARS);
        Date dateDebut = Date.from(dateMin.atStartOfDay(defaultZoneId).toInstant());
        List<ContratHeader> contratsHeaders = contratFacade.rechercherContrats();

        for (ContratHeader contratHeader : contratsHeaders) {
            for (OperationCompartiment oc : getOperations(contratHeader.getCompartiments(), dateDebut, dateFin)) {
                OperationVersementDto operationDto = operationMapper.operationToDto(oc.getOperation());
                operationDto.setContrat(contratParcoursMapper.map(oc.getCompartiment(), false));
                operationsDto.add(operationDto);
            }
        }

        return operationsDto;
    }

    @Override
    public SyntheseVersementDonutDto retrieveSyntheseVersement() throws TechnicalException {
        BigDecimal montantTotalVersementDeductible = BigDecimal.ZERO;
        BigDecimal pourcentageVersementDeductible = BigDecimal.ZERO;
        BigDecimal montantTotalVersementNonDeductible = BigDecimal.ZERO;
        BigDecimal pourcentageVersementNonDeductible = BigDecimal.ZERO;
        BigDecimal montantTotalVersement;
        List<ContratComplet> contratComplets = contratFacade.rechercherContratsComplets();
        List<Operation> versementsDeductibles = findOperationsByDeductibility(contratComplets, true);
        List<Operation> versementsNonDeductibles = findOperationsByDeductibility(contratComplets, false);

        if (!versementsDeductibles.isEmpty()) {
            montantTotalVersementDeductible = versementsDeductibles.stream().map(Operation::getMontant)
                                                                            .reduce(BigDecimal.ZERO, BigDecimal::add);
        }
        if (!versementsNonDeductibles.isEmpty()) {
            montantTotalVersementNonDeductible = versementsNonDeductibles.stream().map(Operation::getMontant)
                                                                                  .reduce(BigDecimal.ZERO, BigDecimal::add);
        }

        montantTotalVersement = montantTotalVersementDeductible.add(montantTotalVersementNonDeductible);

        if (BigDecimal.ZERO.compareTo(montantTotalVersement) != 0) {
            pourcentageVersementDeductible = montantTotalVersementDeductible.divide(montantTotalVersement, 4, RoundingMode.HALF_UP)
                                                                            .multiply(new BigDecimal(100));
            pourcentageVersementNonDeductible = montantTotalVersementNonDeductible.divide(montantTotalVersement, 4, RoundingMode.HALF_UP)
                                                                                  .multiply(new BigDecimal(100));
        }

        return SyntheseVersementDonutDto.builder().montantTotalVersementDeductible(montantTotalVersementDeductible)
                                                  .pourcentageVersementDeductible(pourcentageVersementDeductible)
                                                  .montantTotalVersementNonDeductible(montantTotalVersementNonDeductible)
                                                  .pourcentageVersementNonDeductible(pourcentageVersementNonDeductible)
                                                  .montantTotalVersement(montantTotalVersement)
                                                  .year(LocalDate.now().getYear() - 1)
                                                  .build();

    }

    private List<Operation> findOperationsByDeductibility(List<ContratComplet> contratComplets, boolean isDeductible) {
        return contratComplets.stream()
                .map(contrat -> contrat.getContratHeader()
                                       .getCompartiments()
                        .stream()
                        .filter(compartiment -> compartiment.is(CompartimentType.C1) || compartiment.is(CompartimentType.C4))
                        .filter(compartiment -> isDeductible == compartiment.isDeductible())
                        .collect(Collectors.toList()))
                .map(this::getOperationsVersementPageHub)
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    private List<Operation> getOperationsVersementPageHub(List<Compartiment> compartiments) {
        final LocalDate now = LocalDate.now();
        int year = now.getYear() - 1;

        final Date minDate = DateUtils.createTimelessDate("01/01/" + year);
        final Date maxDate = DateUtils.createTimelessDate("31/12/" + year);
        return compartiments.stream()
                .map(compartiment -> operationFacade.getOperationsForVersementSynthese(compartiment, minDate, maxDate))
                .flatMap(List::stream)
                .filter(operation -> Boolean.FALSE.equals(operation.getEnCoursTraitement()))
                .collect(Collectors.toList());

    }


    @Override
    public DocumentDto rechercherDocumentsVersement() throws TechnicalException {
        List<DocGEDDto> docsGED = new ArrayList<>();

        List<ContratHeader> contratHeaders = contratFacade.rechercherContratsEre();

        for (ContratHeader contratHeader : contratHeaders) {
            RechDocGEDDto inAC = RechDocGEDDto.prepareRechDocGEDDto(contratHeader.getContratId(),
                                                                    DocumentRefType.AC.name(), userContextHolder.get()
                                                                                                                .getNumeroPersonneEre());

            RechDocGEDResponseDto responseAC = documentationFacade.rechercherDernierDocumentEre(inAC);

            if (responseAC.getDocGED() != null) {
                docsGED.addAll(responseAC.getDocGED());
            }

            RechDocGEDDto inPRUN = RechDocGEDDto.prepareRechDocGEDDto(contratHeader.getContratId(),
                                                                      DocumentRefType.PRUN.name(), userContextHolder.get()
                                                                                                                    .getNumeroPersonneEre());

            RechDocGEDResponseDto responsePRUN = documentationFacade.rechercherDernierDocumentEre(inPRUN);

            if (responsePRUN.getDocGED() != null) {
                docsGED.addAll(responsePRUN.getDocGED());
            }
        }

        if (!docsGED.isEmpty()) {
            docsGED.sort(Comparator.comparing(DocGEDDto::getDateIndexation));
            DocGEDDto doc = docsGED.get(docsGED.size() - 1);

            ContratId contrat = contratFacade.rechercherContratParId(doc.getIdContrat()).getContratId();

            try {
                return DocumentDto.builder()
                        .code(doc.getTypeDoc())
                        .name(DocumentRefType.valueOf(doc.getTypeDoc()).getCode())
                        .date(DateUtils.dateToString(doc.getDateIndexation()))
                        .contratId(contrat)
                        .build();
            } catch (Exception e) {
                // DocumentRefType introuvable => Cas impossible
            }
        }
        return null;
    }

    @Override
    public List<ContratParcoursDto> getContrats() throws TechnicalException {
        List<ContratParcoursDto> listContratParcours = contratFacade.rechercherContrats()
                .stream()
                .filter(contrat -> !contrat.getAffichageType().equals(AffichageType.MASQUE)
                        && !contrat.getAffichageType().equals(AffichageType.GRISE))
                .filter(contrat -> !contrat.isClasseAutreContrat())
                .filter(contrat -> contrat.isEre()
                        || contrat.isMdpro() && (contrat.hasCompartiments(CompartimentType.C1)
                        || contrat.hasCompartiments(CompartimentType.C4)))
                .map(contrat -> contratParcoursMapper.map(contrat, true))
                .sorted(Comparator.comparingDouble(contrat -> contrat.getEncours() != null &&
                        contrat.getEncours().getMontantEncours() != null ? contrat.getEncours()
                                                                                  .getMontantEncours() : 0))
                .collect(Collectors.toList());

        Collections.reverse(listContratParcours);
        if (!CollectionUtils.isEmpty(listContratParcours)) {
            return listContratParcours.stream().limit(3).collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }


    }

}
