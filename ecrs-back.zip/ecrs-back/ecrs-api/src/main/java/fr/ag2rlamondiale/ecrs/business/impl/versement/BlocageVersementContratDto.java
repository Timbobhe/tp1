package fr.ag2rlamondiale.ecrs.business.impl.versement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class BlocageVersementContratDto {
    private boolean contratBloque;
}
