package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;

public interface ArbitrageQuestionResolver {

    /**
     *
     * @param questionType
     * @param contexte Le Contexte est mis à jour par le Resolver
     * @param <R>
     * @param <Q>
     * @return
     * @throws TechnicalException
     */
    <R, Q> QuestionResponsesDto<R, Q> resolve(QuestionType questionType, ArbitrageContexteDto contexte) throws TechnicalException;

    boolean accept(QuestionType questionType, ArbitrageContexteDto contexte);
}
