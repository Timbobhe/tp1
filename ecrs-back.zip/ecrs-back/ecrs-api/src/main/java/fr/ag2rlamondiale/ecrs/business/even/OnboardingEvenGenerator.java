package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.List;

import static fr.ag2rlamondiale.trm.utils.CollectionUtils.escapeNull;

/**
 * <p>
 * <h3>Pour les clients ERE :</h3>
 * L’onboarding doit être déclenché lors de la première connexion (première connexion = aucune ligne insérée pour le client dans la table tbcl0not)<br>
 * Si le client a plusieurs contrats, les informations de l’onboarding concernent le dernier contrat pour lequel le client s’est affilié.<br>
 * Une fois le client va jusqu’au bout de l’onboarding l’événement ne s’affiche plus.
 * </p>
 *
 * <p>
 * <h3>Pour les clients MDPRO :</h3>
 * L’onboarding est déclenché pour tous les clients MDPRO jusqu'à ce qu’il soit traité.
 * </p>
 *
 * <p>
 * <h3>Pour les clients multi-équipé ERE et MDPRO :</h3>
 * L'événement doit concerné le dernier contrat ERE pour lequel le client s’est affilié.<br>
 * </p>
 *
 * <p>
 * <h3>Pour les connexion depuis un partenaire :</h3>
 * l’événement ne doit pas être déclenché
 * </p>
 */
@Component
@Slf4j
public class OnboardingEvenGenerator extends AbstractEvenWithoutContratGenerator {

    @Override
    protected boolean evaluerEvenement(String numPersonne) {
        return true;
    }

    @Override
    public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
            Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {

        for (EvenementJson historiqueEven : escapeNull(historiqueEvens)) {
            if (!historiqueEven.getTypeEvenement().getCodeEvenement().equals(TypeEven.ONBOARDING.getCode())) {
                return;
            }
        }

        super.testDeclenchement(idGdi, numPersonne, typeEven, contrats, historiqueEvens, results);
    }

    @Override
    public void prepare(String idGdi, String numPersonne, Collection<ContratHeader> contrats) {
        // aucune preparation necessaire
    }
}
