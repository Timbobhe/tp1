package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationUserDansSiloType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", imports = {CodeApplicationType.class})
public abstract class IdentificationUserDansSiloMapper {

    @Mapping(target = "identifiantDansSilo", source = "idGdi")
    @Mapping(target = "libelleNomSilo", source = "contrat.codeSilo.libelle")
    @Mapping(target = "codeApplication", expression = "java(CodeApplicationType.ECRS.getCode())")
    @Mapping(target = "libelleApplication", constant = FormulaireConstantes.ESPACE_CLIENT_PARTICULIER_ERE)
    @Mapping(target = "codeSystemeInformation", source = "contrat.codeSilo.libelle")
    @Mapping(target = "libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)
    public abstract IdentificationUserDansSiloType mapToIdentificationUserDansSilo(DemandeCreationSigElec demande);
}
