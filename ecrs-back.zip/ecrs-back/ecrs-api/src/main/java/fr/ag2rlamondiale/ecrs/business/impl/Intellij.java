package fr.ag2rlamondiale.ecrs.business.impl;

import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class Intellij {
    public static int addNegValues(ArrayList<Integer> list) {
        return list.stream().
                filter(integer -> integer.compareTo(0) < 0).reduce(0, Integer::sum);
    }

    static boolean exists(int[] ints, int k) {
        return Arrays.binarySearch(ints, k) > 0;
    }

    static boolean recherche(int[] T, int valeurATrouver) {
        for (int i = 0; i < T.length; i++) {
            if (T[i] == valeurATrouver) {
                return true;
            }
        }
        return false;


//        return Arrays.asList(tab).contains(toFind)
    }

    static boolean validerCodePromo(String code) {
        return "POMO5".equals(code) || "PROMO10".equals(code);
    }

    static boolean validerCodePromo() {
        return true;
    }


    public static void main(String[] args) {
        ArrayList<Integer> liste = new ArrayList<Integer>();


        liste.add(1);
        liste.add(-2);
        liste.add(3);
        liste.add(-4);
        liste.add(-5);
        liste.add(6);
        liste.add(7);

        // System.out.println(addNegValues(liste));
        int[] ii = new int[0];


        int[] ints = {-9, 14, 37, 102};
        // System.out.println(exists(ii, 103));


        ArrayList<String> languages = new ArrayList<String>();
        languages.add("PHP");
        languages.add("Java");
        languages.add("C++");
        languages.add("Python");

        languages.trimToSize();
        System.out.println(languages.size());


    }
}

//    int a = 0; b=1;c=0;
//        for(i=2;i< 100-c;++i){
//        c=a+b;
//        a=b;
//        b=c;
//        System.out.println(" "+c;)
//        }
//
//        List<Client> clients=...100k
//
//        List<Long> idVips=...25k
//
//        for


class A {


    public List clients(List<Client> clients, List<Long> idVips) {
        List<Client> clients1 = new ArrayList<>();
        List<Client> clients2 = new ArrayList<>();
        List<Client> clients3 = new ArrayList<>();
        List<Client> clients4 = new ArrayList<>();

        List<Client> clientsDansLesDeuxListes = new ArrayList<>();
//        for (Long idVip : idVips) {
//            for (Client client : clients) {
//                if (idVip.compareTo(client.idVip) = 0) {
//                    clientsDansLesDeuxListes.add(client);
//                }
//            }
//        }
        return clientsDansLesDeuxListes;
    }

    class Client {
        private Long idVip;
    }

    private static class AHolder {
        private static final A INSTANCE = new A();
    }

    public static A getInstance() {
        return AHolder.INSTANCE;
    }
}

class AlgorithmSingleton {
    private int counter = 0;
    private static AlgorithmSingleton instance;

    public int count() {
        return counter = counter + 1;
    }

    public static AlgorithmSingleton getInstance() {
        if (instance == null) {
            instance = new AlgorithmSingleton();
        }
        return instance;
    }
}

class MyCounter2 {
    private static int counter = 0;

    public static synchronized int getCount() {
        return counter++;
    }
}

class MyCounter4 {
    private static AtomicInteger counter = new AtomicInteger(0);

    public static int getCount() {
        return counter.getAndIncrement();
    }
}

class SolutiondisTwin {
    public static boolean isTwin(String a, String b) {
        char[] first = a.toLowerCase().toCharArray();
        char[] second = b.toLowerCase().toCharArray();
        Arrays.sort(first);
        Arrays.sort(second);
        return Arrays.equals(first, second);
    }

    public boolean return1(int a, int b) {
        return ((a + b) == 1 || a == 1 || b == 1);
    }
}

class Algorithm {
    /**
     * @return the largest number of the given array
     */
    static int findLargest(int[] numbers) {
        int maxVal = numbers[0];
        for (int i = 1; i < numbers.length; i++) {
            if (numbers[i] > maxVal) maxVal = numbers[i];
        }
        return maxVal;

    }

    public int maxValue(int array[]) {
        return Arrays.stream(array).max().getAsInt();

    }

    public static int getLargestElement(int[] arr) {
        Arrays.sort(arr);
        return arr[arr.length - 1];
    }
}

class GFG {
    public static void main(String[] args) {
        int arr[] = {10, 324, 45, 90, 9808};
        int max = Arrays.stream(arr).max().getAsInt();
        System.out.println("Largest in given array is " + max);
    }

}

class Solution {

    static int sumRange(int[] ints) {
        int sum = 0;
        for (int i = 1; i < ints.length; i++) {
            int n = ints[i];
            if (n >= 10 && n <= 100)
                sum += n;

        }
        return sum;

        //int sum2 = Arrays.stream(ints, 10, 100).sum();
    }

    // calcul somme nombre pairs
    public void main(String[] commandLine) {

        int total = IntStream.rangeClosed(10, 100)
                             .filter(i -> i % 2 == 0)
                             .sum();

        System.out.println(String.format("The total is %d", total));
    }
}

class MyCounterSynchronized {
    private static int counter = 0;

    public static synchronized int getCount() {
        return counter++;
    }
}

class MyCounterSynchronizedV2 {
    private static AtomicInteger counter = new AtomicInteger(0);

    public static int getCount() {
        return counter.getAndIncrement();
    }
}


class DuoDigit {
    public static String isDuoDigit(int number) {
        boolean isDuoDigit = Integer.toString(number).replace("-", "").chars().distinct().count() <= 2;
        return isDuoDigit ? "y" : "n";
    }

    public static String isDuoDigit2(int number) {
        boolean isDuoDigit = Integer.toString(Math.abs(number)).chars().distinct().count() <= 2;
        return isDuoDigit ? "y" : "n";
    }

/*    public static Map sortByValue(Map map) {
        return map.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue())
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));
    }*/


    // sequence se réjoignant
    class Solution {

        public int computeJoinPoint(int s1, int s2) {
            int joinedPoint = 1;
            Map<Integer, String> joiner = new HashMap<>();

            while (joinedPoint > 0 && joinedPoint < 20000000) {
                if ((s1 + computeSumChar(s1 + "")) == (s2 + computeSumChar(s2 + "")))
                    return (s1 + computeSumChar(s1 + ""));
                else {
                    s1 = (s1 + computeSumChar(s1 + ""));
                    s2 = (s2 + computeSumChar(s2 + ""));
                }
            }

            return 0;
        }

        private int computeSumChar(String input) {
            int inputAsInt = 0;
            for (int i = 0; i < input.length(); i++)
                inputAsInt += Integer.parseInt(input.charAt(i) + "");

            // System.out.println("inputAsInt:"+inputAsInt);
            return inputAsInt;
        }

        /* Ignore and do not change the code below */
        // #region main
        public void main(String args[]) {
            Scanner in = new Scanner(System.in);
            int s1 = in.nextInt();
            int s2 = in.nextInt();
            PrintStream outStream = System.out;
            System.setOut(System.err);
            int res = computeJoinPoint(s1, s2);
            System.setOut(outStream);
            System.out.println(res);
        }
        // #endregion
    }

    String newLine = System.getProperty("line.separator");

    public String stringConcatenation() {
        return "Get busy living"
                + newLine
                + "or"
                + newLine
                + "get busy dying."
                + newLine
                + "--Stephen King";
    }

    public String stringJoin() {
        return String.join(newLine,
                           "Get busy living",
                           "or",
                           "get busy dying.",
                           "--Stephen King");
    }

    public String stringBuilder() {
        return new StringBuilder()
                .append("Get busy living")
                .append(newLine)
                .append("or")
                .append(newLine)
                .append("get busy dying.")
                .append(newLine)
                .append("--Stephen King")
                .toString();
    }

    public char scanChar(String s) {
        for (char c = 'A'; c <= 'Z'; c++) {
            // Check to see if the character corresponds with the ASCII art.

//            if (AsciiArt.printChar(c).equals(s)) {
//                // Return the character if it does.
//                return c;
//            }
        }

        return (char) '?';

    }

    public String remove() {

        return new StringBuilder()
                .append("Get busy living")
                .append(newLine)
                .append("or")
                .append(newLine)
                .append("get busy dying.")
                .append(newLine)
                .append("--Stephen King")
                .toString();
    }
}

class Element {
    Chain parent; // liste à laquelle appartient l’élément
    Element prev; // élément précédant dans la chaîne
    Element next; // élément suivant dans la chaîne

    public Chain getParent() {
        return parent;
    }

    public void setParent(Chain parent) {
        this.parent = parent;
    }

    public Element getPrev() {
        return prev;
    }

    public void setPrev(Element prev) {
        this.prev = prev;
    }

    public Element getNext() {
        return next;
    }

    public void setNext(Element next) {
        this.next = next;
    }
}


class Chain {
    Element first; // premier élément de la liste
    Element last; // dernier élément de la liste
    // methodes ici

    private static Chain instance;

    // Singleton non synchronisé
    public static Chain getInstance() {
        if (instance == null) {
            instance = new Chain();
        }
        return instance;
    }

    public void remove(Element elementToRemove) {
        if (elementToRemove.getParent() != null) {
            if (elementToRemove.getPrev() != null) {
                elementToRemove.getPrev().setNext(elementToRemove.getPrev().getNext());
            } else {
                this.first = elementToRemove.getNext();
            }

            if (elementToRemove.getNext() != null) {
                elementToRemove.getNext().setPrev(elementToRemove.getPrev());
            } else {
                this.last = elementToRemove.getPrev();
            }
        } else {
            System.out.println("cet objet ne figure pas dans la liste");
        }
    }

    // Do not modify Change
    class Change {
        long coin2 = 0;
        long bill5 = 0;
        long bill10 = 0;

        public Change() {
            coin2 = 0;
            bill5 = 0;
            bill10 = 0;
        }


        public long sum() {
            return 2 * coin2 + 5 * bill5 + 10 * bill10;
        }

        @Override
        public String toString() {
            return "[coin2=" + coin2 + "; bill5=" + bill5 + "; bill10=" + bill10 + "]";
        }
    }

    class Solution {

        Change optimalChange(long s) {
            if (s < 2) {
                throw new IllegalArgumentException("The amount must be >= 2");
            }
            Change c = new Change();
            long rest = s;
            c.bill10 = s / 10;
            rest = s % 10;

            if (rest < 5 && rest % 2 != 0) {
                if (c.bill10 > 0) {
                    c.bill10--;
                    rest = rest + 10;
                }
            }
            c.bill5 = rest / 5;
            rest = rest % 5;

            if (rest != 0 && rest % 2 != 0) {
                if (c.bill5 > 0) {
                    c.bill5--;
                    rest = rest + 5;
                }
            }
            if (rest % 2 == 0) {
                c.coin2 = rest / 2;
            }

            // For debug purpose only
            System.out.println(c.toString() + " => " + s);

            return c;
        }

    }


    public class SuiteFibonacciMethod2 {
        int nbr1 = 0;
        int nbr2 = 1;
        int nbr3 = 0;

        void displayFibonacci(int c) {
            if (c > 0) {
                nbr3 = nbr1 + nbr2;
                nbr1 = nbr2;
                nbr2 = nbr3;
                System.out.print(" " + nbr3);
                displayFibonacci(c - 1);
            }
        }

        public void main(String args[]) {
            int c = 10;
            //print 0 and 1
            System.out.print(nbr1 + " " + nbr2);
            //deduire 2 car 0 et 1 sont deja affiches
            displayFibonacci(c - 2);
        }
    }


    // compare two hashmap
    private boolean areEqual(Map<String, String> first, Map<String, String> second) {
        if (first.size() != second.size()) {
            return false;
        }

        return first.entrySet()
                .stream()
                .allMatch(e -> e.getValue().equals(second.get(e.getKey())));
    }

    // compare two hashmap values
    private Map<String, Boolean> areEqualKeyValues(Map<String, String> first, Map<String, String> second) {
        return first.entrySet()
                .stream()
                .collect(Collectors.toMap(e -> e.getKey(),
                                          e -> e.getValue().equals(second.get(e.getKey()))));
    }


//    // The Parse API
//    LocalDate date = LocalDate.parse("2018-05-05");
//    LocalDateTime dateTime = LocalDateTime.parse("2018-05-05T11:50:55");
//
//    SimpleDateFormat formatter = new SimpleDateFormat("dd-M-yyyy hh:mm:ss a", Locale.ENGLISH);
//    formatter.setTimeZone(TimeZone.getTimeZone("America/New_York"));
//
//    String dateInString = "22-01-2015 10:15:55 AM";
//    Date date = formatter.parse(dateInString);
//    String formattedDateString = formatter.format(date);
//
//    // fuite memoire
//    //https://programmer.ink/think/an-example-of-memory-leak.html
//    class Stack1 {
//        private Object[] elements;
//        private int size = 0;
//        private static final int DEFAULT_INITIAL_CAPACITY = 16;
//
//        public Stack() {
//            elements = new Object[DEFAULT_INITIAL_CAPACITY];
//        }
//
//        public void push(Object e) {
//            ensureCapacity();
//            elements[size++] = e;
//        }
//
//        public Object pop() {
//            if (size == 0)
//                throw new EmptyStackException();
//            Object result = elements[--size];
//            elements[size] = null; //Eliminate out of date references
//            return result;
//        }
//
//        public void ensureCapacity() {
//            if (elements.length == size)
//                elements = Arrays.copyOf(elements, 2 * size + 1);
//
//        }
//    }


    public class Sample {

        public void main(String[] args) {

//            String welcome = """
//                My Super App - Copyright KooR.fr
//                Usage: [options] SuperApp param1 param2
//                    -h      display this help
//                    -x      imagine a parameter
//                """;
//
//            System.out.print( welcome );

            // La suite du programme

        }
    }

//    n'oubliez pas qu'un décalage vers la gauche correspond à une multiplication par 2 et qu'un décalage vers la droite correspond à une division par 2.
//    En conséquence, l'exemple ci-dessous multiplie 17 par 4 et divise 17 par 4 (division entière).


    public class A {
        // doit executer le service avec les connections données

        void a(Service s, Connection c) {
            try {
                s.setConnection(c);
                s.execute();
                c.commit();  // si ok on "commit"
            } catch (Exception e) {
                c.rollback(); // si ko on "rollback"
            } finally {
                c.close();  // dans tous les cas : on appelle "close"
            }
        }
    }

    interface Service {
        void execute() throws Exception;

        void setConnection(Connection c);
    }

    interface Connection {
        void commit();

        void rollback();

        void close();
    }

    public static void main(String[] args) {
        Service service = new Service() {
            public void execute() throws Exception {
                System.out.println("execute");
            }

            public void setConnection(Connection c) {
                System.out.println("setConnection");

            }
        };
    }

    class GFG {

        int numberOfWays(int x) {
            // Base condition
            if (x == 0 || x == 1)
                return 1;

                // A participant can choose to consider
                // (1) Remains single. Number of people
                //     reduce to (x-1)
                // (2) Pairs with one of the (x-1) others.
                //     For every pairing, number of people
                //     reduce to (x-2).
            else
                return numberOfWays(x - 1) +
                        (x - 1) * numberOfWays(x - 2);
        }

        // Driver code
        public void main(String[] args) {
            int x = 3;
            System.out.println(numberOfWays(x));

        }
    }

    class Node {
        // keep these​​​​​​‌​​‌‌​​‌​​​‌​​​‌‌​‌‌‌‌​​‌ fields
        Node left, right;
        int value;

        public Node find(int v) {
            Node current = this;
            while (current != null) {
                if (current.value == v) {
                    return current;
                }
                // This will drop out of the loop naturally if there's no appropriate subnode
                current = v < current.value ? current.left : current.right;
            }
            return null;
        }
    }


    class ADD {

        /**
         * Checks that the given string is​​​​​​‌​​‌‌​​‌​​​‌​​​‌‌​‌‌‌‌​​‌ correct.
         */
        boolean check(String str) {
            Stack<Character> stack = new Stack<Character>();
            for (int i = 0; i < str.length(); i++) {
                char c = str.charAt(i);
                if (c == '[' || c == '(') {
                    stack.push(c);
                } else if (c == ']') {
                    if (stack.isEmpty() || stack.pop() != '[') {
                        return false;
                    }
                } else if (c == ')') {
                    if (stack.isEmpty() || stack.pop() != '(') {
                        return false;
                    }
                }
            }
            return stack.isEmpty();
        }
    }

    //https://stackoverflow.com/questions/41292387/reccurence-algorithm-find-position-after-n-moves
    class Algorithm {

        /**
         * Computes the position of
         */
        int getPositionAt(int n) {
//stage(n) = stage(n-1) - stage(n-2)
//pos(n) = pos(n-1) + stage(n)
            int position = 0;
            int step1 = 1;
            position = position + step1;
            n = n - 1;
            int step2 = -2;
            position = position + step2;
            n -= 1;
            while (n > 0) {
                position = position + (step2 - step1);
                int buffer = step1;
                step1 = step2;
                step2 = step2 - buffer;
                n -= 1;
            }
            return position;
        }
    }

    // JAVANAIS https://github.com/musenga17/javanais/blob/master/Javanais.java


}


class Test {
    public static void main(String args[]) {
        String s1 = new String("ABC");
        String s2 = "ABC";
        boolean isEqual;

        isEqual = s1.equals(s2);
        System.out.println(isEqual);

        isEqual = (s1 == s2);
        System.out.println(isEqual);

    }
}

class Test3 {
    public static void main(String args[]) {
        int i = 0;
        outer:
        while (i < 11) {
            if (i == 10)
                break;
            if (i == 9)
                continue outer;
            if (i == 8)
                continue;
            ++i;
        }
        outer:
        System.out.println("i=" + i);
    }
}

// class Test4 {
//    public static void main (String args [] ) {
//        List numbers = Arrays.asList(0, 1, 2, 3);
//        Stream stream = numbers.stream();
//
//        stream.filter(nbr -> nbr > 1)
//              .forEach(nbr -> System.out.println(nbr));
//
//        Long count = stream.count();
//        System.out.println(count);
//    }
//
//}

class Test45 {
    public static void main(String args[]) {
        int n = 3;
        switch (n) {
            case 3:
                System.out.println("Case 3");
            case 0:
                System.out.println("Case 0");
                break;
            default:
                System.out.println("Default");
                break;
        }
    }
}


class Test6 {
    public static void main(String args[]) {
        int i = 0;
        do {
            if (i == 2)
                i = 3;
        } while (i++ < 2);

        System.out.println(i);
    }
}

class Test7 {
    public static void main(String args[]) {
        int i = 0;
        boolean t = true;
        boolean f = false;
        boolean b;

        b = (t && ((i++) == 0));
        b = (f && ((i += 2) > 0));

        System.out.println(i);
    }
}

class TTT {
    public static void main(String args[]) {

        String a = "Helloworld !";
        String b = "Helloworld !";

        boolean c = a == b;
        boolean d = a.equals(b);

        System.out.println("c=" + c + " d=" + d);
    }
}

class Test10 extends Thread {

    public void run() {

        for (int i = 0; i < 20; i++)

            System.out.println("Bonjour");

    }

    public static void main(String[] args) {

        Test t = new Test();

    }

}


class GenerateInsertScript {

    public static void main(String[] args) throws IOException {

        final String request = "INSERT INTO TBCLXPRM(IDPRM, TYPRM, COPRM, LBPRM, VAPRM001, DTDEBVAL, TSCRE) VALUES (CLXPRMQ.NEXTVAL, '%s', '%s', '%s', '%s', '01/01/2022', CURRENT_TIMESTAMP);";
        final String delimiter = ";";

        List<String> statements = new ArrayList<>();

        List<String> lines = Files.readAllLines(Paths.get("libelle_support.csv"));
        String[] columnNames = lines.get(0).split(delimiter);

        for (int i = 1; i < lines.size(); i++) {
            String[] values = lines.get(i).split(delimiter);
            statements.add(String.format(request, "SUPPORT", escapeString(values[0]), escapeString(values[4]), escapeString(values[2])));
        }

        Files.write(Paths.get("result.sql"), statements);
    }

    private static String escapeString(String value) {
        return value.replace("'", "''");
    }
}

//
//class GenerateInsertScript {
//
//    public static void main(String[] args) throws IOException {
//
//        final String request = "INSERT INTO TBCL0BLO(%s, %s, %s, %s, %s, %s, %s, %s) VALUES (%s, '%s', '%s', '%s', '%s', '%s', '%s', '%s');";
//        final String delimiter = ";";
//
//        List<String> statements = new ArrayList<>();
//
//        List<String> lines = Files.readAllLines(Paths.get("libelle_support.csv"));
//        String[] columnNames = lines.get(0).split(delimiter);
//
//        for (int i = 1; i < lines.size(); i++) {
//            String[] values = lines.get(i).split(delimiter);
//            statements.add(String.format(request, columnNames[0], columnNames[1], columnNames[2], columnNames[3], columnNames[4], columnNames[7], columnNames[8], columnNames[9],
//                                         (3718083 + i), "A1324", "Blocage de 469 personnes de Total", "20/04/22", "DIALLOM2", "ERE", "PERSONNE", values[0]));
//        }
//        Files.write(Paths.get("result.sql"), statements);
//    }





























