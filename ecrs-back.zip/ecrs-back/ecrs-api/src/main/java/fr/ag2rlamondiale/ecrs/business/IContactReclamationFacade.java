package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ReclamationResponseDto;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;

import java.util.List;

public interface IContactReclamationFacade {
    List<ContratParcoursDto> start() throws TechnicalException;

    ReclamationResponseDto createDemande(ContactReclamationDto dto) throws TechnicalException;

    boolean isLimiteCinqDemandesParJourAtteinte(ContactReclamationDto dto) throws WorkflowException;
}
