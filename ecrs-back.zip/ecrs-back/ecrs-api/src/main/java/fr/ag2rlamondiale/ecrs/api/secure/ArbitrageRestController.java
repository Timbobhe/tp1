package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArbitrageFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageStartDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.RequestQuestionArbitrageDto;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;

/**
 * Implementation Spring du service REST pour la Modification/Arbitrage de Gestion financiere
 */
@RestController
@RequestMapping(path = "/secure")
public class ArbitrageRestController {

    @Autowired
    private IArbitrageFacade arbitrageFacade;

    @ProfileExecution(codeAction = CodeActionType.API_ARBITRAGE_START)
    @LogExecutionTime
    @GetMapping(path = "/arbitrage/start")
    public ArbitrageStartDto start(@RequestParam(required = false) String paramFluxStock) throws TechnicalException {
        return arbitrageFacade.startModificationArbitrage(ParamFluxStock.fromString(paramFluxStock));
    }

    @ProfileExecution(codeAction = CodeActionType.API_ARBITRAGE_QUESTION)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/arbitrage/question")
    public QuestionResponsesDto<Object, Object> question(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    RequestQuestionArbitrageDto req) throws TechnicalException {
        return arbitrageFacade.resolveQuestion(req);
    }

    @ProfileExecution(codeAction = CodeActionType.API_ARBITRAGE_QUESTION_OR_NEXT)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/arbitrage/question-or-next")
    public ListQuestionResponsesDto resolveQuestionOrNext(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    RequestQuestionArbitrageDto req) throws TechnicalException {
        return arbitrageFacade.resolveQuestionOrNext(req);
    }

    @ProfileExecution(codeAction = CodeActionType.API_ARBITRAGE_TERMINATE)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/arbitrage/terminate")
    public String terminate(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE}) ArbitrageTerminateDto arbitrageTerminateDto,
            @RequestParam("frame") boolean frame) throws TechnicalException, IOException, JAXBException {
        return arbitrageFacade.terminate(arbitrageTerminateDto, frame);
    }
}
