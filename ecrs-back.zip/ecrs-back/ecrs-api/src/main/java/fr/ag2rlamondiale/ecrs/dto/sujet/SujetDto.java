package fr.ag2rlamondiale.ecrs.dto.sujet;

import lombok.*;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SujetDto {
    private static final long serialVersionUID = 5529865317883515553L;

    private Integer idSujet;
    private String titre;
    private String typeSujet;
    private String url;
    private List<Integer> sousSujets;
}
