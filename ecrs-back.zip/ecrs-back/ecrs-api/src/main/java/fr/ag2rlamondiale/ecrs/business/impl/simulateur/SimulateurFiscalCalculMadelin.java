package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.simulateur.dto.Context;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationMDPType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.simulateur.enumeration.EconomieFiscaleContextKeyEnum.*;

@Service
public class SimulateurFiscalCalculMadelin extends BaseSimulateurFiscalCalcul implements ISimulateurFiscalCalcul {

    private static final List<CodeTypeOperationMDPType> CODES_TYPE_OPERATION_COTISATIONS_VERSEMENTS_MADELIN = Arrays
            .asList(CodeTypeOperationMDPType.AP, CodeTypeOperationMDPType.NL, CodeTypeOperationMDPType.VL);

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private CalculDisponibleCommand calculDispoFiscalCommand;

    @Autowired
    private CalculVersementsComplementairesCommand calculVersComplCommand;

    @Autowired
    private CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Autowired
    private CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Autowired
    private CalculEconomieFiscaleCommand calculGainFiscalCommand;

    private static final BigDecimal TRANCHE_1 = new BigDecimal("0.1");
    private static final BigDecimal TRANCHE_2 = new BigDecimal("0.15");
    private static final BigDecimal PLANCHER_REVENU = BigDecimal.ONE;
    private static final BigDecimal PLAFOND_REVENU = new BigDecimal(8);


    private static final List<CodeTypeOperationMDPType> CODES_TYPE_OPERATIONS_VERSEMENTS_MADELIN = Arrays
            .asList(CodeTypeOperationMDPType.NL, CodeTypeOperationMDPType.VL);

    @Override
    public ResultatCalculEpargne calculerDisponibleFiscal(DemandeCalculEpargne demande) throws TechnicalException {
        ContratId contratId = demande.getContrat();
        ContratComplet contratComplet = contratFacade.rechercherContratCompletParId(contratId);

        // param Annee (on fait la simulation pour savoir le gain fiscal de l'année n+1)
        demande.setYear(Annee.Courante.getYear());
        final Context<EconomieFiscaleContextKeyEnum, Object> context = initContextSimulateurFiscal(demande);

        ContratHeader contratHeader = contratComplet.getContratHeader();


        context.put(COTISATIONS_BRUTES, demande.getCotisation());
        context.put(COTB_CET_NDED, BigDecimal.ZERO);

        // La taille de la jauge ( 1 er calcul + 2 eme calcul)
        final BigDecimal plafondVIF = getMontantPlafondVersement(context);
        context.put(EconomieFiscaleContextKeyEnum.PLAFOND_VERSEMENT, plafondVIF);

        final BigDecimal cotisationsDeductibles = calculDispoFiscalCommand
                .calculerMontantCotisationsDeductiblesAvecAbondement(context);

        // VPVL_ANF => les VIFS déjà effectués dans Année N

        final Annee.BorneAnnee anneeCalcul = Annee.fromYear(demande.getYear()).borneAnnee();

        // Cotisations Annee N
        final ContratGeneral contratGeneral = contratComplet.getContratGeneral();
        final BigDecimal mntTotalAnnCotisPeriodiques = contratGeneral.getMontantAnneePrimeTTC();

        // les versements VIF Annee N
        BigDecimal vifBrutsAnneeFiscale = calculMontantVersementsMadelin(contratHeader, anneeCalcul.toFirstDate(), DateUtils.getTodayTimelessDate());

        context.put(EconomieFiscaleContextKeyEnum.VPVL_ANF, vifBrutsAnneeFiscale.add(mntTotalAnnCotisPeriodiques));
        calculVersComplCommand.calculVersementLibreSaisiComplEtVersemetsProgrammesEcheancier(context);

        final BigDecimal plafondSecuSociale = context.getBigDecimal(PASS);
        final BigDecimal pass10pc = plafondSecuSociale.multiply(new BigDecimal("0.1"));

        final BigDecimal disponibleFiscalGlobal = BigDecimal.ZERO.max(pass10pc.subtract(cotisationsDeductibles))
                                                                 .max(plafondVIF.subtract(vifBrutsAnneeFiscale));

        context.put(DISPONIBLE_FISCAL_GLOBAL, disponibleFiscalGlobal);

        // montant déja versé = versements + cotisations de l'année en cours ( garder un seul )
        final BigDecimal montantDejaVerse = context.getBigDecimal(VPVL_ANF);

        context.put(TOTAL_DEJA_VERSE, montantDejaVerse);

        final BigDecimal resteAVerserParDefaut = BigDecimal.ZERO.max(plafondVIF.subtract(montantDejaVerse));
        context.put(VLB_COMP, resteAVerserParDefaut);

        // Calcul du montant déductible
        calculMontantDeductibleCommand.execute(context);

        // Calcul GainFiscal Annee n+1
        calculGainFiscalCommand.execute(context);

        // effort Epargne reel
        calculEffortEpargneReelCommand.execute(context);

        return buildResultatCalculEpargnefromContext(context);
    }

    private BigDecimal calculMontantVersementsMadelin(ContratHeader contratHeader, Date dateDebut, Date dateFin) {
        List<Operation> operationsCotisationsBrutesCET = operationFacade
                .getOperationsCotisationsEtVersementsSimulateurs(contratHeader, dateDebut, dateFin, CODES_TYPE_OPERATIONS_VERSEMENTS_MADELIN);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutesCET, CodeSiloType.MDP);
    }


    private BigDecimal retrieveMontantPremiereTranche(Context<EconomieFiscaleContextKeyEnum, Object> context) {
        // FORMULE CIBLE : MIN(Plafond*PASS;MAX(PASS*Plancher;somme des champs))

        // MAX(PASS*Plancher;somme des champs)
        final BigDecimal a = context.getBigDecimal(PASS).multiply(PLANCHER_REVENU).max(context.getBigDecimal(COTISATION));

        // Plafond*PASS
        final BigDecimal b = PLAFOND_REVENU.multiply(context.getBigDecimal(PASS));

        // MIN(Plafond*PASS;MAX(PASS*Plancher;somme des champs))
        BigDecimal premierCalcul = b.min(a);

        return TRANCHE_1.multiply(premierCalcul);
    }

    private BigDecimal retrieveMontantDeuxiemeTranche(Context<EconomieFiscaleContextKeyEnum, Object> context) {
        // FORMULE CIBLE : MAX(0;MIN(Plafond*PASS; somme des champs)-PASS)

        // MIN(Plafond*PASS; somme des champs)
        final BigDecimal a = PLAFOND_REVENU.multiply(context.getBigDecimal(PASS))
                                           .min(context.getBigDecimal(COTISATION));

        // MIN(Plafond*PASS; somme des champs)-PASS
        final BigDecimal b = a.subtract(context.getBigDecimal(PASS));

        // MAX(0;MIN(Plafond*PASS; somme des champs)-PASS)
        BigDecimal deuxiemeCalcul = BigDecimal.ZERO.max(b);

        return TRANCHE_2.multiply(deuxiemeCalcul);
    }

    private BigDecimal getMontantPlafondVersement(Context<EconomieFiscaleContextKeyEnum, Object> context) {
        return retrieveMontantPremiereTranche(context).add(retrieveMontantDeuxiemeTranche(context));
    }

    public BigDecimal calculMontantCotisationsVersementsMadelin(ContratHeader contratHeader, Annee annee) {
        final Annee.BorneAnnee borneAnnee = annee.borneAnnee();
        List<Operation> operationsCotisationsBrutesCET = operationFacade.getOperationsCotisationsEtVersementsSimulateurs(
                contratHeader, borneAnnee.toFirstDate(), borneAnnee.toLastDate(), CODES_TYPE_OPERATION_COTISATIONS_VERSEMENTS_MADELIN);
        return additionnerMontantBrutsOperations(operationsCotisationsBrutesCET, CodeSiloType.MDP);
    }

}
