package fr.ag2rlamondiale.ecrs.api.secure;

import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import fr.ag2rlamondiale.ecrs.business.IBiaFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaStartDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaTerminateDto;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

import javax.xml.bind.JAXBException;

@RestController
@RequestMapping(path = "/secure")
public class BiaRestController {

    @Autowired
    private IBiaFacade biaFacade;

    @ProfileExecution(codeAction = CodeActionType.API_BIA_START)
    @LogExecutionTime
    @GetMapping(path = "/bia/start")
    public BiaStartDto start() throws TechnicalException {
        return biaFacade.startBia();
    }

    @ProfileExecution(codeAction = CodeActionType.API_BIA_TERMINATE)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/bia/terminate")
    public String terminate(
            @RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) BiaTerminateDto dto,
            @RequestParam boolean frame) throws IOException, CommonException, JAXBException {
        return biaFacade.terminateBia(dto, frame);
    }
}
