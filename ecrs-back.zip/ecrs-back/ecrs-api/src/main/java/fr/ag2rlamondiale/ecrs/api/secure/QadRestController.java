package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IQadFacade;
import fr.ag2rlamondiale.ecrs.dto.qad.QadRequestDto;
import fr.ag2rlamondiale.ecrs.dto.qad.QadResultDto;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.qad.PropositionJson;
import fr.ag2rlamondiale.trm.domain.qad.QuestionJson;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@Api("Ce Endpoint permet de gerer le QAD MDP/ERE")
@RestController
@RequestMapping(path = "/secure")
public class QadRestController {

    @Autowired
    private IQadFacade qadFacade;
    
    @ApiOperation("Cette methode permet des recup\u00E9rer les Questions du QAD")
    @ProfileExecution(codeAction = CodeActionType.API_QAD_START)
    @PostMapping(path = "/qad/qad-questions")
    @Secure
    public List<QuestionJson> getQadQuestionReponses(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) QadRequestDto qadDto)
            throws TechnicalException {
        return qadFacade.getQadQuestRep(qadDto);
    }

    @ApiOperation("Cette methode permet de calculer la grille \u00E0 proposer")
    @PostMapping(path = "/qad/profil-proposition")
    @Secure
    public List<PropositionJson> getQadProposition(@RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) QadResultDto qadResultDto) throws TechnicalException {
        return qadFacade.getTypesPropositionGrille(qadResultDto);
    }


}
