package fr.ag2rlamondiale.ecrs.security;


import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static fr.ag2rlamondiale.ecrs.web.EcrsWebConstants.ORDER_FILTER_PARTENAIRE_EXCEPTION;

public class PartenaireExceptionFilter extends GenericFilterBean implements Ordered {
    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
                         FilterChain filterChain) throws IOException, ServletException {
        try {
            filterChain.doFilter(servletRequest, servletResponse);
        } catch (Exception ex) {
            UserContext user = userContextHolder.get();
            if (user != null) {
                Partenaire partenaire = user.getPartenaire();
                if (partenaire != null && partenaire.getUrlError() != null) {
                    HttpServletResponse httpResponse = (HttpServletResponse) servletResponse;
                    httpResponse.sendRedirect(
                            buildPartenaireErrorRedirect(partenaire.getUrlError(), ex));
                    return;
                }
            }
            throw ex;
        }
    }

    private static String buildPartenaireErrorRedirect(String urlError, Exception ex) {
        String finalUrl = urlError;
        if (ex instanceof PartenaireException) {
            finalUrl += "?id=" + ((PartenaireException) ex).getErrorCode().name();
        }
        return finalUrl;
    }

    @Override
    public int getOrder() {
        return ORDER_FILTER_PARTENAIRE_EXCEPTION;
    }
}
