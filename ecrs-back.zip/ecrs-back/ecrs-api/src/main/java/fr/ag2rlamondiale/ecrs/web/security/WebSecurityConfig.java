package fr.ag2rlamondiale.ecrs.web.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.CsrfConfigurer;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.security.web.savedrequest.RequestCache;
import org.springframework.security.web.util.matcher.*;
import org.springframework.web.accept.ContentNegotiationStrategy;
import org.springframework.web.accept.HeaderContentNegotiationStrategy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


@Slf4j
@Configuration
public class WebSecurityConfig {

    @Value("${security.custom.request.cache.urls:GET /**/api/secure/encours_parcours_client}")
    private List<String> customSavedUrlList;


    /**
     * Copié depuis org.springframework.security.config.annotation.web.configurers.RequestCacheConfigurer
     *
     * @param http
     * @return
     */
    @Bean
    @ConditionalOnProperty("security.custom.request.cache.active")
    public RequestCache requestCache(HttpSecurity http) {
        HttpSessionRequestCache defaultCache = new HttpSessionRequestCache();
        final RequestMatcher defaultSavedRequestMatcher = createDefaultSavedRequestMatcher(http);
        final RequestMatcher customEcrsRequestMatcher = antPathConfig().toRequestMatcher();
        RequestMatcher requestMatcher;
        if (customEcrsRequestMatcher == null) {
            requestMatcher = defaultSavedRequestMatcher;
        } else {
            requestMatcher = new OrRequestMatcher(defaultSavedRequestMatcher, customEcrsRequestMatcher);
        }

        defaultCache.setRequestMatcher(requestMatcher);
        log.info("RequestCache HttpSessionRequestCache avec RequestMatcher = {}", requestMatcher);
        return defaultCache;
    }

    private RequestMatcher createDefaultSavedRequestMatcher(HttpSecurity http) {
        RequestMatcher notFavIcon = new NegatedRequestMatcher(new AntPathRequestMatcher("/**/favicon.*"));
        RequestMatcher notXRequestedWith = new NegatedRequestMatcher(
                new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest"));
        boolean isCsrfEnabled = http.getConfigurer(CsrfConfigurer.class) != null;
        List<RequestMatcher> matchers = new ArrayList<>();
        if (isCsrfEnabled) {
            RequestMatcher getRequests = new AntPathRequestMatcher("/**", "GET");
            matchers.add(0, getRequests);
        }
        matchers.add(notFavIcon);
        matchers.add(notMatchingMediaType(http, MediaType.APPLICATION_JSON));
        matchers.add(notXRequestedWith);
        matchers.add(notMatchingMediaType(http, MediaType.MULTIPART_FORM_DATA));
        matchers.add(notMatchingMediaType(http, MediaType.TEXT_EVENT_STREAM));
        return new AndRequestMatcher(matchers);
    }


    public AntPathConfig antPathConfig() {
        return new AntPathConfig(customSavedUrlList);
    }


    private RequestMatcher notMatchingMediaType(HttpSecurity http, MediaType mediaType) {
        ContentNegotiationStrategy contentNegotiationStrategy = http.getSharedObject(ContentNegotiationStrategy.class);
        if (contentNegotiationStrategy == null) {
            contentNegotiationStrategy = new HeaderContentNegotiationStrategy();
        }
        MediaTypeRequestMatcher mediaRequest = new MediaTypeRequestMatcher(contentNegotiationStrategy, mediaType);
        mediaRequest.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
        return new NegatedRequestMatcher(mediaRequest);
    }
}

