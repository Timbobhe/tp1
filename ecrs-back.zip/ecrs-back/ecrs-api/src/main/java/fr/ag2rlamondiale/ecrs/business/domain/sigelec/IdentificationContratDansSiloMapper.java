package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.formulaire.actesenligne.IdentificationContratDansSiloType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.utils.workflow.FormulaireConstantes;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring", imports = {CodeApplicationType.class}, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class IdentificationContratDansSiloMapper {

    @Mapping(target = "identifiantDansSilo", source = "id")
    @Mapping(target = "libelleNomSilo", source = "codeSilo", qualifiedByName = "libelleNomSilo")
    @Mapping(target = "codeApplication", source = "codeSilo", qualifiedByName = "codeApplication")
    @Mapping(target = "libelleApplication", source = "codeSilo", qualifiedByName = "libelleApplication")
    @Mapping(target = "codeSystemeInformation", source = "codeSilo.libelle")
    @Mapping(target = "libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)
    public abstract IdentificationContratDansSiloType mapToIdentificationContratDansSilo(ContratHeader contrat);

    @Named("libelleNomSilo")
    protected String libelleNomSilo(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getLibelle();
    }

    @Named("codeApplication")
    protected String codeApplication(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getCode();
    }

    @Named("libelleApplication")
    protected String libelleApplication(CodeSiloType codeSiloType) {
        return CodeSiloType.ERE.equals(codeSiloType) ? FormulaireConstantes.PTV : FormulaireConstantes.GESTION_8X;
    }
}
