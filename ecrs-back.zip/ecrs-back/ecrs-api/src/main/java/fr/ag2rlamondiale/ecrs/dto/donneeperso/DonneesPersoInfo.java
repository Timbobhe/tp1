package fr.ag2rlamondiale.ecrs.dto.donneeperso;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class DonneesPersoInfo {
	private ModificationsIdentiteInfo identiteInfoValidee;
    private boolean donneesPersonnellesConfirmees;
    private boolean modificationEnCours;
}
