package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoInfo;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursValidation;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;

public interface IDonneesPersoFacade {
    DonneesPersoInfo getDonnesPerso() throws TechnicalException;
    ModifierPPSiloResponseDto validerModifDonnesPerso(DonneesPersoParcoursValidation donneePersoModification) throws TechnicalException;
}
