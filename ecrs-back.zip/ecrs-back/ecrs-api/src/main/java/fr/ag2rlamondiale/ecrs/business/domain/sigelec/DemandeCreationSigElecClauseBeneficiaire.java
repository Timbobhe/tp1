package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.FormulaireActeEnLigneMapperLocator;
import lombok.Data;
import lombok.EqualsAndHashCode;

@FormulaireActeEnLigneMapperLocator(FormulaireClauseBeneficiaireMapper.class)
@EqualsAndHashCode(callSuper = true)
@Data
public class DemandeCreationSigElecClauseBeneficiaire extends DemandeCreationSigElec<ContratHeader> {
    private String clauseBeneficiaire;
    private String clauseBeneficiaireDescription;
}
