package fr.ag2rlamondiale.ecrs.web.security;

import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.NegatedRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@NoArgsConstructor
@Slf4j
public class AntPathConfig {

    /**
     * Exemple
     * GET \/**\/api\/secure\/encours_parcours_client
     */
    private List<String> patterns;

    public AntPathConfig(List<String> patterns) {
        this.patterns = patterns;
    }

    public AntPathConfig(String pattern) {
        this(pattern != null ? List.of(pattern) : null);
    }

    public boolean isEmpty() {
        return patterns == null || patterns.isEmpty();
    }

    public AntPathConfig orDefault(AntPathConfig other) {
        if (!isEmpty()) {
            return this;
        }
        return other;
    }


    public RequestMatcher toRequestMatcher() {
        if (isEmpty()) {
            return null;
        }

        List<RequestMatcher> matchers = new ArrayList<>();
        for (String patternUrl : patterns) {
            final Pattern regex = Pattern.compile("(\\w+)\\s+(\\S+)\\s*(NOT)?");
            final Matcher matcher = regex.matcher(patternUrl);
            if (matcher.matches()) {
                final String pattern = matcher.group(2);
                final String httpMethod = matcher.group(1);
                final String isNot = matcher.group(3);
                RequestMatcher rm = new AntPathRequestMatcher(pattern, httpMethod);
                if (isNot != null) {
                    rm = new NegatedRequestMatcher(rm);
                }

                matchers.add(rm);
                if (log.isDebugEnabled()) {
                    log.debug("Append RequestMatcher {}", rm);
                }
            } else {
                RequestMatcher rm = new AntPathRequestMatcher(patternUrl);
                matchers.add(rm);
                if (log.isDebugEnabled()) {
                    log.debug("Append RequestMatcher {}", rm);
                }
            }

        }
        return new OrRequestMatcher(matchers);
    }
}
