package fr.ag2rlamondiale.ecrs.dto.arbitrage;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ChoixCompartimentDto {
    private ContratParcoursDto compartiment;
    private boolean tousCompartiments;
    private EncoursDto encours;
    private boolean strategieFinanciereImposee;
    private boolean placementsFinanciersIdentique;
    private boolean placementsFinanciersDifferentsAutorises;
}
