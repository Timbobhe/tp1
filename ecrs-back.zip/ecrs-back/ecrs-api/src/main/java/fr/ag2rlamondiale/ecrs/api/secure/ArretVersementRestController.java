package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArretVersementFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.RequestQuestionArretVersementDto;
import fr.ag2rlamondiale.ecrs.profile.ProfileExecution;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;

@RestController
@RequestMapping(path = "/secure")
public class ArretVersementRestController {

    @Autowired
    private IArretVersementFacade arretVersementFacade;

    @ProfileExecution(codeAction = CodeActionType.API_ARRET_VERSEMENT_START)
    @LogExecutionTime
    @GetMapping(path = "/arret-versement/start")
    public ArretVersementStartDto start() throws TechnicalException {
        return arretVersementFacade.startArretVersement();
    }

    @ProfileExecution(codeAction = CodeActionType.API_ARRET_VERSEMENT_QUESTION_OR_NEXT)
    @LogExecutionTime
    @Secure
    @PostMapping(path = "/arret-versement/question-or-next")
    public ListQuestionResponsesDto resolveQuestionOrNext(
            @RequestBody @SecuredParam(paramType = {SecurityParamType.CONTRAT, SecurityParamType.IDASSURE})
                    RequestQuestionArretVersementDto req) throws TechnicalException {
        return arretVersementFacade.resolveQuestionOrNext(req);
    }

    @ProfileExecution(codeAction = CodeActionType.API_ARRET_VERSEMENT_TERMINATE)
    @Secure
    @LogExecutionTime
    @PostMapping(path = "/arret-versement/terminate")
    public String terminate(
            @RequestBody @SecuredParam(paramType = SecurityParamType.CONTRAT) ArretVersementTerminateDto arretVersementTerminate,
            @RequestParam("frame") boolean frame) throws TechnicalException, IOException, JAXBException {
        return arretVersementFacade.terminate(arretVersementTerminate, frame);
    }
}
