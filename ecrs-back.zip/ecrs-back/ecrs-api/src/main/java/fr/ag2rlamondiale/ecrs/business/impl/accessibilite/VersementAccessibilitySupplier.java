package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IVersementFacade;
import fr.ag2rlamondiale.ecrs.dto.versement.InfoVersementContratDto;
import fr.ag2rlamondiale.trm.business.accessibilite.IFunctionalityAccessibilitySupplier;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT;

@Component
public class VersementAccessibilitySupplier implements IFunctionalityAccessibilitySupplier {

    @Autowired
    private IVersementFacade versementFacade;

    @Override
    public boolean accept(FonctionnaliteType fonctionnaliteType) {
        return FonctionnaliteType.VERSEMENT.equals(fonctionnaliteType);
    }

    @Override
    public AccesFonctionnaliteDto check() throws TechnicalException {
        AccesFonctionnaliteDto accesFonctionnalite = new AccesFonctionnaliteDto(FonctionnaliteType.VERSEMENT);

        List<InfoVersementContratDto> versements = versementFacade.startVersement().getVersements();
        boolean isAccessible = CollectionUtils.isNotEmpty(versements)
                && versements.stream().anyMatch(v -> !v.isBloque());

        accesFonctionnalite.setAccessible(isAccessible);

        if (!isAccessible) {
            accesFonctionnalite.setRaison(VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name());
        }
        return accesFonctionnalite;
    }
}
