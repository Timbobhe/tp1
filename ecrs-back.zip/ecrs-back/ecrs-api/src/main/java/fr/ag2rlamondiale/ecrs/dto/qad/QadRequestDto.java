package fr.ag2rlamondiale.ecrs.dto.qad;

import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.qad.QadType;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel("QAD Request Dto")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QadRequestDto implements ISecurityParamAccess {
    private ContratId contrat;
    private QadType type;

    @Override
    public String secureForNumContrat() {
        return contrat != null ? contrat.getNomContrat() : null;
    }
}
