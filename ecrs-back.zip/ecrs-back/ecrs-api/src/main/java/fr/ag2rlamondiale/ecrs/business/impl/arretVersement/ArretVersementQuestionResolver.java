package fr.ag2rlamondiale.ecrs.business.impl.arretVersement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementContexteDto;

public interface ArretVersementQuestionResolver {

    /**
     *
     * @param questionType
     * @param contexte Le Contexte est mis à jour par le Resolver
     * @param <R>
     * @param <Q>
     * @return
     * @throws TechnicalException
     */
    <R, Q> QuestionResponsesDto<R, Q> resolve(QuestionType questionType, ArretVersementContexteDto contexte) throws TechnicalException;

    boolean accept(QuestionType questionType, ArretVersementContexteDto contexte);
}
