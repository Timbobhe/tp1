package fr.ag2rlamondiale.ecrs.business.integration;

import fr.ag2rlamondiale.trm.rest.auth.PfsTokenBuilder;
import fr.ag2rlamondiale.trm.rest.auth.PfsTokenClaims;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@ContextConfiguration(classes = {GenerateTokenIT.class})
@EnableAspectJAutoProxy
@RunWith(SpringJUnit4ClassRunner.class)
public class GenerateTokenIT {

    @Autowired
    private PfsTokenBuilder pfsTokenBuilder;

    @Value("${pfs.token.private.key.password.prod}")
    private String privateKeyName;

    @Bean
    public static PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() throws IOException {
        final PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
        List<Resource> props = new ArrayList<>();
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:webservices-pfs.properties")));
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:webservices-rest.properties")));
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:application-contextual-values.properties")));
        ppc.setLocations(props.toArray(new Resource[0]));
        return ppc;
    }

    @Bean
    PfsTokenBuilder pfsTokenBuilder() {
        return new PfsTokenBuilder();
    }

    @Test
    public void generateToken() throws NoSuchMethodException {
        final PfsTokenClaims claims = PfsTokenClaims.builder()
                .idGdi("1mgu13")
                .codeCassiniAppli("A1573")
                .build();

        pfsTokenBuilder.setPrivateKeyName(privateKeyName);

        final String token = pfsTokenBuilder.generateToken(claims, null);
        System.out.println(token);
    }

}
