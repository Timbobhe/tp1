package fr.ag2rlamondiale.ecrs.config;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.oauth2.client.OAuth2ClientProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Import;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@Slf4j
@SpringJUnitConfig
@Import(OAuth2Config.class)
@EnableConfigurationProperties(value = OAuth2ClientProperties.class)
@TestPropertySource("classpath:test.properties")
public class OAuth2IT {

    @Autowired
    private OAuth2ClientProperties properties;

    @Autowired
    private OAuth2AuthorizedClientManager authorizedClientManager;

    @Test
    void test_config() throws Exception {
        assertNotNull(properties);
    }

    @Test
    void test_getAccessToken() throws Exception {
        OAuth2AuthorizeRequest authorizeRequest = OAuth2AuthorizeRequest.withClientRegistrationId("cas")
                .principal(new AnonymousAuthenticationToken("Anonymous", "Anonymous",
                        AuthorityUtils.createAuthorityList("ROLE_ANONYMOUS")))
                .build();

        // Récupération  d'un access_token
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
        assertNotNull(accessToken);
        log.info("1ere demande access_token : [{}]", accessToken.getTokenValue());

        // Vérification qu'on récupère le même access_token la 2ème fois car il n'est pas encore expiré
        authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        accessToken = authorizedClient.getAccessToken();
        assertNotNull(accessToken);
        log.info("2eme demande access_token : [{}]", accessToken.getTokenValue());
    }
}
