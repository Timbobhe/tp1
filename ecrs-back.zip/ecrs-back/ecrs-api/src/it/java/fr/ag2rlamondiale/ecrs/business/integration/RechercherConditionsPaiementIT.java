package fr.ag2rlamondiale.ecrs.business.integration;

import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratClientFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.business.impl.CalculerEncoursContratFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.impl.ContratClientFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.impl.ContratFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.impl.OperationFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperERE;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperEREImpl;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperMDP;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperMDPImpl;
import fr.ag2rlamondiale.ecrs.security.UserSecurityServiceImpl;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.PfsConfig;
import fr.ag2rlamondiale.trm.cache.CacheConstants;
import fr.ag2rlamondiale.trm.cache.WithMethodSimpleKeyGenerator;
import fr.ag2rlamondiale.trm.client.rest.impl.PaiementClientImpl;
import fr.ag2rlamondiale.trm.client.rest.mapping.RechercherConditionsPaiementInMapper;
import fr.ag2rlamondiale.trm.client.rest.mapping.RechercherConditionsPaiementInMapperImpl;
import fr.ag2rlamondiale.trm.client.rest.mapping.RechercherConditionsPaiementOutMapper;
import fr.ag2rlamondiale.trm.client.rest.mapping.RechercherConditionsPaiementOutMapperImpl;
import fr.ag2rlamondiale.trm.configuration.ConsoleProperties;
import fr.ag2rlamondiale.trm.demo.CompteDemoEndpointResolver;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.paiement.ConditionsPaiementDto;
import fr.ag2rlamondiale.trm.domain.paiement.RechercherConditionsPaiementIn;
import fr.ag2rlamondiale.trm.rest.PfsRestConfig;
import fr.ag2rlamondiale.trm.rest.auth.PfsTokenBuilder;
import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestServiceInterceptor;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.security.UserSecurityService;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import fr.ag2rlamondiale.trm.utils.DefaultEndpointResolver;
import fr.ag2rlamondiale.trm.utils.IEndpointResolver;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.cache.jcache.JCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.core.convert.converter.ConverterRegistry;
import org.springframework.core.convert.support.DefaultConversionService;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@ContextConfiguration(classes = {RechercherConditionsPaiementIT.class, PfsConfig.class, PfsRestConfig.class})
@EnableAspectJAutoProxy
@RunWith(SpringJUnit4ClassRunner.class)
public class RechercherConditionsPaiementIT {

    @Autowired
    private PaiementClientImpl paiementClient;

    @Value("classpath:ehcache.xml")
    URI ehcacheConfig;

    @Bean
    public static PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() throws IOException {
        final PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
        List<Resource> props = new ArrayList<>();
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:webservices-pfs.properties")));
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:webservices-rest.properties")));
        props.addAll(Arrays.asList(new PathMatchingResourcePatternResolver().getResources("classpath:application-contextual-values.properties")));
        ppc.setLocations(props.toArray(new Resource[0]));
        return ppc;
    }

    @Bean
    UserSecurityService securityService() {
        return new UserSecurityServiceImpl();
    }

    @Bean
    IContratFacade contratFacade() {
        return new ContratFacadeImpl();
    }

    @Bean
    IContratClientFacade contratsClient() {
        return new ContratClientFacadeImpl();
    }

    @Bean
    ContratPacteMapperERE contratPacteMapperERE() {
        return new ContratPacteMapperEREImpl();
    }

    @Bean
    ContratPacteMapperMDP contratPacteMapperMDP() {
        return new ContratPacteMapperMDPImpl();
    }

    @Bean
    ContratMDPROHelper contratMDPROHelper() {
        return new ContratMDPROHelper();
    }

    @Bean
    ICalculerEncoursContratFacade calculerEncoursContratFacade() {
        return new CalculerEncoursContratFacadeImpl();
    }


    @Bean
    IOperationFacade operationFacade() {
        return new OperationFacadeImpl();
    }

    @Bean
    AsyncTaskExecutor asyncTaskExecutor() {
        return new SimpleAsyncTaskExecutor();
    }

    @Bean
    UserTestManager userTestManager() {
        return new UserTestManager();
    }

    @Bean(CacheConstants.DEFAULT_KEY_GENERATOR)
    public KeyGenerator defaulKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }


    @Bean("ehCacheManager")
    @Primary
    public JCacheCacheManager cacheManager() {
        org.springframework.cache.jcache.JCacheCacheManager cacheCacheManager = new JCacheCacheManager();
        final JCacheManagerFactoryBean factory = new JCacheManagerFactoryBean();
        factory.setCacheManagerUri(ehcacheConfig);
        factory.afterPropertiesSet();
        cacheCacheManager.setCacheManager(factory.getObject());
        return cacheCacheManager;
    }

    @Bean
    ConverterRegistry converterRegistry() {
        return new DefaultConversionService();
    }


    @Bean
    KeyGenerator defaultKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }

    @Bean
    ISupplierLibService supplierLibService() {
        return new ISupplierLibService() {
            @Override
            public String getCodeCassiniAppli() {
                return CodeApplicationType.ECRS.getCode();
            }

            @Override
            public String getLibelleAppli() {
                return "ESPACE CLIENT RETRAITE SUPPLEMENTAIRE";
            }

            @Override
            public String getUrlFront() {
                return "";
            }
        };
    }

    @Bean
    PaiementClientImpl paiementClient() {
        return new PaiementClientImpl();
    }

    @Bean
    IEndpointResolver endpointResolver() {
        return new DefaultEndpointResolver();
    }

    @Bean
    CompteDemoEndpointResolver compteDemoEndpointResolver() {
        return new CompteDemoEndpointResolver();
    }

    @Bean
    UserContextHolder userContextHolder() {
        return new UserContextHolder();
    }

    @Bean("consoleProps")
    public ConsoleProperties consoleProperties() {
        return new ConsoleProperties();
    }

    @Bean
    RechercherConditionsPaiementInMapper rechercherConditionsPaiementInMapper() {
        return Mockito.spy(new RechercherConditionsPaiementInMapperImpl());
    }

    @Bean
    RechercherConditionsPaiementOutMapper rechercherConditionsPaiementOutMapper() {
        return Mockito.spy(new RechercherConditionsPaiementOutMapperImpl());
    }

    @Bean
    PfsTokenBuilder pfsTokenBuilder() {
        return Mockito.spy(new PfsTokenBuilder());
    }

    @Bean
    PfsRestServiceInterceptor pfsRestServiceInterceptor() {
        return new PfsRestServiceInterceptor();
    }


    @Test
    public void should_retrieve_rechercher_conditions_paiement_response() {
        RechercherConditionsPaiementIn in = new RechercherConditionsPaiementIn();
        in.setCodeFiliale("ACA");
        in.setCodeProduit("RG01-012-ACA");
        in.setCodeStructureJuridique("ARI");
        in.setDateRecherche(new Date());
        in.setIdContrat("");
        in.setIdExtranet("CLIENT_A");
        in.setIndicateurInfoExclusionsBanques(true);
        in.setIndicateurInfoInclusionPays(true);

        ConditionsPaiementDto rechercherConditionsPaiementOut = paiementClient.rechercherConditionsPaiement(in);

        Assert.assertNotNull(JsonMarshaller.toJSON(rechercherConditionsPaiementOut));
    }
}
