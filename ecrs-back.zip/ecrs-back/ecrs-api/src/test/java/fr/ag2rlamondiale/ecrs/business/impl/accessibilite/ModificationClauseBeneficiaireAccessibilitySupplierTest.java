package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;


import static fr.ag2rlamondiale.trm.domain.FonctionnaliteType.MODIFICATION_CLAUSE_BENEFICIAIRE;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.IClausesBenefCtrFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;

@RunWith(MockitoJUnitRunner.class)
public class ModificationClauseBeneficiaireAccessibilitySupplierTest {
    @InjectMocks
    ModificationClauseBeneficiaireAccessibilitySupplier modificationClauseBeneficiaireAccessibilitySupplier;

    @Mock
    private IClausesBenefCtrFacade clausesBenefCtrFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Test
    public void acceptFonctionnalityType() {
        //When Then
        Assert.assertTrue(modificationClauseBeneficiaireAccessibilitySupplier.accept(FonctionnaliteType.MODIFICATION_CLAUSE_BENEFICIAIRE));
    }

    @Test
    public void checkAccessibityModifClauseBTest() throws TechnicalException {
        //Given
        when(userContextHolder.get()).thenAnswer(ans -> {
            UserContext userContext = new UserContext();
            userContext.setHasContratEre(true);
            userContext.setNumeroPersonneEre("P34567");
            return userContext;
        });
        when(clausesBenefCtrFacade.retrieveContractsforModificationClauseBeneficiaire()).thenReturn(createContratHeaders());
        when(workflowFacade.hasDemandeMdpEncours("P34567")).thenReturn(true);

        //When Then
        AccesFonctionnaliteDto accesFonctionnaliteDto = modificationClauseBeneficiaireAccessibilitySupplier.check();
        Assert.assertEquals(MODIFICATION_CLAUSE_BENEFICIAIRE, accesFonctionnaliteDto.getFonctionnaliteType());
        Assert.assertEquals(accesFonctionnaliteDto.getRaison(), ContratBlocage.BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS.name());

        //Given
        when(userContextHolder.get()).thenAnswer(ans -> {
            UserContext userContext = new UserContext();
            userContext.setHasContratEre(false);
            userContext.setNumeroPersonneMdpro("P64567");
            return userContext;
        });
        //When Then
        AccesFonctionnaliteDto accesFonctionnaliteDto2 = modificationClauseBeneficiaireAccessibilitySupplier.check();
        Assert.assertEquals(accesFonctionnaliteDto2.getRaison(), ContratBlocage.BLOCAGE_BIA_MONO_EQUIPE_MDPRO.name());
    }

    private List<ContratHeader> createContratHeaders() {
        return Arrays.asList(
                ContratHeader.builder().affichageType(AffichageType.NORMAL).classeAutreContrat(true).build(),
                ContratHeader.builder().affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.MDP).build(),
                ContratHeader.builder().affichageType(AffichageType.NORMAL).compartiments(
                        Arrays.asList(Compartiment.builder().type(CompartimentType.C1).build()))
                        .codeSilo(CodeSiloType.ERE).numGenContrat("RAG23").build()
        );
    }

}
