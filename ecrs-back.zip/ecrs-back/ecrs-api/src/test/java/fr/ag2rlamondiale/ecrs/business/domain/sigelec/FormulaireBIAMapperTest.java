package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireBIA;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.NatureSupportInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructureInvCommonFields;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import org.apache.commons.io.FileUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = FormulaireBIAMapperTest.class)
@Configuration
public class FormulaireBIAMapperTest {
    public static final String SRC_TEST_RESOURCES_XML_FORM_BIA_XML = "src/test/resources/xml/Form_BIA.xml";
    @Spy
    OccurenceStructureInvestissementTypeMapper occurenceStructureInvestissementTypeMapper = new OccurenceStructureInvestissementTypeMapperImpl();

    @Spy
    private DateMapper dateMapper;

    @InjectMocks
    FormulaireBIAMapperImpl sut;

    @Test
    public void should_map_bia_form() throws IOException {
        File file = new File(SRC_TEST_RESOURCES_XML_FORM_BIA_XML);
        FormulaireBIA expected = XmlMarshaller.fromXml(StringEscapeUtils.unescapeXml(FileUtils.readFileToString(file, StandardCharsets.UTF_8)), FormulaireBIA.class);

        FormulaireBIA actual = sut.createFormulaireBIA(createDemandeCreationSigElecBIA());
        actual.setInstantInitialisationDemande(DateUtils.dateTimeToXmlCalendar(DateUtils.parseDate("2018-08-17T16:58:01.848+02:00", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));

        assertEquals(JsonMarshaller.toJSON(expected), JsonMarshaller.toJSON(actual));
    }

    @Test
    public void mapFormulaireBIADtoNullTest() {

        // When
        FormulaireBIA actual = sut.createFormulaireBIA(null);

        // Then
        assertNull(actual);
    }

    private DemandeCreationSigElecBIA createDemandeCreationSigElecBIA() {
        DemandeCreationSigElecBIA demandeCreationSigElec = new DemandeCreationSigElecBIA();

        StructureInvCommonFields commonFields1 = new StructureInvCommonFields();
        commonFields1.setId("SF_72000");
        commonFields1.setParentId("SF_72225");
        commonFields1.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFields1.setCodeNatureSupportInvSilo("FG");
        commonFields1.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFields1.setLibeNatureSupport("Fonds de gestion");

        StructureInvCommonFields commonFieldsParent = new StructureInvCommonFields();
        commonFieldsParent.setId("SF_72225");
        commonFieldsParent.setParentId("SF_72148");

        ContributionInv contributionInvParent = new ContributionInv();
        contributionInvParent.setId("72225");
        contributionInvParent.setType(ContributionType.PART_PATRONALE);
        contributionInvParent.setLibelleContributionInvSilo("Part patronale");
        contributionInvParent.setLibelleContributionInv("Part Patronale");
        contributionInvParent.setTauxRepartitionContribution(new BigDecimal("0.0"));
        contributionInvParent.setIndicateurTauxDerogeable(false);
        contributionInvParent.setCommonFields(commonFieldsParent);

        SupportFinancierDto supportFinancierDto1 = new SupportFinancierDto();
        supportFinancierDto1.setCommonFields(commonFields1);
        supportFinancierDto1.setSupportType(SupportType.PROFIL);
        supportFinancierDto1.setNom("Actif en euros");
        supportFinancierDto1.setCode("212");
        supportFinancierDto1.setTaux(new BigDecimal("1.0"));
        supportFinancierDto1.setTauxModifiable(false);
        supportFinancierDto1.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFields2 = new StructureInvCommonFields();
        commonFields2.setId("SF_10831211");
        commonFields2.setParentId("SF_72225");
        commonFields2.setLibeNatureSupportInvSilo("Mixte");
        commonFields2.setCodeNatureSupportInvSilo("MI");
        commonFields2.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields2.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto2 = new SupportFinancierDto();
        supportFinancierDto2.setCommonFields(commonFields2);
        supportFinancierDto2.setSupportType(SupportType.GRILLE);
        supportFinancierDto2.setNom("Gestion pilot\u00E9e par horizon Prudente");
        supportFinancierDto2.setCode("5410");
        supportFinancierDto2.setTaux(BigDecimal.ONE);
        supportFinancierDto2.setTauxModifiable(false);

        StructureInvCommonFields commonFields3 = new StructureInvCommonFields();
        commonFields3.setId("SF_10831235");
        commonFields3.setParentId("SF_72225");
        commonFields3.setLibeNatureSupportInvSilo("Mixte");
        commonFields3.setCodeNatureSupportInvSilo("MI");
        commonFields3.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields3.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto3 = new SupportFinancierDto();
        supportFinancierDto3.setCommonFields(commonFields3);
        supportFinancierDto3.setSupportType(SupportType.GRILLE);
        supportFinancierDto3.setNom("Gestion pilot\u00E9e par horizon Equilibre");
        supportFinancierDto3.setCode("5430");
        supportFinancierDto3.setTaux(new BigDecimal("1.0"));
        supportFinancierDto3.setTauxModifiable(false);

        StructureInvCommonFields commonFields4 = new StructureInvCommonFields();
        commonFields4.setId("SF_10831257");
        commonFields4.setParentId("SF_72225");
        commonFields4.setLibeNatureSupportInvSilo("Mixte");
        commonFields4.setCodeNatureSupportInvSilo("MI");
        commonFields4.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields4.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto4 = new SupportFinancierDto();
        supportFinancierDto4.setCommonFields(commonFields4);
        supportFinancierDto4.setSupportType(SupportType.GRILLE);
        supportFinancierDto4.setNom("Gestion pilot\u00E9e par horizon Dynamique");
        supportFinancierDto4.setCode("5454");
        supportFinancierDto4.setTaux(new BigDecimal("1.0"));
        supportFinancierDto4.setTauxModifiable(false);

        List<SupportFinancierDto> supportFinancierDtoList = Arrays.asList(supportFinancierDto1, supportFinancierDto2,
                supportFinancierDto3, supportFinancierDto4);
        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setId("P4465210");
        personnePhysiqueConsult.setNom("BERRANGER");
        personnePhysiqueConsult.setPrenom("THIBAULT");
        personnePhysiqueConsult.setDateDeNaissance(DateUtils.parseDate("1991-05-22+02:00", "yyyy-MM-dd"));
        personnePhysiqueConsult.setCivilite("MR");
        personnePhysiqueConsult.setEmailPro("didier.ferraris@capgemini.com");

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("RG129441359");
        contratHeader.setRaisonSocialeFront("SAFRAN AIRCRAFT ENGINES");
        contratHeader.setDateAffiliation(DateUtils.parseDate("2000-01-01+01:00", "yyyy-MM-dd"));
        contratHeader.setCollege("Ing\u00E9nieurs et Cadres relevant de l'article 4 de la Convention Nationale AGIRC du 14 mars 1947");

        demandeCreationSigElec.setSupports(supportFinancierDtoList);
        demandeCreationSigElec.setIdGdi("joft2i");
        demandeCreationSigElec.setIdentifiantAssure("1056233");
        demandeCreationSigElec.setIdDemandeWkf("312691");
        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setClauseBeneficiaire("STD");
        demandeCreationSigElec.setClauseBeneficiaireDescription("\u00E0 d\u00E9faut mes h\u00E9ritiers.");

        demandeCreationSigElec.setPersonPhysique(personnePhysiqueConsult);
        return demandeCreationSigElec;
    }
}
