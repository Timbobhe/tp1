package fr.ag2rlamondiale.ecrs.api.error;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.error.RestError;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileResponseDto;
import fr.ag2rlamondiale.trm.utils.ErrorConstantes;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

@RunWith(MockitoJUnitRunner.class)
public class RestExceptionHandlerTest {

    @InjectMocks
    RestExceptionHandler restExceptionHandler;

    @Test
    public void handleBusinessException() {
        BusinessException ex = new BusinessException("Test BusinessException");
        ResponseEntity<RestError> error = restExceptionHandler.handleBusinessException(ex);
        assertEquals("Test BusinessException", error.getBody().getCode());
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, error.getStatusCode());
    }

    @Test
    public void handleTechnicalException() {
        TechnicalException ex = new TechnicalException("Test TechnicalException");
        ResponseEntity<RestError> error = restExceptionHandler.handleTechnicalException(ex);
        assertEquals(null, error.getBody().getCode());
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, error.getStatusCode());
    }

    @Test
    public void handleAccessDenied() {
        AccessDeniedException ex = new AccessDeniedException("Test AccessDeniedException");
        ResponseEntity<RestError> error = restExceptionHandler.handleAccessDenied(ex);
        assertEquals(ErrorConstantes.UTILISATEUR_NON_TROUVE, error.getBody().getCode());
        assertEquals(HttpStatus.FORBIDDEN, error.getStatusCode());
    }

    @Test
    public void handleMiscFailures() {
        AccessDeniedException ex = new AccessDeniedException("Test AccessDeniedException");
        ResponseEntity<RestError> error = restExceptionHandler.handleMiscFailures(ex);
        assertEquals(null, error.getBody().getCode());
        assertEquals(HttpStatus.BAD_REQUEST, error.getStatusCode());
    }


    @Test
    public void handleAuthentication() {
        AuthenticationException ex = mock(AuthenticationException.class);
        ResponseEntity<RestError> error = restExceptionHandler.handleAuthentication(ex);
        assertEquals(null, error.getBody().getCode());
        assertEquals(HttpStatus.UNAUTHORIZED, error.getStatusCode());
    }

    @Test
    public void handleAnyException() {
        Exception ex = new Exception("Test Exception");
        ResponseEntity<?> error = restExceptionHandler.handleAnyException(ex);
        assertEquals(HttpStatus.SERVICE_UNAVAILABLE, error.getStatusCode());
    }

    @Test
    public void handleMaxUploadSizeExceededException() {
        MaxUploadSizeExceededException ex = mock(MaxUploadSizeExceededException.class);
        ResponseEntity<?> error = restExceptionHandler.handleMaxUploadSizeExceededException(ex);
        assertEquals(createUploadFileResponseDto(), error.getBody());
        assertEquals(HttpStatus.BAD_REQUEST, error.getStatusCode());
    }

    private UploadFileResponseDto createUploadFileResponseDto() {
        UploadFileResponseDto uploadFileResponseDto = UploadFileResponseDto.builder()
                .fileName(null)
                .fileContent(null)
                .state(UploadFileResponseDto.State.KO)
                .errorTag(UploadFileResponseDto.UploadErrorType.PJ_TAILLE_KO)
                .build();
        return uploadFileResponseDto;
    }


}
