package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
import org.junit.Test;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.EXC;
import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.INC;
import static org.junit.Assert.*;

public class EvenUtilsIsPersonneContratAutoriseTest {

    @Test
    public void test_isPersonneAutorisee_true() {
        String idGdi = "vnmopv";
        String numPersonne = "P4232980";
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, "P4232980"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, "RG6556262"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, "vnmopv"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isPersonneAutorisee(idGdi, numPersonne, perimetres));
    }

    @Test
    public void test_isPersonneAutorisee_true_TOUT() {
        String idGdi = "vnmopv";
        String numPersonne = "P4232980";
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.TOUT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, "RG6556262"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isPersonneAutorisee(idGdi, numPersonne, perimetres));
    }

    @Test
    public void test_isPersonneAutorisee_false_EXC() {
        String idGdi = "vnmopv";
        String numPersonne = "P4232980";
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, "RG6556262"));
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.PERSONNE, "P4232980"));
        assertFalse(EvenUtils.isPersonneAutorisee(idGdi, numPersonne, perimetres));
    }

    @Test
    public void test_isOperationPersonneConnectee_true() {
        String idGdi = "vnmopv";
        String numPersonne = "P4232980";
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, "P4232980"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, "vnmopv"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isOperationPersonneConnectee(INC, idGdi, numPersonne, perimetres));
    }

    @Test
    public void test_isOperationPersonneConnectee_false() {
        String idGdi = "vnmopv";
        String numPersonne = "P4232980";
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, "P4232980"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, "vnmopv"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertFalse(EvenUtils.isOperationPersonneConnectee(EXC, idGdi, numPersonne, perimetres));
    }

    @Test
    public void test_isOperationPerimetrePersonne_true() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isOperationPerimetrePersonne(INC, perimetres));
    }

    @Test
    public void test_isOperationPerimetrePersonne_INC_true_TOUT() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.TOUT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isOperationPerimetrePersonne(INC, perimetres));
    }

    @Test
    public void test_isOperationPerimetrePersonne_INC_false() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertFalse(EvenUtils.isOperationPerimetrePersonne(INC, perimetres));
    }

    @Test
    public void test_isOperationPerimetrePersonne_EXC_false() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertFalse(EvenUtils.isOperationPerimetrePersonne(EXC, perimetres));
    }

    @Test
    public void test_isOperationPerimetreContrat_true() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertTrue(EvenUtils.isOperationPerimetreContrat(INC, perimetres));
    }

    @Test
    public void test_isContratAutorise_avec_perimetre_personne_true() {
        assertTrue(EvenUtils.isContratAutorise(newContratEre(), null));

        List<PerimetreEvenementJson> perimetres = new ArrayList<>();

        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.PERSONNE, null));
        assertTrue(EvenUtils.isContratAutorise(newContratEre(), perimetres));
        perimetres.clear();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, "C1"));
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.CONTRAT, "C1"));
        assertFalse(EvenUtils.isContratAutorise(newContratEre(), perimetres));
        ContratHeader contrat = newContratEre();
        contrat.setId("C1");
        contrat.setTypeContrat("ERE");
        contrat.setCodeFiliale("ARI");
        assertTrue(EvenUtils.isContratAutorise(contrat, perimetres));
        perimetres.clear();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, "C1"));
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.PERSONNE, "C2"));
        contrat.setId("C2");
        assertFalse(EvenUtils.isContratAutorise(contrat, perimetres));
    }

    @Nonnull
    private ContratHeader newContratEre() {
        final ContratHeader contratHeader = ContratHeader.builder().codeSilo(CodeSiloType.ERE).build();
        return contratHeader;
    }

    @Test
    public void test_isPersonneAutorisee_avec_perimetre_contrat_true() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.CONTRAT, null));
        assertTrue(EvenUtils.isPersonneAutorisee("idGid", "numPersonne", perimetres));
    }

    @Test
    public void test_isOperationPerimetreContrat_INC_true_TOUT() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.TOUT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        assertTrue(EvenUtils.isOperationPerimetreContrat(INC, perimetres));
    }

    @Test
    public void test_isOperationPerimetreContrat_INC_false() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        assertFalse(EvenUtils.isOperationPerimetreContrat(INC, perimetres));
    }

    @Test
    public void test_isOperationPerimetreContrat_EXC_false() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PERSONNE, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.CONTRAT, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, null));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.PRODUIT, null));
        assertFalse(EvenUtils.isOperationPerimetreContrat(EXC, perimetres));
    }

    @Test
    public void test_isPersonneAutorisee_Comportement_Attendu() {
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.IDGDI, "z3ghy4"));

        assertFalse(EvenUtils.isPersonneAutorisee("z3ghy4", "P1", perimetres));

        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.TOUT, "*"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, "c5dfdf"));
        assertTrue(EvenUtils.isOperationPerimetrePersonne(INC, perimetres));
        assertTrue(EvenUtils.isOperationPerimetrePersonne(EXC, perimetres));
        final String idGdi = "c5dfdf";
        final String numPersonne = "P4050279";
        assertTrue(EvenUtils.isOperationPersonneConnectee(INC, idGdi, numPersonne, perimetres));
        assertTrue(EvenUtils.isOperationPersonneConnectee(EXC, idGdi, numPersonne, perimetres));
        assertTrue(EvenUtils.isPersonneAutorisee(idGdi, numPersonne, perimetres));
    }

    private PerimetreEvenementJson perimetreEven(OperationPerimetre operationPerimetre, String codeEvenement,
                                                 PerimetreType typePerimetre, String valeurPerimetre) {
        PerimetreEvenementJson p = new PerimetreEvenementJson();
        p.setOperationPerimetre(operationPerimetre);
        p.setCodeEvenement(codeEvenement);
        p.setTypePerimetre(typePerimetre);
        p.setValeurPerimetre(valeurPerimetre);
        return p;
    }
}
