package fr.ag2rlamondiale.ecrs.security;

import org.junit.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collections;

import static org.junit.Assert.*;

public class EcrsUserDetailsTest {

    private final String USER1 = "user1";
    private final String USER2 = "user2";

    @Test
    public void test() {
        EcrsUserDetails userEcrs1 = user(USER1);
        EcrsUserDetails userEcrs2 = user(USER2);
        EcrsUserDetails userEcrs3 = user(USER1);

        assertNull(userEcrs1.getEnvironnement());
        assertNull(userEcrs1.getCodeDelegation());
        assertNull(userEcrs1.getUserMail());
        assertNull(userEcrs1.getUserSn());
        assertNull(userEcrs1.getUserGivenName());
        assertTrue(userEcrs1.equals(userEcrs3) && userEcrs3.equals(userEcrs1));
        assertTrue(userEcrs1.hashCode() == userEcrs3.hashCode());
        assertFalse(userEcrs1.equals(userEcrs2));
        assertFalse(userEcrs1.equals(null));
    }

    private EcrsUserDetails user(String username) {
        UserDetails userDetails = new User(username, "password", Collections.emptyList());
        EcrsUserDetails userEcrs = new EcrsUserDetails(userDetails, true);

        userEcrs.setEnvironnement("");
        userEcrs.setCodeDelegation("");
        userEcrs.setUserFirstLastName("");
        userEcrs.setUserMail("");
        userEcrs.setUserSn("");
        userEcrs.setUserGivenName("");
        return userEcrs;
    }
}
