package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.profile.EcrsProfilingInterceptor;
import fr.ag2rlamondiale.ecrs.security.EcrsSecurityApplicationListener;
import fr.ag2rlamondiale.ecrs.security.EcrsUserDetails;
import fr.ag2rlamondiale.ecrs.utils.MockUserContext;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.business.impl.TraceFacadeImpl;
import fr.ag2rlamondiale.trm.client.rest.ITraceRestClient;
import fr.ag2rlamondiale.trm.client.rest.impl.TraceRestClientImpl;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.InfoNavigateur;
import fr.ag2rlamondiale.trm.utils.SecurityServiceConfig;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = TraceConnexionTest.TraceConnexionTestContext.class)
public class TraceConnexionTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";

    @Autowired
    private EcrsSecurityApplicationListener connexionListener;


    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    public static class TraceConnexionTestContext {

        private ITraceRestClient traceRestClient = mock(TraceRestClientImpl.class);

        private UserContextHolder userContextHolder = mock(UserContextHolder.class);

        private InfoNavigateur infoNavigateur = mock(InfoNavigateur.class);

        private IContratFacade contratFacade = mock(IContratFacade.class);

        @Bean
        EcrsProfilingInterceptor profilingInterceptor() {
            return new EcrsProfilingInterceptor();
        }

        @Bean
        TraceFacadeImpl traceFacade() {
            return new TraceFacadeImpl();
        }

        @Bean
        ITraceRestClient traceRestClient() {
            when(traceRestClient.insert(any(TraceJson.class))).then(invocation -> {
                TraceJson traceJson = (TraceJson) invocation.getArguments()[0];
                assertEquals(CodeActionType.CQ_CONNEXION.name(), traceJson.getCodeAction());
                assertEquals(ID_GDI, traceJson.getIdGdi());
                assertEquals("CT CONTRAT_ERE_ID | ADH ADHERENTE_ID | CP COLLEGE_ID", traceJson.getZone1());
                return true;
            });

            return traceRestClient;
        }

        @Bean
        UserContextHolder userContextHolder() {
            when(userContextHolder.get()).thenReturn(createUserContextERE());
            return userContextHolder;
        }

        @Bean
        InfoNavigateur infoNavigateur() {
            when(infoNavigateur.navInfo()).thenReturn("INFO NAVIGATEUR");
            return infoNavigateur;
        }

        @Bean
        SecurityServiceConfig mapperUtils() {
            return new SecurityServiceConfig();
        }

        @Bean
        RestTemplate restTemplate() {
            return new RestTemplate();
        }

        @Bean
        EcrsSecurityApplicationListener ecrsSecurityApplicationListener() {
            return new EcrsSecurityApplicationListener();
        }

        @Bean
        ISupplierLibService supplierLibService() {
            return new ISupplierLibService() {
                @Override
                public String getCodeCassiniAppli() {
                    return "A1573";
                }

                @Override
                public String getLibelleAppli() {
                    return "TEST";
                }

                @Override
                public String getUrlFront() {
                    return "http://url.front";
                }
            };
        }

        @Bean
        IContratFacade contratFacade() {
            try {
                List<ContratHeader> contratsERE = new ArrayList<>();
                ContratHeader contrat = new ContratHeader();
                contrat.setId("CONTRAT_ERE_ID");
                contrat.setIdAdherente("ADHERENTE_ID");
                contrat.setIdCollege("COLLEGE_ID");
                contratsERE.add(contrat);
                when(contratFacade.rechercherContratsEre()).thenReturn(contratsERE);
                when(contratFacade.rechercherContratsMdpro()).thenReturn(Collections.emptyList());
            } catch (TechnicalException e) {
                throw new RuntimeException(e);
            }
            return contratFacade;
        }

        private UserContext createUserContextERE() {
            MockUserContext userContext = new MockUserContext();
            userContext.setIdGdi(ID_GDI);
            userContext.setNumeroPersonneEre(NUM_PERS_ERE);
            return userContext;
        }
    }


    @Test
    public void test_Connexion_Event() throws Exception {
        Authentication authentication = buildAuthentication();
        AuthenticationSuccessEvent event = new AuthenticationSuccessEvent(authentication);
        connexionListener.onApplicationEvent(event);
        assertNotNull(event);
    }


    private Authentication buildAuthentication() {
        Authentication authentication = mock(Authentication.class);
        EcrsUserDetails userDetails = ecrsUserDetails();
        when(authentication.getPrincipal()).thenReturn(userDetails);
        return authentication;
    }

    private EcrsUserDetails ecrsUserDetails() {
        User user = new User(ID_GDI, "password", Collections.emptyList());
        return new EcrsUserDetails(user, true);
    }
}
