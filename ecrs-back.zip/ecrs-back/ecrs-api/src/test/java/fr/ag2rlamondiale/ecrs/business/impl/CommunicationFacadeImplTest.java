package fr.ag2rlamondiale.ecrs.business.impl;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.util.ReflectionTestUtils;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.trm.client.soap.ICommunicationClient;
import fr.ag2rlamondiale.trm.domain.creerdemcom.CreerDemComDto;
import fr.ag2rlamondiale.trm.domain.creerdemcom.CreerDemComResponseDto;
import fr.ag2rlamondiale.trm.domain.creerdemcom.ObjetMailType;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.pdf.PDFUtils;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class CommunicationFacadeImplTest {

    private static final String mailTestAkio = "Bruno.ANTOINE.ext@ag2rlamondiale.fr";
    private static final String mailTestMdpro = "ladislas.halifa.ext@ag2rlamondiale.fr";
    private static final String mailGenericContact = "yasmine.kertous.ext@ag2rlamondiale.fr";

    @InjectMocks
    CommunicationClientFacadeImpl gestEditiqueFacadeImpl;

    @Mock
    ICommunicationClient communicationClient;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    private PDFUtils pdfUtils;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "isCreerDemComActivated", "true");
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "mailContactAkioDestinataire", mailTestAkio);
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "mailGestionMDPRO", mailTestMdpro);
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "adresseMailGenerique", mailGenericContact);
        when(userContextHolder.get()).thenReturn(mock(UserContext.class));
        when(userContextHolder.get().getNom()).thenReturn(MOCKDATA);
        when(userContextHolder.get().getPrenom()).thenReturn(MOCKDATA);
        when(userContextHolder.get().getCivilite()).thenReturn(MOCKDATA);
    }

    @Test
    public void creerDemandeCommunicationAkioTest() throws TechnicalException {
        //Given
        CreerDemComDto dto = CreerDemComDto.builder()
                .objetMailType(ObjetMailType.CONTACT_AKIO)
                .build();
        CreerDemComResponseDto responseDto = new CreerDemComResponseDto();
        responseDto.setCodeRetour(BigInteger.TEN);
        responseDto.setNumeroUnique(BigInteger.TEN);

        ContactReclamationDto contactReclamationDto = ContactReclamationDto.builder()
                .email(MOCKDATA)
                .telephone(MOCKDATA)
                .idPersonne(MOCKDATA)
                .idContrat(MOCKDATA)
                .codeQuestion(MOCKDATA)
                .fichiersJoint(Arrays.asList(UploadFileDto.builder().fileName("file").fileContent("wtkdcdc").build()))
                .build();

        when(communicationClient.creerDemandeCommunication(Mockito.any(CreerDemComDto.class)))
                .thenReturn(responseDto);

        //When
        boolean result = gestEditiqueFacadeImpl.creerDemandeEmailContactAkio(contactReclamationDto);
        // gestEditiqueFacadeImpl.creerDemandeCommunication(dto);

        //Then
        Assert.assertFalse(result);
        // Assert.assertTrue(StringUtils.equalsIgnoreCase(mailTestAkio, dto.getAdressesMailDestinataires().get(0)));
    }

    @Test
    public void creerDemandeCommunicationGestionMdproTest() throws TechnicalException {
        //Given
        CreerDemComDto dto = CreerDemComDto.builder()
                .objetMailType(ObjetMailType.MAIL_GESTION_MDPRO)
                .build();
        CreerDemComResponseDto responseDto = new CreerDemComResponseDto();
        responseDto.setCodeRetour(BigInteger.TEN);
        responseDto.setNumeroUnique(BigInteger.TEN);
        when(communicationClient.creerDemandeCommunication(Mockito.any(CreerDemComDto.class)))
                .thenReturn(responseDto);

        //When
        boolean result = gestEditiqueFacadeImpl.creerDemandeMailGestionMDPRO(MOCKDATA, new ArrayList<>());
        // Test lecture adresse mdpro dans fichier de contexte
        // gestEditiqueFacadeImpl.creerDemandeCommunication(dto);

        //Then
        Assert.assertFalse(result);
        //Assert.assertTrue(StringUtils.equalsIgnoreCase(mailTestMdpro, dto.getAdressesMailDestinataires().get(0)));
    }

    @Test
    public void creerDemandeCommunicationDesactivatedTest() throws TechnicalException {
        //Given
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "isCreerDemComActivated", "false");
        CreerDemComDto dto = CreerDemComDto.builder()
                .objetMailType(ObjetMailType.NOTIF_MODIFICATION_RIB)
                .build();
        CreerDemComResponseDto responseDto = new CreerDemComResponseDto();
        responseDto.setCodeRetour(BigInteger.ONE);
        responseDto.setNumeroUnique(BigInteger.TEN);
        when(communicationClient.creerDemandeCommunication(Mockito.any(CreerDemComDto.class)))
                .thenReturn(responseDto);

        //When
        boolean result = gestEditiqueFacadeImpl.creerMailNotificationModifRIB(Collections.singletonList(MOCKDATA), MOCKDATA);

        //Then
        Assert.assertTrue(result);
        Assert.assertNull(dto.getAdressesMailDestinataires());
    }


    @Test
    public void desactivatedGenericAdressTest() throws TechnicalException {

        //Given
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "isEnvoiToGenericAdressActivated", "false");
        CreerDemComResponseDto responseDto = new CreerDemComResponseDto();
        responseDto.setCodeRetour(BigInteger.TEN);
        responseDto.setNumeroUnique(BigInteger.TEN);
        when(communicationClient.creerDemandeCommunication(Mockito.any(CreerDemComDto.class)))
                .thenReturn(responseDto);

        //When
        boolean result = gestEditiqueFacadeImpl.creerMailNotificationContact(Collections.singletonList(mailGenericContact), "ARI");

        //Then
        Assert.assertFalse(result);
    }
}
