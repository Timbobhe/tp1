package fr.ag2rlamondiale.ecrs.business.impl;

import static org.junit.Assert.assertEquals;

import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import fr.ag2rlamondiale.ecrs.api.secure.InitCacheRestController;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;

@RunWith(MockitoJUnitRunner.class)
public class InitCacheRestControllerTest {

    @InjectMocks
    InitCacheRestController initCacheRestController;
    
     @Test
     public void getCache() {
         Map<String, Object> info = initCacheRestController.getCache();
         
         assertEquals(1, info.keySet().size());
         assertEquals("Create cache for Aquea!", info.get("App " + CodeApplicationType.AQEA.getCode()));
         
     }
}
