package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.dto.evenement.TypologieAffichageEven;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EvenementRestControllerTest {
    @Mock
    private IEvenementFacade evenementFacade;

    @InjectMocks
    EvenementRestController evenementController;

    @Test
    public void should_get_NextEven() throws TechnicalException {
        when(evenementFacade.generateNextEvenement(any(), anyBoolean(), anyBoolean())).thenReturn(new EvenementJson(new TypeEvenementJson("ERE_CONF")));
        Assert.assertNotNull(evenementController.getNextEven(TypologieAffichageEven.OBJECTIF));
        assertEquals("ERE_CONF", evenementController.getNextEven(TypologieAffichageEven.OBJECTIF).getTypeEvenement().getCodeEvenement());
    }

    @Test
    public void should_update() {
        when(evenementFacade.updateEvenement(null)).thenReturn(new EvenementJson());
        Assert.assertNotNull(evenementController.update(null));
    }

    @Test
    public void should_cancel() {
        when(evenementFacade.updateEvenement(Mockito.any(EvenementJson.class))).
                thenAnswer((Answer<EvenementJson>) invocation -> EvenementJson.builder()
                        .dateFin(new Date())
                        .etatTraitement(EtatTraitementType.ANNU)
                        .build());
        Assert.assertNotNull(evenementController.cancel(new EvenementJson()));
    }

    @Test
    public void should_terminate() {
        when(evenementFacade.updateEvenement(Mockito.any(EvenementJson.class))).
                thenAnswer((Answer<EvenementJson>) invocation -> EvenementJson.builder()
                        .dateFin(new Date())
                        .etatTraitement(EtatTraitementType.TRAI)
                        .build());
        Assert.assertNotNull(evenementController.terminate(new EvenementJson()));
    }
}
