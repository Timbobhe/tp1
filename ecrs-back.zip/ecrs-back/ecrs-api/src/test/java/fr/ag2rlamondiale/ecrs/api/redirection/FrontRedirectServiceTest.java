package fr.ag2rlamondiale.ecrs.api.redirection;

import fr.ag2rlamondiale.ecrs.business.IPartenaireFacade;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FrontRedirectServiceTest {
    private static final String BAD_PARTENAIRE_URL = "http/pla-lilly-staging.adding.fr/ACACustomisationError.htl";
    private static final String PARTENAIRE_URL_ERROR = "https://pla-lilly-staging.adding.fr/ACACustomisation/Error.html";
    private static final String PARTENAIRE_ID = "49503";
    private static final String APPLICATION_URL = "http://localhost:4200";
    public static final String BAD_APPLICATION_URL = "http/localhost:/4200";
    public static final String LOCATION = "Location";
    public static final String ID_LOGOUT = "?id=LOGOUT";
    @Mock
    IPartenaireFacade partenaireFacadeMock;

    @InjectMocks
    private FrontRedirectService testedClass;

    @Mock
    private UserContextHolder userContextHolder;

    HttpHeaders headers;

    @Test
    public void should_redirect_to_front() {
        headers = new HttpHeaders();
        headers.add(LOCATION, APPLICATION_URL);
        Assert.assertEquals(new ResponseEntity<String>(headers, HttpStatus.FOUND),
                testedClass.redirectToFront(APPLICATION_URL));
    }

    @Test
    public void should_not_redirect_to_front_and_throw_exception() {
        Assert.assertEquals(new ResponseEntity<String>(HttpStatus.BAD_REQUEST),
                testedClass.redirectToFront(BAD_APPLICATION_URL));
    }

    @Test
    public void should_redirect_to_partenaire() {
        when(partenaireFacadeMock.findById(anyString())).thenReturn(createPartenaire());

        headers = new HttpHeaders();
        headers.add(LOCATION, createPartenaire().getUrlError().concat(ID_LOGOUT));

        Assert.assertEquals(new ResponseEntity<String>(headers, HttpStatus.FOUND),
                testedClass.redirectToPartenaireById(PARTENAIRE_ID));
    }

    @Test
    public void should_not_redirect_to_partenaire() {
        when(partenaireFacadeMock.findById(anyString())).thenReturn(createPartenaireWithBadUrl());

        Assert.assertEquals(new ResponseEntity<String>(HttpStatus.BAD_REQUEST),
                testedClass.redirectToPartenaireById(PARTENAIRE_ID));
    }

    @Test
    public void redirectToSwaggerTest(){
        ResponseEntity<String> responseEntity = testedClass.redirectToSwagger(mock(HttpServletRequest.class));
        Assert.assertEquals(responseEntity,new ResponseEntity<>(HttpStatus.BAD_REQUEST));
    }

    private PartenaireJson createPartenaire() {
        PartenaireJson partenaire = new PartenaireJson();
        partenaire.setUrlError(PARTENAIRE_URL_ERROR);
        return partenaire;
    }

    private PartenaireJson createPartenaireWithBadUrl() {
        PartenaireJson partenaire = new PartenaireJson();
        partenaire.setUrlError(BAD_PARTENAIRE_URL);
        return partenaire;
    }
}
