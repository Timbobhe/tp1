package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.EcheancierFacadeImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.IConsulterEcheancierClient;
import fr.ag2rlamondiale.trm.client.soap.IEcheancierClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.echeancier.ConsulterEcheancierDto;
import fr.ag2rlamondiale.trm.domain.echeancier.DemandeSiloRequestDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.RechercherEcheanciersDto;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.springframework.context.annotation.Configuration;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class EcheancierFacadeImplTest {

    private static final String ID_ASSURE_RECH = "84940";
    private static final String ID_ECHEANCIER_RECH = "29513";
    private static final String ID_ASSURE_CONSU = "343742";
    private static final String ID_ECHEANCIER_CONSU = "20206";

    @Mock
    IEcheancierClient echeanciersClient;

    @InjectMocks
    EcheancierFacadeImpl echeancierFacade;

    @Mock
    IConsulterEcheancierClient consulterEcheancierClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Rule
    public final ExpectedException exception = ExpectedException.none();

    @Test
    public void rechercherEcheanciersTest_throws_null_pointer() throws TechnicalException {
        // Given
        Compartiment compartiment = null;
        exception.expect(NullPointerException.class);
        // When
        echeancierFacade.rechercherEcheanciers(compartiment);
    }

    @Test
    public void rechercherEcheanciersTest_2_ERE() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ASSURE_RECH, CodeSiloType.ERE);
        // When
        when(echeanciersClient.rechercherEcheanciers(any(RechercherEcheanciersDto.class)))
                .thenReturn(new ArrayList<Echeancier>());

        // Then
        List<Echeancier> echeanciers = echeancierFacade.rechercherEcheanciers(compartiment);
        assertTrue(echeanciers.isEmpty());
    }

    @Test
    public void rechercherEcheanciersTest_2_MDP() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ASSURE_RECH, CodeSiloType.MDP);
        // When
        when(echeanciersClient.rechercherEcheanciers(any(RechercherEcheanciersDto.class)))
                .thenReturn(new ArrayList<Echeancier>());

        // Then
        List<Echeancier> echeanciers = echeancierFacade.rechercherEcheanciers(compartiment);
        assertTrue(echeanciers.isEmpty());
    }

    @Test
    public void consulterEcheancierTest_ERE() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ECHEANCIER_CONSU, CodeSiloType.ERE);
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(CodeSiloType.ERE);
        demande.setIdAssure(ID_ASSURE_RECH);
        // When
        when(consulterEcheancierClient.consulterEcheancier(any(ConsulterEcheancierDto.class)))
                .thenReturn(null);

        // Then
        Echeancier echeancier = echeancierFacade.consulterEcheancier(compartiment, ID_ECHEANCIER_CONSU);
        assertNull(echeancier);
    }

    @Test
    public void consulterEcheancierTest_MDP() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ECHEANCIER_CONSU, CodeSiloType.MDP);
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(CodeSiloType.MDP);
        demande.setIdAssure(ID_ASSURE_RECH);
        // When
        when(consulterEcheancierClient.consulterEcheancier(any(ConsulterEcheancierDto.class)))
                .thenReturn(new Echeancier());

        // Then
        Echeancier echeancier = echeancierFacade.consulterEcheancier(compartiment, ID_ECHEANCIER_CONSU);
        assertNotNull(echeancier);
    }

    private Compartiment buildCompartiment(String idAssure, CodeSiloType codeSilo) {
        final Compartiment compartiment = new Compartiment(idAssure);
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(codeSilo);
        contratHeader.addCompartiment(compartiment);
        return compartiment;
    }

    @Test
    public void getProchainEcheancierTest() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ASSURE_RECH, CodeSiloType.MDP);
        // When
        when(echeanciersClient.rechercherEcheanciers(any(RechercherEcheanciersDto.class)))
                .thenReturn(new ArrayList<Echeancier>());

        // Then
        Echeancier prochainEch = echeancierFacade.getProchainEcheancier(compartiment);
        assertNull(prochainEch);
    }

    @Test
    public void getProchainEcheancierTest_2() throws TechnicalException {
        // Given
        Compartiment compartiment = buildCompartiment(ID_ASSURE_RECH, CodeSiloType.MDP);
        Echeancier ech1 = new Echeancier();
        ech1.setEcheancierId(BigInteger.valueOf(144));
        List<Echeancier> echeanciers = new ArrayList<Echeancier>();
        echeanciers.add(ech1);
        // When
        when(echeanciersClient.rechercherEcheanciers(any(RechercherEcheanciersDto.class)))
                .thenReturn(echeanciers);
        when(consulterEcheancierClient.consulterEcheancier(any(ConsulterEcheancierDto.class)))
                .thenReturn(new Echeancier());

        // Then
        Echeancier prochainEch = echeancierFacade.getProchainEcheancier(compartiment);
        assertNotNull(prochainEch);
    }
}
