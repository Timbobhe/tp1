package fr.ag2rlamondiale.ecrs.api.secure;

import static org.mockito.Mockito.when;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import fr.ag2rlamondiale.ecrs.business.ICaptchaFacade;
import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseDto;

@RunWith(MockitoJUnitRunner.class)
public class CaptchaRestControllerTest {
	@Mock
	ICaptchaFacade verificationFacade;
	
	@InjectMocks
    CaptchaRestController verificationtController;

	@Test
	public void verifyRequestTest() {
		when(verificationFacade.verifyToken(null)).thenReturn(new VerificationCaptchaResponseDto());
		ResponseEntity<VerificationCaptchaResponseDto> expected = verificationtController.verifyRequest(null);
		Assert.assertNotNull(expected);
	}
}
