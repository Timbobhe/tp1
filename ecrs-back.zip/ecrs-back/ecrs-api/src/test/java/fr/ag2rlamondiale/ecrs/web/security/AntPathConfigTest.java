package fr.ag2rlamondiale.ecrs.web.security;

import org.junit.Test;
import org.springframework.security.web.util.matcher.RequestMatcher;

import java.util.List;

import static org.junit.Assert.*;

public class AntPathConfigTest {

    @Test
    public void test_should_empty_and_requestMatcher_Null() throws Exception {
        assertTrue(new AntPathConfig().isEmpty());
        assertNull(new AntPathConfig().toRequestMatcher());

        assertTrue(new AntPathConfig((List<String>) null).isEmpty());
        assertNull(new AntPathConfig((List<String>) null).toRequestMatcher());

        assertTrue(new AntPathConfig(List.of()).isEmpty());
        assertNull(new AntPathConfig(List.of()).toRequestMatcher());

        assertTrue(new AntPathConfig((String) null).isEmpty());
        assertNull(new AntPathConfig((String) null).toRequestMatcher());
    }

    @Test
    public void test_should_return_request_matcher_not_null() throws Exception {
        final AntPathConfig antPathConfig = new AntPathConfig("POST /**/j_spring_cas_security_check");
        assertFalse(antPathConfig.isEmpty());

        final RequestMatcher requestMatcher = antPathConfig.toRequestMatcher();
        assertNotNull(requestMatcher);
    }

    @Test
    public void test_should_return_request_matcher_not_null_with_simple_url() throws Exception {
        final AntPathConfig antPathConfig = new AntPathConfig(List.of("/**/j_spring_cas_security_check", "/**/j_spring_security_logout"));
        assertFalse(antPathConfig.isEmpty());

        final RequestMatcher requestMatcher = antPathConfig.toRequestMatcher();
        assertNotNull(requestMatcher);
    }

    @Test
    public void test_should_return_default_value() throws Exception {
        final AntPathConfig defaultValue = new AntPathConfig(List.of("/**/j_spring_cas_security_check", "/**/j_spring_security_logout"));

        final AntPathConfig antPathConfig = new AntPathConfig().orDefault(defaultValue);

        assertSame(defaultValue, antPathConfig);
    }

}
