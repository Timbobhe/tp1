package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinActuelleRequestDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinRequestDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereDto;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class GestionFinanciereRestControllerTest {
    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IStructureInvFacade structureInvFacade;

    @InjectMocks
    @Spy
    GestionFinanciereRestController gestFi;

    @Test
    public void getGestionFinaciereCompartimentTest() throws TechnicalException {
        GestionFinRequestDto requestFin = new GestionFinRequestDto();
        buildRequestFin(requestFin);
        assertNotNull(gestFi.getGestionFinanciereCompartiment(requestFin));
    }
    @Test
    public void getGestionFinaciereCompartimentNullTest() throws TechnicalException {
        GestionFinRequestDto requestFin = new GestionFinRequestDto();
        buildRequestFinEchec(requestFin);
        assertNotNull(gestFi.getGestionFinanciereCompartiment(requestFin));
    }

    @Test
    public void getGestionFinaciereContratTest() throws TechnicalException {
        GestionFinRequestDto requestFin = new GestionFinRequestDto();
        buildRequestFin(requestFin);
        assertNotNull(gestFi.getGestionFinanciereContrat(requestFin));
    }

    @Test
    public void getGestionFinanciereActuelleCompartimentTest() throws TechnicalException {
        GestionFinActuelleRequestDto requestFinActulle = new GestionFinActuelleRequestDto();
        buildRequestFinActuelle(requestFinActulle);
        assertNotNull(gestFi.getGestionFinanciereActuelleCompartiment(requestFinActulle));
    }

    @Test
    public void getGestionFinanciereActuelleContratTest() throws TechnicalException {
        GestionFinActuelleRequestDto requestFinActulle = new GestionFinActuelleRequestDto();
        buildRequestFinActuelle(requestFinActulle);
        assertNotNull(gestFi.getGestionFinanciereActuelleContrat(requestFinActulle));
    }

    private void buildRequestFin(GestionFinRequestDto requestFin) throws TechnicalException {
        ContratId contratId = ContratId.ere("NOMCONTRAT", null, "IDCONTRACTANTE", null);
        CompartimentId compartimentId = CompartimentId.ere("IDASSURE", CompartimentType.C1);
        ContratHeader contratHeader = ContratHeader.builder().codeSilo(CodeSiloType.ERE).build();

        requestFin.setContratId(contratId);
        requestFin.setCompartimentId(compartimentId);
        requestFin.setFonctionnalite(FonctionnaliteType.ARBITRAGE);

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(structureInvFacade.getGestionFinanciere(any(Compartiment.class), any())).thenReturn(new GestionFinanciereDto());

    }

    private void buildRequestFinActuelle(GestionFinActuelleRequestDto requestFinActulle) throws TechnicalException {
        ContratId contratId = ContratId.ere("NOMCONTRAT", null, "IDCONTRACTANTE", null);
        ContratHeader contratHeader = ContratHeader.builder().codeSilo(CodeSiloType.ERE).build();
        CompartimentId compartimentId = CompartimentId.ere("IDASSURE", CompartimentType.C1);

        requestFinActulle.setContratId(contratId);
        requestFinActulle.setCompartimentId(compartimentId);

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(structureInvFacade.getGestionFinanciere(any(Compartiment.class), any())).thenReturn(new GestionFinanciereDto());
    }
    private void buildRequestFinEchec(GestionFinRequestDto requestFin) throws TechnicalException {
        ContratId contratId = ContratId.ere("NOMCONTRAT", null, "IDCONTRACTANTE", null);
        CompartimentId compartimentId = CompartimentId.ere(null, null);
        ContratHeader contratHeader = ContratHeader.builder().codeSilo(CodeSiloType.ERE).build();

        requestFin.setContratId(contratId);
        requestFin.setCompartimentId(compartimentId);
        requestFin.setFonctionnalite(FonctionnaliteType.ARBITRAGE);

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(structureInvFacade.getGestionFinanciere(any(Compartiment.class), any())).thenReturn(new GestionFinanciereDto());

    }
}
