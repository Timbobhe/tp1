package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ISimulateurFiscalFacade;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.DictionnaireSimulateurFiscalJahia;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.simulateur.InfoSimulateurContratDto;
import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class SimulateurFiscalAccessibilitySupplierTest {

    @InjectMocks
    SimulateurFiscalAccessibilitySupplier simulateurFiscalAccessibilitySupplier;

    @Mock
    ISimulateurFiscalFacade simulateurFiscalFacade;

    @Test
    public void checkAccessibilitySimulateurFiscalTestAccessible() throws TechnicalException {
        InfoSimulateurContratDto dto1 = InfoSimulateurContratDto.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(DictionnaireSimulateurFiscalJahia.SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name()).build()).build();
        InfoSimulateurContratDto dto2 = InfoSimulateurContratDto.builder().bloque(false).raisonBlocage(null).build();
        SimulateurStartDto startDto = SimulateurStartDto.builder().simulateurs(List.of(dto1,dto2)).build();

        Mockito.when(simulateurFiscalFacade.startSimulateur()).thenReturn(startDto);

        AccesFonctionnaliteDto accessibility = simulateurFiscalAccessibilitySupplier.check();

        assertTrue(accessibility.isAccessible());
        assertNull(accessibility.getRaison());
    }

    @Test
    public void checkAccessibilitySimulateurFiscalTestNotAccessible() throws TechnicalException {
        InfoSimulateurContratDto dto1 = InfoSimulateurContratDto.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name()).build()).build();
        InfoSimulateurContratDto dto2 = InfoSimulateurContratDto.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name()).build()).build();
        SimulateurStartDto startDto = SimulateurStartDto.builder().simulateurs(List.of(dto1,dto2)).build();

        Mockito.when(simulateurFiscalFacade.startSimulateur()).thenReturn(startDto);

        AccesFonctionnaliteDto accessibility = simulateurFiscalAccessibilitySupplier.check();

        assertFalse(accessibility.isAccessible());
        assertEquals(accessibility.getRaison(), SIMULATEUR_FISCAL_BLOCAGE_CONDITIONS_CONTRAT.name());
    }
}
