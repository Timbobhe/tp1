package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import lombok.Getter;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static fr.ag2rlamondiale.trm.domain.ModeGestionMdproType.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverFluxStockMDPTest {

    @InjectMocks
    ArbitrageQuestionResolverFluxStockMDP arbitrageQuestionResolverFluxStockMDP;

    @Mock
    IContratFacade contratFacade;

    @Mock
    private IStructureInvFacade structureInvFacade;

    public ContratHeader prepare(boolean arbitrageMixteUniquement, ConfigEncours configEncours) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(false, arbitrageMixteUniquement, configEncours);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        assertTrue(arbitrageQuestionResolverFluxStockMDP.accept(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte));
    }

    @Test
    public void test_ContratFiscalitePEP() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .fiscalitePEP(true)
                        .build());

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertNotNull(resolved.getPropositions().get(0).getWarningMessage());
    }

    @Test
    public void test_ContratFiscalitePEP_ActifGeneral() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .fiscalitePEP(true)
                        .idGrilleSource("11")
                        .build());

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertEquals(resolved.getPropositions().get(0).getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX);
    }

    @Test
    public void test_ContratFiscalitePEP_GestionPilotee() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .fiscalitePEP(true)
                        .idGrilleSource("12")
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertEquals(resolved.getPropositions().get(0).getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);
    }

    @Test
    public void test_arbitrageGestionCibleTerme_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.DYNAMISATION);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertEquals(resolved.getPropositions().get(0).getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);
    }

    @Test
    public void test_arbitrageGestionSourceLibre_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(false, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(LIBRE)
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK) && choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    @Test
    public void test_arbitrageGestionSourcePilotee_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(PILOTEE)
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    @Test
    public void test_arbitrageGestionSourceDynamisation_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(DYNAMISATION)
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    @Test
    public void test_arbitrageGestionSourceHorizon_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(HORIZON)
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    @Test
    public void test_arbitrageGestionSourceHorizonPrudent_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 100));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(HORIZON)
                        .idGrilleSource("65")
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    @Test
    public void test_arbitrageGestionSourceLibre_encoursNull() throws Exception {
        final ContratHeader contratHeader = prepare(true, new ConfigEncours().setMontant(CompartimentType.C1, 0));
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class)))
                .thenReturn(GestionFinanciereActuelleMdpDto.builder()
                        .modeGestionMDPROSource(LIBRE)
                        .build());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        contexte.setResponseModeGestionType(ModeGestionMdproType.LIBRE);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockMDP.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK) && choix.isDisabled() && choix.getWarningMessage() != null));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && !choix.isDisabled()));
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean arbitrageMixteUniquement, ConfigEncours configEncours) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.MDP);
        contratHeader.setPacte(isPacte);

        contratComplet.setEncours(new Memoizer<>(() -> buildCompteEncours(configEncours.getMontant())));

        final Compartiment compartiment = Compartiment.builder().type(CompartimentType.C1).build();
        contratHeader.addCompartiment(compartiment);
        contratComplet.setEncours(compartiment.getCompartimentId(),
                new Memoizer<>(() -> buildCompteEncours(configEncours.getMontant(CompartimentType.C1))));

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setIndicTypeArbitrageAutorise(!arbitrageMixteUniquement);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private ContratHeader createContratHeader(boolean isPacte) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.MDP);
        contratHeader.setPacte(isPacte);
        return contratHeader;
    }

    private Encours buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(new BigDecimal(montant));
        compteEncours.setEnErreur(false);
        return compteEncours;
    }

    @Getter
    private static class ConfigEncours {
        int montant;
        Map<CompartimentType, Integer> montantSelonCompartiment = new HashMap<>();

        ConfigEncours setMontant(int montant) {
            this.montant = montant;
            return this;
        }

        ConfigEncours setMontant(CompartimentType compartimentType, int montant) {
            this.montantSelonCompartiment.put(compartimentType, montant);
            return this;
        }

        int getMontant(CompartimentType compartimentType) {
            return this.montantSelonCompartiment.getOrDefault(compartimentType, this.montant);
        }
    }
}
