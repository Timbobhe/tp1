package fr.ag2rlamondiale.ecrs.mapping;


import fr.ag2rlamondiale.ecrs.dto.SupportDetailContratDto;
import fr.ag2rlamondiale.ecrs.mapping.GestionFinanciereContratDetailMapper;
import fr.ag2rlamondiale.ecrs.mapping.GestionFinanciereContratDetailMapperImpl;
import fr.ag2rlamondiale.trm.domain.encours.ProfilInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;

@RunWith(MockitoJUnitRunner.class)
public class GestionFinanciereContratDetailMapperTest {
    GestionFinanciereContratDetailMapper mapper = new GestionFinanciereContratDetailMapperImpl();

    @Test
    public void should_map_from_SupportDetailTest1() {
        ProfilInvDto profilInv = new ProfilInvDto();
        profilInv.setIndicTxDerogeableProfilInv(Boolean.FALSE);
        profilInv.setIdProfilInv("A_144910652");
        profilInv.setNomProfilInv("Actif En euro");
        profilInv.setTxRepartitionProfilInv(BigDecimal.valueOf(2));
        SupportDetailContratDto supportDetailContratDto = mapper.map(profilInv);
        Assert.assertNotNull(supportDetailContratDto);
    }

    @Test
    public void should_map_from_SupportDetailTest2() {
        SupportInvDto supportInv = new SupportInvDto();
        supportInv.setIdSupportInv("AF_144910652");
        supportInv.setNomSupportInv("ALM Patrimoine");
        supportInv.setNbePartFonds(BigDecimal.valueOf(4));
        supportInv.setCodeCategorieFonds(" XXX");
        supportInv.setValeurLiquidativeFond(BigDecimal.valueOf(1.3));
        supportInv.setTxRepartitionSupportInv(BigDecimal.valueOf(2));

        SupportDetailContratDto supportDetailContratDto_ = mapper.map(supportInv, BigDecimal.valueOf(2));

        Assert.assertNotNull(supportDetailContratDto_);
    }

}
