package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICguFacade;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CguRestControllerTest {
    public static final String ID_CGU = "idCgu";
    public static final String TEXT_CGU = "textCgu";
    public static final String URL_PDF_CGU = "urlPdfCgu";
    @Mock
    ICguFacade cguFacadeMock;

    @InjectMocks
    CguRestController sut;

    @Test
    public void getCguDetails() {
        when(cguFacadeMock.getCguDetails()).thenReturn(new CguDetails());

        CguDetails expected = sut.getCguDetails();

        assertNotNull(expected);
    }

    @Test
    public void should_create_Acceptation_Cgu() throws TechnicalException {
        when(sut.getCguDetails()).thenReturn(createCGUDetail());
        when(cguFacadeMock.createAcceptationCgu(anyString())).thenReturn(true);

        boolean expected = sut.createAcceptationCgu();

        assertTrue(expected);
    }

    private CguDetails createCGUDetail() {
        CguDetails cguDetails = new CguDetails();
        cguDetails.setIdCgu(ID_CGU);
        cguDetails.setTextCgu(TEXT_CGU);
        cguDetails.setUrlPdfCgu(URL_PDF_CGU);
        return cguDetails;
    }
}
