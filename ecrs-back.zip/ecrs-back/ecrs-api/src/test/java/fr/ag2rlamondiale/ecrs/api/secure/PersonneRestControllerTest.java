package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.ecrs.business.IClientFacade;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.dto.personne.GetCoordonneesClientDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PersonneRestControllerTest {
    @Mock
    private IClientFacade clientFacade;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @InjectMocks
    PersonneRestController personneController;

    @Mock
    private IEvenementFacade evenementFacade;

    @Test
    public void should_get_coordonnees_client() throws CommonException {
        when(consulterPersPhysFacade.getCoordonneesClient(any())).thenReturn(new CoordonneesClientDto());

        assertNotNull(personneController.getCoordonneesClient(new GetCoordonneesClientDto()));
    }

    @Test
    public void should_modifier_coordonnees_client() throws CommonException {
        when(clientFacade.modifierCoordonneesClient(null)).thenReturn(new ModifierPPSiloResponseDto());

        assertNotNull(personneController.modifierCoordonneesClient(null));
    }

    @Test
    public void should_valider_coordonnees_client() throws CommonException {
        when(evenementFacade.saveEvenementUtilisateurTraite(TypeEven.CONFIRMATION_DONNEES_PERSO)).thenReturn(new EvenementJson());

        personneController.validateCoordonneesClient(LectureSujetDto.builder()
                .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                .titre("CONFIRMATION_DONNEES_PERSONNELLES")
                .build());

        personneController.validateCoordonneesClient(LectureSujetDto.builder()
                .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                .titre("VALIDATION_DONNEES_PERSONNELLES")
                .build());
    }
}
