package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.DocumentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.PrelevementCodeSituationType;
import fr.ag2rlamondiale.ecrs.dto.versement.SyntheseVersementDonutDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.*;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.EcheancierToEcheancierDtoMapper;
import fr.ag2rlamondiale.ecrs.mapping.OperationToOperationVersementDtoMapper;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.trm.business.IDocumentationFacade;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.document.DocumentRefType;
import fr.ag2rlamondiale.trm.domain.documentation.ged.DocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.RechDocGEDDto;
import fr.ag2rlamondiale.trm.domain.documentation.ged.RechDocGEDResponseDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(PowerMockRunner.class)
@PrepareForTest({RechDocGEDDto.class, DocumentRefType.class})
public class VersementSyntheseFacadeImplTest {
	private static final String ID_OPERATION = "81169648";

	@InjectMocks
	VersementSyntheseFacadeImpl versementSyntheseFacadeImpl;

    @InjectMocks
    OperationFacadeImpl operationFacadeImpl;
	@Mock
	private IContratFacade contratFacade;

	@Mock
	private IOperationFacade operationFacade;

	@Mock
	private IGestionMandatFacade gestionMandatFacade;

	@Mock
	private IOperationsClient operationsClient;

	@Mock
	private IDocumentationFacade documentationFacade;

	@Mock
	private UserContextHolder userContextHolder;

	@Mock
	private OperationToOperationVersementDtoMapper operationMapper;

	@Mock
	private ContratParcoursMapper contratParcoursMapper;

	@Mock
	private IEcheancierFacade echeancierFacade;

	@Mock
	private EcheancierToEcheancierDtoMapper echeancierMapper;

    @Test
    public void getResumeVersementTest() throws TechnicalException {
        //GIVEN
        when(contratFacade.rechercherContratsComplets())
                .thenReturn(createContratsComplets(true, CodeSiloType.ERE, false));

        when(operationFacade.getOperationsForVersementSynthese(any(Compartiment.class),any(Date.class),any(Date.class)))
                .thenReturn(createOperationList());

        List<Echeancier> echeanciers = getEcheanciers();
        echeanciers.get(1).setDateFin(new Date());

        when(echeancierFacade.rechercherEcheanciers(any(Compartiment.class)))
                .thenReturn(echeanciers);

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.MONTH, 1);
        Echeancier newEch_1 = echeanciers.get(0);
        newEch_1.setDateFin(cal.getTime());
        Prelevement prelevement =  new Prelevement();
        prelevement.setDatePrelevement(new Date());
        prelevement.setCodeSituationPrelevement(PrelevementCodeSituationType.TRANS.name());
        newEch_1.setPrelevements(Collections.singletonList(prelevement));

        when(echeancierFacade.consulterEcheancier(any(Compartiment.class),any()))
                .thenReturn(newEch_1);
        //Then
        VersementSyntheseDto dto = versementSyntheseFacadeImpl.getResumeVersement();

        assertNotNull(dto);
    }

	@Test
	public void getVersementsProgrammes() throws TechnicalException {
		// Given
		List<ContratHeader> listContrats = getContratsHeaders();
		Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
		List<Echeancier> echeanciers = getEcheanciers();
		EcheancierDto echeancierDto = new EcheancierDto();
		echeancierDto.setEcheancierId(BigInteger.valueOf(13));
		// When
		when(contratFacade.rechercherContrats()).thenReturn(listContrats);
		when(echeancierFacade.rechercherEcheanciers(c1)).thenReturn(echeanciers);
		when(echeancierFacade.consulterEcheancier(c1, "22")).thenReturn(echeanciers.get(1));
		when(echeancierMapper.echeancierToDto(echeanciers.get(1))).thenReturn(echeancierDto);
		when(contratParcoursMapper.map(any(ContratHeader.class), Mockito.anyBoolean())).thenReturn(null);
		// Then

		List<EcheancierDto> resultat = versementSyntheseFacadeImpl.getVersementsProgrammes();
		assertNotNull(resultat);
		assertFalse(resultat.isEmpty());
		assertEquals(1, resultat.size());

	}

	private List<Echeancier> getEcheanciers() {
		Echeancier ech1 = new Echeancier();
		ech1.setCodeFractionnement("M");
		ech1.setMontant(BigDecimal.valueOf(500));
		ech1.setDateFin(new Date());
		Echeancier ech2 = new Echeancier();
		ech2.setCodeFractionnement("M");
		ech2.setMontant(BigDecimal.valueOf(500));
		ech2.setDateFin(null);
		ech2.setEcheancierId(BigInteger.valueOf(22));
		return Arrays.asList(ech1, ech2);
	}

	@Test
	public void getVersementsHistoriqueTest() throws TechnicalException {
		// Given
		List<ContratHeader> listContrats = getContratsHeaders();
		Compartiment compartimentC1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1)
				.build();
		ZoneId defaultZoneId = ZoneId.systemDefault();
		LocalDate today = LocalDate.now();
		Date dateFin = Date.from(today.atStartOfDay(defaultZoneId).toInstant());

		LocalDate dateMin = today.minus(2, ChronoUnit.YEARS);
		Date dateDebut = Date.from(dateMin.atStartOfDay(defaultZoneId).toInstant());

		Operation operation = new Operation();
		operation.setId(ID_OPERATION);

		// When
		when(contratFacade.rechercherContrats()).thenReturn(listContrats);
		when(operationFacade.getOperationsForVersementSynthese(compartimentC1, dateDebut, dateFin))
				.thenReturn(Collections.singletonList(operation));
		when(operationMapper.operationToDto(operation))
				.thenReturn(OperationVersementDto.builder().typeOperation("VL").build());
		when(contratParcoursMapper.map(any(ContratHeader.class), Mockito.anyBoolean())).thenReturn(null);
		// Then

		List<OperationVersementDto> resultat = versementSyntheseFacadeImpl.getVersementsHistorique();
		assertNotNull(resultat);
		assertFalse(resultat.isEmpty());
		assertEquals(3, resultat.size());
		assertEquals("VL", resultat.get(0).getTypeOperation());
	}

	@Test
	public void should_retrieve_synthese_versement_donut_data() throws TechnicalException {
		when(contratFacade.rechercherContratsComplets())
				.thenReturn(createContratsComplets(true, CodeSiloType.ERE, false));
		when(operationFacade.getOperationsForVersementSynthese(any(Compartiment.class), any(), any()))
				.thenReturn(createOperationList());

		SyntheseVersementDonutDto actual = versementSyntheseFacadeImpl.retrieveSyntheseVersement();

		assertEquals(new BigDecimal("700"), actual.getMontantTotalVersement());
	}

	private List<ContratHeader> getContratsHeaders() {
		ContratHeader contrat1 = createContratHeader("C1", "990876", CodeSiloType.ERE);
		ContratHeader contrat2 = createContratHeader("C2", "990877", CodeSiloType.ERE);
		ContratHeader contrat3 = createContratHeader("C3", "990878", CodeSiloType.ERE);
        return Arrays.asList(contrat1, contrat2, contrat3);
	}

	private List<Operation> createOperationList() {

		Operation operation1 = new Operation();
		operation1.setMontant(new BigDecimal("200"));
		operation1.setEnCoursTraitement(false);
		Operation operation2 = new Operation();
		operation2.setMontant(new BigDecimal("500"));
		operation2.setEnCoursTraitement(false);

		//
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.MONTH, -2);
        operation1.setDebutPeriode(cal.getTime());
        operation1.setFinPeriode(new Date());
        cal.setTime(new Date());
        cal.add(Calendar.MONTH, -3);
        operation1.setDebutPeriode(cal.getTime());
        operation1.setFinPeriode(new Date());
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 3);
        operation1.setDate(cal.getTime());
        operation2.setDate(cal.getTime());

		return Arrays.asList(operation1, operation2);
	}

	private List<ContratComplet> createContratsComplets(boolean isPacte, CodeSiloType codeSiloType,
			boolean isDeductible) {
		List<ContratComplet> contratComplets = new ArrayList<>();
		ContratComplet contratComplet = new ContratComplet();
		ContratHeader contratHeader = new ContratHeader();
		contratHeader.setId("id");
		contratHeader.setCodeSilo(codeSiloType);
		contratHeader.setDeductible(isDeductible);
		contratHeader.setPacte(isPacte);

		Compartiment compartiment1 = new Compartiment();
		compartiment1.setContratHeader(contratHeader);
		compartiment1.setType(CompartimentType.C1);
		compartiment1.setDeductible(isDeductible);
		contratHeader.setCompartiments(Collections.singletonList(compartiment1));
		contratComplet.setContratHeader(contratHeader);
		contratComplets.add(contratComplet);

		return contratComplets;
	}

	@Test
	public void getVersProgrammeDetailsTest() throws TechnicalException {
		// Given
		ContratId contratId = ContratId.builder().codeSilo(CodeSiloType.ERE).nomContrat("RG0102").idAdherente("007")
				.build();
		VersementProgrammeDetailsRequestDto requestDto = VersementProgrammeDetailsRequestDto.builder()
				.contratId(contratId).codeDocument("ECH").build();
		ContratHeader contratHeader = prepareContratHeader();
		CoordonneesBancairesDto givenCoordBanc = CoordonneesBancairesDto.builder().bic("BC456").iban("FR7645433333")
				.titulaire("Mir").build();

        DocGEDDto dGedDto1 = new DocGEDDto();
        dGedDto1.setIdDoc("ac231");
        DocGEDDto dGedDto2 = new DocGEDDto();
        dGedDto2.setIdDoc("prun231");
		RechDocGEDResponseDto rech = new RechDocGEDResponseDto();
		rech.setDocGED(Arrays.asList(dGedDto1, dGedDto2));
		// When
		when(userContextHolder.get()).thenReturn(getUserContext());
		when(documentationFacade.rechercherDernierDocumentEre(any(RechDocGEDDto.class))).thenReturn(rech);
		when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
		when(gestionMandatFacade.consulterCoordonneesBancairesContrat(contratHeader)).thenReturn(givenCoordBanc);
		// Then
		VersementProgrammeDetailsDto dto = versementSyntheseFacadeImpl.getVersProgrammeDetails(requestDto);
		CoordonneesBancairesDto coordBanc = dto.getCoordonneesBancaires();
		assertNotNull(dto);
		assertNotNull(coordBanc);
		assertEquals("FR7645433333", coordBanc.getIban());
		assertEquals("BC456", coordBanc.getBic());
		assertEquals("Mir", coordBanc.getTitulaire());

	}

/*    @Test
    public void getOpVersementDetailsTestERE() throws TechnicalException {
        //Given
        IdDansSiloDto silo = new IdDansSiloDto("ope42",CodeSiloType.ERE);
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");

        when(operationsClient.consulterStructInvestOperations(silo)).thenReturn(opDetailDto);
        //When
        DetailsOperationDto detailOpeVersDto = operationFacadeImpl.getOperationsDetailsForVersementSynthese("ope42", "ERE");
        assertNotNull(detailOpeVersDto);
        assertEquals(opDetailDto.getMontantNet().doubleValue(), detailOpeVersDto.getMontantNetOperation(), 0.0);
        assertEquals(opDetailDto.getLibTypeOperation(),detailOpeVersDto.getTypeOperation());
    }*/
/*    @Test
    public void getOpVersementDetailsTestMDPRO() throws TechnicalException {
        //Given
        IdDansSiloDto silo = new IdDansSiloDto("ope42",CodeSiloType.MDP);
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        opDetailDto.setSupportInvestissement(buildListOccurStructInvDto());

        when(operationsClient.consulterStructInvestOperations(silo)).thenReturn(opDetailDto);
        //When
        DetailsOperationDto detailOpeVersDto = operationFacadeImpl.getOperationsDetailsForVersementSynthese("ope42", "MDP");
        assertNotNull(detailOpeVersDto);
        assertEquals(opDetailDto.getMontantNet().doubleValue(), detailOpeVersDto.getMontantNetOperation(), 0.0);
        assertEquals(opDetailDto.getLibTypeOperation(),detailOpeVersDto.getTypeOperation());
    }*/

   /* @Test
    public void buildProfilInvDtoTest() {
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        ProfilInvDto profilInvDto = new ProfilInvDto();
        profilInvDto.setIdProfilInv("IDPROFILINV");
        profilInvDto.setTxRepartitionProfilInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        OccurStructInvDto occurStructInvDto = new OccurStructInvDto();
        occurStructInvDto.setProfilInv(profilInvDto);
        occurStructInvDto.setMontantOccurSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        List<OperationDetailInfoDto> operationDetailInfoDtoList = new ArrayList<>();
        operationFacadeImpl.buildProfilInvDto(occurStructInvDto,opDetailDto,operationDetailInfoDtoList);
        assertTrue(operationDetailInfoDtoList.size()>0);
    }
    @Test
    public void buildGrilleInvDtoTest() {
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        GrilleInvDto grilleInvDto = new GrilleInvDto();
        grilleInvDto.setIdGrilleInv("IDGRILLEINV");
        grilleInvDto.setTxRepartitionGrilleInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        OccurStructInvDto occurStructInvDto = new OccurStructInvDto();
        occurStructInvDto.setMontantOccurSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        occurStructInvDto.setGrilleInv(grilleInvDto);
        List<OperationDetailInfoDto> operationDetailInfoDtoList = new ArrayList<>();
        operationFacadeImpl.buildGrilleInvDto(occurStructInvDto,opDetailDto,operationDetailInfoDtoList);
        assertTrue(operationDetailInfoDtoList.size()>0);
    }

    @Test
    public void hasOperationDetailInfoDtoListTest() {


        List<OccurStructInvDto> occurStructInvDtos = buildListOccurStructInvDto();

        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        opDetailDto.setSupportInvestissement(new ArrayList<>());
        List<OperationDetailInfoDto> operationDetailInfoDtoList = new ArrayList<>();
        Map<Integer, List<OccurStructInvDto>> structInvestByLevel = new HashMap<>();
        structInvestByLevel.put(0,occurStructInvDtos);
        Map.Entry<Integer,List<OccurStructInvDto>> entry = structInvestByLevel.entrySet().iterator().next();
        operationFacadeImpl.hasOperationDetailInfoDtoList(opDetailDto,operationDetailInfoDtoList,entry);
        assertTrue(operationDetailInfoDtoList.size()>0);

    }*/

    private List<OccurStructInvDto> buildListOccurStructInvDto() {
        SupportInvDto supportInvDto = new SupportInvDto();
        supportInvDto.setTxRepartitionSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        ContributionInvDto contributionInvDto = new ContributionInvDto();
        contributionInvDto.setTxRepartitionContribution(new BigDecimal("234.78", MathContext.DECIMAL64));
        TarifInvDto tarifInvDto = new TarifInvDto();
        tarifInvDto.setTxRepartitionTarifInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        GrilleInvDto grilleInvDto = new GrilleInvDto();
        grilleInvDto.setIdGrilleInv("IDGRILLEINV");
        grilleInvDto.setTxRepartitionGrilleInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        ProfilInvDto profilInvDto = new ProfilInvDto();
        profilInvDto.setIdProfilInv("IDPROFILINV");
        profilInvDto.setTxRepartitionProfilInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        OccurStructInvDto occurStructInvDto = new OccurStructInvDto();
        occurStructInvDto.setProfilInv(profilInvDto);
        occurStructInvDto.setGrilleInv(grilleInvDto);
        occurStructInvDto.setSupportInv(supportInvDto);
        occurStructInvDto.setTarifInv(tarifInvDto);
        occurStructInvDto.setContributionInv(contributionInvDto);
        occurStructInvDto.setMontantOccurSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        occurStructInvDto.setIdOccurParentStructInv("IDSTRUCTUREINVESTISSEMENT");
        occurStructInvDto.setIdOccurStructInv("IDSTRUCTUREINVESTISSEMENT");
        return Collections.singletonList(occurStructInvDto);
    }

/*    @Test
    public void getThirdLevelFromTreeTest() {
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        opDetailDto.setIdStructureInvestissement("IDSTRUCTUREINVESTISSEMENT");
        opDetailDto.setSupportInvestissement(buildListOccurStructInvDto());
        List<OccurStructInvDto> occurStructInvDtoList = operationFacadeImpl.getThirdLevelFromTree(opDetailDto);
        assertTrue(occurStructInvDtoList.size() > 0);
    }

    @Test
    public void getAllLevel() {

        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        opDetailDto.setIdStructureInvestissement("IDSTRUCTUREINVESTISSEMENT");
        opDetailDto.setSupportInvestissement(buildListOccurStructInvDto());

        Map<Integer, List<OccurStructInvDto>> map = operationFacadeImpl.getAllLevel(opDetailDto);
        assertTrue(map.size() > 0);
    }

    @Test
    public void getAllLevelIsZero() {
        Map<Integer, List<OccurStructInvDto>> map = operationFacadeImpl.getAllLevel(new OperationDetailDto());
        assertEquals(0, map.size());
    }*/

    @Test
    public void rechercherDocumentsVersementTest() throws Exception {

        PowerMockito.mockStatic(RechDocGEDDto.class);
        PowerMockito.mockStatic(DocumentRefType.class);
        PowerMockito.when(DocumentRefType.valueOf(any())).thenReturn(DocumentRefType.FD);

        ContratHeader crt = prepareContratHeader();
        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(crt));
        RechDocGEDDto inAC =  new RechDocGEDDto();
        inAC.setCodeSilo(CodeSiloType.ERE);
        inAC.setTokenPFS("token_Ac");

        RechDocGEDDto inPrun =  new RechDocGEDDto();
        inPrun.setCodeSilo(CodeSiloType.ERE);
        inPrun.setTokenPFS("token_Prun");
        when(userContextHolder.get()).thenAnswer(ans -> {
            UserContext user = new UserContext();
            user.setNumeroPersonneEre("P45647");
            return user;
        });
        PowerMockito.when(RechDocGEDDto.prepareRechDocGEDDto(crt.getContratId(),DocumentRefType.AC.name(),"P45647"))
        .thenReturn(inAC);
        PowerMockito.when(RechDocGEDDto.prepareRechDocGEDDto(crt.getContratId(),DocumentRefType.PRUN.name(),"P45647"))
                .thenReturn(inPrun);

        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        Date first = c.getTime();
        c.add(Calendar.DATE, -2);
        Date seconde = c.getTime();

        RechDocGEDResponseDto reponse = new RechDocGEDResponseDto();
        DocGEDDto dg = new DocGEDDto();
        dg.setIdDoc("AC");
        dg.setDateIndexation(first);
        dg.setIdContrat(crt.getId());
        dg.setTypeDoc("Fiche performance UC");
        reponse.setDocGED(Collections.singletonList(dg));

        RechDocGEDResponseDto reponseB = new RechDocGEDResponseDto();
        DocGEDDto dg2 = new DocGEDDto();
        dg2.setIdDoc("PRUN");
        dg2.setDateIndexation(seconde);
        dg2.setIdContrat(crt.getId());
        dg.setTypeDoc(DocumentRefType.FD.getCode());
        reponseB.setDocGED(Collections.singletonList(dg2));
        when(documentationFacade.rechercherDernierDocumentEre(any()))
                .thenReturn(reponse, reponseB);

        when(contratFacade.rechercherContratParId(crt.getId())).thenReturn(crt);

        //When
        DocumentDto dto = versementSyntheseFacadeImpl.rechercherDocumentsVersement();
        assertNotNull(RechDocGEDDto.prepareRechDocGEDDto(crt.getContratId(),DocumentRefType.AC.name(),"P45647"));
		//PowerMockito.verifyNew(RechDocGEDDto.class).withNoArguments();
	    PowerMockito.verifyStatic(RechDocGEDDto.class, Mockito.times(2));
	    RechDocGEDDto.prepareRechDocGEDDto(crt.getContratId(),DocumentRefType.AC.name(),"P45647");
        assertNotNull(dto);
        assertEquals(dto, DocumentDto.builder().contratId(crt.getContratId()).name(DocumentRefType.FD.getCode())
        .date(DateUtils.dateToString(first)).code(DocumentRefType.FD.getCode()).build());

    }

    @Test
    public void getContratsTest() throws TechnicalException {
        //Given
        when(contratFacade.rechercherContrats()).thenReturn(contratsMock());
        ContratParcoursDto contratMapped = new ContratParcoursDto();
        contratMapped = ContratParcoursDto.builder().identifiantAssure("kuld").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .encours(EncoursDto.builder().encoursEnErreur(false).montantEncours(234.67).build()).compartimentType(CompartimentType.C1)
                .avecEncours(true).build();
        when(contratParcoursMapper.map(any(Compartiment.class), any(Boolean.class))).thenReturn(contratMapped);
        //then
        List<ContratParcoursDto> contrats = versementSyntheseFacadeImpl.getContrats();

        assertEquals(1, contrats.size());
    }

    private List<ContratHeader> contratsMock(){
        return Arrays.asList(
                ContratHeader.builder().affichageType(AffichageType.GRISE).build(),
                ContratHeader.builder().affichageType(AffichageType.MASQUE).build(),
                ContratHeader.builder().affichageType(AffichageType.NORMAL).compartiments(
                        Collections.singletonList(Compartiment.builder().type(CompartimentType.C1).build()))
                      .codeSilo(CodeSiloType.ERE).numGenContrat("RAG23").build()
        );
    }

    private ContratParcoursDto convert() {
        return ContratParcoursDto.builder().identifiantAssure("kuld").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .encours(EncoursDto.builder().encoursEnErreur(false).montantEncours(234.67).build()).compartimentType(CompartimentType.C1)
                .avecEncours(true).build();
    }

	private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType,
			boolean allowDifferentInvestmentsForVif, List<CompartimentType> compartimentTypes,
			SituationAffiliationEnum etatCompartiment, boolean indicRefusArbitrageInternet, int nbeArbitrageAnn,
			String typeContrat, SituationContratEnum etatContrat) {
		final ContratComplet contratComplet = new ContratComplet();

		final ContratHeader contratHeader = new ContratHeader();
		contratComplet.setContratHeader(contratHeader);

		contratHeader.setId("RG912");
		contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
		contratHeader.setPacte(isPacte);
		contratHeader.setAffichageType(affichageType);
		contratHeader.setTypeContrat(typeContrat);
		contratHeader.setEtatContrat(etatContrat);
		contratHeader.setNumGenContrat("Num");
		for (CompartimentType compartimentType : compartimentTypes) {
			final Compartiment compartiment = Compartiment.builder().type(compartimentType)
					.etatCompartiment(etatCompartiment).disponibilite(DisponibiliteType.DISPONIBLE)
					.affichageType(AffichageType.NORMAL).build();
			if (!isMdpro) {
				compartiment.setIdentifiantAssure("281134");
			}
			contratHeader.addCompartiment(compartiment);
		}

		final ContratGeneral contratGeneral = new ContratGeneral();
		contratComplet.setContratGeneral(contratGeneral);
		contratGeneral.setCodeAssureur("code assureur");
		contratGeneral.setIdContractante("Pid");
		contratGeneral.setIdAssurePrincipal("Pid");
		contratGeneral.setDateNaissanceContractante(DateUtils.createDate(10, 10, 2020));
		contratGeneral.setDateNaissanceAssurePrincipal(DateUtils.createDate(10, 10, 2020));

		final OptContratEpargne optContratEpargne = new OptContratEpargne();
		optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
		optContratEpargne.setIndicRefusArbitrageInternet(indicRefusArbitrageInternet);
		optContratEpargne.setNbeArbitrageAnn(nbeArbitrageAnn);
		contratGeneral.setOptContratEpargne(optContratEpargne);

		return contratComplet;
	}

	public ContratComplet prepareContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType,
			List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment,
			boolean gestionFinanciereDifferentePossible, boolean imposee, boolean indicRefusArbitrageInternet,
			int nbeArbitrageAnn, String typeContrat, SituationContratEnum etatContrat, boolean profile)
			throws TechnicalException {
		final ContratComplet contratComplet = createContratComplet(isPacte, isMdpro, affichageType,
				gestionFinanciereDifferentePossible, compartimentTypes, etatCompartiment, indicRefusArbitrageInternet,
				nbeArbitrageAnn, typeContrat, etatContrat);
		when(contratFacade.rechercherContratsComplets()).thenReturn(Collections.singletonList(contratComplet));
		return contratComplet;
	}

	public ContratHeader prepareContratHeader() {
		ContratHeader contratHeader = new ContratHeader();
		contratHeader.setId("RG912");
		contratHeader.setCodeSilo(CodeSiloType.ERE);
		contratHeader.setPacte(true);
		contratHeader.setAffichageType(AffichageType.NORMAL);
		contratHeader.setTypeContrat("");
		contratHeader.setEtatContrat(SituationContratEnum.EN_COURS);
		contratHeader.setNumGenContrat("RG4555");
		return contratHeader;
	}

	private UserContext getUserContext() {
		UserContext user = new UserContext();
		user.setNumeroPersonneEre("ERE");
		user.setNumeroPersonneMdpro("MDP");
		return user;
	}

	private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
		ContratHeader contrat = new ContratHeader();
		contrat.setId(id);
		contrat.setIdentifiantAssure(idAssure);
		contrat.setCodeSilo(silo);
		contrat.setEtatContrat(SituationContratEnum.CREATION);
		contrat.setAffichageType(AffichageType.NORMAL);
		Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
		contrat.setCompartiments(Collections.singletonList(c1));
		return contrat;
	}
}
