package fr.ag2rlamondiale.ecrs.business.impl.arretVersement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.impl.versement.BlocageVersementContratDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementContexteDto;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.PrelevementCodeSituationType;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ArretVersementQuestionResolverChoixCompartimentTest {
    
    @InjectMocks
    ArretVersementQuestionResolverChoixCompartiment sut;

    @Mock
    private IContratFacade contratFacade;

    @InjectMocks
    private ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    IEcheancierFacade echeancierFacade;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    RequestContextHolder requestContextHolder;

    @Before
    public void init() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        sut.setDelaiTeletransmission(15);
        ReflectionTestUtils.setField(sut, "contratParcoursMapper", contratParcoursMapper);
    }

    @Test
    public void should_accept() {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .contratSelectionne(ContratId.builder().build())
                .build();

        boolean result = sut.accept(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertTrue(result);
    }

    @Test
    public void should_not_accept() {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .build();

        boolean result = sut.accept(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertFalse(result);
    }

    @Test
    public void should_resolve_with_all_compartiments() throws TechnicalException {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .contratSelectionne(ContratId.builder()
                        .nomContrat("idContrat")
                        .codeSilo(CodeSiloType.ERE)
                        .build())
                .build();
        ContratHeader contratHeader = createContratHeader(true, false);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratHeader);
        when(echeancierFacade.getProchainEcheancier(any(Compartiment.class))).thenReturn(createEcheancier());
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(500));

        QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = sut.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertTrue(true);
        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getPropositions());
        Assert.assertTrue(result.isShow());
        Assert.assertEquals(2, result.getPropositions().size());
    }

    @Test
    public void should_resolve_with_one_compartiment_through_request_context() throws TechnicalException {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .contratSelectionne(ContratId.builder()
                        .nomContrat("idContrat")
                        .codeSilo(CodeSiloType.ERE)
                        .build())
                .build();
        ContratHeader contratHeader = createContratHeader(true, false);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratHeader);
        when(requestContextHolder.getCompartiment()).thenReturn("c1");
        when(requestContextHolder.getContrat()).thenReturn("idContrat");
        when(echeancierFacade.getProchainEcheancier(any(Compartiment.class))).thenReturn(createEcheancier());
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(500));

        QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = sut.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertTrue(true);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isShow());
        Assert.assertNotNull(result.getDefaultValue());
        Assert.assertNotNull(result.getDefaultValue().getValue());
        Assert.assertNotNull(result.getDefaultValue().getValue().getCompartiment());
        Assert.assertEquals(CompartimentType.C1, result.getDefaultValue().getValue().getCompartiment().getCompartimentType());
        Assert.assertEquals("c1", result.getDefaultValue().getValue().getCompartiment().getIdentifiantAssure());
    }

    @Test
    public void should_resolve_with_one_compartiment_with_versement_programme() throws TechnicalException {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .contratSelectionne(ContratId.builder()
                        .nomContrat("idContrat")
                        .codeSilo(CodeSiloType.ERE)
                        .build())
                .build();
        ContratHeader contratHeader = createContratHeader(true, false);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratHeader);
        when(requestContextHolder.getCompartiment()).thenReturn("c1");
        when(requestContextHolder.getContrat()).thenReturn("idContrat");
        when(echeancierFacade.getProchainEcheancier(
                eq(createCompartiment(CompartimentType.C1, "c1", createContratHeader(true, false)))))
                .thenReturn(createEcheancier());
        when(echeancierFacade.getProchainEcheancier(
                eq(createCompartiment(CompartimentType.C4, "c4", createContratHeader(true, false)))))
                .thenReturn(null);
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(500));

        sut.setDelaiTeletransmission(15);
        QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = sut.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertTrue(true);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isShow());
        Assert.assertNotNull(result.getDefaultValue());
        Assert.assertNotNull(result.getDefaultValue().getValue());
        Assert.assertNotNull(result.getDefaultValue().getValue().getCompartiment());
        Assert.assertEquals(CompartimentType.C1, result.getDefaultValue().getValue().getCompartiment().getCompartimentType());
        Assert.assertEquals("c1", result.getDefaultValue().getValue().getCompartiment().getIdentifiantAssure());
    }

    @Test
    public void should_resolve_with_one_compartiment_through_context() throws TechnicalException {
        ArretVersementContexteDto contexte = ArretVersementContexteDto.builder()
                .contratSelectionne(ContratId.builder()
                        .nomContrat("idContrat")
                        .codeSilo(CodeSiloType.ERE)
                        .build())
                .compartimentSelectionne(CompartimentId.builder()
                        .compartimentType(CompartimentType.C1)
                        .idAssure("c1")
                        .build())
                .build();
        ContratHeader contratHeader = createContratHeader(true, false);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratHeader);
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(500));

        QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> result = sut.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        Assert.assertTrue(true);
        Assert.assertNotNull(result);
        Assert.assertFalse(result.isShow());
        Assert.assertNotNull(result.getDefaultValue());
        Assert.assertNotNull(result.getDefaultValue().getValue());
        Assert.assertNotNull(result.getDefaultValue().getValue().getCompartiment());
        Assert.assertEquals(CompartimentType.C1, result.getDefaultValue().getValue().getCompartiment().getCompartimentType());
        Assert.assertEquals("c1", result.getDefaultValue().getValue().getCompartiment().getIdentifiantAssure());
    }

    private Echeancier createEcheancier() {
        Echeancier echeancier = new Echeancier();
        echeancier.setMontant(BigDecimal.valueOf(100));
        echeancier.setCodeFractionnement(FrequenceVirementType.MENSUELLE.getCodeFractionnement());
        Prelevement prelevement = new Prelevement();
        prelevement.setCodeSituationPrelevement(PrelevementCodeSituationType.TRANS.name());
        prelevement.setDatePrelevement(DateUtils.createDate(10,1,2050));
        echeancier.setPrelevements(Collections.singletonList(prelevement));
        return echeancier;
    }

    private List<ContratComplet> mockContratsComplets() {
        List<ContratComplet> contratComplets = new ArrayList<>();
        ContratComplet contratComplet = new ContratComplet();
        contratComplet.setContratHeader(createContratHeader(true, false));
        contratComplets.add(contratComplet);
        return contratComplets;
    }

    private List<ContratComplet> mockContratsComplets(String idContrat) {
        List<ContratComplet> contratComplets = new ArrayList<>();
        ContratComplet contratComplet = new ContratComplet();
        contratComplet.setContratHeader(createContratHeader(idContrat));
        contratComplets.add(contratComplet);
        return contratComplets;
    }

    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("idContrat");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C1, "c1", contratHeader));
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C4, "c4", contratHeader));
        return contratHeader;
    }

    private ContratHeader createContratHeader(String idContrat) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setPersonId("personId");
        contratHeader.setId(idContrat);
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C1, "c1", contratHeader));
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C4, "c4", contratHeader));
        return contratHeader;
    }

    private Compartiment createCompartiment(CompartimentType type, String idAssure, ContratHeader contratHeader) {
        Compartiment compartiment = new Compartiment();
        compartiment.setType(type);
        compartiment.setIdentifiantAssure(idAssure);
        compartiment.setContratHeader(contratHeader);
        compartiment.setDisponibilite(DisponibiliteType.DISPONIBLE);
        return compartiment;
    }

    private EncoursDto buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(BigDecimal.valueOf(montant));
        compteEncours.setEnErreur(false);
        return new EncoursDto(compteEncours);
    }
}
