package fr.ag2rlamondiale.ecrs.mapping;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.dto.ClientDto;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class UtilisateurMapperTest {

    @Mock
    IConsulterPersPhysFacade consulterPersPhysFacade;

    @InjectMocks
    @Spy
    UtilisateurMapper utilisateurMapper;

    @Test
    public void mapperPersonnePhysiqueToClientDtoTest() throws TechnicalException {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("P3844810");
        Set<CodeSiloType> silos = new HashSet<>();
        silos.add(CodeSiloType.ERE);
        userContext.setSilos(silos);
        // Given
        PersonnePhysiqueConsult personnePhys = PersonnePhysiqueConsult.builder().
                dateDeNaissance(new Date()).codeCivilite("M").build();
        // When
        Mockito.when(consulterPersPhysFacade.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(personnePhys);

        // Then
        ClientDto dto = utilisateurMapper.mapperPersonnePhysiqueToClientDto(new ClientDto(), userContext);
        Assert.assertEquals("M", dto.getCivilite());
        Assert.assertNotNull(dto.getDateDeNaissance());
    }

    @Test
    public void mapperPersonnePhysiqueConsultToClientDtoTest() throws TechnicalException {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("P3844810");
        Set<CodeSiloType> silos = new HashSet<>();
        silos.add(CodeSiloType.ERE);
        userContext.setSilos(silos);
        // Given
        PersonnePhysiqueConsult personnePhys = PersonnePhysiqueConsult.builder().
                dateDeNaissance(new Date())
                .codeCivilite("M")
                .prenom("Anne Marie")
                .nom("ABADIE")
                .nomNaissance("ABADIE")
                .build();
        // When
        Mockito.when(consulterPersPhysFacade.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(personnePhys);

        // Then
        ClientDto dto = utilisateurMapper.mapperPersonnePhysiqueConsultToClientDto(new ClientDto(), userContext);
        Assert.assertEquals("M", dto.getCivilite());
        Assert.assertEquals("Anne Marie", dto.getPrenom());
        Assert.assertEquals("ABADIE", dto.getNom());
        Assert.assertEquals("ABADIE", dto.getNomNaissance());
        Assert.assertNotNull(dto.getDateDeNaissance());
    }
}
