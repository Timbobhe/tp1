package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.impl.accessibilite.*;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.InfoArretVersementContrat;
import fr.ag2rlamondiale.ecrs.dto.versement.InfoVersementContratDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementStartDto;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.business.impl.accessibilite.CoordonneesBancairesAccessibilitySupplier;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesStartDto;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDocumentationFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.business.impl.FonctionnaliteAccessibiliteFacadeImpl;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.documentation.ref.Fiche;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AccesFonctionnaliteFacadeImplTest {
    @Mock
    private IContratFacade contratFacadeMock;

    @Mock
    private IBiaFacade biaFacadeMock;

    @Mock
    private IWorkflowFacade workflowClientMock;

    @Mock
    private UserContextHolder userContextHolderMock;

    @Mock
    private IArbitrageFacade arbitrageFacade;

    @Mock
    private IBlocageFacade blocageFacade;

    @Mock
    private IDocumentationFacade documentationFacade;

    @Mock
    private IGestionMandatFacade gestionMandatFacade;

    @Mock
    private IConsulterPersPhysFacade consulterPPFacade;

    @Mock
    IVersementFacade versementFacade;

    @Mock
    IArretVersementFacade arretVersementFacade;

    @InjectMocks
    @Spy
    private FonctionnaliteAccessibiliteFacadeImpl sut;

    @InjectMocks
    private BiaAccessibilitySupplier biaAccessibilitySupplier;

    @InjectMocks
    private CoordonneesBancairesAccessibilitySupplier coordonneesBancairesAccessibilitySupplier;

    @InjectMocks
    private ArbitrageAccessibilitySupplier arbitrageAccessibilitySupplier;

    @InjectMocks
    private ArretVersementAccessibilitySupplier arretVersementAccessibilitySupplier;

    @InjectMocks
    private VersementAccessibilitySupplier versementAccessibilitySupplier;

    @InjectMocks
    private ModificationClauseBeneficiaireAccessibilitySupplier modificationClauseBeneficiaireAccessibilitySupplier;

    private ContratHeader contrat(String id, CodeSiloType codeSiloType) {
        return ContratHeader.builder().codeSilo(codeSiloType).id(id).college("college_" + id).build();
    }

    private List<ContratHeader> contrats(ContratHeader... contratHeaders) {
        return Arrays.asList(contratHeaders);
    }

    ContratComplet contratComplet(String id, CodeSiloType codeSiloType) {
        final ContratHeader contratHeader = contrat(id, codeSiloType);
        ContratComplet ecc = new ContratComplet(contratHeader);
        return ecc;
    }

    List<ContratComplet> ContratComplets(ContratComplet... contratComplets) {
        return Arrays.asList(contratComplets);
    }

    @Before
    public void init() throws DocumentException, TechnicalException {
//        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
        when(userContextHolderMock.get()).thenReturn(createUserContext());
        when(documentationFacade.rechercherNoticeInformationSalarie(any(ContratHeader.class))).thenReturn(new Fiche());
        sut.setSuppliers(Arrays.asList(biaAccessibilitySupplier, arbitrageAccessibilitySupplier,
                coordonneesBancairesAccessibilitySupplier, modificationClauseBeneficiaireAccessibilitySupplier,
                versementAccessibilitySupplier, arretVersementAccessibilitySupplier));
    }

    void prepareWhen(String idContrat, CodeSiloType codeSiloType, ResultParcoursEffectueDto resultBiaEffectue) throws TechnicalException {
        final ContratHeader id1 = contrat(idContrat, codeSiloType);
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(contrats(id1));
        when(biaFacadeMock.testBiaEffectue(eq(id1))).thenReturn(resultBiaEffectue.toBuilder().contratHeader(id1).build());
    }

    void prepareWhen(ResultParcoursEffectueDto... resultsBiaEffectue) throws TechnicalException {
        final List<ContratHeader> contrats = Stream.of(resultsBiaEffectue).map(ResultParcoursEffectueDto::getContratHeader).collect(Collectors.toList());
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(contrats);

        for (ResultParcoursEffectueDto resultBiaEffectue : resultsBiaEffectue) {
            when(biaFacadeMock.testBiaEffectue(eq(resultBiaEffectue.getContratHeader()))).thenReturn(resultBiaEffectue);
        }
    }

    void prepareContratComplet(String idContrat, CodeSiloType codeSiloType, ResultParcoursEffectueDto resultArbitrageEffectue) throws TechnicalException {
        final ContratComplet id1 = contratComplet(idContrat, codeSiloType);
        when(contratFacadeMock.rechercherContratsComplets()).thenReturn(ContratComplets(id1));
        when(arbitrageFacade.arbitrageContratEnCoursERE(eq(id1.getContratHeader()))).thenReturn(resultArbitrageEffectue.toBuilder().contratHeader(id1.getContratHeader()).build());
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
    }

    void prepareContratComplet(ResultParcoursEffectueDto... resultsArbitrageEffectue) throws TechnicalException {
        final List<ContratHeader> contrats = Stream.of(resultsArbitrageEffectue).map(ResultParcoursEffectueDto::getContratHeader).collect(Collectors.toList());
        final List<ContratComplet> contratComplets = new ArrayList<>();
        for (ContratHeader contratHeader : contrats) {
            contratComplets.add(new ContratComplet(contratHeader));
        }
        when(contratFacadeMock.rechercherContratsComplets()).thenReturn(contratComplets);

        for (ResultParcoursEffectueDto resultArbitrageEffectue : resultsArbitrageEffectue) {
            when(arbitrageFacade.arbitrageContratEnCoursERE(eq(resultArbitrageEffectue.getContratHeader()))).thenReturn(resultArbitrageEffectue);
        }
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
    }

    @Test
    public void should_access_completer_bia_when_has_etat_affiliation_sans_bia() throws TechnicalException {
        prepareWhen("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);
        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(NONE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_acess_completer_bia_when_etat_different_than_remis_en_vigueur_sans_bia_et_affiliation_sans_bia() throws TechnicalException {
        prepareWhen("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(true).build());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_DEJA_SAISI, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_completer_bia_when_demande_modification_donnees_personnelles_en_cours() throws TechnicalException {
        prepareWhen("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_completer_bia_when_has_bia_en_cours() throws TechnicalException {
        prepareWhen("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).workflowParcoursEncours(true).build());
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_3_contrats_biaPending() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(false).sigElecEncoursSigne(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(false).workflowParcoursEncours(true).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_3_contrats_biaEffectue() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(true).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_DEJA_SAISI, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_3_contrats_biaEncours() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(false).sigElecEncoursSigne(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(false).workflowParcoursEncours(true).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_3_contrats_mdpEncours() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(false).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(false).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_access_3_contrats() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(false).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(true).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(NONE, getRaison(accessibiliteFonctionnalite));
    }

    private ContratBlocage getRaison(AccesFonctionnaliteDto accessibiliteFonctionnalite) {
        return ContratBlocage.valueOf(accessibiliteFonctionnalite.getRaison());
    }


    @Test
    public void should_not_access_3_contrats() throws TechnicalException {
        prepareWhen(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(false).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(true).build()
        );
        when(workflowClientMock.hasDemandeMdpEncours(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_MODIFICATION_DONNEES_PERSONNELLES_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_acess_Completer_bia_when_mono_equipe_MDPRO() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(new ArrayList<>());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COMPLETER_BIA);

        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(BLOCAGE_BIA_MONO_EQUIPE_MDPRO, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_access_arbitrage_when_has_etat_affiliation_sans_bia() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isPartsNonArbitrablesERE(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(NONE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_acess_arbitrage_when_etat_different_than_remis_en_vigueur_sans_bia_et_affiliation_sans_bia() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(true).build());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_has_arbitrage_en_cours() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).workflowParcoursEncours(true).build());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_3_contrats_arbitrageEncours() throws TechnicalException {
        prepareContratComplet(
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID1", CodeSiloType.ERE)).parcoursEffectue(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID2", CodeSiloType.ERE)).parcoursEffectue(false).sigElecEncoursSigne(true).build(),
                ResultParcoursEffectueDto.builder().contratHeader(contrat("ID3", CodeSiloType.ERE)).parcoursEffectue(false).workflowParcoursEncours(true).build()
        );

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_EXTRANET_ARBITRAGE_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isMonoSupport_and_has_no_partsArbitrables() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isMonoSupport(any())).thenReturn(true);
        when(arbitrageFacade.isPartsNonArbitrablesERE(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_CONDITIONS_CONTRAT, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isArbitrageEnLigneInterdit() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isPartsNonArbitrablesERE(any())).thenReturn(false);
        when(arbitrageFacade.isArbitrageEnLigneInterdit(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isNbeArbitrageAnnReached() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isPartsNonArbitrablesERE(any())).thenReturn(false);
        when(arbitrageFacade.isNbeArbitrageAnnReachedERE(any())).thenReturn(true);
        when(arbitrageFacade.getNewDateForArbitragePossible()).thenReturn(new Date());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_NB_MAX_DEPASSE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isArbitrageEnAttenteValorisation() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.ERE, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isPartsNonArbitrablesERE(any())).thenReturn(false);
        when(arbitrageFacade.isArbitrageEnAttenteValorisationERE(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_OPERATIONS_EN_COURS, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptant_or_isCompteEpargneAssureNotLibereOrNotEnCoursMDPRO() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(any())).thenReturn(true);
        when(arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isNotContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptant_or_isCompteEpargneAssureLibereOrEnCoursMDPRO() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(any())).thenReturn(false);
        when(arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isMonoSupport_MDPRO() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(any())).thenReturn(true);
        when(arbitrageFacade.isMonoSupport(any())).thenReturn(true);
        when(arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_CONDITIONS_CONTRAT, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isSouscripteurNotEqualsAssureAndContratMoral_or_isAssureOrSouscripteurMineur() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isAssureOrSouscripteurMajeur(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isSouscripteurEqualsAssureAndContratMoral_or_isAssureOrSouscripteurMajeur() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isAssureOrSouscripteurMajeur(any())).thenReturn(true);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_arbitrage_when_contrat_isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptant_or_isCompteEpargneAssureLibereOrEnCoursMDPRO() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(any())).thenReturn(false);
        when(arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(ARB_BLOCAGE_ETAT_COMPTE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_access_arbitrage_when_RM01_and_RM02_and_RM06_are_false() throws TechnicalException {
        prepareContratComplet("ID1", CodeSiloType.MDP, ResultParcoursEffectueDto.builder().parcoursEffectue(false).build());
        when(arbitrageFacade.isContratAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptantMDP(any())).thenReturn(true);
        when(arbitrageFacade.isCompteEpargneAssureLibereOrEnCoursMDPRO(any())).thenReturn(true);
        when(arbitrageFacade.isAssureOrSouscripteurMajeur(any())).thenReturn(true);
        when(arbitrageFacade.isMonoSupport(any())).thenReturn(false);

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.ARBITRAGE);
        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(NONE, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_not_access_rib_when_cb_is_empty() throws TechnicalException {
        when(gestionMandatFacade.startChangeCoordonneesBancaires()).thenReturn(new CoordonneesBancairesStartDto());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COORDONNEES_BANCAIRES);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(MODIFIERRIB_ACCESS_DENIED, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_access_rib_when_cb_is_not_empty() throws TechnicalException {
        when(gestionMandatFacade.startChangeCoordonneesBancaires())
                .thenReturn(new CoordonneesBancairesStartDto(Collections.singletonList(new CoordonneesBancairesDto()),
                        null));

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.COORDONNEES_BANCAIRES);
        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
    }

    /*
    @Test
    public void should_access_versement_when_exist_contrats_with_vif_possible() throws TechnicalException {
        when(versementFacade.startVersement()).thenReturn(new VersementStartDto(
                Arrays.asList(InfoVersementContratDto.builder().contrat(ContratParcours.builder().vifPossible(true).build()).build(),
                InfoVersementContratDto.builder().contrat(ContratParcours.builder().vifPossible(true).build()).build())));

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibiliteVersement();
        Assert.assertTrue(accessibiliteFonctionnalite.isAccessible());
    }
     */

    @Test
    public void should_not_access_versement_when__contract_is_empty() throws TechnicalException {
        when(versementFacade.startVersement()).thenReturn(new VersementStartDto());
        when(consulterPPFacade.consulterPersPhys(any())).thenReturn(PersonnePhysiqueConsult.builder()
                .pays("FRANCE")
                .build());

        AccesFonctionnaliteDto accessibiliteFonctionnalite = sut.checkAccessibility(FonctionnaliteType.VERSEMENT);
        Assert.assertFalse(accessibiliteFonctionnalite.isAccessible());
        Assert.assertEquals(VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT, getRaison(accessibiliteFonctionnalite));
    }

    @Test
    public void should_access_arretVersement() throws TechnicalException {
        when(arretVersementFacade.startArretVersement()).thenReturn(ArretVersementStartDto.builder()
                .infos(Collections.singletonList(InfoArretVersementContrat.builder()
                        .build()))
                .build());

        AccesFonctionnaliteDto result = sut.checkAccessibility(FonctionnaliteType.ARRET_VERSEMENT_PROGRAMME);
        Assert.assertTrue(result.isAccessible());
    }

    @Test
    public void should_not_access_arretVersement() throws TechnicalException {
        when(arretVersementFacade.startArretVersement()).thenReturn(ArretVersementStartDto.builder()
                .infos(Collections.emptyList())
                .build());

        AccesFonctionnaliteDto result = sut.checkAccessibility(FonctionnaliteType.ARRET_VERSEMENT_PROGRAMME);
        Assert.assertFalse(result.isAccessible());
        Assert.assertEquals(ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT, getRaison(result));

    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("123456");
        return userContext;
    }
}
