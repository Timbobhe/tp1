package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IQadFacade;
import fr.ag2rlamondiale.ecrs.dto.qad.QadRequestDto;
import fr.ag2rlamondiale.ecrs.dto.qad.QadResultDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class QadRestControllerTest {
    @Mock
    IQadFacade qadFacade;

    @InjectMocks
    QadRestController qadRestController;

    @Test
    public void should_get_QadQuestRep() throws TechnicalException {
        when(qadFacade.getQadQuestRep((Matchers.any()))).thenReturn(Collections.emptyList());

        assertNotNull(qadRestController.getQadQuestionReponses(new QadRequestDto()));
    }

    @Test
    public void should_get_QadProposition() throws TechnicalException {
        when(qadFacade.getTypesPropositionGrille((Matchers.any()))).thenReturn(Collections.emptyList());

        assertNotNull(qadRestController.getQadProposition(new QadResultDto()));
    }
}
