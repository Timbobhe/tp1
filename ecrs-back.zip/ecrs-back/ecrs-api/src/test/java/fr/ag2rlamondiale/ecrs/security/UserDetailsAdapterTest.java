package fr.ag2rlamondiale.ecrs.security;

import fr.ag2rlamondiale.metis.boot.security.dao.MetisBootCasUserDetailsService;
import fr.ag2rlamondiale.metis.boot.security.dao.UserDetailsImpl;
import org.jasig.cas.client.authentication.AttributePrincipalImpl;
import org.jasig.cas.client.validation.AssertionImpl;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;

import java.util.*;

import static org.junit.Assert.*;

public class UserDetailsAdapterTest {

    MetisBootCasUserDetailsService ecrsCasUserDetailsService = new MetisBootCasUserDetailsService(new String[]{"roles"}, new ApplicationRolesRetrieverMock());

    @Before
    public void setUp() throws Exception {
    }

    @Test
    public void test_creation_should_be_same() throws Exception {
        UserDetailsImpl userDetails = (UserDetailsImpl) ecrsCasUserDetailsService.loadUserDetails(cas3());
        UserDetailsAdapter uda = new UserDetailsAdapter(userDetails);

        assertSame(userDetails.getAuthorities(), uda.getAuthorities());
        assertSame(userDetails.getUserSn(), uda.getUserSn());
        assertSame(userDetails.getUserGivenName(), uda.getUserGivenName());
        assertSame(userDetails.getAttributesMap(), uda.getAttributesMap());
    }

    @Test(expected = NullPointerException.class)
    public void test_creation_should_thow_error_with_user_details_null() throws Exception {
        new UserDetailsAdapter(null);
    }


    private CasAssertionAuthenticationToken cas3() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        attributes.put("roles", Arrays.asList("EERE-Federation", "IMP-EERE-Salarie"));

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        attributes.put("fdiPerimeterName", "49505");
        attributes.put("seeAlso", "part2");
        attributes.put("businessIdMap", "{idEpargneRetraite=idEpargneRetraite}");
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }
}
