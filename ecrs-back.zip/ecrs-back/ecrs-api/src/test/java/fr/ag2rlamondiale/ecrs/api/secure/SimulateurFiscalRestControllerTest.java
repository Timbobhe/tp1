package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ISimulateurFiscalFacade;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class SimulateurFiscalRestControllerTest {

    @Mock
    ISimulateurFiscalFacade simulateurFiscalFacade;

    @InjectMocks
    @Spy
    SimulateurFiscalRestController simulateurFiscalRest;

    @Test
    public void startSimulateurFiscalTest() throws TechnicalException {
        simulateurFiscalRest.start();
        verify(simulateurFiscalRest, times(1)).start();

    }

    @Test
    public void should_calcul_disponible_fiscal() throws TechnicalException {
        simulateurFiscalRest.calculerDisponibleFiscal(new DemandeCalculEpargne());
        verify(simulateurFiscalRest, times(1)).calculerDisponibleFiscal(any());
    }
}
