package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.ModeActionEvtType;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.*;

import static java.time.temporal.ChronoUnit.DAYS;
import static org.junit.Assert.*;

public class EvenUtilsTest {

    @Test
    public void test_TypeEvenIsObligatoire() {
        TypeEvenementJson obli = new TypeEvenementJson();
        obli.setModeAction(ModeActionEvtType.OBLI);
        assertTrue(obli.isObligatoire());

        TypeEvenementJson facu = new TypeEvenementJson();
        facu.setModeAction(ModeActionEvtType.FACU);
        assertFalse(facu.isObligatoire());

        TypeEvenementJson info = new TypeEvenementJson();
        info.setModeAction(ModeActionEvtType.INFO);
        assertFalse(info.isObligatoire());

        TypeEvenementJson undefined = new TypeEvenementJson();
        undefined.setModeAction(null);
        assertFalse(info.isObligatoire());
    }

    @Test
    public void test_pasEncorePresenteAujourdhui_true() {
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(null).build());
        evens.add(EvenementJson.builder().dateFin(null).build());
        assertTrue(EvenUtils.pasEncorePresenteAujourdhui(evens));
        evens.clear();

        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(4, DAYS).truncatedTo(DAYS))).build());
        assertTrue(EvenUtils.pasEncorePresenteAujourdhui(evens));
        assertTrue(EvenUtils.pasEncorePresenteAujourdhui(Collections.emptyList()));
        assertTrue(EvenUtils.pasEncorePresenteAujourdhui(null));
    }

    @Test
    public void test_pasEncorePresenteAujourdhui_false() {
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(4, DAYS).truncatedTo(DAYS))).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now())).build());
        assertFalse(EvenUtils.pasEncorePresenteAujourdhui(evens));
        evens.clear();

        evens.add(EvenementJson.builder().dateFin(Date.from(Instant.now().minus(4, DAYS).truncatedTo(DAYS))).build());
        evens.add(EvenementJson.builder().dateFin(Date.from(Instant.now())).build());
        assertFalse(EvenUtils.pasEncorePresenteAujourdhui(evens));

    }

    @Test
    public void test_pasEncoreTraite() {
        assertTrue(EvenUtils.dejaTraite(evensTrai()));
        assertFalse(EvenUtils.dejaTraite(evensNonTrai()));
        assertFalse(EvenUtils.dejaTraite(null));
    }

    private Collection<EvenementJson> evensTrai() {
        Collection<EvenementJson> res = new ArrayList<>();
        res.add(EvenementJson.builder().etatTraitement(EtatTraitementType.ANNU).build());
        res.add(EvenementJson.builder().etatTraitement(null).build());
        res.add(EvenementJson.builder().etatTraitement(EtatTraitementType.TRAI).build());
        return res;
    }

    private Collection<EvenementJson> evensNonTrai() {
        Collection<EvenementJson> res = new ArrayList<>();
        res.add(EvenementJson.builder().etatTraitement(EtatTraitementType.ANNU).build());
        res.add(EvenementJson.builder().etatTraitement(null).build());
        return res;
    }

    @Test
    public void test_neDepassePasNombreMaxDeclenchements_true() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, null));
        typeEven.setNbDeclenchementsMaxPeriode(10);
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, null));
        
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(4, DAYS).truncatedTo(DAYS))).build());
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, evens));
        
        typeEven.setNbDeclenchementsMaxPeriode(1);
        assertFalse(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, evens));
    }

    @Test
    public void test_neDepassePasNombreMaxDeclenchements_true_sans_evens() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        List<EvenementJson> evens = new ArrayList<>();
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, evens));
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, null));
    }

    @Test
    public void test_neDepassePasNombreMaxDeclenchements_true_sans_delaiReactivation() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(null);
        List<EvenementJson> evens = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(i, DAYS).truncatedTo(DAYS)))
                    .build());
        }
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, evens));
        assertTrue(EvenUtils.neDepassePasNombreMaxDeclenchements(typeEven, null));
    }

    @Test
    public void test_respecteDelaiReactivation_false() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        assertTrue(EvenUtils.respecteDelaiReactivation(typeEven, null));
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        assertTrue(EvenUtils.respecteDelaiReactivation(typeEven, null));

        Collection<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(3, DAYS).truncatedTo(DAYS))).build());

        assertFalse(EvenUtils.respecteDelaiReactivation(typeEven, evens));
    }

    @Test
    public void test_getLastDate() {
        assertNull(EvenUtils.getLastDate(null));
        Collection<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("10/07/2019")).build());
        final Instant lastDate = EvenUtils.getLastDate(evens);
        assertInstantEquals("10/07/2019", lastDate);
    }

    private void assertInstantEquals(String expectedDate, Instant lastDate) {
        assertEquals(date(expectedDate).toInstant().truncatedTo(DAYS), lastDate.truncatedTo(DAYS));
    }

    static Date date(String date) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(date);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void test_getEvenementsSurNbjoursGlissants() {
        assertNull(EvenUtils.getEvenementsSurNbjoursGlissants(null, null));
        assertNull(EvenUtils.getEvenementsSurNbjoursGlissants(null, 10));
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(3, DAYS))).build());
        final List<EvenementJson> results = EvenUtils.getEvenementsSurNbjoursGlissants(evens, 10);
        assertEquals(1, results.size());
    }

    @Test
    public void test_evenementDeclencheDepuis() {
        assertTrue(EvenUtils.evenementDeclencheDepuis(null, null));
        assertTrue(EvenUtils.evenementDeclencheDepuis(null, 1));
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/07/2019")).build());
        assertTrue(EvenUtils.evenementDeclencheDepuis(evens, 1));
        evens.clear();
        evens.add(EvenementJson.builder().dateDebut(date("01/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/07/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(3, DAYS))).build());
    }
}
