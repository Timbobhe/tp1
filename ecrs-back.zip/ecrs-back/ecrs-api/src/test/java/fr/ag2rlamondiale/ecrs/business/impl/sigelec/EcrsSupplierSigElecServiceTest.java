package fr.ag2rlamondiale.ecrs.business.impl.sigelec;

import fr.ag2rlamondiale.ecrs.MockSupplierLibService;
import fr.ag2rlamondiale.ecrs.business.domain.sigelec.DemandeCreationsigElecArbitrage;
import fr.ag2rlamondiale.trm.business.ISupplierSigElecService;
import fr.ag2rlamondiale.trm.csv.CodesAssureurMapper;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EcrsSupplierSigElecServiceTest {

    @InjectMocks
    EcrsSupplierSigElecService ecrsSupplierSigElecService;

    @Spy
    CodesAssureurMapper codesAssureurMapper;

    @Spy
    MockSupplierLibService supplierLibService;

    @Mock
    UserContextHolder userContextHolder;

    @Test
    public void getProfile() {
        // Given
        DemandeCreationSigElec<? extends IContrat> demande = new DemandeCreationsigElecArbitrage();
        demande.setCodeAssureur("LM");

        // When
        final String profile = ecrsSupplierSigElecService.getProfile(demande);

        // Then
        assertEquals("A1573_ERE_LM", profile);
    }


    @Test
    public void getProfile_CodeAssureurNull() {
        // Given
        DemandeCreationSigElec<? extends IContrat> demande = new DemandeCreationSigElec<>();
        demande.setCodeAssureur(null);

        // When
        final String profile = ecrsSupplierSigElecService.getProfile(demande);

        // Then
        assertNull(profile);
    }


    @Test
    public void getUrlRetour() {
        final String urlArbi = ecrsSupplierSigElecService.getUrlRetour(OperationType.ARBI, ISupplierSigElecService.SUCCES, false, "RA1234", null);
        assertEquals(supplierLibService.getUrlFront() + "/#/modification-gestion-financiere/signature/terminee", urlArbi);
    }

    @Test
    public void getUrlRetour_partenaire() {
        when(userContextHolder.get()).thenReturn(newUserContext(true));

        final String urlArbi = ecrsSupplierSigElecService.getUrlRetour(OperationType.ARBI, ISupplierSigElecService.SUCCES, true, "RA1234", null);
        assertEquals("http://nie/def_int_ep/ep/aca/gestion_signature.do?contrat=RA1234&parcours=arbitrage&action=succes", urlArbi);
    }

    private UserContext newUserContext(boolean partenaire) {
        UserContext u = new UserContext();
        if (partenaire) {
            Partenaire p = new Partenaire();
            u.setPartenaire(p);
            p.setCodePartenaire(Partenaire.CODE_NIE);
            p.setBaseUrl("http://nie");
        }

        return u;
    }

    @Test
    public void buildFrameCallbackUrl() {
        final String urlArbi = EcrsSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.ARBI, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlArbi);
        System.out.println(urlArbi);

        final String urlBia = EcrsSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.EBIA, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlBia);
        System.out.println(urlBia);

        final String urlCbf = EcrsSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.CBF, ISupplierSigElecService.SUCCES, "RA1234");
        assertNotNull(urlCbf);
        System.out.println(urlCbf);

        try {
            EcrsSupplierSigElecService.buildFrameCallbackUrl("http://nie", OperationType.LIQR, ISupplierSigElecService.SUCCES, "RA1234");
            fail("Parcours LIQR non pr\u00E9vue en IFRAME pour l'instant (08/04/21)");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void inferActionFromStatus() {
        assertEquals("echec", EcrsSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.ECHEC));
        assertEquals("annulation", EcrsSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.ANNULATION));
        assertEquals("succes", EcrsSupplierSigElecService.inferActionFromStatus(ISupplierSigElecService.SUCCES));
    }

    @Test
    public void getUrl() {
        final String urlArbi = EcrsSupplierSigElecService.getUrl(OperationType.ARBI, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/modification-gestion-financiere/signature/terminee", urlArbi);

        final String urlVr = EcrsSupplierSigElecService.getUrl(OperationType.VR, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/versement/signature/terminee", urlVr);
        final String urlVrli = EcrsSupplierSigElecService.getUrl(OperationType.VRLI, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/versement/signature/terminee", urlVrli);
        final String urlVrPg = EcrsSupplierSigElecService.getUrl(OperationType.VRPG, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/versement/signature/terminee", urlVrPg);
        final String urlArretVrPg = EcrsSupplierSigElecService.getUrl(OperationType.VRPG, ISupplierSigElecService.SUCCES, "arret-versement");
        assertEquals("/#/arret-versement/signature/terminee", urlArretVrPg);

        final String urlCbf = EcrsSupplierSigElecService.getUrl(OperationType.CBF, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/clause-beneficiaire/signature/terminee", urlCbf);

        final String urlRiba = EcrsSupplierSigElecService.getUrl(OperationType.RIBA, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/coordonnees-bancaires/signature/terminee", urlRiba);

        final String urlEbia = EcrsSupplierSigElecService.getUrl(OperationType.EBIA, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/bulletin-affiliation/signature/terminee", urlEbia);

        final String urlLiqr = EcrsSupplierSigElecService.getUrl(OperationType.LIQR, ISupplierSigElecService.SUCCES, null);
        assertEquals("/#/liquidation/signature/terminee", urlLiqr);
    }
}
