package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.ecrs.mapping.ClientMapper;
import fr.ag2rlamondiale.ecrs.mapping.UtilisateurMapper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class UtilisateurRestControllerTest {

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    ClientMapper clientMapper;

    @Mock
    UtilisateurMapper utilisateurMapper;

    @InjectMocks
    @Spy
    UtilisateurRestController utilisateurRest;

    @Test
    public void getClientTest() throws CommonException {
        utilisateurRest.getClient();
        verify(utilisateurRest, times(1)).getClient();
    }

    @Test
    public void getPersonnePhysiqueTest() throws CommonException {
        utilisateurRest.getPersonnePhysiqueInfos();
        verify(utilisateurRest, times(1)).getPersonnePhysiqueInfos();
    }


}
