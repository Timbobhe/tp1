package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverEurosPourcentERETest {

    @InjectMocks
    ArbitrageQuestionResolverEurosPourcentERE arbitrageQuestionResolverEurosPourcentERE;

    @Mock
    IContratFacade contratFacade;


    public ContratHeader prepare(List<CompartimentType> compartimentTypes, Set<PartType> parts) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(false, false, false, compartimentTypes, parts);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set());
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);

        assertTrue(arbitrageQuestionResolverEurosPourcentERE.accept(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte));
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireSansPPouPS_repartitionStock_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_EUROS)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE)));
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireSansPPouPS_C1_repartitionStock_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C1, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_EUROS)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE)));
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireSansPPouPS_repartitionFlux_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE);
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireSansPPouPS_repartitionFluxStock_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE);
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireSansPPouPS_repartitionStock_total() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE);
    }

    @Test
    public void test_unSeulCompartiment_PartObligatoireAvecPPetPS_repartitionStock_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS, PartType.PP));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE);
    }

    @Test
    public void test_tousCompartiments_PartObligatoireAvecPPetPS_repartitionStock_partiel() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), Sets.set(PartType.PS, PartType.PP));
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);
        contexte.setResponseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
        contexte.setResponseTotalPartielType(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageEurosPourcentageType, ?> resolved = arbitrageQuestionResolverEurosPourcentERE.resolve(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_EUROSPOURCENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageEurosPourcentageType.ARBITRAGE_POURCENTAGE);
    }


    public void setCompartiment(ContratHeader contratHeader, CompartimentType compartimentType, ArbitrageContexteDto contexte) {
        contratHeader.getCompartiments().stream()
                .filter(compartiment -> compartiment.getType().equals(compartimentType))
                .findFirst()
                .ifPresent(compartiment -> contexte.setCompartimentSelectionne(compartiment.getCompartimentId()));
    }


    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, boolean arbitrageMixteUniquement, List<CompartimentType> compartimentTypes, Set<PartType> parts) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.setPartsType(parts);

        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment.builder().type(compartimentType).build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);

        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setIndicTypeArbitrageAutorise(!arbitrageMixteUniquement);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }


}
