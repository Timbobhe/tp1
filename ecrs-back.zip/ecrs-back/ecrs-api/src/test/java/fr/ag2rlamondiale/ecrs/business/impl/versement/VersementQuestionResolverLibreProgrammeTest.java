package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.ResponseDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinRequest;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GrilleProfilInvDto;
import fr.ag2rlamondiale.ecrs.dto.versement.*;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_ODF;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VersementQuestionResolverLibreProgrammeTest {

    @InjectMocks
    VersementQuestionResolverLibreProgramme versementQuestionResolverLibreProgramme;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IEcheancierFacade echeancierFacade;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IBlocageFacade blocageFacade;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Mock
    private IStructureInvFacade structureInvFacade;

    @Mock
    VersementGestionMontantService versementGestionMontantService;

    private Integer delaiTeletransmission = 15;

    @Before
    public void setUp() throws Exception {
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
        when(versementGestionMontantService.retrieveMontantsPossibles(any(), any())).thenReturn(MontantPossibleDto.builder()
                                                                                                        .minMontantPossible(300)
                                                                                                        .maxMontantPossible(99999)
                                                                                                        .build());

        assertNotNull(versementGestionMontantService.retrieveMontantsPossibles(new ContratHeader(), TypeVersement.VL));
    }

    public ContratHeader prepare(boolean pacte, boolean mdpro, List<CompartimentType> compartimentTypes, boolean demandeWkfEnCours, boolean avecEcheancier) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());

        when(versementGestionMontantService.retrieveMontantsPossibles(any(), eq(TypeVersement.VL))).thenReturn(MontantPossibleDto.builder()
                                                                                                                       .minMontantPossible(300)
                                                                                                                       .maxMontantPossible(99999)
                                                                                                                       .build());
        when(versementGestionMontantService.retrieveMontantsPossibles(any(), eq(TypeVersement.PO))).thenReturn(MontantPossibleDto.builder()
                                                                                                                       .minMontantPossible(50)
                                                                                                                       .maxMontantPossible(500000)
                                                                                                                       .build());

        assertNotNull(versementGestionMontantService.retrieveMontantsPossibles(new ContratHeader(), TypeVersement.VL));

        ReflectionTestUtils.setField(versementQuestionResolverLibreProgramme, "delaiTeletransmission", delaiTeletransmission);
        final ContratComplet contratComplet = createContratComplet(pacte, mdpro, compartimentTypes);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        ProduitJson produitJson = new ProduitJson();
        produitJson.setLibelleFiscalite("MADELIN");
        when(paramConsoleFacade.findProduitMdpro(anyString(), anyString())).thenReturn(produitJson);
        when(paramConsoleFacade.getParametre(TYPE_ODF, "ODF", Annee.Courante))
                .thenReturn(Optional.of(ParametreDto.builder()
                                                .valeur1("8000")
                                                .build()));

        UserContext userContext = new UserContext();
        userContext.setIdGdi("IDGDI");
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
        when(userContextHolder.get()).thenReturn(userContext);
        when(workflowFacade.hasDemandeEncours(anyString(), any(DemandeWorkflowType.class))).thenReturn(demandeWkfEnCours);

        Echeancier echeancier = getEcheancier(avecEcheancier);
        when(echeancierFacade.getProchainEcheancier(any())).thenReturn(echeancier);

        Map<CompartimentId, CompteGeneralesERE> compteGeneralesEreParCompartiment = new ConcurrentHashMap<>();
        compteGeneralesEreParCompartiment.put(CompartimentId.builder()
                                                      .idAssure("C1-1")
                                                      .compartimentType(CompartimentType.C1)
                                                      .build(), createCompteGenerale());
        contratComplet.setCompteGeneralesEreParCompartiment(compteGeneralesEreParCompartiment);
        contratComplet.setCompteGeneralesERE(createCompteGenerale());

        when(contratFacade.recupererContratComplet(any(ContratHeader.class))).thenReturn(contratComplet);

        GestionFinanciereDto gestionFinanciereDto = new GestionFinanciereDto();
        gestionFinanciereDto.setGrillesProfilsNiveau1(Collections.singletonList(new GrilleProfilInvDto()));

        when(structureInvFacade.getGestionFinanciere(any(Compartiment.class), any(GestionFinRequest.class))).thenReturn(gestionFinanciereDto);
        return contratComplet.getContratHeader();
    }

    private CompteGeneralesERE createCompteGenerale() {
        CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setIdAssure("1470947");
        compteGeneralesERE.setEtatAssure("Affili\u00E9 en cours sans BIA");
        compteGeneralesERE.setCodeEtat("A");
        compteGeneralesERE.setEtat("En cours");
        compteGeneralesERE.setNumeroMatricule("6005095");
        compteGeneralesERE.setIdPersonne("P4167507");
        compteGeneralesERE.setLibelleContributionInvestissementSilo("Versements Volontaires non d\u00E9ductibles");

        ContributionInv contributionInv = new ContributionInv();
        contributionInv.setType(ContributionType.VERSEMENTS_VOLONTAIRES_DEDUCTIBLES);
        GrilleInv grilleInv = new GrilleInv();
        grilleInv.setProfils(new ArrayList<>());
        grilleInv.setNom("G_E_SM_IBMPERO_EQUILIBRE");
        grilleInv.setId("14627");
        grilleInv.setIndicateurTauxDerogeable(false);
        contributionInv.setGrilles(Collections.singletonList(grilleInv));
        contributionInv.setProfils(new ArrayList<>());

        StructInv structInv = new StructInv();
        structInv.addContributions(Collections.singletonList(contributionInv));
        compteGeneralesERE.setStructInv(structInv);

        return compteGeneralesERE;
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), false, false);
        assertTrue(versementQuestionResolverLibreProgramme.accept(QuestionType.VERSEMENT_CHOIX_MODE_TYPE,
                                                                  VersementContexteDto.builder()
                                                                          .contratSelectionne(contratHeader.getContratId())
                                                                          .build()));
    }

    @Test
    public void test_MDPRO() throws Exception {
        final ContratHeader contratHeader = prepare(false, true, Arrays.asList(CompartimentType.C1, CompartimentType.C4), false, false);
        final QuestionResponsesDto<ModeVersementDto, ?> resolved = versementQuestionResolverLibreProgramme.resolve(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, VersementContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .build());

        assertEquals(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 0);
        assertFalse(resolved.isShow());
        assertSame(resolved.getDefaultValue().getValue().getModeType(), VERSEMENT_LIBRE);
    }

    @Test
    public void test_ERE_DemandeWkfEnCours() throws Exception {
        final ContratHeader contratHeader = prepare(false, false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, false);
        final QuestionResponsesDto<ModeVersementDto, ?> resolved = versementQuestionResolverLibreProgramme.resolve(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, VersementContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .compartimentSelectionne(CompartimentId.builder()
                                                 .idAssure("C1-1")
                                                 .compartimentType(CompartimentType.C1)
                                                 .build())
                .build());

        assertEquals(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions()
                           .stream()
                           .anyMatch(choix -> choix.getValue() != null && choix.getValue()
                                                                               .getModeType() == VERSEMENT_LIBRE));
        assertTrue(resolved.getPropositions()
                           .stream().anyMatch(choix -> choix.getValue() == null && choix.isDisabled()));
    }

    @Test
    public void test_ERE_SansDemandeWkfEnCours_SansEcheancier() throws Exception {
        final ContratHeader contratHeader = prepare(false, false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), false, false);
        VersementContexteDto versementContexteDto = VersementContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .compartimentSelectionne(contratHeader.getCompartiments().get(0).getCompartimentId())
                .build();
        final QuestionResponsesDto<ModeVersementDto, ?> resolved = versementQuestionResolverLibreProgramme.resolve(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions()
                           .stream().anyMatch(choix -> choix.getValue().getModeType() == VERSEMENT_LIBRE));
        assertTrue(resolved.getPropositions()
                           .stream().anyMatch(choix -> choix.getValue().getModeType() == VERSEMENT_PROGRAMME));
    }

    @Test
    public void test_ERE_SansDemandeWkfEnCours_AvecEcheancier() throws Exception {
        final ContratHeader contratHeader = prepare(false, false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), false, true);
        VersementContexteDto versementContexteDto = VersementContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .compartimentSelectionne(contratHeader.getCompartiments().get(0).getCompartimentId())
                .build();
        final QuestionResponsesDto<ModeVersementDto, ?> resolved = versementQuestionResolverLibreProgramme.resolve(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_MODE_TYPE, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions()
                           .stream().anyMatch(choix -> choix.getValue().getModeType() == VERSEMENT_LIBRE));

        Optional<ResponseDto<ModeVersementDto>> reponse = resolved.getPropositions()
                .stream().filter(choix -> choix.getValue().getModeType() == VERSEMENT_PROGRAMME).findFirst();
        ModeVersementDto modeVersement = reponse.get().getValue();

        assertEquals(VERSEMENT_PROGRAMME, modeVersement.getModeType());
        assertEquals(DetailsVersementEREType.DEFAUT_PO.getMinMontantPossible(), modeVersement.getMinMontantPossible());
        assertEquals(DetailsVersementEREType.DEFAUT_PO.getMaxMontantPossible(), modeVersement.getMaxMontantPossible());
        assertEquals(1, (int) modeVersement.getVersementProgramme().getMontantActuel());
        assertEquals(FrequenceVirementType.MENSUELLE, modeVersement.getVersementProgramme().getFrequence());
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, List<CompartimentType> compartimentTypes) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.setTypeContrat("");
        contratHeader.setNumGenContrat("RG02");
        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment.builder().type(compartimentType).build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        return contratComplet;
    }

    private Echeancier getEcheancier(boolean avecEcheancier) {
        if (avecEcheancier) {
            Echeancier echeancier = new Echeancier();
            echeancier.setMontant(BigDecimal.ONE);
            echeancier.setCodeFractionnement("M");

            Prelevement prelevement = new Prelevement();
            prelevement.setDatePrelevement(DateUtils.createDate(4, 2, 2050));
            prelevement.setCodeSituationPrelevement("TRANS");
            echeancier.setPrelevements(Collections.singletonList(prelevement));

            return echeancier;
        }
        return null;
    }
}
