package fr.ag2rlamondiale.ecrs.api.unsecure;

import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseInternalDto;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserResponseInternalMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UserIdentityProviderRestControllerTest {

    @InjectMocks
    UserIdentityProviderRestController sut;

    @Mock
    IUserIdentityProviderFacade userIdentityProviderFacade;

    @Spy
    UserResponseInternalMapper mapper;

    @Test
    public void userIdentityExternalTest(){
        Mockito.when(userIdentityProviderFacade.identiteExterne(Mockito.any(UserRequestDto.class)))
                .thenReturn(new UserResponseExternalDto());
        UserResponseExternalDto dto = sut.userIdentityExternal(new UserRequestDto());
        Assert.assertNotNull(dto);

    }

    @Test
    public void userIdentityInternalTest(){
        Mockito.when(userIdentityProviderFacade.identiteInterneDepuisFederation(Mockito.any(UserRequestDto.class),
                Mockito.any(UserRequestOptionsDto.class)))
                .thenReturn(new UserResponseInternal());
        Mockito.when(mapper.map(Mockito.any(UserResponseInternal.class)))
                .thenReturn(new UserResponseInternalDto());
        UserResponseInternalDto dto = sut.userIdentityInternal(new UserRequestDto());
        Assert.assertNotNull(dto);

    }
}
