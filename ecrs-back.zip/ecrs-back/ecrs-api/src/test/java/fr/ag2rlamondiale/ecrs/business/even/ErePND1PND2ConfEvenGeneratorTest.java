package fr.ag2rlamondiale.ecrs.business.even;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBiaFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demande;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.ModeActionEvtType;
import fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.EXC;
import static fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre.INC;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class ErePND1PND2ConfEvenGeneratorTest {
    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Mock
    private UserContextHolder userContextHolder;

    @InjectMocks
    private EreConfEvenGenerator ereConfEvenGenerator;

    @InjectMocks
    private ErePND1EvenGenerator erePND1EvenGenerator;

    @InjectMocks
    private ErePND3EvenGenerator erePND3EvenGenerator;

    @Mock
    IConsulterPersonneClient consulterPersonneClient;

    @Mock
    private IWorkflowFacade workflowClient;
    
    @Mock
    private IBiaFacade biaFacade;

    @Before
    public void setUp() throws WorkflowException {
        MockitoAnnotations.initMocks(this);

        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA));
//        when(workflowClient.consulterDerniereDemandeEnCours(Matchers.any(RechDemFront.class),
//                Matchers.any(DemandeWorkflowType.class))).thenReturn(null);
    }

    @Test
    public void ereConfEvaluerEvenementReturnsTrueWhenDonneePersoNonConfirmeTest()
            throws TechnicalException {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setDonneesPersonnellesConfirmees(Boolean.FALSE);
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(pp);
        assertTrue(ereConfEvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setDonneesPersonnellesConfirmees(Boolean.TRUE);
        assertFalse(ereConfEvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setDonneesPersonnellesConfirmees(Boolean.FALSE);
        when(workflowClient.consulterDerniereDemandeEnCours(Matchers.any(RechDemFront.class),
                Matchers.any(DemandeWorkflowType.class))).thenReturn(new Demande());
        when(workflowClient.hasDemandeMdpEncours(Matchers.anyString())).thenReturn(true);
        assertFalse(ereConfEvenGenerator.evaluerEvenement(MOCKDATA));
    }

    @Test
    public void ereConfEvaluerEvenementFailTest() throws TechnicalException {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setDonneesPersonnellesConfirmees(Boolean.FALSE);
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenThrow(new WorkflowException());
        assertFalse(ereConfEvenGenerator.evaluerEvenement(MOCKDATA));
    }

    @Test
    public void erePnd1EvaluerEvenementReturnsTrueWhenPndDefinitifFalseAndNpaiTrueTest()
            throws TechnicalException {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setPndDefinitif(Boolean.FALSE);
        pp.setNpai(Boolean.TRUE);
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(pp);
        assertTrue(erePND1EvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setNpai(Boolean.FALSE);
        assertFalse(erePND1EvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setNpai(Boolean.TRUE);
        pp.setPndDefinitif(Boolean.TRUE);
        assertFalse(erePND1EvenGenerator.evaluerEvenement(MOCKDATA));

        when(workflowClient.consulterDerniereDemandeEnCours(Matchers.any(RechDemFront.class),
                Matchers.any(DemandeWorkflowType.class))).thenReturn(new Demande());
        
        when(workflowClient.hasDemandeMdpEncours(Matchers.anyString())).thenReturn(true);
        
        pp.setNpai(Boolean.TRUE);
        pp.setPndDefinitif(Boolean.FALSE);
        assertFalse(erePND1EvenGenerator.evaluerEvenement(MOCKDATA));
        assertEquals("PND1", erePND1EvenGenerator.getTypePND());
    }

    @Test
    public void erePnd1EvaluerEvenementReturnsFailTest() throws TechnicalException {
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenThrow(new TechnicalException());
        assertFalse(erePND1EvenGenerator.evaluerEvenement(MOCKDATA));
    }

    @Test
    public void erePnd3EvaluerEvenementReturnsTrueWhenPndDefinitifTrueAndNpaiTrueTest()
            throws TechnicalException {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setPndDefinitif(Boolean.TRUE);
        pp.setNpai(Boolean.TRUE);
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(pp);
        assertTrue(erePND3EvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setNpai(Boolean.FALSE);
        assertFalse(erePND3EvenGenerator.evaluerEvenement(MOCKDATA));

        pp.setNpai(Boolean.TRUE);
        pp.setPndDefinitif(Boolean.TRUE);
        assertTrue(erePND3EvenGenerator.evaluerEvenement(MOCKDATA));

        when(workflowClient.consulterDerniereDemandeEnCours(Matchers.any(RechDemFront.class),
                Matchers.any(DemandeWorkflowType.class))).thenReturn(new Demande());
        pp.setNpai(Boolean.TRUE);
        pp.setPndDefinitif(Boolean.FALSE);
        assertFalse(erePND3EvenGenerator.evaluerEvenement(MOCKDATA));
        assertEquals("PND3", erePND3EvenGenerator.getTypePND());

    }

    @Test
    public void GenerateNextEven() throws TechnicalException {
        TriggeringResult result = new TriggeringResult();
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        pp.setDonneesPersonnellesConfirmees(Boolean.FALSE);
        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenReturn(pp);
        assertNotNull(ereConfEvenGenerator.generateNextEven(result));

        Mockito.when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenThrow(new TechnicalException());
        assertNull(ereConfEvenGenerator.generateNextEven(result));
    }

    @Test
    public void testDeclenchement() throws TechnicalException {
        TriggeringResults results = new TriggeringResults();
        // Cas 1
        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.IDGDI, "z3ghy4"));
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setPerimetreEvenements(perimetres);
        ereConfEvenGenerator.testDeclenchement("z3ghy4", "P1", typeEven, null, null, null);

        // Cas 2
        perimetres.add(perimetreEven(EXC, "ERE_CONF", PerimetreType.TOUT, "*"));
        perimetres.add(perimetreEven(INC, "ERE_CONF", PerimetreType.IDGDI, "c5dfdf"));
        String idGdi = "c5dfdf";
        String numPersonne = "P4050279";
        ereConfEvenGenerator.testDeclenchement(idGdi, numPersonne, typeEven, null, null, results);

        // Cas 3
        typeEven.setModeAction(ModeActionEvtType.INFO);
        ereConfEvenGenerator.testDeclenchement(idGdi, numPersonne, typeEven, null,
                Arrays.asList(createEvenementJson(typeEven, null)), results);

        // Cas 4
        typeEven.setModeAction(ModeActionEvtType.OBLI);
        ereConfEvenGenerator.testDeclenchement(idGdi, numPersonne, typeEven, null,
                Arrays.asList(createEvenementJson(typeEven, EtatTraitementType.TRAI)), results);

        // Cas 5
        typeEven.setNbDeclenchementsMaxPeriode(0);
        ereConfEvenGenerator.testDeclenchement(idGdi, numPersonne, typeEven, null,
                Arrays.asList(createEvenementJson(typeEven, EtatTraitementType.ANNU)), results);
        
        // Cas 6
        typeEven.setNbDeclenchementsMaxPeriode(null);
        typeEven.setDelaiAvantReactivation(5);
        ereConfEvenGenerator.testDeclenchement(idGdi, numPersonne, typeEven, null,
                Arrays.asList(createEvenementJson(typeEven, EtatTraitementType.ANNU)), results);

        assertNotNull(typeEven);
    }

    private EvenementJson createEvenementJson(TypeEvenementJson typeEven, EtatTraitementType etat) {
        EvenementJson even = new EvenementJson();
        even.setEtatTraitement(etat);
        even.setTypeEvenement(typeEven);
        even.setDateDebut(new Date());
        return even;
    }

    private UserContext createUserContext(String numPP) {
        ErePND1PND2ConfEvenGeneratorTest.MockUserContext userContext =
                new ErePND1PND2ConfEvenGeneratorTest.MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setNumeroPersonneMdpro(numPP);
        return userContext;
    }

    public static class MockUserContext extends UserContext {
        private static final long serialVersionUID = 1L;
        private String numeroPersonneEre;
        private String numeroPersonneMdpro;

        @Override
        public String getNumeroPersonneEre() {
            return numeroPersonneEre;
        }

        public void setNumeroPersonneEre(String numeroPersonneEre) {
            this.numeroPersonneEre = numeroPersonneEre;
        }

        @Override
        public String getNumeroPersonneMdpro() {
            return numeroPersonneMdpro;
        }

        public void setNumeroPersonneMdpro(String numeroPersonneMdpro) {
            this.numeroPersonneMdpro = numeroPersonneMdpro;
        }
    }

    private PerimetreEvenementJson perimetreEven(OperationPerimetre operationPerimetre,
                                                 String codeEvenement, PerimetreType typePerimetre, String valeurPerimetre) {
        PerimetreEvenementJson p = new PerimetreEvenementJson();
        p.setOperationPerimetre(operationPerimetre);
        p.setCodeEvenement(codeEvenement);
        p.setTypePerimetre(typePerimetre);
        p.setValeurPerimetre(valeurPerimetre);
        return p;
    }
}
