package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.mapping.parametre.ParametreMapper;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_PASS;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SimulateurFiscalCalculPerpTest {

    @InjectMocks
    SimulateurFiscalCalculPerp simulateurFiscalCalculPerp;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Mock
    private ParametreMapper parametreMapper;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    IOperationFacade operationFacade;

    @Spy
    CalculDisponibleCommand calculDispoFiscalCommand;

    @Spy
    CalculVersementsComplementairesCommand calculVersComplCommand;

    @Spy
    CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Spy
    CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Spy
    CalculEconomieFiscaleCommand calculGainFiscalCommand;

    @Test
    public void test_calcul_disponible_fiscal() throws Exception {
        // Given
//        DemandeCalculEpargne(cotisationsBrutes=null, cotisationsCET=null, tmi=0.45, versementLibre1=null, versementLibre2=null, year=0, contrat=ContratId(codeSilo=MDP, nomContrat=RA149894488000, idAdherente=null, idContractante=null, idCollege=null), abondement=0, revenuImposable=145000)
//
//                - totalCotisationsEtVersements = 0 // operationFacade.getOperationsCotisationsEtVersementsPERP
//                - mntTotalAnnCotisPeriodiques = 0 // contratGeneral.getMontantAnneeTTC()
//                - vifBrutsAnneeFiscale = 0 // operationFacade.getOperationsCotisationsEtVersementsPERP

        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();

        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.MDP)
                .build();
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(0.45));
        demandeCalcul.setAbondement(BigDecimal.valueOf(0));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(145000));
        demandeCalcul.setContrat(contratId);
        ContratHeader contratHeader = createContratHeader("id", null, CodeSiloType.MDP);

        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));
        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("PERP", new BigDecimal(0)));
        when(operationFacade.getOperationsCotisationsEtVersementsSimulateurs(any(), any(), any(), any())).thenReturn(new ArrayList<>(0));

        // When
        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalCalculPerp.calculerDisponibleFiscal(demandeCalcul);

        // Then
        // ResultatCalculEpargne(montantEpargne=6525.0000, partEffort=7975.0000, partGain=6525.0000, disponibleFiscal=14500.0, plafondVersement=14500.0, versementsDeductibles=0.00, dejaVerse=0.00, resteAverser=14500.00)
        assertEquals(new BigDecimal("6525.000"), resultatCalculEpargne.getMontantEpargne());
        assertEquals(new BigDecimal("7975.000"), resultatCalculEpargne.getPartEffort());
        assertEquals(new BigDecimal("6525.000"), resultatCalculEpargne.getPartGain());
        assertEquals(new BigDecimal("14500.0"), resultatCalculEpargne.getDisponibleFiscal());
        assertEquals(new BigDecimal("14500.0"), resultatCalculEpargne.getPlafondVersement());
        assertEquals(new BigDecimal("14500.0"), resultatCalculEpargne.getResteAverser());

    }


    private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
        contrat.setCompartiments(Collections.singletonList(c1));
        return contrat;
    }

    private ContratComplet createContratComplet(String codeCadreFiscal, BigDecimal montantAnneeTTC) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        Compartiment compartiment = new Compartiment();
        compartiment.setContratHeader(contratHeader);
        compartiment.setType(CompartimentType.C1);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setCompartiments(Collections.singletonList(compartiment));

        CompteEncours compteEncours = buildCompteEncours(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto1 = new OccurStructInvDto();
        SupportInvDto supportInvDto = new SupportInvDto();
        supportInvDto.setIdSupportInv("13132");
        occurStructInvDto1.setSupportInv(supportInvDto);
        occurStructInvDto1.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto2 = new OccurStructInvDto();
        occurStructInvDto2.setSupportInv(supportInvDto);
        occurStructInvDto2.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        List<OccurStructInvDto> occurStructInvDtos = new ArrayList<>();
        occurStructInvDtos.add(occurStructInvDto1);
        occurStructInvDtos.add(occurStructInvDto2);
        compteEncours.setOccurStructInvList(occurStructInvDtos);

        contratComplet.setEncours(new Memoizer<>(() -> compteEncours));

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("P12324");
        contratGeneral.setCodeCadreFiscal(codeCadreFiscal);
        contratGeneral.setMontantAnneePrimeTTC(montantAnneeTTC);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();


        contratGeneral.setOptContratEpargne(optContratEpargne);

        Map<CompartimentId, Memoizer<Encours>> encoursParCompartiment = new ConcurrentHashMap<>();
        encoursParCompartiment.put(getCompartimentId(), new Memoizer<>(() -> buildCompteEncours(BigDecimal.valueOf(34))));
        contratComplet.setEncoursParCompartiment(encoursParCompartiment);

        return contratComplet;
    }

    private CompteEncours buildCompteEncours(BigDecimal montant) {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontantEncours(montant);
        compteEncours.setEncoursEnErreur(false);
        return compteEncours;
    }

    private CompartimentId getCompartimentId() {
        CompartimentId compartimentId = new CompartimentId();
        compartimentId.setCompartimentType(CompartimentType.C1);
        compartimentId.setIdAssure("IDASSURE");
        compartimentId.setNomContrat("RG152289321");
        return compartimentId;
    }
}
