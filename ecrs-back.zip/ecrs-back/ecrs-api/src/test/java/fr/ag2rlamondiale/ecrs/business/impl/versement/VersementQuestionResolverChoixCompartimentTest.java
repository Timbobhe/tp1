package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IParcoursSimplifieFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.business.domain.structinv.SupportsInvNiveau1;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;
import fr.ag2rlamondiale.trm.domain.structinv.*;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VersementQuestionResolverChoixCompartimentTest {

    @InjectMocks
    VersementQuestionResolverChoixCompartiment versementQuestionResolverChoixCompartiment;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IStructureInvFacade structureInvFacade;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    RequestContextHolder requestContextHolder;

    @InjectMocks
    ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    ContratVifHelper contratVifHelper;

    @Mock
    IParcoursSimplifieFacade parcoursSimplifieFacade;

    public ContratHeader prepare(boolean pacte, List<CompartimentType> compartimentTypes, boolean gestionFinanciereDifferentePossible, int montantEncours, boolean isVifPossible) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(versementQuestionResolverChoixCompartiment, "contratParcoursMapper", contratParcoursMapper);
        final ContratComplet contratComplet = createContratComplet(pacte, false, gestionFinanciereDifferentePossible, compartimentTypes);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(calculerEncoursContratFacade.getEncoursDto(any(ContratHeader.class))).thenReturn(buildCompteEncours(montantEncours));
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(montantEncours));
        when(structureInvFacade.getGrillesProfilsPremierNiveau(any(Compartiment.class))).thenReturn(buildStructInv(contratComplet.getContratHeader()));
        when(contratVifHelper.isVifPossible(any(ContratComplet.class), any(CompartimentId.class))).thenReturn(isVifPossible);
        when(requestContextHolder.getCompartiment()).thenReturn(null);
        when(requestContextHolder.getContrat()).thenReturn(null);
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, 10, true);
        assertTrue(versementQuestionResolverChoixCompartiment.accept(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT,
                VersementContexteDto.builder().contratSelectionne(contratHeader.getContratId()).build()));
    }

    @Test
    public void test_nonPacte() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, 10, true);
        VersementContexteDto ctx = new VersementContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolved = versementQuestionResolverChoixCompartiment.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 0);
        assertFalse(resolved.isShow());
    }

    @Test
    public void test_Pacte_ContratBloque() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, 10, false);
        VersementContexteDto ctx = new VersementContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolved = versementQuestionResolverChoixCompartiment.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getData().isContratBloque());
        assertFalse(resolved.isShow());
    }

    @Test
    public void test_Pacte_PlusieursCompartiments() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, 10, true);
        VersementContexteDto ctx = new VersementContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolved = versementQuestionResolverChoixCompartiment.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertFalse(resolved.getData().isContratBloque());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getCompartiment().isDeductible() && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C1)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> !choix.getValue().getCompartiment().isDeductible() && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C4)));
    }

    @Test
    public void test_Pacte_PlusieursCompartiments_with_contrat_and_compartiment_selected() throws Exception {

        prepare(true, Arrays.asList(CompartimentType.C1, CompartimentType.C4), true, 10, true);
        when(requestContextHolder.getCompartiment()).thenReturn("C1-1");
        when(requestContextHolder.getContrat()).thenReturn("id");
        VersementContexteDto contexte = new VersementContexteDto();
        contexte.setContratSelectionne(ContratId.builder().build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolved = versementQuestionResolverChoixCompartiment.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertNotNull(resolved.getDefaultValue());
        assertNotNull(resolved.getDefaultValue().getValue());
        assertNotNull(resolved.getDefaultValue().getValue().getCompartiment());
        assertTrue(resolved.getDefaultValue().getValue().getCompartiment().isDeductible());
        assertTrue(resolved.getDefaultValue().getValue().getCompartiment().isDeductible());
        assertEquals(CompartimentType.C1, resolved.getDefaultValue().getValue().getCompartiment().getCompartimentType());
        assertEquals("C1-1", resolved.getDefaultValue().getValue().getCompartiment().getIdentifiantAssure());
        assertFalse(resolved.getData().isContratBloque());
    }

    @Test
    public void test_Pacte_UnCompartiment() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1), true, 10, true);
        VersementContexteDto ctx = new VersementContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> resolved = versementQuestionResolverChoixCompartiment.resolve(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 0);
        assertFalse(resolved.getData().isContratBloque());
        assertFalse(resolved.isShow());
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, boolean allowDifferentInvestmentsForVif, List<CompartimentType> compartimentTypes) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment.builder().type(compartimentType).build();
            if (compartimentType == CompartimentType.C1) {
                compartiment.setDeductible(true);
            }
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private SupportsInvNiveau1 buildStructInv(ContratHeader contratHeader) {
        final SupportsInvNiveau1 res = new SupportsInvNiveau1();

        StructInv structInv = new StructInv();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), contratHeader.isPacte());
            final List<ContributionInv> contributionInvs = contributionTypes.stream().map(contributionType -> {
                ContributionInv contributionInv = new ContributionInv();
                contributionInv.setType(contributionType);
                contributionInv.setTauxRepartitionContribution(new BigDecimal(0));
                contributionInv.setProfils(Collections.singletonList(newProfil(1, contributionType + "-profil")));
                contributionInv.setGrilles(Collections.singletonList(newGrille(1, contributionType + "-grille")));
                contributionInv.setIndicateurTauxDerogeable(true);
                contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
                return contributionInv;
            }).collect(Collectors.toList());
            structInv.addContributions(contributionInvs);

            for (ContributionType contributionType : contributionTypes) {
                final ContributionInv contribution = structInv.getContribution(contributionType);
                if (contribution != null) {
                    res.addAll(contribution.getGrilles());
                    res.addAll(contribution.getProfils());
                }
            }
        }
        return res;
    }

    private EncoursDto buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(BigDecimal.valueOf(montant));
        compteEncours.setEnErreur(false);
        return new EncoursDto(compteEncours);
    }

    private GrilleInv newGrille(double d, String id) {
        GrilleInv grille = new GrilleInv();
        grille.setTauxRepartitionDefaut(new BigDecimal(d));
        grille.setIndicateurTauxDerogeable(false);
        grille.setTauxRepartition(new BigDecimal(d));
        grille.setId(id);
        return grille;
    }

    private ProfilInv newProfil(double d, String id) {
        ProfilInv profil = new ProfilInv();
        profil.setId(id);
        profil.setTauxRepartitionDefaut(new BigDecimal(d));
        profil.setTauxRepartition(new BigDecimal(d));
        profil.setIndicateurTauxDerogeable(false);
        return profil;
    }
}
