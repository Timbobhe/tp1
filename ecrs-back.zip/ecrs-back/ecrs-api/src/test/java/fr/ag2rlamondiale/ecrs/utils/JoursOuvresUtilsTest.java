package fr.ag2rlamondiale.ecrs.utils;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.DEFAULT_DATE_FORMAT;
import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.DEFAULT_DATE_FORMAT_EXTENDED_DF;
import static org.junit.Assert.*;

public class JoursOuvresUtilsTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(JoursOuvresUtilsTest.class.getName());

    public static final String DEFAULT_DATE_FORMAT_DAY = "EEEE dd/MM/yyyy";

    private static final int TWO = 2;
    private static final int THREE = 3;
    private static final int FOUR = 4;
    private static final int FIVE = 5;
    private static final int SIX = 6;
    private static final int SEVEN = 7;
    private static final int EIGHT = 8;
    private static final int NINE = 9;
    private static final int TEN = 10;
    private static final int ELEVEN = 11;
    private static final int TWELVE = 12;
    private Date date1;
    private Date date2;
    private Date date3;
    private Date date4;
    private Date date5;
    private Date date6;
    private Date date7;
    private Date date8;
    private Date date9;
    private Date date10;
    private Date date11;
    private Date date12;

    @Before
    public void setUp() {
        date1 = initDateSdf("01/01/2017");
        date2 = initDateSdf("17/04/2017");
        date3 = initDateSdf("01/05/2017");
        date4 = initDateSdf("08/05/2017");
        date5 = initDateSdf("25/05/2017");
        date6 = initDateEdf("05/06/2017 11:01:02");
        date7 = initDateEdf("14/07/2017 03:52:44");
        date8 = initDateEdf("15/08/2017 09:05:02");
        date9 = initDateEdf("01/11/2017 03:00:14");
        date10 = initDateEdf("11/11/2017 22:33:02");
        date11 = initDateEdf("25/12/2017 22:33:02");

        date12 = initDateEdf("22/05/2017 22:33:02");
    }

    @Test
    public void testIsJourWeekEnd() {
        assertTrue(JoursOuvresUtils.isJourWeekEnd(date1));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date2));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date3));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date4));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date5));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date6));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date7));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date8));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date9));
        assertTrue(JoursOuvresUtils.isJourWeekEnd(date10));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date11));
        assertFalse(JoursOuvresUtils.isJourWeekEnd(date12));
    }

    @Test
    public void testIsJourFerie() {
        assertTrue(JoursOuvresUtils.isJourFerie(date1));
        assertTrue(JoursOuvresUtils.isJourFerie(date2));
        assertTrue(JoursOuvresUtils.isJourFerie(date3));
        assertTrue(JoursOuvresUtils.isJourFerie(date4));
        assertTrue(JoursOuvresUtils.isJourFerie(date5));
        assertTrue(JoursOuvresUtils.isJourFerie(date6));
        assertTrue(JoursOuvresUtils.isJourFerie(date7));
        assertTrue(JoursOuvresUtils.isJourFerie(date8));
        assertTrue(JoursOuvresUtils.isJourFerie(date9));
        assertTrue(JoursOuvresUtils.isJourFerie(date10));
        assertTrue(JoursOuvresUtils.isJourFerie(date11));

        assertFalse(JoursOuvresUtils.isJourFerie(date12));
    }

    @Test
    public void testIsJourOuvre() {
        assertFalse(JoursOuvresUtils.isJourOuvre(date1));
        assertFalse(JoursOuvresUtils.isJourOuvre(date2));
        assertFalse(JoursOuvresUtils.isJourOuvre(date3));
        assertFalse(JoursOuvresUtils.isJourOuvre(date4));
        assertFalse(JoursOuvresUtils.isJourOuvre(date5));
        assertFalse(JoursOuvresUtils.isJourOuvre(date6));
        assertFalse(JoursOuvresUtils.isJourOuvre(date7));
        assertFalse(JoursOuvresUtils.isJourOuvre(date8));
        assertFalse(JoursOuvresUtils.isJourOuvre(date9));
        assertFalse(JoursOuvresUtils.isJourOuvre(date10));
        assertFalse(JoursOuvresUtils.isJourOuvre(date11));

        assertTrue(JoursOuvresUtils.isJourOuvre(date12));
    }

    // @Ignore("Test is ignored as a demonstration")
    @Test
    public void testGetDateApresNombreJourOuvres() {
        // jour de l'an
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date1, 1), initDateSdf("02/01/2017"));
        // lundi de paques 17/04/2017
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date2, TWO), initDateSdf("19/04/2017"));
        // 01/05/2017
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date3, THREE), initDateSdf("04/05/2017"));
        // 08/05/2017
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date4, FOUR), initDateSdf("12/05/2017"));

        // ascension 25/05/2017
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date5, FIVE), initDateSdf("01/06/2017"));
        // pentecote 05/06/2017 11:01:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date6, SIX), initDateEdf("13/06/2017 11:01:02"));

        // 14/07/2017 03:52:44
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date7, SEVEN), initDateEdf("25/07/2017 03:52:44"));
        // 15/08/2017 09:05:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date8, EIGHT), initDateEdf("25/08/2017 09:05:02"));
        // 01/11/2017 03:00:14
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date9, NINE), initDateEdf("14/11/2017 03:00:14"));
        // 11/11/2017 22:33:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date10, TEN), initDateEdf("24/11/2017 22:33:02"));
        // 25/12/2017 22:33:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date11, ELEVEN), initDateEdf("10/01/2018 22:33:02"));

        // 22/05/2017 22:33:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date12, TWELVE), initDateEdf("09/06/2017 22:33:02"));

        // 22/05/2017 22:33:02
        assertEquals(JoursOuvresUtils.getDateApresNombreJourOuvres(date12, 0), initDateEdf("22/05/2017 22:33:02"));
    }

    @Test
    public void testJourFeriesAnnee() {
        List<Date> listeJoursFeries = JoursOuvresUtils.getJoursFeries(2021);

        assertEquals(formatAvecJour(listeJoursFeries.get(0)), "Friday 01/01/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(1)), "Monday 05/04/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(2)), "Saturday 01/05/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(3)), "Saturday 08/05/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(4)), "Thursday 13/05/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(5)), "Monday 24/05/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(6)), "Wednesday 14/07/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(7)), "Sunday 15/08/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(8)), "Monday 01/11/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(9)), "Thursday 11/11/2021");
        assertEquals(formatAvecJour(listeJoursFeries.get(10)), "Saturday 25/12/2021");
    }

    private static SimpleDateFormat dateFormat(String format) {
        return new SimpleDateFormat(format, Locale.ENGLISH);
    }

    private Date initDateSdf(String sd) {
        Date d = null;
        try {
            d = dateFormat(DEFAULT_DATE_FORMAT).parse(sd);
        } catch (ParseException e) {
            LOGGER.error("Erreur format de date", e);
        }
        return d;
    }

    private Date initDateEdf(String sd) {
        Date d = null;
        try {
            d = dateFormat(DEFAULT_DATE_FORMAT_EXTENDED_DF).parse(sd);
        } catch (ParseException e) {
            LOGGER.error("Erreur format de date", e);
        }
        return d;
    }

    private String formatAvecJour(Date dateJour) {
        return dateFormat(DEFAULT_DATE_FORMAT_DAY).format(dateJour);
    }
}
