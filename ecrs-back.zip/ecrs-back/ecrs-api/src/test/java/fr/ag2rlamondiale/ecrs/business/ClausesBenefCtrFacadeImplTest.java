package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.ClausesBenefCtrFacadeImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.bia.ClauseBeneficiaireDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireStartDto;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireTerminateDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.business.*;
import fr.ag2rlamondiale.trm.client.soap.IConsulterClausesBenefCtrClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ClausesContratDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.*;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.sigelec.*;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.dto.sigelec.ResultatEtatDemandesDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class ClausesBenefCtrFacadeImplTest {
    private static final String NUM_CONTRAT = "RG151312337";
    private static final String CODE_TYPE_BENEF = "CODE_TYPE_BENEF";
    private static final Date DATE_JOUR = new Date();

    @Mock
    private IConsulterClausesBenefCtrClient clausesBenefCtrClient;

    @Mock
    private IContratFacade contratFacadeMock;

    @Mock
    private IBlocageFacade blocageFacadeMock;

    @Mock
    private UserContextHolder userContextHolderMock;

    @Mock
    private ISigElecFacade sigElecFacadeMock;

    @Mock
    private IWorkflowFacade workflowFacadeMock;

    @Mock
    private IDownloadDocumentFacade downloadDocumentFacade;

    @Mock
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Mock
    private IJahiaFacade jahiaFacadeMock;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Spy
    private ContratParcoursMapperImpl contratParcoursMapper;

    @InjectMocks
    ClausesBenefCtrFacadeImpl clausesBenefCtrFacade;

    @Before
    public void init() throws IOException, TechnicalException {
        UserContext user = new UserContext();
        user.setNumeroPersonneMdpro("numeroPersonneMdpro");
        user.setNumeroPersonneEre("numeroPersonneEre");
        when(userContextHolderMock.get()).thenReturn(user);

//        when(dataDocumentContratFacade.getDocumentTitle(any(DocRefType.class))).thenReturn("document title");
//        when(dataDocumentContratFacade.getNomFichierActeDocumentEnLigne(any(DocRefType.class))).thenReturn("document signature en ligne title");
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(new DataDocumentContrat());

        when(jahiaFacadeMock.findDictionaryEntry(DictionaryKeyType.CLAUSE_BENEFICIAIRE, "CLAUSE_BENEFICIAIRE_AGREMENTS_ACTE")).thenReturn("clause beneficiaire agrement acte");
        when(jahiaFacadeMock.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE")).thenReturn("agrement convention de preuves");
        when(jahiaFacadeMock.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE_TITLE_DOC")).thenReturn("agrement convention de preuves title doc");
    }

    @Test
    public void consulterClausesBenefCtrTest() throws TechnicalException {
        // Given
        when(clausesBenefCtrClient
                .consulterClausesBenefCtr(any(ConsulterClausesBenefCtrDto.class)))
                        .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                            ConsulterClausesBenefCtrResponseDto response =
                                    new ConsulterClausesBenefCtrResponseDto();
                            ClausesContratDto clausesContrat = new ClausesContratDto();
                            clausesContrat.setCodeTypeBenef(CODE_TYPE_BENEF);
                            clausesContrat.setDateFinClauseBenef(DATE_JOUR);
                            response.setClausesContrat(Arrays.asList(clausesContrat));
                            return response;
                        });

        // When
        ConsulterClausesBenefCtrResponseDto response =
                clausesBenefCtrFacade.consulterClausesBenefCtr(NUM_CONTRAT, CodeSiloType.MDP);

        // Then
        Assert.assertEquals(CODE_TYPE_BENEF,
                response.getClausesContrat().get(0).getCodeTypeBenef());
        Assert.assertEquals(DATE_JOUR, response.getClausesContrat().get(0).getDateFinClauseBenef());
    }

    @Test
    public void should_return_empty_list_of_contracts_when_fonctionnalite_bloquee_pour_contrat() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(createContratsEreList());
        when(blocageFacadeMock.getInfosBlocagesClient()).thenReturn(createInfoBlocageClient());

        ClauseBeneficiaireStartDto actual = clausesBenefCtrFacade.startModificationClauseBeneficiaire();

        Assert.assertEquals(0, actual.getClauseBeneficiaireContrats().size());
    }

    @Test(expected = TechnicalRuntimeException.class)
    public void should_return_exception_when_modification_en_cours_is_in_error() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(createContratsEreList());
        when(blocageFacadeMock.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
        when(userContextHolderMock.get()).thenReturn(createUserContext());
        when(workflowFacadeMock.hasDemandeEnCoursByContrat(anyString(), any(ContratHeader.class), any(DemandeWorkflowType.class)))
                .thenThrow(new WorkflowException("Error occurred"));

        clausesBenefCtrFacade.startModificationClauseBeneficiaire();
    }

    @Test
    public void should_retrieve_empty_list_of_contracts_when_has_demande_modification_clause_beneficiaire_in_workflow() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(createContratsEreList());
        when(blocageFacadeMock.getInfosBlocagesClient()).thenReturn(createInfoBlocageClient());
        when(userContextHolderMock.get()).thenReturn(createUserContext());
        when(workflowFacadeMock.hasDemandeEncours(anyString(), any(DemandeWorkflowType.class)))
                .thenReturn(true);

        ClauseBeneficiaireStartDto actual = clausesBenefCtrFacade.startModificationClauseBeneficiaire();

        Assert.assertEquals(0, actual.getClauseBeneficiaireContrats().size());
    }

    @Test
    public void should_retrieve_empty_list_of_contracts_when_has_demande_sigelec_en_cours() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(createContratsEreList());
        when(blocageFacadeMock.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
        when(userContextHolderMock.get()).thenReturn(createUserContext());
        when(sigElecFacadeMock.verifierEtatDemandes(anyString(), anyString(), any(OperationType.class))).thenReturn(createEtatDemandes(true));
        when(sigElecFacadeMock.consulterDemSigElec(anyString())).thenReturn(createConsulterDemSigelecResponse());


        ClauseBeneficiaireStartDto actual = clausesBenefCtrFacade.startModificationClauseBeneficiaire();

        Assert.assertEquals(0, actual.getClauseBeneficiaireContrats().size());
    }

    private ResultatEtatDemandesDto createEtatDemandes(boolean enCours) {
        return ResultatEtatDemandesDto.builder().sigElecEncoursSigne(enCours).build();
    }

    @Test
    public void should_retrieve_start_modification_clause_beneficiaire_dto_with_contracts_not_empty() throws TechnicalException {
        when(contratFacadeMock.rechercherContratsEre()).thenReturn(createContratsEreList());
        when(blocageFacadeMock.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());
        when(userContextHolderMock.get()).thenReturn(createUserContext());

        when(sigElecFacadeMock.verifierEtatDemandes(anyString(), anyString(), any(OperationType.class))).thenReturn(createEtatDemandes(false));
        when(sigElecFacadeMock.consulterDemSigElec(anyString())).thenReturn(new ConsulterDemSigElecResponseDto());

        ClauseBeneficiaireStartDto actual = clausesBenefCtrFacade.startModificationClauseBeneficiaire();

        Assert.assertEquals(createContratsEreList().get(0).getId(), actual.getClauseBeneficiaireContrats().get(0).getContrat().getNomContrat());
    }

    @Test
    public void should_terminate_modification_clause_beneficiaire_by_electronic_signature() throws IOException, JAXBException, CommonException {
        when(contratFacadeMock.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true));

        clausesBenefCtrFacade.terminateModificationClauseBeneficiaire(
                createClauseBeneficiaireTerminateDto(), false);

        verify(sigElecFacadeMock, times(0)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),eq(false));
    }

    @Test
    public void should_not_terminate_modification_clause_beneficiaire_by_electronic_signature() throws IOException, JAXBException, CommonException {
        when(contratFacadeMock.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true));
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(null);

        String actual = clausesBenefCtrFacade.terminateModificationClauseBeneficiaire(
                createClauseBeneficiaireTerminateDto(), false);

        Assert.assertNull(actual);
    }

    private ConsulterDemSigElecResponseDto createConsulterDemSigelecResponse() {
        ConsulterDemSigElecResponseDto consulterDemSigElecResponseDto = new ConsulterDemSigElecResponseDto();
        consulterDemSigElecResponseDto.setDateSignature(new Date());
        consulterDemSigElecResponseDto.setDescription("description");
        consulterDemSigElecResponseDto.setIdDemande("id demande");
        consulterDemSigElecResponseDto.setSignEnCours(BigInteger.ONE);
        consulterDemSigElecResponseDto.setSignManuscrite(false);
        consulterDemSigElecResponseDto.setStatusSignature("SIGN");
        consulterDemSigElecResponseDto.setUrlPageSigntr("url page signature");
        return consulterDemSigElecResponseDto;
    }

    private List<SigElecJson> createDemandeSigelecList() {
        List<SigElecJson> demandesSigElecList = new ArrayList<>();
        SigElecJson sigElecJson = new SigElecJson();
        sigElecJson.setAnalyse(true);
        sigElecJson.setCodeApp(AccesApp.A1573);
        sigElecJson.setCodeDepartement("78");
        sigElecJson.setDirty(false);
        sigElecJson.setEtatDmd(EtatSigELec.SIGN);
        sigElecJson.setIdContrat("idcontrat");
        sigElecJson.setIdDemande(Long.parseLong("12345"));
        sigElecJson.setIdExt("idExt");
        sigElecJson.setIdGdi("idGdi");
        sigElecJson.setIdTransaction("idTransaction");
        sigElecJson.setLibCompartiment("C3");
        sigElecJson.setLibelleMsgAno("anomalie");
        sigElecJson.setMontant(BigDecimal.ONE);
        sigElecJson.setNumeroAssure("numero assure");
        sigElecJson.setNumPersonne("num personne");
        sigElecJson.setTypeOp(OperationType.CBF);
        demandesSigElecList.add(sigElecJson);
        return demandesSigElecList;
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setIdGdi("idGdi");
        return userContext;
    }

    private List<ContratHeader> createContratsEreList() {
        List<ContratHeader> contratHeaders = new ArrayList<>();
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("id");
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeaders.add(contratHeader);
        return contratHeaders;
    }

    private InfosBlocagesClient createInfoBlocageClient() {
        InfosBlocagesClient infosBlocagesClient = new InfosBlocagesClient();
        Map<String, Set<String>> blocage = new HashMap<>();
        Set<String> code = new HashSet<>();
        code.add("ClauseBeneficiaire");
        blocage.put("id", code);
        infosBlocagesClient.setFonctionnalitesBloqueesContrats(blocage);
        return infosBlocagesClient;
    }


    private ClauseBeneficiaireTerminateDto createClauseBeneficiaireTerminateDto() {
        ClauseBeneficiaireTerminateDto clauseBeneficiaireTerminateDto = new ClauseBeneficiaireTerminateDto();
        ContratId contratId = new ContratId();
        contratId.setCodeSilo(CodeSiloType.ERE);
        contratId.setIdAdherente("");
        contratId.setIdContractante("S4164948");
        contratId.setNomContrat("RG151236289");
        clauseBeneficiaireTerminateDto.setContratSelected(contratId);
        ClauseBeneficiaireDto clauseBeneficiaireDto = new ClauseBeneficiaireDto();
        clauseBeneficiaireDto.setClauseStandard(true);
        clauseBeneficiaireDto.setTypeClause("STD");
        clauseBeneficiaireDto.setContenuClause("contenu clause standard");
        clauseBeneficiaireTerminateDto.setClauseBeneficiaire(clauseBeneficiaireDto);
        DocumentDto document = new DocumentDto();
        document.setHtmlContent("html content");
        clauseBeneficiaireTerminateDto.setContenuClauseBeneficiaire(document);
        return clauseBeneficiaireTerminateDto;
    }

    private ContratHeader createContratHeader(boolean isPacte) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("RG151236289");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        return contratHeader;
    }

    private HashMap<String, ChampsPDFInfo> generateMapParameters() {
        HashMap<String, ChampsPDFInfo> params = new HashMap<>();
        params.put(ChampsPdfType.NOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRENOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_PRODUIT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COMPTEUR_SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.E_MAIL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADR_LEGALE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE_COURRIER.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT_LB));
        params.put(ChampsPdfType.ANNUEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_SPECIFIQUE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_STANDARD.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_POSTAL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COLLEGE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CONSENTEMENTS.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DEPARTEMENT_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FONDS_DEFAUT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.IDENTIFIANT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LIEU_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LOGO.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LOGOPART.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MADAME.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MENSUEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONSIEUR.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONTANT_VL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONTANT_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NUM_CONTRAT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OPT_IN.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRENOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PAYS.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRODUIT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.QR_CODE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.RAISON_SOCIALE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SEMESTRIEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.STRATEGIE_FINANCIERE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TAUX_SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PORTABLE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PROFESSIONNEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TEXTE_CLAUSESPECIFIQUE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TRIMESTRIEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.VILLE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        return params;
    }
}
