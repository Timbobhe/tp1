package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.impl.versement.BlocageVersementContratDto;
import fr.ag2rlamondiale.ecrs.business.impl.versement.DictionnaireVersementJahia;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementGestionMontantService;
import fr.ag2rlamondiale.ecrs.business.impl.versement.VersementQuestionResolverChoixCompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.NouvelleRepartitionDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.ecrs.dto.versement.*;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.RibDto;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.*;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.constantes.Constantes;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.Adherente;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.RolePersonneContrat;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.mandat.CoordonneesCmptBanc;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.qad.PropositionJson;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.sigelec.DocumentRIB;
import fr.ag2rlamondiale.trm.domain.sigelec.DocumentType;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Sets;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.AFFILIATION_AVEC_BIA;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VersementFacadeImplTest {
    @InjectMocks
    VersementFacadeImpl versementFacadeImpl;

    @Spy
    @InjectMocks
    ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    private IBlocageFacade blocageFacade;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IStructureInvFacade structureInvFacade;

    @Mock
    VersementQuestionResolverChoixCompartiment choixCompartiment;

    @Mock
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    private ContratVifHelper contratVifHelper;

    @Mock
    private ISigElecFacade sigElecfacade;

    @Mock
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Mock
    private IJahiaFacade jahiaFacade;

    @Mock
    private IQadFacade qadFacade;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Mock
    private RequestContextHolder requestContextHolder;

    @Mock
    private VersementGestionMontantService versementGestionMontantService;

    @Mock
    private IParcoursSimplifieFacade  parcoursSimplifieFacade;

    @Before
    public void init() throws TechnicalException, IOException {
        MockitoAnnotations.initMocks(this);
        when(userContextHolder.get()).thenReturn(createUserContext());
        ReflectionTestUtils.setField(versementFacadeImpl, "contratParcoursMapper", contratParcoursMapper);
        when(choixCompartiment.resolve(any(ContratHeader.class), any(VersementContexteDto.class))).thenReturn(buildChoixCompartiment());
        ReflectionTestUtils.setField(versementFacadeImpl, "questionResolvers", Collections.singletonList(choixCompartiment));
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            return info;
        });

        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class))).thenReturn(GestionFinanciereActuelleMdpDto.builder()
                .modeGestionMDPROSource(ModeGestionMdproType.LIBRE)
                .build());

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        physiqueConsult.setPays("FRANCE");
        physiqueConsult.setPaysResidenceFiscale("FRANCE");
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);
        when(contratVifHelper.isVifPossible(any(ContratComplet.class), any())).thenReturn(true);

        when(qadFacade.getPropositionParProduit(any())).thenReturn(Collections.singletonList(new PropositionJson()));

        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class), any())).thenAnswer((Answer<DataDocumentContrat>) invocation -> {
            DataDocumentContrat dataDocumentContrat = new DataDocumentContrat();
            dataDocumentContrat.setRib(new DocumentRIB("titulaire", "bic", "iban"));
            return dataDocumentContrat;
        });

        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(new DataDocumentContrat());
        when(contratFacade.rechercherContratGeneral(any())).thenReturn(createContratGeneral());
        when(workflowFacade.genererIdDemFront(any(CodeActionType.class), anyString(), anyString(), any(CodeSiloType.class))).thenReturn("id dem front generated");

        when(versementGestionMontantService.verifierMontant(any(), any(), any())).thenReturn(true);
        when(parcoursSimplifieFacade.isParcoursSimplifieActivate(any(String.class),any(FonctionnaliteType.class))).thenReturn(false);

    }

    public ContratComplet prepareContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType, List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment, boolean gestionFinanciereDifferentePossible, boolean imposee, String typeContrat, SituationContratEnum etatContrat, boolean profile, int anneeNaissance, String codeRole, String idContractante) throws TechnicalException {
        final ContratComplet contratComplet = createContratComplet(isPacte, isMdpro, affichageType, gestionFinanciereDifferentePossible, compartimentTypes, etatCompartiment, typeContrat, etatContrat, anneeNaissance, codeRole, idContractante);
        when(contratFacade.rechercherContratsComplets()).thenReturn(Collections.singletonList(contratComplet));
        return contratComplet;
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType, boolean allowDifferentInvestmentsForVif, List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment, String typeContrat, SituationContratEnum etatContrat, int anneeNaissance, String codeRole, String idContractante) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("RG912");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.setAffichageType(affichageType);
        contratHeader.setTypeContrat(typeContrat);
        contratHeader.setEtatContrat(etatContrat);
        contratHeader.setNumGenContrat("Num");
        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment
                    .builder()
                    .type(compartimentType)
                    .etatCompartiment(etatCompartiment)
                    .disponibilite(DisponibiliteType.DISPONIBLE)
                    .affichageType(AffichageType.NORMAL)
                    .build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");
        if (StringUtils.isNotEmpty(idContractante)) {
            contratGeneral.setIdContractante(idContractante);
        }
        contratGeneral.setIdAssurePrincipal("Pid");
        contratGeneral.setDateNaissanceContractante(DateUtils.createDate(10, 10, anneeNaissance));
        contratGeneral.setDateNaissanceAssurePrincipal(DateUtils.createDate(10, 10, anneeNaissance));
        if (StringUtils.isNotEmpty(codeRole)) {
            RolePersonneContrat rolePersonneContrat = new RolePersonneContrat();
            rolePersonneContrat.setCodeRolePersCtr(codeRole);
            contratGeneral.setRolePersonnes(Collections.singletonList(rolePersonneContrat));
        }
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("123456");
        userContext.setSilos(Sets.set(CodeSiloType.ERE));
        return userContext;
    }

    private QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> buildChoixCompartiment() {
        return QuestionResponsesDto.<ChoixCompartimentDto, BlocageVersementContratDto>builder()
                .data(BlocageVersementContratDto.builder().contratBloque(false).build())
                .build();
    }


    private VersementTerminateDto createVersementTerminateDto(boolean withQad, RibStatusType ribStatus, CodeSiloType codeSilo, QuestionType.ResponseVersementModeType modeVersement, QuestionType.ResponseVersementMoyenPaiementType moyenPaiement) {
        VersementTerminateDto versementTerminateDto = new VersementTerminateDto();

        DocumentDto documentVersement = new DocumentDto();
        documentVersement.setHtmlContent("html content");
        documentVersement.setHtmlStyle("html style");
        versementTerminateDto.setContenuVersement(documentVersement);
        if (withQad) {
            DocumentDto documentQad = new DocumentDto();
            documentQad.setHtmlContent("html content");
            documentQad.setHtmlStyle("html style");
            versementTerminateDto.setContenuQad(documentQad);
        }
        ContratId contratId = new ContratId();
        contratId.setNomContrat("nom contrat");
        contratId.setIdContractante("id contractante");
        contratId.setIdAdherente("id adherente");
        contratId.setCodeSilo(codeSilo);
        versementTerminateDto.setContratSelected(contratId);

        NouvelleRepartitionDto nouvelleRepartitionDto = new NouvelleRepartitionDto();
        nouvelleRepartitionDto.setRepartitions(createRepartition());
        VersementClientDto versementClientDto = VersementClientDto.builder()
                .montantVersement(new BigDecimal(100))
                .periodiciteVersement(FrequenceVirementType.ANNUELLE)
                .montantVersementActuel(new BigDecimal(100))
                .periodiciteVersementActuel(FrequenceVirementType.MENSUELLE)
                .modeVersement(modeVersement)
                .moyenPaiement(moyenPaiement)
                .compartimentId(CompartimentId.builder()
                        .idAssure(CodeSiloType.ERE.equals(codeSilo) ? "id" : null)
                        .nomContrat(CodeSiloType.MDP.equals(codeSilo) ? "nom contrat" : null)
                        .compartimentType(CompartimentType.C1)
                        .build())
                .coordonneesBancaires(new RibDto("titulaire", "iban", "bic"))
                .ribStatus(ribStatus)
                .fichiercoordonneesBancaires(UploadFileDto.builder().fileContent("RIB CONTENT").build())
                .nouvelleRepartition(nouvelleRepartitionDto)
                .build();
        versementTerminateDto.setVersementClient(versementClientDto);
        return versementTerminateDto;
    }

    private List<RepartitionSupportDto> createRepartition() {
        RepartitionSupportDto repartitionSupportDto = new RepartitionSupportDto();
        return Collections.singletonList(repartitionSupportDto);
    }

    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("nom contrat");
        contratHeader.setIdentifiantAssure("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C1)
                .identifiantAssure("id")
                .contratHeader(contratHeader)
                .build());
        contratHeader.setCompartiments(Collections.singletonList(Compartiment.builder()
                .type(CompartimentType.C1)
                .identifiantAssure("id")
                .contratHeader(contratHeader)
                .build()));
        return contratHeader;
    }

    private ContratGeneral createContratGeneral() {
        ContratGeneral contratGeneral = new ContratGeneral();
        contratGeneral.setCodeAssureur("code assureur");
        CoordonneesCmptBanc coordonneesCmptBanc = new CoordonneesCmptBanc();
        coordonneesCmptBanc.setCodeIBAN("iban");
        coordonneesCmptBanc.setCodeBIC("bic");
        coordonneesCmptBanc.setTitulaireCompte("titulaire");
        contratGeneral.setCoordonneesCmptBanc(coordonneesCmptBanc);
        contratGeneral.setIdAssurePrincipal("Pid");
        contratGeneral.setIdContractante("Pid");
        Adherente adherente = new Adherente();
        adherente.setId("id adherente");
        adherente.setRaisonSociale("raison sociale");
        contratGeneral.setAdherentes(Collections.singletonList(adherente));
        contratGeneral.setDateNaissanceContractante(DateUtils.createDate(10, 10, 2020));
        contratGeneral.setDateNaissanceAssurePrincipal(DateUtils.createDate(10, 10, 2020));
        return contratGeneral;
    }

    private ProduitJson createProduitJson(String typeContrat, String numGen, String fiscalite, Boolean deductible) {
        ProduitJson produit = new ProduitJson();
        produit.setCodeFiliale("LMX");
        produit.setTypeContrat(typeContrat);
        produit.setNumeroGeneration(numGen);
        produit.setLibelleFiscalite(fiscalite);
        produit.setDeductible(deductible);
        return produit;
    }

    @Test
    public void startVersement_when_contract_ere_pacte_and_vif_possible() throws TechnicalException {
        when(contratVifHelper.isVifPossibleByListCompartimentTypes(any(ContratComplet.class), any())).thenReturn(true);
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C4), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertFalse(versementStartDto.getVersements().get(0).isBloque());
    }

    @Test
    public void startVersement_when_contract_ere_pacte_and_contract_bloque_console() throws TechnicalException {
        when(contratVifHelper.isVifPossibleByListCompartimentTypes(any(ContratComplet.class), any())).thenReturn(true);

        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });

        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C4), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name());
    }

    @Test
    public void startVersement_when_contract_ere_pacte_and_versement_libre_and_programme_bloques() throws TechnicalException {
        when(contratVifHelper.isVifPossibleByListCompartimentTypes(any(ContratComplet.class), any())).thenReturn(true);

        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            Map<String, Set<String>> fct = new HashMap<>();
            fct.put("RG912", Stream.of("versementLibre", "versementProgramme").collect(Collectors.toSet()));

            info.setFonctionnalitesBloqueesContrats(fct);
            return info;
        });

        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C4), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name());
    }

    @Test
    public void startVersement_when_contract_ere_pacte_and_vif_not_possible() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C4), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name());
    }

    @Test
    public void startVersement_when_contract_ere_not_pacte_and_vif_possible() throws TechnicalException {
        when(contratVifHelper.isVifPossibleByListCompartimentTypes(any(ContratComplet.class), any())).thenReturn(true);
        prepareContratComplet(false, false, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertFalse(versementStartDto.getVersements().get(0).isBloque());
    }

    @Test
    public void startVersement_when_contract_ere_not_pacte_and_vif_not_possible() throws TechnicalException {
        prepareContratComplet(false, false, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_mineur() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2020, "24", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_confirmees_and_not_tiers_payeurs() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "30", "Pid");
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        //Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name())
    }

    @Test
    public void startVersement_when_contract_mdpro_versementLibre_bloque() throws TechnicalException {
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            Map<String, Set<String>> fct = new HashMap<>();
            fct.put("RG912", Stream.of("versementLibre").collect(Collectors.toSet()));

            info.setFonctionnalitesBloqueesContrats(fct);
            return info;
        });
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "30", "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_contractante_null_and_assure_majeur_and_donnees_confirmees_and_not_tiers_payeurs() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "30", null);
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_non_confirmees() throws TechnicalException {
        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(false);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);

        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_confirmees_and_contractante_undefined_and_product_mdpro_undefined() throws TechnicalException {
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(null);
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, null, "Pid");
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        // Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_confirmees_and_contractante_undefined_and_madelin() throws TechnicalException {
        ProduitJson produitDeductible = createProduitJson("RA09", "V01", "MADELIN", Boolean.TRUE);
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produitDeductible);
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS_SANS_PRIME, false, 2000, null, "Pid");
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();


        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_ra09_v51() throws TechnicalException {
        ProduitJson produitDeductible = createProduitJson("RA09", "V51", "", Boolean.TRUE);
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produitDeductible);
        final BaseContratComplet contratComplet = prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS_SANS_PRIME, false, 2000, null, "Pid");
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();


        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT.name());
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_confirmees_and_contractante_undefined_and_not_madelin() throws TechnicalException {
        ProduitJson produitNonDeductible = createProduitJson("RA10", "V01", "IRC - ASS", Boolean.FALSE);
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produitNonDeductible);
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS_SANS_PRIME, false, 2000, null, "Pid");

        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            info.setToutLesContratsTotalementsBloques(true);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();


        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        // Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_STATUT.name())
    }

    @Test
    public void startVersement_when_contract_mdpro_and_souscripteur_equals_assure_and_contrat_moral_and_assure_majeur_and_donnees_confirmees_and_tiers_payeurs() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3), AFFILIATION_AVEC_BIA, false, false, "RA09", SituationContratEnum.EN_COURS, false, 2000, "24", "Pid");
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            Map<String, Set<String>> fct = new HashMap<>();
            fct.put("RG912", Stream.of("versementLibre").collect(Collectors.toSet()));

            info.setFonctionnalitesBloqueesContrats(fct);
            return info;
        });
        VersementStartDto versementStartDto = versementFacadeImpl.startVersement();

        Assert.assertNotNull(versementStartDto.getVersements());
        Assert.assertEquals(1, versementStartDto.getVersements().size());
        Assert.assertEquals("RG912", versementStartDto.getVersements().get(0).getContrat().getNomContrat());
        Assert.assertTrue(versementStartDto.getVersements().get(0).isBloque());
        Assert.assertEquals(versementStartDto.getVersements().get(0).getRaisonBlocage().getJahiaDicoEntry(), DictionnaireVersementJahia.VERSEMENT_BLOCAGE_CONSOLE.name());
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_without_qad_and_contract_ere_not_pacte_and_known_rib_and_versement_libre_and_cheque() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_without_qad_and_contract_ere_not_pacte_and_known_rib_and_versement_libre_and_prelevement() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.PRELEVEMENT_AUTOMATIQUE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_without_qad_and_contract_ere_not_pacte_and_known_rib_and_versement_programme() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_PROGRAMME, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_without_qad_and_contract_ere_not_pacte_and_new_rib() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.NEW, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(
                argThat(demandeCreationSigElec -> demandeCreationSigElec.getUploadedDocuments().size() == 1 && demandeCreationSigElec.getUploadedDocuments().get(0).getType().equals(DocumentType.RIB)),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_with_qad_and_contract_ere_not_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(true, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_without_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_with_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        versementFacadeImpl.terminate(createVersementTerminateDto(true, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_with_contract_mdpro_and_known_rib() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, true));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.MDP, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                eq(false));
    }

    @Test
    public void should_terminate_versement_by_electronic_signature_with_contract_mdpro_and_new_rib() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, true));

        versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.NEW, CodeSiloType.MDP, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(
                argThat(demandeCreationSigElec -> demandeCreationSigElec.getUploadedDocuments().size() == 1 && demandeCreationSigElec.getUploadedDocuments().get(0).getType().equals(DocumentType.RIB)),
                eq(false));
    }

    @Test
    public void should_fail_when_terminate_versement() throws IOException, TechnicalException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(null);
        String terminate = versementFacadeImpl.terminate(createVersementTerminateDto(false, RibStatusType.KNOWN, CodeSiloType.ERE, QuestionType.ResponseVersementModeType.VERSEMENT_LIBRE, QuestionType.ResponseVersementMoyenPaiementType.CHEQUE_BANCAIRE), false);

        Assert.assertNull(terminate);
    }

    @Test
    public void should_resolve_question_or_next() throws TechnicalException {
        when(choixCompartiment.resolve(eq(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT), any(VersementContexteDto.class)))
                .thenReturn(QuestionResponsesDto.<ChoixCompartimentDto, BlocageVersementContratDto>builder()
                        .question(QuestionDto.builder()
                                .id(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT)
                                .label(Constantes.MOCKDATA)
                                .build())
                        .show(true)
                        .build());
        when(choixCompartiment.accept(eq(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT), any(VersementContexteDto.class))).thenReturn(true);
        ListQuestionResponsesDto listQuestionResponsesDto = versementFacadeImpl.resolveQuestionOrNext(RequestQuestionVersementDto.builder()
                .questionTypeList(Collections.singletonList(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT))
                .questionType(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT)
                .contexte(VersementContexteDto.builder().build())
                .build());

        Assert.assertNotNull(listQuestionResponsesDto);
        Assert.assertEquals(1, listQuestionResponsesDto.getQuestionResponsesList().size());
        Assert.assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, listQuestionResponsesDto.getQuestionResponsesList().get(0).getQuestion().getId());
        Assert.assertEquals(QuestionType.VERSEMENT_CHOIX_COMPARTIMENT, listQuestionResponsesDto.getQuestionTypeDisplayed());
        Assert.assertEquals(Constantes.MOCKDATA, listQuestionResponsesDto.getQuestionResponsesList().get(0).getQuestion().getLabel());
    }
}
