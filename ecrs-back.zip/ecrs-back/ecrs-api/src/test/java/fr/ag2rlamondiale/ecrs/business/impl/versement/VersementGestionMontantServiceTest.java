package fr.ag2rlamondiale.ecrs.business.impl.versement;

import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.versement.MontantPossibleDto;
import fr.ag2rlamondiale.ecrs.dto.versement.TypeVersement;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VersementGestionMontantServiceTest {

    @InjectMocks
    VersementGestionMontantService versementGestionMontantService;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Test
    public void retrieveMontantsPossibles_VL_ERE_NonPacte() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .pacte(false)
                .build();

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, TypeVersement.VL);

        // Then
        assertNotNull(montantPossible);
        assertEquals(300, montantPossible.getMinMontantPossible());
        assertEquals(999999, montantPossible.getMaxMontantPossible());
    }

    @Test
    public void retrieveMontantsPossibles_VL_ERE_NonPacte_RG151411374() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("RG151411374")
                .pacte(false)
                .build();

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, TypeVersement.VL);

        // Then
        assertNotNull(montantPossible);
        assertEquals(100, montantPossible.getMinMontantPossible());
        assertEquals(999999, montantPossible.getMaxMontantPossible());
    }

    @Test
    public void retrieveMontantsPossibles_VL_ERE_Pacte_RG151411374() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("RG151411374")
                .pacte(true)
                .build();

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, TypeVersement.VL);

        // Then
        assertNotNull(montantPossible);
        assertEquals(100, montantPossible.getMinMontantPossible());
        assertEquals(999999, montantPossible.getMaxMontantPossible());
    }

    @Test
    public void retrieveMontantsPossibles_PO_ERE_NonPacte() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .pacte(false)
                .build();

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, TypeVersement.PO);

        // Then
        assertNotNull(montantPossible);
        assertEquals(50, montantPossible.getMinMontantPossible());
        assertEquals(500000, montantPossible.getMaxMontantPossible());
    }


    @Test
    public void retrieveMontantsPossibles_MDP_NonPacte() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .pacte(false)
                .build();

        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(null);

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, null);

        // Then
        assertNotNull(montantPossible);
        assertEquals(300, montantPossible.getMinMontantPossible());
        assertEquals(999999, montantPossible.getMaxMontantPossible());
    }

    @Test
    public void retrieveMontantsPossibles_MDP_NonPacte_PERP() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .pacte(false)
                .build();

        ProduitJson produit = new ProduitJson();
        produit.setLibelleFiscalite("PERP");
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produit);

        // When
        final MontantPossibleDto montantPossible = versementGestionMontantService.retrieveMontantsPossibles(contratHeader, null);

        // Then
        assertNotNull(montantPossible);
        assertEquals(300, montantPossible.getMinMontantPossible());
        assertEquals(999999, montantPossible.getMaxMontantPossible());
    }

    @Test
    public void test_verifierMontant_VL_ERE_Pacte_RG151411374_OK() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("RG151411374")
                .pacte(true)
                .build();

        // When
        final boolean montantOK = versementGestionMontantService.verifierMontant(contratHeader, TypeVersement.VL, BigDecimal.valueOf(200));

        // Then
        assertTrue(montantOK);
    }

    @Test
    public void test_verifierMontant_VL_ERE_Pacte_RG151411374_KO() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("RG151411374")
                .pacte(true)
                .build();

        // When
        final boolean montantKO = versementGestionMontantService.verifierMontant(contratHeader, TypeVersement.VL, BigDecimal.valueOf(99));

        // Then
        assertFalse(montantKO);
    }

    @Test
    public void test_verifierMontant_MDP_OK() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .pacte(false)
                .build();

        ProduitJson produit = new ProduitJson();
        produit.setLibelleFiscalite("PERP");
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produit);

        // When
        final boolean montantOK = versementGestionMontantService.verifierMontant(contratHeader, null, BigDecimal.valueOf(300));

        // Then
        assertTrue(montantOK);
    }

    @Test
    public void test_verifierMontant_MDP_KO() {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .pacte(false)
                .build();

        ProduitJson produit = new ProduitJson();
        produit.setLibelleFiscalite("PERP");
        when(paramConsoleFacade.findProduitMdpro(any(), any())).thenReturn(produit);

        // When
        final boolean montantKO = versementGestionMontantService.verifierMontant(contratHeader, null, BigDecimal.valueOf(99));

        // Then
        assertFalse(montantKO);

        // When
        final boolean montantKO2 = versementGestionMontantService.verifierMontant(contratHeader, null, BigDecimal.valueOf(-200));

        // Then
        assertFalse(montantKO2);
    }

}
