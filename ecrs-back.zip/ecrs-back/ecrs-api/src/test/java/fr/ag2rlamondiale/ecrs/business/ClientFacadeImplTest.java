/*
 * Cree le 3 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException;
import fr.ag2rlamondiale.ecrs.business.impl.ClientFacadeImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.client.soap.IRecherchePersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IRechercherPPSiloClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.personne.*;
import fr.ag2rlamondiale.trm.domain.workflow.IdDemSilo;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Test de la classe ClientFacadeImpl
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ClientFacadeImplTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";
    private static final String NOM = "NOM";
    private static final String PRENOM = "PRENOM";
    private static final String CIVILITE = "CIVILITE";

    @Mock
    private IRecherchePersonneClient recherchePersonneClient;
    
    @Mock
    private UserContextHolder userContextHolder;
    
    @Mock
    private IConsulterPersonneClient consulterPersonneClient;
    
    @Mock
	private IContratFacade contratFacade;
    
    @Mock
	private IWorkflowFacade workflowFacade;
    
    @Mock
	private IModifierPPSiloClient modifierPPSiloClient;
    
    @Mock
    private ICommunicationClientFacade communicationFacade;

    @Mock
    private IRechercherHabiliFacade habiliService;

    @Mock
    private IRechercherPPSiloClient rechercherPP;

    @InjectMocks
    ClientFacadeImpl clientFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Test
    public void testRecupereListeContrat() throws CommonException {
        when(habiliService.rechercherParIdGdi(ID_GDI))
                .thenAnswer((Answer<PersonnePhysique>) invocation -> {
                    PersonnePhysique personne = new PersonnePhysique();
                    personne.setNumeroPersonneEre(NUM_PERS_ERE);
                    return personne;
                });

        PersonnePhysique retour = clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);

        Assert.assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail1() throws Exception {
        when(habiliService.rechercherParIdGdi(Matchers.any()))
                .thenReturn(null);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail2() throws Exception {

        PersonnePhysique user = new PersonnePhysique();
        when(habiliService.rechercherParIdGdi(Matchers.any()))
                .thenReturn(user);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }

    
    @Test
    public void testrechercherPersonnePhysiqueEreParNumeroPersonne() throws CommonException {
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class)))
                .thenAnswer((Answer<PersonnePhysiqueConsult>) invocation -> {
                    PersonnePhysiqueConsult personnePhysique = new PersonnePhysiqueConsult();
                    personnePhysique.setNom(NOM);
                    personnePhysique.setPrenom(PRENOM);
                    personnePhysique.setCivilite(CIVILITE);
                    return personnePhysique;
                });

        PersonnePhysique retour = clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(NUM_PERS_ERE);

        Assert.assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }

    @Test(expected = PartenaireException.class)
    public void testrechercherPersonnePhysiqueEreParNumeroPersonneFail1() throws Exception {
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class)))
                .thenThrow(new TechnicalException("PERSONNE-PHYSIQUE-INEXISTANTE", new Throwable("PERSONNE-PHYSIQUE-INEXISTANTE")));

        clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(ID_GDI);
    }

    @Test
    public void testrechercherPPSilo() throws TechnicalException {
        when(rechercherPP.rechercherPPSilo(Matchers.any())).thenReturn(new RechercherPPSiloResponseDto());

        RechercherPPSiloResponseDto rechercherPPSiloResponseDto = clientFacade.rechercherPPSilo(new DemandeRecherchePP("ID"));

        Assert.assertNotNull(rechercherPPSiloResponseDto);
    }

    @Test
    public void modifierCoordonneesClient() throws TechnicalException {
        UserContext ctx = new UserContext();
        ctx.setSilos(Sets.newHashSet(CodeSiloType.ERE));
        ctx.setIdGdi(ID_GDI);
        when(userContextHolder.get()).thenReturn(ctx);


        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        when(consulterPersonneClient.consulterPersPhys(Matchers.any())).thenReturn(pp);
        
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        ContratComplet contrat = new ContratComplet();
        contrat.setContratHeader(contratHeader);
        contrat.setContratGeneral(new ContratGeneral());
        when(contratFacade.rechercherContratsCompletsERE()).thenReturn(Lists.newArrayList(contrat));

        when(workflowFacade.creerDemandeWorkflow(Matchers.any())).thenReturn(new IdDemSilo());

        
        
        CoordonneesClientDto dto = new CoordonneesClientDto();
        dto.setEmail("EMAIL");
        dto.setTelPortable("0600000000");
        
        Assert.assertNull(clientFacade.modifierCoordonneesClient(dto));
    }
}
