package fr.ag2rlamondiale.ecrs.business.even;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.ICguFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterIdentiteClient;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CguEvenGeneratorTest {

    @InjectMocks
    CguEvenGenerator cguEvenGenerator;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    ICguFacade cguFacade;

    @Mock
    IConsulterIdentiteClient consulterIdentiteClient;

    @Mock
    IConsulterPersonneClient consulterPersonneClient;

    @Test
    public void evaluerEvenementFail() throws Exception {
        UserContext user = new UserContext();
        Partenaire partenaire = new Partenaire();
        user.setPartenaire(partenaire);
        CguDetails cguDetails = new CguDetails();
        partenaire.setCodePartenaire(UserContext.CODE_PARTENAIRE_NIE);
        user.setTemporaryId(1);
        when(cguFacade.getCguDetails()).thenReturn(cguDetails);
        user.setIdGdi("idGdi");
        when(cguFacade.getAcceptedGguIds(user.getIdGdi())).thenThrow(new TechnicalException());
        assertFalse(cguEvenGenerator.evaluerEvenement("numP"));
    }
    
    @Test
    public void evaluerEvenement() throws Exception {
        UserContext user = new UserContext();
        Partenaire partenaire = new Partenaire();
        user.setPartenaire(partenaire);
        CguDetails cguDetails = new CguDetails();
        /////
        when(userContextHolder.get()).thenReturn(user);
        assertFalse(cguEvenGenerator.evaluerEvenement("numP"));
        /////
        partenaire.setCodePartenaire(UserContext.CODE_PARTENAIRE_NIE);
        user.setTemporaryId(1);
        when(cguFacade.getCguDetails()).thenReturn(cguDetails);
        assertTrue(cguEvenGenerator.evaluerEvenement("numP"));
        /////
        user.setIdGdi("idGdi");
        when(cguFacade.getAcceptedGguIds(user.getIdGdi())).thenReturn(Arrays.asList("idCgu"));
        assertTrue(cguEvenGenerator.evaluerEvenement("numP"));
        /////
        cguDetails.setIdCgu("idCgu");
        assertTrue(cguEvenGenerator.evaluerEvenement("numP"));
        /////
        when(cguFacade.getAcceptedGguIds(user.getIdGdi())).thenReturn(Arrays.asList(""));
        when(cguFacade.getAcceptedGguIds(user.getTemporaryId())).thenReturn(Arrays.asList("idCgu"));
        assertFalse(cguEvenGenerator.evaluerEvenement("numP"));
    }

    @Test
    public void prepare() {
        String idGdi = null;
        cguEvenGenerator.prepare(idGdi, "numP", Arrays.asList(new ContratHeader()));

        idGdi = "idGdi";
        doNothing().when(consulterPersonneClient)
                .cacheEvictConsulterPersPhys(Matchers.any(IdSiloDto.class));
        doNothing().when(consulterIdentiteClient).cacheEvictConsulterIdentite(idGdi);
        
        cguEvenGenerator.prepare(null, "numP", Arrays.asList(new ContratHeader()));

        cguEvenGenerator.prepare(idGdi, null, Arrays.asList(new ContratHeader()));

        // appel sans retour
        assertFalse(idGdi.isEmpty());
    }
}
