package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.ecrs.api.secure.EvenementRestController;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.dto.evenement.TypologieAffichageEven;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EvenementRestControllerTest {

    @InjectMocks
    EvenementRestController evenementRestController;

    @Mock
    IEvenementFacade evenementFacade;

    @Test
    public void getNextEven() throws Exception {
        when(evenementFacade.generateNextEvenement(any(), anyBoolean(), anyBoolean())).thenReturn(new EvenementJson());

        EvenementJson json = evenementRestController.getNextEven(TypologieAffichageEven.POPIN);

        assertNotNull(json);
    }

    @Test
    public void update() {
        EvenementJson init = new EvenementJson();
        when(evenementFacade.updateEvenement(any(EvenementJson.class))).thenReturn(new EvenementJson());

        EvenementJson json = evenementRestController.update(init);

        assertNotNull(json);
    }

    @Test
    public void cancel() {
        EvenementJson init = new EvenementJson();
        when(evenementFacade.updateEvenement(init)).thenReturn(init);

        EvenementJson json = evenementRestController.cancel(init);

        assertNotNull(json);
    }

    @Test
    public void terminate() {
        EvenementJson init = new EvenementJson();
        when(evenementFacade.updateEvenement(init)).thenReturn(init);

        EvenementJson json = evenementRestController.terminate(init);

        assertNotNull(json);
    }
}
