package fr.ag2rlamondiale.ecrs.business.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import fr.ag2rlamondiale.trm.client.rest.ICguRestClient;
import fr.ag2rlamondiale.trm.client.soap.IConsulterIdentiteClient;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import fr.ag2rlamondiale.trm.domain.gdi.IdentiteDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;

@RunWith(MockitoJUnitRunner.class)
public class CguFacadeImplTest {

    @InjectMocks
    CguFacadeImpl cguFacadeImpl;

    @Mock
    ICguRestClient cguRestClient; 
    
    @Mock
    UserContextHolder userContextHolder;
    
    @Mock
    IConsulterIdentiteClient consulterIdentiteClient;
    @Test
    public void getCguDetails() {
        when(cguRestClient.getCguDetails()).thenReturn(new CguDetails());
        
        assertNotNull(cguFacadeImpl.getCguDetails());
    }
    
    @Test
    public void getAcceptedGguIdsString() throws Exception {
        IdentiteDto dto = new IdentiteDto();
        dto.setIdCguValides(Arrays.asList("1"));
        when(consulterIdentiteClient.consulterIdentite("")).thenReturn(dto);
        assertFalse(cguFacadeImpl.getAcceptedGguIds("").isEmpty());
    }
    
    @Test
    public void getAcceptedGguIdsInteger() {
        when(cguRestClient.getAcceptedGguIds(1)).thenReturn(new ArrayList<>());
        assertTrue(cguFacadeImpl.getAcceptedGguIds(1).isEmpty());
    }
    
    @Test
    public void createAcceptationCgu() {
        UserContext user = new UserContext();
        user.setTemporaryId(1);
        when(userContextHolder.get()).thenReturn(user);
        when(cguRestClient.createAcceptationCgu(1, "")).thenReturn(true);
        assertTrue(cguFacadeImpl.createAcceptationCgu(""));
    }
}
