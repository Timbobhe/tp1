package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.dto.ClientDto;
import fr.ag2rlamondiale.ecrs.utils.MockUserContext;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContext;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashSet;
import java.util.Set;

@RunWith(MockitoJUnitRunner.class)
public class ClientMapperTest {
    
    ClientMapper clientMapper = new ClientMapperImpl();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void should_map_userContext_to_clientDto() {
        UserContext userContext = mockUserContext();

        ClientDto clientDto = clientMapper.map(userContext);

        Assert.assertNotNull(clientDto);
    }

    @Test
    public void should_map_userContext_to_clientDto_2() {
        UserContext userContext = new MockUserContext();

        ClientDto clientDto = clientMapper.map(userContext);

        Assert.assertNotNull(clientDto);
        Assert.assertNull(clientDto.getInfosBlocagesClient());
        Assert.assertNull(clientDto.getPartenaire());
        Assert.assertNotNull(clientDto.getSilos());
        Assert.assertTrue(clientDto.getSilos().isEmpty());
    }

    @Test
    public void should_not_map_userContext_to_clientDto() {
        ClientDto clientDto = clientMapper.map((UserContext) null);

        Assert.assertNull(clientDto);
    }

    private UserContext mockUserContext() {
        MockUserContext userContext = new MockUserContext();
        Set<CodeSiloType> silos = new HashSet<>();
        silos.add(CodeSiloType.ERE);
        userContext.setSilos(silos);
        userContext.setNumeroPersonneEre("P123456");
        userContext.setPartenaire(new Partenaire());
        userContext.setInfosBlocagesClient(new InfosBlocagesClient());
        return userContext;
    }
}
