package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Test;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import static junit.framework.TestCase.*;

public class TriggeringResultsTest {

    @Test
    public void test_list() {
        TriggeringResults results1 = new TriggeringResults();
        assertTrue(results1.isEmpty());
        assertFalse(results1.stream().findFirst().isPresent());
        assertFalse(results1.iterator().hasNext());

        TriggeringResults results2 = new TriggeringResults();
        results2.add(new TriggeringResult());
        assertFalse(results2.isEmpty());
        assertTrue(results2.stream().findFirst().isPresent());
        assertTrue(results2.iterator().hasNext());

        TriggeringResults results3 = new TriggeringResults();
        results3.add(null, "idGdi", "numPerson", new TypeEvenementJson("TYPE"));
        assertFalse(results3.isEmpty());
        assertTrue(results3.stream().findFirst().isPresent());
        assertTrue(results3.iterator().hasNext());

        TriggeringResults results4 = new TriggeringResults();
        final NullGene generator = new NullGene();
        results4.add(generator, "idGdi", "numPerson", new TypeEvenementJson("TYPE"), null);
        results4.add(generator, "idGdi", "numPerson", new TypeEvenementJson("TYPE"), null);
        AtomicInteger counter = new AtomicInteger();
        results4.forEachGenerator(g -> {
            counter.getAndIncrement();
            assertEquals(generator, g);
        });
        assertEquals(1, counter.get());
    }

    static class NullGene extends AbstractEvenGenerator {

        @Override
        public EvenementJson generateNextEven(TriggeringResult result) {
            return null;
        }

        @Override
        public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {

        }
    }
}
