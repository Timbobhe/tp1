package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.dto.versementsynthese.OperationVersementDto;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class OperationToOperationVersementDtoMapperTest {

    OperationToOperationVersementDtoMapper mapper = new OperationToOperationVersementDtoMapperImpl();

    @Test
    public void should_map_operation_to_operationVersementDto() {
        Operation operation = new Operation();
        operation.setDate(DateUtils.createDate(6, 4, 2021));

        OperationVersementDto operationVersementDto = mapper.operationToDto(operation);

        Assert.assertNotNull(operationVersementDto);

    }
}
