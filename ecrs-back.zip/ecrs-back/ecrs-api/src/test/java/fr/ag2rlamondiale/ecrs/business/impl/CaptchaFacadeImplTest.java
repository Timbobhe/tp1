package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseDto;
import fr.ag2rlamondiale.ecrs.dto.verificationCaptcha.VerificationCaptchaResponseJson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CaptchaFacadeImplTest {

	@InjectMocks
    CaptchaFacadeImpl captchaFacade;

	@Mock
	private RestTemplate restTemplate;

	@Before
	public void init() {
		ReflectionTestUtils.setField(captchaFacade, "restTemplate", restTemplate);
		ReflectionTestUtils.setField(captchaFacade, "proxyActive", false);
		ReflectionTestUtils.setField(captchaFacade, "recaptchaSecret", "6Ldgm-EUAAAAAPoYUDiiR0HIM9pX1rc3g4Nv5AOw");
		ReflectionTestUtils.setField(captchaFacade, "recaptchaVerifyUrl",
				"https://www.google.com/recaptcha/api/siteverify");
	}

	@Test
	public void isValidTest() throws RestClientException {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
		param.add("secret", "6Ldgm-EUAAAAAPoYUDiiR0HIM9pX1rc3g4Nv5AOw");
		param.add("response",
				"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		when(restTemplate.postForObject("https://www.google.com/recaptcha/api/siteverify", param,
				VerificationCaptchaResponseJson.class)).thenReturn(new VerificationCaptchaResponseJson());
		boolean res = captchaFacade.isValid(
				"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		assertFalse(res);
	}

	@Test
	public void isValidExceptionTest() throws RestClientException {
		MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
		param.add("secret", "6Ldgm-EUAAAAAPoYUDiiR0HIM9pX1rc3g4Nv5AOw");
		param.add("response",
				"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		when(restTemplate.postForObject("https://www.google.com/recaptcha/api/siteverify", param,
				VerificationCaptchaResponseJson.class)).thenReturn(new VerificationCaptchaResponseJson());
		try {
			captchaFacade.isValid(
					"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		} catch (RestClientException e) {
			fail();
		}
	}

	@Test
	public void verifyTokenTest() {
		VerificationCaptchaResponseDto expected = new VerificationCaptchaResponseDto();
		expected.setMessage("Invalid captcha");
		expected.setStatus(400);
		MultiValueMap<String, String> param = new LinkedMultiValueMap<>();
		param.add("secret", "6Ldgm-EUAAAAAPoYUDiiR0HIM9pX1rc3g4Nv5AOw");
		param.add("response",
				"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		when(restTemplate.postForObject("https://www.google.com/recaptcha/api/siteverify", param,
				VerificationCaptchaResponseJson.class)).thenReturn(new VerificationCaptchaResponseJson());
		VerificationCaptchaResponseDto actual = captchaFacade.verifyToken(
				"03AHaCkAa6CNLTzrnmk2a8zbmKVXP8b2Qg0jqe24bR1xd-Hgaw54xhuqODdpzfLJ3j_vUhYivFsLE5mvpdb0L_NiKFtEmM5UnI3h1f18ANuwi6hzcZ_XybjVLOAYfJwZFyh8OmU13OFcm04EjHFTxTF9KKDZot9Dqf_74G_POZ-Ybx44-Gylx2nsuNOyVieKlqWifcyumreElDY4edp0J1t6Yt4OdSf4KGDaKwK1nZzCGCBTDh48ykKRmcNtqGisnH3BXivgt45DKL7SL4IE06k8dg3hgy5JWnqSJTrJNYVf_nBdr81-I_fDtC00FjVgG_CwTpM333cl6BTOHZZEQEBaEQC-INo4Mn2qbGAk-j-Ek-VDDOFixCjr8GHsq88VYQ7z7xEdfJkSAF");
		assertEquals(expected, actual);
	}
}
