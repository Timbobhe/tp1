package fr.ag2rlamondiale.ecrs.dto.simulateur;

import fr.ag2rlamondiale.trm.domain.FiscaliteType;
import org.junit.Test;

import static org.junit.Assert.*;

public class FiscaliteSimuTypeTest {

    @Test
    public void test_should_return_good_fiscalite_simu() throws Exception {
        assertEquals(FiscaliteSimuType.ART83, FiscaliteSimuType.from(FiscaliteType.ART83));
        assertEquals(FiscaliteSimuType.MADELIN, FiscaliteSimuType.from(FiscaliteType.FISCMAD));
        assertEquals(FiscaliteSimuType.PERP, FiscaliteSimuType.from(FiscaliteType.PERP));
    }

    @Test
    public void test_should_return_null_when_fiscalite_not_simu() throws Exception {
        assertNull(FiscaliteSimuType.from(FiscaliteType.FISCDSK));
    }
}
