package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EtatTraitementType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.evenement.ModeActionEvtType.OBLI;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class OnboardingEvenGeneratorTest {

    @InjectMocks
    OnboardingEvenGenerator generator;

    @Test
    public void test_evaluerEvenement() {
        assertTrue(generator.evaluerEvenement("NUMPERSONNE"));
    }

    @Test
    public void test_prepare() {
        try {
            generator.prepare("IDGDI", "NUMPERSONNE", new ArrayList<>(0));
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testDeclenchement_historiqueVide() {
        // GIVEN
        final TypeEvenementJson onbr = new TypeEvenementJson(TypeEven.ONBOARDING.getCode());
        onbr.setModeAction(OBLI);
        onbr.setNbDeclenchementsMaxPeriode(null);
        onbr.setDelaiAvantReactivation(null);

        final List<EvenementJson> historiqueEvens = new ArrayList<>();
        final TriggeringResults results = new TriggeringResults();
        final ArrayList<ContratHeader> contrats = new ArrayList<>(0);

        // WHEN
        generator.testDeclenchement("IDGDI", "NUMPERSONNE", onbr, contrats, historiqueEvens, results);

        // THEN
        assertFalse(results.isEmpty());
    }

    @Test
    public void testDeclenchement_historiqueNonVide() {
        // GIVEN
        final TypeEvenementJson onbr = new TypeEvenementJson(TypeEven.ONBOARDING.getCode());
        onbr.setModeAction(OBLI);
        onbr.setNbDeclenchementsMaxPeriode(null);
        onbr.setDelaiAvantReactivation(null);

        final List<EvenementJson> historiqueEvens = new ArrayList<>();
        historiqueEvens.add(EvenementJson.builder().typeEvenement(new TypeEvenementJson("ERE_CONF")).build());

        final TriggeringResults results = new TriggeringResults();
        final ArrayList<ContratHeader> contrats = new ArrayList<>(0);

        // WHEN
        generator.testDeclenchement("IDGDI", "NUMPERSONNE", onbr, contrats, historiqueEvens, results);

        // THEN
        assertTrue(results.isEmpty());
    }

    @Test
    public void testDeclenchement_historiqueNonVide_ONBR_NONTRAITE() {
        // GIVEN
        final TypeEvenementJson onbr = new TypeEvenementJson(TypeEven.ONBOARDING.getCode());
        onbr.setModeAction(OBLI);
        onbr.setNbDeclenchementsMaxPeriode(null);
        onbr.setDelaiAvantReactivation(null);

        final List<EvenementJson> historiqueEvens = new ArrayList<>();
        historiqueEvens.add(EvenementJson.builder().typeEvenement(new TypeEvenementJson(TypeEven.ONBOARDING.getCode())).build());

        final TriggeringResults results = new TriggeringResults();
        final ArrayList<ContratHeader> contrats = new ArrayList<>(0);

        // WHEN
        generator.testDeclenchement("IDGDI", "NUMPERSONNE", onbr, contrats, historiqueEvens, results);

        // THEN
        assertFalse(results.isEmpty());
    }

    @Test
    public void testDeclenchement_historiqueNonVide_ONBR_TRAITE() {
        // GIVEN
        final TypeEvenementJson onbr = new TypeEvenementJson(TypeEven.ONBOARDING.getCode());
        onbr.setModeAction(OBLI);
        onbr.setNbDeclenchementsMaxPeriode(null);
        onbr.setDelaiAvantReactivation(null);

        final List<EvenementJson> historiqueEvens = new ArrayList<>();
        historiqueEvens.add(EvenementJson.builder()
                .typeEvenement(new TypeEvenementJson(TypeEven.ONBOARDING.getCode()))
                .etatTraitement(EtatTraitementType.TRAI)
                .build());

        final TriggeringResults results = new TriggeringResults();
        final ArrayList<ContratHeader> contrats = new ArrayList<>(0);

        // WHEN
        generator.testDeclenchement("IDGDI", "NUMPERSONNE", onbr, contrats, historiqueEvens, results);

        // THEN
        assertTrue(results.isEmpty());
    }
}
