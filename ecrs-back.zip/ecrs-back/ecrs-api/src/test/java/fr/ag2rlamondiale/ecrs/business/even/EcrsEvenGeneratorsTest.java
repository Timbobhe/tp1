package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static junit.framework.TestCase.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

public class EcrsEvenGeneratorsTest {

    private EreConfEvenGenerator ereConfEvenGenerator;
    private ErePND3EvenGenerator erePND3EvenGenerator;
    private ErePND1EvenGenerator erePND1EvenGenerator;
    private EreVdppEvenGenerator ereVdppEvenGenerator;
    private CguEvenGenerator cguEvenGenerator;

    @InjectMocks
    private EcrsEvenGenerators generators;

    @Before
    public void init() {
        this.ereConfEvenGenerator = mock(EreConfEvenGenerator.class);
        this.erePND3EvenGenerator = mock(ErePND3EvenGenerator.class);
        this.erePND1EvenGenerator = mock(ErePND1EvenGenerator.class);
        this.ereVdppEvenGenerator = mock(EreVdppEvenGenerator.class);
        this.cguEvenGenerator = mock(CguEvenGenerator.class);

        generators = new EcrsEvenGenerators();
        MockitoAnnotations.initMocks(this);
        
        generators.afterPropertiesSet();
    }

    @Test
    public void test_getEvenGenerator() {
        final List<String> typesEven =
                Arrays.asList("PRT_CGU", "ERE_CONF", "ERE_PND_3", "ERE_PND_1", "ERE_VDPP");

        typesEven.forEach(type -> assertNotNull(generators.getEvenGenerator(type)));

        assertNull(generators.getEvenGenerator("CODE_INCONNU"));
    }

    @Test
    public void test_getEvenGenerator_sousListe() {
        final List<String> typesEven = Arrays.asList("PRT_CGU", "ERE_CONF", "ERE_VDPP");

        typesEven.forEach(type -> assertNotNull(generators.getEvenGenerator(type)));

        assertNull(generators.getEvenGenerator("CODE_INCONNU"));
    }

    @Test
    public void test_generate_sousListe_NULL() throws Exception {

        final List<TypeEvenementJson> typesEven =
                Stream.of("PRT_CGU", "ERE_CONF", "ERE_BIA", "ERE_VDPP").map(TypeEvenementJson::new)
                        .collect(Collectors.toList());

        MockitoAnnotations.initMocks(this);

        Collection<ContratHeader> contrats = new ArrayList<>();
        List<EvenementJson> historiqueEvens = new ArrayList<>();
        final EvenementJson even =
                generators.generateNextEven(typesEven, "idGdi", "numPersonne", contrats, historiqueEvens);

        assertNull(even);
    }

    @Test
    public void test_generate_sousListe_Dernier() {

        final List<TypeEvenementJson> typesEven =
                Stream.of("PRT_CGU", "ERE_CONF", "ERE_BIA", "ERE_VDPP").map(TypeEvenementJson::new)
                        .collect(Collectors.toList());

        when(ereVdppEvenGenerator.generateNextEven(any()))
                .thenReturn(new EvenementJson(new TypeEvenementJson("ERE_VDPP")));

        doAnswer(invocation -> {
            TriggeringResults results = invocation.getArgument(5);
            results.add(ereVdppEvenGenerator, "idGdi", "numPersonne", new TypeEvenementJson("ERE_VDPP"));
            return null;
        }).when(ereVdppEvenGenerator).testDeclenchement(any(), any(), any(), any(), any(), any());

        MockitoAnnotations.initMocks(this);
        assertNotNull(ereVdppEvenGenerator.generateNextEven(null));

        Collection<ContratHeader> contrats = new ArrayList<>();
        List<EvenementJson> historiqueEvens = new ArrayList<>();
        final EvenementJson even =
                generators.generateNextEven(typesEven, "idGdi", "numPersonne", contrats, historiqueEvens);

        assertEquals("ERE_VDPP", even.getTypeEvenement().getCodeEvenement());
    }

    @Test
    public void test_generate_sousListe() {

        final List<TypeEvenementJson> typesEven =
                Stream.of("PRT_CGU", "ERE_CONF", "ERE_BIA", "ERE_VDPP").map(TypeEvenementJson::new)
                        .collect(Collectors.toList());

        doAnswer(invocation -> {
            TriggeringResults results = invocation.getArgument(5);
            results.add(cguEvenGenerator, "idGdi", "numPersonne", new TypeEvenementJson("PRT_CGU"));
            return null;
        }).when(cguEvenGenerator).testDeclenchement(any(), any(), any(), any(), any(), any());

        when(cguEvenGenerator.generateNextEven(any()))
                .then(invocation -> new EvenementJson(new TypeEvenementJson("PRT_CGU")));

        MockitoAnnotations.initMocks(this);

        Collection<ContratHeader> contrats = new ArrayList<>();
        List<EvenementJson> historiqueEvens = new ArrayList<>();
        final EvenementJson even =
                generators.generateNextEven(typesEven, "idGdi", "numPersonne", contrats, historiqueEvens);

        assertEquals("PRT_CGU", even.getTypeEvenement().getCodeEvenement());
    }


}
