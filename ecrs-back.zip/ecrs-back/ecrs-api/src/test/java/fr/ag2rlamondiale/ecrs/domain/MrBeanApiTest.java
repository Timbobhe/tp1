package fr.ag2rlamondiale.ecrs.domain;

import fr.ag2rlamondiale.ecrs.config.ApiConfig;
import fr.ag2rlamondiale.ecrs.business.even.AbstractEvenGenerator;
import fr.ag2rlamondiale.ecrs.business.even.TriggeringResult;
import fr.ag2rlamondiale.ecrs.business.even.TriggeringResults;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.BasicInfoParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.InfoArbitrageContratDto;
import fr.ag2rlamondiale.ecrs.dto.bia.InfoBiaContratDto;
import fr.ag2rlamondiale.ecrs.dto.onboarding.OnboardingStartDto;
import fr.ag2rlamondiale.ecrs.dto.versement.InfoVersementContratDto;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.ecrs.dto.contrat.ContratClientDto;
import fr.ag2rlamondiale.trm.testing.MrBeanTester;
import org.junit.Test;

import java.util.Collection;
import java.util.List;

import static org.junit.Assert.*;

public class MrBeanApiTest {

    @Test
    public void testApiBean() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addClasses("fr.ag2rlamondiale.ecrs.domain", ApiConfig.class);
        beanTester.addClasses("fr.ag2rlamondiale.ecrs.dto", ApiConfig.class);
        beanTester.setPropsHashEquals(ContratClientDto.class, "codeSilo", "id", "idAdherente", "idContractante", "idCollege");
        beanTester.addClassExclusion(OnboardingStartDto.class, BasicInfoParcoursDto.class, InfoArbitrageContratDto.class, InfoBiaContratDto.class, InfoVersementContratDto.class);
        beanTester.test();
        assertNotNull(beanTester);
    }

    @Test
    public void test_TriggeringResult() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addFactory(AbstractEvenGenerator.class, () -> new AbstractEvenGenerator() {
            @Override
            public EvenementJson generateNextEven(TriggeringResult result) {
                return null;
            }

            @Override
            public void testDeclenchement(String idGdi, String numPersonne, TypeEvenementJson typeEven,
                                          Collection<ContratHeader> contrats, List<EvenementJson> historiqueEvens, TriggeringResults results) {

            }
        });
        beanTester.fullTester(TriggeringResult.class);
        assertNotNull(beanTester);
    }

    private MrBeanTester newMrBeanTester() {
        MrBeanTester beanTester = new MrBeanTester();
        beanTester.setClassPredicate(
                beanTester.getClassPredicate().and(clazz -> !clazz.getSimpleName().endsWith("MapperImpl")));

        return beanTester;
    }

}
