package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArretVersementFacade;
import fr.ag2rlamondiale.ecrs.dto.MessageDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementStartDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.InfoArretVersementContrat;
import fr.ag2rlamondiale.trm.domain.accessibilite.AccesFonctionnaliteDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT;
import static fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage.BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ArretVersementAccessibilitySupplierTest {

    @Mock
    IArretVersementFacade arretVersementFacade;

    @InjectMocks
    ArretVersementAccessibilitySupplier arretVersementAccessibilitySupplier;

    @Test
    public void checkAccessibityArretVersementTest_un_seul_contrat_bloque() throws TechnicalException {
        // Given
        InfoArretVersementContrat infoContrat1 = InfoArretVersementContrat.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS.name()).build()).build();
        InfoArretVersementContrat infoContrat2 = InfoArretVersementContrat.builder().bloque(false).raisonBlocage(null).build();
        List<InfoArretVersementContrat> infos = Arrays.asList(infoContrat1, infoContrat2);
        ArretVersementStartDto arretVersementStartDto = ArretVersementStartDto.builder().infos(infos).sigElecOff(false).build();

        // When
        when(arretVersementFacade.startArretVersement()).thenReturn(arretVersementStartDto);

        // Then
        AccesFonctionnaliteDto accessibility = arretVersementAccessibilitySupplier.check();
        assertTrue(accessibility.isAccessible());
        assertNull(accessibility.getRaison());
    }

    @Test
    public void checkAccessibityArretVersementTest_tout_contrat_bloque() throws TechnicalException {
        // Given
        InfoArretVersementContrat infoContrat1 = InfoArretVersementContrat.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS.name()).build()).build();
        InfoArretVersementContrat infoContrat2 = InfoArretVersementContrat.builder().bloque(true).raisonBlocage(MessageDto.builder().jahiaDicoEntry(BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS.name()).build()).build();
        List<InfoArretVersementContrat> infos = Arrays.asList(infoContrat1, infoContrat2);
        ArretVersementStartDto arretVersementStartDto = ArretVersementStartDto.builder().infos(infos).sigElecOff(false).build();

        // When
        when(arretVersementFacade.startArretVersement()).thenReturn(arretVersementStartDto);

        // Then
        AccesFonctionnaliteDto accessibility = arretVersementAccessibilitySupplier.check();
        assertFalse(accessibility.isAccessible());
        assertNotNull(accessibility.getRaison());
        assertEquals(BLOCAGE_DEM_ARRET_VERSEMENT_EN_COURS.name(), accessibility.getRaison());
    }


    @Test
    public void checkAccessibityArretVersementTest_aucun_versement_programme() throws TechnicalException {
        // Given
        List<InfoArretVersementContrat> infos = new ArrayList<InfoArretVersementContrat>();
        ArretVersementStartDto arretVersementStartDto = ArretVersementStartDto.builder().infos(infos).sigElecOff(false).build();

        // When
        when(arretVersementFacade.startArretVersement()).thenReturn(arretVersementStartDto);

        // Then
        AccesFonctionnaliteDto accessibility = arretVersementAccessibilitySupplier.check();
        assertFalse(accessibility.isAccessible());
        assertNotNull(accessibility.getRaison());
        assertEquals(ARRET_VERSEMENT_BLOCAGE_CONDITIONS_CONTRAT.name(), accessibility.getRaison());
    }
}
