package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArbitrageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageTerminateDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class ArbitrageRestControllerTest {
    @Mock
    IArbitrageFacade arbitrageFacade;

    @Mock
    private IContratFacade contratFacade;

    @InjectMocks
    @Spy
    ArbitrageRestController arbitrageRest;

    @Test
    public void startModificationArbitrageTest() throws TechnicalException {
        arbitrageRest.start(null);
        verify(arbitrageRest, times(1)).start(null);
    }

    @Test
    public void questionTest() throws TechnicalException {
        arbitrageRest.question(null);
        verify(arbitrageRest, times(1)).question(null);
    }

    @Test
    public void resolveQuestionOrNextTest()throws TechnicalException{
        arbitrageRest.resolveQuestionOrNext(null);
        verify(arbitrageRest, times(1)).resolveQuestionOrNext(null);
    }

    @Test
    public void terminate() throws TechnicalException, JAXBException, IOException {
        arbitrageRest.terminate(new ArbitrageTerminateDto(), false);

        verify(arbitrageFacade, times(1)).terminate(any(ArbitrageTerminateDto.class), Matchers.eq(false));
    }


}
