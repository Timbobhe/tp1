package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverTotalPartielMDPTest {

    @InjectMocks
    ArbitrageQuestionResolverTotalPartielMDP arbitrageQuestionResolverTotalPartielMDP;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IStructureInvFacade structureInvFacade;


    public ContratHeader prepare() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(false, false);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenAnswer(invocation -> buildStructInv(invocation.getArgument(0)));
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare();

        final ArbitrageContexteDto contexte = ArbitrageContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .responseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)
                .build();

        assertTrue(arbitrageQuestionResolverTotalPartielMDP.accept(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, contexte));
    }

    @Test
    public void test_repartitionStock() throws Exception {
        final ContratHeader contratHeader = prepare();

        final ArbitrageContexteDto contexte = ArbitrageContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .responseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)
                .build();

        final QuestionResponsesDto<QuestionType.ResponseArbitrageTotalPartielType, ?> resolved = arbitrageQuestionResolverTotalPartielMDP.resolve(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_PARTIEL)));
    }

    @Test
    public void test_repartitionFlux() throws Exception {
        final ContratHeader contratHeader = prepare();

        final ArbitrageContexteDto contexte = ArbitrageContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .responseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX)
                .build();

        final QuestionResponsesDto<QuestionType.ResponseArbitrageTotalPartielType, ?> resolved = arbitrageQuestionResolverTotalPartielMDP.resolve(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL);
    }

    @Test
    public void test_repartitionFluxStock() throws Exception {
        final ContratHeader contratHeader = prepare();

        final ArbitrageContexteDto contexte = ArbitrageContexteDto.builder()
                .contratSelectionne(contratHeader.getContratId())
                .responseFluxStockType(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK)
                .build();

        final QuestionResponsesDto<QuestionType.ResponseArbitrageTotalPartielType, ?> resolved = arbitrageQuestionResolverTotalPartielMDP.resolve(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_TOTALPARTIEL, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageTotalPartielType.ARBITRAGE_TOTAL);
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean allowDifferentInvestmentsForVif) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.MDP);
        contratHeader.setPacte(isPacte);
        contratHeader.addCompartiment(Compartiment.builder().type(CompartimentType.C1).build());

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private StructInv buildStructInv(ContratHeader contratHeader) {
        StructInv structInv = new StructInv();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), contratHeader.isPacte());
            final List<ContributionInv> contributionInvs = contributionTypes.stream().map(contributionType -> {
                ContributionInv contributionInv = new ContributionInv();
                contributionInv.setType(contributionType);
                contributionInv.setIndicateurTauxDerogeable(true);
                contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
                return contributionInv;
            }).collect(Collectors.toList());
            structInv.addContributions(contributionInvs);
        }

        return structInv;
    }
}
