package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import com.ag2r.common.exceptions.TechnicalException;
import com.alm.esb.service.gestoperation_1.rechercheroperations_1.RechercherOperationsResponseType;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.versement.PrelevementCodeSituationType;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.parametre.ParametreMapper;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.operations.RechercherOperationsResponseMapperImpl;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.operation.OperationDetailDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.structinv.IdDansSiloDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.powermock.reflect.Whitebox;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_PASS;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SimulateurFiscalCalculArt83Test {
    private static final String YEAR_START = "-01-01";
    private static final String YEAR_END = "-12-31";
    private static final String DATE_FORMAT = "yyyy-MM-dd";

    private static final String FILEPATH_MOCK = "/xml/RechercherOperations_response_Simulateur.xml";

    @InjectMocks
    SimulateurFiscalCalculArt83 simulateurFiscalFacade;

    @InjectMocks
    private RechercherOperationsResponseMapperImpl ereMapper;

    @Spy
    private CalculDisponibleCommand calculDispoFiscalCommand;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IEcheancierFacade echeancierFacade;

    @Mock
    IOperationFacade operationFacade;

    @Mock
    IOperationsClient operationClient;

    @Mock
    IBlocageFacade blocageFacade;

    @Mock
    RequestContextHolder requestContextHolder;

    @Mock
    ContratVifHelper contratVifHelper;

    @Mock
    ContratParcoursMapper contratParcoursMapper;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Mock
    private ParametreMapper parametreMapper;

    @Spy
    private DateMapper dateMapper;

    @Spy
    private CalculVersementsComplementairesCommand calculVersComplCommand;

    @Spy
    private CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Spy
    private CalculEconomieFiscaleCommand calculGainFiscalCommand;

    @Spy
    private CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Test
    public void getVersementsProgrammesTest() throws Exception {
        // Given
        ContratHeader contrat = createContratHeader("C1", "990876", CodeSiloType.ERE);
        Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
        List<Echeancier> echeanciers = getEcheanciers();
        // When
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contrat);
        when(echeancierFacade.rechercherEcheanciers(c1)).thenReturn(echeanciers);
        when(echeancierFacade.consulterEcheancier(c1, "12")).thenReturn(echeanciers.get(0));
        // Then
        ContratId contratId = new ContratId();
        contratId.setCodeSilo(CodeSiloType.ERE);
        contratId.setIdAdherente("");
        contratId.setIdContractante("S4164948");
        contratId.setNomContrat("RG151236289");
        Echeancier resultat = Whitebox.invokeMethod(simulateurFiscalFacade, "getVersementsProgrammes", contratId);
        assertNotNull(resultat);

    }

    @Test
    public void getVersementsProgrammesTestNull() throws Exception {
        // Given
        ContratHeader contrat = createContratHeader("C1", "990876", CodeSiloType.ERE);
        Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
        // When
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contrat);
        when(echeancierFacade.rechercherEcheanciers(c1)).thenReturn(Collections.emptyList());
        // Then
        ContratId contratId = new ContratId();
        contratId.setCodeSilo(CodeSiloType.ERE);
        contratId.setIdAdherente("");
        contratId.setIdContractante("S4164948");
        contratId.setNomContrat("RG151236289");
        Echeancier resultat = Whitebox.invokeMethod(simulateurFiscalFacade, "getVersementsProgrammes", contratId);
        assertNull(resultat);

    }


    private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
        contrat.setCompartiments(Collections.singletonList(c1));
        return contrat;
    }

    private List<Echeancier> getEcheanciers() {
        Echeancier ech1 = new Echeancier();
        ech1.setCodeFractionnement("M");
        ech1.setMontant(BigDecimal.valueOf(500));
        ech1.setEcheancierId(BigInteger.valueOf(12));
        ech1.setDateFin(new Date());
        Prelevement prelevement = new Prelevement();
        prelevement.setCodeSituationPrelevement(PrelevementCodeSituationType.TRANS.name());
        prelevement.setDatePrelevement(DateUtils.createDate(10, 1, 2021));
        ech1.setPrelevements(Collections.singletonList(prelevement));
        Echeancier ech2 = new Echeancier();
        ech2.setCodeFractionnement("M");
        ech2.setMontant(BigDecimal.valueOf(500));
        ech2.setDateFin(null);
        ech1.setDateFin(new Date());
        Prelevement prelevement1 = new Prelevement();
        prelevement1.setCodeSituationPrelevement(PrelevementCodeSituationType.TRANS.name());
        prelevement1.setDatePrelevement(DateUtils.createDate(10, 1, 2021));
        ech2.setEcheancierId(BigInteger.valueOf(12));
        return Arrays.asList(ech1, ech2);
    }

    @Test
    public void getVersementsLibresTest() throws Exception {
        final Date dateDebut = DateUtils.createDate(1, 1, 2021);
        final Date dateFin = DateUtils.createDate(31, 12, 2021);
        when(operationFacade.getOperationsVIFERE("990876", dateDebut, dateFin))
                .thenReturn(getOperations());

        when(operationClient.consulterStructInvestOperations(any(IdDansSiloDto.class))).thenReturn(createOperationDetailDto());
        BigDecimal result = Whitebox.invokeMethod(simulateurFiscalFacade, "getTotalVIFs", "990876", dateDebut, dateFin);
        assertEquals(BigDecimal.valueOf(1000), result);
    }


    private List<Operation> getOperations() {
        Operation operation1 = new Operation();
        operation1.setId("144910652");
        operation1.setMontant(BigDecimal.valueOf(200));
        operation1.setDate(DateUtils.createDate(6, 4, 2021));
        Operation operation2 = new Operation();
        operation2.setId("144910651");
        operation2.setMontant(BigDecimal.valueOf(500));
        operation2.setDate(DateUtils.createDate(2, 8, 2021));
        List<Operation> list = new ArrayList<>();
        list.add(operation1);
        list.add(operation2);
        return list;
    }


    @Test
    public void testCalculDisponibleFiscalGlobal() throws TechnicalException {
        // Given
        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();
        List<Operation> listOperations = getListOperationsFromResourceFile();

        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.ERE)
                .build();
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(11));
        demandeCalcul.setAbondement(BigDecimal.valueOf(4400));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(40000));
        demandeCalcul.setContrat(contratId);
        ContratHeader contratHeader = createContratHeader("id", "281134", CodeSiloType.ERE);

        int anneeMoinsUn = demandeCalcul.getYear() - 1;
        final Date dateDebutCotisations = DateUtils.parseDate(anneeMoinsUn + YEAR_START, DATE_FORMAT);
        final Date dateFinCotisations = DateUtils.parseDate(anneeMoinsUn + YEAR_END, DATE_FORMAT);
        // When
        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet());

        Mockito.when(operationFacade.getOperationsCotisationsBrutesERE("281134", dateDebutCotisations,
                                                                       dateFinCotisations))
               .thenReturn(listOperations.stream().filter(
                                                 op -> ("RCP".equals(op.getCodeTypeOperation()) || "RCN".equals(op.getCodeTypeOperation())))
                                                  .collect(Collectors.toList()));

        Mockito.when(operationFacade.getOperationsCotisationsCETERE("281134", dateDebutCotisations,
                                                                    dateFinCotisations))
               .thenReturn(listOperations.stream().filter(op -> "RPX_19".equals(op.getCodeTypeOperation()))
                                                  .collect(Collectors.toList()));

        // THEN
        ResultatCalculEpargne resultatCalcul = simulateurFiscalFacade.calculerDisponibleFiscal(demandeCalcul);

        // Assert
        assertEquals(BigDecimal.valueOf(4400), resultatCalcul.getDejaVerse());
        assertEquals(BigDecimal.valueOf(4140.0), resultatCalcul.getPlafondVersement());

    }

    private OperationDetailDto createOperationDetailDto() {


        OperationDetailDto operationDetailDto1 = new OperationDetailDto();
        operationDetailDto1.setOperationId("OPERATIONID");
        operationDetailDto1.setMontantNet(BigDecimal.valueOf(87));
        operationDetailDto1.setCodeTypeOperation("AF");
        operationDetailDto1.setLibTypeOperation("Actif");
        operationDetailDto1.setIdStructureInvestissement("PARENT");
        operationDetailDto1.setMontantBrut(BigDecimal.valueOf(500));
        return operationDetailDto1;

    }

    private ContratComplet createContratComplet() {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        Compartiment compartiment = new Compartiment();
        compartiment.setContratHeader(contratHeader);
        compartiment.setType(CompartimentType.C1);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setCompartiments(Collections.singletonList(compartiment));

        CompteEncours compteEncours = buildCompteEncours(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto1 = new OccurStructInvDto();
        SupportInvDto supportInvDto = new SupportInvDto();
        supportInvDto.setIdSupportInv("13132");
        occurStructInvDto1.setSupportInv(supportInvDto);
        occurStructInvDto1.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto2 = new OccurStructInvDto();
        occurStructInvDto2.setSupportInv(supportInvDto);
        occurStructInvDto2.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        List<OccurStructInvDto> occurStructInvDtos = new ArrayList<>();
        occurStructInvDtos.add(occurStructInvDto1);
        occurStructInvDtos.add(occurStructInvDto2);
        compteEncours.setOccurStructInvList(occurStructInvDtos);

        contratComplet.setEncours(new Memoizer<>(() -> compteEncours));

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("P12324");
        contratGeneral.setCodeCadreFiscal("ART83");
        final OptContratEpargne optContratEpargne = new OptContratEpargne();


        contratGeneral.setOptContratEpargne(optContratEpargne);

        Map<CompartimentId, Memoizer<Encours>> encoursParCompartiment = new ConcurrentHashMap<>();
        encoursParCompartiment.put(getCompartimentId(), new Memoizer<>(() -> buildCompteEncours(BigDecimal.valueOf(34))));
        contratComplet.setEncoursParCompartiment(encoursParCompartiment);

        return contratComplet;
    }

    private CompartimentId getCompartimentId() {
        CompartimentId compartimentId = new CompartimentId();
        compartimentId.setCompartimentType(CompartimentType.C1);
        compartimentId.setIdAssure("IDASSURE");
        compartimentId.setNomContrat("RG152289321");
        return compartimentId;
    }

    private CompteEncours buildCompteEncours(BigDecimal montant) {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontantEncours(montant);
        compteEncours.setEncoursEnErreur(false);
        return compteEncours;
    }


    private List<Operation> getListOperationsFromResourceFile() {
        RechercherOperationsResponseType responseOperations = XmlMarshaller.convertSoapBodyToObject(FILEPATH_MOCK,
                                                                                                    RechercherOperationsResponseType.class);

        return ereMapper.rechercherOperationsTypeToDto(responseOperations).getOperations();
    }

}
