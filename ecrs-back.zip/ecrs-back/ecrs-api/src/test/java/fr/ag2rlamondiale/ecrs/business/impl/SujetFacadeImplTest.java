package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBiaFacade;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.business.even.EreConfEvenGenerator;
import fr.ag2rlamondiale.ecrs.business.even.EreVdppEvenGenerator;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.mapping.SujetMapper;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.rest.ISujetRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEven;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestListJson;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SujetFacadeImplTest {
    private static final String IDGDI = "cobnj6";
    private static final String NUM_PERSONNE = "P3880287";
    public static final int ID_SOUS_SUJET_CONF = -18;
    public static final int ID_SUJET_VERIFICATION_IDENTITE = -16;
    public static final String TITRE_SOUS_SUJET_CONF = "CONFIRMATION_DONNEES_PERSONNELLES";
    public static final String TYPE_VERIFICATION_IDENTITE = "VERIFICATIONIDENTITE";

    public static final int ID_SOUS_SUJET_VDPP = -17;
    public static final String TITRE_SOUS_SUJET_VDPP = "VALIDATION_DONNEES_PERSONNELLES";

    @InjectMocks
    SujetFacadeImpl sujetFacade;

    @Mock
    ISujetRestClient sujetRestClient;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    SujetMapper sujetMapper;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IBiaFacade biaFacade;

    @Mock
    EreConfEvenGenerator ereConfEvenGenerator;

    @Mock
    EreVdppEvenGenerator ereVdppEvenGenerator;

    @Mock
    IBlocageFacade blocageFacade;

    @Mock
    private IEvenementFacade evenementFacade;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Before
    public void init() throws TechnicalException {
        UserContext user = new UserContext();
        user.setIdGdi(IDGDI);
        user.setNumeroPersonneEre(NUM_PERSONNE);
        when(userContextHolder.get()).thenReturn(user);
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> new InfosBlocagesClient());
    }

    @Test
    public void should_get_sujets() {
        when(sujetRestClient.getSujets(any())).thenReturn(new ArrayList<>());
        assertNotNull(sujetFacade.getSujets());
    }

    @Test
    public void should_get_sujets_selectionnes_par_utilisateurWithSujetParentIsNull() throws TechnicalException {

        when(sujetRestClient.getSujetsParUtilisateur(any()))
                .thenAnswer((Answer<List<LectureSujetJson>>) invocation -> {
                    LectureSujetJson lectureSujetJson = new LectureSujetJson();
                    SujetJson sujetJson = new SujetJson();
                    sujetJson.setIdSujet(-13);
                    lectureSujetJson.setSujet(sujetJson);
                    lectureSujetJson.setIdGdi(IDGDI);
                    return Collections.singletonList(lectureSujetJson);
                });
        when(contratFacade.rechercherCompartimentEREPlusRecent(CompartimentType.C3)).thenReturn(buildCompartiment(CompartimentType.C3, buildContratHeader()));
        when(ereConfEvenGenerator.evaluerEvenement(NUM_PERSONNE)).thenReturn(false);
        when(ereVdppEvenGenerator.evaluerEvenement(NUM_PERSONNE)).thenReturn(true);
        assertNotNull(sujetFacade.getSujetsSelectionnesParUtilisateur());
    }

    @Test
    public void should_get_objectifs_par_utilisateur() throws TechnicalException {
        when(sujetRestClient.getSujetsParUtilisateur(new SujetRequestJson())).thenReturn(new ArrayList<>());
        assertNotNull(sujetFacade.getObjectifsParUtilisateur());
    }

    @Test
    public void should_create_sujet_par_utilisateur() throws TechnicalException {
        when(sujetRestClient.createSujetParUtilisateur(new SujetRequestListJson())).thenReturn(new ArrayList<>());
        when(sujetMapper.toLectureSujetDto(any(LectureSujetJson.class))).thenReturn(new LectureSujetDto());
        List<Integer> idSujets = new ArrayList<>();
        idSujets.add(1);
        assertNotNull(sujetFacade.createSujetParUtilisateur(idSujets));
    }

    @Test
    public void test_update_sujet() {
        when(sujetRestClient.updateSujetLuParUtilisateur(any(SujetRequestJson.class))).thenReturn(new LectureSujetJson());
        when(sujetMapper.toLectureSujetDto(any(LectureSujetJson.class))).thenReturn(new LectureSujetDto());
        assertNotNull(sujetFacade.updateSujetLuParUtilisateur(null));
    }

    private ContratHeader buildContratHeader() {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");
        return contratHeader;
    }

    private Compartiment buildCompartiment(CompartimentType compartimentType, ContratHeader contratHeader) {
        Compartiment co = Compartiment.builder()
                .type(compartimentType)
                .build();
        contratHeader.addCompartiment(co);
        return co;
    }

    @Test
    public void test_buildSousSujetsVerificationIdentite() throws TechnicalException {
        // Given
        Predicate<TypeEvenementJson> p = TypeEven.CONFIRMATION_DONNEES_PERSO.toPredicate();
        LectureSujetDto sujet = LectureSujetDto.builder()
                .idGdi(IDGDI)
                .idSujet(ID_SOUS_SUJET_CONF)
                .idSujetParent(ID_SUJET_VERIFICATION_IDENTITE)
                .titre(TITRE_SOUS_SUJET_CONF)
                .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                .typeSujet(TYPE_VERIFICATION_IDENTITE)
                .sousSujets(new ArrayList<>())
                .build();
        // When
        when(ereConfEvenGenerator.evaluerEvenement(anyString())).thenReturn(true);
//        when(evenementFacade.evenementDejaTraite(p)).thenReturn(false);

        List<LectureSujetDto> sujets = sujetFacade.buildSousSujetsVerificationIdentite(IDGDI, new EvenementJson(), new EvenementJson());
        // Then
        assertEquals(1, sujets.size());
        assertEquals(sujet, sujets.get(0));
    }

    @Test
    public void test_buildSousSujetsVerificationIdentite_2() throws TechnicalException {
        // Given
        Predicate<TypeEvenementJson> p = TypeEven.CONFIRMATION_DONNEES_PERSO.toPredicate();
        Predicate<TypeEvenementJson> p2 = TypeEven.VALIDATION_PERIODIQUE_DONNEES_PERSO.toPredicate();
        LectureSujetDto sujet = LectureSujetDto.builder()
                .idGdi(IDGDI)
                .idSujet(ID_SOUS_SUJET_VDPP)
                .idSujetParent(ID_SUJET_VERIFICATION_IDENTITE)
                .titre(TITRE_SOUS_SUJET_VDPP)
                .url(FonctionnaliteType.MODIFDONNEESPERSO.getLabel())
                .typeSujet(TYPE_VERIFICATION_IDENTITE)
                .sousSujets(new ArrayList<>())
                .build();
        // When
        final EvenementJson evenVdpp = new EvenementJson();
        final EvenementJson evenConf = null;

        // Then
        List<LectureSujetDto> sujets = sujetFacade.buildSousSujetsVerificationIdentite(IDGDI, evenConf, evenVdpp);
        assertEquals(1, sujets.size());
        assertEquals(sujet, sujets.get(0));
    }
}
