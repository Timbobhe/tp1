package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEcheancierFacade;
import fr.ag2rlamondiale.ecrs.business.impl.arretVersement.ArretVersementQuestionResolverChoixCompartiment;
import fr.ag2rlamondiale.ecrs.business.impl.arretVersement.ArretVersementQuestionResolverLibreProgramme;
import fr.ag2rlamondiale.ecrs.business.impl.versement.BlocageVersementContratDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.ListQuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.*;
import fr.ag2rlamondiale.ecrs.dto.versement.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.versement.FrequenceVirementType;
import fr.ag2rlamondiale.ecrs.dto.versement.PrelevementCodeSituationType;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.ecrs.utils.MockUserContext;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.rest.ISigElecRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.VERSEMENT_CHOIX_COMPARTIMENT;
import static fr.ag2rlamondiale.ecrs.dto.QuestionType.VERSEMENT_CHOIX_MODE_TYPE;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class ArretVersementFacadeImplTest {

    @InjectMocks
    ArretVersementFacadeImpl sut;

    @Mock
    IContratFacade contratFacade;

    @Spy
    @InjectMocks
    ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    IEcheancierFacade echeancierFacade;

    @Mock
    RequestContextHolder requestContext;

    @Mock
    ArretVersementQuestionResolverChoixCompartiment choixCompartiment;

    @Mock
    ArretVersementQuestionResolverLibreProgramme modeVersement;

    @Mock
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private ISigElecFacade sigElecfacade;

    @Mock
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Mock
    private IWorkflowFacade demandeWorkflowFacade;

    @Mock
    private ISigElecRestClient sigElecConsoleService;

    @Mock
    private IBlocageFacade blocageFacade;


    @Before
    public void init() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        sut.setDelaiTeletransmission(15);
        ReflectionTestUtils.setField(sut, "contratParcoursMapper", contratParcoursMapper);
        ReflectionTestUtils.setField(sut, "questionResolvers", Arrays.asList(choixCompartiment, modeVersement));
        when(consulterPersPhysFacade.consulterPersPhys(any())).thenReturn(PersonnePhysiqueConsult.builder()
                .paysResidenceFiscale("FRANCE")
                .build());
        when(userContextHolder.get()).thenReturn(new MockUserContext());
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            return info;
        });
    }

    @Test
    public void should_startArretVersement_with_1_PO() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(mockContratsComplets());
        when(echeancierFacade.getProchainEcheancier(
                eq(createCompartiment(CompartimentType.C1, "c1", createContratHeader(true, false)))))
                .thenReturn(createEcheancier());
        ArretVersementStartDto result = sut.startArretVersement();

        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getInfos());
        Assert.assertEquals(1, result.getInfos().size());
        Assert.assertNotNull(result.getInfos().get(0));
        Assert.assertNotNull(result.getInfos().get(0).getContrat());
        Assert.assertEquals("idContrat", result.getInfos().get(0).getContrat().getNomContrat());
        Assert.assertNotNull(result.getInfos().get(0).getArretVersements());
        Assert.assertEquals(1, result.getInfos().get(0).getArretVersements().size());
    }

    @Test
    public void should_startArretVersement_with_2_PO() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(mockContratsComplets());
        when(echeancierFacade.getProchainEcheancier(any(Compartiment.class))).thenReturn(createEcheancier());

        ArretVersementStartDto result = sut.startArretVersement();

        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getInfos());
        Assert.assertEquals(1, result.getInfos().size());
        Assert.assertNotNull(result.getInfos().get(0));
        Assert.assertNotNull(result.getInfos().get(0).getContrat());
        Assert.assertEquals("idContrat", result.getInfos().get(0).getContrat().getNomContrat());
        Assert.assertNotNull(result.getInfos().get(0).getArretVersements());
        Assert.assertEquals(2, result.getInfos().get(0).getArretVersements().size());
    }

    @Test
    public void should_startArretVersement_with_0_PO() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(mockContratsComplets());

        ArretVersementStartDto result = sut.startArretVersement();

        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getInfos());
        Assert.assertTrue(result.getInfos().isEmpty());
    }

    @Test
    public void should_startArretVersement_with_contrat_and_compartiment() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(mockContratsComplets("contrat2"));
        when(requestContext.getContrat()).thenReturn("contrat2");
        when(requestContext.getCompartiment()).thenReturn("c1");
        when(echeancierFacade.getProchainEcheancier(any(Compartiment.class))).thenReturn(createEcheancier());

        ArretVersementStartDto result = sut.startArretVersement();

        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getInfos());
        Assert.assertEquals(1, result.getInfos().size());
        Assert.assertNotNull(result.getInfos().get(0));
        Assert.assertNotNull(result.getInfos().get(0).getContrat());
        Assert.assertEquals("contrat2", result.getInfos().get(0).getContrat().getNomContrat());
        Assert.assertNotNull(result.getInfos().get(0).getArretVersements());
        Assert.assertEquals(1, result.getInfos().get(0).getArretVersements().size());
    }

    @Test
    public void should_startArretVersement_with_contrat() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(mockContratsComplets("contrat2"));
        when(requestContext.getContrat()).thenReturn("contrat2");
        when(echeancierFacade.getProchainEcheancier(any(Compartiment.class))).thenReturn(createEcheancier());

        ArretVersementStartDto result = sut.startArretVersement();

        Assert.assertNotNull(result);
        Assert.assertNotNull(result.getInfos());
        Assert.assertEquals(1, result.getInfos().size());
        Assert.assertNotNull(result.getInfos().get(0));
        Assert.assertNotNull(result.getInfos().get(0).getContrat());
        Assert.assertEquals("contrat2", result.getInfos().get(0).getContrat().getNomContrat());
        Assert.assertNotNull(result.getInfos().get(0).getArretVersements());
        Assert.assertEquals(2, result.getInfos().get(0).getArretVersements().size());
    }

    @Test
    public void should_resolveQuestion() throws TechnicalException {
        when(choixCompartiment.accept(eq(VERSEMENT_CHOIX_COMPARTIMENT), any(ArretVersementContexteDto.class))).thenReturn(true);
        when(choixCompartiment.resolve(eq(VERSEMENT_CHOIX_COMPARTIMENT), any(ArretVersementContexteDto.class))).thenReturn(createChoixCompartiment());
        when(modeVersement.accept(eq(VERSEMENT_CHOIX_MODE_TYPE), any(ArretVersementContexteDto.class))).thenReturn(true);
        when(modeVersement.resolve(eq(VERSEMENT_CHOIX_MODE_TYPE), any(ArretVersementContexteDto.class))).thenReturn(new QuestionResponsesDto<>());
        RequestQuestionArretVersementDto request = RequestQuestionArretVersementDto.builder()
                .questionType(VERSEMENT_CHOIX_COMPARTIMENT)
                .questionTypeList(Arrays.asList(VERSEMENT_CHOIX_COMPARTIMENT, VERSEMENT_CHOIX_MODE_TYPE))
                .contexte(ArretVersementContexteDto.builder()
                        .build())
                .build();

        ListQuestionResponsesDto result = sut.resolveQuestionOrNext(request);

        Assert.assertNotNull(result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void should_not_resolveQuestion() throws TechnicalException {
        when(choixCompartiment.accept(eq(VERSEMENT_CHOIX_COMPARTIMENT), any(ArretVersementContexteDto.class))).thenReturn(false);
        RequestQuestionArretVersementDto request = RequestQuestionArretVersementDto.builder()
                .questionType(VERSEMENT_CHOIX_COMPARTIMENT)
                .contexte(ArretVersementContexteDto.builder()
                        .build())
                .build();

        sut.resolveQuestion(request);

        Assert.fail();

    }

    @Test
    public void should_terminate() throws TechnicalException, IOException, JAXBException {
        ArretVersementTerminateDto terminateDto = new ArretVersementTerminateDto();
        terminateDto.setContratSelected(ContratId.builder()
                .nomContrat("contrat")
                .codeSilo(CodeSiloType.ERE)
                .build());
        ArretVersementClientDto clientDto = ArretVersementClientDto.builder()
                .compartimentId(CompartimentId.ere("c1", CompartimentType.C1))
                .montantVersement(BigDecimal.TEN)
                .periodiciteVersement(FrequenceVirementType.MENSUELLE)
                .build();
        terminateDto.setArretVersementClient(clientDto);
        DocumentDto documentDto = new DocumentDto();
        documentDto.setHtmlContent("");
        terminateDto.setContenuVersement(documentDto);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader("contrat"));
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(new DataDocumentContrat());
        when(userContextHolder.get()).thenReturn(createUserContext());
        when(sigElecfacade.envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class), eq(false))).thenReturn("url");

        String url = sut.terminate(terminateDto, false);

        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
        Assert.assertEquals("url", url);
    }

    @Test
    public void should_not_terminate() throws TechnicalException, IOException, JAXBException {
        ArretVersementTerminateDto terminateDto = new ArretVersementTerminateDto();
        terminateDto.setContratSelected(ContratId.builder()
                .nomContrat("contrat")
                .codeSilo(CodeSiloType.ERE)
                .build());
        ArretVersementClientDto clientDto = ArretVersementClientDto.builder()
                .compartimentId(CompartimentId.ere("c1", CompartimentType.C1))
                .montantVersement(BigDecimal.TEN)
                .periodiciteVersement(FrequenceVirementType.MENSUELLE)
                .build();
        terminateDto.setArretVersementClient(clientDto);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader("contrat"));

        String result = sut.terminate(terminateDto, false);

        Assert.assertNull(result);
    }

    private Echeancier createEcheancier() {
        Echeancier echeancier = new Echeancier();
        echeancier.setMontant(BigDecimal.valueOf(100));
        echeancier.setCodeFractionnement(FrequenceVirementType.MENSUELLE.getCodeFractionnement());
        Prelevement prelevement = new Prelevement();
        prelevement.setCodeSituationPrelevement(PrelevementCodeSituationType.TRANS.name());
        prelevement.setDatePrelevement(DateUtils.createDate(10,1,2050));
        echeancier.setPrelevements(Collections.singletonList(prelevement));
        return echeancier;
    }

    private List<ContratComplet> mockContratsComplets() {
        List<ContratComplet> contratComplets = new ArrayList<>();
        ContratComplet contratComplet = new ContratComplet();
        contratComplet.setContratHeader(createContratHeader(true, false));
        contratComplets.add(contratComplet);
        return contratComplets;
    }

    private List<ContratComplet> mockContratsComplets(String idContrat) {
        List<ContratComplet> contratComplets = new ArrayList<>();
        ContratComplet contratComplet = new ContratComplet();
        contratComplet.setContratHeader(createContratHeader(idContrat));
        contratComplets.add(contratComplet);
        return contratComplets;
    }

    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("idContrat");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C1, "c1", contratHeader));
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C4, "c4", contratHeader));
        return contratHeader;
    }

    private ContratHeader createContratHeader(String idContrat) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setPersonId("personId");
        contratHeader.setId(idContrat);
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C1, "c1", contratHeader));
        contratHeader.addCompartiment(createCompartiment(CompartimentType.C4, "c4", contratHeader));
        return contratHeader;
    }

    private Compartiment createCompartiment(CompartimentType type, String idAssure, ContratHeader contratHeader) {
        Compartiment compartiment = new Compartiment();
        compartiment.setType(type);
        compartiment.setIdentifiantAssure(idAssure);
        compartiment.setContratHeader(contratHeader);
        compartiment.setDisponibilite(DisponibiliteType.DISPONIBLE);
        return compartiment;
    }

    private QuestionResponsesDto<ChoixCompartimentDto, BlocageVersementContratDto> createChoixCompartiment() {
        return QuestionResponsesDto.<ChoixCompartimentDto, BlocageVersementContratDto>builder()
                .build();
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("123456");
        return userContext;
    }
}
