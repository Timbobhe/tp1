package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.business.impl.ConsulterPersPhysFacadeImpl;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.mockito.Mockito.when;

public class ConsulterPersPhysFacadeImplTest {
    private static final String ID_SILO = "P0802026";

    @Mock
    IConsulterPersonneClient consulterPersonneClient;

    @InjectMocks
    ConsulterPersPhysFacadeImpl consulterPersPhysFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Test
    public void consulterPersPhysTest() throws TechnicalException {
        // Given
        when(consulterPersonneClient.consulterPersPhys(Matchers.any(IdSiloDto.class)))
                .thenAnswer((Answer<PersonnePhysiqueConsult>) object -> {
                    PersonnePhysiqueConsult personnePhysique = new PersonnePhysiqueConsult();
                    personnePhysique.setId(ID_SILO);
                    return personnePhysique;
                });
        // When
        PersonnePhysiqueConsult personnePhysique = consulterPersPhysFacade.consulterPersPhys(new IdSiloDto(ID_SILO, CodeApplicationType.EGESPER_ERE.getCode(), CodeSiloType.ERE.getLibelle()));
        // Then
        Assert.assertEquals(ID_SILO, personnePhysique.getId());
    }
}
