package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.domain.structinv.SupportsInvNiveau1;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.document.*;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.IPrevalidationPieceIdentiteFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.prevalidpieceident.PrevalidationPieceIdentiteJson;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleProfilInv;
import fr.ag2rlamondiale.trm.domain.structinv.ProfilInv;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demande;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demandes;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.ecrs.dto.ResultParcoursEffectueDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaStartDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.bia.ClauseBeneficiaireDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.dto.sigelec.MatchAccountOutDto;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;

import static fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType.EXTRANET_BIA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.AFFILIATION_AVEC_BIA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.AFFILIATION_SANS_BIA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.REMIS_ENVIGEUR_SANS_BIA;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BiaFacadeImplTest {

    @InjectMocks
    BiaFacadeImpl sut;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Mock
    private ISigElecFacade sigElecfacade;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IPrevalidationPieceIdentiteFacade prevalidationPieceIdentiteFacade;

    @Mock
    private IStructureInvFacade structureInvFacade;

    @Mock
    private IContratsClient contratsClient;

    @Mock
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Mock
    private IJahiaFacade jahiaFacade;

    @Mock
    private IBlocageFacade blocageFacade;

    @Spy
    private ContratParcoursMapperImpl contratParcoursMapper;

    @Before
    public void init() throws IOException, TechnicalException {
        UserContext user = new UserContext();
        user.setNumeroPersonneMdpro("numeroPersonneMdpro");
        user.setNumeroPersonneEre("numeroPersonneEre");
        when(userContextHolder.get()).thenReturn(user);
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(new DataDocumentContrat());

        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMPLETER_BIA, "BIA_AGREMENTS_ACTE")).thenReturn("bia agrement acte");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE")).thenReturn("agrement convention de preuves");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE_TITLE_DOC")).thenReturn("agrement convention de preuves title doc");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_QAD")).thenReturn("agrement qad");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_QAD_TITLE_DOC")).thenReturn("agrement qad title doc");
    }

    @Test
    public void contratWithAffiliationSansBiaThenHasBiaFalse_a() throws TechnicalException {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        Compartiment compartimentC3 = Compartiment.builder()
                .identifiantAssure("123456")
                .etatCompartiment(AFFILIATION_SANS_BIA)
                .type(CompartimentType.C3)
                .build();

        contratHeader.addCompartiment(compartimentC3);

        CompteGeneralesERE compteGeneralesERE_a = new CompteGeneralesERE();
        compteGeneralesERE_a.setCodeEtat("A");

        when(contratsClient.consulterCompteGeneralesERE(any())).thenReturn(compteGeneralesERE_a);
        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());

        final ResultParcoursEffectueDto res_a = sut.testBiaEffectue(contratHeader);
        assertFalse(res_a.isParcoursEffectue());
    }

    @Test
    public void contratWithAffiliationSansBiaThenHasBiaFalse_v() throws TechnicalException {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        Compartiment compartimentC3 = Compartiment.builder()
                .identifiantAssure("123456")
                .type(CompartimentType.C3)
                .etatCompartiment(REMIS_ENVIGEUR_SANS_BIA)
                .build();

        contratHeader.addCompartiment(compartimentC3);

        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());

        final ResultParcoursEffectueDto res = sut.testBiaEffectue(contratHeader);
        assertFalse(res.isParcoursEffectue());
    }

    @Test
    public void contratWithAffiliationAutreThenHasBiaTrue() throws TechnicalException {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        Compartiment compartimentC3 = Compartiment.builder()
                .identifiantAssure("123456")
                .type(CompartimentType.C3)
                .etatCompartiment(AFFILIATION_AVEC_BIA)
                .build();

        contratHeader.addCompartiment(compartimentC3);

        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());

        final ResultParcoursEffectueDto res_a = sut.testBiaEffectue(contratHeader);
        assertTrue(res_a.isParcoursEffectue());
    }

    @Test
    public void hasDemandeBiaEncoursThenTrue() throws TechnicalException {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(contratHeader));
        when(workflowFacade.consulterDerniereDemandeEnCours(Matchers.any(RechDemFront.class),
                Matchers.eq(EXTRANET_BIA))).thenReturn(new Demande());


        final ResultParcoursEffectueDto res = sut.testBiaEffectue(contratHeader);
        assertFalse(res.isWorkflowParcoursEncours());
    }

    @Test
    public void contratWithoutUnfinishedDemandeThenFalse() throws TechnicalException {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        CompteGeneralesERE compteGeneralesERE_v = new CompteGeneralesERE();
        compteGeneralesERE_v.setCodeEtat("V");

        when(contratsClient.consulterCompteGeneralesERE(any())).thenReturn(compteGeneralesERE_v);
        when(contratFacade.rechercherContratsEre()).thenReturn(Collections.singletonList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());


        final ResultParcoursEffectueDto res = sut.testBiaEffectue(contratHeader);
        assertFalse(res.isSigElecEncoursNonSigne());
    }

    @Test
    public void biaStartDto() throws TechnicalException {
        UserContext userCtx = new UserContext();
        userCtx.setSilos(Sets.newHashSet(CodeSiloType.ERE));
        userCtx.setIdGdi("cobnj6");
        when(userContextHolder.get()).thenReturn(userCtx);

        when(structureInvFacade.getGrillesProfilsPremierNiveau(any(Compartiment.class))).thenReturn(getGrillesProfilsPremierNiveau());

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);

        MatchAccountOutDto matchAccountDto = new MatchAccountOutDto();
        matchAccountDto.setMatch(true);
        when(sigElecfacade.matchAccount(any(PersonnePhysiqueConsult.class))).thenReturn(matchAccountDto);

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setCodeEtat("A");

        when(contratsClient.consulterCompteGeneralesERE(any())).thenReturn(compteGeneralesERE);
        when(contratFacade.rechercherContratsEre()).thenReturn(Arrays.asList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());
        when(prevalidationPieceIdentiteFacade.getPrevalidationByIdGdi(Matchers.anyString())).thenReturn(null);
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());

        BiaStartDto biaStartDto = sut.startBia();
        assertNotNull(biaStartDto);
    }

    private SupportsInvNiveau1 getGrillesProfilsPremierNiveau() {
        Set<GrilleProfilInv> grilleProfilInvs = new HashSet<>();
        GrilleProfilInv grilleProfilInv = new ProfilInv();
        grilleProfilInv.setId("ID");
        grilleProfilInv.setNom("nom");
        grilleProfilInvs.add(grilleProfilInv);
        return SupportsInvNiveau1.builder().supports(grilleProfilInvs).build();
    }

    @Test
    public void biaStartDto_2() throws TechnicalException {
        UserContext userCtx = new UserContext();
        userCtx.setSilos(Sets.newHashSet(CodeSiloType.ERE));
        userCtx.setIdGdi("cobnj6");
        when(userContextHolder.get()).thenReturn(userCtx);

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);

        MatchAccountOutDto matchAccountDto = new MatchAccountOutDto();
        matchAccountDto.setMatch(true);
        when(sigElecfacade.matchAccount(any(PersonnePhysiqueConsult.class))).thenReturn(matchAccountDto);

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setId("RG000000000");
        contratHeader.setRaisonSocialeAdherente("raisonSocialeAdherente");

        CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setCodeEtat("A");
        ContratGeneral contratGeneral = new ContratGeneral();
        contratGeneral.setProduit("Produit#1");


        when(contratsClient.consulterCompteGeneralesERE(any())).thenReturn(compteGeneralesERE);
        when(contratFacade.rechercherContratsEre()).thenReturn(Arrays.asList(contratHeader));
        when(workflowFacade.rechercherDemandes(Matchers.any())).thenReturn(new Demandes());

        when(prevalidationPieceIdentiteFacade.getPrevalidationByIdGdi(Matchers.anyString()))
                .thenReturn(new PrevalidationPieceIdentiteJson());
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(new InfosBlocagesClient());

        BiaStartDto biaStartDto = sut.startBia();
        assertNotNull(biaStartDto);

    }

    @Test
    public void should_terminate_bia_by_electronic_signature_without_qad_and_contract_ere_not_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        sut.terminateBia(createBiaTerminateDto(false), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }


    @Test
    public void should_terminate_bia_by_electronic_signature_with_qad_and_contract_ere_not_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        sut.terminateBia(createBiaTerminateDto(true), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }


    @Test
    public void should_terminate_bia_by_electronic_signature_without_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        sut.terminateBia(createBiaTerminateDto(false), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }


    @Test
    public void should_terminate_bia_by_electronic_signature_with_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        sut.terminateBia(createBiaTerminateDto(true), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }

    private BiaTerminateDto createBiaTerminateDto(boolean withQad) {
        BiaTerminateDto biaTerminateDto = new BiaTerminateDto();
        DocumentDto documentQad = new DocumentDto();
        DocumentDto documentBia = new DocumentDto();
        if (withQad) {
            documentQad.setHtmlContent("html style");
            documentQad.setHtmlContent("html content");
        }
        documentBia.setHtmlContent("html style");
        documentBia.setHtmlContent("html content");
        biaTerminateDto.setContenuQAD(documentQad);
        biaTerminateDto.setContenuBIA(documentBia);
        ContratParcoursDto contratParcours = new ContratParcoursDto();
        contratParcours.setCompartimentType(CompartimentType.C3);
        contratParcours.setCodeSilo(CodeSiloType.ERE);
        contratParcours.setIdentifiantAssure("123456");
        contratParcours.setNomContrat("nom");
        biaTerminateDto.setContratSelected(contratParcours);
        RepartitionSupportDto repartitionSupportDto = new RepartitionSupportDto();
        repartitionSupportDto.setNom("nom grille");
        repartitionSupportDto.setPourcentage(new BigDecimal("75.0"));
        biaTerminateDto.setGestionFinanciereSelected(Collections.singletonList(repartitionSupportDto));
        ClauseBeneficiaireDto clauseBeneficiaireDto = new ClauseBeneficiaireDto();
        clauseBeneficiaireDto.setClauseStandard(true);
        biaTerminateDto.setClauseBeneficiaireSelected(clauseBeneficiaireDto);
        return biaTerminateDto;
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro) {
        ContratComplet contratComplet = new ContratComplet();

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);

        contratComplet.setContratHeader(contratHeader);

        ContratGeneral contratGeneral = new ContratGeneral();
        contratGeneral.setCodeAssureur("code assureur");
        contratComplet.setContratGeneral(contratGeneral);
        return contratComplet;
    }

    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        return contratHeader;
    }

    private HashMap<String, ChampsPDFInfo> generateMapParameters() {
        HashMap<String, ChampsPDFInfo> params = new HashMap<>();
        params.put(ChampsPdfType.NOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRENOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_PRODUIT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COMPTEUR_SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.E_MAIL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADR_LEGALE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE_COURRIER.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT_LB));
        params.put(ChampsPdfType.ANNUEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_SPECIFIQUE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_STANDARD.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_POSTAL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COLLEGE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CONSENTEMENTS.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DEPARTEMENT_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FONDS_DEFAUT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.IDENTIFIANT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LIEU_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LOGO.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LOGOPART.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MADAME.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MENSUEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONSIEUR.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONTANT_VL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONTANT_VP.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM_NAISSANCE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NUM_CONTRAT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF1.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF2.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF3.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF4.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF5.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF6.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF7.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OPT_IN.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRENOM.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PAYS.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRODUIT.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.QR_CODE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.RAISON_SOCIALE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SEMESTRIEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.STRATEGIE_FINANCIERE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TAUX_SF.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PORTABLE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PROFESSIONNEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TEXTE_CLAUSESPECIFIQUE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TRIMESTRIEL.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.VILLE.getChamps(), new ChampsPDFInfo("contratHeader.getLibelleProduit()", TypeChampsPdfType.TEXT));
        return params;
    }
}
