package fr.ag2rlamondiale.ecrs.business.impl.accessibilite;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class VersementPageHubAccessibilitySupplierTest {
    @InjectMocks
    VersementPageHubAccessibilitySupplier versementPageHubAccessibilitySupplier;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private ContratVifHelper contratVifHelper;

    private final ContratHeader crt3 =  ContratHeader.builder().affichageType(AffichageType.NORMAL)
            .codeSilo(CodeSiloType.ERE).numGenContrat("RAG23").build();

    @Test
    public void acceptFonctionnalityType() {
        //When Then
        Assert.assertTrue(versementPageHubAccessibilitySupplier.accept(FonctionnaliteType.VOS_DONNEES_VERSEMENT));
    }

    @Test
    public void checkAccessibityVersementHubTest() throws TechnicalException {
        when(contratFacade.rechercherContratsComplets()).thenReturn(createContratComplets());
        when(contratVifHelper.isVifPossible(any(ContratComplet.class), any(CompartimentId.class))).thenReturn(true);
        Assert.assertNotNull(versementPageHubAccessibilitySupplier.check());
    }

    private List<ContratComplet> createContratComplets() {
        List<ContratComplet> contratComplets = new ArrayList<>();
        createContratHeaders().stream().forEach(c -> contratComplets.add(new ContratComplet(c)));
        return contratComplets;
    }
    List<Compartiment> cCrt3() {
        return Arrays.asList(Compartiment.builder().type(CompartimentType.C1).identifiantAssure("XERUTZ")
                .contratHeader(crt3).build());
    }
    private List<ContratHeader> createContratHeaders() {
        ContratHeader crt3Re = ContratHeader.builder().affichageType(AffichageType.NORMAL).compartiments(cCrt3())
                .codeSilo(CodeSiloType.ERE).numGenContrat("RAG23").build();

        return Arrays.asList(
                ContratHeader.builder().affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE).classeAutreContrat(true).build(),
                ContratHeader.builder().affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.MDP).id("RG34567").build(),
                crt3Re

        );
    }

}
