package fr.ag2rlamondiale.ecrs.api.secure;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import fr.ag2rlamondiale.ecrs.business.IClausesBenefCtrFacade;
import fr.ag2rlamondiale.ecrs.dto.clausebeneficiaire.ClauseBeneficiaireTerminateDto;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import javax.xml.bind.JAXBException;

@RunWith(MockitoJUnitRunner.class)
public class ClauseBeneficiaireRestControllerTest {
    @Mock
    private IClausesBenefCtrFacade clausesBenefCtrFacadeMock;

    @InjectMocks
    @Spy
    private ClauseBeneficiaireRestController sut;

    @Test
    public void should_returned_values_to_start_modification_clause_beneficiaire() throws TechnicalException {
        sut.start();
        verify(clausesBenefCtrFacadeMock, times(1)).startModificationClauseBeneficiaire();
    }

    @Test
    public void should_terminate_modification_clause_beneficiaire() throws CommonException, JAXBException, IOException {
        sut.terminate(new ClauseBeneficiaireTerminateDto(), false);
        verify(sut, times(1)).terminate(any(ClauseBeneficiaireTerminateDto.class),
                Matchers.eq(false));
    }
}
