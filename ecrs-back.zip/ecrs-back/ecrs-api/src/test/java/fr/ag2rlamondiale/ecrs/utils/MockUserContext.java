package fr.ag2rlamondiale.ecrs.utils;

import lombok.Data;
import lombok.EqualsAndHashCode;
import fr.ag2rlamondiale.trm.security.UserContext;

@Data
@EqualsAndHashCode(callSuper = false)
public class MockUserContext extends UserContext {

    private String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
}
