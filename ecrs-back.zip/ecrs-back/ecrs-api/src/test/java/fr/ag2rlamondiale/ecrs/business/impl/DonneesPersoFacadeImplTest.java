package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IEvenementFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoInfo;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursType;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursValidation;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.ModificationsIdentiteInfo;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.IdDemSilo;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.assertj.core.util.Lists;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.ZoneId;
import java.util.Calendar;
import java.util.TimeZone;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class DonneesPersoFacadeImplTest {

    @InjectMocks
    DonneesPersoFacadeImpl donneesPersoFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private IWorkflowFacade workflowFacade;

    @Mock
    private IContratFacade contratFacade;

    @Mock
    private IEvenementFacade evenementFacade;

    @Mock
    private IModifierPPSiloClient modifierPPSiloClient;

    @Mock
    private IConsulterPersonneClient consulterPersonneClient;

    @Test
    public void getDonnesPerso() throws TechnicalException {
        PersonnePhysiqueConsult p = getPersPhysiqueConsult();
        UserContext u= getUserContext();
        //when
        when(userContextHolder.get()).thenReturn(u);
        when(consulterPersPhysFacade.consulterPersPhys((Matchers.any()))).thenReturn(p);
        when(workflowFacade.hasDemandeEncours(anyString(), any(DemandeWorkflowType.class))).thenReturn(true);
        DonneesPersoInfo donneesPerso = donneesPersoFacade.getDonnesPerso();
        //assertNotNull(donneesPerso);
        assertEquals(donneesPerso,buildDonneesPerso());
    }

    private DonneesPersoInfo buildDonneesPerso() {
        ModificationsIdentiteInfo modifInfo= createIdentite();
        DonneesPersoInfo donneesPersoInfo = DonneesPersoInfo.builder()
                .donneesPersonnellesConfirmees(true)
                .identiteInfoValidee(modifInfo)
                .modificationEnCours(true)
                .build();
        return donneesPersoInfo;
    }

    private UserContext getUserContext() {
        UserContext user = new UserContext();
        user.setNumeroPersonneEre("ERE");
        user.setNumeroPersonneMdpro("MDP");
        return user;
    }

    private PersonnePhysiqueConsult getPersPhysiqueConsult() {
        PersonnePhysiqueConsult PersphysiqueConsult = new PersonnePhysiqueConsult();
        PersphysiqueConsult.setId("P00000");
        PersphysiqueConsult.setCodeCivilite("Mme");
        PersphysiqueConsult.setCivilite("Madame");
        PersphysiqueConsult.setNom("GIFAL");
        PersphysiqueConsult.setPrenom("CARINE");
        PersphysiqueConsult.setNomNaissance("GIFAL");
        PersphysiqueConsult.setDateDeNaissance(buildDate(1980, 7, 18, 00, 00, 00, 00).getTime());
        PersphysiqueConsult.setLieuNaissance("ST DENIS");
        PersphysiqueConsult.setDonneesPersonnellesConfirmees(true);
        PersphysiqueConsult.setEmailPro("emailpro@email.domain");
        PersphysiqueConsult.setTelPortable("06XXXXXXXX");
        return PersphysiqueConsult;
    }

    private ModificationsIdentiteInfo createIdentite() {
        ModificationsIdentiteInfo modificationsIdentiteInfo = ModificationsIdentiteInfo.builder()
                .civilite("Madame").codeCivilite("Mme")
                .nom("GIFAL").prenom("CARINE")
                .nomNaissance("GIFAL")
                .dateDeNaissance("18/08/1980")
                .lieuNaissance("ST DENIS").build();
        return modificationsIdentiteInfo;
    }

    private Calendar buildDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return new Calendar.Builder().setDate(year, month, day).setTimeOfDay(hour, minute, second, millis)
                .setTimeZone(TimeZone.getTimeZone(ZoneId.systemDefault())).build();
    }
    private DonneesPersoParcoursValidation createdonneesPerso() {
        ModificationsIdentiteInfo modificationsIdentiteInfo = ModificationsIdentiteInfo.builder()
                .civilite("Madame").codeCivilite("Mme")
                .nom("GIFAL").prenom("CARINE")
                .dateDeNaissance("18/08/1980")
                .lieuNaissance("ST DENIS").build();
        DonneesPersoParcoursValidation donneesPerso = DonneesPersoParcoursValidation.builder()
                .modificationsIdentiteInfo(modificationsIdentiteInfo)
                .donneesPersoParcoursType(DonneesPersoParcoursType.CONFIRMATION)
                .pieceJointes(null).build();
        return donneesPerso;

    }

    @Test
    public void validerModifDonnesPerso() throws TechnicalException {
        UserContext u= getUserContext();
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        ContratComplet contrat = new ContratComplet();
        contrat.setContratHeader(contratHeader);
        contrat.setContratGeneral(new ContratGeneral());
        PersonnePhysiqueConsult pPhys=getPersPhysiqueConsult();
        when(userContextHolder.get()).thenReturn(u);
        when(consulterPersPhysFacade.consulterPersPhys(Matchers.any())).thenReturn(pPhys);
        when(contratFacade.rechercherContratsCompletsERE()).thenReturn(Lists.newArrayList(contrat));
        when(workflowFacade.creerDemandeWorkflow(Matchers.any())).thenReturn(new IdDemSilo());
        consulterPersonneClient.forceCacheEvictConsulterPersPhys(userContextHolder.get().getIdSilo());
        when(workflowFacade.genererIdDemFront(any(CodeActionType.class), anyString(), anyString(), any(CodeSiloType.class))).thenReturn("id dem front generated");
        DonneesPersoParcoursValidation donneesModifiees= createdonneesPerso();

        ModifierPPSiloDto modifierPPSiloDto=ModifierPPSiloDto.builder()
                .personnePhysique(pPhys).build();
        ModifierPPSiloResponseDto modifierResponsePPSiloDto=new ModifierPPSiloResponseDto();
        modifierResponsePPSiloDto.setResult(true);
        when(modifierPPSiloClient.modifierPPSilo1(modifierPPSiloDto)).thenReturn(modifierResponsePPSiloDto);

        ModifierPPSiloResponseDto pp= donneesPersoFacade.validerModifDonnesPerso(donneesModifiees);

        assertEquals(pp,modifierResponsePPSiloDto);
    }
}
