package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IArretVersementFacade;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.ArretVersementTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.arretVersement.RequestQuestionArretVersementDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class ArretVersementRestControllerTest {
    @Mock
    IArretVersementFacade arretVersementFacade;

    @InjectMocks
    @Spy
    ArretVersementRestController sut;

    @Test
    public void startModificationVersementTest() throws TechnicalException {
        sut.start();
        verify(sut, times(1)).start();
    }

    @Test
    public void resolveQuestionOrNext() throws TechnicalException {
        sut.resolveQuestionOrNext(new RequestQuestionArretVersementDto());
        verify(sut, times(1)).resolveQuestionOrNext(any(RequestQuestionArretVersementDto.class));
    }

    @Test
    public void terminate() throws TechnicalException, JAXBException, IOException {
        sut.terminate(new ArretVersementTerminateDto(), false);
        verify(sut, times(1)).terminate(any(ArretVersementTerminateDto.class), Matchers.eq(false));
    }
}
