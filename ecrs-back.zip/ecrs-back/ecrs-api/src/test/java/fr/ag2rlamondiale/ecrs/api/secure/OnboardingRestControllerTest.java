package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.dto.onboarding.OnboardingTerminateDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.mapping.StructInvMapper;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class OnboardingRestControllerTest {
    @Mock
    IContratFacade contratFacade;

    @Mock
    IEvenementFacade evenementFacade;

    @Mock
    ISujetFacade sujetFacade;

    @Mock
    IBiaFacade biaFacade;

    @Mock
    IStructureInvFacade structureInvFacade;

    @InjectMocks
    @Spy
    OnboardingRestController onboardingRest;

    @Test
    public void startOnboardingTest() throws Exception {
        onboardingRest.start();
        verify(onboardingRest, times(1)).start();
    }

    @Test
    public void terminateOnboardingTest() throws TechnicalException {
        OnboardingTerminateDto onboardingTerminateDto = new OnboardingTerminateDto();
        EvenementJson evenementJson = new EvenementJson();
        onboardingTerminateDto.setEvenement(evenementJson);
        onboardingRest.terminate(onboardingTerminateDto);
        verify(onboardingRest, times(1)).terminate(any(OnboardingTerminateDto.class));
    }
}
