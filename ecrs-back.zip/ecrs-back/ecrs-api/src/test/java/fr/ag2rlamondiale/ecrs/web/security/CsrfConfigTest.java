package fr.ag2rlamondiale.ecrs.web.security;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.web.util.matcher.RequestMatcher;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import static org.junit.Assert.*;

public class CsrfConfigTest {

    @Test
    public void activeRequireCsrfProtectionMatcher_with_exclude_url() {
        final RequestMatcher requestMatcher = getRequestMatcher("/**/j_spring_cas_security_check", "/**/j_spring_security_logout");

        assertTrue("POST Method", requestMatcher.matcher(mockRequest("POST", "qdsfqsdf")).isMatch());
        assertTrue("PUT Method", requestMatcher.matcher(mockRequest("PUT", "qdsfqsdf")).isMatch());
        assertTrue("DELETE Method", requestMatcher.matcher(mockRequest("DELETE", "qdsfqsdf")).isMatch());

        List<String> allowedMethods = Arrays.asList("GET", "HEAD", "TRACE", "OPTIONS");
        for (String allowedMethod : allowedMethods) {
            assertFalse(allowedMethod + " Method", requestMatcher.matcher(mockRequest(allowedMethod, "qdsfqsdf")).isMatch());
        }


        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/rsb/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/rsb/j_spring_security_logout")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/j_spring_security_logout")).isMatch());

        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/rsb/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/rsb/j_spring_security_logout")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/j_spring_security_logout")).isMatch());

        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/rsb/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/rsb/j_spring_security_logout")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/j_spring_security_logout")).isMatch());
    }

    private RequestMatcher getRequestMatcher(String... patterns) {
        CsrfConfig config = new CsrfConfig();
        config.setCustomExcludeUrlList(List.of(patterns));

        return config.activeRequireCsrfProtectionMatcher();
    }

    @Test
    public void activeRequireCsrfProtectionMatcher_with_exclude_pattern() {
        final RequestMatcher requestMatcher = getRequestMatcher("POST /**/j_spring_cas_security_check", "POST /**/j_spring_security_logout");

        assertTrue("POST Method", requestMatcher.matcher(mockRequest("POST", "qdsfqsdf")).isMatch());
        assertTrue("PUT Method", requestMatcher.matcher(mockRequest("PUT", "qdsfqsdf")).isMatch());
        assertTrue("DELETE Method", requestMatcher.matcher(mockRequest("DELETE", "qdsfqsdf")).isMatch());

        List<String> allowedMethods = Arrays.asList("GET", "HEAD", "TRACE", "OPTIONS");
        for (String allowedMethod : allowedMethods) {
            assertFalse(allowedMethod + " Method", requestMatcher.matcher(mockRequest(allowedMethod, "qdsfqsdf")).isMatch());
        }


        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/rsb/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/rsb/j_spring_security_logout")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("POST", "/j_spring_security_logout")).isMatch());

        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/rsb/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/j_spring_cas_security_check")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/rsb/j_spring_security_logout")).isMatch());
        assertFalse("Exclude URL Method", requestMatcher.matcher(mockRequest("OPTIONS", "/j_spring_security_logout")).isMatch());

        assertTrue("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/rsb/j_spring_cas_security_check")).isMatch());
        assertTrue("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/j_spring_cas_security_check")).isMatch());
        assertTrue("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/rsb/j_spring_security_logout")).isMatch());
        assertTrue("Exclude URL Method", requestMatcher.matcher(mockRequest("PUT", "/j_spring_security_logout")).isMatch());
    }

    @Nonnull
    private MockHttpServletRequest mockRequest(String method, String requestPath) {
        final MockHttpServletRequest mockHttpServletRequest = new MockHttpServletRequest(method, "");
        mockHttpServletRequest.setServletPath(requestPath);
        return mockHttpServletRequest;
    }
}
