package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.business.impl.arbitrage.ArbitrageQuestionResolverChoixCompartimentERE;
import fr.ag2rlamondiale.ecrs.business.impl.arbitrage.ArbitrageQuestionResolverChoixCompartimentMDP;
import fr.ag2rlamondiale.ecrs.business.impl.arbitrage.BlocageArbitrageContratDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratBlocage;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.*;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.*;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.dto.structinv.GestionFinanciereActuelleMdpDto;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IDataDocumentContratFacade;
import fr.ag2rlamondiale.trm.business.ISigElecFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.business.impl.BaseDownloadDocumentFacadeImpl;
import fr.ag2rlamondiale.trm.client.soap.IConsulterClausesBenefCtrClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ClausesContratDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrDto;
import fr.ag2rlamondiale.trm.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.document.DictionaryKeyType;
import fr.ag2rlamondiale.trm.domain.document.DocRefType;
import fr.ag2rlamondiale.trm.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.qad.PropositionJson;
import fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.trm.domain.structinv.*;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.dto.document.DocumentDto;
import fr.ag2rlamondiale.trm.jahia.IJahiaFacade;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.test.util.ReflectionTestUtils;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.AFFILIATION_AVEC_BIA;
import static fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum.SANS_EFFET;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ArbitrageFacadeImplTest {
    public static final String BASE_IDASSURE = "123456-";
    private static final Date DATE_JOUR = new Date();

    @Mock
    IContratFacade contratFacade;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @InjectMocks
    ArbitrageFacadeImpl arbitrageFacadeImpl;

    @Spy
    @InjectMocks
    ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    ArbitrageQuestionResolverChoixCompartimentERE choixCompartimentERE;

    @Mock
    ArbitrageQuestionResolverChoixCompartimentMDP choixCompartimentMDP;

    @Mock
    private InfosBlocagesClient infosBlocagesClient;

    @Mock
    private IBlocageFacade blocageFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IConsulterClausesBenefCtrClient clausesBenefCtrClient;

    @Mock
    private IStructureInvFacade structureInvFacade;

    @Mock
    private ISigElecFacade sigElecfacade;

    @Mock
    private IWorkflowFacade workflowClient;

    @Mock
    private IOperationFacade operationFacade;

    @Mock
    private IQadFacade qadFacade;

    @Mock
    private BaseDownloadDocumentFacadeImpl downloadDocumentFacade;

    @Mock
    private IJahiaFacade jahiaFacade;

    @Mock
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private ContratMDPROHelper contratMDPROHelper;

    @Mock
    private IParcoursSimplifieFacade  parcoursSimplifieFacade;

    @Before
    public void init() throws TechnicalException, IOException {
        MockitoAnnotations.initMocks(this);
        when(userContextHolder.get()).thenReturn(createUserContext());
        ReflectionTestUtils.setField(arbitrageFacadeImpl, "contratParcoursMapper", contratParcoursMapper);
        when(choixCompartimentERE.resolve(any(ContratHeader.class), any(ArbitrageContexteDto.class))).thenReturn(buildChoixCompartimentERE());
        when(choixCompartimentMDP.resolve(any(ContratHeader.class), any(ArbitrageContexteDto.class))).thenReturn(buildChoixCompartimentERE());
        ReflectionTestUtils.setField(arbitrageFacadeImpl, "questionResolvers", Collections.singletonList(choixCompartimentERE));
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            return info;
        });
        when(qadFacade.getPropositionParProduit(Matchers.any())).thenReturn(Collections.singletonList(new PropositionJson()));

        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(new DataDocumentContrat());

        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.ARBITRAGE, "ARB_AGREMENTS_ACTE")).thenReturn("arbitrage agrement acte");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE")).thenReturn("agrement convention de preuves");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_CONVENTION_PREUVE_TITLE_DOC")).thenReturn("agrement convention de preuves title doc");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_QAD")).thenReturn("agrement qad");
        when(jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, "AGREMENTS_QAD_TITLE_DOC")).thenReturn("agrement qad title doc");

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);

        when(contratMDPROHelper.isContratAutoriseNonPacteArbitrage(any(ContratHeader.class))).thenReturn(Boolean.TRUE);
    }

    private ContratComplet prepareContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType,
                                                 List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment,
                                                 boolean gestionFinanciereDifferentePossible, boolean imposee,
                                                 boolean indicRefusArbitrageInternet, int nbeArbitrageAnn, String typeContrat,
                                                 SituationContratEnum etatContrat, boolean profile, String numGen) throws TechnicalException {
        final ContratComplet contratComplet = createContratComplet(isPacte, isMdpro, affichageType,
                gestionFinanciereDifferentePossible, compartimentTypes, etatCompartiment, indicRefusArbitrageInternet,
                nbeArbitrageAnn, typeContrat, etatContrat, numGen);
        when(contratFacade.rechercherContratsComplets()).thenReturn(Collections.singletonList(contratComplet));
        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenAnswer(invocation -> buildStructInv(imposee, invocation.getArgument(0), profile));
        when(parcoursSimplifieFacade.isParcoursSimplifieActivate(any(String.class),any(FonctionnaliteType.class))).thenReturn(false);

        return contratComplet;
    }

    private ContratComplet prepareContratCompletMajeur(boolean isPacte, boolean isMdpro, AffichageType affichageType, List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment, boolean gestionFinanciereDifferentePossible, boolean imposee, boolean indicRefusArbitrageInternet, int nbeArbitrageAnn, String typeContrat, SituationContratEnum etatContrat, boolean profile) throws TechnicalException {
        final ContratComplet contratComplet = createContratCompletMajeur(isPacte, isMdpro, affichageType, gestionFinanciereDifferentePossible, compartimentTypes, etatCompartiment, indicRefusArbitrageInternet, nbeArbitrageAnn, typeContrat, etatContrat);
        when(contratFacade.rechercherContratsComplets()).thenReturn(Collections.singletonList(contratComplet));
        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenAnswer(invocation -> buildStructInv(imposee, invocation.getArgument(0), profile));
        when(parcoursSimplifieFacade.isParcoursSimplifieActivate(any(String.class),any(FonctionnaliteType.class))).thenReturn(false);

        return contratComplet;
    }

    private QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> buildChoixCompartimentERE() {
        return QuestionResponsesDto.<ChoixCompartimentDto, BlocageArbitrageContratDto>builder()
                .data(BlocageArbitrageContratDto.builder().contratBloque(false).build())
                .build();
    }

    @Test
    public void startArbitrage_when_contratNonPacte_isERE_and_isMonoSupport_and_has_no_partsArbitrablesTest() throws TechnicalException {
        prepareContratComplet(false, false, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1),
                AFFILIATION_AVEC_BIA, false, false, false, 1,
                "RA09", SituationContratEnum.EN_COURS, false, null);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT.name());
    }

    @Test
    public void startArbitrage_when_contratPacte_isERE_and_isMonoSupport_and_has_no_partsArbitrablesTest() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1),
                AFFILIATION_AVEC_BIA, false, false, false, 1,
                "RA09", SituationContratEnum.EN_COURS, false, null);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isClotureTest() throws TechnicalException {
        prepareContratComplet(false, false, AffichageType.MASQUE, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                SANS_EFFET, false, false, false, 1, "RA09",
                SituationContratEnum.EN_COURS, true, null);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(0, arbitrageStartDto.getArbitrages().size());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_and_isContratAutoriseNonPacteAndContratGarantieOrBeneficiaireAcceptant() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA09", SituationContratEnum.EN_COURS, true, null);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACCD");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGND");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_ETAT_COMPTE.name());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_notFiscalitePEP() throws TechnicalException {
        prepareContratCompletMajeur(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA09", SituationContratEnum.EN_COURS, true);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACCD");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGND");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class))).thenReturn(GestionFinanciereActuelleMdpDto.builder()
                .fiscalitePEP(false)
                .build());

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertFalse(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(QadStatusType.OBLIGATOIRE, arbitrageStartDto.getArbitrages().get(0).getQadStatus());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_withFiscalitePEP() throws TechnicalException {
        prepareContratCompletMajeur(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA09", SituationContratEnum.EN_COURS, true);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACCD");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGND");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });
        when(structureInvFacade.getInfoGestionFinanciereActuelleMdp(any(ContratHeader.class))).thenReturn(GestionFinanciereActuelleMdpDto.builder()
                .fiscalitePEP(true)
                .build());

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertFalse(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(QadStatusType.IMPOSSIBLE, arbitrageStartDto.getArbitrages().get(0).getQadStatus());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_and_isContratNonAutoriseNonPacteAndContratNonGarantieOrBeneficiaireNonAcceptant() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA08", SituationContratEnum.EN_COURS, true, null);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACC");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGN");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });
        when(contratMDPROHelper.isContratAutoriseNonPacteArbitrage(any(ContratHeader.class))).thenReturn(Boolean.FALSE);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_and_isMonoSupportTest() throws TechnicalException {
        prepareContratComplet(true, true, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA09", SituationContratEnum.EN_COURS, false, null);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACCD");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGND");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT.name());
    }

    @Test
    public void startArbitrage_when_contrat_isMDPRO_and_isSouscripteurEqualsAssureAndContratMoral_and_isAssureOrSouscripteurMineurTest() throws TechnicalException {
        prepareContratComplet(false, true, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false, 1,
                "RA09", SituationContratEnum.EN_COURS, true, null);
        when(clausesBenefCtrClient.consulterClausesBenefCtr(Matchers.any(ConsulterClausesBenefCtrDto.class)))
                .thenAnswer((Answer<ConsulterClausesBenefCtrResponseDto>) object -> {
                    ConsulterClausesBenefCtrResponseDto response = new ConsulterClausesBenefCtrResponseDto();
                    ClausesContratDto clausesContrat1 = new ClausesContratDto();
                    clausesContrat1.setCodeTypeBenef("ACCD");
                    clausesContrat1.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    ClausesContratDto clausesContrat2 = new ClausesContratDto();
                    clausesContrat2.setCodeTypeBenef("DGND");
                    clausesContrat2.setDateFinClauseBenef(getDatePlusOneYear(DATE_JOUR));
                    response.setClausesContrat(Arrays.asList(clausesContrat1, clausesContrat2));
                    return response;
                });

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_ETAT_COMPTE.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isArbitrageEnLigneInterditTest() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Collections.singletonList(CompartimentType.C1),
                AFFILIATION_AVEC_BIA, false, true, true, 1,
                "RA09", SituationContratEnum.EN_COURS, true, null);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_CONDITIONS_CONTRAT_MANUEL.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isNbeArbitrageAnnReachedTest() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                0, "RA09", SituationContratEnum.EN_COURS, true, null);

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_NB_MAX_DEPASSE.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isArbitrageEnAttenteValorisationTest_C() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, null);
        when(operationFacade.getOperationsEnCoursERE(Matchers.any())).thenReturn(Collections.singletonList(createOperation("C")));

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_OPERATIONS_EN_COURS.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isArbitrageEnAttenteValorisationTest_P() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, null);
        when(operationFacade.getOperationsEnCoursERE(Matchers.any())).thenReturn(Collections.singletonList(createOperation("E")));

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_OPERATIONS_EN_COURS.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isArbitrageEnAttenteValorisationTest_M() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, null);
        when(operationFacade.getOperationsEnCoursERE(Matchers.any())).thenReturn(Collections.singletonList(createOperation("P")));

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_OPERATIONS_EN_COURS.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_isArbitrageEnAttenteValorisationTest_E() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, null);
        when(operationFacade.getOperationsEnCoursERE(Matchers.any())).thenReturn(Collections.singletonList(createOperation("M")));

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertTrue(arbitrageStartDto.getArbitrages().get(0).isBloque());
        Assert.assertEquals(arbitrageStartDto.getArbitrages().get(0).getRaisonBlocage().getJahiaDicoEntry(), ContratBlocage.ARB_BLOCAGE_OPERATIONS_EN_COURS.name());
    }

    @Test
    public void startArbitrage_when_contrat_isERE_and_arbitrageValoriseTest() throws TechnicalException {
        prepareContratComplet(true, false, AffichageType.NORMAL, Arrays.asList(CompartimentType.C1, CompartimentType.C3),
                AFFILIATION_AVEC_BIA, false, false, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, null);
        when(operationFacade.getOperationsEnCoursERE(Matchers.any())).thenReturn(Collections.singletonList(createOperation("V")));

        ArbitrageStartDto arbitrageStartDto = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertNotNull(arbitrageStartDto.getArbitrages());
        Assert.assertEquals(1, arbitrageStartDto.getArbitrages().size());
        Assert.assertEquals("RG912", arbitrageStartDto.getArbitrages().get(0).getContrat().getNomContrat());
        Assert.assertFalse(arbitrageStartDto.getArbitrages().get(0).isBloque());
    }

    @Test
    public void should_terminate_arbitrage_by_electronic_signature_without_qad_and_contract_ere_not_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        arbitrageFacadeImpl.terminate(createArbitrageTerminateDto(false), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }

    @Test
    public void should_terminate_arbitrage_by_electronic_signature_with_qad_and_contract_ere_not_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(false, false));

        arbitrageFacadeImpl.terminate(createArbitrageTerminateDto(true), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }


    @Test
    public void should_terminate_arbitrage_by_electronic_signature_without_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        arbitrageFacadeImpl.terminate(createArbitrageTerminateDto(false), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }


    @Test
    public void should_terminate_arbitrage_by_electronic_signature_with_qad_and_contract_ere_pacte() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));

        arbitrageFacadeImpl.terminate(createArbitrageTerminateDto(true), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }

    @Test
    public void should_terminate_arbitrage_by_electronic_signature_without_qad_and_compartiment_ere_pacte2() throws IOException, CommonException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));
        when(calculerEncoursContratFacade.getCompteEncoursCompartiment(any(Compartiment.class)))
                .thenReturn(createCompteEncours());

        arbitrageFacadeImpl.terminate(createArbitrageTerminateDtoWithCompartiment(false), false);
        verify(sigElecfacade, times(1)).envoyerDocumentPourSignatureElectronique(any(DemandeCreationSigElec.class),
                Matchers.eq(false));
    }

    @Test
    public void should_fail_when_terminate() throws IOException, TechnicalException, JAXBException {
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(createContratHeader(true, false));
        when(dataDocumentContratFacade.buildDocumentContrat(any(ContratHeader.class), any(CompartimentId.class), any(DocumentDto.class), any(DocRefType.class))).thenReturn(null);
        String terminate = arbitrageFacadeImpl.terminate(createArbitrageTerminateDto(false), false);

        Assert.assertNull(terminate);
    }

    @Test
    public void should_resolve_question_or_next() throws TechnicalException {
        when(choixCompartimentERE.resolve(eq(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT), any(ArbitrageContexteDto.class)))
                .thenReturn(QuestionResponsesDto.<ChoixCompartimentDto, BlocageArbitrageContratDto>builder()
                        .question(QuestionDto.builder()
                                .id(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT)
                                .label(MOCKDATA)
                                .build())
                        .show(true)
                        .build());
        when(choixCompartimentERE.accept(eq(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT), any(ArbitrageContexteDto.class))).thenReturn(true);
        ListQuestionResponsesDto listQuestionResponsesDto = arbitrageFacadeImpl.resolveQuestionOrNext(RequestQuestionArbitrageDto.builder()
                .questionTypeList(Arrays.asList(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT))
                .questionType(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT)
                .contexte(ArbitrageContexteDto.builder().build())
                .build());

        Assert.assertNotNull(listQuestionResponsesDto);
        Assert.assertEquals(1, listQuestionResponsesDto.getQuestionResponsesList().size());
        Assert.assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, listQuestionResponsesDto.getQuestionResponsesList().get(0).getQuestion().getId());
        Assert.assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, listQuestionResponsesDto.getQuestionTypeDisplayed());
        Assert.assertEquals(MOCKDATA, listQuestionResponsesDto.getQuestionResponsesList().get(0).getQuestion().getLabel());
    }

    @Test
    public void should_not_retrieve_contract_pacte_mdpro_c2_when_trying_to_return_contrats_arbitrables_for_start_arbitrage() throws TechnicalException {
        prepareContratComplet(true, true, AffichageType.LECTURE_SEULE, Collections.singletonList(CompartimentType.C2),
                AFFILIATION_AVEC_BIA, true, true, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, "B02");

       ArbitrageStartDto actual = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertEquals(0, actual.getArbitrages().size());
    }


    @Test
    public void should_not_retrieve_contract_pacte_mdpro_c3_when_trying_to_return_contrats_arbitrables_for_start_arbitrage() throws TechnicalException {
        prepareContratComplet(true, true, AffichageType.LECTURE_SEULE, Collections.singletonList(CompartimentType.C3),
                AFFILIATION_AVEC_BIA, true, true, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, "C01");

        ArbitrageStartDto actual = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertEquals(0, actual.getArbitrages().size());
    }

    @Test
    public void should_not_retrieve_contract_pacte_mdpro_non_deductible_when_trying_to_return_contrats_arbitrables_for_start_arbitrage() throws TechnicalException {
        prepareContratComplet(true, true, AffichageType.LECTURE_SEULE, Collections.singletonList(CompartimentType.C1),
                AFFILIATION_AVEC_BIA, true, true, false,
                1, "RA09", SituationContratEnum.EN_COURS, true, "A07");

        ArbitrageStartDto actual = arbitrageFacadeImpl.startModificationArbitrage(null);
        Assert.assertEquals(0, actual.getArbitrages().size());
    }

    private EncoursDto buildCompteEncours() {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(BigDecimal.TEN);
        compteEncours.setEnErreur(false);
        return new EncoursDto(compteEncours);
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, AffichageType affichageType,
                                                boolean allowDifferentInvestmentsForVif,
                                                List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment,
                                                boolean indicRefusArbitrageInternet, int nbeArbitrageAnn, String typeContrat,
                                                SituationContratEnum etatContrat, String numGen) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("RG912");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.setAffichageType(affichageType);
        contratHeader.setTypeContrat(typeContrat);
        contratHeader.setEtatContrat(etatContrat);
        contratHeader.setNumGenContrat(numGen != null ? numGen : "Num");
        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment
                    .builder()
                    .type(compartimentType)
                    .etatCompartiment(etatCompartiment)
                    .affichageType(AffichageType.NORMAL)
                    .build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");
        contratGeneral.setIdContractante("Pid");
        contratGeneral.setIdAssurePrincipal("Pid");
        contratGeneral.setDateNaissanceContractante(DateUtils.createDate(10, 10, 2020));
        contratGeneral.setDateNaissanceAssurePrincipal(DateUtils.createDate(10, 10, 2020));

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        optContratEpargne.setIndicRefusArbitrageInternet(indicRefusArbitrageInternet);
        optContratEpargne.setNbeArbitrageAnn(nbeArbitrageAnn);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private ContratComplet createContratCompletMajeur(boolean isPacte, boolean isMdpro, AffichageType affichageType, boolean allowDifferentInvestmentsForVif, List<CompartimentType> compartimentTypes, SituationAffiliationEnum etatCompartiment, boolean indicRefusArbitrageInternet, int nbeArbitrageAnn, String typeContrat, SituationContratEnum etatContrat) {
        final ContratComplet contratComplet = createContratComplet(isPacte, isMdpro, affichageType, allowDifferentInvestmentsForVif, compartimentTypes, etatCompartiment, indicRefusArbitrageInternet, nbeArbitrageAnn, typeContrat, etatContrat, null);
        contratComplet.getContratGeneral().setDateNaissanceContractante(DateUtils.createDate(10, 10, 2000));
        contratComplet.getContratGeneral().setDateNaissanceAssurePrincipal(DateUtils.createDate(10, 10, 2000));
        return contratComplet;
    }

    private StructInv buildStructInv(boolean imposee, ContratHeader contratHeader, boolean profile) {
        StructInv structInv = new StructInv();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), contratHeader.isPacte());
            final List<ContributionInv> contributionInvs = contributionTypes.stream().map(contributionType -> {
                ContributionInv contributionInv = new ContributionInv();
                contributionInv.setType(contributionType);
                if (profile) {
                    contributionInv.setProfils(Collections.singletonList(newProfil(1, contributionType + "-profil")));
                    contributionInv.setGrilles(Collections.singletonList(newGrille(1, contributionType + "-grille")));
                }
                if (imposee) {
                    contributionInv.setIndicateurTauxDerogeable(false);
                    contributionInv.setTauxRepartitionDefaut(new BigDecimal(100));
                } else {
                    contributionInv.setIndicateurTauxDerogeable(true);
                    contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
                }
                return contributionInv;
            }).collect(Collectors.toList());
            structInv.addContributions(contributionInvs);
        }

        return structInv;
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("123456");
        return userContext;
    }

    private Date getDatePlusOneYear(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.YEAR, 1);
        return calendar.getTime();
    }

    private GrilleInv newGrille(double d, String id) {
        GrilleInv grille = new GrilleInv();
        grille.setTauxRepartitionDefaut(new BigDecimal(d));
        grille.setId(id);
        return grille;
    }

    private ProfilInv newProfil(double d, String id) {
        ProfilInv profil = new ProfilInv();
        profil.setId(id);
        profil.setTauxRepartitionDefaut(new BigDecimal(d));
        profil.setIndicateurTauxDerogeable(true);
        return profil;
    }

    private ArbitrageTerminateDto createArbitrageTerminateDto(boolean withQad) {
        ArbitrageTerminateDto arbitrageTerminateDto = new ArbitrageTerminateDto();

        DocumentDto documentArbitrage = new DocumentDto();
        documentArbitrage.setHtmlContent("html content");
        documentArbitrage.setHtmlStyle("html style");
        arbitrageTerminateDto.setContenuArbitrage(documentArbitrage);
        if (withQad) {
            DocumentDto documentQad = new DocumentDto();
            documentQad.setHtmlContent("html content");
            documentQad.setHtmlStyle("html style");
            arbitrageTerminateDto.setContenuQad(documentQad);
        }
        ContratId contratId = new ContratId();
        contratId.setNomContrat("nom contrat");
        contratId.setIdContractante("id contractante");
        contratId.setIdAdherente("id adherente");
        contratId.setCodeSilo(CodeSiloType.ERE);
        arbitrageTerminateDto.setContratSelected(contratId);
        ContratParcoursDto contratParcours = new ContratParcoursDto();
        contratParcours.setIdentifiantAssure("123456");
        contratParcours.setCollege("college");
        contratParcours.setCodeSilo(CodeSiloType.ERE);
        contratParcours.setCompartimentType(CompartimentType.C3);
        NouvelleRepartitionDto nouvelleRepartitionDto = new NouvelleRepartitionDto();
        nouvelleRepartitionDto.setRepartitions(createRepartition());
        RepartionActuelleDto repartionActuelleDto = new RepartionActuelleDto();
        repartionActuelleDto.setRepartitions(createRepartition());
        DesinvestissementDto desinvestissementDto = new DesinvestissementDto();
        ArbitrageClientDto arbitrageClientDto = ArbitrageClientDto.builder()
                .typeArbitrage(ResponseDto.<QuestionType.ResponseArbitrageFluxStockType>builder()
                        .value(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)
                        .build())
                .compartimentIds(Collections.singletonList(CompartimentId.builder()
                        .idAssure("123456")
                        .compartimentType(CompartimentType.C3)
                        .build()))
                .nouvelleRepartition(nouvelleRepartitionDto)
                .repartitionActuelle(repartionActuelleDto)
                .desinvestissement(desinvestissementDto)
                .build();
        arbitrageTerminateDto.setArbitragesClient(Collections.singletonList(arbitrageClientDto));
        return arbitrageTerminateDto;
    }

    private List<RepartitionSupportDto> createRepartition() {
        RepartitionSupportDto repartitionSupportDto = new RepartitionSupportDto();
        return Collections.singletonList(repartitionSupportDto);
    }

    private ArbitrageTerminateDto createArbitrageTerminateDtoWithCompartiment(boolean withQad) {
        ArbitrageTerminateDto arbitrageTerminateDto = createArbitrageTerminateDto(withQad);
        NouvelleRepartitionDto nouvelleRepartitionDto = new NouvelleRepartitionDto();
        nouvelleRepartitionDto.setRepartitions(createRepartition());
        RepartionActuelleDto repartionActuelleDto = new RepartionActuelleDto();
        repartionActuelleDto.setRepartitions(createRepartition());
        DesinvestissementDto desinvestissementDto = new DesinvestissementDto();
        desinvestissementDto.setDesinvestissementsSupport(createRepartition());
        ArbitrageClientDto arbitrageClientDto = ArbitrageClientDto.builder()
                .typeArbitrage(ResponseDto.<QuestionType.ResponseArbitrageFluxStockType>builder()
                        .value(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)
                        .build())
                .compartimentIds(Collections.singletonList(CompartimentId.builder()
                        .idAssure("123456")
                        .compartimentType(CompartimentType.C3)
                        .build()))
                .nouvelleRepartition(nouvelleRepartitionDto)
                .repartitionActuelle(repartionActuelleDto)
                .desinvestissement(desinvestissementDto)
                .build();
        arbitrageTerminateDto.setArbitragesClient(Collections.singletonList(arbitrageClientDto));
        return arbitrageTerminateDto;
    }

    private ContratParcoursDto createContratCompartiment() {
        return ContratParcoursDto.builder()
                .compartimentType(CompartimentType.C3)
                .codeSilo(CodeSiloType.ERE)
                .estCompartiment(true)
                .identifiantAssure("123456")
                .build();
    }

    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C3)
                .identifiantAssure("123456")
                .build());
        return contratHeader;
    }

    private CompteEncours createCompteEncours() {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setDateValeur(DateUtils.createDate(10, 11, 2020));
        compteEncours.setMontantEncours(BigDecimal.TEN);
        compteEncours.setDeviseEncours("EUR");
        return compteEncours;
    }

    private Operation createOperation(String codeSituationOperationSilo) {
        Operation operation = new Operation();
        operation.setCodeSituationOperationSilo(codeSituationOperationSilo);
        return operation;
    }

    private ProduitJson createProduitJson(String typeContrat, String numGen, String fiscalite, Boolean deductible) {
        ProduitJson produit = new ProduitJson();
        produit.setCodeFiliale("LMX");
        produit.setTypeContrat(typeContrat);
        produit.setNumeroGeneration(numGen);
        produit.setLibelleFiscalite(fiscalite);
        produit.setDeductible(deductible);
        return produit;
    }
}
