package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.ModeGestionMdproType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.GrilleInvDto;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.ModeGestionMdproType.*;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverModeGestionMDPTest {

    @InjectMocks
    ArbitrageQuestionResolverModeGestionMDP arbitrageQuestionResolverModeGestionMDP;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IStructureInvFacade structureInvFacade;

    @Mock
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    private IParamConsoleFacade produitFacade;

    public ContratComplet prepareContratComplet() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(false);
        init(contratComplet);
        return contratComplet;
    }

    public ContratHeader prepare() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(false);
        init(contratComplet);
        return contratComplet.getContratHeader();
    }

    private void init(ContratComplet contratComplet) throws TechnicalException {
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(calculerEncoursContratFacade.getCompteEncoursNonPacte(any(ContratHeader.class))).thenAnswer(invocation -> buildCompteEncours(invocation.getArgument(0)));

        SupportInvestissementJson jsonLibre = new SupportInvestissementJson();
        jsonLibre.setModeGestion("LIBRE");
        SupportInvestissementJson jsonPilotee = new SupportInvestissementJson();
        jsonPilotee.setModeGestion("PILOTEE");
        SupportInvestissementJson jsonDynamisation = new SupportInvestissementJson();
        jsonDynamisation.setModeGestion("DYNAMISATION");
        SupportInvestissementJson jsonHorizon = new SupportInvestissementJson();
        jsonHorizon.setModeGestion("HORIZON");
        when(produitFacade.getSupportsInvestissement("1")).thenReturn(jsonLibre);
        when(produitFacade.getSupportsInvestissement("2")).thenReturn(jsonPilotee);
        when(produitFacade.getSupportsInvestissement("3")).thenReturn(jsonDynamisation);
        when(produitFacade.getSupportsInvestissement("4")).thenReturn(jsonHorizon);
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare();
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        assertTrue(arbitrageQuestionResolverModeGestionMDP.accept(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte));
    }

    @Test
    public void test_ContratFiscalitePEP() throws Exception {
        final ContratComplet contratComplet = prepareContratComplet();
        final ContratHeader contratHeader = contratComplet.getContratHeader();
        contratComplet.getContratGeneral().setCodeCadreFiscal("PEP");

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("1", "2", "3", "4")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 0);
    }

    @Test
    public void test_Contrats() throws Exception {
        final ContratHeader contratHeader = prepare();

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("1", "2", "3", "4")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 4);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(LIBRE)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(DYNAMISATION)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(HORIZON)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(PILOTEE)));
    }

    @Test
    public void test_ContratGestionLibre() throws Exception {
        final ContratHeader contratHeader = prepare();

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("1")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(LIBRE)));
    }

    @Test
    public void test_ContratGestionDynamisation() throws Exception {
        final ContratHeader contratHeader = prepare();

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("3")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(DYNAMISATION)));
    }

    @Test
    public void test_ContratGestionPilotee() throws Exception {
        final ContratHeader contratHeader = prepare();

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("2")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(PILOTEE)));
    }

    @Test
    public void test_ContratGestionHorizon() throws Exception {
        final ContratHeader contratHeader = prepare();

        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenReturn(buildStructInv(contratHeader, Arrays.asList("4")));

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());

        final QuestionResponsesDto<ModeGestionMdproType, ?> resolved = arbitrageQuestionResolverModeGestionMDP.resolve(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_MODEGESTION, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(HORIZON)));
    }

    private ContratComplet createContratComplet(boolean isPacte) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.MDP);
        contratHeader.setPacte(isPacte);
        contratHeader.addCompartiment(Compartiment.builder().type(CompartimentType.C1).build());

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        return contratComplet;
    }

    private StructInv buildStructInv(ContratHeader contratHeader, List<String> codesSupports) {
        StructInv structInv = new StructInv();
        structInv.addContributions(Arrays.asList(buildContributionInv(codesSupports)));
        return structInv;
    }

    private ContributionInv buildContributionInv(List<String> codesSupports) {
        ContributionInv contributionInv = new ContributionInv();
        contributionInv.setType(ContributionType.VERSEMENT_LIBRE);
        contributionInv.setIndicateurTauxDerogeable(true);
        contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);

        for (String codeSupport : codesSupports) {
            contributionInv.getGrilles().add(buildGrilleInv(codeSupport));
        }
        return contributionInv;
    }

    private GrilleInv buildGrilleInv(String idGrille) {
        GrilleInv grilleInv = new GrilleInv();
        grilleInv.setId(idGrille);
        grilleInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
        return grilleInv;
    }

    private CompteEncours buildCompteEncours(ContratHeader contratHeader) {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.getOccurStructInvList().add(buildOccurence("1"));
        compteEncours.getOccurStructInvList().add(buildOccurence("2"));
        compteEncours.getOccurStructInvList().add(buildOccurence("3"));
        compteEncours.getOccurStructInvList().add(buildOccurence("4"));
        return compteEncours;
    }

    private OccurStructInvDto buildOccurence(String idGrille) {
        OccurStructInvDto occur = new OccurStructInvDto();
        GrilleInvDto grille = new GrilleInvDto();
        grille.setIdGrilleInv(idGrille);
        occur.setGrilleInv(grille);
        return occur;
    }
}
