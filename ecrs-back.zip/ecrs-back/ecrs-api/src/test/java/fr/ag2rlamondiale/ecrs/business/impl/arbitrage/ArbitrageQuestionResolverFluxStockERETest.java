package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import lombok.Getter;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverFluxStockERETest {

    @InjectMocks
    ArbitrageQuestionResolverFluxStockERE arbitrageQuestionResolverFluxStockERE;

    @Mock
    IContratFacade contratFacade;


    public ContratHeader prepare(List<CompartimentType> compartimentTypes, boolean arbitrageMixteUniquement, ConfigEncours configEncours, boolean isPacte) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(isPacte, false, arbitrageMixteUniquement, compartimentTypes, configEncours);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 100), false);
        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);

        assertTrue(arbitrageQuestionResolverFluxStockERE.accept(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte));
    }

    @Test
    public void test_unCompartiment_arbitrageMixteAutorise_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 100), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK)));
    }

    @Test
    public void test_unCompartiment_arbitrageMixteInterdit_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new ConfigEncours().setMontant(CompartimentType.C3, 100), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);
    }

    @Test
    public void test_unCompartiment_arbitrageMixteAutorise_encoursNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 0), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        setCompartiment(contratHeader, CompartimentType.C3, contexte);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK) && choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && choix.isDisabled()));
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteAutorise_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 100), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK)));
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteInterdit_encoursNonNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new ConfigEncours().setMontant(CompartimentType.C3, 100), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteAutorise_encoursNull() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 0), false);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK) && choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().equals(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK) && choix.isDisabled()));
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteAutorise_encoursNull_Pacte_Flux() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 0), true);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);
        contexte.setParamFluxStock(ParamFluxStock.FLUX);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUX);
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteAutorise_encoursNonNull_Pacte_Stock() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 100), true);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);
        contexte.setParamFluxStock(ParamFluxStock.STOCK);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertEquals(resolved.getDefaultValue().getValue(), QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_STOCK);
    }

    @Test
    public void test_tousCompartiments_arbitrageMixteAutorise_encoursNull_Pacte_Stock() throws Exception {
        final ContratHeader contratHeader = prepare(Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new ConfigEncours().setMontant(CompartimentType.C3, 0), true);

        ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setContratSelectionne(contratHeader.getContratId());
        contexte.setTousCompartimentsSelectionnes(true);
        contexte.setParamFluxStock(ParamFluxStock.STOCK);

        final QuestionResponsesDto<QuestionType.ResponseArbitrageFluxStockType, ?> resolved = arbitrageQuestionResolverFluxStockERE.resolve(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_FLUXSTOCK, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getWarningMessage() != null);
    }

    public void setCompartiment(ContratHeader contratHeader, CompartimentType compartimentType, ArbitrageContexteDto contexte) {
        contratHeader.getCompartiments().stream()
                .filter(compartiment -> compartiment.getType().equals(compartimentType))
                .findFirst()
                .ifPresent(compartiment -> contexte.setCompartimentSelectionne(compartiment.getCompartimentId()));
    }


    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, boolean arbitrageMixteUniquement, List<CompartimentType> compartimentTypes, ConfigEncours configEncours) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);

        if (!isPacte || isMdpro) {
            contratComplet.setEncours(new Memoizer<>(() -> buildCompteEncours(configEncours.getMontant())));
        }

        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment.builder().type(compartimentType).build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);

            contratComplet.setEncours(compartiment.getCompartimentId(),
                    new Memoizer<>(() -> buildCompteEncours(configEncours.getMontant(compartimentType))));
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setIndicTypeArbitrageAutorise(!arbitrageMixteUniquement);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }


    private ContratHeader createContratHeader(boolean isPacte, boolean isMdpro) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        return contratHeader;
    }

    private Encours buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(new BigDecimal(montant));
        compteEncours.setEnErreur(false);
        return compteEncours;
    }


    @Getter
    private static class ConfigEncours {
        int montant;
        Map<CompartimentType, Integer> montantSelonCompartiment = new HashMap<>();

        ConfigEncours setMontant(int montant) {
            this.montant = montant;
            return this;
        }

        ConfigEncours setMontant(CompartimentType compartimentType, int montant) {
            this.montantSelonCompartiment.put(compartimentType, montant);
            return this;
        }

        int getMontant(CompartimentType compartimentType) {
            return this.montantSelonCompartiment.getOrDefault(compartimentType, this.montant);
        }

    }

}
