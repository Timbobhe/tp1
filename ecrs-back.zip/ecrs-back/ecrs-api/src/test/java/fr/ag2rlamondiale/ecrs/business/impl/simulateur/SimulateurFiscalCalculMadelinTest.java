package fr.ag2rlamondiale.ecrs.business.impl.simulateur;

import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.fiscal.commands.*;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_PASS;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)

public class SimulateurFiscalCalculMadelinTest {

    @InjectMocks
    SimulateurFiscalCalculMadelin simulateurFiscalCalculMadelin;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;


    @Mock
    private IContratFacade contratFacade;

    @Spy
    CalculDisponibleCommand calculDispoFiscalCommand;

    @Spy
    CalculVersementsComplementairesCommand calculVersComplCommand;

    @Spy
    CalculMontantDeductibleCommand calculMontantDeductibleCommand;

    @Spy
    CalculEffortEpargneReelCommand calculEffortEpargneReelCommand;

    @Spy
    CalculEconomieFiscaleCommand calculGainFiscalCommand;

    @Mock
    IOperationFacade operationFacade;

    @Test
    public void test_calcul_disponible_fiscal() throws Exception {


        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41136").build();

        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.MDP)
                .build();
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(0.45));
        demandeCalcul.setAbondement(BigDecimal.valueOf(0));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(145000));
        demandeCalcul.setContrat(contratId);
        demandeCalcul.setCotisation(BigDecimal.valueOf(2256.8));
        demandeCalcul.setYear(2022);
        ContratHeader contratHeader = createContratHeader("id", null, CodeSiloType.MDP);

        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));
        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("Madelin", new BigDecimal(0)));


        // When
        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalCalculMadelin.calculerDisponibleFiscal(demandeCalcul);

        // Then

        assertEquals(new BigDecimal("2262.4800"), resultatCalculEpargne.getPartEffort());
        assertEquals(new BigDecimal("1851.1200"), resultatCalculEpargne.getPartGain());
        assertEquals(new BigDecimal("4113.60"), resultatCalculEpargne.getDisponibleFiscal());
        assertEquals(new BigDecimal("4113.60"), resultatCalculEpargne.getPlafondVersement());
        assertEquals(new BigDecimal("0"), resultatCalculEpargne.getVersementsDeductibles());
        assertEquals(new BigDecimal("0"), resultatCalculEpargne.getDejaVerse());
        assertEquals(new BigDecimal("4113.60"), resultatCalculEpargne.getResteAverser());

    }


    private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
        contrat.setCompartiments(Collections.singletonList(c1));
        return contrat;
    }

    private ContratComplet createContratComplet(String codeCadreFiscal, BigDecimal montantAnneeTTC) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        Compartiment compartiment = new Compartiment();
        compartiment.setContratHeader(contratHeader);
        compartiment.setType(CompartimentType.C1);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setCompartiments(Collections.singletonList(compartiment));

        CompteEncours compteEncours = buildCompteEncours(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto1 = new OccurStructInvDto();
        SupportInvDto supportInvDto = new SupportInvDto();
        supportInvDto.setIdSupportInv("13132");
        occurStructInvDto1.setSupportInv(supportInvDto);
        occurStructInvDto1.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto2 = new OccurStructInvDto();
        occurStructInvDto2.setSupportInv(supportInvDto);
        occurStructInvDto2.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        List<OccurStructInvDto> occurStructInvDtos = new ArrayList<>();
        occurStructInvDtos.add(occurStructInvDto1);
        occurStructInvDtos.add(occurStructInvDto2);
        compteEncours.setOccurStructInvList(occurStructInvDtos);

        contratComplet.setEncours(new Memoizer<>(() -> compteEncours));

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("P12324");
        contratGeneral.setCodeCadreFiscal(codeCadreFiscal);
        contratGeneral.setMontantAnneePrimeTTC(montantAnneeTTC);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();


        contratGeneral.setOptContratEpargne(optContratEpargne);

        Map<CompartimentId, Memoizer<Encours>> encoursParCompartiment = new ConcurrentHashMap<>();
        encoursParCompartiment.put(getCompartimentId(), new Memoizer<>(() -> buildCompteEncours(BigDecimal.valueOf(34))));
        contratComplet.setEncoursParCompartiment(encoursParCompartiment);

        return contratComplet;
    }

    private CompteEncours buildCompteEncours(BigDecimal montant) {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2021));
        compteEncours.setMontantEncours(montant);
        compteEncours.setEncoursEnErreur(false);
        return compteEncours;
    }

    private CompartimentId getCompartimentId() {
        CompartimentId compartimentId = new CompartimentId();
        compartimentId.setCompartimentType(CompartimentType.C1);
        compartimentId.setIdAssure("IDASSURE");
        compartimentId.setNomContrat("RA149819992000");
        return compartimentId;
    }
}
