package fr.ag2rlamondiale.ecrs.api.secure;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import fr.ag2rlamondiale.ecrs.business.IBiaFacade;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaStartDto;
import fr.ag2rlamondiale.ecrs.dto.bia.BiaTerminateDto;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.IOException;

import javax.xml.bind.JAXBException;

@RunWith(MockitoJUnitRunner.class)
public class BiaRestControllerTest {
    @Mock
    IBiaFacade biaFacade;

    @InjectMocks
    BiaRestController sut;

    @Test
    public void should_startBia() throws TechnicalException {
        when(biaFacade.startBia()).thenReturn(new BiaStartDto());

        assertNotNull(sut.start());
    }

    @Test
    public void should_terminate_bia() throws CommonException, JAXBException, IOException {
        sut.terminate(new BiaTerminateDto(), false);

        verify(biaFacade, times(1)).terminateBia(any(BiaTerminateDto.class), Matchers.eq(false));
    }
}
