package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleInv;
import fr.ag2rlamondiale.trm.domain.structinv.NatureSupportInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructureInvCommonFields;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.formulaire.actesenligne.OccurenceStructureInvestissementType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Arrays;

@RunWith(MockitoJUnitRunner.class)
public class OccurenceStructureInvestissementTypeMapperTest {

    @InjectMocks
    private OccurenceStructureInvestissementTypeMapperImpl sut;


    @Test
    public void mapSupportFinancierDtoToOccurenceStructureInvestissementType_with_support_type_profil() {
        SupportFinancierDto arbitrageExpected = createSupportFinancierDto(SupportType.PROFIL);

        OccurenceStructureInvestissementType actual = sut.mapSupportFinancierDtoToOccurenceStructureInvestissementType(
                createSupportFinancierDto(SupportType.PROFIL), BigDecimal.ZERO);

        Assert.assertNotNull(actual);
        Assert.assertEquals(arbitrageExpected.getCommonFields().getId(), actual.getIdentifiantOccurenceStructureInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getParentId(), actual.getIdentifiantOccurenceParentStructureInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getNatureSupport().getCodeNatureSupport(), actual.getCodeNatureSupportInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getLibeNatureSupport(), actual.getLibelleNatureSupportInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getCodeNatureSupportInvSilo(), actual.getCodeNatureSupportInvestissementSilo());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getLibeNatureSupportInvSilo(), actual.getLibelleNatureSupportInvestissementSilo());
        Assert.assertEquals(arbitrageExpected.getTaux(), actual.getProfilInvestissement().getTauxRepartitionProfilInvestissement());
    }


    @Test
    public void mapSupportFinancierDtoToOccurenceStructureInvestissementType_with_support_type_grille() {
        SupportFinancierDto arbitrageExpected = createSupportFinancierDto(SupportType.PROFIL);

        OccurenceStructureInvestissementType actual = sut.mapSupportFinancierDtoToOccurenceStructureInvestissementType(
                createSupportFinancierDto(SupportType.GRILLE), BigDecimal.ZERO);

        Assert.assertNotNull(actual);
        Assert.assertEquals(arbitrageExpected.getCommonFields().getId(), actual.getIdentifiantOccurenceStructureInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getParentId(), actual.getIdentifiantOccurenceParentStructureInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getNatureSupport().getCodeNatureSupport(), actual.getCodeNatureSupportInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getLibeNatureSupport(), actual.getLibelleNatureSupportInvestissement());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getCodeNatureSupportInvSilo(), actual.getCodeNatureSupportInvestissementSilo());
        Assert.assertEquals(arbitrageExpected.getCommonFields().getLibeNatureSupportInvSilo(), actual.getLibelleNatureSupportInvestissementSilo());
        Assert.assertEquals(arbitrageExpected.getTaux(), actual.getGrilleInvestissement().getTauxRepartitionGrilleInvestissement());
    }

    @Test
    public void mapContributionInvToOccurenceStructureInvestissementType() {
        ContributionInv expectedContributionInv = createContributionInv();

        OccurenceStructureInvestissementType actual = sut.mapContributionInvToOccurenceStructureInvestissementType(
                createContributionInv(), BigDecimal.ZERO);

        Assert.assertNotNull(actual);

        Assert.assertEquals(expectedContributionInv.getCommonFields().getId(), actual.getIdentifiantOccurenceStructureInvestissement());
        Assert.assertEquals(expectedContributionInv.getCommonFields().getParentId(), actual.getIdentifiantOccurenceParentStructureInvestissement());
        Assert.assertEquals(expectedContributionInv.getLibelleContributionInv(), actual.getContributionInvestissement().getLibelleContributionInvestissement());
        Assert.assertEquals(expectedContributionInv.getLibelleContributionInvSilo(), actual.getContributionInvestissement().getLibelleContributionInvestissementSilo());
        Assert.assertEquals(expectedContributionInv.getTauxRepartitionContribution(), actual.getContributionInvestissement().getTauxRepartitionContribution());

    }


    private ContributionInv createContributionInv() {
        ContributionInv contributionInv = new ContributionInv();
        contributionInv.setType(ContributionType.PART_PATRONALE);
        contributionInv.setIndicateurTauxDerogeable(true);
        contributionInv.setLibelleContributionInv("libelle contribution inv");
        contributionInv.setLibelleContributionInvSilo("libelle contribution inv silo");
        contributionInv.setTauxRepartitionContribution(BigDecimal.ZERO);
        contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
        contributionInv.setId("id");
        GrilleInv grilleInv = new GrilleInv();
        grilleInv.setId("id");
        grilleInv.setNom("nom");
        grilleInv.setIndicateurTauxDerogeable(true);
        grilleInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
        contributionInv.setGrilles(Arrays.asList(grilleInv));

        StructureInvCommonFields commonFields = new StructureInvCommonFields();

        commonFields.setNatureSupport(NatureSupportInv.UNITE_COMPTE);
        commonFields.setCodeModeGestion("code mode gestion");
        commonFields.setCodeModeGestionSilo("code mode gestion silo");
        commonFields.setCodeNatureSupportInvSilo("code nature support silo");
        commonFields.setId("id");
        commonFields.setLibeNatureSupport("libelle nature support");
        commonFields.setLibeNatureSupportInvSilo("libelle nature support inv silo");
        commonFields.setLibModeGestion("libelle mode gestion");
        commonFields.setLibModeGestionSilo("libelle mode gestion silo");
        commonFields.setMontantSupport(BigDecimal.ZERO);
        commonFields.setParentId("parent id");
        contributionInv.setCommonFields(commonFields);
        return contributionInv;
    }

    private SupportFinancierDto createSupportFinancierDto(SupportType supportType) {
        StructureInvCommonFields commonFields = new StructureInvCommonFields();

        commonFields.setNatureSupport(NatureSupportInv.UNITE_COMPTE);
        commonFields.setCodeModeGestion("code mode gestion");
        commonFields.setCodeModeGestionSilo("code mode gestion silo");
        commonFields.setCodeNatureSupportInvSilo("code nature support silo");
        commonFields.setId("id");
        commonFields.setLibeNatureSupport("libelle nature support");
        commonFields.setLibeNatureSupportInvSilo("libelle nature support inv silo");
        commonFields.setLibModeGestion("libelle mode gestion");
        commonFields.setLibModeGestionSilo("libelle mode gestion silo");
        commonFields.setMontantSupport(BigDecimal.ZERO);
        commonFields.setParentId("parent id");
        ContributionInv contributionInv = new ContributionInv();
        contributionInv.setType(ContributionType.PART_PATRONALE);

        SupportFinancierDto supportFinancierDto = new SupportFinancierDto();
        supportFinancierDto.setCommonFields(commonFields);
        supportFinancierDto.setContributionInvParent(contributionInv);
        supportFinancierDto.setSupportType(supportType);
        supportFinancierDto.setDirty(true);
        supportFinancierDto.setRecommanded(true);
        supportFinancierDto.setSelected(true);
        supportFinancierDto.setUniteDeCompte(true);
        supportFinancierDto.setTaux(new BigDecimal("1.0"));
        supportFinancierDto.setTauxInitial(new BigDecimal("1.0"));
        supportFinancierDto.setTauxModifiable(false);
        supportFinancierDto.setTauxRepartitionDefaut(new BigDecimal("100.0"));

        return supportFinancierDto;
    }
}
