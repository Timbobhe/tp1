package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.trm.client.rest.IConfirmationEmailRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.emailconf.ConfirmationEmailJson;
import fr.ag2rlamondiale.trm.domain.emailconf.EtatConfirmation;
import static org.fest.assertions.Assertions.assertThat;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ConfirmationEmailFacadeImplTest {

    @InjectMocks
    private ConfirmationEmailFacadeImpl confirmationEmailFacade;

    @Mock
    private IConfirmationEmailRestClient confEmailClient;

    @Test
    public void createConfirmationTest() {
        //Given
        ConfirmationEmailJson confirmation = new ConfirmationEmailJson();
        confirmation.setCodeSilo(CodeSiloType.ERE);
        confirmation.setEmail("hi@email.com");
        confirmation.setNumeroPersonne("P3456989");
        confirmation.setEtat(EtatConfirmation.CONF);
        when(confEmailClient.createConfirmation(any(ConfirmationEmailJson.class))).thenReturn(confirmation);

        //when
        String conf = confirmationEmailFacade.createConfirmation("hi@email.com", "P3456989", CodeSiloType.ERE);

        //Then
        assertThat(conf).isNotNull();
//        assertThat(conf);
    }
}
