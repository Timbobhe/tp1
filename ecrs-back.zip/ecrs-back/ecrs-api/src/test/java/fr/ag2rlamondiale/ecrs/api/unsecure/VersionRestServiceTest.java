package fr.ag2rlamondiale.ecrs.api.unsecure;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class VersionRestServiceTest {

    @InjectMocks
    @Spy
    VersionRestService service;

    @Test
    public void afterPropertiesSetTest() throws Exception {
        service.afterPropertiesSet();
        verify(service,times(1)).afterPropertiesSet();
    }

    @Test
    public void versionTest() throws Exception {
        service.version();
        verify(service,times(1)).version();
    }

}
