package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IVersementFacade;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementClientDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementTerminateDto;
import fr.ag2rlamondiale.trm.business.IUploadFileFacade;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.IOException;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class VersementRestControllerTest {
    @Mock
    IVersementFacade versementFacade;

    @Mock
    IUploadFileFacade uploadFileFacade;

    @InjectMocks
    @Spy
    VersementRestController versementRest;

    @Test
    public void startModificationVersementTest() throws TechnicalException {
        versementRest.start();
        verify(versementRest, times(1)).start();
    }

    @Test
    public void terminate() throws TechnicalException, JAXBException, IOException {
        final VersementTerminateDto versementTerminate = new VersementTerminateDto();
        versementTerminate.setVersementClient(new VersementClientDto());
        versementRest.terminate(versementTerminate, false);

        verify(versementRest, times(1)).terminate(any(VersementTerminateDto.class), Matchers.eq(false));
    }

    @Test
    public void questionTest() throws TechnicalException{
        versementRest.question(null);
        verify(versementRest, times(1)).question(null);
    }
    @Test
    public void resolveQuestionOrNextTest() throws TechnicalException{
        versementRest.resolveQuestionOrNext(null);
        verify(versementRest, times(1)).resolveQuestionOrNext(null);
    }
}
