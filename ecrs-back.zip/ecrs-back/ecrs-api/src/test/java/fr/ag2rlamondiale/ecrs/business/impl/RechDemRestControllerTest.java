package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.ecrs.api.secure.RechDemRestController;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demandes;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RechDemRestControllerTest {

    @InjectMocks
    RechDemRestController rechDemRestController;

    @Mock
    IWorkflowFacade facade;

    @Mock
    UserContextHolder userContextHolder;

    @Test
    public void test() throws WorkflowException {
        when(userContextHolder.get()).thenReturn(new UserContext());
        when(facade.rechercherDemandes(Matchers.any(RechDemFront.class)))
                .thenReturn(new Demandes());
        assertNotNull(rechDemRestController.getADemande());
    }
}
