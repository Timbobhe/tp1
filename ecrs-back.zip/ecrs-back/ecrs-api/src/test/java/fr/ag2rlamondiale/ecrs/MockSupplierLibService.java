package fr.ag2rlamondiale.ecrs;

import fr.ag2rlamondiale.trm.ISupplierLibService;

public class MockSupplierLibService implements ISupplierLibService {
    @Override
    public String getCodeCassiniAppli() {
        return "A1573";
    }

    @Override
    public String getLibelleAppli() {
        return "ECRS";
    }

    @Override
    public String getUrlFront() {
        return "http://localhost:4200";
    }
}
