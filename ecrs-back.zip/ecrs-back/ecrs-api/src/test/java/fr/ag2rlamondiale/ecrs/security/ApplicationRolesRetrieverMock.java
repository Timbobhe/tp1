package fr.ag2rlamondiale.ecrs.security;

import com.google.common.base.Splitter;
import fr.ag2rlamondiale.metis.boot.security.dao.IApplicationRolesRetriever;

import java.util.List;

public class ApplicationRolesRetrieverMock implements IApplicationRolesRetriever {
    @Override
    public List<String> getApplicationRoles() {
        return Splitter.on(',')
                .omitEmptyStrings()
                .trimResults()
                .splitToList("EERE-Salarie,NET-Utilisateur,IMP-EERE-Salarie,cla_fonds_pension,EMDPRO-Utilisateur,NET-Pilotage,EERE-Federation");
    }
}
