package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ChoixCompartimentDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static fr.ag2rlamondiale.ecrs.business.impl.arbitrage.DictionnaireArbitrageJahia.ARB_TOUT_CONTRAT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ArbitrageQuestionResolverChoixCompartimentMDPTest {

    @InjectMocks
    ArbitrageQuestionResolverChoixCompartimentMDP arbitrageQuestionResolverChoixCompartimentMDP;

    @Mock
    IContratFacade contratFacade;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;


    public ContratHeader prepare(boolean pacte, boolean gestionFinanciereDifferentePossible, int montantEncours) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        final ContratComplet contratComplet = createContratComplet(pacte, gestionFinanciereDifferentePossible);
        when(contratFacade.rechercherContratCompletParId(any())).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(calculerEncoursContratFacade.getEncoursDto(any(ContratHeader.class))).thenReturn(buildCompteEncours(montantEncours));
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(montantEncours));
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, true, 10);
        assertTrue(arbitrageQuestionResolverChoixCompartimentMDP.accept(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT,
                ArbitrageContexteDto.builder().contratSelectionne(contratHeader.getContratId()).build()));
    }

    @Test
    public void test_NonPacte() throws Exception {
        prepare(false, true, 10);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ContratId contratId = ContratId.builder().codeSilo(CodeSiloType.ERE).build();
        ctx.setContratSelectionne(contratId);
        when(contratFacade.rechercherContratParId(contratId)).thenReturn(new ContratHeader());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentMDP.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().isTousCompartiments() && choix.getJahiaDicoEntry().equals(DictionnaireArbitrageJahia.ARB_TOUT_CONTRAT.name())));
    }

    @Test
    public void test_Pacte() throws Exception {
        prepare(true, true, 10);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ContratId contratId = ContratId.builder().codeSilo(CodeSiloType.ERE).build();
        ctx.setContratSelectionne(contratId);
        when(contratFacade.rechercherContratParId(contratId)).thenReturn(new ContratHeader());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentMDP.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 1);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().isTousCompartiments() && choix.getJahiaDicoEntry().equals(ARB_TOUT_CONTRAT.name())));
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean allowDifferentInvestmentsForVif) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.MDP);
        contratHeader.setPacte(isPacte);

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private EncoursDto buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(BigDecimal.valueOf(montant));
        compteEncours.setEnErreur(false);
        return new EncoursDto(compteEncours);
    }
}
