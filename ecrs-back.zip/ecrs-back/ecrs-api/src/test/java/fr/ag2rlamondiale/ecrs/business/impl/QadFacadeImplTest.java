package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.qad.QadRequestDto;
import fr.ag2rlamondiale.ecrs.dto.qad.QadResultDto;
import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.qad.CodeProfilType;
import fr.ag2rlamondiale.trm.domain.qad.QadResultData;
import fr.ag2rlamondiale.trm.domain.qad.QadType;
import fr.ag2rlamondiale.trm.domain.qad.TypeProfilJson;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class QadFacadeImplTest {

    @InjectMocks
    QadFacadeImpl qadFacade;

    @Mock
    IQadRestClient qadRestClient;

    @Mock
    IContratFacade contratFacade;

    private static int indexQuestion = 0;

    @Test
    public void getQadQuestRepTest() throws TechnicalException {
        ContratId contratId = createContratId();
        QadRequestDto qadRequest = new QadRequestDto();
        qadRequest.setContrat(contratId);
        qadRequest.setType(QadType.COMPLETER_BIA_ERE);
        when(contratFacade.rechercherContrats()).thenReturn(new ArrayList<ContratHeader>());
        when(contratFacade.rechercherContratParId(contratId)).thenReturn(null);

        assertTrue(qadFacade.getQadQuestRep(qadRequest).isEmpty());

    }

    @Test
    public void getQadQuestRepTest2() throws TechnicalException {
        ContratId contratId = createContratId();
        QadRequestDto qadRequest = new QadRequestDto();
        qadRequest.setContrat(contratId);
        qadRequest.setType(QadType.COMPLETER_BIA_ERE);
        List<ContratHeader> contrats = createContratHeaderList();
        when(contratFacade.rechercherContrats()).thenReturn(contrats);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contrats.get(0));
        when(qadRestClient.getQuesRepByProfil(qadRequest.getType().getListeCodeProfil()))
                .thenReturn(new ArrayList<>());
        assertNotNull(qadFacade.getQadQuestRep(qadRequest));
        contrats.get(0).setPacte(true);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contrats.get(0));
        assertNotNull(qadFacade.getQadQuestRep(qadRequest));

    }

    @Test
    public void calculerGrilleTest() throws TechnicalException {
        List<QadResultData> resultats = createQadResultList();
        ContratId contratId = createContratId();
        List<ContratHeader> contrats = createContratHeaderList();
        when(contratFacade.rechercherContrats()).thenReturn(contrats);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contrats.get(0));
        int score = QadResultData.getScoreFromResults(resultats, QadType.COMPLETER_BIA_ERE_PACTE.getListeCodeProfil().iterator().next());
        assertEquals(55, score);
        score = QadResultData.getScoreFromResults(resultats, QadType.COMPLETER_BIA_ERE.getListeCodeProfil().iterator().next());
        assertEquals(0, score);
        QadResultDto qadResultDto = QadResultDto.builder()
                .contrat(contratId)
                .qadResult(resultats)
                .fonctionnaliteType(FonctionnaliteType.COMPLETER_BIA)
                .codesSupportsContrat(null)
                .build();
        assertEquals(0, qadFacade.getTypesPropositionGrille(qadResultDto).size());
        contratId.setCodeSilo(CodeSiloType.MDP);
        qadResultDto.setContrat(contratId);
        assertEquals(0, qadFacade.getTypesPropositionGrille(qadResultDto).size());
    }

    @Test
    public void getTypesProfilParProfilsTest() {
        //Given
        Set<CodeProfilType> profils = Sets.set(CodeProfilType.EPAR, CodeProfilType.PART);

        when(qadRestClient.getTypesProfilParProfils(profils)).thenReturn(createProfilsTypes());

        //When
        // Then
        List<TypeProfilJson> profilJsons = qadFacade.getTypesProfilParProfils(profils, Sets.set());
        assertNotNull(profilJsons);
        assertTrue(profilJsons.size() == 2);
        List<TypeProfilJson> profilJsons2 = qadFacade.getTypesProfilParProfils(profils, Sets.set("codeEpar", "codePart"));
        assertNotNull(profilJsons2);
        assertTrue(profilJsons2.size() == 2);

    }

    private List<TypeProfilJson> createProfilsTypes() {
        TypeProfilJson typeProfilJson = new TypeProfilJson();
        typeProfilJson.setCodeSupport("codeEpar");
        TypeProfilJson typeProfilJson2 = new TypeProfilJson();
        typeProfilJson2.setCodeSupport("codePart");
        return Arrays.asList(typeProfilJson, typeProfilJson2);
    }

    private List<QadResultData> createQadResultList() {
        return Arrays.asList(createQadResult(CodeProfilType.PACTE, "Question1", Arrays.asList("30 ans"), 10),
                createQadResult(CodeProfilType.PACTE, "Question2", Arrays.asList("Action", "Monetaire"), 25),
                createQadResult(CodeProfilType.PACTE, "Question3", Arrays.asList("Intermediaire"), 20));
    }

    private QadResultData createQadResult(CodeProfilType codeProfil, String labelCourt, List<String> reponsesLabels,
                                          int reponseWeight) {
        indexQuestion++;
        return new QadResultData(indexQuestion, indexQuestion, codeProfil, labelCourt, reponsesLabels, reponseWeight);
    }

    private ContratHeader createContratHeader(String id, String college, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setCollege(college);
        contrat.setCodeSilo(silo);
        return contrat;
    }

    private List<ContratHeader> createContratHeaderList() {
        return Arrays.asList(createContratHeader("RG152172242", "Cadres", CodeSiloType.ERE),
                createContratHeader("id1", "idAssur1", CodeSiloType.MDP));
    }

    private ContratId createContratId() {
        return ContratId.ere("RG152172242", null, null, null);
    }
}
