package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.CommunicationClientFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.impl.ContactReclamationFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.impl.ContratFacadeImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ReclamationResponseDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.ecriture.FormulaireContactDto;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.Demandes;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.ZoneId;
import java.util.*;

import static fr.ag2rlamondiale.ecrs.dto.reclamation.State.KO;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class ContactReclamationFacadeImplTest {
    private static final String mailTestAkio = "yasmine.kertous.ext@ag2rlamondiale.fr";
    private static final String mailTestMdpro = "ladislas.halifa.ext@ag2rlamondiale.fr";
    @InjectMocks
    ContactReclamationFacadeImpl contactReclamationFacadeImpl;

    @Bean
    DateMapper dateMapper() {
        return new DateMapper();
    }

    @Mock
    IWorkflowFacade workflowFacade;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    IConsulterPersPhysFacade persPhysFacade;

    @Mock
    CommunicationClientFacadeImpl communicationClientFacade;

    @Mock
    CommunicationClientFacadeImpl gestEditiqueFacadeImpl;

    @Mock
    ContratFacadeImpl contratFacade;

    @Mock
    IBlocageFacade blocageFacade;

    @Mock
    private ContratParcoursMapper contratParcoursMapper;

    @Before
    public void init() throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "isCreerDemComActivated", "true");
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "mailContactAkioDestinataire", mailTestAkio);
        ReflectionTestUtils.setField(gestEditiqueFacadeImpl, "mailGestionMDPRO", mailTestMdpro);
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> new InfosBlocagesClient());
        when(userContextHolder.get()).thenReturn(mock(UserContext.class));
        when(userContextHolder.get().getNom()).thenReturn(MOCKDATA);
        when(userContextHolder.get().getPrenom()).thenReturn(MOCKDATA);
        when(workflowFacade.rechercherDemandes(any())).thenAnswer(invocation -> {

            Demandes demandes = new Demandes();
//            for (int i = 0; i < 5; i++) {
//                demandes.add(new Demande());
//            }

            return demandes;
        });
    }

    @Test
    public void createDemande() throws TechnicalException {
        //Given
        ContactReclamationDto dtoERE = createContactReclamationDtoObject(ERE);
        ContactReclamationDto dtoMDP = createContactReclamationDtoObject(MDP);

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        physiqueConsult.setCivilite("M.");
        physiqueConsult.setDateDeNaissance(buildDate(2019, 1, 25, 17, 21, 56, 271).getTime());

        //When
        when(persPhysFacade.consulterPersPhys(any())).thenReturn(physiqueConsult);
        when(contratFacade.rechercherContratParId(anyString())).thenAnswer(invocation -> {
            ContratHeader contratHeader = new ContratHeader();
            contratHeader.setCodeSilo(ERE);
            return contratHeader;
        });
        ReclamationResponseDto retourERE = contactReclamationFacadeImpl.createDemande(dtoERE);
        ReclamationResponseDto retourMDP = contactReclamationFacadeImpl.createDemande(dtoMDP);


        //Then
        Assert.assertNotNull(retourERE);
        Assert.assertEquals(KO, retourERE.getState());
        Assert.assertNotNull(retourMDP);
        Assert.assertEquals(KO, retourMDP.getState());
    }

    @Test
    public void getDemandeWorkflowTypeTest() {
        //Then
        Assert.assertEquals(DemandeWorkflowType.QUESTION_GESTION_SALARIE, contactReclamationFacadeImpl.getDemandeWorkflowType(ContactReclamationDto.builder().codeSilo(ERE).codeQuestion("1").build()));
        Assert.assertEquals(DemandeWorkflowType.QUESTION_FONCT_SITE_SALARIE, contactReclamationFacadeImpl.getDemandeWorkflowType(ContactReclamationDto.builder().codeSilo(ERE).codeQuestion("2").build()));
        Assert.assertEquals(DemandeWorkflowType.QUESTION_VIF_SALARIE, contactReclamationFacadeImpl.getDemandeWorkflowType(ContactReclamationDto.builder().codeSilo(ERE).codeQuestion("3").build()));
    }

    @Test
    public void mapperContactReclamationToFormulaireContactTest() throws TechnicalException {

        //Given
        ContactReclamationDto dto = createContactReclamationDtoObject(ERE);
        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        physiqueConsult.setCivilite("M.");
        physiqueConsult.setDateDeNaissance(buildDate(2019, 1, 25, 17, 21, 56, 271).getTime());
        when(persPhysFacade
                .consulterPersPhys(any())).thenReturn(physiqueConsult);
        //When
        FormulaireContactDto result = contactReclamationFacadeImpl.mapperContactReclamationToFormulaireContact(dto);

        //Then
        Assert.assertNotNull(result);
        Assert.assertEquals(dto.getIdAssure(), result.getIdAssure());
    }


    @Test
    public void should_retrieve_contracts_for_contact_when_ere() throws TechnicalException {
        when(contratFacade.rechercherContrats()).thenReturn(Collections.singletonList(createContratHeader(ERE, false, null, AffichageType.NORMAL)));
        List<ContratParcoursDto> actual = contactReclamationFacadeImpl.start();
        Assert.assertEquals(1, actual.size());
    }


    @Test
    public void should_retrieve_empty_list_contracts_for_contact_when_mdpro_pacte_c2() throws TechnicalException {
        when(contratFacade.rechercherContrats()).thenReturn(Collections.singletonList(createContratHeader(MDP, true, CompartimentType.C2, AffichageType.LECTURE_SEULE)));
        List<ContratParcoursDto> actual = contactReclamationFacadeImpl.start();
        Assert.assertEquals(0, actual.size());
    }

    @Test
    public void should_retrieve_empty_list_contracts_for_contact_when_mdpro_pacte_c3() throws TechnicalException {
        when(contratFacade.rechercherContrats()).thenReturn(Collections.singletonList(createContratHeader(MDP, true, CompartimentType.C3, AffichageType.LECTURE_SEULE)));
        List<ContratParcoursDto> actual = contactReclamationFacadeImpl.start();
        Assert.assertEquals(0, actual.size());
    }

    private ContratHeader createContratHeader(CodeSiloType codeSiloType, boolean isPacte, CompartimentType compartimentType, AffichageType affichageType) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(codeSiloType);
        contratHeader.setPacte(isPacte);
        contratHeader.setAffichageType(affichageType);
        if (MDP.equals(codeSiloType) && isPacte) {
            contratHeader.setTypeContrat("RA09");
        }
        if (compartimentType != null) {
            List<Compartiment> compartiments = new ArrayList<>();
            Compartiment compartiment = new Compartiment();
            compartiment.setContratHeader(contratHeader);
            compartiment.setType(compartimentType);
            if (compartiment.isMdpro()) {
                if (CompartimentType.C2.equals(compartimentType)) {
                    contratHeader.setNumGenContrat("B02");
                } else if (CompartimentType.C3.equals(compartimentType)) {
                    contratHeader.setNumGenContrat("C02");
                }
            }
            compartiments.add(compartiment);
            contratHeader.setCompartiments(compartiments);
        }
        return contratHeader;
    }

    private Calendar buildDate(int year, int month, int day, int hour, int minute, int second, int millis) {
        return new Calendar.Builder()
                .setDate(year, month, day)
                .setTimeOfDay(hour, minute, second, millis)
                .setTimeZone(TimeZone.getTimeZone(ZoneId.systemDefault()))
                .build();
    }

    private ContactReclamationDto createContactReclamationDtoObject(CodeSiloType codeSilo) {
        ContactReclamationDto dto = new ContactReclamationDto();
        dto.setIdContrat("RG142295702");
        dto.setIdAssure("114765");
        dto.setIdPersonne("P2137726");
        dto.setCodeSilo(codeSilo);
        dto.setCodeFiliale("ARI");
        dto.setCodeQuestion("1");
        dto.setMessage("message test");
        dto.setReclamation(false);
        dto.setEmail("jymounou@cirrus-sa.com");
        dto.setTelephone("0793321380");
        dto.setRaisonSociale("CIRRUS");
        return dto;
    }
}
