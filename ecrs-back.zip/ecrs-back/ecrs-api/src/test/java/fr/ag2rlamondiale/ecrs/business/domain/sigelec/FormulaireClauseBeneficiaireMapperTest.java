package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireClauseBenef;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import org.apache.commons.io.FileUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
@ContextConfiguration(classes = FormulaireClauseBeneficiaireMapperTest.class)
@Configuration
public class FormulaireClauseBeneficiaireMapperTest {
    public static final String SRC_TEST_RESOURCES_XML_FORM_ClauseBenef_XML = "src/test/resources/xml/Form_ClauseBenef.xml";
    @Spy
    private DateMapper dateMapper;

    @InjectMocks
    FormulaireClauseBeneficiaireMapperImpl sut;

    @Test
    public void should_map_clausebenef_form() throws IOException {
        File file = new File(SRC_TEST_RESOURCES_XML_FORM_ClauseBenef_XML);
        FormulaireClauseBenef expected = XmlMarshaller.fromXml(StringEscapeUtils.unescapeXml(FileUtils.readFileToString(file, StandardCharsets.UTF_8)), FormulaireClauseBenef.class);

        FormulaireClauseBenef actual = sut.createFormulaireClauseBeneficiaire(createDemandeCreationSigElecClauseBenefifiaire());
        actual.setInstantInitialisationDemande(DateUtils.dateTimeToXmlCalendar(DateUtils.parseDate("2020-08-05T21:31:24.994+02:00", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));

        assertEquals(JsonMarshaller.toJSON(expected), JsonMarshaller.toJSON(actual));
    }

    @Test
    public void mapFormulaireClauseBeneftoNullTest() {
        // When
        FormulaireClauseBenef actual = sut.createFormulaireClauseBeneficiaire(null);

        // Then
        assertNull(actual);
    }

    private DemandeCreationSigElecClauseBeneficiaire createDemandeCreationSigElecClauseBenefifiaire() {
        DemandeCreationSigElecClauseBeneficiaire demandeCreationSigElec = new DemandeCreationSigElecClauseBeneficiaire();

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setId("P4347307");

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("RG151361516");

        demandeCreationSigElec.setIdGdi("8sw4kw");
        demandeCreationSigElec.setIdentifiantAssure("762831");
        demandeCreationSigElec.setIdDemandeWkf("679164");

        demandeCreationSigElec.setClauseBeneficiaire("LIB");
        demandeCreationSigElec.setClauseBeneficiaireDescription("Je d\u00E9signe comme b\u00E9n\u00E9ficiaire des prestations pr\u00E9vues en cas de d\u00E9c\u00E8s avant le terme de mon affiliation: \u00E0 mes enfants, n\u00E9s ou \u00E0 na\u00EEtre, vivants ou repr\u00E9sent\u00E9s, par parts \u00E9gales, \u00E0 d\u00E9faut mes h\u00E9ritiers.");

        demandeCreationSigElec.setContrats(Collections.singletonList(contratHeader));
        demandeCreationSigElec.setPersonPhysique(personnePhysiqueConsult);
        return demandeCreationSigElec;
    }
}
