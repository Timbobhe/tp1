package fr.ag2rlamondiale.ecrs.security;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletResponse;

import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireException.ErrorCode;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;

@RunWith(MockitoJUnitRunner.Silent.class)
public class PartenaireExceptionFilterTest {

    @InjectMocks
    PartenaireExceptionFilter partenaireExceptionFilter;

    @Mock
    UserContextHolder userContextHolder;

    @Test
    public void doFilter() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        doNothing().when(filterChain).doFilter(any(ServletRequest.class),
                any(ServletResponse.class));

        partenaireExceptionFilter.doFilter(null, null, filterChain);

        assertNotNull(filterChain);
    }

    @Test
    public void doFilterExpetions() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        doThrow(new IOException()).when(filterChain).doFilter(any(ServletRequest.class),
                any(ServletResponse.class));

        when(userContextHolder.get()).thenReturn(null);

        partenaireExceptionFilter.doFilter(null, null, filterChain);

        assertNotNull(filterChain);
    }

    @Test
    public void doFilterExpetions2() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        doThrow(new IOException()).when(filterChain).doFilter(any(ServletRequest.class),
                any(ServletResponse.class));

        when(userContextHolder.get()).thenReturn(new UserContext());

        partenaireExceptionFilter.doFilter(null, null, filterChain);

        assertNotNull(filterChain);
    }

    @Test
    public void doFilterExpetions3() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        doThrow(new IOException()).when(filterChain).doFilter(any(ServletRequest.class),
                any(ServletResponse.class));

        UserContext user = new UserContext();
        Partenaire part = new Partenaire();
        user.setPartenaire(part);
        when(userContextHolder.get()).thenReturn(user);

        partenaireExceptionFilter.doFilter(null, null, filterChain);

        assertNotNull(filterChain);
    }

    @Test
    public void doFilterExpetions5() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        Mockito.ignoreStubs();
        doThrow(new IOException()).when(filterChain).doFilter(any(ServletRequest.class),
                any(ServletResponse.class));
        
        MockHttpServletResponse response = new MockHttpServletResponse();
        UserContext user = new UserContext();
        Partenaire part = new Partenaire();
        part.setUrlError("http://foo");
        user.setPartenaire(part);
        when(userContextHolder.get()).thenReturn(user);

        partenaireExceptionFilter.doFilter(null, response, filterChain);

        assertNotNull(filterChain);
    }

    @Test
    public void doFilterExpetions6() throws Exception {
        FilterChain filterChain = mock(FilterChain.class);
        PartenaireException ex = new PartenaireException(ErrorCode.UNKNOWN_PARTENAIRE);
        doThrow(ex).when(filterChain)
                .doFilter(any(ServletRequest.class), any(ServletResponse.class));

        MockHttpServletResponse response = new MockHttpServletResponse();
        UserContext user = new UserContext();
        Partenaire part = new Partenaire();
        part.setUrlError("http://foo");
        user.setPartenaire(part);
        when(userContextHolder.get()).thenReturn(user);

        partenaireExceptionFilter.doFilter(null, response, filterChain);

        assertNotNull(filterChain);
    }

}
