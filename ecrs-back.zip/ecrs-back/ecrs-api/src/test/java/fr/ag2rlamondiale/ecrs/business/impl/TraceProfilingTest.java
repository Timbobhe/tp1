package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.alm.esb.service.gestpersphys_2.RechPersPhysClient8Port;
import com.alm.esb.service.gestpersphys_2.rechpersphysclient_8.IdSiloType;
import com.alm.esb.service.gestpersphys_2.rechpersphysclient_8.PersonnePhysiqueType;
import com.alm.esb.service.gestpersphys_2.rechpersphysclient_8.RechPersPhysClientFuncType;
import com.alm.esb.service.gestpersphys_2.rechpersphysclient_8.RechPersPhysClientResponseType;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.business.impl.TraceFacadeImpl;
import fr.ag2rlamondiale.trm.client.rest.ITraceRestClient;
import fr.ag2rlamondiale.trm.client.rest.impl.TraceRestClientImpl;
import fr.ag2rlamondiale.trm.client.soap.IRecherchePersonneClient;
import fr.ag2rlamondiale.trm.client.soap.factory.PFSWebServiceFactory;
import fr.ag2rlamondiale.trm.client.soap.impl.RecherchePersonneSoapClientImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.personne.RechPersPhysMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.personne.RechPersPhysMapperImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.personne.RechPersPhysReponseMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.personne.RechPersPhysReponseMapperImpl;
import fr.ag2rlamondiale.trm.configuration.ConsoleProperties;
import fr.ag2rlamondiale.trm.demo.CompteDemoEndpointResolver;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.profile.AbstractProfilingInterceptor;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DefaultEndpointResolver;
import fr.ag2rlamondiale.trm.utils.IEndpointResolver;
import fr.ag2rlamondiale.trm.utils.InfoNavigateur;
import fr.ag2rlamondiale.trm.utils.SecurityServiceConfig;
import fr.ag2rlamondiale.ecrs.utils.MockUserContext;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = TraceProfilingTest.TraceProfilingTestContext.class)
public class TraceProfilingTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";

    @Autowired
    private IRecherchePersonneClient recherchePesonneSoapClient;


    @Rule
    public MockitoRule rule = MockitoJUnit.rule();
    public static class TraceProfilingTestContext {

        private ITraceRestClient traceRestClient = mock(TraceRestClientImpl.class);

        private UserContextHolder userContextHolder = mock(UserContextHolder.class);

        private InfoNavigateur infoNavigateur = mock(InfoNavigateur.class);

        @Bean
        AbstractProfilingInterceptor profilingInterceptor() {
            return new AbstractProfilingInterceptor();
        }

        @Bean
        CompteDemoEndpointResolver compteDemoEndpointResolver() {
            return new CompteDemoEndpointResolver();
        }

        @Bean
        IEndpointResolver portInitializerUrl() {
            return new DefaultEndpointResolver();
        }

        @Bean
        TraceFacadeImpl traceFacade() {
            return new TraceFacadeImpl();
        }

        @Bean
        RechPersPhysMapper rechPersPhysMapper() {
            return new RechPersPhysMapperImpl();
        }

        @Bean
        RechPersPhysReponseMapper rechPersPhysResponseMapper() {
            return new RechPersPhysReponseMapperImpl();
        }

        @Bean
        RecherchePersonneSoapClientImpl recherchePersonneSoapClient() {
            return new RecherchePersonneSoapClientImpl();
        }

        @Bean
        PFSWebServiceFactory pfsWebServiceFactory() {
            PFSWebServiceFactory factory = mock(PFSWebServiceFactory.class);
            when(factory.getRechPersPhysClient8Service()).thenReturn(mockRechPersPhysClient8Port());
            return factory;
        }


        private RechPersPhysClient8Port mockRechPersPhysClient8Port() {
            return in -> {
                RechPersPhysClientResponseType res = new RechPersPhysClientResponseType();
                RechPersPhysClientFuncType value = new RechPersPhysClientFuncType();
                PersonnePhysiqueType pp = new PersonnePhysiqueType();
                IdSiloType idSilo = new IdSiloType();
                idSilo.setCodeAppli(CodeApplicationType.EGESPER_ERE.getCode());
                idSilo.setLibIdPersonne(NUM_PERS_ERE);
                pp.getIdSilo().add(idSilo);
                value.getPersonnePhysique().add(pp);
                res.setRechPersPhysClientFunc(value);
                return res;
            };
        }


        @Bean
        ITraceRestClient traceRestClient() {
            when(traceRestClient.insert(any(TraceJson.class))).then(invocation -> {
                TraceJson traceJson = (TraceJson) invocation.getArguments()[0];
                assertEquals(CodeActionType.TP_SM_PER_PP.name(), traceJson.getCodeAction());
                assertEquals(ID_GDI, traceJson.getIdGdi());
                return true;
            });

            return traceRestClient;
        }

        @Bean
        UserContextHolder userContextHolder() {
            when(userContextHolder.get()).thenReturn(createUserContextERE());
            return userContextHolder;
        }


        private UserContext createUserContextERE() {
            MockUserContext userContext = new MockUserContext();
            userContext.setIdGdi(ID_GDI);
            userContext.setNumeroPersonneEre(NUM_PERS_ERE);
            return userContext;
        }

        @Bean
        InfoNavigateur infoNavigateur() {
            when(infoNavigateur.navInfo()).thenReturn("INFO NAVIGATEUR");
            return infoNavigateur;
        }

        @Bean
        SecurityServiceConfig mapperUtils() {
            return new SecurityServiceConfig();
        }

        @Bean
        RestTemplate restTemplate() {
            return new RestTemplate();
        }

        @Bean
        RecherchePersonneSoapClientImpl recherchePesonneSoapClient() {
            return new RecherchePersonneSoapClientImpl();
        }

        @Bean("consoleProps")
        ConsoleProperties consoleProperties() {
            return new ConsoleProperties();
        }

        @Bean
        ISupplierLibService supplierLibService() {
            return new ISupplierLibService() {
                @Override
                public String getCodeCassiniAppli() {
                    return "A1573";
                }

                @Override
                public String getLibelleAppli() {
                    return "TEST";
                }

                @Override
                public String getUrlFront() {
                    return "http://url.front";
                }
            };
        }
    }



    @Test
    public void test_Trace_TP_SM_PER_PP() throws CommonException {
        RequetePersonnePhysique criteres = new RequetePersonnePhysique();
        criteres.setIdGDI(ID_GDI);

        // PersonnePhysique retour =
        //clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
        PersonnePhysique retour = recherchePesonneSoapClient.recherche(criteres);

        assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }


}
