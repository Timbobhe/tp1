package fr.ag2rlamondiale.ecrs.api.unsecure;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PublicRestServiceExampleTest {
    @InjectMocks
    PublicRestServiceExample sut;

    @Test
    public void helloTest(){
        Assert.assertNotNull(sut.hello());
    }
}
