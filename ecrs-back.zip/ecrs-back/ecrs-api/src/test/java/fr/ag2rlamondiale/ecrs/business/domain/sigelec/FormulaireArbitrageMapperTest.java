package fr.ag2rlamondiale.ecrs.business.domain.sigelec;

import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.NatureSupportInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructureInvCommonFields;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import fr.ag2rlamondiale.formulaire.actesenligne.FormulaireArbitrage;
import org.apache.commons.io.FileUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.bind.JAXBException;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.*;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class FormulaireArbitrageMapperTest {
    public static final String SRC_TEST_RESOURCES_XML_FORM_ARBITRAGE_XML = "src/test/resources/xml/Form_Arbitrage.xml";
    @Spy
    OccurenceStructureInvestissementTypeMapper occurenceStructureInvestissementTypeMapper = new OccurenceStructureInvestissementTypeMapperImpl();

    @Spy
    private DateMapper dateMapper;

    @InjectMocks
    private FormulaireArbitrageMapperImpl sut;

    @Test
    public void should_map_demande_creation_sig_elec_arbitrage_to_formulaire_arbitrage() throws IOException {
        File file = new File(SRC_TEST_RESOURCES_XML_FORM_ARBITRAGE_XML);

        FormulaireArbitrage expected = XmlMarshaller.fromXml(StringEscapeUtils.unescapeXml(FileUtils.readFileToString(file, StandardCharsets.UTF_8)), FormulaireArbitrage.class);

        FormulaireArbitrage actual = sut.createFormulaireArbitrage(createDemandeCreationSigElecArbitrage());
        actual.setInstantInitialisationDemande(DateUtils.dateTimeToXmlCalendar(DateUtils.parseDate("2020-08-10T09:49:49.160+02:00", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));

        assertEquals(JsonMarshaller.toJSON(expected), JsonMarshaller.toJSON(actual));
    }


    @Test
    public void should_put_in_form_arbitrage() throws JAXBException, IOException {
        File file = new File(SRC_TEST_RESOURCES_XML_FORM_ARBITRAGE_XML);

        Map<String, String> mapForm = new HashMap<>();
        sut.putInFormMap(createDemandeCreationSigElecArbitrage(), mapForm);

        FormulaireArbitrage expected = XmlMarshaller.fromXml(StringEscapeUtils.unescapeXml(FileUtils.readFileToString(file, StandardCharsets.UTF_8)), FormulaireArbitrage.class);
        FormulaireArbitrage actual = XmlMarshaller.fromXml(StringEscapeUtils.unescapeXml((mapForm.values().stream().findFirst().orElse(null))), FormulaireArbitrage.class);
        actual.setInstantInitialisationDemande(DateUtils.dateTimeToXmlCalendar(DateUtils.parseDate("2020-08-10T09:49:49.160+02:00", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")));

        assertEquals(JsonMarshaller.toJSON(expected), JsonMarshaller.toJSON(actual));
    }


    private DemandeCreationsigElecArbitrage createDemandeCreationSigElecArbitrage() {
        DemandeCreationsigElecArbitrage demandeCreationsigElecArbitrage = new DemandeCreationsigElecArbitrage();
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setId("RG129441359");
        contratHeader.setRaisonSocialeFront("SAFRAN AIRCRAFT ENGINES");
        contratHeader.setCollege("Ing\u00E9nieurs et Cadres relevant de l'article 4 de la Convention Nationale AGIRC du 14 mars 1947");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        demandeCreationsigElecArbitrage.setCodeSilo(CodeSiloType.ERE);

        demandeCreationsigElecArbitrage.setResponseArbitrageFluxStock(QuestionType.ResponseArbitrageFluxStockType.ARBITRAGE_FLUXSTOCK);

        demandeCreationsigElecArbitrage.setContrats(Collections.singletonList(contratHeader));
        demandeCreationsigElecArbitrage.setIdentifiantAssure("310600");
        demandeCreationsigElecArbitrage.setIdGdi("riewdy");
        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setId("P0913941");
        personnePhysiqueConsult.setNom("MOSSER");
        personnePhysiqueConsult.setPrenom("PIERRE ETIENNE");
        personnePhysiqueConsult.setDateDeNaissance(DateUtils.parseDate("1957-05-31+01:00", "yyyy-MM-dd"));
        personnePhysiqueConsult.setCivilite("MR");
        personnePhysiqueConsult.setEmailPro("pierre-etienne.mosser@wanadoo.fr");
        demandeCreationsigElecArbitrage.setPersonPhysique(personnePhysiqueConsult);
        demandeCreationsigElecArbitrage.setIdDemandeWkf("681020");
        demandeCreationsigElecArbitrage.setMontant(new BigDecimal("138601.49"));
        demandeCreationsigElecArbitrage.setDeviseEncours("EUR");
        demandeCreationsigElecArbitrage.setDateEncours(DateUtils.parseDate("2020-08-10+02:00", "yyyy-MM-dd"));


        StructureInvCommonFields commonFields1 = new StructureInvCommonFields();
        commonFields1.setId("SF_72000");
        commonFields1.setParentId("SF_72148");
        commonFields1.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFields1.setCodeNatureSupportInvSilo("FG");
        commonFields1.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFields1.setLibeNatureSupport("Fonds de gestion");

        StructureInvCommonFields commonFieldsParent = new StructureInvCommonFields();
        commonFieldsParent.setId("SF_7977769");
        commonFieldsParent.setParentId("SF_72148");

        ContributionInv contributionInvParent = new ContributionInv();
        contributionInvParent.setId("7977769");
        contributionInvParent.setType(ContributionType.VERSEMENT_LIBRE);
        contributionInvParent.setLibelleContributionInvSilo("Versement libre");
        contributionInvParent.setLibelleContributionInv("Versement Libre");
        contributionInvParent.setTauxRepartitionContribution(new BigDecimal("1"));
        contributionInvParent.setIndicateurTauxDerogeable(false);
        contributionInvParent.setCommonFields(commonFieldsParent);

        SupportFinancierDto supportFinancierDto1 = new SupportFinancierDto();
        supportFinancierDto1.setCommonFields(commonFields1);
        supportFinancierDto1.setSupportType(SupportType.PROFIL);
        supportFinancierDto1.setNom("Actif en euros");
        supportFinancierDto1.setCode("212");
        supportFinancierDto1.setTaux(new BigDecimal("1.0"));
        supportFinancierDto1.setTauxModifiable(false);
        supportFinancierDto1.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFields2 = new StructureInvCommonFields();
        commonFields2.setId("SF_7977771");
        commonFields2.setParentId("SF_7977769");
        commonFields2.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFields2.setCodeNatureSupportInvSilo("FG");
        commonFields2.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFields2.setLibeNatureSupport("Fonds Euro");

        SupportFinancierDto supportFinancierDto2 = new SupportFinancierDto();
        supportFinancierDto2.setCommonFields(commonFields2);
        supportFinancierDto2.setSupportType(SupportType.PROFIL);
        supportFinancierDto2.setNom("Actif en euros");
        supportFinancierDto2.setCode("212");
        supportFinancierDto2.setTaux(BigDecimal.ZERO);
        supportFinancierDto2.setTauxModifiable(false);
        supportFinancierDto2.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFields3 = new StructureInvCommonFields();
        commonFields3.setId("SF_10831278");
        commonFields3.setParentId("SF_7977769");
        commonFields3.setLibeNatureSupportInvSilo("Mixte");
        commonFields3.setCodeNatureSupportInvSilo("MI");
        commonFields3.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields3.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto3 = new SupportFinancierDto();
        supportFinancierDto3.setCommonFields(commonFields3);
        supportFinancierDto3.setSupportType(SupportType.GRILLE);
        supportFinancierDto3.setNom("Gestion pilot\u00E9e par horizon Prudente");
        supportFinancierDto3.setCode("5410");
        supportFinancierDto3.setTaux(new BigDecimal("1"));
        supportFinancierDto3.setTauxModifiable(false);
        supportFinancierDto3.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFields4 = new StructureInvCommonFields();
        commonFields4.setId("SF_10831302");
        commonFields4.setParentId("SF_7977769");
        commonFields4.setLibeNatureSupportInvSilo("Mixte");
        commonFields4.setCodeNatureSupportInvSilo("MI");
        commonFields4.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields4.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto4 = new SupportFinancierDto();
        supportFinancierDto4.setCommonFields(commonFields4);
        supportFinancierDto4.setSupportType(SupportType.GRILLE);
        supportFinancierDto4.setNom("Gestion pilot\u00E9e par horizon Equilibre");
        supportFinancierDto4.setCode("5430");
        supportFinancierDto4.setTaux(new BigDecimal("0"));
        supportFinancierDto4.setTauxModifiable(false);
        supportFinancierDto4.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFields5 = new StructureInvCommonFields();
        commonFields5.setId("SF_10831324");
        commonFields5.setParentId("SF_7977769");
        commonFields5.setLibeNatureSupportInvSilo("Mixte");
        commonFields5.setCodeNatureSupportInvSilo("MI");
        commonFields5.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields5.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto5 = new SupportFinancierDto();
        supportFinancierDto5.setCommonFields(commonFields5);
        supportFinancierDto5.setSupportType(SupportType.GRILLE);
        supportFinancierDto5.setNom("Gestion pilot\u00E9e par horizon Dynamique");
        supportFinancierDto5.setCode("5454");
        supportFinancierDto5.setTaux(new BigDecimal("0"));
        supportFinancierDto5.setTauxModifiable(false);
        supportFinancierDto5.setContributionInvParent(contributionInvParent);

        StructureInvCommonFields commonFieldsParent1 = new StructureInvCommonFields();
        commonFieldsParent1.setId("SF_72225");
        commonFieldsParent1.setParentId("SF_72148");

        ContributionInv contributionInvParent1 = new ContributionInv();
        contributionInvParent1.setId("72225");
        contributionInvParent1.setType(ContributionType.PART_PATRONALE);
        contributionInvParent1.setLibelleContributionInvSilo("Part patronale");
        contributionInvParent1.setLibelleContributionInv("Part Patronale");
        contributionInvParent1.setTauxRepartitionContribution(new BigDecimal("1"));
        contributionInvParent1.setIndicateurTauxDerogeable(false);
        contributionInvParent1.setCommonFields(commonFieldsParent1);

        StructureInvCommonFields commonFields6 = new StructureInvCommonFields();
        commonFields6.setId("SF_72225");
        commonFields6.setParentId("SF_72148");
        commonFields6.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFields6.setCodeNatureSupportInvSilo("FG");
        commonFields6.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFields6.setLibeNatureSupport("Fonds Euro");

        SupportFinancierDto supportFinancierDto6 = new SupportFinancierDto();
        supportFinancierDto6.setCommonFields(commonFields6);
        supportFinancierDto6.setSupportType(SupportType.PROFIL);
        supportFinancierDto6.setNom("Actif en euros");
        supportFinancierDto6.setCode("212");
        supportFinancierDto6.setTaux(new BigDecimal("0"));
        supportFinancierDto6.setTauxModifiable(false);
        supportFinancierDto6.setContributionInvParent(contributionInvParent1);

        StructureInvCommonFields commonFields7 = new StructureInvCommonFields();
        commonFields7.setId("SF_72000");
        commonFields7.setParentId("SF_72225");
        commonFields7.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFields7.setCodeNatureSupportInvSilo("FG");
        commonFields7.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFields7.setLibeNatureSupport("Fonds Euro");

        SupportFinancierDto supportFinancierDto7 = new SupportFinancierDto();
        supportFinancierDto7.setCommonFields(commonFields7);
        supportFinancierDto7.setSupportType(SupportType.PROFIL);
        supportFinancierDto7.setNom("Actif en euros");
        supportFinancierDto7.setCode("212");
        supportFinancierDto7.setTaux(new BigDecimal("0"));
        supportFinancierDto7.setTauxModifiable(false);
        supportFinancierDto7.setContributionInvParent(contributionInvParent1);

        StructureInvCommonFields commonFields8 = new StructureInvCommonFields();
        commonFields8.setId("SF_10831211");
        commonFields8.setParentId("SF_72225");
        commonFields8.setLibeNatureSupportInvSilo("Mixte");
        commonFields8.setCodeNatureSupportInvSilo("MI");
        commonFields8.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields8.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto8 = new SupportFinancierDto();
        supportFinancierDto8.setCommonFields(commonFields8);
        supportFinancierDto8.setSupportType(SupportType.GRILLE);
        supportFinancierDto8.setNom("Gestion pilot\u00E9e par horizon Prudente");
        supportFinancierDto8.setCode("5410");
        supportFinancierDto8.setTaux(new BigDecimal("1"));
        supportFinancierDto8.setTauxModifiable(false);
        supportFinancierDto8.setContributionInvParent(contributionInvParent1);

        StructureInvCommonFields commonFields9 = new StructureInvCommonFields();
        commonFields9.setId("SF_10831235");
        commonFields9.setParentId("SF_72225");
        commonFields9.setLibeNatureSupportInvSilo("Mixte");
        commonFields9.setCodeNatureSupportInvSilo("MI");
        commonFields9.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields9.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto9 = new SupportFinancierDto();
        supportFinancierDto9.setCommonFields(commonFields9);
        supportFinancierDto9.setSupportType(SupportType.GRILLE);
        supportFinancierDto9.setNom("Gestion pilot\u00E9e par horizon Equilibre");
        supportFinancierDto9.setCode("5430");
        supportFinancierDto9.setTaux(new BigDecimal("0"));
        supportFinancierDto9.setTauxModifiable(false);
        supportFinancierDto9.setContributionInvParent(contributionInvParent1);

        StructureInvCommonFields commonFields10 = new StructureInvCommonFields();
        commonFields10.setId("SF_10831257");
        commonFields10.setParentId("SF_72225");
        commonFields10.setLibeNatureSupportInvSilo("Mixte");
        commonFields10.setCodeNatureSupportInvSilo("MI");
        commonFields10.setNatureSupport(NatureSupportInv.MIXTE);
        commonFields10.setLibeNatureSupport("Mixte");

        SupportFinancierDto supportFinancierDto10 = new SupportFinancierDto();
        supportFinancierDto10.setCommonFields(commonFields10);
        supportFinancierDto10.setSupportType(SupportType.GRILLE);
        supportFinancierDto10.setNom("Gestion pilot\u00E9e par horizon Dynamique");
        supportFinancierDto10.setCode("5454");
        supportFinancierDto10.setTaux(new BigDecimal("0"));
        supportFinancierDto10.setTauxModifiable(false);
        supportFinancierDto10.setContributionInvParent(contributionInvParent1);

        List<SupportFinancierDto> supportFinancierNewRepartitionList = Arrays.asList(supportFinancierDto2,
                supportFinancierDto3, supportFinancierDto4, supportFinancierDto5, supportFinancierDto7,
                supportFinancierDto8, supportFinancierDto9, supportFinancierDto10);

        demandeCreationsigElecArbitrage.setNewRepartition(supportFinancierNewRepartitionList);

        StructureInvCommonFields commonFieldsParent11 = new StructureInvCommonFields();
        commonFieldsParent11.setId("SF_11673045");
        commonFieldsParent11.setParentId("SF_2567854");
        commonFieldsParent11.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFieldsParent11.setCodeNatureSupportInvSilo("FG");
        commonFieldsParent11.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFieldsParent11.setLibeNatureSupport("Fonds Euro");

        ContributionInv contributionInvParent11 = new ContributionInv();
        contributionInvParent11.setId("SF_11673045");
        contributionInvParent11.setCommonFields(commonFieldsParent11);

        StructureInvCommonFields commonFields11 = new StructureInvCommonFields();
        commonFields11.setId("5410");
        commonFields11.setParentId("SF_11673045");

        SupportFinancierDto supportFinancierDto11 = new SupportFinancierDto();
        supportFinancierDto11.setCommonFields(commonFields11);
        supportFinancierDto11.setSupportType(SupportType.GRILLE);
        supportFinancierDto11.setNom("Gestion pilot\u00E9e par horizon Prudente");
        supportFinancierDto11.setCode("5410");
        supportFinancierDto11.setTaux(BigDecimal.ZERO);
        supportFinancierDto11.setContributionInvParent(contributionInvParent11);

        StructureInvCommonFields commonFieldsParent12 = new StructureInvCommonFields();
        commonFieldsParent12.setId("SF_2581980");
        commonFieldsParent12.setParentId("SF_2567854");
        commonFieldsParent12.setLibeNatureSupportInvSilo("Fond en Devises");
        commonFieldsParent12.setCodeNatureSupportInvSilo("FG");
        commonFieldsParent12.setNatureSupport(NatureSupportInv.FONDS_DE_GESTION);
        commonFieldsParent12.setLibeNatureSupport("Fonds Euro");

        ContributionInv contributionInvParent12 = new ContributionInv();
        contributionInvParent12.setId("SF_2581980");
        contributionInvParent12.setCommonFields(commonFieldsParent12);

        StructureInvCommonFields commonFields12 = new StructureInvCommonFields();
        commonFields12.setId("237");
        commonFields12.setParentId("SF_2581980");

        SupportFinancierDto supportFinancierDto12 = new SupportFinancierDto();
        supportFinancierDto12.setCommonFields(commonFields12);
        supportFinancierDto12.setSupportType(SupportType.PROFIL);
        supportFinancierDto12.setNom("Fonds Club 3");
        supportFinancierDto12.setCode("237");
        supportFinancierDto12.setTaux(BigDecimal.ZERO);
        supportFinancierDto12.setContributionInvParent(contributionInvParent12);


       List<SupportFinancierDto> oldRepartitionList = new ArrayList<>();
       oldRepartitionList.add(supportFinancierDto11);
       oldRepartitionList.add(supportFinancierDto12);
       demandeCreationsigElecArbitrage.setOldRepartition(oldRepartitionList);
       demandeCreationsigElecArbitrage.setDesinvestissementRepartition(oldRepartitionList);

        return demandeCreationsigElecArbitrage;
    }

}
