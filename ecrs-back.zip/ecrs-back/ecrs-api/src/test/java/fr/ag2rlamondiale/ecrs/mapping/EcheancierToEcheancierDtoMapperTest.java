package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.dto.versementsynthese.EcheancierDto;
import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Collections;

@RunWith(MockitoJUnitRunner.class)
public class EcheancierToEcheancierDtoMapperTest {

    EcheancierToEcheancierDtoMapper mapper = new EcheancierToEcheancierDtoMapperImpl();

    @Test
    public void should_map_echeancier_to_echeancierDTO() {
        Echeancier echeancier = new Echeancier();
        Prelevement prelevement = new Prelevement();
        prelevement.setDatePrelevement(DateUtils.createDate(3, 4, 2025));
        echeancier.setPrelevements(Collections.singletonList(prelevement));

        EcheancierDto echeancierDto = mapper.echeancierToDto(echeancier);

        Assert.assertNotNull(echeancierDto);
    }

    @Test
    public void should_not_map_echeancier_to_echeancierDTO() {
        EcheancierDto echeancierDto = mapper.echeancierToDto(null);

        Assert.assertNull(echeancierDto);
    }
}
