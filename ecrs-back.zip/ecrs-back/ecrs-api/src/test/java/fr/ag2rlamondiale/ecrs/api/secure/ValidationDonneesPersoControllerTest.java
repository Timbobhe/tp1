package fr.ag2rlamondiale.ecrs.api.secure;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IDonneesPersoFacade;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursType;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.DonneesPersoParcoursValidation;
import fr.ag2rlamondiale.ecrs.dto.donneeperso.ModificationsIdentiteInfo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


@RunWith(MockitoJUnitRunner.class)
public class ValidationDonneesPersoControllerTest {
    @Spy
    @InjectMocks
    ValidationDonneesPersoController validationDonneesPersoRest;
    @Mock
    IDonneesPersoFacade donneesPersoFacade;

    @Test
    public void getDonnesPersoTest() throws TechnicalException {
        validationDonneesPersoRest.info();
        verify(validationDonneesPersoRest, times(1)).info();
    }

    @Test
    public void validerModifDonnesPersoTest() throws TechnicalException {
        validationDonneesPersoRest.validationModifDonnesPerso(createdonneesPerso());
        verify(validationDonneesPersoRest, times(1)).validationModifDonnesPerso(createdonneesPerso());
    }

    private DonneesPersoParcoursValidation createdonneesPerso() {
        ModificationsIdentiteInfo modificationsIdentiteInfo = ModificationsIdentiteInfo.builder()
                .civilite("Madame").codeCivilite("Mme")
                .nom("GIFAL").prenom("CARINE")
                .dateDeNaissance("18/08/1980")
                .lieuNaissance("ST DENIS").build();
        DonneesPersoParcoursValidation donneesPerso = DonneesPersoParcoursValidation.builder()
                .modificationsIdentiteInfo(modificationsIdentiteInfo)
                .donneesPersoParcoursType(DonneesPersoParcoursType.CONFIRMATION)
                .pieceJointes(null).build();
        return donneesPerso;

    }
}
