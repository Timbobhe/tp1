package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContactReclamationFacade;
import fr.ag2rlamondiale.trm.business.IUploadFileFacade;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ContactReclamationDto;
import fr.ag2rlamondiale.ecrs.dto.reclamation.ReclamationResponseDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ContactReclamationRestControllerTest {
    @Mock
    IContactReclamationFacade contactFacade;

    @Mock
    IUploadFileFacade uploadFileFacade;

    @InjectMocks
    ContactReclamationRestController contactController;

    @Test
    public void createReclamationTest() throws TechnicalException {
        when(contactFacade.createDemande(any())).thenReturn(new ReclamationResponseDto());
        ResponseEntity<ReclamationResponseDto> expected = contactController.createReclamation(new ContactReclamationDto());
        Assert.assertNotNull(expected);
    }

    @Test
    public void should_retrieve_contracts_to_start() throws TechnicalException {
        when(contactFacade.start()).thenReturn(new ArrayList<>());
        List<ContratParcoursDto> actual = contactController.start();
        Assert.assertNotNull(actual);
    }
}
