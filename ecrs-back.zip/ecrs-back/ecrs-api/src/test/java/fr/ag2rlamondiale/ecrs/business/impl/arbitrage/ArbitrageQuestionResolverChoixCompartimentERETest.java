package fr.ag2rlamondiale.ecrs.business.impl.arbitrage;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.IStructureInvFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ArbitrageContexteDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ChoixCompartimentDto;
import fr.ag2rlamondiale.ecrs.dto.arbitrage.ParamFluxStock;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.domain.structinv.*;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class ArbitrageQuestionResolverChoixCompartimentERETest {

    @InjectMocks
    ArbitrageQuestionResolverChoixCompartimentERE arbitrageQuestionResolverChoixCompartimentERE;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IStructureInvFacade structureInvFacade;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @InjectMocks
    ContratParcoursMapperImpl contratParcoursMapper;


    public ContratHeader prepare(boolean pacte, List<CompartimentType> compartimentTypes, boolean gestionFinanciereDifferentePossible, StrategieFinanciereImposee strategieFinanciereImposee, int montantEncours, boolean profile) throws TechnicalException {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(arbitrageQuestionResolverChoixCompartimentERE, "contratParcoursMapper", contratParcoursMapper);
        final ContratComplet contratComplet = createContratComplet(pacte, false, gestionFinanciereDifferentePossible, compartimentTypes);
        when(contratFacade.rechercherContratCompletParId(any(ContratId.class))).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(calculerEncoursContratFacade.getEncoursDto(any(ContratHeader.class))).thenReturn(buildCompteEncours(montantEncours));
        when(calculerEncoursContratFacade.getEncoursDto(any(Compartiment.class))).thenReturn(buildCompteEncours(montantEncours));
        when(structureInvFacade.consulterStructInv(any(ContratHeader.class))).thenAnswer(invocation -> buildStructInv(strategieFinanciereImposee, invocation.getArgument(0), profile));
        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        assertTrue(arbitrageQuestionResolverChoixCompartimentERE.accept(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT,
                ArbitrageContexteDto.builder().contratSelectionne(contratHeader.getContratId()).build()));
    }

    @Test
    public void test_plusieursCompartiments_gestionFinanciereDifferentePossible_strategieFinanciereLibre() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().isTousCompartiments()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getCompartiment() != null && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C1)));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getCompartiment() != null && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C3)));
    }

    @Test
    public void test_unSeulCompartiment_gestionFinanciereDifferentePossible_strategieFinanciereLibre() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getDefaultValue().getValue().getCompartiment() != null && resolved.getDefaultValue().getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C1));
    }

    @Test
    public void test_unSeulCompartiment_gestionFinanciereDifferentePossible_strategieFinanciereLibre_ParamStock() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1), true, new StrategieFinanciereImposee().setImposee(false), 0, false);
        final ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setParamFluxStock(ParamFluxStock.STOCK);
        contexte.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getData().isContratBloque());
    }

    @Test
    public void test_unSeulCompartimentC1_gestionFinanciereDifferentePossible_strategieFinanciereLibre_ParamFlux() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        final ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setParamFluxStock(ParamFluxStock.FLUX);
        contexte.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getData().isContratBloque());
    }

    @Test
    public void test_unSeulCompartimentC3_gestionFinanciereDifferentePossible_strategieFinanciereLibre_ParamFlux() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        final ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setParamFluxStock(ParamFluxStock.FLUX);
        contexte.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertFalse(resolved.getData().isContratBloque());
        assertEquals(CompartimentType.C3, resolved.getDefaultValue().getValue().getCompartiment().getCompartimentType());
    }

    @Test
    public void test_plusieursCompartimentC3_gestionFinanciereDifferentePossible_strategieFinanciereLibre_ParamFlux() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1, CompartimentType.C3, CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(false), 10, false);
        final ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setParamFluxStock(ParamFluxStock.FLUX);
        contexte.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 2);
        assertFalse(resolved.getData().isContratBloque());
        assertTrue(resolved.getPropositions().stream().allMatch(r -> CompartimentType.C3 == r.getValue().getCompartiment().getCompartimentType()));
    }

    @Test
    public void test_plusieursCompartiments_gestionFinanciereDifferentePossible_strategieFinanciereLibre_ParamStock() throws Exception {
        prepare(true, Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(false), 0, false);
        final ArbitrageContexteDto contexte = new ArbitrageContexteDto();
        contexte.setParamFluxStock(ParamFluxStock.STOCK);
        contexte.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, contexte);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getData().isContratBloque());
    }

    @Test
    public void test_plusieursCompartiments_gestionFinanciereDifferentePossible_strategieFinanciereImposee() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new StrategieFinanciereImposee().setImposee(true), 10, true);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertFalse(resolved.getData().isContratBloque());
    }

    @Test
    public void test_plusieursCompartiments_gestionFinanciereDifferentePossible_strategieFinanciereImposeeC3() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C3), true, new StrategieFinanciereImposee()
                .setImposee(ContributionType.PART_PATRONALE, true)
                .setImposee(ContributionType.PART_SALARIALE, true), 10, false);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertTrue(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 3);
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getCompartiment() != null && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C1) && !choix.isDisabled()));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getCompartiment() != null && choix.getValue().getCompartiment().getCompartimentType().equals(CompartimentType.C3) && !choix.isDisabled()));
    }

    @Test
    public void test_plusieursCompartiments_gestionFinanciereDifferenteImpossible_strategieFinanciereLibre() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1, CompartimentType.C3), false, new StrategieFinanciereImposee().setImposee(false), 10, false);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertTrue(resolved.getDefaultValue().getValue().isTousCompartiments());
    }

    @Test
    public void test_unSeulCompartiment_gestionFinanciereDifferenteImpossible_strategieFinanciereLibre() throws Exception {
        prepare(false, Arrays.asList(CompartimentType.C1), false, new StrategieFinanciereImposee().setImposee(false), 10, false);
        ArbitrageContexteDto ctx = new ArbitrageContexteDto();
        ctx.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        final QuestionResponsesDto<ChoixCompartimentDto, BlocageArbitrageContratDto> resolved = arbitrageQuestionResolverChoixCompartimentERE.resolve(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, ctx);

        assertEquals(QuestionType.ARBITRAGE_CHOIX_COMPARTIMENT, resolved.getQuestion().getId());
        assertFalse(resolved.isShow());
        assertEquals(resolved.getPropositions().size(), 0);
        assertFalse(resolved.getDefaultValue().getValue().isTousCompartiments());
        assertEquals(CompartimentType.C1, resolved.getDefaultValue().getValue().getCompartiment().getCompartimentType());
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, boolean allowDifferentInvestmentsForVif, List<CompartimentType> compartimentTypes) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);
        int counter = 0;
        for (CompartimentType compartimentType : compartimentTypes) {
            final Compartiment compartiment = Compartiment.builder().type(compartimentType).build();
            if (!isMdpro) {
                compartiment.setIdentifiantAssure(compartimentType.name() + "-" + (++counter));
            }
            contratHeader.addCompartiment(compartiment);
        }

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setAllowDifferentInvestmentsForVif(allowDifferentInvestmentsForVif);
        contratGeneral.setOptContratEpargne(optContratEpargne);

        return contratComplet;
    }

    private StructInv buildStructInv(StrategieFinanciereImposee strategieFinanciereImposee, ContratHeader contratHeader, boolean profile) {
        StructInv structInv = new StructInv();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            final List<ContributionType> contributionTypes = ContributionType.forCompartiment(compartiment.getType(), contratHeader.isPacte());
            final List<ContributionInv> contributionInvs = contributionTypes.stream().map(contributionType -> {
                ContributionInv contributionInv = new ContributionInv();
                contributionInv.setType(contributionType);
                contributionInv.setTauxRepartitionContribution(new BigDecimal(0));
                if (profile) {
                    contributionInv.setProfils(Collections.singletonList(newProfil(1, contributionType + "-profil")));
                    contributionInv.setGrilles(Collections.singletonList(newGrille(1, contributionType + "-grille")));
                }
                if (strategieFinanciereImposee.isImposee(contributionType)) {
                    contributionInv.setIndicateurTauxDerogeable(false);
                } else {
                    contributionInv.setIndicateurTauxDerogeable(true);
                    contributionInv.setTauxRepartitionDefaut(BigDecimal.ZERO);
                }
                return contributionInv;
            }).collect(Collectors.toList());
            structInv.addContributions(contributionInvs);
        }

        return structInv;
    }

    private EncoursDto buildCompteEncours(int montant) {
        BasicEncours compteEncours = new BasicEncours();
        compteEncours.setDate(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontant(BigDecimal.valueOf(montant));
        compteEncours.setEnErreur(false);
        return new EncoursDto(compteEncours);
    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Data
    public static class StrategieFinanciereImposee {
        private boolean imposee;
        private Map<ContributionType, Boolean> imposeeSelonContributionType = new HashMap<>();

        StrategieFinanciereImposee setImposee(boolean imposee) {
            this.imposee = imposee;
            return this;
        }

        StrategieFinanciereImposee setImposee(ContributionType contributionType, boolean imposee) {
            imposeeSelonContributionType.put(contributionType, imposee);
            return this;
        }

        public boolean isImposee(ContributionType contributionType) {
            if (this.imposee) {
                return true;
            }
            final Boolean i = this.imposeeSelonContributionType.get(contributionType);
            return i != null ? i : false;
        }
    }

    private GrilleInv newGrille(double d, String id) {
        GrilleInv grille = new GrilleInv();
        grille.setTauxRepartitionDefaut(new BigDecimal(d));
        grille.setIndicateurTauxDerogeable(false);
        grille.setTauxRepartition(new BigDecimal(d));
        grille.setId(id);
        return grille;
    }

    private ProfilInv newProfil(double d, String id) {
        ProfilInv profil = new ProfilInv();
        profil.setId(id);
        profil.setTauxRepartitionDefaut(new BigDecimal(d));
        //profil.setTauxRepartition(new BigDecimal(d));
        profil.setIndicateurTauxDerogeable(false);
        return profil;
    }
}
