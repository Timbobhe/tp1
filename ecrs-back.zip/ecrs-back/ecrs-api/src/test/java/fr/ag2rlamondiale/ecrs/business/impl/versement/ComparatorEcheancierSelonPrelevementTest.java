package fr.ag2rlamondiale.ecrs.business.impl.versement;

import fr.ag2rlamondiale.trm.domain.echeancier.Echeancier;
import fr.ag2rlamondiale.trm.domain.echeancier.Prelevement;
import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.utils.DateUtils.todayMoreDays;
import static org.junit.Assert.*;

public class ComparatorEcheancierSelonPrelevementTest {

    private int counter = 0;

    @Before
    public void setUp() throws Exception {
        counter = 0;
    }

    @Test
    public void test_sortPrelevements() throws Exception {
        Echeancier e1 = buildEcheancier(todayMoreDays(10), todayMoreDays(5), todayMoreDays(4));
        final Prelevement prelevement = new ComparatorEcheancierSelonPrelevement().prochainPrelevementApresDateJour(e1);
        assertEquals(3, prelevement.getPrelevementId().intValue());
    }

    @Test
    public void test_sort() throws Exception {
        Echeancier e1 = buildEcheancier(todayMoreDays(10), todayMoreDays(5), todayMoreDays(4));
        Echeancier e2 = buildEcheancier(todayMoreDays(15), todayMoreDays(7), todayMoreDays(3));
        final int compare = new ComparatorEcheancierSelonPrelevement().compare(e1, e2);
        assertTrue(compare > 0);
    }

    private Echeancier buildEcheancier(Date... datesPrelevements) {
        Echeancier e = new Echeancier();
        e.setPrelevements(Arrays.stream(datesPrelevements).map(this::prelevement).collect(Collectors.toList()));
        return e;
    }

    private Prelevement prelevement(Date date) {
        Prelevement p = new Prelevement();
        p.setPrelevementId(BigInteger.valueOf(++counter));
        p.setDatePrelevement(date);
        return p;
    }


}
