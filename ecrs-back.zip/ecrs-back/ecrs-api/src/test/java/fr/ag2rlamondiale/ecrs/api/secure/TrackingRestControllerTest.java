package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.TrackingFacadeImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class TrackingRestControllerTest {

    @InjectMocks
    private TrackingRestController trackingRestController;

    @Mock
    private TrackingFacadeImpl trackingFacade;

    @Test
    public void getTrackingInfo() throws TechnicalException {
        trackingRestController.getTrackingInfo();
        verify(trackingFacade).getTrackingInfo();
    }
}
