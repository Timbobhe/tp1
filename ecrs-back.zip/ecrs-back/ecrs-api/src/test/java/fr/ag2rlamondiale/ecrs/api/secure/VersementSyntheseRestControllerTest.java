package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.business.IVersementSyntheseFacade;
import fr.ag2rlamondiale.ecrs.dto.DetailsOperationDto;
import fr.ag2rlamondiale.ecrs.dto.OperationDetailInfoDto;
import fr.ag2rlamondiale.ecrs.dto.versementsynthese.VersementProgrammeDetailsRequestDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class VersementSyntheseRestControllerTest {
    @Mock
    IOperationFacade operationFacade;

    @Mock
    IVersementSyntheseFacade versementSyntheseFacade;

    @InjectMocks
    @Spy
    VersementSyntheseRestController versementSyntheseRest;

    @Test
    public void getVersementSyntheseTest() throws TechnicalException {
        versementSyntheseRest.getVersementSynthese();
        verify(versementSyntheseRest, times(1)).getVersementSynthese();
    }

    @Test
    public void getVersementProgrammeDetailsTest() throws TechnicalException {
        versementSyntheseRest.getVersementProgrammeDetails(new VersementProgrammeDetailsRequestDto());
        verify(versementSyntheseRest, times(1))
                .getVersementProgrammeDetails(any(VersementProgrammeDetailsRequestDto.class));
    }

    @Test
    public void getVersementProgrammeTest() throws TechnicalException {
        versementSyntheseRest.getVersementsProgrammes();
        verify(versementSyntheseRest, times(1)).getVersementsProgrammes();
    }

    @Test
    public void getHistoriqueVersementTest() throws TechnicalException {
        versementSyntheseRest.getHistoriqueVersements();
        verify(versementSyntheseRest, times(1)).getHistoriqueVersements();
    }

    @Test
    public void getSyntheseVersementDonutTest() throws TechnicalException {
        versementSyntheseRest.getSyntheseVersementDonut();
        verify(versementSyntheseRest, times(1)).getSyntheseVersementDonut();
    }

    @Test
    public void getDetailsOperationVersementTest() throws TechnicalException {
        when(operationFacade.getOperationsDetailsForVersementSynthese("144910652", "ERE")).thenReturn(getDetailsOperation());
        DetailsOperationDto expected = versementSyntheseRest.getDetailsOperationVersement("144910652", "ERE");
        assertNotNull(expected);

    }

    @Test
    public void rechercherDocumentsVersementTest() throws TechnicalException {
        versementSyntheseRest.rechercherDocumentsVersement();
        verify(versementSyntheseRest, times(1)).rechercherDocumentsVersement();
    }

    @Test
    public void getContrats() throws TechnicalException {
        versementSyntheseRest.getContrats();
        verify(versementSyntheseRest, times(1)).getContrats();
    }

    private DetailsOperationDto getDetailsOperation() {
        OperationDetailInfoDto operationDetailInfoDto = new OperationDetailInfoDto();
        operationDetailInfoDto.setOperationId("A_144910652");
        operationDetailInfoDto.setMontant(new BigDecimal("34.6"));
        operationDetailInfoDto.setLabel("Réalignement");
        operationDetailInfoDto.setNbreParts(BigDecimal.valueOf(2));
        operationDetailInfoDto.setValeurLiquidative(BigDecimal.valueOf(12.6));
        operationDetailInfoDto.setIdentifiantStrucInv("Struct_144910652");
        List<OperationDetailInfoDto> operationDetailInfoDtoList = new ArrayList<>();
        operationDetailInfoDtoList.add(operationDetailInfoDto);
        DetailsOperationDto detailsOperationDto = DetailsOperationDto.builder()
                .montantNetOperation(98.8)
                .typeOperation("A_R")
                .operationInvestissements(operationDetailInfoDtoList)
                .build();
        return detailsOperationDto;

    }
}
