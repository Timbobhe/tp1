package fr.ag2rlamondiale.ecrs.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ISujetFacade;
import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SujetRestControllerTest {
    @Mock
    ISujetFacade sujetFacade;

    @InjectMocks
    SujetRestController sujetRestController;

    @Test
    public void should_get_sujets() {
        when(sujetFacade.getSujets()).thenReturn(new ArrayList<>());
        List<SujetDto> expected = sujetRestController.getSujets();
        Assert.assertNotNull(expected);
    }

    @Test
    public void should_get_sujets_selectionnes_par_utilisateur() throws TechnicalException {
        when(sujetFacade.getSujetsSelectionnesParUtilisateur()).thenReturn(new HashSet<>());
        Collection<LectureSujetDto> expected = sujetRestController.getSujetsSelectionnesParUtilisateur();
        Assert.assertNotNull(expected);
    }

    @Test
    public void should_get_objectifs_par_utilisateur() throws TechnicalException {
        when(sujetFacade.getObjectifsParUtilisateur()).thenReturn(new HashSet<>());
        Collection<LectureSujetDto> expected = sujetRestController.getObjectifsParUtilisateur();
        Assert.assertNotNull(expected);
    }

    @Test
    public void should_create_sujets_selectionnes() throws TechnicalException {
        when(sujetFacade.createSujetParUtilisateur(Collections.emptyList())).thenReturn(new HashSet<>());
        Collection expected = sujetRestController.createSujetParUtilisateur(Collections.emptyList());
        assertNotNull(expected);
    }

    @Test
    public void should_update_sujet_lu() {
        when(sujetFacade.updateSujetLuParUtilisateur(1)).thenReturn(new LectureSujetDto());
        LectureSujetDto expected = sujetRestController.updateSujetLuParUtilisateur(1);
        assertNotNull(expected);
    }
}
