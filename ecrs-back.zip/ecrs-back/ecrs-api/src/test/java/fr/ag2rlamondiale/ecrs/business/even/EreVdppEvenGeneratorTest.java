package fr.ag2rlamondiale.ecrs.business.even;

import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.OperationPerimetre;
import fr.ag2rlamondiale.trm.domain.evenement.PerimetreEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.trm.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.trm.domain.workflow.lecture.RechDemFront;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.business.even.EvenUtils.evenementDeclencheDepuis;
import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static fr.ag2rlamondiale.trm.utils.Sets.set;
import static java.time.temporal.ChronoUnit.DAYS;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class EreVdppEvenGeneratorTest {
    private static final String IDGDI = "vnmopv";
    private static final String NUM_PERSONNE = "P4232980";
    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Mock
    private UserContextHolder userContextHolder;

    @InjectMocks
    EreVdppEvenGenerator ereVdppEvenGenerator;

    @Mock
    private IWorkflowFacade workflowClient;

    @Before
    public void setUp() throws WorkflowException {
        MockitoAnnotations.initMocks(this);

        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA));
        when(workflowClient.consulterDerniereDemandeEnCours(
                Matchers.any(RechDemFront.class),
                Matchers.any(DemandeWorkflowType.class))).thenReturn(null);
    }

    @Test
    public void ereVdppDeclenchementDepuisTest_true() {
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(3, DAYS).truncatedTo(DAYS))).build());
        assertTrue(evenementDeclencheDepuis(evens, 2));
    }

    @Test
    public void ereVdppDeclenchementDepuisTest_false() {
        List<EvenementJson> evens = new ArrayList<>();
        evens.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evens.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(2, DAYS).truncatedTo(DAYS))).build());
        assertFalse(evenementDeclencheDepuis(evens, 2));
    }

    @Test
    public void ereVdppEvaluerEvenementTrue_neDepassePasNombreMaxDeclenchements_avec_delaiReactivation() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        List<EvenementJson> evenementsDejaEnregistres = new ArrayList<>();
        Collection<ContratHeader> contrats = new ArrayList<>();
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(4, DAYS).truncatedTo(DAYS))).build());

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);

        assertFalse(results.isEmpty());
    }

    @Test
    public void ereVdppEvaluerEvenementTrue_neDepassePasNombreMaxDeclenchements_avec_delaiReactivation_evens_vide() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        List<EvenementJson> evenementsDejaEnregistres = new ArrayList<>();
        Collection<ContratHeader> contrats = new ArrayList<>();

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);
        assertFalse(results.isEmpty());
    }

    @Test
    public void ereVdppEvaluerEvenementTrue_neDepassePasNombreMaxDeclenchements_avec_delaiReactivation_sans_evens() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3); // 3 jours
        List<EvenementJson> evenementsDejaEnregistres = null;
        Collection<ContratHeader> contrats = new ArrayList<>();

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);
        assertFalse(results.isEmpty());
    }

    @Test
    public void ereVdppEvaluerEvenementTrue_neDepassePasNombreMaxDeclenchements_sans_delaiReactivation() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(null);
        List<EvenementJson> evenementsDejaEnregistres = new ArrayList<>();
        Collection<ContratHeader> contrats = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(i, DAYS).truncatedTo(DAYS))).build());
        }

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);
        assertFalse(results.isEmpty());

    }

    @Test
    public void ereVdppEvaluerEvenementTrue_neRespectePasDelaiReactivation() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3);
        List<EvenementJson> evenementsDejaEnregistres = new ArrayList<>();
        List<ContratHeader> contrats = new ArrayList<>();
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(date("01/06/2019")).build());
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(date("05/06/2019")).build());
        evenementsDejaEnregistres.add(EvenementJson.builder().dateDebut(Date.from(Instant.now().minus(3, DAYS).truncatedTo(DAYS))).build());

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);
        assertFalse(results.isEmpty());
    }

    @Test
    public void ereVdppEvaluerEvenementTrue_isPersonneAutoriseeFalse() {
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setDelaiAvantReactivation(3);
        List<EvenementJson> evenementsDejaEnregistres = new ArrayList<>();
        List<ContratHeader> contrats = new ArrayList<>();

        List<PerimetreEvenementJson> perimetres = new ArrayList<>();
        perimetres.add(perimetreEven(OperationPerimetre.INC, "ERE_CONF", PerimetreType.CONTRAT, "RG6556262"));
        perimetres.add(perimetreEven(OperationPerimetre.EXC, "ERE_CONF", PerimetreType.PERSONNE, "P4232980"));
        typeEven.setPerimetreEvenements(perimetres);

        TriggeringResults results = new TriggeringResults();
        ereVdppEvenGenerator.testDeclenchement(IDGDI, NUM_PERSONNE, typeEven, contrats, evenementsDejaEnregistres, results);
        assertTrue(results.isEmpty());
    }

    private UserContext createUserContext(String numPP) {
        ErePND1PND2ConfEvenGeneratorTest.MockUserContext userContext = new ErePND1PND2ConfEvenGeneratorTest.MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setNumeroPersonneMdpro(numPP);
        userContext.setSilos(set(CodeSiloType.ERE));
        return userContext;
    }

    private Date date(String date) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(date);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private PerimetreEvenementJson perimetreEven(OperationPerimetre operationPerimetre, String codeEvenement,
                                                 PerimetreType typePerimetre, String valeurPerimetre) {
        PerimetreEvenementJson p = new PerimetreEvenementJson();
        p.setOperationPerimetre(operationPerimetre);
        p.setCodeEvenement(codeEvenement);
        p.setTypePerimetre(typePerimetre);
        p.setValeurPerimetre(valeurPerimetre);
        return p;
    }
}
