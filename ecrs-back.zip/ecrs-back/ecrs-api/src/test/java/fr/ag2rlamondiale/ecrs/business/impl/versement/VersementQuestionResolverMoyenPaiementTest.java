package fr.ag2rlamondiale.ecrs.business.impl.versement;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.QuestionResponsesDto;
import fr.ag2rlamondiale.ecrs.dto.QuestionType;
import fr.ag2rlamondiale.ecrs.dto.structinv.RepartitionSupportDto;
import fr.ag2rlamondiale.ecrs.dto.versement.MoyenPaiementDto;
import fr.ag2rlamondiale.ecrs.dto.versement.VersementContexteDto;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.paiement.ConditionsPaiementDto;
import fr.ag2rlamondiale.trm.domain.paiement.Inclusion;
import fr.ag2rlamondiale.trm.domain.paiement.ModePaiement;
import fr.ag2rlamondiale.trm.domain.paiement.ParametresProfils;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionInv;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.GrilleInv;
import fr.ag2rlamondiale.trm.domain.structinv.StructInv;
import fr.ag2rlamondiale.trm.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.trm.paiementdigital.dto.ParametrageLabDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static fr.ag2rlamondiale.ecrs.dto.QuestionType.ResponseVersementMoyenPaiementType.*;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class VersementQuestionResolverMoyenPaiementTest {
    @InjectMocks
    VersementQuestionResolverMoyenPaiement versementQuestionResolverMoyenPaiement;

    @Mock
    IContratFacade contratFacade;

    @Mock
    IGestionMandatFacade gestionMandatFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Mock
    private IBlocageFacade blocageFacade;

    @Before
    public void init() throws TechnicalException {
        when(userContextHolder.get()).thenReturn(createUserContext());
        when(blocageFacade.getInfosBlocagesClient()).thenAnswer(invocation -> {
            InfosBlocagesClient info = new InfosBlocagesClient();
            info.setPersonneTotalementBloquee(false);
            return info;
        });
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre("123456");
        userContext.setSilos(Sets.set(CodeSiloType.ERE));
        return userContext;
    }

    public ContratHeader prepare(boolean pacte, VersementContexteDto contexteDto, String pays, boolean paiementLabAutorise, boolean domiciliationAutorisee) throws TechnicalException {
        final ContratComplet contratComplet = createContratComplet(pacte, false, contexteDto);
        when(contratFacade.rechercherContratCompletParId(any())).thenReturn(contratComplet);
        when(contratFacade.rechercherContratParId(any(ContratId.class))).thenReturn(contratComplet.getContratHeader());
        when(gestionMandatFacade.consulterCoordonneesBancairesContrat(contratComplet.getContratHeader())).thenReturn(getCoordonneesBancaires());

        ConditionsPaiementDto conditionsPaiementOut = new ConditionsPaiementDto();
        ParametresProfils parametresProfils = new ParametresProfils();
        parametresProfils.setModePaiements(Collections.singletonList(new ModePaiement()));
        parametresProfils.setMontantMaximumDisponible(new BigDecimal(1000));
        parametresProfils.setNombrePaiementDisponible(2);
        Inclusion inclusionPays = new Inclusion();
        inclusionPays.setLibellePays("FRANCE");
        inclusionPays.setPaysISO("FRA");
        conditionsPaiementOut.setParametresProfils(parametresProfils);
        conditionsPaiementOut.setInclusions(Collections.singletonList(inclusionPays));

        PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
        physiqueConsult.setId("P00000");
        physiqueConsult.setDonneesPersonnellesConfirmees(true);
        physiqueConsult.setEmailPro("emailpro@email.domain");
        physiqueConsult.setTelPortable("06XXXXXXXX");
        physiqueConsult.setPays(pays);
        physiqueConsult.setPaysResidenceFiscale(pays);
        when(consulterPersPhysFacade.consulterPersPhys(any(IdSiloDto.class))).thenReturn(physiqueConsult);
        when(paiementFacade.isPaiementDigitalEnabled(any(), any())).thenReturn(ParametrageLabDto.builder()
                .autorise(paiementLabAutorise)
                .domiciliationAutorisee(domiciliationAutorisee)
                .plafondDepasse(false)
                .build());

        return contratComplet.getContratHeader();
    }

    @Test
    public void test_accept() throws Exception {
        final ContratHeader contratHeader = prepare(false, new VersementContexteDto(), null, true, true);
        assertTrue(versementQuestionResolverMoyenPaiement.accept(QuestionType.VERSEMENT_CHOIX_PAIEMENT,
                VersementContexteDto.builder().contratSelectionne(contratHeader.getContratId()).build()));
    }

    @Test
    public void test_signatureManuscrite() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(true);
        versementContexteDto.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        prepare(false, versementContexteDto, null, true, true);
        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == CHEQUE_BANCAIRE));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == PRELEVEMENT_AUTOMATIQUE));
    }

    @Test
    public void test_signatureElectronique() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(false);
        versementContexteDto.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        prepare(false, versementContexteDto, null, true, true);
        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
    }

    @Test
    public void test_personneIsNotSousSurveillanceLAB_and_parametrageLABAutorise() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(false);
        versementContexteDto.setContratSelectionne(ContratId.builder().nomContrat("RG").codeSilo(CodeSiloType.ERE).build());
        versementContexteDto.setMontantVersement(new BigDecimal(200));

        prepare(false, versementContexteDto, "FRANCE", true, true);

        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == PRELEVEMENT_AUTOMATIQUE));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == CARTE_BANCAIRE));
    }

    @Test
    public void test_strategieFinanciereParDefaut() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(false);
        versementContexteDto.setContratSelectionne(ContratId.builder().nomContrat("RG").codeSilo(CodeSiloType.ERE).build());
        versementContexteDto.setMontantVersement(new BigDecimal(200));
        RepartitionSupportDto repartitionSupportDto = new RepartitionSupportDto();
        repartitionSupportDto.setId("id");
        repartitionSupportDto.setPourcentage(new BigDecimal(100.0));

        versementContexteDto.setRepartitions(Collections.singletonList(repartitionSupportDto));
        prepare(false, versementContexteDto, "FRANCE", true, true);

        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getJahiaDicoEntry().equalsIgnoreCase(CARTE_BANCAIRE.toString())));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.isDisabled() && choix.getJahiaDicoEntry().equalsIgnoreCase(CARTE_BANCAIRE.toString())));
    }

    @Test
    public void test_personneSousSurveillanceLAB_and_parametrageLABAutorise() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(true);
        versementContexteDto.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        versementContexteDto.setMontantVersement(new BigDecimal(200));
        prepare(false, versementContexteDto, "FRANCE", true, true);
        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == CHEQUE_BANCAIRE));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == PRELEVEMENT_AUTOMATIQUE));
    }

    @Test
    public void test_personnePasSousSurveillanceLAB_and_parametrageLABAutorise_and_domicilePasEnFrance() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(false);
        versementContexteDto.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        versementContexteDto.setMontantVersement(new BigDecimal(200));
        prepare(false, versementContexteDto, "ITALIE", true, false);
        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == PRELEVEMENT_AUTOMATIQUE));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.isDisabled() && choix.getJahiaDicoEntry().equalsIgnoreCase(CARTE_BANCAIRE.toString())));
    }

    @Test
    public void test_personnePasSousSurveillanceLAB_and_parametrageLABAutorise_and_plafondDepasse() throws Exception {
        VersementContexteDto versementContexteDto = new VersementContexteDto();
        versementContexteDto.setParcoursManuscrit(false);
        versementContexteDto.setContratSelectionne(ContratId.builder().codeSilo(CodeSiloType.ERE).build());
        versementContexteDto.setMontantVersement(new BigDecimal(2000));
        prepare(false, versementContexteDto, "FRANCE", true, true);
        when(paiementFacade.isPaiementDigitalEnabled(any(), any())).thenReturn(ParametrageLabDto.builder().autorise(true).build());
        final QuestionResponsesDto<MoyenPaiementDto, ?> resolved = versementQuestionResolverMoyenPaiement.resolve(QuestionType.VERSEMENT_CHOIX_PAIEMENT, versementContexteDto);

        assertEquals(QuestionType.VERSEMENT_CHOIX_PAIEMENT, resolved.getQuestion().getId());
        assertEquals(resolved.getPropositions().size(), 2);
        assertTrue(resolved.isShow());
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.getValue().getMoyenPaiementType() == PRELEVEMENT_AUTOMATIQUE));
        assertTrue(resolved.getPropositions().stream().anyMatch(choix -> choix.isDisabled() && choix.getJahiaDicoEntry().equalsIgnoreCase(CARTE_BANCAIRE.toString())));
    }

    private ContratComplet createContratComplet(boolean isPacte, boolean isMdpro, VersementContexteDto contexte) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(isMdpro ? CodeSiloType.MDP : CodeSiloType.ERE);
        contratHeader.setPacte(isPacte);

        final Compartiment compartiment = Compartiment.builder().identifiantAssure("id").contratHeader(contratHeader).type(CompartimentType.C1).build();
        contratHeader.addCompartiment(compartiment);

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("code assureur");

        Map<CompartimentId, CompteGeneralesERE> compteGeneralesEreParCompartiment = new ConcurrentHashMap<>();
        compteGeneralesEreParCompartiment.put(CompartimentId.builder().idAssure("id").compartimentType(CompartimentType.C1).build(), createCompteGenerale());
        contratComplet.setCompteGeneralesEreParCompartiment(compteGeneralesEreParCompartiment);

        contratComplet.setCompteGeneralesERE(createCompteGenerale());

        setCompartiment(contratHeader, CompartimentType.C1, contexte);

        return contratComplet;
    }

    private CompteGeneralesERE createCompteGenerale() {
        CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setIdAssure("1470947");
        compteGeneralesERE.setEtatAssure("Affili\u00E9 en cours sans BIA");
        compteGeneralesERE.setCodeEtat("A");
        compteGeneralesERE.setEtat("En cours");
        compteGeneralesERE.setNumeroMatricule("6005095");
        compteGeneralesERE.setIdPersonne("P4167507");
        compteGeneralesERE.setLibelleContributionInvestissementSilo("Versements Volontaires non d\u00E9ductibles");

        ContributionInv contributionInv = new ContributionInv();
        contributionInv.setType(ContributionType.VERSEMENTS_VOLONTAIRES_DEDUCTIBLES);
        GrilleInv grilleInv = new GrilleInv();
        grilleInv.setProfils(new ArrayList<>());
        grilleInv.setNom("G_E_SM_IBMPERO_EQUILIBRE");
        grilleInv.setId("14627");
        grilleInv.setIndicateurTauxDerogeable(false);
        contributionInv.setGrilles(Collections.singletonList(grilleInv));
        contributionInv.setProfils(new ArrayList<>());

        StructInv structInv = new StructInv();
        structInv.addContributions(Collections.singletonList(contributionInv));
        compteGeneralesERE.setStructInv(structInv);

        return compteGeneralesERE;
    }

    public void setCompartiment(ContratHeader contratHeader, CompartimentType compartimentType, VersementContexteDto contexte) {
        contratHeader.getCompartiments().stream()
                .filter(compartiment -> compartiment.getType().equals(compartimentType))
                .findFirst()
                .ifPresent(compartiment -> contexte.setCompartimentSelectionne(compartiment.getCompartimentId()));
    }

    private CoordonneesBancairesDto getCoordonneesBancaires() {
        CoordonneesBancairesDto dto = new CoordonneesBancairesDto();
        dto.setTitulaire("TITULAIRE");
        dto.setBic("BIC");
        dto.setIban("IBAN");
        return dto;
    }
}
