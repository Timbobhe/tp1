package fr.ag2rlamondiale.ecrs.business.impl;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBlocageFacade;
import fr.ag2rlamondiale.ecrs.business.IContratFacade;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.SimulateurFiscalCalculArt83;
import fr.ag2rlamondiale.ecrs.business.impl.simulateur.SimulateurFiscalCalculPerp;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.simulateur.SimulateurStartDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.ecrs.mapping.parametre.ParametreMapper;
import fr.ag2rlamondiale.ecrs.simulateur.dto.DemandeCalculEpargne;
import fr.ag2rlamondiale.ecrs.simulateur.dto.ResultatCalculEpargne;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratVifHelper;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_PASS;
import static fr.ag2rlamondiale.ecrs.domain.parametre.ParametreConstantes.TYPE_TMI;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class SimulateurFiscalFacadeImplTest {

    @InjectMocks
    SimulateurFiscalFacadeImpl simulateurFiscalFacade;


    @Mock
    private IContratFacade contratFacade;

    @Mock
    IBlocageFacade blocageFacade;

    @Mock
    RequestContextHolder requestContextHolder;

    @Mock
    ContratVifHelper contratVifHelper;

    @Mock
    ContratParcoursMapper contratParcoursMapper;

    @Mock
    private IParamConsoleFacade paramConsoleFacade;

    @Mock
    private ParametreMapper parametreMapper;

    @Mock
    private SimulateurFiscalCalculArt83 simulateurFiscalCalculArt83;

    @Mock
    private SimulateurFiscalCalculPerp simulateurFiscalCalculPerp;

    @Test
    public void should_start_simulateur_fiscal() throws TechnicalException {
        // Given
        ParametreDto paramTmi = ParametreDto.builder().codeParam("TMI").valeur1("11").build();
        when(contratFacade.rechercherContratsComplets()).thenReturn(Collections.singletonList(createContratComplet("ART83")));
        when(blocageFacade.getInfosBlocagesClient()).thenReturn(createInfoBlocageClient());
        when(requestContextHolder.getContrat()).thenReturn("id");
        // when(contratVifHelper.isVifPossible(any())).thenReturn(true);
        when(contratParcoursMapper.map(any(ContratHeader.class), Mockito.anyBoolean())).thenReturn(null);
        when(paramConsoleFacade.getParametres(TYPE_TMI, Annee.Precedente)).thenReturn(Arrays.asList(paramTmi));
        when(parametreMapper.map(Arrays.asList(paramTmi))).thenReturn(new ArrayList<>());
        SimulateurStartDto dto = simulateurFiscalFacade.startSimulateur();

        assertNotNull(dto);
    }

    @Test
    public void test_should_call_SimulateurFiscalCalculArt83_with_contrat_art83() throws Exception {
        // Given
        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.ERE)
                .build();
        ContratHeader contratHeader = createContratHeader("id", "281134", CodeSiloType.ERE);

        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();
        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("ART83"));// Given


        // When
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(11));
        demandeCalcul.setAbondement(BigDecimal.valueOf(4400));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(40000));
        demandeCalcul.setContrat(contratId);

        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalFacade.calculerDisponibleFiscal(demandeCalcul);

        // Then
        verify(simulateurFiscalCalculArt83).calculerDisponibleFiscal(eq(demandeCalcul));
    }


    @Test
    public void test_should_call_SimulateurFiscalCalculPerp_with_contrat_perp() throws Exception {
        // Given
        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.MDP)
                .build();
        ContratHeader contratHeader = createContratHeader("id", null, CodeSiloType.MDP);

        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();
        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("PERP"));// Given


        // When
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(11));
        demandeCalcul.setAbondement(BigDecimal.valueOf(4400));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(40000));
        demandeCalcul.setContrat(contratId);

        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalFacade.calculerDisponibleFiscal(demandeCalcul);

        // Then
        verify(simulateurFiscalCalculPerp).calculerDisponibleFiscal(eq(demandeCalcul));
    }

    @Test(expected = Exception.class)
    public void test_should_throw_exception_with_contrat_autre_fiscalite_exemple_PEP() throws Exception {
        // Given
        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.MDP)
                .build();
        ContratHeader contratHeader = createContratHeader("id", null, CodeSiloType.MDP);

        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();
        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("PEP"));// Given


        // When
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(11));
        demandeCalcul.setAbondement(BigDecimal.valueOf(4400));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(40000));
        demandeCalcul.setContrat(contratId);

        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalFacade.calculerDisponibleFiscal(demandeCalcul);

        // Then
        verify(simulateurFiscalCalculPerp).calculerDisponibleFiscal(eq(demandeCalcul));
    }

    @Test(expected = Exception.class)
    public void test_should_throw_exception_with_contrat_autre_fiscalite_exemple_MADELIN() throws Exception {
        // Given
        ContratId contratId = ContratId.builder()
                .nomContrat("id")
                .codeSilo(CodeSiloType.MDP)
                .build();
        ContratHeader contratHeader = createContratHeader("id", null, CodeSiloType.MDP);

        ParametreDto paramPass = ParametreDto.builder().codeParam("PASS").valeur1("41400").build();
        when(paramConsoleFacade.getParametre(TYPE_PASS, "PASS", Annee.Precedente)).thenReturn(Optional.of(paramPass));

        when(contratFacade.rechercherContratParId(contratId)).thenReturn(contratHeader);
        when(contratFacade.rechercherContratCompletParId(contratId)).thenReturn(createContratComplet("FISCMAD"));// Given


        // When
        DemandeCalculEpargne demandeCalcul = new DemandeCalculEpargne();
        demandeCalcul.setTmi(BigDecimal.valueOf(11));
        demandeCalcul.setAbondement(BigDecimal.valueOf(4400));
        demandeCalcul.setRevenuImposable(BigDecimal.valueOf(40000));
        demandeCalcul.setContrat(contratId);

        final ResultatCalculEpargne resultatCalculEpargne = simulateurFiscalFacade.calculerDisponibleFiscal(demandeCalcul);

        // Then
        verify(simulateurFiscalCalculPerp).calculerDisponibleFiscal(eq(demandeCalcul));
    }


    private ContratComplet createContratComplet(String codeCadreFiscal) {
        final ContratComplet contratComplet = new ContratComplet();

        final ContratHeader contratHeader = new ContratHeader();
        contratComplet.setContratHeader(contratHeader);

        Compartiment compartiment = new Compartiment();
        compartiment.setContratHeader(contratHeader);
        compartiment.setType(CompartimentType.C1);

        contratHeader.setId("id");
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setPacte(true);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        contratHeader.setCompartiments(Collections.singletonList(compartiment));

        CompteEncours compteEncours = buildCompteEncours(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto1 = new OccurStructInvDto();
        SupportInvDto supportInvDto = new SupportInvDto();
        supportInvDto.setIdSupportInv("13132");
        occurStructInvDto1.setSupportInv(supportInvDto);
        occurStructInvDto1.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        OccurStructInvDto occurStructInvDto2 = new OccurStructInvDto();
        occurStructInvDto2.setSupportInv(supportInvDto);
        occurStructInvDto2.setMontantOccurSupportInv(BigDecimal.valueOf(34));

        List<OccurStructInvDto> occurStructInvDtos = new ArrayList<>();
        occurStructInvDtos.add(occurStructInvDto1);
        occurStructInvDtos.add(occurStructInvDto2);
        compteEncours.setOccurStructInvList(occurStructInvDtos);

        contratComplet.setEncours(new Memoizer<>(() -> compteEncours));

        final ContratGeneral contratGeneral = new ContratGeneral();
        contratComplet.setContratGeneral(contratGeneral);
        contratGeneral.setCodeAssureur("P12324");
        contratGeneral.setCodeCadreFiscal(codeCadreFiscal);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();


        contratGeneral.setOptContratEpargne(optContratEpargne);

        Map<CompartimentId, Memoizer<Encours>> encoursParCompartiment = new ConcurrentHashMap<>();
        encoursParCompartiment.put(getCompartimentId(), new Memoizer<>(() -> buildCompteEncours(BigDecimal.valueOf(34))));
        contratComplet.setEncoursParCompartiment(encoursParCompartiment);

        return contratComplet;
    }

    private CompartimentId getCompartimentId() {
        CompartimentId compartimentId = new CompartimentId();
        compartimentId.setCompartimentType(CompartimentType.C1);
        compartimentId.setIdAssure("IDASSURE");
        compartimentId.setNomContrat("RG152289321");
        return compartimentId;
    }

    private CompteEncours buildCompteEncours(BigDecimal montant) {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
        compteEncours.setMontantEncours(montant);
        compteEncours.setEncoursEnErreur(false);
        return compteEncours;
    }

    private InfosBlocagesClient createInfoBlocageClient() {
        InfosBlocagesClient infosBlocagesClient = new InfosBlocagesClient();
        Map<String, Set<String>> blocage = new HashMap<>();
        Set<String> code = new HashSet<>();
        code.add("SimulateurFiscal");
        blocage.put("id", code);
        infosBlocagesClient.setFonctionnalitesBloqueesContrats(blocage);
        return infosBlocagesClient;
    }

    private ContratHeader createContratHeader(String id, String idAssure, CodeSiloType silo) {
        ContratHeader contrat = new ContratHeader();
        contrat.setId(id);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        if (CodeSiloType.ERE.equals(silo)) {
            contrat.setIdentifiantAssure(idAssure);
            Compartiment c1 = Compartiment.builder().identifiantAssure("281134").type(CompartimentType.C1).build();
            contrat.setCompartiments(Collections.singletonList(c1));
        } else if (CodeSiloType.MDP.equals(silo)) {
            Compartiment c1 = Compartiment.builder().type(CompartimentType.C1).build();
            contrat.setCompartiments(Collections.singletonList(c1));
        }
        return contrat;
    }

}
