package fr.ag2rlamondiale.ecrs.mapping;

import fr.ag2rlamondiale.ecrs.dto.sujet.LectureSujetDto;
import fr.ag2rlamondiale.ecrs.dto.sujet.SujetDto;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;

@RunWith(MockitoJUnitRunner.class)
public class SujetMapperTest {

    SujetMapper sujetMapper = new SujetMapper();

    @Test
    public void should_map_LectureSujetJson_To_Dto() {
        SujetJson sujetJson = SujetJson.builder()
                .build();
        LectureSujetJson lectureSujetJson = LectureSujetJson.builder()
                .sujet(sujetJson)
                .build();

        LectureSujetDto lectureSujetDto = sujetMapper.toLectureSujetDto(lectureSujetJson);

        Assert.assertNotNull(lectureSujetDto);
    }

    @Test
    public void should_map_sujetJson_to_Dto() {
        SujetJson sujetJson = SujetJson.builder()
                .sousSujets(new ArrayList<>())
                .build();

        SujetDto sujetDto = sujetMapper.toSujetDto(sujetJson);

        Assert.assertNotNull(sujetDto);
    }

    @Test
    public void should_map_sujetDto_to_lectureSujetDto() {
        SujetDto sujetDto = SujetDto.builder()
                .build();

        LectureSujetDto lectureSujetDto = sujetMapper.toLectureSujetDto(sujetDto, "idgdi");

        Assert.assertNotNull(lectureSujetDto);
    }
}
