# ECRS - BACK - CHANGES

## v7.2.0 - 15/09/2021

- Refonte Données personnelles
- Simplification sur la gestion des Even à la connexion : distinction POPIN, INDISPO, OBJECTIF

## release/2.0.x 

### 28/01/2020

- Monté de version vers METIS v5
    - MAJ version Spring, Spring-security    
    - Migration apache-commons-lang vers lang3    
    - Migration apache-commons-collection vers collection4    
    - Création fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException (supprimée du Framework)    
    - Modification classe mère fr.ag2rlamondiale.ecrs.api.error.RestExceptionHandler (Framework casse le type de retour)    
    - MAJ version plugin maven Jetty (corrige NPE) - DTR0073865

- Simplification du fichier [ecrs-api/src/main/resources/webservices-rest.properties](ecrs-api/src/main/resources/webservices-rest.properties) : le fichier ne contient plus que l'URL root de la Console.
Les URL de chaques API sont intégrées directement dans le code.     

- Externalisation du module `ecrs-pfs-generate` (voir [README.md](README.md))

- Monté de version de Mapstuct -> 1.3.1.Final (dernière version à date)

- Monté de version du plugin maven compiler -> 3.8.1 (dernière version à date) (_souhait d'un meilleur support compilation incrémentale_) (MCOMPILER-349) https://issues.apache.org/jira/secure/ReleaseNote.jspa?projectId=12317225&version=12343484

- Modification de la version du plugin maven jetty => Corriger la commande de lancement du Jetty local (voir [README.md](README.md)) 
