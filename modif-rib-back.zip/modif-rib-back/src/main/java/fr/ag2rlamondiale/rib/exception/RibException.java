package fr.ag2rlamondiale.rib.exception;

public class RibException extends RuntimeException {
    public RibException() {
        super();
    }

    public RibException(String message) {
        super(message);
    }

    public RibException(String message, Throwable cause) {
        super(message, cause);
    }

    public RibException(Throwable cause) {
        super(cause);
    }

    protected RibException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
