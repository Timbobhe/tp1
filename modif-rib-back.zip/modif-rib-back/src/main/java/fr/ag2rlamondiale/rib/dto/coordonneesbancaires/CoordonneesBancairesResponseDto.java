package fr.ag2rlamondiale.rib.dto.coordonneesbancaires;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CoordonneesBancairesResponseDto implements Serializable {
	private static final long serialVersionUID = -8695535421487668456L;
	private State state;
	private String errorTag;
	
	public enum State {
        OK, KO;
    }
}
