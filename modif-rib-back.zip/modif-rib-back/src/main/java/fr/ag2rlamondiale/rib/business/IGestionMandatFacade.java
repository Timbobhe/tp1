package fr.ag2rlamondiale.rib.business;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesStartDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.ModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.List;

public interface IGestionMandatFacade {
    CoordonneesBancairesStartDto startChangeCoordonneesBancaires() throws TechnicalException;

    CoordonneesBancairesDto consulterCoordonneesBancairesContrat(IContrat contrat);

    String terminateChangeCoordonneesBancaires(
            List<ModificationCoordonneesBancairesDto> modificationCoordonneesBancairesDtos,
            boolean isFrame) throws IOException, CommonException, JAXBException;
}
