package fr.ag2rlamondiale.rib.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.*;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.ecrs.domain.contrat.contratgenerale.Adherente;
import fr.ag2rlamondiale.ecrs.domain.document.DictionaryKeyType;
import fr.ag2rlamondiale.ecrs.domain.document.DocRefType;
import fr.ag2rlamondiale.ecrs.domain.document.DocumentMDProRefType;
import fr.ag2rlamondiale.ecrs.domain.document.DocumentRefType;
import fr.ag2rlamondiale.ecrs.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.ecrs.domain.sigelec.DocumentRIB;
import fr.ag2rlamondiale.ecrs.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.ecrs.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.ecrs.dto.sigelec.DocumentType;
import fr.ag2rlamondiale.ecrs.dto.sigelec.OperationType;
import fr.ag2rlamondiale.ecrs.dto.sigelec.json.DocumentJson;
import fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.ecrs.jahia.IJahiaFacade;
import fr.ag2rlamondiale.ecrs.mapping.ContratClientMapper;
import fr.ag2rlamondiale.ecrs.security.UserContext;
import fr.ag2rlamondiale.ecrs.security.UserContextHolder;
import fr.ag2rlamondiale.ecrs.utils.Lambda;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.business.ISupplierRibService;
import fr.ag2rlamondiale.rib.domain.sigelec.DemandeCreationSigElecModifRIB;
import fr.ag2rlamondiale.rib.domain.sigelec.FormulaireModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesStartDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.ModificationCoordonneesBancairesDto;
import lombok.Setter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.ecrs.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.rib.business.impl.RibConstants.AGREMENTS_CONVENTION_PREUVE;
import static fr.ag2rlamondiale.rib.business.impl.RibConstants.AGREMENTS_CONVENTION_PREUVE_TITLE_DOC;


@Service
public class GestionMandatFacadeImpl implements IGestionMandatFacade, ApplicationContextAware, InitializingBean {

    @Setter
    private ApplicationContext applicationContext;

    @Autowired
    private IBaseContratFacade contratFacade;

    @Autowired
    private ISupplierRibService supplierRibService;

    @Autowired
    private UserContextHolder userContextHolder;


    @Autowired
    private ISigElecFacade sigElecFacade;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private IJahiaFacade jahiaFacade;

    @Autowired
    private IDownloadDocumentFacade downloadDocumentFacade;

    @Autowired
    private IDataDocumentContratFacade dataDocumentContratFacade;

    @Autowired
    private ContratClientMapper contratClientMapper;

    @Autowired
    private IWorkflowFacade demandeWorkflowFacade;

    private Collection<ICoordonneesBancairesSupplier> coordonneesBancairesSuppliers;

    @Override
    public CoordonneesBancairesStartDto startChangeCoordonneesBancaires() throws TechnicalException {
        final CoordonneesBancairesStartDto res = new CoordonneesBancairesStartDto();

        final Collection<IContrat> principauxContrats = supplierRibService.recupererPrincipauxContrats();
        final List<CoordonneesBancairesDto> principaux = new ArrayList<>();
        for (IContrat contrat : principauxContrats) {
            findCoordonneesBancairesSupplier(contrat)
                    .map(s -> s.retrieveCoordonneesBancairesContrat(contrat))
                    .ifPresent(principaux::add);
        }
        res.setCoordonneesBancairesMetierPrincipal(principaux);

        final Collection<IContrat> contratsSecondaires = supplierRibService.recupererContratsSecondaires();
        final List<CoordonneesBancairesDto> secondaires = new ArrayList<>();
        for (IContrat contrat : contratsSecondaires) {
            final ContratParcoursDto contratParcours = contratClientMapper.map(contrat);
            CoordonneesBancairesDto cb = new CoordonneesBancairesDto();
            cb.setContrat(contratParcours);
            secondaires.add(cb);
        }

        res.setCoordonneesBancairesAutresMetiers(secondaires);

        return res;
    }

    private Optional<ICoordonneesBancairesSupplier> findCoordonneesBancairesSupplier(IContrat contrat) {
        return coordonneesBancairesSuppliers.stream()
                .filter(s -> s.accept(contrat))
                .findFirst();
    }


    @Override
    public CoordonneesBancairesDto consulterCoordonneesBancairesContrat(IContrat contrat) {
        final Optional<ICoordonneesBancairesSupplier> supplier = findCoordonneesBancairesSupplier(contrat);
        return supplier.filter(s -> s.isAffichable(contrat)).map(s -> s.retrieveCoordonneesBancairesContrat(contrat)).orElse(null);
    }


    @Override
    public String terminateChangeCoordonneesBancaires(
            List<ModificationCoordonneesBancairesDto> modificationCoordonneesBancaires,
            boolean isFrame) throws IOException, CommonException, JAXBException {
        List<IContrat> contratHeaders = new ArrayList<>();
        List<DataDocumentContrat> documentContrats = new ArrayList<>();
        List<FormulaireModificationCoordonneesBancairesDto> formulaireModificationCoordonneesBancairesDtos = new ArrayList<>();

        for (ModificationCoordonneesBancairesDto mcb : modificationCoordonneesBancaires) {
            final ContratId contratId = mcb.getContratId();
            final IContrat contrat = contratFacade.rechercherContratParId(contratId);
            final ICoordonneesBancairesSupplier coordonneesBancairesSupplier = findCoordonneesBancairesSupplier(contrat).orElseThrow(() -> new RuntimeException("Pas de ICoordonneesBancairesSupplier pour le " + contrat));
            final ICompartiment compartiment = coordonneesBancairesSupplier.getCompartimentRib(contrat);
            final CompartimentId compartimentId = compartiment != null ? compartiment.getCompartimentId() : null;

            final DocRefType docRefType = ERE.equals(contrat.getCodeSilo()) ? DocumentRefType.MODIFICATION_RIB : DocumentMDProRefType.MODIFICATION_RIB_MDPRO;
            final DataDocumentContrat documentContrat = dataDocumentContratFacade.buildDocumentContrat(contrat, compartimentId, null, docRefType, dataDocumentContrat -> {
                DocumentRIB documentRIB = new DocumentRIB();
                documentRIB.setBic(mcb.getCoordonneesBancairesModifiees().getCodeBIC());
                documentRIB.setIban(mcb.getCoordonneesBancairesModifiees().getCodeIBAN());
                documentRIB.setTitulaire(mcb.getCoordonneesBancairesModifiees().getTitulaireCompte());
                dataDocumentContrat.setRib(documentRIB);
            });

            contratHeaders.add(contrat);
            documentContrats.add(documentContrat);
            formulaireModificationCoordonneesBancairesDtos.add(mapperCoordonneesBancairesToFormulaire(mcb, contrat, compartimentId));
        }

        UserContext userContext = userContextHolder.get();
        DemandeCreationSigElecModifRIB demandeCreationSigElec = new DemandeCreationSigElecModifRIB();
        demandeCreationSigElec.addAll(documentContrats);
        demandeCreationSigElec.setContrats(contratHeaders);

        if (contratHeaders.stream().anyMatch(IContrat::isEre)) {
            demandeCreationSigElec.setCodeSilo(ERE);
        } else if (contratHeaders.stream().anyMatch(IContrat::isMdpro)) {
            demandeCreationSigElec.setCodeSilo(MDP);
        }

        demandeCreationSigElec.setAgrementsConventionDePreuve(
                jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, AGREMENTS_CONVENTION_PREUVE));
        demandeCreationSigElec.setConventionDePreuveTitre(
                jahiaFacade.findDictionaryEntry(DictionaryKeyType.COMMON_APP_MESSAGES, AGREMENTS_CONVENTION_PREUVE_TITLE_DOC));

        demandeCreationSigElec.setIdGdi(userContext.getIdGdi());
        demandeCreationSigElec.setPersonPhysique(consulterPersPhysFacade.consulterPersPhys(userContext.getIdSilo(demandeCreationSigElec.getCodeSilo())));
        demandeCreationSigElec.setTypeOperation(OperationType.RIBA);
        demandeCreationSigElec.setNumPP(ERE.equals(demandeCreationSigElec.getCodeSilo()) ? userContextHolder.get().getNumeroPersonneEre()
                : userContextHolder.get().getNumeroPersonneMdpro());
        demandeCreationSigElec.setFormulaireModificationCoordonneesBancairesDtos(formulaireModificationCoordonneesBancairesDtos);
        demandeCreationSigElec.setCodeAssureur(getCodeAssureur(contratHeaders));
        final List<DocumentJson> documents = getUploadedRibs(modificationCoordonneesBancaires);
        demandeCreationSigElec.setUploadedDocuments(documents);

        return sigElecFacade.envoyerDocumentPourSignatureElectronique(demandeCreationSigElec, isFrame);
    }

    private String getCodeAssureur(List<IContrat> contrats) {
        return contrats.stream()
                .map(c -> Lambda.handleException(() -> contratFacade.rechercherContratGeneral(c.getContratId())))
                .map(ContratGeneral::getCodeAssureur)
                .findFirst()
                .orElse(null);
    }

    @Nonnull
    private List<DocumentJson> getUploadedRibs(List<ModificationCoordonneesBancairesDto> modificationCoordonneesBancairesDtos) {
        final List<DocumentJson> documents = modificationCoordonneesBancairesDtos.stream()
                .filter(e -> e.getFichiersJoint() != null)
                .flatMap(e -> e.getFichiersJoint().stream())
                .filter(Objects::nonNull)
                .distinct()
                .map(e -> DocumentJson.builder().type(DocumentType.RIB).contenu(e.getFileContent()).build())
                .collect(Collectors.toList());
        return documents;
    }


    private FormulaireModificationCoordonneesBancairesDto mapperCoordonneesBancairesToFormulaire(
            ModificationCoordonneesBancairesDto dto, IContrat contrat, CompartimentId compartimentId) throws WorkflowException {
        final ContratGeneral contratGeneral;
        try {
            contratGeneral = contratFacade.rechercherContratGeneral(contrat.getContratId());
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }

        // get Adherente
        Optional<Adherente> adherente = contratGeneral.getAdherentes().stream()
                .filter(adh -> adh.getId().equals(contrat.getIdAdherente())).findFirst();
        String adherenteRS = adherente.isPresent() ? adherente.get().getRaisonSociale() : "";

        String idDemandeWkf = demandeWorkflowFacade.genererIdDemFront(CodeActionType.DEM_RIBA, contrat.getContratId().getCodeSilo());

        final String idAssure = compartimentId != null ? compartimentId.getIdAssure() : null;

        return FormulaireModificationCoordonneesBancairesDto.builder()
                .idGdi(userContextHolder.get().getIdGdi())
                .idPersonne(contrat.getPersonId())
                .idContrat(contrat.getContratId().getNomContrat())
                .silo(contrat.getContratId().getCodeSilo())
                .idAssure(idAssure)
                .nom(userContextHolder.get().getNom())
                .prenom(userContextHolder.get().getPrenom())
                .codeFiliale(contratGeneral.getCodeFiliale())
                .coordonneesBancairesActuelles(dto.getCoordonneesBancairesActuelles())
                .coordonneesBancairesModifiees(dto.getCoordonneesBancairesModifiees())
                .raisonSocialeContractante(contratGeneral.getContractante())
                .raisonSocialeAdherente(adherenteRS)
                .idDemandeWkf(idDemandeWkf)
                .referenceExterne(contratGeneral.getReferenceExterne()).build();
    }

    @Override
    public void afterPropertiesSet() {
        final Map<String, ICoordonneesBancairesSupplier> beans = this.applicationContext.getBeansOfType(ICoordonneesBancairesSupplier.class);
        this.coordonneesBancairesSuppliers = beans.values();
    }
}
