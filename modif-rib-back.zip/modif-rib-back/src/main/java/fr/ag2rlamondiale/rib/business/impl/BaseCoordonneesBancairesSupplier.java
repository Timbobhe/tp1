package fr.ag2rlamondiale.rib.business.impl;

import fr.ag2rlamondiale.ecrs.business.IWorkflowFacade;
import fr.ag2rlamondiale.ecrs.domain.CodeApplicationType;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.workflow.DemandeWorkflowType;
import fr.ag2rlamondiale.ecrs.domain.workflow.error.WorkflowException;
import fr.ag2rlamondiale.ecrs.domain.workflow.lecture.*;
import fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.ecrs.utils.workflow.DemandeUtils;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.rib.utils.JoursOuvresUtils;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.rib.business.impl.RibConstants.MESSAGE_EN_COURS_TRAITEMENT;

public abstract class BaseCoordonneesBancairesSupplier implements ICoordonneesBancairesSupplier {

    @Autowired
    private IWorkflowFacade workflowFacade;

    /**
     * Verifie s'il existe déjà une demande de modification de RIB en attente de prise en compte ou
     * en cours d'activation.
     *
     * @return true si la demande est en cours de traitement ou dactivation
     */
    protected boolean isDemandeEnCoursTraitementOuActivation(IContrat contrat, CoordonneesBancairesDto cb) {
        //RM12
        final RechDemFront rechDemande = new RechDemFront();
        String personId = contrat.getPersonId();
        rechDemande.setIdPers(personId);
        List<Demande> listeDemandesWorkflow;
        try {
            listeDemandesWorkflow = workflowFacade.rechercherDemandes(rechDemande).getDemandes();
        } catch (WorkflowException e) {
            throw new TechnicalRuntimeException(e);
        }

        if (listeDemandesWorkflow != null) {
            List<Demande> demandes = DemandeUtils.getDemandes(listeDemandesWorkflow,
                    Collections.singletonList(DemandeWorkflowType.EXTRANET_RIB))
                    .stream()
                    .filter(demande -> demande.isRelatedToContrat(contrat))
                    .collect(Collectors.toList());

            // Si une demande annulee: IGNOREE
            if (CollectionUtils.isNotEmpty(demandes)) {
                List<EtatDem> etatDem;
                for (Demande demande : demandes) {
                    etatDem = demande.getEtatDem();
                    if (CollectionUtils.isEmpty(etatDem)) {
                        cb.setModificationRibPossible(false);
                        cb.setIdMessage(MESSAGE_EN_COURS_TRAITEMENT);
                        return true;
                    }

                    if (CollectionUtils.isNotEmpty(etatDem)) {
                        return isDemandeAnnuleeOrTraite(cb, demande, etatDem);
                    }
                }
            }
        }

        // Modification possible du RIB
        return false;
    }

    private boolean isDemandeAnnuleeOrTraite(CoordonneesBancairesDto cb, Demande demande, List<EtatDem> etatDem) {
        if (DemandeUtils.isAnnulee(etatDem.get(0))) {
            // Modification possible du RIB
            return false;
        }

        return isDemandeNonTraite(etatDem, demande, cb);
    }

    private boolean isDemandeNonTraite(List<EtatDem> etatDem, Demande demande, CoordonneesBancairesDto cb) {
        if (DemandeUtils.isTraite(etatDem.get(0))) {
            if (isDemandeAssezAncienne(demande)) {
                /*
                 * RECUPERATION DU DETAIL DES COORDONNEES BANCAIRES DE LA DERNIERE
                 * DEMANDE WORKFLOW !
                 */
                DemandeAvecFormulaires dmcb = lireDetailDemandeModifCoordBancairesWorkflow(demande);
                FormulaireCoordonneesBancairesDto rib =
                        dmcb.getDemandeModifCoordonneesBancaires() != null
                                ? dmcb.getDemandeModifCoordonneesBancaires().getCoordonneesBancairesModifiees() : null;
                if (rib != null) {
                    // Si coordonnées bancaires WF <> coordonnées bancaires SPS
                    if (!rib.getCodeIBAN().equalsIgnoreCase(cb.getIban())
                            || !rib.getCodeBIC().equalsIgnoreCase(cb.getBic())
                            || !rib.getTitulaireCompte().equalsIgnoreCase(cb.getTitulaire())) {
                        // Alors le mandat n’a pas encore été pris en compte dans
                        // SPS
                        cb.setIdMessage(MESSAGE_EN_COURS_TRAITEMENT);
                        return true;
                    }
                }
            }
            // Modification possible du RIB
            return false;
        }
        cb.setIdMessage(MESSAGE_EN_COURS_TRAITEMENT);
        return true;
    }

    private boolean isDemandeAssezAncienne(Demande demande) {
        // Vrai si date de traitement de la demande < 3 jours ouvrés avant aujourd'hui
        Date dateJour = new Date();
        return demande.getDateDem()
                .before(JoursOuvresUtils.getDateApresNombreJourOuvres(dateJour, -3));
    }

    private DemandeAvecFormulaires lireDetailDemandeModifCoordBancairesWorkflow(Demande demande) {
        // Parametrer la demande ici
        ConsultDemFront<DemandeAvecFormulaires> consultDemande = new ConsultDemFront<>();
        consultDemande.setInstanciator(DemandeAvecFormulaires::new);
        setCodeAppli(demande);
        consultDemande.setIdDemATC(demande.getIdDemSilo());
        consultDemande.setIdDemWkf(demande.getIdDemWkf());
        try {
            return workflowFacade.consultDemFront(consultDemande);
        } catch (WorkflowException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    private void setCodeAppli(Demande demande) {
        if (demande.getIdDemSilo() != null) {
            demande.getIdDemSilo().setCodeAppli(CodeApplicationType.ATC.getCode());
        }
    }

}
