package fr.ag2rlamondiale.rib.business.impl.ere;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.*;
import fr.ag2rlamondiale.rib.business.impl.BaseCoordonneesBancairesSupplier;
import fr.ag2rlamondiale.rib.business.impl.RibContratVifHelper;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.ecrs.business.IBaseContratFacade;
import fr.ag2rlamondiale.ecrs.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.ecrs.domain.mandat.Mandat;
import fr.ag2rlamondiale.ecrs.domain.mandat.RechercherMandatDto;
import fr.ag2rlamondiale.ecrs.mapping.ContratClientMapper;
import fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.ecrs.client.soap.IRechercherMandatClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

import static fr.ag2rlamondiale.rib.business.impl.RibConstants.MESSAGE_AUCUN_MANDAT_SEPA;
import static fr.ag2rlamondiale.rib.business.impl.RibConstants.MODIFIERRIB_ACCESS_DENIED;


@Component
public class CoordonneesBancairesSupplierERE extends BaseCoordonneesBancairesSupplier {

	@Autowired
	private IBaseContratFacade contratFacade;

	@Autowired
	private ContratClientMapper contratClientMapper;

	@Autowired
	private IRechercherMandatClient mandatClient;

	@Autowired
	private RibContratVifHelper contratVifHelper;

	@Override
	public CoordonneesBancairesDto retrieveCoordonneesBancairesContrat(IContrat contrat) {
		// IdAssure est celui du C1 ou du C4 => PTV aligne tout les compartiments avec le nouveau RIB
		final CompartimentId compartimentId = getCompartimentRib(contrat).getCompartimentId();

		// Rechercher un mandat SEPA valide
		final CompteGeneralesERE compteGenerale;
		try {
			compteGenerale = contratFacade.rechercherCompteGeneralesEre(compartimentId.getIdAssure());
		} catch (TechnicalException e) {
			throw new TechnicalRuntimeException(e);
		}
		CoordonneesBancairesDto cb = new CoordonneesBancairesDto();
		cb.setContrat(contratClientMapper.map(contrat));
		if (compteGenerale.getNumeroMandat() != null) {
			RechercherMandatDto rechercherMandatDto = new RechercherMandatDto();
			rechercherMandatDto.setNumeroMandat(compteGenerale.getNumeroMandat());

			final ContratGeneral contratGeneral;
			try {
				contratGeneral = contratFacade.rechercherContratGeneral(contrat.getContratId());
			} catch (TechnicalException e) {
				throw new TechnicalRuntimeException(e);
			}
			final String codeAssureur = contratGeneral.getCodeAssureur();
			rechercherMandatDto.setCodeAssureur(codeAssureur);

			List<Mandat> mandats = rechercherMandat(rechercherMandatDto);
			if (!mandats.isEmpty()) {
				Mandat mandat = mandats.get(0);
				cb.setBic(mandat.getDebiteur().getCoordBancairesDebiteur().getCodeBIC());
				cb.setIban(mandat.getDebiteur().getCoordBancairesDebiteur().getCodeIBAN());
				cb.setTitulaire(mandat.getDebiteur().getLibDebiteur());
				cb.setIdMessage(null);
			} else {
				cb.setIdMessage(MESSAGE_AUCUN_MANDAT_SEPA);
			}
		} else {
			cb.setIdMessage(MESSAGE_AUCUN_MANDAT_SEPA);
		}

		boolean vifPossible = contratVifHelper.isVifPossible(contrat, compartimentId);
		if (!vifPossible) {
			cb.setIdMessage(MODIFIERRIB_ACCESS_DENIED);
			cb.setModificationRibPossible(false);
			return cb;
		}

		/*
		 * TRAITEMENT: Regle metier sur le workflow
		 * RM12 + RM13
		 */
		isDemandeEnCoursTraitementOuActivation(contrat, cb);
		return cb;
	}

	@Override
	public boolean accept(IContrat contrat) {
		return contrat.isEre();
	}

	@Override
	public boolean isAffichable(IContrat contrat) {
		return getCompartimentRib(contrat) != null;
	}

	/**
	 * Pour un contrat Pacte, on se base sur le c1
	 * Si le c1 est cloturé on se base sur le c4
	 * Si le c4 est cloturé, on ne prend pas en compte le contrat
	 */
	@Override
	public ICompartiment getCompartimentRib(IContrat contrat) {
		final ICompartiment c1 = contrat.findFirstCompartiment(CompartimentType.C1).orElse(null);
		if (c1 != null && c1.getAffichageType().isEnabled()) {
			return c1;
		}

		final ICompartiment c4 = contrat.findFirstCompartiment(CompartimentType.C4).orElse(null);
		if (c4 != null && c4.getAffichageType().isEnabled()) {
			return c4;
		}

		return null;
	}

	public List<Mandat> rechercherMandat(RechercherMandatDto rechercherMandatDto) {
		try {
			return mandatClient.rechercherMandat(rechercherMandatDto);
		} catch (TechnicalException e) {
			throw new TechnicalRuntimeException(e);
		}
	}
}
