package fr.ag2rlamondiale.rib.business.impl;

import fr.ag2rlamondiale.ecrs.domain.contrat.ICompartiment;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;

public interface ICoordonneesBancairesSupplier {
    CoordonneesBancairesDto retrieveCoordonneesBancairesContrat(IContrat contrat);

    boolean accept(IContrat contrat);

    boolean isAffichable(IContrat contrat);

    ICompartiment getCompartimentRib(IContrat contrat);
}
