package fr.ag2rlamondiale.rib.business.impl.document;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.document.creation.BaseDataDocumentContratSupplier;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.document.*;
import fr.ag2rlamondiale.ecrs.domain.document.creation.DataDocumentContrat;
import fr.ag2rlamondiale.ecrs.domain.sigelec.DocumentRIB;
import fr.ag2rlamondiale.ecrs.jahia.IJahiaFacade;
import fr.ag2rlamondiale.ecrs.utils.Sets;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static fr.ag2rlamondiale.ecrs.domain.document.DocumentMDProRefType.MODIFICATION_RIB_MDPRO;
import static fr.ag2rlamondiale.ecrs.domain.document.DocumentRefType.MODIFICATION_RIB;

@Component
public class RibDataDocumentContratSupplier extends BaseDataDocumentContratSupplier<IContrat> {

    private static final String MODIFIERRIB_TITLE = "MODIFIERRIB_TITLE";
    private static final String MODIFIERRIB_EN_LIGNE_TITLE_DOC = "MODIFIERRIB_EN_LIGNE_TITLE_DOC";
    private static final String MODIFIERRIB_AGREMENTS_ACTE = "MODIFIERRIB_AGREMENTS_ACTE";

    public static final Set<DocRefType> RIB_DOCS = Sets.unmodifiableSet(MODIFICATION_RIB, MODIFICATION_RIB_MDPRO);

    @Autowired
    private IJahiaFacade jahiaFacade;

    @Override
    public boolean accept(DocRefType documentRefType) {
        return RIB_DOCS.contains(documentRefType);
    }

    @Override
    public String getNomFichierActeDocumentEnLigne(DocRefType documentRefType) throws IOException {

        String title = null;
        if (documentRefType == MODIFICATION_RIB) {
            title = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_EN_LIGNE_TITLE_DOC);
        } else if (documentRefType == MODIFICATION_RIB_MDPRO) {
            title = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_EN_LIGNE_TITLE_DOC);
        }


        return title;
    }

    @Override
    public String getDocumentTitle(DocRefType documentRefType) throws IOException {

        String title = null;
        if (documentRefType == MODIFICATION_RIB) {
            title = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_TITLE);
        } else if (documentRefType == MODIFICATION_RIB_MDPRO) {
            title = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_TITLE);
        }

        return title;
    }


    @Override
    public String getAgrementActe(DocRefType docRefType) throws IOException {
        String agrementActe = null;
        if (docRefType == MODIFICATION_RIB) {
            agrementActe = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_AGREMENTS_ACTE);
        } else if (docRefType == MODIFICATION_RIB_MDPRO) {
            agrementActe = jahiaFacade.findDictionaryEntry(DictionaryKeyType.MODIFIER_RIB, MODIFIERRIB_AGREMENTS_ACTE);
        }

        return agrementActe;
    }

    @Override
    public void appendParams(DataDocumentContrat<IContrat> documentContrat, IContrat contrat, HashMap<String, String> params) throws IOException {
        if (documentContrat.getRib() != null) { // traitement à ajouter dans le cas des versements ou modif du RIB
            params.putAll(getRibPDFDownloadParams(contrat, documentContrat));
        }
    }


    private HashMap<String, String> getRibPDFDownloadParams(IContrat contratHeader,
                                                            DataDocumentContrat<IContrat> documentContrat) throws IOException {
        DocumentRIB rib = documentContrat.getRib();
        HashMap<String, String> paramsHashMap = new HashMap<>();
        paramsHashMap.put(ParamsDownloadPdfType.CODE_IBAN.getLibelle(), rib.getIban());
        paramsHashMap.put(ParamsDownloadPdfType.CODE_BIC.getLibelle(), rib.getBic());
        paramsHashMap.put(ParamsDownloadPdfType.TITULAIRE_COMPTE.getLibelle(), rib.getTitulaire());

        paramsHashMap.put(ParamsDownloadPdfType.SEPA_ADRESSE_1.getLibelle(),
                jahiaFacade.findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType.ADRESSE_1_SEPA_PDF,
                        contratHeader.getCodeFiliale(), contratHeader.getNomContrat()) + ".");

        setSEPAAdresse2(paramsHashMap, contratHeader);

        paramsHashMap.put(ParamsDownloadPdfType.SEPA_ADRESSE_PAIEMENT.getLibelle(),
                jahiaFacade.findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType.ADRESSE_PAIEMENT_SEPA_PDF,
                        contratHeader.getCodeFiliale(), contratHeader.getNomContrat()));

        return paramsHashMap;
    }

    private void setSEPAAdresse2(HashMap<String, String> paramsHashMap, IContrat contrat)
            throws IOException {

        String adresse2SEPA = jahiaFacade.findDictionaryEntryByNumContratOrCodeFiliale(
                DictionaryKeyType.ADRESSE_2_SEPA_PDF, contrat.getCodeFiliale(), contrat.getNomContrat());

        String adresse1 = null;
        String adresse2;

        if (adresse2SEPA.startsWith("AG2R LA MONDIALE")) {
            adresse1 = adresse2SEPA.substring(0, 17);
            adresse2 = adresse2SEPA.substring(17);
        } else {
            StringBuilder sb = new StringBuilder();

            for (String tokenToAdd : adresse2SEPA.split(" ")) {
                if (adresse1 == null && (sb.length() + tokenToAdd.length()) > 16) {
                    adresse1 = sb.substring(1);
                    sb = new StringBuilder(tokenToAdd);
                } else {
                    sb.append(" ").append(tokenToAdd);
                }
            }

            adresse2 = sb.toString();
        }

        paramsHashMap.put(ParamsDownloadPdfType.SEPA_ADRESSE_2.getLibelle(), adresse1);
        paramsHashMap.put(ParamsDownloadPdfType.SEPA_ADRESSE_3.getLibelle(), adresse2);
    }

    @Override
    public void setDataMap(Map<String, String> parameters, DataDocumentContrat<IContrat> documentContrat) throws TechnicalException {
        Map<String, ChampsPDFInfo> mapResult = convertDataMapToChampsPDF(parameters, documentContrat);
        for (Map.Entry<String, String> entry : parameters.entrySet()) {
            final ArbitrageChampsPdfType arbitrageChampsPdfType = ArbitrageChampsPdfType.fromString(entry.getKey());
            final RibChampsPdfType ribChampsPdfType = RibChampsPdfType.fromString(entry.getKey());

            if (arbitrageChampsPdfType != null) {
                ChampsPDFInfo champsPDFInfo = arbitrageChampsPdfType.toChampsPdfInfo(entry.getValue());
                mapResult.put(entry.getKey(), champsPDFInfo);

            } else if (ribChampsPdfType != null) {
                ChampsPDFInfo champsPDFInfo = ribChampsPdfType.toChampsPdfInfo(entry.getValue());
                mapResult.put(entry.getKey(), champsPDFInfo);
            }

        }
        documentContrat.setDownloadParams(mapResult);
    }


    @Override
    protected String getQrCode(IContrat contrat, DocRefType docRefType) {
        String qrCodeType = null;
        if (docRefType == MODIFICATION_RIB) {
            qrCodeType = QRCodeType.RIB.getQRCode(contrat);

        } else if (docRefType == MODIFICATION_RIB_MDPRO) {
            qrCodeType = QRCodeType.RIB.getQRCode(contrat);
        }

        return qrCodeType;
    }


    @Override
    protected void appendConsentements(DataDocumentContrat<IContrat> documentContrat, List<String> engagementList, List<String> informationList) throws IOException, TechnicalException {
        final DocRefType docRefType = documentContrat.getDocRefType();
        if (docRefType == MODIFICATION_RIB) {
            String engagementCertificationRenseignements = getEngagement(DictionaryKeyType.MODIFIER_RIB,
                    ENGAGEMENT_CERTIFICATION_RENSEIGNEMENTS);
            engagementList.add(engagementCertificationRenseignements);
        }
    }

}
