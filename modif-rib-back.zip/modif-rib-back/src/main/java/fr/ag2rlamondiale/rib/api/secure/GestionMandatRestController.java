package fr.ag2rlamondiale.rib.api.secure;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.aspect.log.LogExecutionTime;
import fr.ag2rlamondiale.rib.business.IGestionMandatFacade;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesStartDto;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.ModificationCoordonneesBancairesDto;
import fr.ag2rlamondiale.ecrs.business.IUploadFileFacade;
import fr.ag2rlamondiale.ecrs.domain.upload.OptionValidationPJ;
import fr.ag2rlamondiale.ecrs.aspect.profile.ProfileExecution;
import fr.ag2rlamondiale.ecrs.aspect.security.SecuredParam;
import fr.ag2rlamondiale.ecrs.aspect.security.SecurityParamType;
import fr.ag2rlamondiale.ecrs.domain.CodeActionType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.bind.JAXBException;
import java.io.IOException;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.CodeActionType.API_COORDONNEES_BANCAIRES_GET;

@RestController
@RequestMapping(path = "/secure")
public class GestionMandatRestController {
	@Autowired
	private IGestionMandatFacade gestionMandatFacade;

	@Autowired
	private IUploadFileFacade uploadFileFacade;

	/**
	 * Méthode pour récupérer la liste des coordonnees bancaires de tous les contrats retraites supp, et en plus épargne et prévoyance
	 * dans le cadre MDPRO
	 */
	@ProfileExecution(codeAction = API_COORDONNEES_BANCAIRES_GET)
	@LogExecutionTime
	@GetMapping(path = "/coordonnees-bancaires/start")
	public CoordonneesBancairesStartDto startChangeCoordonneesBancaires() throws TechnicalException {
		return gestionMandatFacade.startChangeCoordonneesBancaires();
	}

	@ProfileExecution(codeAction = CodeActionType.API_COORDONNEES_BANCAIRES_POST)
	@LogExecutionTime
	@PostMapping(path = "/coordonnees-bancaires/terminate")
	public String terminateChangeCoordonneesBancaires(@SecuredParam(
			paramType = SecurityParamType.CONTRAT) @RequestBody List<ModificationCoordonneesBancairesDto> modificationCoordonneesBancairesDtos,
	                                                  @RequestParam boolean frame) throws CommonException, JAXBException, IOException {

		for (ModificationCoordonneesBancairesDto e : modificationCoordonneesBancairesDtos) {
			uploadFileFacade.validPiecesJointes(e.getFichiersJoint(), OptionValidationPJ.builder().obligatoire(true).maxFiles(1).build(), s -> {
				throw new RuntimeException(s);
			});
		}

		return gestionMandatFacade
				.terminateChangeCoordonneesBancaires(modificationCoordonneesBancairesDtos, frame);
	}
}
