package fr.ag2rlamondiale.rib.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IBaseCalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IBaseContratFacade;
import fr.ag2rlamondiale.ecrs.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.ecrs.domain.CodeApplicationType;
import fr.ag2rlamondiale.ecrs.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.ecrs.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.ecrs.domain.contrat.Encours;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.ecrs.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.ecrs.utils.contrats.SituationAffiliationEnum;
import fr.ag2rlamondiale.rib.business.impl.mdp.VersementMDPROHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.ecrs.utils.Sets.set;


@Service
public class RibContratVifHelper {
    @Autowired
    private IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private IBaseCalculerEncoursContratFacade calculerEncoursContratFacade;

    @Autowired
    private IBaseContratFacade contratFacade;


    public boolean isVifPossible(IContrat contrat) {
        return isVifPossible(contrat, null);
    }

    public boolean isVifPossible(IContrat contrat, CompartimentId compartimentId) {
        if (contrat == null) {
            return false;
        }

        if (contrat.isMdpro()) {
            return estVifPossibleSelonContratMDP(contrat);
        }

        IdSiloDto idSiloDto = getIdSiloDto(contrat);
        PersonnePhysiqueConsult pp;
        try {
            pp = consulterPersonneClient.consulterPersPhys(idSiloDto);
        } catch (TechnicalException e) {
            return false;
        }

        if (pp.getAge() == null || (pp.getAge() > pp.getLimiteAgeVIF())) {
            return false;
        }

        return estVifPossibleSelonContratERE(contrat, compartimentId);
    }

    private boolean estVifPossibleSelonContratMDP(IContrat contrat) {
        return VersementMDPROHelper.isVifPossible(contrat);
    }

    private IdSiloDto getIdSiloDto(IContrat contrat) {
        if (contrat.isEre()) {
            return new IdSiloDto(contrat.getPersonId(),
                    CodeApplicationType.EGESPER_ERE.getCode(), CodeSiloType.ERE.getLibelle());
        } else {
            return new IdSiloDto(contrat.getPersonId(),
                    CodeApplicationType.EGESPER_MDPRO.getCode(), CodeSiloType.MDP.getLibelle());
        }
    }

    private boolean estVifPossibleSelonContratERE(IContrat contrat,
                                                  CompartimentId compartimentId) {
        ContratGeneral contratGeneral;
        try {
            contratGeneral = contratFacade.rechercherContratGeneral(contrat.getContratId());
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
        if ("1".equals(contratGeneral.getOptContratEpargne().getIndRefusVIF())
                || contratGeneral.getOptContratEpargne().isIndResiliation()) {
            return false;
        }

        if (contrat.isPacte()) {
            final CompteGeneralesERE compteGeneralesERE;
            try {
                compteGeneralesERE = contratFacade.rechercherCompteGeneralesEre(compartimentId.getIdAssure());
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException(e);
            }
            if (SituationAffiliationEnum.LIBERE.getCodeSilo().equalsIgnoreCase(compteGeneralesERE.getCodeEtat())) {
                final Encours encours = calculerEncoursContratFacade.getEncours(contrat.getCompartiment(compartimentId));
                return encours.hasVLVersement();
            }

        } else {
            if (!set("3", "4", "5").contains(contratGeneral.getOptContratEpargne().getCodeTypeTenueCompte())) {
                return false;
            }

            final CompteGeneralesERE compteGeneralesERE;
            try {
                compteGeneralesERE = contratFacade.rechercherCompteGeneralesEre(contrat.getIdAssureNonPacte());
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException(e);
            }
            if (SituationAffiliationEnum.LIBERE.getCodeSilo().equalsIgnoreCase(compteGeneralesERE.getCodeEtat())) {
                Encours encours = calculerEncoursContratFacade.getEncours(contrat);
                return encours.hasVLVersement();
            }
        }

        return true;
    }
}
