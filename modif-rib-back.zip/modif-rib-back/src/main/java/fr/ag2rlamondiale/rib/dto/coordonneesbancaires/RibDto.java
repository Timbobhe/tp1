package fr.ag2rlamondiale.rib.dto.coordonneesbancaires;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RibDto {
    private String titulaire;
    private String bic;
    private String iban;
}