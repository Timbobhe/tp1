package fr.ag2rlamondiale.rib.dto.coordonneesbancaires;

import fr.ag2rlamondiale.ecrs.dto.contrat.ContratParcoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CoordonneesBancairesDto {
    private ContratParcoursDto contrat;
    private String idAssure;
    private String titulaire;
    private String bic;
    private String iban;
    private String idMessage;
    private boolean modificationRibPossible;
}
