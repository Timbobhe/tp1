package fr.ag2rlamondiale.rib.domain.sigelec;

import fr.ag2rlamondiale.ecrs.ISupplierLibService;
import fr.ag2rlamondiale.ecrs.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.ecrs.domain.CodeApplicationType;
import fr.ag2rlamondiale.ecrs.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.utils.workflow.FormulaireConstantes;
import fr.ag2rlamondiale.formulaire.modificationcoordonneesbancaires.FormulaireModificationCoordonneesBancaires;
import fr.ag2rlamondiale.ecrs.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.ecrs.domain.sigelec.IFormulaireMapper;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.util.Map;

@Mapper(componentModel = "spring", uses = {DateMapper.class}, imports = {DateMapper.class, StringUtils.class,
        CodeApplicationType.class, FormulaireConstantes.class})
public abstract class FormulaireModificationCoordonneesBancairesMapper implements IFormulaireMapper {

    @Autowired
    private ISupplierLibService supplierLibService;

    @Mapping(target = "instantInitialisationDemande", expression = "java(DateMapper.today())")
    @Mapping(target = "identificationContratDansSilo.identifiantDansSilo", source = "dto.idContrat")
    @Mapping(target = "identificationContratDansSilo.libelleNomSilo", source = "dto.silo", qualifiedByName = "libelleApplicationPTV")
    @Mapping(target = "identificationContratDansSilo.codeApplication", source = "dto.silo", qualifiedByName = "codeApplicationPTV")
    @Mapping(target = "identificationContratDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationContratDansSilo.codeSystemeInformation", source = "dto.silo.libelle")
    @Mapping(target = "identificationContratDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationAffiliationDansSilo.identifiantDansSilo", source = "dto.idAssure")
    @Mapping(target = "identificationAffiliationDansSilo.libelleNomSilo", source = "dto.silo", qualifiedByName = "libelleApplicationPTV")
    @Mapping(target = "identificationAffiliationDansSilo.codeApplication", source = "dto.silo", qualifiedByName = "codeApplicationPTV")
    @Mapping(target = "identificationAffiliationDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationAffiliationDansSilo.codeSystemeInformation", source = "dto.silo.libelle")
    @Mapping(target = "identificationAffiliationDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationUserDansSilo.identifiantDansSilo", source = "dto.idGdi")
    @Mapping(target = "identificationUserDansSilo.libelleNomSilo", source = "dto.silo.libelle")
    @Mapping(target = "identificationUserDansSilo.codeApplication", source = ".", qualifiedByName = "codeApplication")
    @Mapping(target = "identificationUserDansSilo.libelleApplication", source = ".", qualifiedByName = "libelleApplication")
    @Mapping(target = "identificationUserDansSilo.codeSystemeInformation", source = "dto.silo.libelle")
    @Mapping(target = "identificationUserDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationPersonneDansSilo.identifiantDansSilo", source = "dto.idPersonne")
    @Mapping(target = "identificationPersonneDansSilo.libelleNomSilo", source = "dto.silo", qualifiedByName = "libelleApplicationEGESPER")
    @Mapping(target = "identificationPersonneDansSilo.codeApplication", source = "dto.silo", qualifiedByName = "codeApplicationEGESPER")
    @Mapping(target = "identificationPersonneDansSilo.libelleApplication", source = "dto.silo", qualifiedByName = "libelleApplicationEGESPER")
    @Mapping(target = "identificationPersonneDansSilo.codeSystemeInformation", source = "dto.silo.libelle")
    @Mapping(target = "identificationPersonneDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "identificationDemandeDansSilo.identifiantDansSilo", source = "dto.idDemandeWkf")
    @Mapping(target = "identificationDemandeDansSilo.libelleNomSilo", source = "dto.silo.libelle")
    @Mapping(target = "identificationDemandeDansSilo.codeApplication", source = "dto.silo", qualifiedByName = "codeApplicationPTV")
    @Mapping(target = "identificationDemandeDansSilo.libelleApplication", constant = FormulaireConstantes.PTV)
    @Mapping(target = "identificationDemandeDansSilo.codeSystemeInformation", source = "dto.silo.libelle")
    @Mapping(target = "identificationDemandeDansSilo.libelleSystemeInformation", constant = FormulaireConstantes.EPARGNE_RETRAITE_PARTICULIER)

    @Mapping(target = "informationsComplementaires.signaletiquePP.nom", source = "dto.nom")
    @Mapping(target = "informationsComplementaires.signaletiquePP.prenom", source = "dto.prenom")
    @Mapping(target = "informationsComplementaires.dossiersCommunication.emails.libelleEmail", source = "dto.email")
    @Mapping(target = "informationsComplementaires.informationsContrat.raisonSociale", expression = "java(formulaireModificationCoordonneesBancairesDto.getRaisonSocialeAdherente() != null? formulaireModificationCoordonneesBancairesDto.getRaisonSocialeAdherente(): formulaireModificationCoordonneesBancairesDto.getRaisonSocialeContractante())")
    @Mapping(target = "informationsComplementaires.informationsContrat.numeroExterneContrat", source = "dto.referenceExterne")

    // Champs Formulaire CB
    @Mapping(target = "coordonneesBancairesActuelles.titulaireCompte", source = "dto.coordonneesBancairesActuelles.titulaireCompte")
    @Mapping(target = "coordonneesBancairesActuelles.codeIBAN", source = "dto.coordonneesBancairesActuelles.codeIBAN")
    @Mapping(target = "coordonneesBancairesActuelles.codeBIC", source = "dto.coordonneesBancairesActuelles.codeBIC")
    @Mapping(target = "coordonneesBancairesModifiees.titulaireCompte", source = "dto.coordonneesBancairesModifiees.titulaireCompte")
    @Mapping(target = "coordonneesBancairesModifiees.codeIBAN", source = "dto.coordonneesBancairesModifiees.codeIBAN")
    @Mapping(target = "coordonneesBancairesModifiees.codeBIC", source = "dto.coordonneesBancairesModifiees.codeBIC")
    public abstract FormulaireModificationCoordonneesBancaires createFormulaireModifDonneesBancaires(
            FormulaireModificationCoordonneesBancairesDto dto);

    @Named("codeApplication")
    protected String codeApplication(Object ignore) {
        return supplierLibService.getCodeCassiniAppli();
    }

    @Named("libelleApplication")
    protected String libelleApplication(Object ignore) {
        return supplierLibService.getLibelleAppli();
    }

    @Named("codeApplicationPTV")
    protected String codeApplicationPTV(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getCode();
    }

    @Named("libelleApplicationPTV")
    protected String libelleApplicationPTV(CodeSiloType codeSiloType) {
        return codeSiloType.ptv().getLibelle();
    }

    @Named("codeApplicationEGESPER")
    protected String codeApplicationEGESPER(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getCode();
    }

    @Named("libelleApplicationEGESPER")
    protected String libelleApplicationEGESPER(CodeSiloType codeSiloType) {
        return codeSiloType.egesper().getLibelle();
    }

    @Override
    public <C extends IContrat> void putInFormMap(DemandeCreationSigElec<C> demandeSigElec, Map<String, String> formsMap) throws JAXBException {
        DemandeCreationSigElecModifRIB<C> demandeCreationSigElecModifRIB = (DemandeCreationSigElecModifRIB<C>) demandeSigElec;
        for (FormulaireModificationCoordonneesBancairesDto formulaireModificationCoordonneesBancairesDto : demandeCreationSigElecModifRIB.formulaireModificationCoordonneesBancairesDtos) {
            FormulaireModificationCoordonneesBancaires form = this.createFormulaireModifDonneesBancaires(formulaireModificationCoordonneesBancairesDto);
            formsMap.put(getCle(
                    form.getIdentificationContratDansSilo().getIdentifiantDansSilo(),
                    form.getIdentificationContratDansSilo().getCodeSystemeInformation(),
                    form.getIdentificationAffiliationDansSilo().getIdentifiantDansSilo()),
                    marshallFormModificationDonneesBancaires(form));
        }
    }

    private String marshallFormModificationDonneesBancaires(FormulaireModificationCoordonneesBancaires form) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(FormulaireModificationCoordonneesBancaires.class);
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
        StringWriter sw = new StringWriter();
        marshaller.marshal(form, sw);
        return sw.toString();
    }
}
