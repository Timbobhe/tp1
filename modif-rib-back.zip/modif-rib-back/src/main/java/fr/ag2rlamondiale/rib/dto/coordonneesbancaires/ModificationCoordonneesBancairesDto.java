package fr.ag2rlamondiale.rib.dto.coordonneesbancaires;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratId;
import fr.ag2rlamondiale.ecrs.dto.upload.UploadFileDto;
import fr.ag2rlamondiale.ecrs.aspect.security.ISecurityParamAccess;
import fr.ag2rlamondiale.ecrs.domain.workflow.lecture.FormulaireCoordonneesBancairesDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ModificationCoordonneesBancairesDto implements ISecurityParamAccess {
    private ContratId contratId;
    private String email;
    private String codeFiliale;
    private String raisonSociale;

    private FormulaireCoordonneesBancairesDto coordonneesBancairesActuelles;
    private FormulaireCoordonneesBancairesDto coordonneesBancairesModifiees;

    private List<UploadFileDto> fichiersJoint;

    @Override
    public String secureForNumContrat() {
        return this.contratId.getNomContrat();
    }
}
