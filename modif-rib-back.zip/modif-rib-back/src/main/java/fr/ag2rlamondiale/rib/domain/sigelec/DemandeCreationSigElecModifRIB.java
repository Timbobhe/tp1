package fr.ag2rlamondiale.rib.domain.sigelec;

import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.sigelec.DemandeCreationSigElec;
import fr.ag2rlamondiale.ecrs.domain.sigelec.FormulaireActeEnLigneMapperLocator;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@FormulaireActeEnLigneMapperLocator(FormulaireModificationCoordonneesBancairesMapper.class)
@EqualsAndHashCode(callSuper = true)
@Data
public class DemandeCreationSigElecModifRIB<C extends IContrat> extends DemandeCreationSigElec<C> {
    List<FormulaireModificationCoordonneesBancairesDto> formulaireModificationCoordonneesBancairesDtos;

}
