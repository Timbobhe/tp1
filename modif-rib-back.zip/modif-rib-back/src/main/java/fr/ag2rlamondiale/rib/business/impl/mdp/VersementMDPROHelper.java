package fr.ag2rlamondiale.rib.business.impl.mdp;

import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.utils.contrats.TagDeductible;

import java.util.*;

import static fr.ag2rlamondiale.ecrs.utils.Sets.set;
import static fr.ag2rlamondiale.ecrs.utils.contrats.TagDeductible.deductible;
import static fr.ag2rlamondiale.ecrs.utils.contrats.TagDeductible.nonDeductible;

public class VersementMDPROHelper {

    private static final Set<String> TYPCON = set("RA06", "RA07", "RA08", "RA09", "RA10");

    private static final Set<String> RA06_DEDUCTIBLE = set("V02", "V03", "V04", "V05", "V06", "V07", "V08", "V09", "V10", "V11", "V12", "V13", "V14", "V15", "V17", "V18", "V19", "V20", "V21");
    private static final Set<String> RA06_NON_DEDUCTIBLE = set("V01", "V16", "V22");
    private static final Set<String> RA07_NON_DEDUCTIBLE = set("V01");
    private static final Set<String> RA08_NON_DEDUCTIBLE = set("V01");
    private static final Set<String> RA09_DEDUCTIBLE = set("V01", "V02", "V03", "V04", "V05", "V10", "V11", "V12", "V21", "V22", "V23", "V24", "V25", "V31", "V32", "V35", "V41", "V42", "V45");
    private static final Set<String> RA10_NON_DEDUCTIBLE = set("V01", "V02", "V21", "V22", "V41", "V51");

    private static final Map<String, List<TagDeductible>> CONTRAT_AUTORISES_NON_PACTE = new HashMap<>();

    private VersementMDPROHelper() {
        // Forbidden
    }

    static {
        TYPCON.forEach(typcon -> CONTRAT_AUTORISES_NON_PACTE.put(typcon, new ArrayList<>()));
        RA06_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA06").add(deductible(numgen)));
        RA06_NON_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA06").add(nonDeductible(numgen)));
        RA07_NON_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA07").add(nonDeductible(numgen)));
        RA08_NON_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA08").add(nonDeductible(numgen)));
        RA09_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA09").add(deductible(numgen)));
        RA10_NON_DEDUCTIBLE.forEach(numgen -> CONTRAT_AUTORISES_NON_PACTE.get("RA10").add(nonDeductible(numgen)));
    }

    public static boolean isVifPossible(IContrat contrat) {
        if (contrat == null || contrat.getTypeContrat() == null || contrat.getNumGenContrat() == null) {
            return false;
        }
        return CONTRAT_AUTORISES_NON_PACTE.containsKey(contrat.getTypeContrat())
                && CONTRAT_AUTORISES_NON_PACTE.get(contrat.getTypeContrat()) != null
                && CONTRAT_AUTORISES_NON_PACTE.get(contrat.getTypeContrat()).stream()
                .anyMatch(tag -> contrat.getNumGenContrat().equalsIgnoreCase(tag.getNumGen()));
    }

}
