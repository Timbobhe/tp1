package fr.ag2rlamondiale.rib.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.SupplierLib;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.contrat.MetierContratType;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.utils.Lambda.handleException;

@SupplierLib
public interface ISupplierRibService {

    MetierContratType getMetierContratPrincipale() throws TechnicalException;

    Set<MetierContratType> getMetiersContratSecondaires() throws TechnicalException;

    Collection<IContrat> recupererContrats(MetierContratType metierContrat) throws TechnicalException;

    default Collection<IContrat> recupererPrincipauxContrats() throws TechnicalException {
        return recupererContrats(getMetierContratPrincipale());
    }

    default Collection<IContrat> recupererContratsSecondaires() throws TechnicalException {
        return getMetiersContratSecondaires().stream()
                .map(metierContrat -> handleException(() -> recupererContrats(metierContrat)))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }
}
