package fr.ag2rlamondiale.rib.dto.coordonneesbancaires;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class CoordonneesBancairesStartDto {
    private List<CoordonneesBancairesDto> coordonneesBancairesMetierPrincipal;
    private List<CoordonneesBancairesDto> coordonneesBancairesAutresMetiers;
}
