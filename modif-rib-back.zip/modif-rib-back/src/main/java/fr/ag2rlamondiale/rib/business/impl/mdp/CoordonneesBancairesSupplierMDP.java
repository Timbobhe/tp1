package fr.ag2rlamondiale.rib.business.impl.mdp;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.ecrs.business.IBaseContratFacade;
import fr.ag2rlamondiale.ecrs.client.soap.IConsulterClausesBenefCtrClient;
import fr.ag2rlamondiale.ecrs.domain.CodeSiloType;
import fr.ag2rlamondiale.ecrs.domain.clausesbenefctr.ClausesContratDto;
import fr.ag2rlamondiale.ecrs.domain.clausesbenefctr.ConsulterClausesBenefCtrDto;
import fr.ag2rlamondiale.ecrs.domain.clausesbenefctr.ConsulterClausesBenefCtrResponseDto;
import fr.ag2rlamondiale.ecrs.domain.contrat.ICompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.ecrs.domain.contrat.IContrat;
import fr.ag2rlamondiale.ecrs.domain.contrat.contratgenerale.RolePersonneContrat;
import fr.ag2rlamondiale.ecrs.domain.mandat.CoordonneesCmptBanc;
import fr.ag2rlamondiale.ecrs.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.ecrs.mapping.ContratClientMapper;
import fr.ag2rlamondiale.ecrs.security.UserContextHolder;
import fr.ag2rlamondiale.ecrs.utils.DateUtils;
import fr.ag2rlamondiale.ecrs.utils.contrats.RolePersonneContratEnum;
import fr.ag2rlamondiale.rib.business.impl.BaseCoordonneesBancairesSupplier;
import fr.ag2rlamondiale.rib.dto.coordonneesbancaires.CoordonneesBancairesDto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.rib.business.impl.RibConstants.MESSAGE_AUCUN_MANDAT_SEPA;
import static fr.ag2rlamondiale.rib.business.impl.RibConstants.MODIFIERRIB_ACCESS_DENIED;


@Component
public class CoordonneesBancairesSupplierMDP extends BaseCoordonneesBancairesSupplier {

    @Autowired
    private IBaseContratFacade contratFacade;

    @Autowired
    private ContratClientMapper contratClientMapper;

    @Autowired
    private IConsulterPersPhysFacade consulterPersPhysFacade;

    @Autowired
    private IConsulterClausesBenefCtrClient clausesBenefCtrClient;

    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public CoordonneesBancairesDto retrieveCoordonneesBancairesContrat(IContrat contrat) {
        final ContratGeneral contratGeneral;
        try {
            contratGeneral = contratFacade.rechercherContratGeneral(contrat.getContratId());
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }

        final CoordonneesCmptBanc coordonneesCmptBanc = contratGeneral.getCoordonneesCmptBanc();
        CoordonneesBancairesDto cb = new CoordonneesBancairesDto();
        cb.setContrat(contratClientMapper.map(contrat));
        if (coordonneesCmptBanc != null) {
            cb.setBic(coordonneesCmptBanc.getCodeBIC());
            cb.setIban(coordonneesCmptBanc.getCodeIBAN());
            String titulaireCompte = coordonneesCmptBanc.getTitulaireCompte();
            cb.setTitulaire(StringUtils.isBlank(titulaireCompte) ? "NC" : titulaireCompte);
            cb.setIdMessage(null);
        } else {
            cb.setIdMessage(MESSAGE_AUCUN_MANDAT_SEPA);
        }
        //RM7 + RM8 + RM9 + RM10 + RM11
        if (isAssureOrSouscripteurMajeur(contratGeneral)
                && isSouscripteurEqualsAssureAndContratMoral(contratGeneral)
                && isContratNotGarantieOrBeneficiaireNotAcceptant(contrat)
                && isDonneesPersonnellesConfirmees()
                && isTiersPayeur(contratGeneral)) {
            cb.setModificationRibPossible(true);
        } else {
            cb.setIdMessage(MODIFIERRIB_ACCESS_DENIED);
            cb.setModificationRibPossible(false);
        }

        return cb;
    }


    private boolean isAssureOrSouscripteurMajeur(ContratGeneral contratGeneral) {
        //RM8
        // souscripteurs ou assurés mineurs = date de naissance du souscripteur ou de l'assuré
        // inférieure à 18 ans
        return DateUtils.estMajeur(contratGeneral.getDateNaissanceContractante())
                && DateUtils.estMajeur(contratGeneral.getDateNaissanceAssurePrincipal());
    }

    private boolean isSouscripteurEqualsAssureAndContratMoral(ContratGeneral contratGeneral) {
        //RM7 + RM9
        if (StringUtils.isBlank(contratGeneral.getIdContractante())) {
            return true;
        }
        return StringUtils.isNotBlank(contratGeneral.getIdContractante()) && contratGeneral.getIdContractante().startsWith("P") && contratGeneral.getIdContractante().equals(contratGeneral.getIdAssurePrincipal());
    }

    private boolean isContratNotGarantieOrBeneficiaireNotAcceptant(IContrat contrat) {
        //RM10 + RM11
        ConsulterClausesBenefCtrResponseDto dto = consulterClausesBenefCtr(contrat.getNomContrat(), CodeSiloType.MDP);
        return (dto.getClausesContrat().isEmpty()
                || (isCodeTypeBenefAbsent(dto.getClausesContrat(), "DGN")
                && isCodeTypeBenefAbsent(dto.getClausesContrat(), "ACC")));
    }

    private ConsulterClausesBenefCtrResponseDto consulterClausesBenefCtr(String numContrat, CodeSiloType silo) {
        ConsulterClausesBenefCtrDto dto = new ConsulterClausesBenefCtrDto(silo, numContrat);
        try {
            return clausesBenefCtrClient.consulterClausesBenefCtr(dto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    private boolean isCodeTypeBenefAbsent(List<ClausesContratDto> clausesContratDtos,
                                          String codeTypeBenef) {
        for (ClausesContratDto dto : clausesContratDtos) {
            if (codeTypeBenef.equals(dto.getCodeTypeBenef()) && (dto.getDateFinClauseBenef() == null
                    || dto.getDateFinClauseBenef().after(new Date()))) {
                return false;
            }
        }
        return true;
    }

    private boolean isDonneesPersonnellesConfirmees() {
        try {
            return consulterPersPhysFacade.consulterPersPhys(userContextHolder.get().getIdSilo())
                    .isDonneesPersonnellesConfirmees();
        } catch (TechnicalException e) {
            return false;
        }
    }

    private boolean isTiersPayeur(ContratGeneral contratGeneral) {
        List<RolePersonneContrat> rolePersonneContrats = contratGeneral.getRolePersonnes();
        if (rolePersonneContrats == null || rolePersonneContrats.isEmpty()) {
            return true;
        }

        for (RolePersonneContrat rolePersonne : rolePersonneContrats) {
            if (RolePersonneContratEnum.TIERS_PAYEUR.getCodeValue().equals(rolePersonne.getCodeRolePersCtr())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean accept(IContrat contrat) {
        return contrat.isMdpro();
    }

    @Override
    public boolean isAffichable(IContrat contrat) {
        return contrat.getAffichageType().isEnabled();
    }

    @Override
    public ICompartiment getCompartimentRib(IContrat contrat) {
        return null;
    }
}
