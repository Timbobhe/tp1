package fr.ag2rlamondiale.rib.business.impl.mdp;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class TagDeductible {
    private String numGen;
    private boolean deductible;

    public static TagDeductible deductible(String numGen) {
        return new TagDeductible(numGen, true);
    }

    public static TagDeductible nonDeductible(String numGen) {
        return new TagDeductible(numGen, false);
    }
}
