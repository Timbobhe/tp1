package fr.ag2rlamondiale.rib.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static fr.ag2rlamondiale.ecrs.domain.constantes.Constantes.DEFAULT_DATE_FORMAT;

/**
 * Classe permettant de calculer les jours ouvres d'une année
 */
public class JoursOuvresUtils {
    private JoursOuvresUtils() {
        // Empty
    }

    private static Calendar getCalandarDate(Date theDate) {
        Calendar calDate = Calendar.getInstance();
        calDate.setTime(theDate);
        return calDate;
    }

    public static Date getDateApresNombreJourOuvres(Date aPartirDe, int decalageJours) {
        Calendar dateDernierJourOuvre = getCalandarDate(aPartirDe);

        int joursRestant = Math.abs(decalageJours);
        int increment = (decalageJours >= 0) ? 1 : -1;
        while (joursRestant != 0) {
            dateDernierJourOuvre.add(Calendar.DAY_OF_MONTH, increment);
            if (isJourOuvre(dateDernierJourOuvre.getTime())) {
                joursRestant--;
            }
        }
        return dateDernierJourOuvre.getTime();
    }

    public static boolean isJourFerie(Date laDate) {
        for (Date d : getJoursFeries(getCalandarDate(laDate).get(Calendar.YEAR))) {
            SimpleDateFormat sdf = dateFormat(DEFAULT_DATE_FORMAT);
            if (sdf.format(d).equals(sdf.format(laDate))) {
                return true;
            }
        }
        return false;
    }

    public static boolean isJourOuvre(Date laDate) {
        return !isJourWeekEnd(laDate) && !isJourFerie(laDate);
    }

    public static boolean isJourWeekEnd(Date laDate) {
        Calendar cal = getCalandarDate(laDate);
        return cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
                || cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
    }

    public static List<Date> getJoursFeries(int year) {
        List<Date> datesFeriees = new ArrayList<>();

        Date lundiPaques = getLundiPaques(year);

        datesFeriees.add(getJourAn(year));
        datesFeriees.add(lundiPaques);
        datesFeriees.add(getPremierMai(year));
        datesFeriees.add(getHuitMai(year));
        datesFeriees.add(getAscension(lundiPaques));
        datesFeriees.add(getPentecote(lundiPaques));
        datesFeriees.add(getQuatorzeJuillet(year));
        datesFeriees.add(getAssomption(year));
        datesFeriees.add(getToussaint(year));
        datesFeriees.add(getArmistice(year));
        datesFeriees.add(getNoel(year));

        return datesFeriees;
    }

    private static Date getLundiPaques(int year) {
        int a = year / 100;
        int b = year % 100;
        int c = (3 * (a + 25)) / 4;
        int d = (3 * (a + 25)) % 4;
        int e = (8 * (a + 11)) / 25;
        int f = (5 * a + b) % 19;
        int g = (19 * f + c - e) % 30;
        int h = (f + 11 * g) / 319;
        int j = (60 * (5 - d) + b) / 4;
        int k = (60 * (5 - d) + b) % 4;
        int m = (2 * j - k - g + h) % 7;
        int n = (g - h + m + 114) / 31;
        int p = (g - h + m + 114) % 31;
        int day = p + 1;
        int month = n;

        Calendar lundiPaques = Calendar.getInstance();
        lundiPaques.set(year, month - 1, day);
        lundiPaques.add(Calendar.DAY_OF_MONTH, 1);
        return lundiPaques.getTime();
    }

    private static Date getJourAn(int year) {
        Calendar jourAn = Calendar.getInstance();
        jourAn.set(year, Calendar.JANUARY, 1);
        return jourAn.getTime();
    }

    private static Date getPremierMai(int year) {
        Calendar premierMai = Calendar.getInstance();
        premierMai.set(year, Calendar.MAY, 1);
        return premierMai.getTime();
    }

    private static Date getHuitMai(int year) {
        Calendar huitMai = Calendar.getInstance();
        huitMai.set(year, Calendar.MAY, 8);
        return huitMai.getTime();
    }

    private static Date getAscension(Date lundiPaques) {
        Calendar ascension = getCalandarDate(lundiPaques);
        ascension.add(Calendar.DAY_OF_MONTH, 38);
        return ascension.getTime();
    }

    private static Date getPentecote(Date lundiPaques) {
        Calendar pentecote = getCalandarDate(lundiPaques);
        pentecote.add(Calendar.DAY_OF_MONTH, 49);
        return pentecote.getTime();
    }

    private static Date getQuatorzeJuillet(int year) {
        Calendar quatorzeJuillet = Calendar.getInstance();
        quatorzeJuillet.set(year, Calendar.JULY, 14);
        return quatorzeJuillet.getTime();
    }

    private static Date getAssomption(int year) {
        Calendar assomption = Calendar.getInstance();
        assomption.set(year, Calendar.AUGUST, 15);
        return assomption.getTime();
    }

    private static Date getToussaint(int year) {
        Calendar toussaint = Calendar.getInstance();
        toussaint.set(year, Calendar.NOVEMBER, 1);
        return toussaint.getTime();
    }

    private static Date getArmistice(int year) {
        Calendar armistice = Calendar.getInstance();
        armistice.set(year, Calendar.NOVEMBER, 11);
        return armistice.getTime();
    }

    private static Date getNoel(int year) {
        Calendar noel = Calendar.getInstance();
        noel.set(year, Calendar.DECEMBER, 25);
        return noel.getTime();
    }

    /**
     * @param format
     * @return le SimpleDateFormat
     */
    private static final SimpleDateFormat dateFormat(String format) {
        return new SimpleDateFormat(format);
    }
}
