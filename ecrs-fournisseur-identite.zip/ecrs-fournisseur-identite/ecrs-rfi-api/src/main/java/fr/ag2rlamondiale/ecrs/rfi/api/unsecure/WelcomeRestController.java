package fr.ag2rlamondiale.ecrs.rfi.api.unsecure;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// http://localhost:8086/api/public/welcome-app
@RestController
@RequestMapping("/api/public")
public class WelcomeRestController {


	@GetMapping("/welcome-app")
	public String welcome() {
		return String.format("Welcome to %s!", "ECRS-RFI");
	}
}
