package fr.ag2rlamondiale.ecrs.rfi.api.external;

import fr.ag2rlamondiale.ecrs.rfi.security.RfiRoles;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// http://localhost:8086/api/external/welcome-app
@RestController
@RequestMapping("/api/external")
@Secured(RfiRoles.ROLE_EXTERNAL)
public class ExternalWelcomeRestController {


	@GetMapping("/welcome-app")
	public String welcome() {
		return String.format("Welcome to %s!", "ECRS-RFI");
	}
}
