package fr.ag2rlamondiale.ecrs.rfi.config;

import fr.ag2rlamondiale.ecrs.mock.PfsGenerateConfig;
import fr.ag2rlamondiale.trm.CoreConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@ComponentScan({"fr.ag2rlamondiale.ecrs", "fr.ag2rlamondiale.ecrs.rfi"})
@Import({CoreConfig.class, PfsGenerateConfig.class})
public class RfiConfig {
}
