package fr.ag2rlamondiale.ecrs.rfi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RfiApplication {
	public static void main(String[] args) {
		SpringApplication.run(RfiApplication.class, args);
	}
}
