package fr.ag2rlamondiale.ecrs.rfi.security;

public class RfiRoles {
    public static final String ROLE_EXTERNAL = "ROLE_EXTERNAL";

    private RfiRoles() {
    }
}
