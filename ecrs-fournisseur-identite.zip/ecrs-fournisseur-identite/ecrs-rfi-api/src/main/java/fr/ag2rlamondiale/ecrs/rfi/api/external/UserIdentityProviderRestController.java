package fr.ag2rlamondiale.ecrs.rfi.api.external;

import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseInternalDto;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserResponseInternalMapper;
import fr.ag2rlamondiale.ecrs.rfi.security.RfiRoles;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping(path = {"/api/external/identity-provider"})
@Secured(RfiRoles.ROLE_EXTERNAL)
public class UserIdentityProviderRestController {

    @Autowired
    private IUserIdentityProviderFacade userIdentityProviderFacade;

    @Autowired
    private UserResponseInternalMapper mapper;


    @LogExecutionTime(logStart = true)
    @PostMapping("/to-external-user")
    public UserResponseExternalDto userIdentityExternal(@RequestBody UserRequestDto userRequest) {
        final UserResponseExternalDto res = userIdentityProviderFacade.identiteExterne(userRequest);
        log.info(">>> Retour {} - input={}", res, userRequest);
        return res;
    }

    @LogExecutionTime(logStart = true)
    @PostMapping("/to-internal-user-from-federation")
    public UserResponseInternalDto userIdentityInternal(@RequestBody UserRequestDto userRequest) {
        final UserResponseInternal in = userIdentityProviderFacade.identiteInterneDepuisFederation(userRequest, UserRequestOptionsDto.builder()
                .createHabili(true)
                .build());
        final UserResponseInternalDto res = mapper.map(in);
        log.info(">>> Retour {} - input={}", res, userRequest);
        return res;
    }

}
