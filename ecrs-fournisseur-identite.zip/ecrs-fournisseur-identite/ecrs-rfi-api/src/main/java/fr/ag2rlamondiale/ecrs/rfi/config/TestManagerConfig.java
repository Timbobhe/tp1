package fr.ag2rlamondiale.ecrs.rfi.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource("classpath:data-fixtures.xml")
public class TestManagerConfig {
}
