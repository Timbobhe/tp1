package fr.ag2rlamondiale.ecrs.rfi.trm;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RfiSupplierLibService implements ISupplierLibService {

	@Value("${ecrs.front.url}")
	private String urlFront;

	@Override
	public String getCodeCassiniAppli() {
		return "A1573";
	}

	@Override
	public String getLibelleAppli() {
		return "ECRS - Fournisseur Identite";
	}

	@Override
	public String getUrlFront() {
		return urlFront;
	}
}
