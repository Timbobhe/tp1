package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.utils.LockCache;
import fr.ag2rlamondiale.trm.utils.TimestampObject;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import java.lang.reflect.Method;

public interface IMetaCache {

    TimestampObject<LockCache> timestampCache(Object target, Method method, Object[] params);

    default TimestampObject<LockCache> timestampCache(ProceedingJoinPoint joinPoint) {
        final Object target = joinPoint.getTarget();
        final MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        final Method method = signature.getMethod();
        final Object[] params = joinPoint.getArgs();

        return timestampCache(target, method, params);
    }
}
