package fr.ag2rlamondiale.trm.utils;

import lombok.SneakyThrows;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class LimitByteArrayOutputStream extends ByteArrayOutputStream {

    private final int limitSize;

    private String indicator;

    public boolean throwLimitReached;

    private boolean appliedIndicator = false;

    public LimitByteArrayOutputStream(int limitSize) {
        super();
        this.limitSize = limitSize;
    }

    public LimitByteArrayOutputStream(int limitSize, String indicator) {
        this(limitSize);
        this.indicator = indicator;
    }

    public LimitByteArrayOutputStream(int limitSize, String indicator, boolean throwLimitReached) {
        this(limitSize, indicator);
        this.throwLimitReached = throwLimitReached;
    }

    public int getLimitSize() {
        return limitSize;
    }

    @Override
    public synchronized void write(int b) {
        if (limitSize == -1 || limitSize > size()) {
            super.write(b);
        } else if (limitSize <= size()) {
            appendIndicator();
            if (this.throwLimitReached) {
                throw new LimitReachedException();
            }
        }
    }

    @Override
    public synchronized void write(byte[] b, int off, int len) {
        int l = limitSize == -1 ? len : Math.min(limitSize - size(), len);
        super.write(b, off, l);
        if (l < len) {
            appendIndicator();
            if (this.throwLimitReached) {
                throw new LimitReachedException();
            }
        }
    }

    public synchronized void basicWrite(byte[] b, int off, int len) {
        super.write(b, off, len);
    }

    @SneakyThrows
    private synchronized void appendIndicator() {
        if (indicator == null) {
            return;
        }

        if (!appliedIndicator) {
            basicWrite(indicator.getBytes(StandardCharsets.UTF_8), 0, indicator.length());
            appliedIndicator = true;
        }
    }


    public static class LimitReachedException extends RuntimeException {

    }
}
