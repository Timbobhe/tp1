package fr.ag2rlamondiale.trm.utils;

import java.util.function.Supplier;

public class CacheData<T> {

    private T data;

    private LockCache lock = new LockCache();

    public CacheData() {
    }

    public CacheData(T data) {
        this.data = data;
    }

    public T getData() {
        return data;
    }

    public CacheData<T> setData(T data) {
        this.data = data;
        return this;
    }

    public void resetCache() {
        lock.resetCache();
    }

    public <E> E concurrent(Supplier<E> reader, Runnable writer) {
        return lock.concurrent(reader, writer);
    }

    public LockCache getLock() {
        return lock;
    }
}
