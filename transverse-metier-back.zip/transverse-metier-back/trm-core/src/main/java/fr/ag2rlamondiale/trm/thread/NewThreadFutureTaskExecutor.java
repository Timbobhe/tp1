package fr.ag2rlamondiale.trm.thread;

import org.springframework.core.task.AsyncTaskExecutor;

import java.util.concurrent.Callable;
import java.util.concurrent.Future;

public class NewThreadFutureTaskExecutor implements AsyncTaskExecutor {

    @Override
    public void execute(Runnable command) {
        final CustomFutureTask<Void> task = new CustomFutureTask<>(command);
        new Thread(task, ThreadNames.nextName()).start();
    }

    @Override
    public void execute(Runnable runnable, long l) {
        execute(runnable);
    }

    @Override
    public Future<?> submit(Runnable runnable) {
        final CustomFutureTask<Void> task = new CustomFutureTask<>(runnable);
        new Thread(task, ThreadNames.nextName()).start();
        return task;
    }

    @Override
    public <T> Future<T> submit(Callable<T> callable) {
        final CustomFutureTask<T> task = new CustomFutureTask<>(callable);
        new Thread(task, ThreadNames.nextName()).start();
        return task;
    }
}
