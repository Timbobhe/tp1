package fr.ag2rlamondiale.trm.cache;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.security.AuthentificationUtils;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.TimestampObject;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.web.session.HttpSessionDestroyedEvent;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Slf4j
@Service
public class TrackUserCacheImpl implements ITrackUserCache, ClearableCache, TrackUserCacheImplMBean {

    @Autowired
    private IQueryCache queryCache;

    @Autowired
    private CacheManager cacheManager;

    private final ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>> userCacheEntries = new ConcurrentHashMap<>();


    @Getter
    @Setter
    @Value("${ecrs.trackusercache.active:true}")
    private boolean enable = true;

    @Override
    public void trackUserCache(Object target, Method method, Object[] params) {
        if (!enable) {
            return;
        }

        final NoAuthRequired noAuthRequired = method.getAnnotation(NoAuthRequired.class);
        if (noAuthRequired != null) {
            return;
        }

        final String idGdi = idGdi();
        if (idGdi == null) {
            return;
        }

        queryCache.withCache(target, method, params, (cache, key) -> saveUserCacheEntry(new UserCacheEntry(idGdi, cache.getName(), key)));
    }

    public void saveUserCacheEntry(UserCacheEntry userCacheEntry) {
        if (log.isDebugEnabled()) {
            log.debug("saveUserCacheEntry {}", userCacheEntry);
        }
        userCacheEntries.computeIfAbsent(userCacheEntry.getIdGdi(), s -> new TimestampObject<>(new ConcurrentHashMap<>())).touch().getObject().put(userCacheEntry, true);
    }

    @Override
    public void clearUserCache(String idGdi) {
        if (idGdi == null) {
            return;
        }

        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> removed = userCacheEntries.remove(idGdi);
        log.info("ClearUserCache {} : {} entr\u00E9es surpprim\u00E9es", idGdi, removed != null ? removed.getObject().size() : 0);
        if (removed != null) {
            removed.getObject().forEach((userCacheEntry, aBoolean) -> this.removeUserCacheEntry(userCacheEntry));
        }
    }

    @Override
    public void migrateTrackUserCache(String idGdiSource, String idGdiCible) {
        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> source = userCacheEntries.remove(idGdiSource);
        if (source != null) {
            final ConcurrentMap<UserCacheEntry, Boolean> mc = userCacheEntries.computeIfAbsent(idGdiCible, s -> new TimestampObject<>(new ConcurrentHashMap<>(), source.getTimestamp())).getObject();
            source.getObject().forEach((userCacheEntry, aBoolean) -> mc.put(userCacheEntry.toBuilder().idGdi(idGdiCible).build(), aBoolean));
        }
    }

    private void removeUserCacheEntry(UserCacheEntry userCacheEntry) {
        try {
            final Cache cache = cacheManager.getCache(userCacheEntry.getCacheName());
            if (cache != null) {
                cache.evictIfPresent(userCacheEntry.getKeyCache());
            }
        } catch (Exception ignore) {
            // ignore exception
        }
    }

    private String idGdi() {
        try {
            return AuthentificationUtils.getIdGdi();
        } catch (CommonException e) {
            return null;
        }
    }

    @Override
    public void clearCache() {
        this.userCacheEntries.clear();
    }

    @Override
    public void logUserCacheEntries() {
        this.userCacheEntries.forEach((idGdi, entries) -> log.info("JMX\tUserCacheEntry {} : {} entr\u00E9es", idGdi, entries.getObject().size()));
    }

    @Override
    public void logUserCacheEntries(String idGdi) {
        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> entries = this.userCacheEntries.get(idGdi);
        if (entries == null) {
            log.info("JMX\tAucun cache pour {}", idGdi);
            return;
        }
        log.info("JMX\tUserCacheEntry {} : {} entr\u00E9es", idGdi, entries.getObject().size());
        entries.getObject().forEach((userCacheEntry, aBoolean) -> log.info("JMX\tUserCacheEntry {}", userCacheEntry));
    }


    @Override
    @Scheduled(fixedRateString = "${cache.concurrent.cleaning.fixedRate:1800000}") // 30min
    public void cleanUserCacheEntries() {
        try {
            log.info("D\u00E9but du nettoyage des UserCacheEntries, total = {}", userCacheEntries.size());
            final Instant now = Instant.now();
            List<Object> keys = new ArrayList<>();
            userCacheEntries.forEach((key, value) -> {
                final Instant timestamp = value.getTimestamp();
                if (timestamp.plus(30, ChronoUnit.MINUTES).isBefore(now)) {
                    keys.add(key);
                }
            });

            keys.forEach(userCacheEntries::remove);
            log.info("Fin du nettoyage des UserCacheEntries, restant = {}", userCacheEntries.size());
        } catch (Exception e) {
            log.error("Erreur pendant le nettoyage des UserCacheEntries", e);
        }
    }

    @Override
    @NoAuthRequired
    @LogError(category = "EVENT_LISTENER")
    @EventListener(HttpSessionDestroyedEvent.class)
    public void handleSessionDestroyed(HttpSessionDestroyedEvent event) {
        if (event != null && event.getSession() != null) {
            if (log.isDebugEnabled()) {
                log.debug("Session destroyed id={}", event.getSession().getId());
            }
            final UserContext userContext = UserContextHolder.getUserContext(event.getSession());
            if (userContext != null) {
                this.clearUserCache(userContext.getIdGdi());
            }
        }
    }
}
