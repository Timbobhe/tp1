package fr.ag2rlamondiale.trm.log;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface LogError {

    /**
     * @return Log le type d'appel, "REST" par exemple
     */
    String category() default "";
}
