package fr.ag2rlamondiale.trm.csv;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ParametersAreNonnullByDefault
public enum SituationFamilialeType {
    // classer par ordre alphabétique
    C("C", "Célibataire", true),
    D("D", "Divorcé", true),
    M("M", "Marié", true),
    P("P", "PACS", true),
    T("T", "PACS + 3 ANS", true),
    S("S", "Séparé de droit", true),
    F("F", "Séparé de fait", true),
    U("U", "Union libre", true),
    V("V", "Veuf", true),
    VM("VM", "Vie maritale", true),
    // Non renseigné, la valeur Groupe n'a pas encore été validée par le Métier.
    // Libellé vide en cas d'impression client
    NR("NR", "", false),
    // Hors nomenclature Xref/Groupe. Libellé vide en cas d'impression client
    HNX("HNX", "", false);

    private final String code;

    private final String libelle;

    // Détermine si le choix de situation familiale concerné est proposé à l'utilisateur pour
    // edition
    private final boolean availableForEdition;

    private static Map<String, SituationFamilialeType> situationFamilialeTypeParCode = initSituationFamilialesParCode();

    private static Map<String, SituationFamilialeType> initSituationFamilialesParCode() {
        Map<String, SituationFamilialeType> map = new HashMap<>();
        for (SituationFamilialeType situationFamiliale : SituationFamilialeType.values()) {
            map.put(situationFamiliale.getCode(), situationFamiliale);
        }
        return map;
    }

    SituationFamilialeType(String code, String libelle, boolean availableForEdition) {
        this.code = code;
        this.libelle = libelle;
        this.availableForEdition = availableForEdition;
    }

    public String getCode() {
        return code;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getCodeEtLibelle() {
        if ("XX".equals(getCode())) {
            return getLibelle();
        }

        return code + " - " + libelle;
    }

    protected boolean isAvailableForEdition() {
        return availableForEdition;
    }

    /**
     * @return une liste contenant null suivi de chaque département
     */
    @Nullable
    public static SituationFamilialeType getSituationFamilialeByCode(@Nullable String code) {
        if (code == null) {
            return null;
        }
        return situationFamilialeTypeParCode.get(code);
    }

    /**
     * @return une liste contenant null suivi de chaque département
     */
    public static List<SituationFamilialeType> getAllElementsForEditionIncludingNull() {
        List<SituationFamilialeType> result = new ArrayList<>();
        result.add(null);
        for (SituationFamilialeType sitFamType : SituationFamilialeType.values()) {
            if (sitFamType.isAvailableForEdition()) {
                result.add(sitFamType);
            }
        }
        return result;
    }
}
