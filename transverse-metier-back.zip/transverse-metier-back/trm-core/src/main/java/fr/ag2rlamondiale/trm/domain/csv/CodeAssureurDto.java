package fr.ag2rlamondiale.trm.domain.csv;

import lombok.Data;

import java.io.Serializable;

@Data
public class CodeAssureurDto implements Serializable {
    private static final long serialVersionUID = 6106700205962430152L;

    private String code;
    private String numICS;
    private String libelle;
    private String profileSignatureElectronique;

    public CodeAssureurDto(String code, String numICS, String libelle, String profileSignatureElectronique) {
        this.code = code;
        this.numICS = numICS;
        this.libelle = libelle;
        this.profileSignatureElectronique = profileSignatureElectronique;
    }
}
