package fr.ag2rlamondiale.trm.domain.partenaire;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Partenaire implements Serializable {
    public static final String CODE_NIE = "49505";
    public static final String CODE_ADDING = "49504";

    private static final long serialVersionUID = 3041615428666612534L;
    private String codePartenaire;
    private String codePartenairePrincipal;
    private String label;
    private String urlHeader;
    private String urlFooter;
    private String urlError;
    private String urlMenu;
    private String nomCss;
    private String baseUrl;
    private List<String> idContrats;
    private String refExterne;

    public String getCodeAppli() {
        if (refExterne != null && CODE_NIE.equals(codePartenaire)) {
            return "A1587";
        } else if (CODE_ADDING.equals(codePartenaire)) {
            return "A1520";
        } else {
            return "A1573";
        }
    }
}
