package fr.ag2rlamondiale.trm.rest.oauth2;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.InMemoryClientRegistrationRepository;

import java.util.ArrayList;
import java.util.List;

/**
 * Pour les applications NON Spring Boot, implémenter cette interface dans une classe avec l'annotation @Configuration.
 * <p> Par exemple </p>
 * <pre>
 *     {@code
 * @Configuration
 * public class OAuth2Config implements OAuth2Configurable {
 *
 * }
 *     }
 * </pre>
 *
 */
public interface OAuth2Configurable {
    Logger log = LoggerFactory.getLogger(OAuth2Configurable.class);

    @Bean
    default OAuth2AuthorizedClientManager authorizedClientManager(ClientRegistrationRepository clients) {
        OAuth2AuthorizedClientService service = new InMemoryOAuth2AuthorizedClientService(clients);
        AuthorizedClientServiceOAuth2AuthorizedClientManager manager = new AuthorizedClientServiceOAuth2AuthorizedClientManager(clients, service);

        // @formatter:off
        OAuth2AuthorizedClientProvider authorizedClientProvider = OAuth2AuthorizedClientProviderBuilder.builder().clientCredentials().build();
        // @formatter:on

        manager.setAuthorizedClientProvider(authorizedClientProvider);
        return manager;
    }

    @Bean
    default ClientRegistrationRepository customClientRegistrationRepository(OAuth2ClientProperties properties) {
        List<ClientRegistration> registrations = new ArrayList<>(OAuth2ClientPropertiesRegistrationAdapter.getClientRegistrations(properties).values());

        if (registrations.isEmpty()) {
            log.warn("ClientRegistrations is empty");
            return registrationId -> {
                throw new IllegalStateException("Impossible de retrouver le provider " + registrationId + " => Verifier la CONF oauth2.client");
            };
        }

        return new InMemoryClientRegistrationRepository(registrations);
    }

    @Bean
    default OAuth2ClientProperties oauth2ClientProperties() {
        return new OAuth2ClientProperties();
    }

}
