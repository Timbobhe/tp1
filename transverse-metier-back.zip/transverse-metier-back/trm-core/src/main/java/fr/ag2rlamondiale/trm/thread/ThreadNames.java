package fr.ag2rlamondiale.trm.thread;

import java.util.concurrent.atomic.AtomicLong;

public class ThreadNames {

    public static final String NEW_THREAD_NAME = "nt";

    private static AtomicLong counter = new AtomicLong(0);

    private ThreadNames() {
        // utils
    }

    public static long nextCounter() {
        counter.compareAndSet(Long.MAX_VALUE, 0);
        return counter.incrementAndGet();
    }

    public static String nextName() {
        final String parent = Thread.currentThread().getName();
        return parent + "::" + NEW_THREAD_NAME + nextCounter();
    }
}
