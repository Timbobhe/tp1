package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Arrays;

@Data
public class SoapRequestContext {
    private String codeApplication;
    private String idGdi;
    private SecurityHeaderInfo securityHeaderInfo;

    private boolean enableXCaller;
    private boolean hasSharepointTokenEre;
    private boolean hasSharepointTokenMdpro;
    private boolean hasSecurityHeader;
    private boolean forceLogBody;

    private String endpoint;
    private Arg arg;

    public void setArg(String name, Object value) {
        if (value == null) {
            return;
        }

        if (value.getClass().isArray()) {
            Object[] array = (Object[]) value;
            this.arg = new Arg(name, array.length == 1 ? array[0] : Arrays.asList(array));
        } else {
            this.arg = new Arg(name, value);
        }
    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    public static class Arg {
        private String name;
        private Object value;

        @Override
        public String toString() {
            StringBuilder str = new StringBuilder();
            if (name != null) {
                str.append(name).append("=");
            }
            str.append(value);
            return str.toString();
        }
    }
}
