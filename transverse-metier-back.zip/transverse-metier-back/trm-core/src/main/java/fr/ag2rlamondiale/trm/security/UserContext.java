package fr.ag2rlamondiale.trm.security;


import fr.ag2rlamondiale.trm.demo.CompteDemo;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import lombok.*;

import java.io.Serializable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class UserContext implements Serializable {

    private static final long serialVersionUID = 6515295438592524330L;

    public static final String CODE_PARTENAIRE_NIE = "49505";
    private boolean initialized;

    protected String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
    private Partenaire partenaire;
    private String sousPartenaire;
    private String nom;
    private String prenom;
    private String civilite;
    private boolean impersonation;
    /**
     * Top Impersonnation
     */
    private String externalUid;

    private boolean filialeACA;

    private boolean hasContratEre;

    private boolean pilotage;

    private Integer temporaryId;

    private boolean hasIdGdi;

    private String currentIdContrat;
    private String currentCodeSilo;

    private InfosBlocagesClient infosBlocagesClient;

    private Set<CodeSiloType> silos;

    private CompteDemo compteDemo;

    private String idExtranet;


    /**
     * Indique que l'utilisateur n'est pas un vrai utilisateur mais uniquement utilisé pour les Tests de supervision
     */
    private boolean forSupervision;

    public boolean isPartenaireNIE() {
        if (this.partenaire != null) {
            return CODE_PARTENAIRE_NIE.equals(this.partenaire.getCodePartenaire());
        }
        return false;
    }

    public IdSiloDto getIdSilo() {
        return CodeApplicationType.idSilo(this);
    }

    public IdSiloDto getIdSilo(CodeSiloType codeSiloType) {
        return CodeApplicationType.idSilo(this, codeSiloType);
    }

    public Set<CodeSiloType> getSilos() {
        if (silos == null) {
            silos = new HashSet<>(2);
        }
        return Collections.unmodifiableSet(silos);
    }

    public boolean estDansSilo(CodeSiloType codeSilo) {
        return getSilos().contains(codeSilo);
    }

    public boolean estUniquementDansSilo(CodeSiloType codeSilo) {
        return getSilos().size() == 1 && estDansSilo(codeSilo);
    }

    public String getNumeroPersonne(CodeSiloType codeSiloType) {
        switch (codeSiloType) {
            case ERE:
                return getNumeroPersonneEre();
            case MDP:
                return getNumeroPersonneMdpro();
        }
        throw new IllegalArgumentException();
    }

    public boolean isCompteDemo() {
        return compteDemo != null;
    }

    public boolean isConnectedUser() {
        return true;
    }
}
