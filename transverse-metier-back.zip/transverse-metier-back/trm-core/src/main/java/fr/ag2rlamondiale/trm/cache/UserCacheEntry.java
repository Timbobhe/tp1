package fr.ag2rlamondiale.trm.cache;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class UserCacheEntry {
    private String idGdi;
    private String cacheName;
    private Object keyCache;
}
