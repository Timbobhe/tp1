/*
 * Cree le 25 févr. 2019. (c) Ag2r - La Mondiale, 2019. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.personne.detail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class Address implements Serializable {
    private static final long serialVersionUID = 6090745907780753756L;

    @JsonProperty(value = "libelle")
    String libelle;

    @JsonProperty(value = "codePostale")
    String postalCode;

    @JsonProperty(value = "ville")
    String city;

    @JsonProperty(value = "pays")
    String country;

    public Address() {
        super();
    }
}
