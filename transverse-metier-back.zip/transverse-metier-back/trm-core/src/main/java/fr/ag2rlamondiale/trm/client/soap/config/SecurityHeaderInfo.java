package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class SecurityHeaderInfo {
    private String login;
    private String password;
    private String codeApplication;
}
