/*
 * Cree le 14 avr. 2015. (c) Ag2r - La Mondiale, 2015. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import lombok.Getter;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

/**
 * Code CASSINI. Pour retrouver la signification d'un code CASSINI :<br>
 * 1. Taper cassini dans le navigateur web<br>
 * 2. Lancer une recherche sur le code
 */
@Getter
public enum CodeApplicationType {
    /**
     * Ancienne application salarie de retraite supplementaire en GWT.
     */
    AQEA("A1324"),

    /**
     * Application salarie de retraite supplementaire en Angular.
     */
    ECRS("A1573"),

    /**
     * Referentiel ERE des utilisateurs client AG2R La Mondiale.
     */
    EGESPER_ERE("A0499", CodeSiloType.ERE, "EGESPER ERE"),

    /**
     * Referentiel MdPro des utilisateurs client AG2R La Mondiale.
     */
    EGESPER_MDPRO("A0406", CodeSiloType.MDP, "EGESPER MDPRO"),

    /**
     * Referentiel ERE des contrats AG2R La Mondiale.
     */
    PTV_ERE("A0252", CodeSiloType.ERE, "ERE PTV2/3"),

    /**
     * Referentiel MdPro des contrats AG2R La Mondiale.
     */
    X8_MDPRO("A0443", CodeSiloType.MDP, "MDPRO 8X"),

    /**
     * Mini-Workflow pour les applications Front.
     */
    ATC("A0535"),

    /**
     * Workflow ERE
     */
    WORKFLOW_ERE("A0185", CodeSiloType.ERE),
    /**
     * Workflow MDPRO
     */
    WORKFLOW_MDPRO("A0944", CodeSiloType.MDP),

    CODE_APPLI_MAIL("A0136"),

    CODE_APPLI_EMETTRICE_MAIL("A0487"),

    CODE_APPLI_PARCOURS_CLIENT("A1531"),

    PTV_RENTE_ERE("A0426", CodeSiloType.ERE, "ERE PTV1 RENTES");

    private final String code;

    private final String libelle;

    private CodeSiloType silo;

    CodeApplicationType(String code) {
        this(code, null, null);
    }

    CodeApplicationType(String code, CodeSiloType silo) {
        this(code, silo, null);
    }

    CodeApplicationType(String code, CodeSiloType silo, String libelle) {
        this.code = code;
        this.silo = silo;
        this.libelle = libelle;
    }


    public static CodeApplicationType getTypeByCode(String code) {
        for (CodeApplicationType type : values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }

        return null;
    }

    public IdSiloDto idSilo(String identifiant) {
        return IdSiloDto.forAppli(identifiant, this);
    }

    public static IdSiloDto idSilo(UserContext userContext) {
        if (userContext.estDansSilo(CodeSiloType.ERE)) {
            return EGESPER_ERE.idSilo(userContext.getNumeroPersonneEre());
        }
        if (userContext.estDansSilo(CodeSiloType.MDP)) {
            return EGESPER_MDPRO.idSilo(userContext.getNumeroPersonneMdpro());
        }

        return null;
    }

    public static IdSiloDto idSilo(UserContext userContext, CodeSiloType codeSilo) {
        if (CodeSiloType.ERE.equals(codeSilo) && isNotBlank(userContext.getNumeroPersonneEre())) {
            return EGESPER_ERE.idSilo(userContext.getNumeroPersonneEre());
        }
        if (CodeSiloType.MDP.equals(codeSilo) && isNotBlank(userContext.getNumeroPersonneMdpro())) {
            return EGESPER_MDPRO.idSilo(userContext.getNumeroPersonneMdpro());
        }

        return null;
    }
}
