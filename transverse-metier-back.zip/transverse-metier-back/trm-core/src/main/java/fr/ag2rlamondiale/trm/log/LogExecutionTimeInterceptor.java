package fr.ag2rlamondiale.trm.log;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Slf4j
@Aspect
@Component
public class LogExecutionTimeInterceptor implements Ordered {

    @Around("@annotation(logExecutionTime)")
    public Object logExecutionTime(ProceedingJoinPoint joinPoint, LogExecutionTime logExecutionTime) throws Throwable /*NOSONAR*/ {

        if (!log.isInfoEnabled()) {
            return joinPoint.proceed();
        }

        Signature signature = joinPoint.getSignature();
        String argsString = "";
        if (joinPoint.getArgs() != null && joinPoint.getArgs().length > 0) {
            argsString = Arrays.toString(joinPoint.getArgs());
        }
        String infosAppelMethode = "[" + signature.getDeclaringType().getSimpleName() + "] " + signature.getName() + "("
                + argsString + ")";

        long start = System.currentTimeMillis();
        if (logExecutionTime.logStart()) {
            log.info(infosAppelMethode + " start");
        }

        Object proceed = joinPoint.proceed();

        long executionTime = System.currentTimeMillis() - start;
        log.info(infosAppelMethode + " executed in " + executionTime + " ms");
        return proceed;
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.LOG_EXECUTION_TIME_ORDER;
    }
}
