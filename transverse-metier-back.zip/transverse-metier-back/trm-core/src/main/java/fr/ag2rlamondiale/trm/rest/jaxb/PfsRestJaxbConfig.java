package fr.ag2rlamondiale.trm.rest.jaxb;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

@Configuration
public class PfsRestJaxbConfig {
    public static final String JAXB_REST_TEMPLATE = "restTemplateJaxb";
    public static final String JAXB_OBJECT_MAPPER = "objectMapperJaxb";
    public static final String DATE_FORMAT = "yyyy-MM-dd";

    @Bean(JAXB_REST_TEMPLATE)
    public RestTemplate restTemplateJaxb() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().stream()
                .filter(AbstractJackson2HttpMessageConverter.class::isInstance)
                .map(AbstractJackson2HttpMessageConverter.class::cast)
                .findFirst()
                .ifPresent(httpMessageConverter -> {
                    ObjectMapper mapper = httpMessageConverter.getObjectMapper();
                    DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
                    mapper.setDateFormat(dateFormat);
                    mapper.registerModule(new JaxbAnnotationModule());
                });
        return restTemplate;
    }


    @Bean(JAXB_OBJECT_MAPPER)
    public ObjectMapper buildJaxbObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        objectMapper.setDateFormat(dateFormat);
        objectMapper.registerModule(new JaxbAnnotationModule());
        return objectMapper;
    }

}
