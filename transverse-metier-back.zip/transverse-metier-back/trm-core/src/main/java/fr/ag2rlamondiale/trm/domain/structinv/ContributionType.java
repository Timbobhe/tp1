package fr.ag2rlamondiale.trm.domain.structinv;

import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import lombok.Getter;

import javax.annotation.Nonnull;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * Type de compartiment.
 */
@Getter
public enum ContributionType {
    VERSEMENT_LIBRE("VERLIB", "Versement libre", CompartimentType.C1, true), // Part facultative
    PART_PATRONALE("PPATRO", "Part patronale", CompartimentType.C3, false),
    PART_SALARIALE("PSALAR", "Part salariale", CompartimentType.C3, false),
    VERSEMENTS_VOLONTAIRES_DEDUCTIBLES("VERVOL", "Versements Volontaires", CompartimentType.C1, true),
    EPARGNE_SALARIALE("EPSALAR", "Epargne Salariale", CompartimentType.C2, true),
    VERSEMENTS_VOLONTAIRES_NON_DEDUCTIBLES("VERVOLND", "Versements Volontaires non d\u00E9ductibles", CompartimentType.C4, true),
    PART_PATRONALE_VERSEMENT_LIBRE("PPVERLIB", "Part patronale/Versement Libre", null, true);

    /**
     * Le code correspondant à cette enum dans PFS ("codeContributionInv").
     */
    @Nonnull
    private final String code;

    /**
     * Le libelle correspondant à cette enum dans PFS ("libContributionInvSilo").
     */
    @Nonnull
    private final String libelle;

    private final CompartimentType compartiment;

    private boolean facultative;

    ContributionType(String code, String libelle, CompartimentType compartiment, boolean facultative) {
        this.code = code;
        this.libelle = libelle;
        this.compartiment = compartiment;
        this.facultative = facultative;
    }

    @Nonnull
    public String getCode() {
        return code;
    }

    public static ContributionType fromCode(@Nonnull String code) {
        for (ContributionType value : values()) {
            if (value.getCode().equals(code)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown code: " + code);
    }

    public static ContributionType forLibelle(String libelle) {
        if(libelle == null) {
            return null;
        }
        final String cl = libelle.trim();
        for (ContributionType value : values()) {
            if (value.getLibelle().equals(cl)) {
                return value;
            }
        }
        throw new IllegalArgumentException("Unknown libelle: " + cl);
    }

    public static List<ContributionType> forCompartiment(CompartimentType compartimentType, boolean pacte) {
        if (pacte) {
            return forCompartiment(compartimentType);
        }

        return forCompartimentNonPacte(compartimentType);
    }

    public static List<ContributionType> forCompartiment(CompartimentType compartimentType) {
        return Stream.of(values())
                .filter(t -> t.getCompartiment() != null && t.getCompartiment().equals(compartimentType))
                .collect(Collectors.toList());
    }

    public static List<ContributionType> forCompartimentNonPacte(CompartimentType compartimentType) {
        switch (compartimentType) {
            case C1:
            case C4:
                return Collections.singletonList(ContributionType.VERSEMENT_LIBRE);
            case C2:
                return Collections.emptyList();
            case C3:
                return Arrays.asList(ContributionType.PART_PATRONALE, ContributionType.PART_SALARIALE);
        }
        return Collections.emptyList();
    }
}
