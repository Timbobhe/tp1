package fr.ag2rlamondiale.trm.domain.document;

import lombok.Getter;

@Getter
public enum ArbitrageChampsPdfType implements ToChampsPDFInfo {
    TITRE("Titre"), GRAPHIQUE("Corps", TypeChampsPdfType.HTML);

    private final String champs;
    // ReadOnly true par defaut
    private final boolean readOnly;
    // Par defaut type TEXT
    private final TypeChampsPdfType type;

    ArbitrageChampsPdfType(String champs) {
        this(champs, TypeChampsPdfType.TEXT);
    }

    ArbitrageChampsPdfType(String champs, TypeChampsPdfType type) {
        this.champs = champs;
        this.type = type;
        this.readOnly = true;
    }

    public static ArbitrageChampsPdfType fromString(String text) {
        if (text != null) {
            for (ArbitrageChampsPdfType element : ArbitrageChampsPdfType.values()) {
                if (element.getChamps().equalsIgnoreCase(text)) {
                    return element;
                }
            }
        }
        return null;
    }

    @Override
    public ChampsPDFInfo toChampsPdfInfo(String valeur) {
        return new ChampsPDFInfo(valeur, isReadOnly(), getType());
    }
}
