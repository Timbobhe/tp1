package fr.ag2rlamondiale.trm.domain;

import lombok.Getter;

@Getter
public enum CodeDestinataireType {
    ASSURE("A"),
    SALARIE("S"),
    ENTREPRISE("E");

    private final String libelle;

    private CodeDestinataireType(String libelle) {
        this.libelle = libelle;
    }

    public static CodeDestinataireType fromLibelle(String str) {
        for (CodeDestinataireType type : values()) {
            if (type.libelle.equals(str)) {
                return type;
            }
        }
        return null;
    }
}
