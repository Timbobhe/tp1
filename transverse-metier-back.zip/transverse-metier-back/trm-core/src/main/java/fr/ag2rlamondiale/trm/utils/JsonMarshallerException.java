package fr.ag2rlamondiale.trm.utils;

public class JsonMarshallerException extends RuntimeException {
    private static final long serialVersionUID = -4077964320530391834L;

    public JsonMarshallerException(Throwable cause) {
        super(cause);
    }


}
