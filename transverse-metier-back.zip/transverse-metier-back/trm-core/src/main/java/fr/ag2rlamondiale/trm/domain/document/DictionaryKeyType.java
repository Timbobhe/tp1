package fr.ag2rlamondiale.trm.domain.document;

import java.util.Arrays;

public enum DictionaryKeyType {
    ADRESSES_CONTRATS_PDF("ADRESSES_CONTRATS_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/mentionslegalespdf-1"),
    ADRESSE_COURRIER_PDF("ADRESSE_COURRIER_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/mentionslegalescontratspdf-1"),
    ADRESSE_COURRIER_VERSEMENTS_PDF("ADRESSE_COURRIER_VERSEMENTS_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/adressecourrierversementspdf"),
    ADRESSE_1_SEPA_PDF("ADRESSE_1_SEPA_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/adresse1sepapdf"),
    ADRESSE_2_SEPA_PDF("ADRESSE_2_SEPA_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/adresse2sepapdf"),
    ADRESSE_PAIEMENT_SEPA_PDF("ADRESSE_PAIEMENT_SEPA_PDF","/sites/aqe/home/retraite-supplementaire/mentions-legales/mentions/area-simple-content/adressepaiementsepapdf"),
    ARBITRAGE("arbitrage_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/area-simple-content/arbitragedictionnairedelibelles"),
    ARBITRAGE_MDPRO("arbitrage_mdpro_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/mdpro/area-simple-content/arbitragemdprodictionnairedelibelles"),
    ARRET_VERSEMENT("dictionnaire_arretVersement", "/sites/aqe/ecrs/arretversement/body-content/dictionnairearretversement"),
    CHOIX_OPTION("choixOption_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/faire-une-demande-de-choix-doption/area-simple-content/choixoptiondictionnairedelibelles"),
    CLAUSE_BENEFICIAIRE_COMMUN("clause_beneficiaire_commun_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/modifier-sa-clause-beneficiaire/area-simple-content/clausebeneficiairecommundictionn"),
    CLAUSE_BENEFICIAIRE("clause_beneficiaire_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/modifier-sa-clause-beneficiaire/area-simple-content/clausebeneficiairedictionnairede"),
    CLAUSE_STANDARD("clausestandard_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausestandarddictionnairedelibe"),
    CLAUSE_CONTRAT("clause_contrat_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausecontratdictionnairedelibel"),
    COMMON_APP_MESSAGES("common_app_messages_dictionnaire", "/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content/commonappmessagesdictionnaire"),
    COMPLETER_BIA("completerbia_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/area-simple-content/completerbiadictionnairedelibell"),
    DOCUMENTS("documents_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/vos-documents/area-simple-content/documentsdictionnairedelibelles"),
    EN_SAVOIR_PLUS("ensavoirplus_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/ensavoirplusMessages/area-simple-content/ensavoirplusdictionnairedelibell"),
    LIQUIDATION("liquidation_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/effectuer-une-liquidation/area-simple-content/liquidationdictionnairedelibelle"),
    MDPRO("MDPRO_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/area-simple-content/mdprodictionnairedelibelles"),
    MODIFICATIONS_DONNEES_PERSONELLES("modifdonneesperso_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/modification-donnees-personnelle/area-simple-content/modifdonneespersodictionnairedel"),
    MODIFIER_RIB("modifierrib_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/modifier-le-rib/area-simple-content/modifierribdictionnairedelibelle"),
    SIGNATURE_ELECTRONIQUE("signature_electronique_dictionnaire", "/sites/aqe/home/retraite-supplementaire/signatureelectronique/area-simple-content/signatureelectroniquedictionnair"),
    SUIVI_DEMANDE("suividemande_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/suivre-vos-demandes/area-simple-content/suividemandedictionnairedelibell"),
    TITLE("titles_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/area-simple-content/titlesdictionnairedelibelles"),
    VERSEMENT_LIBRE("versementlibre_dictionnaire_de_libelles", "/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/faire-un-versement-libre/area-simple-content/versementlibredictionnairedelibe");
    DictionaryKeyType(String name, String url) {
        this.name = name;
        this.url = url;
    }

    private final String name;
    private final String url;

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public static DictionaryKeyType fromName(String name) {
        return Arrays.stream(DictionaryKeyType.values()).filter(dictionaryKeyType -> dictionaryKeyType.getName().equals(name)).findAny().orElse(null);
    }
}
