package fr.ag2rlamondiale.trm.utils;

import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.Reader;
import java.io.StringReader;

public class XmlMarshaller {

    private XmlMarshaller() {
    }

    @SuppressWarnings("unchecked")
    public static <T> T fromXml(String xml, Class<T> clazz) {
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(clazz);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            StringReader stringReader = new StringReader(xml);
            InputSource inputSource = new InputSource(stringReader);
            return (T) jaxbUnmarshaller.unmarshal(inputSource);
        } catch (Exception e) {
            throw new XmlMarshallerException(e);
        }
    }

    public static <T> T convertXMLStringToObject(String xmlString, Class<T> type) {
        try {
            Reader reader = new StringReader(xmlString);
            XMLInputFactory xif = XMLInputFactory.newFactory();
            // disable resolving of external DTD entities
            xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);

            XMLStreamReader xsr = xif.createXMLStreamReader(reader);
            do {
                nextElement(xsr);
            } while (xsr.hasNext() && !"Body".equals(xsr.getLocalName()));
            xsr.nextTag();
            JAXBContext jaxbContext = JAXBContext.newInstance(type);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<T> object = jaxbUnmarshaller.unmarshal(xsr, type);
            return object.getValue();
        } catch (Exception e) {
            throw new XmlMarshallerException(e);
        }
    }

    /**
     * Convertir le body SOAP en objet, lu depuis {@code ressourcePath} <br>
     * <p>Usage : {@code XmlMarshaller.convertSoapBodyToObject("/xml/file1.xml", Employee.class);}</p>
     *
     * @param <T>
     * @param ressourcePath chemin absolut du fichier dans le classPath
     * @param type          class de retour.
     * @return Object
     */
    public static <T> T convertSoapBodyToObject(String ressourcePath, Class<T> type) {
        try {
            XMLInputFactory xif = XMLInputFactory.newFactory();
            // disable resolving of external DTD entities
            xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
            XMLStreamReader xsr = xif.createXMLStreamReader(XmlMarshaller.class.getResourceAsStream(ressourcePath));
            do {
                nextElement(xsr);
            } while (xsr.hasNext() && !"Body".equals(xsr.getLocalName()));
            xsr.nextTag();
            JAXBContext jaxbContext = JAXBContext.newInstance(type);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<T> object = jaxbUnmarshaller.unmarshal(xsr, type);
            return object.getValue();
        } catch (Exception e) {
            throw new XmlMarshallerException(e);
        }
    }

    /**
     * Convertir le body SOAP en objet, lu depuis {@code ressourcePath} <br>
     * <p>Usage : {@code XmlMarshaller.convertSoapBodyToObject("/xml/file1.xml", CreerDemOpeType.class, FormulaireQuestion.class);}</p>
     *
     * @param <T>
     * @param ressourcePath chemin absolut du fichier dans le classPath
     * @param type          class de retour.
     * @param formType      class du formulaire
     * @return Object
     */
    public static <T, F> T convertSoapBodyToObject(String ressourcePath, Class<T> type, Class<F> formType) {
        try {
            XMLInputFactory xif = XMLInputFactory.newFactory();
            // disable resolving of external DTD entities
            xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
            XMLStreamReader xsr = xif.createXMLStreamReader(XmlMarshaller.class.getResourceAsStream(ressourcePath));
            do {
                nextElement(xsr);
            } while (xsr.hasNext() && !"Body".equals(xsr.getLocalName()));
            xsr.nextTag();
            JAXBContext jaxbContext = JAXBContext.newInstance(type, formType);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            JAXBElement<T> object = jaxbUnmarshaller.unmarshal(xsr, type);
            return object.getValue();
        } catch (Exception e) {
            throw new XmlMarshallerException(e);
        }
    }

    @SuppressWarnings("squid:S1166")
    private static void nextElement(XMLStreamReader xsr) throws XMLStreamException {
        try {
            xsr.nextTag();
        } catch (XMLStreamException e) {
            xsr.next();
        }
    }
}
