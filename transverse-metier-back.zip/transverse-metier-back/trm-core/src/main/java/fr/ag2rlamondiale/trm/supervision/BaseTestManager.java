package fr.ag2rlamondiale.trm.supervision;

import com.ag2r.common.administration.model.AbstractTestManager;
import com.ag2r.common.administration.model.TestReport;

import java.util.Objects;

public abstract class BaseTestManager extends AbstractTestManager { //NOSONAR

    public static final String PROFILE_TESTMANAGER = "testManager";

    public BaseTestManager(String name) {
        setName(name);
    }

    @Override
    public TestReport performTest() {
        TestReport result = new TestReport(TestReport.RESULT_OK);
        try {
            test();
        } catch (Exception e) {
            result.setCause(e);
            result.setResult(TestReport.RESULT_KO);
        }
        return result;
    }

    @SuppressWarnings("squid:S00112")
    protected abstract void test() throws Exception;

    protected void requireDep(Object dep, String name, Class<?> clazz) {
        Objects.requireNonNull(dep, "Il manque le bean '" + name + "' de classe " + clazz.getName());
    }
}
