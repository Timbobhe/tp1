package fr.ag2rlamondiale.trm.domain;

public interface ICodeActionType {
    String name();

    static ICodeActionType fromCode(String codeAction) {
        return () -> codeAction;
    }
}
