package fr.ag2rlamondiale.trm.mvel;

import org.mvel2.MVEL;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class ExpressionEvaluator {
    public boolean eval(String expression, Map<String, Object> context) {
        final Boolean res = (Boolean) MVEL.eval(expression, context);
        return Boolean.TRUE.equals(res);
    }
}
