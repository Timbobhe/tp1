package fr.ag2rlamondiale.trm.supervision;

import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import lombok.Data;

@Data
public class UserTestManager {
    private String idGdi;
    private PersonnePhysique personnePhysique;

    public UserTestManager() {
        // Constructeur vide
    }

    public UserTestManager(String idGdi, String numeroEre) {
        this(idGdi, numeroEre, null);
    }

    public UserTestManager(String idGdi, String numeroEre, String numeroMdpro) {
        this.idGdi = idGdi;
        this.personnePhysique = new PersonnePhysique();
        this.personnePhysique.setIdGdi(this.idGdi);
        this.personnePhysique.setNumeroPersonneEre(numeroEre);
        this.personnePhysique.setNumeroPersonneMdpro(numeroMdpro);
    }
}
