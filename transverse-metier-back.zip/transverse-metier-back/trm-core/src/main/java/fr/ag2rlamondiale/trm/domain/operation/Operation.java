package fr.ag2rlamondiale.trm.domain.operation;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
@Data
public class Operation implements Serializable {
    private static final long serialVersionUID = -7411016161295605204L;

    private String codeTypeOperation;
    private String id;
    private String libelle;
    private String codeSituationOperation;
    private String codeSituationOperationSilo;

    private Boolean enCoursTraitement;

    private Date date;
    private Date debutPeriode;
    private Date finPeriode;
    private BigDecimal montant;
    private BigDecimal montantBrut;
    private BigDecimal montantFGNet;
    private BigInteger anneeFiscaleRef;
    private boolean deductible;

    // Necessite d'etre recupere par rapport au codeTypeOperation et la table de reference
    private TypeOperation typeOperation;
}
