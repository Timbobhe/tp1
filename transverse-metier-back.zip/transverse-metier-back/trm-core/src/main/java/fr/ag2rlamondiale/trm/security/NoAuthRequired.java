package fr.ag2rlamondiale.trm.security;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Indique que la méthode ne nécessite pas d'être authentifier (utiliser pour le tracking du cache utilisateur,
 * ne pas résoudre l'utilisateur ou sa session)
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface NoAuthRequired {
}
