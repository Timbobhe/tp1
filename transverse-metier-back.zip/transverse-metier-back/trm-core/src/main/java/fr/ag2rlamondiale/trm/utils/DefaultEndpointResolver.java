package fr.ag2rlamondiale.trm.utils;


import fr.ag2rlamondiale.trm.demo.ICompteDemoEndpointResolver;
import fr.ag2rlamondiale.trm.demo.NullCompteDemoEndpointResolver;
import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.soap.PortInitializer;
import lombok.Setter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Service;
import org.springframework.util.StringValueResolver;

import static fr.ag2rlamondiale.trm.utils.UrlUtils.assembleUrl;

@Service
public class DefaultEndpointResolver implements EmbeddedValueResolverAware, IEndpointResolver, InitializingBean {

    private StringValueResolver stringValueResolver;

    @Setter
    @Value("${pfs.reverseProxy}")
    private String pfsSoapReverseProxy;

    @Setter
    @Value("${pfs.restReverseProxy}")
    private String pfsRestReverseProxy;

    @Autowired(required = false)
    private ICompteDemoEndpointResolver compteDemoEndpointResolver = NullCompteDemoEndpointResolver.instance;


    @Override
    public String getSoapUrl(PortInitializer portInitializer) {
        String url = compteDemoEndpointResolver.getUrl(portInitializer.serviceId());
        if (url != null) {
            return url;
        }

        return getUrl(portInitializer.serviceId(), portInitializer.alternative(), pfsSoapReverseProxy);
    }

    @Override
    public String getRestUrl(PfsRestServiceConfig pfsRestServiceConfig) {
        String url = compteDemoEndpointResolver.getUrl(pfsRestServiceConfig.getServiceId());
        if (url != null) {
            return url;
        }
        return getUrl(pfsRestServiceConfig.getServiceId(), pfsRestServiceConfig.getAlternative(), pfsRestReverseProxy);
    }

    @Override
    public String getSoapUrlForLog(PortInitializer portInitializer) {
        return getUrl(portInitializer.serviceId(), portInitializer.alternative(), pfsSoapReverseProxy);
    }

    @Override
    public String getRestUrlForLog(PfsRestServiceConfig pfsRestServiceConfig) {
        return getUrl(pfsRestServiceConfig.getServiceId(), pfsRestServiceConfig.getAlternative(), pfsSoapReverseProxy);
    }

    public String getUrl(String serviceId, String alternative, String reverseProxy) {

        if (alternative != null && !alternative.isEmpty()) {
            try {
                final String evaluated = stringValueResolver.resolveStringValue(alternative);
                if (evaluated != null && (!evaluated.equals(alternative) || !evaluated.contains("${"))) {
                    return evaluated;
                }
            } catch (IllegalArgumentException ignore) {
                // ignore
            }
        }

        return assembleUrl(reverseProxy, serviceId);
    }

    @Override
    public void setEmbeddedValueResolver(StringValueResolver resolver) {
        stringValueResolver = resolver;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if (compteDemoEndpointResolver == null) {
            compteDemoEndpointResolver = NullCompteDemoEndpointResolver.instance;
        }
    }
}
