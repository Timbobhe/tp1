package fr.ag2rlamondiale.trm.domain.workflow;

import fr.ag2rlamondiale.trm.domain.exception.UnknownEnumerationValueException;

import javax.annotation.Nonnull;

public enum CodeTypePieceJointeWorkflowEnum {
    // NOM, CODE TYPE DOCUMENT, NOM
    ACCES_EXTRANET("AX", "Acces Extranet"),
    ACCORD_D_ENTREPRISE("AE", "Accord d'entreprise"),
    ACCUSE_DE_RECEPTION("AC", "Accuse de reception"),
    ACTE_DE_DECES("ADDC", "Acte de deces"),
    AFFILIATION("AFFI", "Affiliation"),
    AGIRA_RENTIERS("AGIR", "AGIRA RENTIERS"),
    APPEL_DE_CONTRIBUTION("ADCO", "Appel de contribution"),
    APPEL_DE_FONDS("ADF", "Appel de fonds"),
    AR_RECLAMATION("ARR", "AR Réclamation"),
    ARBITRAGES("ARB", "Arbitrages"),
    ARRET_DE_COTISATION("ARTC", "Arret de cotisation"),
    ATTESTATION_ANTIBLANCHIMENT("AANT", "Attestation antiblanchiment"),
    ATTESTATION_DE_FIN_DE_VERSEMENTS("AFV", "Attestation de fin de versements"),
    ATTESTATION_ORIAS_ET_D_ASSURANCE("AOA", "Attestation ORIAS et d'assurance"),
    AUTORISATION_DE_PRELEVEMENT("ADP", "Autorisation de prelevement"),
    AVENANT("AVN", "Avenant"),
    AVENANT_D_ADHESION("AA", "Avenant d'adhesion"),
    AVENANT_DE_NOUVELLE_SELECTION("ANS", "Avenant de nouvelle selection"),
    AVIS_D_IMPAYE("AI", "Avis d'impaye"),
    AVIS_D_IMPOSITION("LIAI", "Avis d'imposition"),
    AVIS_DE_RECEPTION("ADR", "Avis de reception"),
    AVIS_TIERS_DETENTEUR("ATD", "Avis tiers detenteur"),
    BENEFICE_DES_ANNUITES_GARANTIES("BAG", "Benefice des annuites garanties"),
    BIA("BIA", "BIA"),
    BILAN_EXAMEN_MEDICAUX_DIVERS("BEM", "Bilan, examen medicaux divers"),
    BORDEREAUX("BRD", "Bordereaux"),
    BORDEREAUX_DE_COMMISSION("BC", "Bordereaux de commission"),
    BULLETIN_DE_SOUSCRIPTION("BS", "Bulletin de souscription"),
    CARTE_D_IDENTITE("CID", "Carte d'identite"),
    CERTIFICAT_DE_GAIN("CGN", "Certificat de gain"),
    CERTIFICAT_DE_RENTE_LETTRE_D_ACCOMPAGNEMENT("CR",
            "Certificat de rente+lettre d'accompagnement"),
    CESSION_DE_CREANCE("CSC", "Cession de creance"),
    CHANGEMENT_D_ADRESSE("CHA", "Changement d'adresse"),
    CHANGEMENT_D_INTERLOCUTEUR("CI", "Changement d'interlocuteur"),
    CHANGEMENT_DE_CLAUSE_BENEFICIAIRE("CCB", "Changement de clause beneficiaire"),
    CHANGEMENT_DE_COORDONNEES_BANCAIRES_OU_POSTALES("CDC",
            "Changement de coordonnees bancaires ou postales"),
    CHANGEMENT_DE_DENOMINATION_SOCIALE("CDS", "Changement de denomination sociale"),
    CHANGEMENT_DE_MONTANT_DE_PO("CHPO", "Changement de montant de PO"),
    CHANGEMENT_DE_NOM("CDN", "Changement de nom"),
    CLAUSE_BENEFICIAIRE("CCB", "Clause beneficiaire"),
    COMMISSION_EXCEPTIONELLE("CE", "Commission exceptionelle"),
    COMMUNICATION_SPECIFIQUE("COMSPE", "Communication specifique"),
    COMPTE_EPARGNE("CEP", "Compte epargne"),
    COMPTE_RENDU_DE_GESTION("CRGE", "Compte rendu de gestion"),
    COMPTE_TECHNIQUE("CT", "Compte technique"),
    CONDITIONS_GENERALES("CG", "Conditions generales"),
    CONDITIONS_PARTICULIERES("CP", "Conditions particulieres"),
    CONTRIBUTION_L137_11("CONT", "Contribution L137-11"),
    CONVENTION_D_APPORT("CA", "Convention d'apport"),
    CONVENTION_DE_PREUVE("CPR", "Convention de preuve"),
    COTISATION_OU_DOTATION_EXCEPTIONNELLE("CDE", "Cotisation ou dotation exceptionnelle"),
    COURRIER_AVERTISSEMENT_SAISIE("CAS", "Courrier avertissement saisie"),
    COURRIER_CONFIDENTIEL("CC", "Courrier confidentiel"),
    COURRIER_SORTANT_ANTIBLANCHIMENT("CSA", "Courrier sortant (antiblanchiment)"),
    COURRIER_SORTANT_CLAUSE_BENEFICIAIRE("CSCB", "Courrier sortant (clause beneficiaire)"),
    COURRIER_SORTANT_COMMISSIONNEMENT("CSCM", "Courrier sortant (commissionnement)"),
    COURRIER_SORTANT_CORRESPONDANCE("CSCR", "Courrier sortant (correspondance)"),
    COURRIER_SORTANT_DOCUMENTS_BANCAIRES("CSDB", "Courrier sortant (documents bancaires)"),
    COURRIER_SORTANT_DOCUMENTS_CONTRACTUELS("CSDC", "Courrier sortant (documents contractuels)"),
    COURRIER_SORTANT_DOCUMENTS_D_ETUDES_OU_DE_VENTE("CSE",
            "Courrier sortant (documents d'etudes ou de vente)"),
    COURRIER_SORTANT_FATCA("CSFA", "Courrier sortant (FATCA)"),
    COURRIER_SORTANT_FISCALITE("CSF", "Courrier sortant (fiscalite)"),
    COURRIER_SORTANT_GESTION_ADMINISTRATIVE("CSG", "Courrier sortant (gestion administrative)"),
    COURRIER_SORTANT_LETTRE_DE_RESILIATION("CSRI", "Courrier sortant (Lettre de resiliation)"),
    COURRIER_SORTANT_LIQUIDATION_DE_RETRAITE("CSL", "Courrier sortant (liquidation de retraite)"),
    COURRIER_SORTANT_MEDICAL("CSM", "Courrier sortant (Medical)"),
    COURRIER_SORTANT_PRESTATION_SORTIE("CSP", "Courrier sortant (prestation/sortie)"),
    COURRIER_SORTANT_RECLAMATION("CSRC", "Courrier sortant (reclamation)"),
    COURRIER_SORTANT_RECOUVREMENT("CSR", "Courrier sortant (recouvrement)"),
    COURRIER_SORTANT_RELEVES("CSRV", "Courrier sortant (releves)"),
    COURRIER_SORTANT_RENTE("CSRT", "Courrier sortant (rente)"),
    COURRIER_SORTANT_REVALORISATION("CSRO", "Courrier sortant (revalorisation)"),
    COURRIER_SORTANT_SINISTRE("CSS", "Courrier sortant (sinistre)"),
    COURRIER_SORTANT_TACOTAC("CST", "Courrier sortant (tacotac)"),
    CURATELLE_TUTELLE("CUTU", "Curatelle/tutelle"),
    DECLARATION_ANNUELLE_DE_SALAIRE("DAS", "Declaration annuelle de salaire"),
    DECLARATION_DE_DECES("DCD", "Declaration de deces"),
    DECLARATION_DE_SANTE("DDS", "Declaration de sante"),
    DECLARATION_FISCALE("DF", "Declaration fiscale"),
    DECLARATION_GAGNANT("DG", "Declaration gagnant"),
    DEMANDE_D_AVENANT("DA", "Demande d'avenant"),
    DEMANDE_D_ETUDE_ET_DE_REETUDE("DER", "Demande d'etude et de reetude"),
    DEMANDE_D_ETUDE("DDE", "Demande d'étude"),
    DEMANDE_DE_CONTRAT("DC", "Demande de contrat"),
    DEMANDE_DE_VALEURS_ET_SIMULATION("DVS", "Demande de valeurs et simulation"),
    DEROGATION("DERO", "Derogation"),
    DOCUMENT_REVALORISATION("DORO", "Document revalorisation"),
    DOCUMENTS_DIVERS("DODI", "Documents divers"),
    DOCUMENTS_INTERNES("DI", "Documents internes"),
    DONNEES_PERSONNELLES("DOPE", "Donnees personnelles"),
    DOSSIER_APPRECIATION_DU_RISQUE("DAR", "Dossier appreciation du risque"),
    DSN_CHEQUE_ENCAISSE("CDSN", "DSN : Cheque encaisse"),
    DUPLICATA("DPC", "Duplicata"),
    DECES_AGIRA_I("AGI", "Décès AGIRA I"),
    DECES_AGIRA_II("AGII", "Décès AGIRA II"),
    DECES_SUSPICION("DSP", "Décès suspicion"),
    DECES_SUSPICION_AGIRA_I("DSA1", "Décès suspicion AGIRA I"),
    DECES_SUSPICION_AGIRA_II("DSA2", "Décès suspicion AGIRA II"),
    ECHEANCIER("ECH", "Echeancier"),
    ENVOI_DOSSIER_DE_LIQUIDATION("EDL", "Envoi dossier de liquidation"),
    ETATS_CUMULES("EC", "Etats cumules"),
    ETUDE("ETD", "Etude"),
    EXONERATION("EXO", "Exoneration"),
    EXTRANET_CREATION_COMPTE_ENTREPRISE("ECCE", "Extranet : Création compte entreprise"),
    EXTRANET_CREATION_COMPTE_SALARIE("ECCS", "Extranet : Création compte salarié"),
    EXTRANET_MODIFICATION_DES_DONNEES("EMD", "Extranet : modification des donnees"),
    EXTRANET_MODIFICATION_DES_DONNEES_ENTREPRISE("EMDE",
            "Extranet : modification des donnees entreprise"),
    EXTRANET_FONCTIONNEMENT_DU_SITE("EFS", "Extranet: Fonctionnement du site"),
    EXTRANET_FONCTIONNEMENT_DU_SITE_ENTREPRISE("EFSE",
            "Extranet: Fonctionnement du site entreprise"),
    EXTRANET_QUESTION_DE_GESTION("EQG", "Extranet: Question de gestion"),
    EXTRANET_QUESTION_DE_GESTION_ENTREPRISE("EQGE", "Extranet: Question de gestion entreprise"),
    EXTRANET_QUESTION_SUR_LES_VIFS("EQV", "Extranet: Question sur les VIFs"),
    EXTRANET_QUESTIONS_DIVERSES_COURTIER("EQD", "Extranet: Questions Diverses Courtier"),
    FICHE_DE_SYNTHESE("FDS", "Fiche de synthese"),
    FISCALITE_GESTION("FIGE", "Fiscalite gestion"),
    FISCALITE_PRESTATION("FIPR", "Fiscalite prestation"),
    FISCALITE_RENTE("FIRE", "Fiscalite rente"),
    GARANTIES_GESTION("GAR", "Garanties gestion"),
    IFU("IFU", "Imprimé Fiscal Unique"),
    INFORMATIONS_GENERALES("IG", "Informations generales"),
    JURIDIQUE("JRI", "Juridique"),
    JUSTIFICATIF_VIE("JV", "Justificatif vie"),
    KBIS_STATUTS("KBI", "Kbis/statuts"),
    LETTRE_AVENANT("LA", "Lettre avenant"),
    LETTRE_AVENANT_CLAUSE_BENEFICIAIRE("LAC", "Lettre avenant clause beneficiaire"),
    LETTRE_DE_MISE_EN_DEMEURE("LMD", "Lettre de mise en demeure"),
    LETTRE_DE_RELANCE("LDR", "Lettre de relance"),
    LETTRE_DE_RESILIATION_COURRIER_SORTANT("CSRI", "Lettre de resiliation (Courrier sortant)"),
    LIQUIDATION_DE_RETRAITE("LR", "Liquidation de retraite"),
    LOI_FILLON("LF", "Loi Fillon"),
    MAJ_ACTUARIELLE("DRE", "MAJ Actuarielle"),
    MANDAT("MDT", "Mandat"),
    MEMO("MEMO", "MEMO"),
    MISE_EN_CONFORMITE_ART82_83("MEC", "Mise en conformite Art82/83"),
    MODIFICATION_DE_COTISATION("MDC", "Modification de cotisation"),
    MODIFICATION_DE_PORTEFEUILLE("MP", "Modification de portefeuille"),
    MODIFICATIONS_DIVERSES("MD", "Modifications diverses"),
    MOINS_PERCUS_TROP_PERCUS("MTP", "Moins perçus/Trop perçus"),
    NANTISSEMENT("NAT", "Nantissement"),
    NOTE_INFORMATION_GESTION("NIG", "Note information gestion"),
    NOTE_INFORMATION_LIQUIDATION("NILI", "Note Information Liquidation"),
    NOTICE_DE_GESTION("NDG", "Notice de gestion"),
    PAIEMENT_RENTE("PMTRT", "Paiement rente"),
    PARAMETRAGE_DSN("PDSN", "Parametrage DSN"),
    PIECES_DIVERSES_ANTI_BLANCHIMENT("PDA", "Pieces diverses anti-blanchiment"),
    PIECES_DIVERSES_CLAUSE_BENEFICIAIRE("PDB", "Pieces diverses clause beneficiaire"),
    PIECES_DIVERSES_COMMISSIONNEMENT("PDC", "Pieces diverses commissionnement"),
    PIECES_DIVERSES_DECES("PDDC", "Pieces diverses deces"),
    PIECES_DIVERSES_DOCUMENTS_BANCAIRES("PDD", "Pieces diverses documents bancaires"),
    PIECES_DIVERSES_RENTE("PDR", "Pieces diverses rente"),
    PND("PND1", "PND"),
    PND_DAS("PNDA", "PND DAS"),
    PND_DECEDE("PNDD", "PND decede"),
    PND_RAS("PNDR", "PND RAS"),
    PROPOSITION("PRP", "Proposition"),
    PROPOSITION_D_OPTIONS_DE_RENTE("POR", "Proposition d'options de rente"),
    PROTOCOLE("PRT", "Protocole"),
    QAD("QAD", "Questionnaire d’aide à la décision"),
    QUESTIONS_DIVERSES_COMMISSIONNEMENT("QDC", "Questions diverses commissionnement"),
    QUESTIONS_DIVERSES_FISCALITE("QDF", "Questions diverses fiscalite"),
    QUESTIONS_DIVERSES_SINISTRE("QDS", "Questions diverses sinistre"),
    QUESTIONS_DIVERSES_TACOTAC("QDT", "Questions diverses Tacotac"),
    QUITTANCE("QUIT", "Quittance"),
    RACHAT_DE_RENTE("RDR", "Rachat de rente"),
    RACHAT_RETRAIT("RAC", "Rachat/retrait"),
    RAPPEL_INTERLOCUTEUR("RINT", "Rappel interlocuteur"),
    RAPPORT_CONFIDENTIEL("RC", "Rapport confidentiel"),
    RAPPORTS_R137_4("RAPR", "Rapports R137-4"),
    RECLAMATION("RCL", "Reclamation"),
    RECLAMATION_DG("REDG", "Reclamation DG"),
    REFUS_VIF("RVIF", "Refus VIF"),
    REGULARISATION("RGL", "Regularisation"),
    REGULARISATION_DE_COMMISSION("RGC", "Regularisation de commission"),
    REGULARISATION_FATCA("RGFA", "Regularisation FATCA"),
    REJET_BANCAIRE_COMMISSIONNEMENT("RBC", "Rejet bancaire commissionnement"),
    REJET_BANCAIRE_PRESTATION("RBP", "Rejet bancaire prestation"),
    REJET_BANCAIRE_RENTE("RBR", "Rejet bancaire rente"),
    RELEVE_ANNUEL_DE_SITUATION("RAS", "Releve annuel de situation"),
    RELEVE_DE_SITUATION_INTERMEDIAIRE("RSI", "Releve de situation intermediaire"),
    RELEVE_SPECIFIQUE("RLS", "Releve specifique"),
    REMISE_EN_VIGUEUR("RMVI", "Remise en vigueur"),
    REPORTING_FIRME("RF", "Reporting firme"),
    RESIDENCE_FISCALE("REFI", "Residence fiscale"),
    RESILIATION("RSL", "Resiliation"),
    REVALORISATION_RENTE("REVRE", "Revalorisation rente"),
    REVERSION("RVR", "Reversion"),
    REVISION_DE_RENTE("RERE", "Revision de rente"),
    RELEVE_D_IDENTITE_BANCAIRE("RIB", "RIB"),
    SORTIE_EN_CAPITAL("SC", "Sortie en capital"),
    SPECIFICITE_CONTRAT("SPCT", "Specificite contrat"),
    SUIVI_ANTIBLANCHIMENT("SA", "Suivi antiblanchiment"),
    SUIVI_DU_RETROACTIF("SDRE", "Suivi du retroactif"),
    TARIFICATION("TRF", "Tarification"),
    TRANSFERT("TFT", "Transfert"),
    UTILISATION_DE_L_EXTRANET("UEXT", "Utilisation de l extranet"),
    VERSEMENT_LIBRE("VL", "Versement libre"),

    // Liquidation
    JUSTIFICATIF_ASSURANCE_MALADIE("JASM", "Justificatif assurance maladie"),
    FORMULAIRE_PRELEVEMENTS_SOCIAUX("JFPS", "Formulaire Prélèvements Sociaux"),
    JUSTIFICATIF_RESIDENCE_FISCALE_ETRANGERE("JRFE", "Justificatif résidence fiscale étrangère"),
    LIVRET_DE_FAMILLE("LVRT", "Livret de famille"),
    ACTE_DE_NAISSANCE("ACNA", "Acte de naissance"),
    NOTIFICATION_SECURITE_SOCIALE("NSS", "Notification Sécurité Sociale"),
    JUSTIFICATIF_AUTRE("NR", "Non renseigné");

    private final String code;
    private final String libelle;
    private final String encodage;

    private CodeTypePieceJointeWorkflowEnum(final String code, final String libelle) {
        this(code, libelle, "base64");
    }

    private CodeTypePieceJointeWorkflowEnum(final String code, final String libelle,
                                            final String encodage) {
        this.code = code;
        this.libelle = libelle;
        this.encodage = encodage;
    }

    public String getCode() {
        return code;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getEncodage() {
        return encodage;
    }

    public static CodeTypePieceJointeWorkflowEnum fromCode(@Nonnull final String code) {
        for (CodeTypePieceJointeWorkflowEnum item : CodeTypePieceJointeWorkflowEnum.values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }
        throw new UnknownEnumerationValueException(CodeTypePieceJointeWorkflowEnum.class,
                "code=\"" + code + "\" non recensé.");
    }

    public static CodeTypePieceJointeWorkflowEnum fromLibelle(@Nonnull final String libelle) {
        for (CodeTypePieceJointeWorkflowEnum item : CodeTypePieceJointeWorkflowEnum.values()) {
            if (item.getLibelle().equals(libelle)) {
                return item;
            }
        }
        throw new UnknownEnumerationValueException(CodeTypePieceJointeWorkflowEnum.class,
                "libelle=\"" + libelle + "\"' non recensé.");
    }
}
