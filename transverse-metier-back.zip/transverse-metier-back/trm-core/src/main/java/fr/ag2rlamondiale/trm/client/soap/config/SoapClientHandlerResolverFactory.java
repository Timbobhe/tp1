package fr.ag2rlamondiale.trm.client.soap.config;

import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Component;

@Component
public class SoapClientHandlerResolverFactory {

    @Lookup // Overridden by spring
    public SoapClientHandlerResolver createSoapClientHandlerResolver() {
        return null;
    }
}
