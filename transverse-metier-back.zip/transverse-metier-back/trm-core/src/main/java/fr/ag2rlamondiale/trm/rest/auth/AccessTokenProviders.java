package fr.ag2rlamondiale.trm.rest.auth;

import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class AccessTokenProviders {

    @Autowired
    private Collection<IAccessTokenProvider> providers;

    public IAccessTokenProvider findAccessTokenProvider(AccessTokenType accessTokenType) {
        return providers.stream()
                .filter(e -> accessTokenType.equals(e.getAccessTokenType()))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(accessTokenType + " : pas de provider trouve"));
    }

    public String getAccessToken(PfsRestServiceConfig pfsRestServiceConfig) {
        final IAccessTokenProvider accessTokenProvider = findAccessTokenProvider(pfsRestServiceConfig.getAccessTokenType());
        return accessTokenProvider.getAccessToken(pfsRestServiceConfig);
    }

}
