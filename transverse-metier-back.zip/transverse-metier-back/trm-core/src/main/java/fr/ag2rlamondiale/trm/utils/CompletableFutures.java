package fr.ag2rlamondiale.trm.utils;

import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class CompletableFutures {

    private CompletableFutures() {

    }

    public static void join(Collection<CompletableFuture<?>> futures) {
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
    }
}
