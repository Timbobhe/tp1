package fr.ag2rlamondiale.trm.utils;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import fr.ag2rlamondiale.trm.domain.constantes.Constantes;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Nullable;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

/**
 * Classe permettant de convertir les Date au format dd/MM/yyyy au moment de la sérialization JSON
 */
@Slf4j
@SuppressWarnings("serial")
public class DateUtils extends StdSerializer<Date> {
    public DateUtils() {
        this(null);
    }

    public DateUtils(Class<Date> t) {
        super(t);
    }

    @Override
    public void serialize(Date date, JsonGenerator jsonGenerator,
                          SerializerProvider serializerProvider) throws IOException {
        SimpleDateFormat sdf = dateFormat(Constantes.DEFAULT_DATE_FORMAT);
        jsonGenerator.writeString(sdf.format(date));
    }

    /**
     * Méthode permettant de créer un objet Date
     *
     * @param d le jour du mois
     * @param m le numéro de mois (janvier = 1)
     * @param y l'année
     * @return une Date
     */
    public static Date createDate(int d, int m, int y) {
        GregorianCalendar cal = new GregorianCalendar();
        cal.set(Calendar.MONTH, m - 1);
        cal.set(Calendar.YEAR, y);
        cal.set(Calendar.DAY_OF_MONTH, d);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    /**
     * Verifie si une personne avec la date de naissance donnee en parametre est majeure à la date
     * du jour
     *
     * @param dateNaissance la date de naissance
     * @return true si la personne est majeure, faux sinon.
     */
    public static boolean estMajeur(Date dateNaissance) {
        if (dateNaissance != null) {
            GregorianCalendar dateJourCal = new GregorianCalendar();
            dateJourCal.setTime(new Date());
            int backInTime = dateJourCal.get(Calendar.YEAR) - 18;
            dateJourCal.set(Calendar.YEAR, backInTime);

            return !dateNaissance.after(dateJourCal.getTime());
        }
        return true;
    }

    /**
     * Créer une date sans heure.
     *
     * @param dateString en format (dd/MM/yyyy)
     * @return date
     */
    public static Date createTimelessDate(String dateString) {
        SimpleDateFormat sdf = dateFormat(Constantes.DEFAULT_DATE_FORMAT);
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
            log.info(e.getMessage());
        }
        return null;
    }

    @Nullable
    public static Date getDateOrNull(@Nullable XMLGregorianCalendar xmlGregorianCalendar) {
        if (xmlGregorianCalendar == null) {
            return null;
        }
        return xmlGregorianCalendar.toGregorianCalendar().getTime();
    }

    @Nullable
    public static XMLGregorianCalendar dateTimeToXmlCalendar(@Nullable Date date) {
        if (date == null) {
            return null;
        }
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.setTime(date);
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
        } catch (DatatypeConfigurationException ex) {
            throw new RuntimeException(ex);
        }
    }

    @Nullable
    public static XMLGregorianCalendar dateToXmlCalendar(@Nullable Date date) {
        if (date == null) {
            return null;
        }
        GregorianCalendar gregorianCalendar = new GregorianCalendar();
        gregorianCalendar.setTime(date);
        try {
            XMLGregorianCalendar xmlDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            xmlDate.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED,
                    DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
            return xmlDate;
        } catch (DatatypeConfigurationException ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * @param dateString
     * @param format
     * @return
     */
    public static Date parseDate(String dateString, String format) {
        try {
            return dateFormat(format).parse(dateString);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * @param format
     * @return
     */
    private static final SimpleDateFormat dateFormat(String format) {
        return new SimpleDateFormat(format);
    }

    /**
     * @param unixTime
     * @return Date
     */

    public static Date getDateFromUnixTime(String unixTime) {
        Date date = new Date();
        try {
            date.setTime(Long.valueOf(unixTime));
        } catch (NumberFormatException e) {
            log.warn("erreur lors du formatage de date");
        }
        return date;
    }

    public static String dateToString(Date date) {
        return dateToStringByformat(date, "dd/MM/yyyy");
    }

    public static String dateToStringByformat(Date date, String pattern) {
        DateFormat formatter = new SimpleDateFormat(pattern, Locale.FRANCE);
        return formatter.format(date);
    }

    public static Date stringToDate(String date) {
        return stringToDateByFormat(date, "dd/MM/yyyy");
    }

    public static Date stringToDateByFormat(String date, String pattern) {
        if (date == null) {
            return null;
        }

        try {
            DateFormat formatter = new SimpleDateFormat(pattern);
            return formatter.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    public static Date getTodayTimelessDate() {
        LocalDate localDate = LocalDate.now();
        Calendar.Builder calendarBuilder = new Calendar.Builder();
        calendarBuilder.setDate(localDate.getYear(), localDate.getMonth().getValue() - 1, localDate.getDayOfMonth());
        Calendar calendar = calendarBuilder.build();
        return calendar.getTime();
    }

    public static Date todayMoreDays(int numberOfDays) {
        final Instant instant = getTodayTimelessDate().toInstant().plus(numberOfDays, ChronoUnit.DAYS);
        return Date.from(instant);
    }
}
