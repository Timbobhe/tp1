package fr.ag2rlamondiale.trm.profile;

import fr.ag2rlamondiale.trm.domain.CodeActionType;

import java.lang.annotation.*;

/**
 * to calculate the execution time of a method
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Inherited
@Documented
public @interface ProfileExecution {
    CodeActionType codeAction();
}
