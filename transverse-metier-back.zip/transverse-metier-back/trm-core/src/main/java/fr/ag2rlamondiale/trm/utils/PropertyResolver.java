package fr.ag2rlamondiale.trm.utils;

import com.google.common.base.Splitter;
import org.springframework.context.EmbeddedValueResolverAware;
import org.springframework.stereotype.Service;
import org.springframework.util.StringValueResolver;

import java.util.List;

@Service
public class PropertyResolver implements EmbeddedValueResolverAware {
    private StringValueResolver stringValueResolver;

    public String findProperty(String propertyName) {
        final String strVal;
        if (propertyName.startsWith("${") && propertyName.endsWith("}")) {
            strVal = propertyName;
        } else {
            strVal = "${" + propertyName + "}";
        }

        try {
            final String evaluated = stringValueResolver.resolveStringValue(strVal);
            if (evaluated != null && (!evaluated.equals(strVal) || !evaluated.contains("${"))) {
                return evaluated;
            }
        } catch (IllegalArgumentException ignore) {
            // ignore
        }
        return null;
    }

    public List<String> findPropertyList(String propertyName) {
        final String property = findProperty(propertyName);
        if (property == null) {
            return null;
        }

        return Splitter.on(',').omitEmptyStrings().trimResults().splitToList(property);
    }


    @Override
    public void setEmbeddedValueResolver(StringValueResolver stringValueResolver) {
        this.stringValueResolver = stringValueResolver;
    }
}
