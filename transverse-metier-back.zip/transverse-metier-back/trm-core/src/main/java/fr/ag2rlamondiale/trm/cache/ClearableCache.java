package fr.ag2rlamondiale.trm.cache;

public interface ClearableCache {

    void clearCache();
}
