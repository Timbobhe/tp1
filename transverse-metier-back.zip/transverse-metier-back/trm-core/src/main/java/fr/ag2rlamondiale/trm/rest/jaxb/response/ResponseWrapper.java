package fr.ag2rlamondiale.trm.rest.jaxb.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.trm.rest.AbstractResponseWrapper;
import lombok.Data;

import java.util.function.Consumer;

@Data
public class ResponseWrapper<T> implements AbstractResponseWrapper<T> {
    @JsonProperty("Response")
    private Response<T> response;

    public void handleError(Consumer<Header> consumer) {
        if (response != null && response.getHeader() != null && response.getHeader().getErrorMessage() != null) {
            consumer.accept(response.getHeader());
        }

        if (response == null || response.getBody() == null) {
            Header header = Header.empty("Pas de BODY");
            if (response != null && response.getHeader() != null) {
                header = response.getHeader();
            }
            consumer.accept(header);
        }
    }

    @Override
    public T getResponseBody() {
        return response.getBody();
    }
}
