package fr.ag2rlamondiale.trm.rest.auth;

import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PfsTokenBuilder {
    private static final String CODE_PFS = "A0487";
    private static final String SOURCE = "ESP_CLIENT";
    private static final int JWT_TOKEN_VALIDITY = 1000 * 60 * 60 * 2;
    private static final int JWT_TOKEN_START_VALIDITY = 60 * 5;

    @Setter
    @Autowired
    private PropertyResolver propertyResolver;

    @Setter
    @Getter
    @Value("${pfs.token.private.key.password}")
    private String privateKeyName;

    public String generateToken(PfsTokenClaims pfsTokenClaims, PfsRestServiceConfig pfsRestServiceConfig) {
        return getToken(pfsTokenClaims, findToken(pfsRestServiceConfig));
    }

    private String getToken(PfsTokenClaims pfsTokenClaims, String token) {
        Date expirationDate = new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY);
        Date startDate = new Date(System.currentTimeMillis() - JWT_TOKEN_START_VALIDITY);
        final String codeCassiniAppli = pfsTokenClaims.getCodeCassiniAppli();


        return JwtTokenUtils.createBearerToken(getClaims(pfsTokenClaims), expirationDate, StringUtils.EMPTY, CODE_PFS, codeCassiniAppli, startDate, token);
    }

    private Map<String, Object> getClaims(PfsTokenClaims pfsTokenClaims) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("source", SOURCE);
        if (pfsTokenClaims.getIdGdi() != null) {
            claims.put("iss_profileid_idfid", "1");
            claims.put("iss_profileid_lblogidn", pfsTokenClaims.getIdGdi());
        } else if (pfsTokenClaims.getCodePartenaire() != null) {
            claims.put("iss_profileid_idfid", pfsTokenClaims.getCodePartenaire());
            claims.put("iss_profileid_lblogidn", "1");
        }
        return claims;
    }

    public String findToken(PfsRestServiceConfig pfsRestServiceConfig) {
        if (pfsRestServiceConfig == null || pfsRestServiceConfig.getServiceId() == null) throw new AssertionError();
        return getToken(pfsRestServiceConfig);
    }

    private String getToken(PfsRestServiceConfig pfsRestServiceConfig) {
        final String s = pfsRestServiceConfig.getServiceId();
        final String alternative = "pfs." + s.replace('/', '.') + ".token";
        List<String> keys = Arrays.asList(alternative, pfsRestServiceConfig.getAlternativeAccessToken());
        for (String key : keys) {
            if (key != null && !key.isEmpty()) {
                final String evaluated = propertyResolver.findProperty(key);
                if (evaluated != null) {
                    return evaluated;
                }
            }
        }

        return privateKeyName;
    }
}
