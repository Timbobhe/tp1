package fr.ag2rlamondiale.trm.demo;

import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.soap.PortInitializer;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.trm.utils.UrlUtils.assembleUrl;

@Slf4j
@Service
public class CompteDemoEndpointResolver implements InitializingBean, ICompteDemoEndpointResolver {

    @Getter
    @Setter
    @Value("#{consoleProps.demoActive}")
    private boolean demoActive;


    @Getter
    @Setter
    @Value("#{consoleProps.consoleV2ApiUrl}/demo")
    private String prefixUrlDemoApiConsole;


    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public String getUrl(PortInitializer portInitializer) {
        if (!demoActive) {
            return null;
        }

        final UserContext userContext = userContextHolder.get();
        boolean compteDemo = userContext.isCompteDemo();
        if (compteDemo) {
            return getUrl(portInitializer.serviceId(), userContext.getCompteDemo());
        }

        return null;
    }

//    public String getUrl(PfsRestService pfsRestService) {
//        if (!demoActive) {
//            return null;
//        }
//
//        final UserContext userContext = userContextHolder.get();
//        boolean compteDemo = userContext.isCompteDemo();
//        if (compteDemo) {
//            return getUrl(pfsRestService.serviceId(), userContext.getCompteDemo());
//        }
//        return null;
//    }
//
//    public String getUrl(PfsRestServiceSwagger pfsRestServiceSwagger) {
//        if (!demoActive) {
//            return null;
//        }
//
//        final UserContext userContext = userContextHolder.get();
//        boolean compteDemo = userContext.isCompteDemo();
//        if (compteDemo) {
//            return getUrl(pfsRestServiceSwagger.serviceId(), userContext.getCompteDemo());
//        }
//        return null;
//    }


    @Override
    public String getUrl(String serviceId) {
        if (!demoActive) {
            return null;
        }

        final UserContext userContext = userContextHolder.get();
        boolean compteDemo = userContext.isCompteDemo();
        if (compteDemo) {
            return getUrl(serviceId, userContext.getCompteDemo());
        }
        return null;
    }

    @Override
    public String getUrl(String serviceId, CompteDemo compteDemo) {
        return assembleUrl(prefixUrlDemoApiConsole, serviceId) + "?cdm=" + compteDemo.getIdCompteDemo();
    }

    @Override
    public void afterPropertiesSet() {
        if (demoActive && prefixUrlDemoApiConsole == null) {
            throw new IllegalStateException("Pour utiliser la fonctionnalité DEMO (demo.active=true) il faut aussi renseigner la property \"consolev2.api.url\"");
        }
    }
}
