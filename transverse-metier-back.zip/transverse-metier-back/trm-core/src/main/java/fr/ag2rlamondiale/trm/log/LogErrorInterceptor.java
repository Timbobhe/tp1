package fr.ag2rlamondiale.trm.log;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.Arrays;

@Slf4j
@Aspect
@Component
public class LogErrorInterceptor implements Ordered {

    @AfterThrowing(pointcut = "@annotation(logError)", throwing = "excep")
    public Object afterThrowingAdvice(JoinPoint joinPoint, Throwable excep, LogError logError) throws Throwable /*NOSONAR*/ {
        Signature signature = joinPoint.getSignature();
        String argsString = "";
        if (joinPoint.getArgs() != null && joinPoint.getArgs().length > 0) {
            argsString = Arrays.toString(joinPoint.getArgs());
        }
        log.error("Erreur lors de l'appel {} [{}] {}({}) => {}", logError.category(),
                signature.getDeclaringType().getSimpleName(), signature.getName(), argsString, buildErrorMessage(excep));

        throw excep;
    }

    private String buildErrorMessage(Throwable excep) {
        Throwable src = ExceptionUtils.getRootCause(excep);
        if (src == null) {
            src = excep;
        }

        return src.getClass() + " : " + src.getMessage();
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.LOG_ERROR_ORDER;
    }
}
