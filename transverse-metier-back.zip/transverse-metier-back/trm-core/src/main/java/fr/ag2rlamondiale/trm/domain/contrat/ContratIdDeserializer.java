package fr.ag2rlamondiale.trm.domain.contrat;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;

import java.io.IOException;

public class ContratIdDeserializer extends StdDeserializer<ContratId> {

    public ContratIdDeserializer() {
        this(null);
    }

    public ContratIdDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public ContratId deserialize(JsonParser jp, DeserializationContext ctx) throws IOException {
        JsonNode node = jp.getCodec().readTree(jp);
        String codeSilo = nodeText("codeSilo", node);
        String nomContrat = nodeText("nomContrat", node);
        String idAdherente = nodeText("idAdherente", node);
        String idContractante = nodeText("idContractante", node);
        String idCollege = nodeText("idCollege", node);
        if (CodeSiloType.ERE.name().equals(codeSilo)) {
            return ContratId.ere(nomContrat, idAdherente, idContractante, idCollege);
        } else if (CodeSiloType.MDP.name().equals(codeSilo)) {
            return ContratId.mdpro(nomContrat);
        } else {
            throw new IllegalArgumentException("silo inconnu, " + codeSilo);
        }
    }

    private String nodeText(String fieldName, JsonNode node) {
        final JsonNode n = node.get(fieldName);
        if (n == null) {
            return null;
        }

        final String text = n.asText();
        if (text.equalsIgnoreCase("null")) {
            return null;
        }

        return text;
    }
}
