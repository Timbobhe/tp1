package fr.ag2rlamondiale.trm.utils;

import java.util.function.Supplier;

public class Memoizer<T> {

    private T value;

    private Supplier<T> supplier;

    public Memoizer(Supplier<T> supplier) {
        super();
        this.supplier = supplier;
    }

    public T getValue() {
        if (value == null) {
            this.value = this.supplier.get();
        }
        return value;
    }
}
