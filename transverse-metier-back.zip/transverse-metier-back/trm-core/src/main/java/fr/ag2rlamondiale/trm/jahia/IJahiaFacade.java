package fr.ag2rlamondiale.trm.jahia;

import com.fasterxml.jackson.databind.JsonNode;
import fr.ag2rlamondiale.trm.domain.document.DictionaryKeyType;

import java.io.IOException;

public interface IJahiaFacade {

    JsonNode findDictionary(DictionaryKeyType dictionaryKeyType) throws IOException;

    String findDictionaryEntry(DictionaryKeyType dictionaryKeyType, String key) throws IOException;

    boolean dictionaryContainsEntry(DictionaryKeyType dictionaryKeyType, String key) throws IOException;

    String findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType dictionaryKeyType, String numContrat, String codeFiliale) throws IOException;

    String locateDocument(String documentType, String numContrat);

    byte[] getDocument(String documentPath) throws IOException;

    String getExistingFileName(String pathAQE, String extension, String numContrat, String codeFiliale);

    String getLastModified(String documentLocation) throws IOException;
}
