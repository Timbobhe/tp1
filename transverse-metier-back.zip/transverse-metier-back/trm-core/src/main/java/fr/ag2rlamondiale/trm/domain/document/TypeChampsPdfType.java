package fr.ag2rlamondiale.trm.domain.document;

public enum TypeChampsPdfType {
    TEXT("Text"),
    TEXT_LB("Text_LB"),
    CHECKBOX("Checkbox"),
    GRAPHE("GRAPHE"),
    LOGO("LOGO"),
    QRCODE("QRCODE"),
    HTML("HTML");

    private final String valeur;

    TypeChampsPdfType(String valeur) {
        this.valeur = valeur;
    }

    public String getValeur() {
        return this.valeur;
    }
}
