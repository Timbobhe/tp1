package fr.ag2rlamondiale.trm.thread;

import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.slf4j.MDC;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class CustomFutureTask<T> extends FutureTask<T> {

    private RequestAttributes attributes;
    private UserContext userContext;
    private String idReq;
    private String idUser;


    public CustomFutureTask(Runnable command) {
        super(command, null);
        this.attributes = RequestContextHolder.getRequestAttributes();
        this.userContext = UserContextHolder.getUserContext();
        this.idReq = MDC.get(FrmkLogKeys.IDENTIFIANT_REQUETE);
        this.idUser = MDC.get(FrmkLogKeys.IDENTIFIANT_UTILISATEUR);
    }

    public CustomFutureTask(Callable<T> callable) {
        super(callable);
        this.attributes = RequestContextHolder.getRequestAttributes();
        this.userContext = UserContextHolder.getUserContext();
        this.idReq = MDC.get(FrmkLogKeys.IDENTIFIANT_REQUETE);
        this.idUser = MDC.get(FrmkLogKeys.IDENTIFIANT_UTILISATEUR);
    }

    @Override
    public void run() {
        if (attributes != null) {
            RequestContextHolder.setRequestAttributes(attributes);
        }
        if (userContext != null) {
            UserContextHolder.setUserContext(userContext);
        }

        if (idReq != null) {
            MDC.put(FrmkLogKeys.IDENTIFIANT_REQUETE, idReq);
        }

        if (idUser != null) {
            MDC.put(FrmkLogKeys.IDENTIFIANT_UTILISATEUR, idUser);
        }


        try {
            super.run();
        } finally {
            RequestContextHolder.resetRequestAttributes();
            UserContextHolder.reset();
        }
    }

}
