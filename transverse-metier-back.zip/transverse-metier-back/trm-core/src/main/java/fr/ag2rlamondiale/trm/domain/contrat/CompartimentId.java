package fr.ag2rlamondiale.trm.domain.contrat;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompartimentId implements ISecurityParamAccess {
    private String idAssure;
    private String nomContrat;
    private CompartimentType compartimentType;

    public static CompartimentId ere(String idAssure, CompartimentType compartimentType) {
        return CompartimentId.builder()
                .idAssure(idAssure)
                .compartimentType(compartimentType)
                .build();
    }

    public static CompartimentId mdpro(String nomContrat, CompartimentType compartimentType) {
        return CompartimentId.builder()
                .nomContrat(nomContrat)
                .compartimentType(compartimentType)
                .build();
    }

    public CompartimentId clean(CodeSiloType codeSiloType) {
        if (CodeSiloType.ERE.equals(codeSiloType)) {
            return idAssure != null && compartimentType != null ? ere(idAssure, compartimentType) : null;
        } else if (CodeSiloType.MDP.equals(codeSiloType)) {
            return nomContrat != null && compartimentType != null ? mdpro(nomContrat, compartimentType) : null;
        }

        throw new IllegalArgumentException(codeSiloType + " non géré");
    }

    @Override
    public String secureForNumContrat() {
        return this.nomContrat;
    }

    @Override
    public String secureForIdentifiantAssure() {
        return this.idAssure;
    }
}
