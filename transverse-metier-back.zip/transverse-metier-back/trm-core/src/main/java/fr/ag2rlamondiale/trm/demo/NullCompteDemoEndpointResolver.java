package fr.ag2rlamondiale.trm.demo;

import fr.ag2rlamondiale.trm.soap.PortInitializer;

public class NullCompteDemoEndpointResolver implements ICompteDemoEndpointResolver {

    public static final NullCompteDemoEndpointResolver instance = new NullCompteDemoEndpointResolver();

    @Override
    public String getUrl(PortInitializer portInitializer) {
        return null;
    }

    @Override
    public String getUrl(String serviceId) {
        return null;
    }

    @Override
    public String getUrl(String serviceId, CompteDemo compteDemo) {
        return null;
    }

    @Override
    public boolean isDemoActive() {
        return false;
    }
}
