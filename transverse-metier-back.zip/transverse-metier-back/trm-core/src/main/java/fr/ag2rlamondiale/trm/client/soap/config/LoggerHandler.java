package fr.ag2rlamondiale.trm.client.soap.config;

import fr.ag2rlamondiale.trm.utils.LimitByteArrayOutputStream;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Nullable;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.IOException;
import java.util.Collections;
import java.util.Set;

/**
 * Handler permettant de logger le message SOAP en entrée et en sortie
 */
@Slf4j
public class LoggerHandler extends CommonHandler implements SOAPHandler<SOAPMessageContext> {

    private boolean enableLog = true;

    public LoggerHandler() {
        this(-1, true);
    }

    public LoggerHandler(int maxChars, boolean enableLog) {
        super(maxChars);
        this.enableLog = enableLog;
    }

    @Override
    public boolean handleMessage(SOAPMessageContext smc) {
        // Propriete permettant de savoir s il s agit de la requete ou de la reponse
        final boolean isRequest = Boolean.TRUE.equals(smc.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY));
        String serviceType = isRequest ? "REQUEST" : "RESPONSE";

        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        final String enpoint = soapRequestContext != null ? soapRequestContext.getEndpoint() : null;
        final Object arg = soapRequestContext != null ? soapRequestContext.getArg() : null;
        final boolean forceLogBody = soapRequestContext != null && soapRequestContext.isForceLogBody();

        try {
            if (log.isDebugEnabled()) {
                final String str = getMessageBody(smc, isRequest);

                // On loggue l appel
                log.debug("{} SOAP(#{}) {} {}\t{}", serviceType, Thread.currentThread().getId(), enpoint, arg, str);

            } else if (log.isInfoEnabled()) {
                if (isRequest || forceLogBody) {
                    final String str = getMessageBody(smc, isRequest);
                    log.info("{} SOAP(#{}) {} {}\t{}", serviceType, Thread.currentThread().getId(), enpoint, arg, str);
                } else {
                    log.info("{} SOAP(#{}) {} {}", serviceType, Thread.currentThread().getId(), enpoint, arg);
                }
            }
        } catch (Exception ex) {
            log.error("Exception lors de la gestion du message", ex);
        }

        return true;
    }

    @Nullable
    public String getMessageBody(SOAPMessageContext smc, boolean isRequest) throws IOException {
        if (!enableLog && isRequest) {
            return "$$$NOLOG$$$";
        }

        // On recupere l appel en chaine de caractere

        try (LimitByteArrayOutputStream out = new LimitByteArrayOutputStream(maxChars, "...", true)) {
            try {
                smc.getMessage().writeTo(out);
            } catch (LimitByteArrayOutputStream.LimitReachedException | SOAPException | IOException ignore) {
                // ignore
            }

            return out.toString();
        }

    }


    @Override
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }

    @Override
    public void close(MessageContext context) {
        /* Implémentation obligatoire mais pas d'actions à effectuer */
    }
}
