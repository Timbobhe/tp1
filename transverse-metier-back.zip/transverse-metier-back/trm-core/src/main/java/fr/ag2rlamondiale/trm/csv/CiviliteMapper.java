package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class CiviliteMapper extends AbstractCsvMapper<String> {

    public CiviliteMapper() {
        super("csv/libelles_civilite.csv");
    }
}
