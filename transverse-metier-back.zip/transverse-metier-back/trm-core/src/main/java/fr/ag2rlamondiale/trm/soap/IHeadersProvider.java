package fr.ag2rlamondiale.trm.soap;

public interface IHeadersProvider {

    Object buildHeader();
}
