package fr.ag2rlamondiale.trm.rest.auth;

import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;

public interface IAccessTokenProvider {

    String getAccessToken(PfsRestServiceConfig pfsRestServiceConfig);

    AccessTokenType getAccessTokenType();
}
