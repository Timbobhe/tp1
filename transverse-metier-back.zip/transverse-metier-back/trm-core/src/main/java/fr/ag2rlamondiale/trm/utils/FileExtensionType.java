package fr.ag2rlamondiale.trm.utils;

public enum FileExtensionType {
    JPEG("jpeg"),

    JPG("jpg"),

    PNG("png"),

    GIF("gif"),

    TIFF("tiff"),

    TIF("tif"),

    BMP("bmp"),

    PDF("pdf");

    private String extensionStr;

    FileExtensionType(String extensionStr) {
        this.extensionStr = extensionStr;
    }

    public static FileExtensionType fromString(String extStr) {
        if (extStr == null) {
            return null;
        }
        for (FileExtensionType ext : FileExtensionType.values()) {
            if (ext.getStringValue().equalsIgnoreCase(extStr)) {
                return ext;
            }
        }
        throw new IllegalArgumentException("Le format pass\u00e9 en param\u00e8tre [" + extStr
                + "] n'est pas un FileExtensionType valide.");
    }

    public String getStringValue() {
        return extensionStr;
    }
}
