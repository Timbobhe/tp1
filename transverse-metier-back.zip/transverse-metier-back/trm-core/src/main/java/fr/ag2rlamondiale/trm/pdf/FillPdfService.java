package fr.ag2rlamondiale.trm.pdf;

import fr.ag2rlamondiale.trm.domain.document.ChampsPDFInfo;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

public interface FillPdfService {

    default void fillPdfForm(byte[] documentBytes, OutputStream documentOutputStream,
                             Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle, boolean isNeedAppearances)
            throws DocumentException, IOException {
        try (ByteArrayInputStream documentAsStream = new ByteArrayInputStream(documentBytes)) {
            this.fillPdfForm(documentAsStream, documentOutputStream, formFieldsValues, bodyStyle, isNeedAppearances);
        }
    }

    void fillPdfForm(InputStream documentInputStream, OutputStream documentOutputStream,
                     Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle, boolean isNeedAppearances)
            throws DocumentException, IOException;

    default void fillPdfForm(byte[] documentBytes, OutputStream documentOutputStream,
                             Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle) throws DocumentException, IOException {
        try (ByteArrayInputStream documentAsStream = new ByteArrayInputStream(documentBytes)) {
            this.fillPdfForm(documentAsStream, documentOutputStream, formFieldsValues, bodyStyle);
        }
    }

    void fillPdfForm(InputStream documentInputStream, OutputStream documentOutputStream,
                     Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle) throws DocumentException, IOException;
}
