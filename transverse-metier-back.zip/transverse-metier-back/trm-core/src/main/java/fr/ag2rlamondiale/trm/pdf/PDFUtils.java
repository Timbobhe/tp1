package fr.ag2rlamondiale.trm.pdf;

import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codecimpl.TIFFImageDecoder;
import fr.ag2rlamondiale.trm.utils.FileExtensionType;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.JPEGFactory;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.media.jai.PlanarImage;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import static org.apache.commons.io.FilenameUtils.getExtension;

@Slf4j
@Component
public class PDFUtils {
    private static final String MESSAGE_ERROR = "IOException to convert Image {}";

    public byte[] convertToPDF(String fileName, byte[] fileContent) throws PDFException {
        final FileExtensionType extension;
        try {
            extension = FileExtensionType.fromString(getExtension(fileName));
        } catch (Exception e) {
            throw new PDFException(e);
        }

        return convertToPDF(extension, fileContent);
    }


    /**
     * @param content contenu PDF encodé en Base64
     * @return
     */
    public static byte[] convertPdfContent(String content) {
        return Base64.getDecoder().decode(content);
    }


    public static String encodeToString(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    /**
     * Merge fichiers PDF.
     *
     * @param piecesJointes
     * @return
     */
    public byte[] mergeFiles(final List<String> piecesJointes) throws PDFException {
        PDFMergerUtility merging = new PDFMergerUtility();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            for (String doc : piecesJointes) {
                merging.addSource(new ByteArrayInputStream(convertPdfContent(doc)));
            }
            merging.setDestinationStream(bos);
            merging.mergeDocuments(null);
            return bos.toByteArray();
        } catch (Exception e) {
            log.error("Erreur lors du merge des documents", e);
            throw new PDFException(e);
        }
    }

    /**
     * Extension (PDF, TIFF/TIF, JPG/JPEG, PNG, GIF, BMP).
     *
     * @param extension
     * @param fileContent
     * @return
     * @throws Exception
     */
    private byte[] convertToPDF(FileExtensionType extension, byte[] fileContent) throws PDFException {
        if (extension == null) {
            throw new PDFException("extension NULL");
        }

        if (fileContent == null) {
            throw new PDFException("fileContent NULL");
        }

        try (PDDocument document = new PDDocument()) {
            List<PDImageXObject> images = new ArrayList<>();

            switch (extension) {
                case PDF:
                    // Vérifie que le fileContent est vraiment un PDF
                    PDDocument.load(fileContent);
                    return fileContent;

                case TIFF:
                case TIF:
                    for (BufferedImage bufferedImage : extractBufferedImagesFromTiff(
                            new ByteArrayInputStream(fileContent))) {
                        images.add(LosslessFactory.createFromImage(document, bufferedImage));
                    }
                    break;

                case JPG:
                case JPEG:
                    images.add(JPEGFactory.createFromStream(document,
                            new ByteArrayInputStream(fileContent)));
                    break;

                case PNG:
                case GIF:
                case BMP:
                    images.add(LosslessFactory.createFromImage(document,
                            ImageIO.read(new ByteArrayInputStream(fileContent))));
                    break;

                default:
                    throw new IllegalArgumentException(
                            "Le format de l'image pass\u00e9e en param\u00e8tre n'est pas support\u00e9 pour la conversion PDF ("
                                    + extension.getStringValue() + ")");
            }
            writePDFFromImages(document, images);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            document.save(outputStream);
            return outputStream.toByteArray();
        } catch (Exception ex) {
            log.error(MESSAGE_ERROR, ex.getMessage());
            throw new PDFException(ex);
        }
    }

    private void writePDFFromImages(PDDocument document, List<PDImageXObject> images)
            throws IOException {
        for (PDImageXObject img : images) {
            PDPage page = new PDPage(new PDRectangle(img.getWidth(), img.getHeight()));
            document.addPage(page);
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                contentStream.drawImage(img, 0, 0);
            }
        }
    }


    /**
     * Récupérer une BufferedImage à partir d'un tableau de byte (image .tiff)
     *
     * @param is
     * @return BufferedImage
     * @throws IOException
     */
    private static List<BufferedImage> extractBufferedImagesFromTiff(InputStream is)
            throws IOException {
        List<BufferedImage> images = new ArrayList<>();
        try {
            TIFFImageDecoder dec =
                    new TIFFImageDecoder(SeekableStream.wrapInputStream(is, true), null);
            int numPages = dec.getNumPages();
            if (numPages != 0) {
                BufferedImage image;
                for (int i = 0; i < numPages; i++) {
                    image = PlanarImage.wrapRenderedImage(dec.decodeAsRenderedImage(i))
                            .getAsBufferedImage();
                    if (image != null) {
                        images.add(image);
                    }
                }
            }
        } catch (IOException ex) {
            log.error(MESSAGE_ERROR, ex.getMessage());
            throw ex;
        }
        return images;
    }
}
