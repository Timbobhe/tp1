/*
 * Créé le 1 juin 2015. (c) Ag2r, 2007. Tous droits réservés.
 */
package fr.ag2rlamondiale.trm.csv;

import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.Map.Entry;

/**
 * NB: La cle T doit etre declarer dans la classe fille pour la declaration dans EREMapperType
 */
@Slf4j
public abstract class AbstractCsvMapper<V> {

    // On ne stocke pas dans un champs static, Spring n'injecte qu'une seul fois.
    protected final Map<Key, V> values = new HashMap<>();

    // On initialise la map dans le constructeur et non pas a la demande car si les fichiers ne sont
    // pas parser correctement, l'application ne doit pas fonctionner.
    public AbstractCsvMapper(String path) {
        log.info("Chargement du ficher {}", path);

        try (BufferedReader buffer = new BufferedReader(
                new InputStreamReader(new ClassPathResource(path).getInputStream(), StandardCharsets.UTF_8))) {
            String ligne;
            while ((ligne = buffer.readLine()) != null) {
                if (!ligne.trim().isEmpty()) {
                    processLine(ligne);
                }
            }
        } catch (Exception ex) {
            log.error("Erreur lors du chargement du ficher {}", path, ex);
            throw new TechnicalRuntimeException("[AbstractCsvMapper]: Erreur lors du chargement du ficher " + path, ex);
        }
    }

    /**
     * Intepretation par defaut de la ligne.
     *
     * @param line
     */
    @SuppressWarnings({"unchecked", "WeakerAccess"})
    protected void processLine(String line) {
        String[] items = line.split(";");
        String code;
        String lang;
        V value;
        for (int i = 0; i < (items.length - 1) / 2; i++) {
            code = items[0];
            lang = items[1 + 2 * i];
            value = (V) items[2 + 2 * i];
            values.put(getNewKey(code, lang), value);
        }
    }

    @SuppressWarnings("WeakerAccess")
    protected Key getNewKey(String code, String lang) {
        return new Key(code, lang);
    }

    public V getValue(String code, String lang) {
        return this.values.get(new Key(code, lang));
    }

    public V getValueFR(String code) {
        return this.values.get(new Key(code, Locale.FRANCE.getCountry()));
    }

    @NoArgsConstructor
    @AllArgsConstructor
    @Data
    public static class Key {
        private String code;
        private String lang;
    }

    /**
     * Retourne l'ensemble des valeurs triés par ordre alphabétique.
     *
     * @return la liste des valeurs
     */
    public Set<V> getAllValues() {
        return new TreeSet<>(values.values());
    }

    /**
     * Retourne le code pays correspondant à un label pays.
     *
     * @param value label du pays
     * @return le code pays
     */
    public Key getKeyFromValue(V value) {
        if (value != null) {
            for (Entry<Key, V> entry : values.entrySet()) {
                if (value.equals(entry.getValue())) {
                    return entry.getKey();
                }
            }
        }
        return null;
    }
}
