package fr.ag2rlamondiale.trm.csv;

import fr.ag2rlamondiale.trm.domain.csv.CodeAssureurDto;
import org.springframework.stereotype.Component;


@Component
public class CodesAssureurMapper extends AbstractCsvMapper<CodeAssureurDto> {

    public CodesAssureurMapper() {
        super("csv/codes_assureur.csv");
    }

    public CodeAssureurDto getCodesAssureurs(String codeAssureur) {
        return getValue(codeAssureur, null);
    }

    @Override
    protected void processLine(String line) {
        String[] items = line.split(";");
        String code = items[0];
        String numICS = items[1];
        String libelle = items[2];
        String profileSignatureElectronique = items[3];
        values.put(getNewKey(code, null), new CodeAssureurDto(code, numICS, libelle, profileSignatureElectronique));
    }
}
