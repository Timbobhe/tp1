package fr.ag2rlamondiale.trm.domain;

import lombok.Getter;

@Getter
public enum CodeCategorieDocType {
    SPECIFIQUE("S"),
    STANDARD("D"),
    STANDARD_GENERE("E"),
    GENERE("G");

    private final String libelle;

    private CodeCategorieDocType(String libelle) {
        this.libelle = libelle;
    }
}
