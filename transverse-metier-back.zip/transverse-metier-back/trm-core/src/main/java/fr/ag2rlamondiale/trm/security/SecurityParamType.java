package fr.ag2rlamondiale.trm.security;

/**
 * Permet de dire sur <u>quel type de valeur</u> s'appuie la vérification de la sécurité.<br>
 * Le paramètre de la méthode sécurisée doit être du type {@link String} ou {@link ISecurityParamAccess}
 */
public enum SecurityParamType {

    CONTRAT {
        @Override
        public String getSecurityValue(ISecurityParamAccess access) {
            return access.secureForNumContrat();
        }
    }, IDASSURE {
        @Override
        public String getSecurityValue(ISecurityParamAccess access) {
            return access.secureForIdentifiantAssure();
        }
    };

    public abstract String getSecurityValue(ISecurityParamAccess access);
}
