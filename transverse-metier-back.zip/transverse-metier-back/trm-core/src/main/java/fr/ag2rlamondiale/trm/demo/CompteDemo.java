package fr.ag2rlamondiale.trm.demo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CompteDemo {
    private long idCompteDemo;
}
