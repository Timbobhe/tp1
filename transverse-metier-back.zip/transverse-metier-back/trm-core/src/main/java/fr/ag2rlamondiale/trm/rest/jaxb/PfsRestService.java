package fr.ag2rlamondiale.trm.rest.jaxb;

import fr.ag2rlamondiale.trm.rest.auth.AccessTokenType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface PfsRestService {

    String serviceId();

    String alternative() default "";

    /**
     * Chaine de caractères correspondant à une Property, permettant de retrouver le nom de l'accessToken.
     *
     * @return
     */
    String alternativeAccessToken() default "";

    boolean enableLog() default true;

    AccessTokenType accessTokenType() default AccessTokenType.RSA_PRIVATE_KEY;
}
