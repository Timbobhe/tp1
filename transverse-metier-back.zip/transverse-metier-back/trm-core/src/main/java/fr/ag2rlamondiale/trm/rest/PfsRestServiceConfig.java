package fr.ag2rlamondiale.trm.rest;

import fr.ag2rlamondiale.trm.rest.auth.AccessTokenType;
import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestService;
import fr.ag2rlamondiale.trm.rest.swagger.PfsRestServiceSwagger;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PfsRestServiceConfig {
    private String serviceId;
    private String alternative;
    private boolean enableLog;
    @Builder.Default
    private AccessTokenType accessTokenType = AccessTokenType.RSA_PRIVATE_KEY;
    private String alternativeAccessToken;
    @Builder.Default
    private boolean restful = false;

    public static PfsRestServiceConfig from(PfsRestService pfsRestService) {
        return PfsRestServiceConfig.builder()
                .serviceId(pfsRestService.serviceId())
                .alternative(pfsRestService.alternative())
                .enableLog(pfsRestService.enableLog())
                .accessTokenType(pfsRestService.accessTokenType())
                .alternativeAccessToken(pfsRestService.alternativeAccessToken())
                .build();
    }

    public static PfsRestServiceConfig from(PfsRestServiceSwagger pfsRestServiceSwagger) {
        return PfsRestServiceConfig.builder()
                .serviceId(pfsRestServiceSwagger.serviceId())
                .alternative(pfsRestServiceSwagger.alternative())
                .enableLog(pfsRestServiceSwagger.enableLog())
                .accessTokenType(pfsRestServiceSwagger.accessTokenType())
                .alternativeAccessToken(pfsRestServiceSwagger.alternativeAccessToken())
                .restful(pfsRestServiceSwagger.restful())
                .build();
    }
}
