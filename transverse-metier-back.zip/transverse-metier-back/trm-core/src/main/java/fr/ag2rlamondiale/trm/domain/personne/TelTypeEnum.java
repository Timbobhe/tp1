package fr.ag2rlamondiale.trm.domain.personne;

public enum TelTypeEnum {
    TPE("TPE"),

    TPO("TPO"),

    TPR("TPR"),

    TFX("TFX");

    private final String value;

    private TelTypeEnum(String lbl) {
        this.value = lbl;
    }

    public String getValue() {
        return value;
    }
}
