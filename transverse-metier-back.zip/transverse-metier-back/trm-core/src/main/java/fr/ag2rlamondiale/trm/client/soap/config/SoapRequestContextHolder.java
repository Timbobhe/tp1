package fr.ag2rlamondiale.trm.client.soap.config;

/**
 *
 */
public class SoapRequestContextHolder {
    private static final ThreadLocal<SoapRequestContext> REQUEST_CONTEXT = new InheritableThreadLocal<>();

    private SoapRequestContextHolder() {}

    public static void set(SoapRequestContext requestContext) {
        REQUEST_CONTEXT.set(requestContext);
    }

    public static SoapRequestContext get() {
        return REQUEST_CONTEXT.get();
    }

    public static void clean() {
        REQUEST_CONTEXT.remove();
    }
}
