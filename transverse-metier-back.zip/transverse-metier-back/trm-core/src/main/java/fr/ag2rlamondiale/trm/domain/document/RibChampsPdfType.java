package fr.ag2rlamondiale.trm.domain.document;

import lombok.Getter;

@Getter
public enum RibChampsPdfType implements ToChampsPDFInfo {
    CODE_IBAN("IBAN"),
    CODE_BIC("codeBIC"),
    TITULAIRE_COMPTE("Titulaire_Compte"),
    SEPA_ADRESSE_1("SEPA_Adresse_1"),
    SEPA_ADRESSE_2("SEPA_Adresse_2"),
    SEPA_ADRESSE_3("SEPA_Adresse_3"),
    SEPA_ADRESSE_PAIEMENT("SEPA_Adresse_Paiement", TypeChampsPdfType.TEXT_LB),
    EXTENSION_TITLE("extension_title_modif_contrats"),
    EXTENSION("extension_modif_contrats");


    private final String champs;
    private final boolean readOnly;
    private final TypeChampsPdfType type;

    RibChampsPdfType(String champs) {
        this(champs, TypeChampsPdfType.TEXT);
    }

    RibChampsPdfType(String champs, TypeChampsPdfType type) {
        this.champs = champs;
        this.type = type;
        this.readOnly = true;
    }

    public static RibChampsPdfType fromString(String text) {
        if (text != null) {
            for (RibChampsPdfType element : RibChampsPdfType.values()) {
                if (element.getChamps().equalsIgnoreCase(text)) {
                    return element;
                }
            }
        }
        return null;
    }
}
