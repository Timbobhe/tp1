package fr.ag2rlamondiale.trm.utils;

import fr.ag2rlamondiale.trm.client.soap.config.SecurityHeaderInfo;
import lombok.Getter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Getter
@Component
public class SecurityServiceConfig implements InitializingBean {
    @Value("${ere.mapper.header.token.ged}")
    private String tokenGED; // ERE/MDPRO

    @Value("${ere.mapper.header.token.sharepoint.ere}")
    private String tokenSharepointEre;

    @Value("${ere.mapper.header.token.sharepoint.mdpro}")
    private String tokenSharepointMdPro;

    private Map<String, SecurityHeaderInfo> securityHeaderInfoMap;

    @Value("${ere.mapper.security.mandat.header.login}")
    private String loginMandat;

    @Value("${ere.mapper.security.mandat.header.password}")
    private String passwordMandat;

    @Value("${ere.mapper.security.mandat.header.application}")
    private String securityHeaderCodeApplicationMandat;

    @Override
    public void afterPropertiesSet() {
        securityHeaderInfoMap = new HashMap<>(1);
        securityHeaderInfoMap.put("mandat", new SecurityHeaderInfo(loginMandat, passwordMandat, securityHeaderCodeApplicationMandat));
    }

    public SecurityHeaderInfo getSecurityHeaderInfo(String codeService){
        return securityHeaderInfoMap.get(codeService);
    }
}
