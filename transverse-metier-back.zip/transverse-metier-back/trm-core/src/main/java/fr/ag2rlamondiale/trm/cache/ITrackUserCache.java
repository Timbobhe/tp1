package fr.ag2rlamondiale.trm.cache;

import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.web.session.HttpSessionDestroyedEvent;

import java.lang.reflect.Method;

public interface ITrackUserCache {

    void trackUserCache(Object target, Method method, Object[] params);

    void clearUserCache(String idGdi);

    void migrateTrackUserCache(String idGdiSource, String idGdiCible);

    @Scheduled(fixedRateString = "${cache.concurrent.cleaning.fixedRate:1800000}") // 30min
    void cleanUserCacheEntries();

    void handleSessionDestroyed(HttpSessionDestroyedEvent event);
}
