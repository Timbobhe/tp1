/*
 * Cree le 13 sept. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.security;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * Authentification Class
 */
@Slf4j
public class AuthentificationUtils {
    public static final String NO_ATH_USER_MSG = "Aucun utilisateur n'est identifie";

    private AuthentificationUtils() {
    }

    public static boolean hasRole(UserDetails userDetails, RolesEnum role) {
        if (userDetails != null) {
            for (GrantedAuthority authority : userDetails.getAuthorities()) {
                if (authority != null && authority.getAuthority().equals(role.getCompleteRoleName())) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isUserImpersonated(UserDetails userDetails) {
        return hasRole(userDetails, RolesEnum.IMPERSONATION_MDPRO) || hasRole(userDetails, RolesEnum.IMPERSONATION_SALARIE);
    }

    /**
     * Retourne l identifiant GDI de l utilisateur connecte
     */
    public static String getIdGdi() throws CommonException {
        if (log.isDebugEnabled()) {
            log.debug("R\u00e9cup\u00e9ration des infos utilisateur");
        }
        Authentication auth = getAuthentication();
        if (auth != null) {
            if (auth instanceof AnonymousAuthenticationToken) {
                throw new BusinessException(AuthentificationUtils.NO_ATH_USER_MSG);
            } else {
                return auth.getName();
            }
        } else {
            throw new BusinessException(AuthentificationUtils.NO_ATH_USER_MSG);
        }
    }

    private static Authentication getAuthentication() {
        SecurityContext securityContext = SecurityContextHolder.getContext();
        return securityContext != null ? securityContext.getAuthentication() : null;
    }
}
