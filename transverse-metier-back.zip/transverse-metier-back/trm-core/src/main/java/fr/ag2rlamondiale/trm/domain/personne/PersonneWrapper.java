/*
 * Cree le 13 sept. 2018.
 * (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.personne;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

/**
 * Wrapper de Sortie du service de recherche de personne physique
 * Il encapsule le POJO "Personne" qui contient les données
 * et une map contenant d'eventuelles erreurs à remonter au front
 *
 * <br>Historique:
 * <br>
 *
 * @author CORNE
 */
@Data
public class PersonneWrapper {

	//TODO Supprimer classe si elle n'est pas utilisé
	PersonnePhysique personne;
	Map<String, String> errorList;

	public PersonneWrapper() {
		this.errorList = new HashMap<>();
	}
}
