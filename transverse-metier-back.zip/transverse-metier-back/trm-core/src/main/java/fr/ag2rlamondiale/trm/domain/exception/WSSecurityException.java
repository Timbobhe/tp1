package fr.ag2rlamondiale.trm.domain.exception;

/**
 * Exception leve lors d'une menace securite. Exemple : un utilisateur X essaye de consulter des
 * contrats d'un utilisateur Y.
 */
public class WSSecurityException extends RuntimeException {
    private static final long serialVersionUID = -6664620204774191733L;

    public WSSecurityException(String message, Throwable cause) {
        super(message, cause);
    }

    public WSSecurityException(String message) {
        super(message);
    }

    public WSSecurityException(Throwable cause) {
        super(cause);
    }

    public WSSecurityException() {
        super();
    }
}
