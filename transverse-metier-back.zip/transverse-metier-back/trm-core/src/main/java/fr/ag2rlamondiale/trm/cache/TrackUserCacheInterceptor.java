package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Slf4j
@Aspect
@Component
public class TrackUserCacheInterceptor implements Ordered {

    @Autowired
    private IQueryCache queryCache;

    @Autowired
    private ITrackUserCache trackUserCache;

    @Around("@annotation(cacheable)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint, Cacheable cacheable) throws Throwable {

        final Object target = joinPoint.getTarget();
        final MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        final Method method = signature.getMethod();
        final Object[] params = joinPoint.getArgs();

        trackUserCache.trackUserCache(target, method, params);
        return joinPoint.proceed();
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.TRACK_USER_CACHE_ORDER;
    }
}
