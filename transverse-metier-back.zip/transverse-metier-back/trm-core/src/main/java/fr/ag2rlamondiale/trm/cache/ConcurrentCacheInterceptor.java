package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import fr.ag2rlamondiale.trm.utils.LockCache;
import fr.ag2rlamondiale.trm.utils.TimestampObject;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.Ordered;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Le Rôle de cet Interceptor est d'intercepté les méthodes {@linkplain Cacheable} et
 * de protéger l'exécution concurrente de ces méthodes avec les mêmes paramètres.
 *
 * <p>
 * Si plusieurs Thread exécute en même temps la même méthode avec les mêmes paramètres alors <u>un seul et unique</u> appel sera réellement déclenché.
 * Les autres appels seront bloqués jusqu'à la fin de l'exécution du service.
 * Ils iront lire le résultat directement depuis le Cache.
 * </p>
 */
@Slf4j
@Aspect
@Component
public class ConcurrentCacheInterceptor implements Ordered, ClearableCache, IMetaCache {

    // VERROUS
    private final ConcurrentCacheKeyGenerator cacheKeyGenerator = new ConcurrentCacheKeyGenerator();
    private final ConcurrentMap<Object, TimestampObject<LockCache>> locks = new ConcurrentHashMap<>();

    // Pour JMX
    private final AtomicBoolean enable = new AtomicBoolean(true);

    @Autowired
    private IQueryCache queryCache;

    @Around("@annotation(cacheable)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint, Cacheable cacheable) throws Throwable {
        if (!enable.get()) {
            return joinPoint.proceed();
        }
        final boolean cached = isCached(joinPoint);
        if (cached) {
            return joinPoint.proceed();
        }

        final TimestampObject<LockCache> timestampObject = timestampCache(joinPoint);
        final LockCache lockCache = timestampObject.touch().getObject();
        final AtomicBoolean removeLock = new AtomicBoolean(false);
        try {
            if (!lockCache.isWriteLocking()) {
                lockCache.resetCache();
            }

            // reader = writer : on laisse jouer le cache
            return lockCache.concurrent(() -> proceed(joinPoint), () -> {
                proceed(joinPoint);
                timestampObject.touch();
                removeLock.set(true);
            });
        } catch (RunningException e) {
            throw e.getCause();
        } finally {
            if (removeLock.get()) {
                locks.remove(lockCache.getKeyLock());
            }
        }
    }

    private Object proceed(ProceedingJoinPoint joinPoint) {
        try {
            return joinPoint.proceed();
        } catch (Throwable e) {
            throw new RunningException(e);
        }
    }

    private boolean isCached(ProceedingJoinPoint joinPoint) {
        return queryCache.isCached(joinPoint);
    }

    public boolean isEnable() {
        return enable.get();
    }

    public void setEnable(boolean enable) {
        this.enable.set(enable);
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.CONCURRENT_CACHE_ORDER;
    }

    @Scheduled(fixedRateString = "${cache.concurrent.cleaning.fixedRate:300000}") // 5min
    public void cleanLock() {
        cleanLock(false);
    }

    public void cleanLock(boolean force) {
        try {
            log.info("D\u00E9but du nettoyage des verrous, total = {}", getLocksCounter());
            final Instant now = Instant.now();
            List<Object> keys = new ArrayList<>();
            locks.forEach((key, value) -> {
                final Instant timestamp = value.getTimestamp();
                if (force || timestamp != null && timestamp.plus(1, ChronoUnit.MINUTES).isBefore(now)) {
                    keys.add(key);
                }
            });

            keys.forEach(locks::remove);

            log.info("Fin du nettoyage des verrous, restant = {}", getLocksCounter());
        } catch (Exception e) {
            log.error("Erreur pendant le nettoyage des verrous", e);
        }
    }

    public int getLocksCounter() {
        return locks.size();
    }

    @Override
    public void clearCache() {
        locks.clear();
    }

    @Override
    public TimestampObject<LockCache> timestampCache(Object target, Method method, Object[] params) {
        final Object keyLock = cacheKeyGenerator.generate(method, params);
        return locks.computeIfAbsent(keyLock, o -> new TimestampObject<>(new LockCache(keyLock), null));
    }

    private static class RunningException extends RuntimeException {
        public RunningException(Throwable cause) {
            super(cause);
        }
    }
}
