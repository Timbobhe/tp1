package fr.ag2rlamondiale.trm.rest.jaxb;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.trm.rest.AbstractPfsRestServiceInterceptor;
import fr.ag2rlamondiale.trm.rest.PfsRestException;
import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.rest.jaxb.response.ResponseWrapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import static fr.ag2rlamondiale.trm.rest.jaxb.PfsRestJaxbConfig.JAXB_OBJECT_MAPPER;
import static fr.ag2rlamondiale.trm.rest.jaxb.PfsRestJaxbConfig.JAXB_REST_TEMPLATE;


@Slf4j
@Aspect
@Component
public class PfsRestServiceInterceptor extends AbstractPfsRestServiceInterceptor<ResponseWrapper<?>> {

    @Qualifier(JAXB_REST_TEMPLATE)
    @Autowired
    private RestTemplate restTemplate;

    @Qualifier(JAXB_OBJECT_MAPPER)
    @Autowired
    private ObjectMapper jsonMapper;


    @Around("@annotation(pfsRestService)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint, PfsRestService pfsRestService) throws Throwable {
        PfsRestServiceConfig config = PfsRestServiceConfig.from(pfsRestService);
        return aroundAdvice(joinPoint, config);
    }

    @Override
    protected void checkError(String url, String jsonInput, long requestId, ResponseWrapper<?> responseWrapper) {
        responseWrapper.handleError(header -> {
            logger().error("ERROR REST(#{}) {} {} : {}", requestId, url, jsonInput, header.getErrorMessage());
            throw new PfsRestException(header);
        });
    }

    @Override
    protected void handleError(ResponseWrapper<?> responseWrapper, HttpStatusCodeException e) {
        responseWrapper.handleError(header -> {
            throw new PfsRestException(header, e);
        });
    }

    @Override
    protected Logger logger() {
        return log;
    }

    @Override
    protected Class responseWrapperClass() {
        return ResponseWrapper.class;
    }

    @Override
    protected ObjectMapper jsonMapper() {
        return jsonMapper;
    }

    @Override
    protected RestTemplate restTemplate() {
        return restTemplate;
    }
}
