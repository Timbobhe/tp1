package fr.ag2rlamondiale.trm.rest.swagger;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.rest.AbstractPfsRestServiceInterceptor;
import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.rest.auth.PfsTokenBuilder;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import static fr.ag2rlamondiale.trm.rest.swagger.PfsRestSwaggerConfig.SWAGGER_OBJECT_MAPPER;
import static fr.ag2rlamondiale.trm.rest.swagger.PfsRestSwaggerConfig.SWAGGER_REST_TEMPLATE;


@Slf4j
@Aspect
@Component
public class PfsRestServiceSwaggerInterceptor extends AbstractPfsRestServiceInterceptor<ResponseWrapperSwagger<?>> {

    @Autowired
    private PfsTokenBuilder pfsTokenBuilder;

    @Qualifier(SWAGGER_REST_TEMPLATE)
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ISupplierLibService supplierLibService;

    @Qualifier(SWAGGER_OBJECT_MAPPER)
    @Autowired
    private ObjectMapper jsonMapper;


    @Around("@annotation(pfsRestServiceSwagger)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint, PfsRestServiceSwagger pfsRestServiceSwagger) throws Throwable {
        return aroundAdvice(joinPoint, PfsRestServiceConfig.from(pfsRestServiceSwagger));
    }

    @Override
    protected Class responseWrapperClass() {
        return ResponseWrapperSwagger.class;
    }

    @Override
    protected RestTemplate restTemplate() {
        return restTemplate;
    }

    @Override
    protected ObjectMapper jsonMapper() {
        return jsonMapper;
    }

    @Override
    protected Logger logger() {
        return log;
    }
}
