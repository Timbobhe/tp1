package fr.ag2rlamondiale.trm.exception;

public class TechnicalRuntimeException extends RuntimeException {
    public TechnicalRuntimeException() {
    }

    public TechnicalRuntimeException(String message) {
        super(message);
    }

    public TechnicalRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public TechnicalRuntimeException(Throwable cause) {
        super(cause);
    }

    public TechnicalRuntimeException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
