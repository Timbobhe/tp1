package fr.ag2rlamondiale.trm.domain;

import lombok.Getter;

@Getter
public enum FiscaliteType {

    //ERE
    PERE("PERE", "Fiscalité PER Entreprise"),
    EPARRETR("EPARRETR", "Fiscalité Epargne Retraite"),
    PACTE("PACTE", "Fiscalité PACTE"),
    EXPATR("EXPATR", "Fiscalité Expatriés"),

    //MDPRO
    FISCMAD("FISCMAD", "Fiscalité Madelin"),
    ASSVIE("ASSVIE", "Fiscalité Assurance vie"),
    PEP("PEP", "Fiscalité Madelin Agricole"),
    PERP("PERP", "Fiscalité PERP"),
    FISCLAS("FISCLAS", "Fiscalité Classique"),
    PEA("PEA", "Fiscalité PEA"),
    FISCDSK("FISCDSK", "Fiscalité DSK"),

    //COMMUN
    ART39("ART39", "Fiscalité Article 39"),
    DISPO82("82DISPO", "Fiscalité Article 82"),
    NODISP82("82NODISP", "Fiscalité Article 82"),
    ART83("ART83", "Fiscalité PER Entreprise");

    private final String codeCadreFiscal;
    private final String libCadreFiscal;

    FiscaliteType(final String codeCadreFiscal, final String libCadreFiscal) {
        this.codeCadreFiscal = codeCadreFiscal;
        this.libCadreFiscal = libCadreFiscal;
    }

    public static String getLibelleFiscaliteFromCode(String code) {
        final FiscaliteType fiscalite = getFiscaliteFromCode(code);
        return fiscalite != null ? fiscalite.getLibCadreFiscal() : null;
    }

    public static FiscaliteType getFiscaliteFromCode(String code) {
        for (FiscaliteType fiscaliteType : values()) {
            if (fiscaliteType.codeCadreFiscal.equals(code))
                return fiscaliteType;
        }
        return null;
    }
}
