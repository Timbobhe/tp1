package fr.ag2rlamondiale.trm.domain.contrat;

import fr.ag2rlamondiale.trm.domain.exception.UnknownEnumerationValueException;
import lombok.Getter;

import javax.annotation.Nonnull;

@Getter
public enum SituationContratEnum {
    CREATION("C", "CREAT", "Création"),
    MISE_EN_GESTION("G", "MISGES", "Mis en gestion"),
    VALIDE("V", "VALID", "Validé"),
    INVALIDE("I", "INVAL", "Invalidé"),
    SORTI("S", "SORTI", "Sorti"),
    TRANSFERE("T", "TRANSF", "Transféré"),
    SOLDE("D", "SOLDE", "Soldé"),
    RECOUVREMENT("R", "RECOUV", "Mise en recouvrement"),
    SANS_EFFET("Z", "REPRIS", "Reprise"),
    DESACTIVE("F", "DESACT", "Désactivé"),
    REMISE_EN_VENTE("N", "REMVEN", "Remise en vente"),
    ANNUL("X", "ANNULE", "Annulé"),
    REACTIVATION_EN_ATTENTE("A", "ATREAC", "Attente réactivation"),
    ARRET_QUITTANCEMENT("Q", "ARQUIT", "Arrêt de quittancement"),
    EN_COURS("2", "EC", "En cours"),
    EN_COURS_SANS_PRIME("3", "ECSSPRM", "En cours sans prime"),
    RACHETE_OFFICE("6", "RACHOFF", "Racheté d'office"),
    RACHETE_DEMANDE("7", "RACHDEM", "Racheté demande"),
    EXPIRE_AVEC_CONTRAT("8", "EXPAVCTR", "Expiré avec contrat"),
    EXPIRE_SANS_CONTRAT("9", "EXPSSCTR", "Expiré sans contrat"),
    ANNEE_BLANCHE("12", "ANBLCH", "Année Blanche/P.A.SS Appel"),
    SINISTRE("13", "SINIS", "Sinistré"),
    LIBERE_PRIME_OFFICE("16", "LIBPRMOFF", "Libéré prime office"),
    LIBERE_PRIME_DEMANDE("17", "LIBPRMDEM", "Libéré prime demande"),
    REDUIT("20", "RED", "Réduit"),
    TRANSFORME("21", "TRSFRM", "Transformé");

    private final String codeSilo;
    private final String codeValue;
    private final String libelleSilo;

    SituationContratEnum(final String codeSilo, final String codeValue,
                         final String libelleSilo) {
        this.codeSilo = codeSilo;
        this.codeValue = codeValue;
        this.libelleSilo = libelleSilo;
    }

    public static SituationContratEnum fromCodeSilo(@Nonnull final String codeSilo) {
        for (SituationContratEnum item : SituationContratEnum.values()) {
            if (item.getCodeSilo().equals(codeSilo)) {
                return item;
            }
        }

        throw new UnknownEnumerationValueException(SituationContratEnum.class,
                "codeSilo=\"" + codeSilo + "\" non recensé.");
    }

    public static SituationContratEnum fromCodeValue(@Nonnull final String codeValue) {
        for (SituationContratEnum item : SituationContratEnum.values()) {
            if (item.getCodeValue().equals(codeValue)) {
                return item;
            }
        }
        throw new UnknownEnumerationValueException(SituationContratEnum.class,
                "codeValue=\"" + codeValue + "\"' non recensé.");
    }

    public boolean isSame(SituationContratEnum other) {
        return this.getCodeSilo().equals(other.getCodeSilo());
    }


    public boolean isDifferent(SituationContratEnum other) {
        return !this.isSame(other);
    }


}
