package fr.ag2rlamondiale.trm.domain;

import lombok.*;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

@Getter
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString
public class Annee {
    public static Annee Courante = Annee.fromAmount(0);
    public static Annee Precedente = Annee.fromAmount(-1);
    public static Annee Prochaine = Annee.fromAmount(1);

    @EqualsAndHashCode.Include
    private final int year;

    /**
     * Retourne l'année + ou - l'année courante
     *
     * @param amount
     * @return
     */
    public static Annee fromAmount(int amount) {
        LocalDate today = LocalDate.now();
        int year = today.plus(amount, ChronoUnit.YEARS).getYear();
        return new Annee(year);
    }

    private Annee(int year) {
        this.year = year;
    }

    public static Annee fromYear(int year) {
        return new Annee(year);
    }

    public LocalDate toLocalDate() {
        return LocalDate.of(this.year, Month.JANUARY, 1);
    }

    public Date toDate() {
        return Date.from(toLocalDate()
                .atStartOfDay()
                .atZone(ZoneId.systemDefault())
                .toInstant());
    }

    public LocalDate firstDate() {
        return LocalDate.of(this.year, Month.JANUARY, 1);
    }

    public LocalDate lastDate() {
        return LocalDate.of(this.year, Month.DECEMBER, 31);
    }

    public BorneAnnee borneAnnee() {
        return BorneAnnee.builder()
                .firstDate(firstDate())
                .lastDate(lastDate())
                .build();
    }

    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    @Data
    public static class BorneAnnee {
        private LocalDate firstDate;
        private LocalDate lastDate;

        public Date toFirstDate() {
            return Date.from(firstDate
                    .atStartOfDay()
                    .atZone(ZoneId.systemDefault())
                    .toInstant());
        }

        public Date toLastDate() {
            return Date.from(lastDate
                    .atStartOfDay()
                    .atZone(ZoneId.systemDefault())
                    .toInstant());
        }
    }
}
