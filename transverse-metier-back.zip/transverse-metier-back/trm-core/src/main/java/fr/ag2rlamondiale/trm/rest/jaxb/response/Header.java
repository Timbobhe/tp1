package fr.ag2rlamondiale.trm.rest.jaxb.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;

import java.util.Collections;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Header {
    @JsonProperty("TechError")
    private List<TechError> techError;

    @JsonProperty("FuncError")
    private List<FuncError> funcError;

    public String getErrorMessage() {
        if (CollectionUtils.isNotEmpty(techError)) {
            return techError.get(0).getErrorMessage();
        }
        if (CollectionUtils.isNotEmpty(funcError)) {
            return funcError.get(0).getErrorMessage();
        }
        return null;
    }

    public static Header empty(String errorMessage) {
        return new Header(Collections.singletonList(new TechError(errorMessage, errorMessage)), Collections.emptyList());
    }
}
