package fr.ag2rlamondiale.trm.domain.exception;

import javax.annotation.Nonnull;

public class UnknownEnumerationValueException extends RuntimeException {
    private static final long serialVersionUID = 3307143460681078268L;

    public UnknownEnumerationValueException(Enum<?> enumEntry, @Nonnull String message) {
        super(enumEntry.getClass() + "(" + enumEntry.name() + ") : " + message);
    }
    
    public UnknownEnumerationValueException(Class<?> clazz, @Nonnull String message) {
        super(clazz.getName() + ": " + message);
    }
}
