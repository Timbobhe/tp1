package fr.ag2rlamondiale.trm.spring;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation indique qu'il s'agit de <b>l'implémentation par défaut - fournie par la librairie</b>.<br>
 * A utiliser conjointement avec {@link ConditionnalDefaultImpl} de la manière suivante :
 *
 * <pre>{@code
 * @Service
 * @Conditional(ConditionnalDefaultImpl.class)
 * @DefaultImpl(implemtationOf = IConsulterPersPhysFacade.class)
 * public class ConsulterPersPhysFacadeImpl implements IConsulterPersPhysFacade {
 * }</pre>
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface DefaultImpl {
    Class<?> implemtationOf();
}
