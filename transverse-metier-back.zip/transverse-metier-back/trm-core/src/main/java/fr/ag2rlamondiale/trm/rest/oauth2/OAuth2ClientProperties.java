package fr.ag2rlamondiale.trm.rest.oauth2;

import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;

@Slf4j
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OAuth2ClientProperties implements InitializingBean {

    @Autowired
    @ToString.Exclude
    private PropertyResolver propertyResolver;

    /**
     * OAuth provider details.
     */
    @Builder.Default
    private final Map<String, Provider> provider = new HashMap<>();

    /**
     * OAuth client registrations.
     */
    @Builder.Default
    private final Map<String, Registration> registration = new HashMap<>();


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Provider {
        /**
         * Authorization URI for the provider.
         */
        private String authorizationUri;

        /**
         * Token URI for the provider.
         */
        private String tokenUri;

        /**
         * User info URI for the provider.
         */
        private String userInfoUri;

        /**
         * User info authentication method for the provider.
         */
        private String userInfoAuthenticationMethod;

        /**
         * Name of the attribute that will be used to extract the username from the call
         * to 'userInfoUri'.
         */
        private String userNameAttribute;

        /**
         * JWK set URI for the provider.
         */
        private String jwkSetUri;

        /**
         * URI that can either be an OpenID Connect discovery endpoint or an OAuth 2.0
         * Authorization Server Metadata endpoint defined by RFC 8414.
         */
        private String issuerUri;
    }


    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Registration {
        /**
         * Reference to the OAuth 2.0 provider to use. May reference an element from the
         * 'provider' property or used one of the commonly used providers (google, github,
         * facebook, okta).
         */
        private String provider;

        /**
         * Client ID for the registration.
         */
        private String clientId;

        /**
         * Client secret of the registration.
         */
        private String clientSecret;

        /**
         * Client authentication method. May be left blank when using a pre-defined
         * provider.
         */
        private String clientAuthenticationMethod;

        /**
         * Authorization grant type. May be left blank when using a pre-defined provider.
         */
        private String authorizationGrantType;

        /**
         * Redirect URI. May be left blank when using a pre-defined provider.
         */
        private String redirectUri;

        /**
         * Authorization scopes. When left blank the provider's default scopes, if any,
         * will be used.
         */
        private Set<String> scope;

        /**
         * Client name. May be left blank when using a pre-defined provider.
         */
        private String clientName;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        final List<String> providers = propertyResolver.findPropertyList("oauth2.client.provider");
        if (providers != null) {
            for (String registrationId : providers) {
                final Provider provider = Provider.builder()
                        .issuerUri(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".issuerUri"))
                        .authorizationUri(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".authorizationUri"))
                        .tokenUri(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".tokenUri"))
                        .userInfoUri(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".userInfoUri"))
                        .userInfoAuthenticationMethod(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".userInfoAuthenticationMethod"))
                        .userNameAttribute(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".userNameAttribute"))
                        .jwkSetUri(propertyResolver.findProperty("oauth2.client.provider." + registrationId + ".jwkSetUri"))
                        .build();
                this.provider.put(registrationId, provider);
            }
        }

        final List<String> registrations = propertyResolver.findPropertyList("oauth2.client.registration");
        if (registrations != null) {
            for (String registrationId : registrations) {
                final List<String> scopeConfig = propertyResolver.findPropertyList("oauth2.client.registration." + registrationId + ".scope");
                Set<String> scope = null;
                if (scopeConfig != null) {
                    scope = new HashSet<>(scopeConfig);
                }

                final Registration registration = Registration.builder()
                        .clientId(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".clientId"))
                        .clientSecret(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".clientSecret"))
                        .clientAuthenticationMethod(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".clientAuthenticationMethod"))
                        .authorizationGrantType(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".authorizationGrantType"))
                        .redirectUri(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".redirectUri"))
                        .scope(scope)
                        .clientName(propertyResolver.findProperty("oauth2.client.registration." + registrationId + ".clientName"))
                        .build();

                this.registration.put(registrationId, registration);
            }
        }

        log.info("oauth2.client = {}", this);
    }

}
