package fr.ag2rlamondiale.trm.soap;

import fr.ag2rlamondiale.trm.client.soap.config.AttachementHandler;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Documented
@Retention(RUNTIME)
@Target(METHOD)
/**
 * Permet d'initialiser le Port Soap créer par un {@link javax.xml.ws.Service} en lui passant l'URL
 * et l'{@link AttachementHandler}
 * 
 * @author barukh
 *
 */
public @interface PortInitializer {

    String serviceId();

    String alternative() default "";

    /**
     * Indique qu'il faudra rajouter le {@link AttachementHandler} dans la chain des Handler SOAP.<br>
     * Si <code>true</code> alors le 1er argument de la méthode doit être un {@link fr.ag2rlamondiale.ecrs.client.soap.config.AttachmentResponse}
     * @return
     */
    boolean withAttachment() default false;

    boolean handleSoapClientHandler() default false;

    boolean enableLog() default true;
}
