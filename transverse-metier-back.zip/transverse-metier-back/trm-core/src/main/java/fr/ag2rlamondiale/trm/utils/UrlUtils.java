package fr.ag2rlamondiale.trm.utils;

import lombok.SneakyThrows;
import org.springframework.web.util.UriComponentsBuilder;

public class UrlUtils {
    private UrlUtils() {
        // ignore
    }

    public static String assembleUrl(String a, String b) {
        if (a.endsWith("/") && b.startsWith("/")) {
            return a + b.substring(1);
        }

        if (a.endsWith("/") && !b.startsWith("/")) {
            return a + b;
        }

        if (!a.endsWith("/") && b.startsWith("/")) {
            return a + b;
        }

        if (!a.endsWith("/") && !b.startsWith("/")) {
            return a + "/" + b;
        }

        throw new IllegalArgumentException(a + "+" + b);
    }

    @SneakyThrows
    public static String appendQueryParams(String url, String key, Object value) {
        return UriComponentsBuilder.fromHttpUrl(url).queryParam(key, value).build().toUriString();
    }

    /**
     * Pas de control sur l'URL
     *
     * @param url
     * @param key
     * @param value
     * @return
     */
    public static String basicAppendQueryParams(String url, String key, Object value) {
        return url + "?" + key + "=" + value;
    }
}
