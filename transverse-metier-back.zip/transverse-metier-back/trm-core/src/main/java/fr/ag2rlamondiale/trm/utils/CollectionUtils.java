package fr.ag2rlamondiale.trm.utils;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

import java.util.*;

/**
 * Static utility methods pertaining to collections.
 */
public final class CollectionUtils {
    private CollectionUtils() { /* prevents instantiation */ }

    public static <T> List<T> nullToEmpty(List<T> list) {
        return list == null ? ImmutableList.of() : list;
    }

    public static <T> Set<T> nullToEmpty(Set<T> set) {
        return set == null ? ImmutableSet.of() : set;
    }

    /**
     * Split a list into small parts.
     *
     * @param list
     * @param maxSize
     * @return
     */
    public static <T> List<List<T>> chopList(final List<T> list, final int maxSize) {
        List<List<T>> parts = new ArrayList<>();
        final int total = list.size();

        for (int i = 0; i < total; i += maxSize) {
            parts.add(list.subList(i, Math.min(total, i + maxSize)));
        }

        return parts;
    }

    public static <T> Collection<T> escapeNull(Collection<T> collection) {
        if (collection != null) {
            return collection;
        }

        return Collections.emptyList();
    }
}
