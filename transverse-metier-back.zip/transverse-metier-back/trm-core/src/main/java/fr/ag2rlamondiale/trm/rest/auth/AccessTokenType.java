package fr.ag2rlamondiale.trm.rest.auth;

public enum AccessTokenType {
    RSA_PRIVATE_KEY,
    OAUTH2_CAS_APPLI,
    OAUTH2_CAS_USER
}
