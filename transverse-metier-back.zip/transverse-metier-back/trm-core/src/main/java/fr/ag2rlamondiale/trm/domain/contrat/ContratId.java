package fr.ag2rlamondiale.trm.domain.contrat;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonDeserialize(using = ContratIdDeserializer.class)
public class ContratId implements ISecurityParamAccess, Serializable {
    private static final long serialVersionUID = -4049926851116324981L;
    private CodeSiloType codeSilo;
    private String nomContrat;
    private String idAdherente;
    private String idContractante;
    private String idCollege;

    public static ContratId ere(String nomContrat, String idAdherente, String idContractante, String idCollege) {
        return ContratId.builder()
                .codeSilo(CodeSiloType.ERE)
                .nomContrat(nomContrat)
                .idAdherente(idAdherente)
                .idContractante(idContractante)
                .idCollege(idCollege)
                .build();
    }

    public static ContratId mdpro(String nomContrat) {
        return ContratId.builder()
                .codeSilo(CodeSiloType.MDP)
                .nomContrat(nomContrat)
                .build();
    }

    public ContratId clean() {
        if (CodeSiloType.MDP.equals(codeSilo)) {
            return ContratId.builder().codeSilo(codeSilo).nomContrat(nomContrat).build();
        }
        return this;
    }

    public boolean is(CodeSiloType codeSilo) {
        return codeSilo.equals(this.codeSilo);
    }

    @Override
    public String secureForNumContrat() {
        return nomContrat;
    }
}
