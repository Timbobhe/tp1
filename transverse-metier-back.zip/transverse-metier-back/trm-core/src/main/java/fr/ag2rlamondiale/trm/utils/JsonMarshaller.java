package fr.ag2rlamondiale.trm.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import fr.ag2rlamondiale.trm.rest.jaxb.response.ResponseWrapper;
import fr.ag2rlamondiale.trm.rest.swagger.ResponseWrapperSwagger;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import static fr.ag2rlamondiale.trm.rest.swagger.PfsRestSwaggerConfig.DATE_FORMAT;

public class JsonMarshaller {

    private JsonMarshaller() {
    }

    public static String toJSON(Object o) {
        return toJSON(o, false);
    }

    public static String toJSON(Object o, boolean withPrettyPrinter) {
        ObjectWriter ow = new ObjectMapper().writer();
        if (withPrettyPrinter) {
            ow.withDefaultPrettyPrinter();
        }
        String json;
        try {
            json = ow.writeValueAsString(o);
        } catch (JsonProcessingException e) {
            throw new JsonMarshallerException(e);
        }
        return json;
    }

    public static <T> T fromJSON(String json, Class<T> clazz) {
        return fromJSON(json, clazz, false);
    }

    public static <T> T fromJSON(String json, Class<T> clazz, boolean ignoreUnknownProps) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            if (ignoreUnknownProps) {
                objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
            }
            return objectMapper.readValue(json, clazz);
        } catch (IOException e) {
            throw new JsonMarshallerException(e);
        }
    }

    public static <T> T fromJSONRestServicesPfs(String json, Class<T> clazz) {
        try {
            return objectMapperWithJaxb().readValue(json, clazz);
        } catch (IOException e) {
            throw new JsonMarshallerException(e);
        }
    }

    public static <T> T fromJSONRestServicesPfs(InputStream inputStream, Class<T> clazz) {
        try {
            return objectMapperWithJaxb().readValue(inputStream, clazz);
        } catch (IOException e) {
            throw new JsonMarshallerException(e);
        }
    }

    public static <T> T fromJSONRestSwaggerServicesPfs(InputStream inputStream, Class<T> clazz) {
        try {
            final ObjectMapper objectMapper = JsonMarshaller.buildSwaggerObjectMapper();
            JavaType javaType = JsonMarshaller.javaTypeResponseWrapperSwagger(objectMapper, clazz);
            ResponseWrapperSwagger<T> responseWrapper = objectMapper.readValue(inputStream, javaType);
            return responseWrapper.getResponseBody();
        } catch (IOException e) {
            throw new JsonMarshallerException(e);
        }
    }

    public static <T> T fromJSONRestSwaggerRestFulServicesPfs(InputStream inputStream, Class<T> clazz) {
        try {
            final ObjectMapper objectMapper = JsonMarshaller.buildSwaggerObjectMapper();
            JavaType javaType = JsonMarshaller.javaTypeResponseWrapperSwaggerRestFul(objectMapper, clazz);
            Object responseWrapper = objectMapper.readValue(inputStream, javaType);
            return (T) responseWrapper;
        } catch (IOException e) {
            throw new JsonMarshallerException(e);
        }
    }

    public static ObjectMapper objectMapperWithJaxb() {
        ObjectMapper objectMapper = new ObjectMapper();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        objectMapper.setDateFormat(dateFormat);
        objectMapper.registerModule(new JaxbAnnotationModule());
        return objectMapper;
    }

    public static ObjectMapper buildSwaggerObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        objectMapper.setDateFormat(dateFormat);
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }

    public static <T> JavaType javaTypeResponseWrapper(ObjectMapper objectMapper, Class<T> clazz) {
        final TypeFactory typeFactory = objectMapper.getTypeFactory();
        final JavaType javaReturnType = typeFactory.constructType(clazz);
        return typeFactory.constructParametricType(ResponseWrapper.class, javaReturnType);
    }

    public static <T> JavaType javaTypeResponseWrapperSwagger(ObjectMapper objectMapper, Class<T> clazz) {
        final TypeFactory typeFactory = objectMapper.getTypeFactory();
        final JavaType javaReturnType = typeFactory.constructType(clazz);
        return typeFactory.constructParametricType(ResponseWrapperSwagger.class, javaReturnType);
    }

    public static <T> JavaType javaTypeResponseWrapperSwaggerRestFul(ObjectMapper objectMapper, Class<T> clazz) {
        final TypeFactory typeFactory = objectMapper.getTypeFactory();
        return typeFactory.constructType(clazz);
    }
}
