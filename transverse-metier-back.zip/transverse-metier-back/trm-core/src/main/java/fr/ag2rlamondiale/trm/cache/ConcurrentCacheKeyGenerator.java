package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.utils.Sets;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.SimpleKey;

import java.lang.reflect.Method;

class ConcurrentCacheKeyGenerator {

    private static final Object EMPTY_DOMAIN = new Object();

    public Object generate(Method method, Object... params) {
        Object domain = EMPTY_DOMAIN;

        final Cacheable cacheable = method.getAnnotation(Cacheable.class);
        final CacheEvict cacheEvict = method.getAnnotation(CacheEvict.class);

        if (cacheable != null && cacheable.keyGenerator().isEmpty()) {
            domain = method;
        } else if (cacheable != null && !cacheable.keyGenerator().isEmpty()) {
            domain = domainFor(IQueryCache.cacheNames(cacheable));
        } else if (cacheEvict != null && !cacheEvict.keyGenerator().isEmpty()) {
            domain = domainFor(cacheEvict.cacheNames());
        } else if (cacheEvict != null && cacheEvict.keyGenerator().isEmpty()) {
            throw new IllegalArgumentException("Impossible de retrouver la cl\u00E9 de cache dans ce cas seulement \u00E0 partir de CacheEvict pour " + method);
        }

        return compute(domain, params);
    }

    private Object compute(Object domain, Object... params) {
        if (params.length == 0) {
            return domain;
        }

        if (params.length == 1) {
            Object param = params[0];
            if (param != null && !param.getClass().isArray()) {
                return new SimpleKey(domain, param);
            }
        }

        final Object[] array = new Object[params.length + 1];
        array[0] = domain;
        System.arraycopy(params, 0, array, 1, params.length);

        return new SimpleKey(array);
    }

    private Object domainFor(String[] names) {
        if (names == null || names.length == 0) {
            return EMPTY_DOMAIN;
        }
        if (names.length == 1) {
            return names[0];
        }
        return Sets.set(names);
    }
}
