package fr.ag2rlamondiale.trm.domain.contrat;

import java.util.Comparator;

public enum AffichageType {
    NORMAL(0) {
        @Override
        public boolean isDisabled() {
            return false;
        }

        @Override
        public boolean isSelectable() {
            return true;
        }
    },
    /**
     * Indique que le Contrat s'affiche dans la Synthese mais ne permet pas de réaliser des actes
     */
    LECTURE_SEULE(1) {
        @Override
        public boolean isDisabled() {
            return false;
        }
    },
    GRISE(2),
    MASQUE(3);

    private final Integer force;

    AffichageType(int force) {
        this.force = force;
    }

    public boolean isDisabled() {
        return true;
    }

    public boolean isEnabled() {
        return !this.isDisabled();
    }

    public boolean isSelectable() {
        return false;
    }

    public Integer getForce() {
        return force;
    }

    public static class ForceComparator implements Comparator<AffichageType> {
        public static final ForceComparator instance = new ForceComparator();

        @Override
        public int compare(AffichageType o1, AffichageType o2) {
            return o1.getForce().compareTo(o2.getForce());
        }
    }
}
