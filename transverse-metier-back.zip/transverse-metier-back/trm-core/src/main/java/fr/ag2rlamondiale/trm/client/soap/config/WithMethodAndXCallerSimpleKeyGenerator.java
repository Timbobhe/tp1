package fr.ag2rlamondiale.trm.client.soap.config;

import fr.ag2rlamondiale.trm.cache.WithMethodSimpleKeyGenerator;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.WITH_XCALLER_KEY_GENERATOR;

@Qualifier(WITH_XCALLER_KEY_GENERATOR)
@Service
public class WithMethodAndXCallerSimpleKeyGenerator extends WithMethodSimpleKeyGenerator {

    @Autowired
    private UserContextHolder userContextHolder;

    @Override
    public Object generate(Object target, Method method, Object... params) {
        final Partenaire partenaire = userContextHolder.get().getPartenaire();
        if (partenaire != null) {
            final Object[] array = new Object[params.length + 1];
            System.arraycopy(params, 0, array, 0, params.length);
            array[params.length] = partenaire.getCodeAppli();
            return super.generate(target, method, array);
        }

        return super.generate(target, method, params);
    }
}
