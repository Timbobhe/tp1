package fr.ag2rlamondiale.trm.soap;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Inherited
@Documented
public @interface SoapRequest {

    boolean hasSecurityHeader() default false;

    boolean enableXCaller() default false;

    boolean useSharepointToken() default false;

    String externalSecurityHeader() default "";

    boolean forceLogBody() default false;

    /**
     * Indique que l'appel est fait en mode connecté (avec un utilisateur connecté)
     *
     * @return
     */
    boolean connectedRequest() default true;
}
