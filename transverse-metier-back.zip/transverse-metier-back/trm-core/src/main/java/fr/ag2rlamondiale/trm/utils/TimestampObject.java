package fr.ag2rlamondiale.trm.utils;

import lombok.Getter;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;

public class TimestampObject<T> {

    @Getter
    private final T object;

    private final AtomicReference<Instant> timestamp = new AtomicReference<>();

    public TimestampObject(T object) {
        this(object, Instant.now());
    }

    public TimestampObject(T object, Instant instant) {
        this.object = object;
        this.timestamp.set(instant);
    }

    public TimestampObject<T> touch() {
        timestamp.set(Instant.now());
        return this;
    }

    public Instant getTimestamp() {
        return timestamp.get();
    }


}
