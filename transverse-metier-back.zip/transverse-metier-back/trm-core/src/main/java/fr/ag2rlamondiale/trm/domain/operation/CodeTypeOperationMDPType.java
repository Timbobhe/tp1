/*
 * Cree le 26 nov. 2018.
 * (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.operation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum CodeTypeOperationMDPType {
    // Arbitrage
    AF("Arbitrage Final", "Arbitrage", false, true, true),
    // Division VL LM Actions Monde
    AM_DV("Arbitrage Mondiale Division VL Actions Monde", "Division VL LM Actions Monde", false, false, false),
    // Fusion Nouveau Marché Assur
    AM_NM("Arbitrage Mondiale Nouveau Marché", "Fusion Nouveau Marché Assur", false, false, false),
    // Arbitrage
    AM("Arbitrage Mondiale", "Arbitrage", false, true, true),
    // Cotisation
    AP("Appel", "Cotisation", true, true, true),
    // Arbitrage
    AR("Arbitrage Initial", "Arbitrage", false, true, true),
    // Avance
    AV("Avance", "Avance", true, true, true),
    // Modification
    CG("Changement Mode Gestion Financier", "Modification", false, true, true),
    // Cessation de profil
    CP("Cessation de profil", "Cessation de profil", false, true, true),
    // Exonération
    EX("Exonération", "Exonération", false, false, true),
    // Dynamisation de la plus value
    GP_DP("Gestion Pilotée Dynamisation de la plus value", "Dynamisation de la plus value", true, true, true),
    // Arbitrage Gestion Pilotée
    GP("Gestion Pilotée", "Arbitrage Gestion Pilotée", false, true, true),
    // Transfert Fourgous
    NA_FO("Nouvelle Affaire Fourgous", "Transfert Fourgous", true, true, true),
    // Versement
    NA("Nouvelle Affaire", "Versement", true, true, true),
    // Versement
    NL("Versement Libre à l'Adhésion", "Versement", true, true, true),
    // Cotisation
    NP("Premier Appel", "Cotisation", true, true, true),
    // Versement
    NT("Versement de transfert Adhésion", "Versement", true, true, true),
    // Rachat
    RA("Rachat Partiel", "Rachat", true, false, true),
    // Résorption d'avance
    RB("RAP/Remboursement Avance", "Résorption d'avance", true, false, true),
    // Rachat
    RP("Rachat Programmé", "Rachat", true, false, true),
    // Rachat
    RT("Rachat Total", "Rachat", true, false, true),
    // Sinistre
    SI("Sinistre", "Sinistre", true, false, true),
    // Transfert de profil
    TP("Transfert de Profil", "Transfert de Profil", true, true, true),
    // Transfert
    TR("Transfert", "Transfert", true, true, true),
    // Versement
    VC("Versement de Cotisation", "Versement", true, true, true),
    // Versement
    VL("Versement Libre", "Versement", true, true, true),
    // Versement
    VP("Versement Programmé", "Versement", true, true, true),
    // Versement
    VT("Versement de Transfert", "Versement", true, true, true),
    // Prélèvements sociaux Actif Général
    RA_PS("Rachat Partiel Prélèvements sociaux", "Prélèvements sociaux Actif Général", true, true, true),
    //
    RA_RE("Rachat résidence principale", "Rachat résidence principale", true, true, true),
    RA_KF("LIQUID FRAC DDE", "Capital franctionnant", true, true, true);

    private String libelleOutil;
    private String libelleFront;
    private boolean avecMontant;
    private boolean avecDetail;
    private boolean afficher;

    public static CodeTypeOperationMDPType getTypeOperationFromCode(String code) {
        for (CodeTypeOperationMDPType operationMDPType : values()) {
            if (operationMDPType.name().equals(code))
                return operationMDPType;
        }
        return null;
    }


}
