package fr.ag2rlamondiale.trm.domain.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;

import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

public interface IContrat {
    ContratId getContratId();

    @SuppressWarnings("squid:S1452")
    List<? extends ICompartiment<? extends IContrat>> getCompartiments();

    AffichageType getAffichageType();

    String getPersonId();

    String getTypeContrat();

    String getNumGenContrat();

    MetierContratType getMetierContrat();

    String getIdAdherente();

    default String getIdCollege() {
        return null;
    }

    String getCodeFiliale();

    String getCodeProduit();

    String getLibelleProduit();

    String getIdContractante();

    String getRaisonSocialeFront();

    String getDescriptionFront();

    default SituationContratEnum getEtatContrat() {
        return SituationContratEnum.EN_COURS;
    }

    boolean isPacte();

    default CodeSiloType getCodeSilo() {
        return getContratId().getCodeSilo();
    }

    default String getNomContrat() {
        return getContratId().getNomContrat();
    }

    default boolean isEre() {
        return CodeSiloType.ERE.equals(getCodeSilo());
    }

    default boolean isMdpro() {
        return CodeSiloType.MDP.equals(getCodeSilo());
    }

    default boolean is(CodeSiloType codeSilo) {
        return codeSilo.equals(getCodeSilo());
    }

    @SuppressWarnings("squid:S1452")
    default ICompartiment<? extends IContrat> getCompartiment(CompartimentId compartimentId) {
        return getCompartiments().stream()
                .filter(compartiment -> compartimentId.equals(compartiment.getCompartimentId()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Impossible de récupérer le compartiment " + compartimentId + " pour " + this));
    }

    @SuppressWarnings("squid:S1452")
    default Optional<? extends ICompartiment<? extends IContrat>> findFirstCompartiment(CompartimentType compartimentType) {
        return compartiments(compartimentType)
                .stream()
                .findFirst();
    }

    @SuppressWarnings("squid:S1452")
    default Collection<? extends ICompartiment<? extends IContrat>> compartiments(CompartimentType compartimentType) {
        return getCompartiments().stream()
                .filter(compartiment -> compartimentType.equals(compartiment.getType()))
                .collect(Collectors.toList());
    }

    default String getIdAssureNonPacte() {
        if (!isPacte() && isEre()) {
            return getCompartiments().stream()
                    .map(compartiment -> compartiment.getCompartimentId().getIdAssure())
                    .filter(Objects::nonNull)
                    .findAny()
                    .orElse(null);
        }

        return null;
    }

    /**
     * Retourne n'importe quel identifiant assure d'un des compartiments d'un contrat pacte ou non pacte
     * Necessaire pour workflow ou sigelec (il en faut un)
     *
     * @return
     */
    default String getIdentifiantAssureParDefaut() {
        return null;
    }

    default boolean isContrat(ContratId contratId) {
        Objects.requireNonNull(contratId);
        if (isEre() && isPacte()) {
            return getContratId().equals(contratId.toBuilder().idCollege(null).build());
        }
        return getContratId().equals(contratId);
    }

    /**
     * Test si le contrat a le meme nomContrat et s'il y a un idCollege renseigné pour les ERE Non pacte
     * @param contratParamsUrl
     * @return
     */
    default boolean match(ContratParamsUrl contratParamsUrl) {
        Objects.requireNonNull(contratParamsUrl);
        if (!getNomContrat().equals(contratParamsUrl.getContrat())) {
            return false;
        }
        if (isEre() && !isPacte() && contratParamsUrl.getIdCollege() != null) {
            return contratParamsUrl.getIdCollege().equals(getIdCollege());
        }
        return true;
    }
}
