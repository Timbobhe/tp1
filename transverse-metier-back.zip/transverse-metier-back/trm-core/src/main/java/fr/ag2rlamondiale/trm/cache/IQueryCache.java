package fr.ag2rlamondiale.trm.cache;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.cache.Cache;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.KeyGenerator;

import java.lang.reflect.Method;
import java.util.function.BiConsumer;

public interface IQueryCache {

    static String[] cacheNames(Cacheable cacheable) {
        if (cacheable.value().length > 0) {
            return cacheable.value();
        } else if (cacheable.cacheNames().length > 0) {
            return cacheable.cacheNames();
        }
        return new String[0];
    }

    default boolean isCached(ProceedingJoinPoint joinPoint) {
        final Object target = joinPoint.getTarget();
        final MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        final Method method = signature.getMethod();
        final Object[] params = joinPoint.getArgs();

        return isCached(target, method, params);
    }

    boolean isCached(Object target, Method method, Object[] params);

    void withCache(Object target, Method method, Object[] params, BiConsumer<Cache, Object> consumer);

    void withCache(CacheEvict cacheEvict, Object[] params, BiConsumer<Cache, Object> consumer);

    KeyGenerator keyGenerator(String name);
}
