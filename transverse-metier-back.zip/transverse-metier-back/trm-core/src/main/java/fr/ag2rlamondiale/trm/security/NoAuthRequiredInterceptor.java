package fr.ag2rlamondiale.trm.security;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
public class NoAuthRequiredInterceptor implements Ordered {

    @Autowired
    private UserContextHolder userContextHolder;


    @Around("@annotation(noAuthRequired)")
    public Object aroundAdvice(ProceedingJoinPoint joinPoint, NoAuthRequired noAuthRequired) throws Throwable {
        final UserContext prev = userContextHolder.get();
        try {
            userContextHolder.setDisconnectUserContext();
            return joinPoint.proceed();
        } finally {
            userContextHolder.set(prev);
        }
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.SECURE_ORDER;
    }
}
