package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.namespace.QName;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPFault;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import javax.xml.ws.soap.SOAPFaultException;
import java.util.HashSet;
import java.util.Set;

/**
 * Handler permettant de gérer les erreur En cas d'anomalie dans le message, le header du message de
 * retour sera remplie au niveau de la balise "ns1:codeErreur" Ce handler interceptera le code et
 * renverra une Exception appropriée
 */
@Slf4j
public class ErrorHandler extends CommonHandler implements SOAPHandler<SOAPMessageContext> {

    public ErrorHandler() {
        this(-1);
    }

    public ErrorHandler(int maxChars) {
        super(maxChars);
    }

    @Override
    public boolean handleMessage(SOAPMessageContext smc) {
        // Propriete permettant de savoir s il s agit de la requete ou de la
        // reponse
        final boolean isRequest = (Boolean) smc.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        if (!isRequest) {
            try {
                // On regarde s il existe dans la reponse un noeud CodeErreur
                final String codeErreur = getTextNodeHeader(smc, "ns1:CodeErreur");
                // Si l'erreur se termine par "FUNC-TRANSCO-UNKNOWN", c'est à titre d'information
                // La reponse est présente donc on peut l'exploiter
                if (codeErreur != null && !codeErreur.contains("FUNC-TRANSCO-UNKNOWN")) {
                    final String messageErreur = getTextNodeHeader(smc, "ns1:MessageErreur");
                    log.error("HeaderHandler ns1:CodeErreur = {}, ns1:MessageErreur = {}", codeErreur, messageErreur);
                    throwSoapFault(smc.getMessage(), codeErreur, messageErreur);
                }
            } catch (SOAPException e) {
                log.error("ErrorHandler", e);
                throw new RuntimeException(e);
            }
        }

        return true;
    }

    private String getTextNodeHeader(SOAPMessageContext smc, String elementName) throws SOAPException {
        final NodeList nodes = smc.getMessage().getSOAPHeader().getElementsByTagName(elementName);
        if (nodes == null || nodes.getLength() == 0) {
            return null;
        }
        final Node errorCodeNode = nodes.item(0);
        if (errorCodeNode == null || errorCodeNode.getTextContent() == null) {
            return null;
        }

        return errorCodeNode.getTextContent();
    }

    private void throwSoapFault(SOAPMessage msg, String codeErreur, String messageErreur) {
        try {
            SOAPBody soapBody = msg.getSOAPPart().getEnvelope().getBody();
            soapBody.addNamespaceDeclaration("error", "error");
            SOAPFault soapFault = soapBody.addFault();
            soapFault.setFaultCode("error:" + codeErreur);
            soapFault.setFaultString(codeErreur + "(" + messageErreur + ")");

            throw new SOAPFaultException(soapFault);
        } catch (SOAPException e) {
            log.debug("SOAPException", e);
        }
    }

    @Override
    public Set<QName> getHeaders() {
        return new HashSet<>();
    }

    @Override
    public void close(MessageContext context) {
        //Implémentation obligatoire mais pas d'actions à effectuer
    }

}
