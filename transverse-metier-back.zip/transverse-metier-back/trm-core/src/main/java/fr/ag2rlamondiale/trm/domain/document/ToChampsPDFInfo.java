package fr.ag2rlamondiale.trm.domain.document;

public interface ToChampsPDFInfo {
    String getChamps();

    boolean isReadOnly();

    TypeChampsPdfType getType();

    default ChampsPDFInfo toChampsPdfInfo(String valeur) {
        return new ChampsPDFInfo(valeur, isReadOnly(), getType());
    }
}
