package fr.ag2rlamondiale.trm.domain.contrat;


import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;

public interface ICompartiment<C extends IContrat> {

    CompartimentType getType();

    C getContrat();

    CompartimentId getCompartimentId();

    AffichageType getAffichageType();

    String getCollege();

    String getIdCollege();

    boolean isDeductible();

    ContributionType getContributionType();

    default CodeSiloType getCodeSilo() {
        return getContrat().getCodeSilo();
    }

    default String getIdentifiantAssure() {
        final CodeSiloType codeSilo = getCodeSilo();
        if (CodeSiloType.ERE.equals(codeSilo)) {
            return getCompartimentId().getIdAssure();
        }
        return null;
    }
}
