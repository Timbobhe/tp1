package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class FractionnementMapper extends AbstractCsvMapper<String> {
	public FractionnementMapper() {
		super("csv/libelles_fractionnement.csv");
	}

	@Override
	protected AbstractCsvMapper.Key getNewKey(String code, String lang) {
		return new AbstractCsvMapper.Key(code, lang);
	}
}
