package fr.ag2rlamondiale.trm.security;

import lombok.ToString;


@ToString
public class DisconnectUserContext extends UserContext {

    public DisconnectUserContext(String idGdi) {
        this.idGdi = idGdi;
    }

    @Override
    public boolean isConnectedUser() {
        return false;
    }
}
