package fr.ag2rlamondiale.trm.spring;

import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.ConfigurationCondition;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.Objects;

/**
 * Cette condition va s'assurer que l'implémentation fournie par l'application sera la seule existante.<br>
 * A utiliser de concert avec {@link ConditionnalDefaultImpl} car on ne connait pas l'ordre de traitement des beans par Spring.
 */
public class ConditionnalAppImpl implements ConfigurationCondition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        MultiValueMap<String, Object> attrs = metadata.getAllAnnotationAttributes(AppImpl.class.getName());
        if (attrs != null) {
            final ConfigurableListableBeanFactory beanFactory = Objects.requireNonNull(context.getBeanFactory());

            Class<?> implemtationOf = null;
            for (Object value : attrs.get("implemtationOf")) {
                implemtationOf = (Class<?>) value;
                try {
                    final String[] beanNamesForType = beanFactory.getBeanNamesForType(implemtationOf);
                    removeDefaultImpl(context, beanFactory, Arrays.asList(beanNamesForType));

                } catch (NoUniqueBeanDefinitionException e) {
                    removeDefaultImpl(context, beanFactory, Objects.requireNonNull(e.getBeanNamesFound()));
                } catch (NoSuchBeanDefinitionException e) {
                    return true;
                }
            }

            if (implemtationOf != null) {
                try {
                    // On vérifie qu'il ne reste plus qu'une implémentation
                    final Object bean = beanFactory.getBean(implemtationOf);
                    // et que c'est l'implémentation fournié par l'application
                    Objects.requireNonNull(bean.getClass().getAnnotation(AppImpl.class));
                } catch (NoSuchBeanDefinitionException e) {
                    // Ou bien qu'il n'en reste plus et donc on fournie l'implémentation de l'Application
                    return true;
                }
            }
        }

        return true;
    }

    private void removeDefaultImpl(ConditionContext context, ConfigurableListableBeanFactory beanFactory, Iterable<String> beanNamesForType) {
        for (String beanName : beanNamesForType) {
            final Object bean = beanFactory.getBean(beanName);
            removeDefaultImpl(context, beanName, bean);
        }
    }


    private void removeDefaultImpl(ConditionContext context, String beanName, Object bean) {
        final DefaultImpl defaultImpl = bean.getClass().getAnnotation(DefaultImpl.class);
        if (defaultImpl != null && beanName != null) {
            context.getRegistry().removeBeanDefinition(beanName);
        }
    }

    @Override
    public ConfigurationPhase getConfigurationPhase() {
        return ConfigurationPhase.REGISTER_BEAN;
    }
}
