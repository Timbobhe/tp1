package fr.ag2rlamondiale.trm.domain.exception;

/**
 * Exception leve lors d'une menace securite. Exemple : un utilisateur X essaye de consulter des
 * contrats d'un utilisateur Y.
 */
public class ContextNotInitializedException extends RuntimeException {
    private static final long serialVersionUID = 6633547181423306065L;

    public ContextNotInitializedException(String message, Throwable cause) {
        super(message, cause);
    }

    public ContextNotInitializedException(String message) {
        super(message);
    }

    public ContextNotInitializedException(Throwable cause) {
        super(cause);
    }

    public ContextNotInitializedException() {
        super();
    }
}
