package fr.ag2rlamondiale.trm.security;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import org.aspectj.lang.JoinPoint;

public interface UserSecurityService {
    boolean isAuthorized(JoinPoint joinPoint, Secure secure);

    void initSecurityContext(String idGdi, PersonnePhysique personnePhysique) throws TechnicalException;

    void initSecurityContext(UserTestManager userTestManager);
}
