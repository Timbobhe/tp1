package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.Data;

import java.io.Serializable;

/**
 * Classe qui va contenir la piece jointe fournit par un web service
 */
@Data
public class AttachmentResponse implements Serializable {
    private static final long serialVersionUID = -1312055424503206385L;

    private byte[] attachment;

}
