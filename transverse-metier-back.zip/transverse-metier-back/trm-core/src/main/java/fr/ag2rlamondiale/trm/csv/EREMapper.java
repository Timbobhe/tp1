package fr.ag2rlamondiale.trm.csv;

import java.util.List;

public interface EREMapper {
    <T> T map(Object source, Class<T> destinationClass);

    <T> List<T> mapList(Object source, Class<T> destinationClass);
}
