package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class EtatCompteCsvMapper extends AbstractCsvMapper<String> {
    public EtatCompteCsvMapper() {
        super("csv/libelles_etat_compte.csv");
    }

    @Override
    protected AbstractCsvMapper.Key getNewKey(String code, String lang) {
        return new AbstractCsvMapper.Key(code, lang);
    }
}
