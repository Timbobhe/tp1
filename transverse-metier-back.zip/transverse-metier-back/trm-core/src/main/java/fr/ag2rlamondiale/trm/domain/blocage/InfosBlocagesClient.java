package fr.ag2rlamondiale.trm.domain.blocage;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import lombok.Data;

import java.io.Serializable;
import java.util.*;

@Data
public class InfosBlocagesClient implements Serializable {

    private static final long serialVersionUID = 2698224213347487017L;

    @JsonIgnore
    private Map<CodeSiloType, Boolean> isPersonneTotalementBloqueeParSilo = new EnumMap<>(CodeSiloType.class);

    private boolean isPersonneTotalementBloquee;

    private boolean isToutLesContratsTotalementsBloques;

    private Set<String> fonctionnalitesBloqueesALaPersonne = new HashSet<>();

    // Si un contrat est bloque sur toutes les fonctionnalites, la liste sera vide
    private Map<String, Set<String>> fonctionnalitesBloqueesContrats = new HashMap<>();

    private Set<String> fonctionnalitesBloqueesPartenaire = new HashSet<>();

    private Set<String> fonctionnalitesBloqueesTousContrats = new HashSet<>();

	public boolean isFonctionnaliteBloqueePourContrat(String idContrat, FonctionnaliteType fonctionnaliteType) {
		return isFonctionnaliteBloqueePourContrat(idContrat, fonctionnaliteType.getLabel());
	}

	public boolean isFonctionnaliteBloqueePourContrat(String idContrat, String codeFonctionnalite) {
		if (isPersonneTotalementBloquee() || isToutLesContratsTotalementsBloques()) {
			return true;
		}

		if (fonctionnalitesBloqueesPartenaire != null && fonctionnalitesBloqueesPartenaire.contains(codeFonctionnalite)) {
			return true;
		}
		if (fonctionnalitesBloqueesTousContrats != null && fonctionnalitesBloqueesTousContrats.contains(codeFonctionnalite)) {
			return true;
		}
		if (fonctionnalitesBloqueesALaPersonne != null && fonctionnalitesBloqueesALaPersonne.contains(codeFonctionnalite)) {
			return true;
		}
		if (fonctionnalitesBloqueesContrats != null) {
			final Set<String> codes = fonctionnalitesBloqueesContrats.get(idContrat);
			return codes != null && (codes.isEmpty() || codes.contains(codeFonctionnalite));
		}
		return false;
	}
}
