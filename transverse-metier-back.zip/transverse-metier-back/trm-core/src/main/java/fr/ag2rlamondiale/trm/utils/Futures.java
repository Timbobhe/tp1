package fr.ag2rlamondiale.trm.utils;

import com.ag2r.common.exceptions.TechnicalException;
import lombok.extern.slf4j.Slf4j;

import java.util.Collection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

@Slf4j
public class Futures {

    private Futures() {

    }

    public static void join(Future<?>... futures) throws ExecutionException, InterruptedException {
        for (Future<?> future : futures) {
            future.get();
        }
    }

    public static void join(Collection<? extends Future<?>> futures) throws ExecutionException, InterruptedException {
        for (Future<?> future : futures) {
            future.get();
        }
    }

    public static <V> V get(Future<V> future) throws TechnicalException {
        try {
            return future.get();
        } catch (InterruptedException e) {
            log.error("Interruption", e);
            Thread.currentThread().interrupt();
            throw new TechnicalException(e);
        } catch (ExecutionException e) {
            throw new TechnicalException(e.getCause());
        }
    }
}
