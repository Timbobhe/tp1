package fr.ag2rlamondiale.trm.cache;

public class CacheException extends RuntimeException {

    public CacheException(String message) {
        super(message);
    }
}
