package fr.ag2rlamondiale.trm.security;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/** Classe où on stocke les données de références ou de confiance pour securisé les appels WS. */
@Getter
//@Setter(value = AccessLevel.PACKAGE)
@Setter
@ToString
@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class UserSecurityContext implements Serializable {

    private static final long serialVersionUID = -4782822022330658544L;

    private boolean isContextActive;
    private String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
    private Set<String> idContrats = new HashSet<>();
    private Set<String> idAssures = new HashSet<>();

    public void clear() {
        isContextActive = false;
        idGdi = null;
        idContrats = new HashSet<>();
        idAssures = new HashSet<>();
    }
}
