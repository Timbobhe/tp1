package fr.ag2rlamondiale.trm.domain;

import lombok.Getter;

@Getter
public enum CodeLangueType {
    FRANCAIS("FRA");

    private final String libelle;

    private CodeLangueType(String libelle) {
        this.libelle = libelle;
    }
}
