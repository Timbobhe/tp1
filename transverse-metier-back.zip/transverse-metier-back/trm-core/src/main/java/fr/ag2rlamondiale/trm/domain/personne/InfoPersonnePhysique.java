package fr.ag2rlamondiale.trm.domain.personne;

import fr.ag2rlamondiale.trm.csv.DepartementType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;

import java.util.Date;

public interface InfoPersonnePhysique {
    String getId();

    CodeSiloType getCodeSilo();

    String getNomNaissance();

    String getNom();

    String getPrenom();

    Date getDateDeNaissance();

    String getCivilite();

    DepartementType getDepartementNaissance();

    default String getEmailSigElec() {
        if (CodeSiloType.ERE.equals(getCodeSilo())) {
            return getEmailPro();
        }
        return getEmailPerso();
    }

    String getEmailPro();

    String getEmailPerso();

    String getTelPortable();
}
