package fr.ag2rlamondiale.trm.domain.upload;

import com.google.common.base.MoreObjects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UploadFileResponseDto {
    private String fileName;
    private String fileContent;
    private State state;
    private UploadErrorType errorTag;

    public enum State {
        OK, KO, UNKNOWN;
    }

    public enum UploadErrorType {
        PJ_TAILLE_KO,
        PJ_EXTENSION_KO,
        PJ_CORRUPTED_FILE,
        PJ_DOUBLON_FILE,
        PJ_NULL_OR_EMPTY,
        PJ_TAILLE_ALL_KO,
        PJ_UNKNOWN
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("fileName", fileName)
                .add("fileContent", isNotBlank(fileContent) ? "<FILECONTENT>" : null)
                .add("state", state)
                .add("errorTag", errorTag)
                .toString();
    }
}
