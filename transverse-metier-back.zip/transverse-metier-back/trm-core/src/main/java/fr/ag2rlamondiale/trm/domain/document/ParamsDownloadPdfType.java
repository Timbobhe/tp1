package fr.ag2rlamondiale.trm.domain.document;

public enum ParamsDownloadPdfType {
    TYPE_DOCUMENT("typeDocument"),
    ID_CONTRAT("idContrat"),
    ID_SILO("idSilo"),
    ID_ASSURE("idAssure"),
    ID_PERSONNE("idPersonne"),
    NUM_ADHERENTE("numAdherente"),
    CODES_ISIN("codesIsin"),
    CODES_SUPPORT("codesSupport"),
    SOURCE("source"),
    CODE_PRODUIT("codeProduit"),
    CODE_FILIALE("codeFiliale"),
    CODE_DESTINATAIRE("codeDestinataire"),
    CODE_LANGUE("codeLangue"),
    URL_DOC("urlDoc"),
    URLS_DOC("urlsDoc"),
    CANAL_ARRIVEE_DOC("CanalArriveeDocument", true),
    COLLEGE("codeCategoriePersonnel"),
    ID_CONTRACTANTE("idContractante"),
    QRCODE("QRCODE"),
    DATE_DE_CREATION("dateDeCreation", true),
    ID_DOC("idDoc"),
    TITULAIRE_COMPTE("Titulaire_Compte"),
    CODE_IBAN("IBAN"),
    CODE_BIC("codeBIC"),
    LOGO("LOGO"),
    ADRESSE_COURRIER("AdresseCourrier"),
    ADR_LEGALE("AdrLegale"),
    CONSENTEMENTS("Consentements"),
    CUSTOM_PREFIX("customPrefix"),
    SEPA_ADRESSE_1("SEPA_Adresse_1"),
    SEPA_ADRESSE_2("SEPA_Adresse_2"),
    SEPA_ADRESSE_3("SEPA_Adresse_3"),
    SEPA_ADRESSE_PAIEMENT("SEPA_Adresse_Paiement");

    private final String libelle;
    private final boolean otherCriteria;

    ParamsDownloadPdfType(String libelle) {
        this(libelle, false);
    }

    ParamsDownloadPdfType(String libelle, boolean otherCriteria) {
        this.libelle = libelle;
        this.otherCriteria = otherCriteria;
    }

    public String getLibelle() {
        return libelle;
    }

    public boolean isOtherCriteria() {
        return otherCriteria;
    }

    public static boolean isOtherTextCriteria(String text) {
        final ParamsDownloadPdfType p = fromString(text);
        return p != null && p.otherCriteria;
    }

    public static ParamsDownloadPdfType fromString(String text) {
        if (text != null) {
            for (ParamsDownloadPdfType element : ParamsDownloadPdfType.values()) {
                if (element.getLibelle().equalsIgnoreCase(text)) {
                    return element;
                }
            }
        }
        return null;
    }
}
