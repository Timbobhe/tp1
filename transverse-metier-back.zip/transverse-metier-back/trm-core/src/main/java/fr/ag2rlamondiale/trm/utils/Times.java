package fr.ag2rlamondiale.trm.utils;

import lombok.SneakyThrows;

import java.util.concurrent.Callable;
import java.util.function.LongConsumer;

public class Times {
    private Times() {
        // utils
    }

    @SneakyThrows
    public static <T> T timeSpent(Callable<T> runnable, LongConsumer consumeTime) {
        final long s = System.currentTimeMillis();
        final T res = runnable.call();
        final long e = System.currentTimeMillis();
        consumeTime.accept(e - s);
        return res;
    }
}
