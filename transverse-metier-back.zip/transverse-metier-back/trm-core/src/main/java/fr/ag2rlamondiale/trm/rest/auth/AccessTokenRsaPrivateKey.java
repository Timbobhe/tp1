package fr.ag2rlamondiale.trm.rest.auth;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccessTokenRsaPrivateKey implements IAccessTokenProvider {

    @Autowired
    private PfsTokenBuilder pfsTokenBuilder;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private ISupplierLibService supplierLibService;

    @Override
    public AccessTokenType getAccessTokenType() {
        return AccessTokenType.RSA_PRIVATE_KEY;
    }

    @Override
    public String getAccessToken(PfsRestServiceConfig pfsRestServiceConfig) {
        return pfsTokenBuilder.generateToken(getClaims(), pfsRestServiceConfig);
    }

    public PfsTokenClaims getClaims() {
        PfsTokenClaims pfsTokenClaims = new PfsTokenClaims();
        final String codeCassiniAppli = supplierLibService.getCodeCassiniAppli();
        pfsTokenClaims.setCodeCassiniAppli(codeCassiniAppli);

        final UserContext userContext = userContextHolder.get();
        if (userContext.getIdGdi() != null) {
            pfsTokenClaims.setIdGdi(userContext.getIdGdi());
        } else if (userContext.getPartenaire() != null) {
            pfsTokenClaims.setCodePartenaire(userContext.getPartenaire().getCodePartenaire());
        }
        return pfsTokenClaims;
    }
}
