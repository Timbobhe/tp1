package fr.ag2rlamondiale.trm.client.soap.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.HandlerResolver;
import javax.xml.ws.handler.PortInfo;
import java.util.ArrayList;
import java.util.List;

/**
 * Service qui va fournir la chaine de Handler a appliquer pour le traitement des requetes et
 * reponses Soap
 * <p>
 * Attention : La methode getHandlerChain sera appelee lors de l instanciation du port et supprimera
 * tous les handlers precedement enregistres
 * <p>
 * Pour ajouter un nouveau Handler, il faudra appeler la methode getHandlers et faire un ajout dans
 * cette liste apres l instanciation du port (Sous peine que le handler ne soit pas execute si l
 * ajout est effectue avant l instanciation du port)
 * <p>
 * Par defaut, la chaine de Handler executera les handlers dans l ordre qui suit :
 * <p>
 * Pour les messages sortants : - Execution des handlers ajoutes par l utilisateur dans l ordre
 * decroissant d insertion - Execution du HeaderHandler - Execution du LoggerHandler
 * <p>
 * Pour les messages entrants : - Execution du LoggerHandler - Execution du ErrorHandler - Execution
 * des handlers ajoutes par l utilisateur dans l ordre croissant d insertion
 *
 * @author CORNE
 */
@SuppressWarnings("rawtypes")
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class SoapClientHandlerResolver implements HandlerResolver {
    private List<Handler> additionnalHandlers = new ArrayList<>();

//    @Setter
//    @Autowired
//    private HeaderHandlerFactory headerHandlerFactory;

    @Value("${soap.log.limit.chars.size:30000}")
    private int maxChars;

    public SoapClientHandlerResolver() {
        /* Constructeur vide */
    }

    @Override
    public List<Handler> getHandlerChain(PortInfo ignore) {
        return getHandlerChain(true);
    }

    public List<Handler> getHandlerChain(boolean enableLog) {
        List<Handler> handlers = new ArrayList<>();

        // Ajout des handlers supplementaires
        if (!additionnalHandlers.isEmpty()) {
            handlers.addAll(additionnalHandlers);
        }

        // Ajout des handlers de base requis pour tous les services
        handlers.add(new ErrorHandler(maxChars));
        handlers.add(new LoggerHandler(maxChars, enableLog));

        return handlers;
    }

    /**
     * Ajoute un handler a la liste
     *
     * @return chaine des handlers
     */
    public void addHandler(Handler handler) {
        additionnalHandlers.add(handler);
    }
}
