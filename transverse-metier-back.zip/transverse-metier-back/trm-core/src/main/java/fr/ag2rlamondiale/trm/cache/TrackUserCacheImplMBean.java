package fr.ag2rlamondiale.trm.cache;

public interface TrackUserCacheImplMBean {

    void setEnable(boolean enable);

    boolean isEnable();

    void logUserCacheEntries();

    void logUserCacheEntries(String idGdi);

}
