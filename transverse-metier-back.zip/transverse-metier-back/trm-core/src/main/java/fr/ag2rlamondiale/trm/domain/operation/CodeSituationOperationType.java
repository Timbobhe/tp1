/*
 * Cree le 20 déc. 2018.
 * (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.operation;

public enum CodeSituationOperationType {
    // Valorisé
    VALOR("V"),
    // Enregistrée
    ENREG("E"),
    // Estimée
    ESTIME("M"),
    // A recalculer
    ARECAL("C"),
    // Partiellement valorisé
    PRTVLR("P"),
    // En attente
    ATTENT("T"),
    // Annulé
    ANNULE("A"),
    // A traiter (specifique)
    ATRSPE("0"),
    // Traite (specifique)
    TRASPE("1"),
    // Annule (specifique)
    ANLSPE("2");

    private String codeSilo;

    private CodeSituationOperationType(final String codeSilo) {
        this.codeSilo = codeSilo;
    }

    public static CodeSituationOperationType fromString(String value) {
        for (CodeSituationOperationType item : CodeSituationOperationType.values()) {
            if (item.name().equals(value)) {
                return item;
            }
        }
        return null;
    }

    public String getCodeSilo() {
        return codeSilo;
    }
}
