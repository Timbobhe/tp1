package fr.ag2rlamondiale.trm.domain.personne;

import lombok.Data;

@Data
public class RequetePersonnePhysique {

    private String idGDI;
    private String numeroPersonneEre;
}
