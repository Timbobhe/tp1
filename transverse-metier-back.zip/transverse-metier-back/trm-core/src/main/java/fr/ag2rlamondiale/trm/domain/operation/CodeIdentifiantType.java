package fr.ag2rlamondiale.trm.domain.operation;

import lombok.Getter;

@Getter
public enum CodeIdentifiantType {
    AFFILIE("AFFILIE"),
    ECHEANCIER("ECHEANCIER PRIME"),
    OPERATION("OPERATION"),
    CONTRAT("CONTRAT"),
    PERSONNE("PERSONNE");

    private String libelle;

    private CodeIdentifiantType(String libelle) {
        this.libelle = libelle;
    }
}
