package fr.ag2rlamondiale.trm.csv;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.LinkedHashSet;
import java.util.Map.Entry;
import java.util.Set;

/**
 * Classe d'import des codes et libellés de référence pour les pays.
 */
@Component
public class PaysMapper extends AbstractCsvMapper<PaysMapper.Pays> {
    private static final String LIBELLE_FR = "FRANCE";
    private static final String FR_ISO = "FRA";
    private static final Pays LIBELLE_FR_ISO = new Pays(LIBELLE_FR, FR_ISO);

    /**
     * Classe de parsing du fichier de référence.
     */
    public PaysMapper() {
        super("csv/codes_pays.csv");
    }

    @Override
    protected void processLine(String line) {
        String[] items = line.split(";");
        String code = items[0];
        String lang = items[1];
        String label = items[2];
        String iso = items[3];
        values.put(getNewKey(code, lang), new Pays(label, iso));
    }

    public String getLabelPays(Key input) {
        Pays p = values.get(input);
        return p != null ? p.getLabel() : null;
    }

    public boolean isPaysEtranger(String iso) {
        return iso != null && !FR_ISO.equals(iso);
    }

    /**
     * Retourne le code ISO pays correspondant à un code INSEE pays.
     *
     * @param code INSEE du pays
     * @return le code ISO pays
     */
    public String getIso(String code) {
        Pays paysIso = getValueFR(code);
        return paysIso != null ? paysIso.getIso() : null;
    }

    /**
     * Retourne l'ensemble des libellés de pays de référence triés par ordre alphabétique.
     *
     * @return la liste des libellés
     */
    public Set<String> getLabels() {
        Set<Pays> brut = getAllValues();
        brut.remove(LIBELLE_FR_ISO);

        Set<String> filtre = new LinkedHashSet<>();

        filtre.add("");
        filtre.add(LIBELLE_FR);
        for (Pays pays : brut) {
            filtre.add(pays.getLabel());
        }
        return filtre;
    }

    /**
     * Retourne le code pays correspondant à un label pays.
     *
     * @param value label du pays
     * @return le code pays
     */
    public Key getKeyFromValue(String value) {
        if (value != null) {
            for (Entry<Key, Pays> entry : values.entrySet()) {
                if (value.equals(entry.getValue().getLabel())) {
                    return entry.getKey();
                }
            }
        }
        return null;
    }

    /**
     * Retourne le code pays correspondant à un label pays.
     *
     * @param label du pays
     * @return le code pays
     */
    public String getCodeFromLabel(String label) {
        final Key key = getKeyFromValue(label);
        return key != null ? key.getCode() : null;
    }

    @AllArgsConstructor
    @Data
    @Getter
    public static class Pays implements Comparable<Pays> {
        private String label;
        private String iso;

        @Override
        public int compareTo(Pays o) {
            final int i = label.compareTo(o.getLabel());
            if (i != 0) {
                return i;
            }
            return iso.compareTo(o.getIso());
        }
    }

}
