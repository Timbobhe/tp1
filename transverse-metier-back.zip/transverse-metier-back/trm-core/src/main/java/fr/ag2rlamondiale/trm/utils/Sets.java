package fr.ag2rlamondiale.trm.utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Sets {

    private Sets() {
        // utility class
    }

    @SafeVarargs
    public static <E> Set<E> set(E... elements) {
        return new HashSet<>(Arrays.asList(elements));
    }


    @SafeVarargs
    public static <E> Set<E> unmodifiableSet(E... elements) {
        return Collections.unmodifiableSet(set(elements));
    }


    @SafeVarargs
    public static <E> Set<E> concat(Set<E>... sets) {
        Set<E> s = new HashSet<>();
        for (Set<E> set : sets) {
            s.addAll(set);
        }
        return s;
    }

}
