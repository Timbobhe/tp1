package fr.ag2rlamondiale.trm.spring;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Cette annotation indique qu'il s'agit de <b>l'implémentation fournie par l'application</b>.<br>
 * A utiliser conjointement avec {@link ConditionnalAppImpl} de la manière suivante :
 *
 * <pre>{@code
 * @Service
 * @Conditional(ConditionnalAppImpl.class)
 * @AppImpl(implemtationOf = IDownloadDocumentFacade.class)
 * public class DownloadDocumentFacadeImpl implements IDownloadDocumentFacade {
 * }</pre>
 */
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface AppImpl {
    Class implemtationOf();
}
