package fr.ag2rlamondiale.trm.domain;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum FonctionnaliteType {
    SYNTHESE("SyntheseDesComptes", "/#/synthese-des-comptes"),
    COMPLETER_BIA("completerBIA", "/#/bulletin-affiliation"),
    SIGELEC_COMPLETER_BIA("completerBIASigElec", "/#/bulletin-affiliation"),
    VERSEMENT("versement", "/#/versement"),
    CARTE_BANCAIRE("carteBancaire", ""),
    VERSEMENT_LIBRE("versementLibre", "/#/versement"),
    VERSEMENT_PROGRAMME("versementProgramme", "/#/versement"),
    ARRET_VERSEMENT_PROGRAMME("arretVersement", "/#/arret-versement"),
    SIGELEC_VERSEMENT("versementSigElec", "/#/versement"),
    SIGELEC_VERSEMENT_LIBRE("versementLibreSigElec", "/#/versement"),
    SIGELEC_VERSEMENT_PROGRAMME("versementProgrammeSigElec", "/#/versement"),
    ARBITRAGE("Arbitrage", "/#/modification-gestion-financiere"),
    SIGELEC_ARBITRAGE("ArbitrageSigElec", "/#/modification-gestion-financiere"),
    MODIFDONNEESPERSO("ModifDonneesPerso", ""),
    MODIFICATION_CLAUSE_BENEFICIAIRE("ClauseBeneficiaire", ""),
    SIGELEC_MODIFIER_CLAUSE_BENEF("ClauseBeneficiaireSigElec", ""),
    COORDONNEES_BANCAIRES("VosCoordonneesBancaires", "/#/coordonnees-bancaires"),
    MODIFIER_RIB("ModifierRIB", ""),
    VOS_DONNEES_VERSEMENT("VosDonneesVersement", "/#/vos-donnees/vos-versements"),
    BYPASS_SIGELEC("bypassSigelec", ""),
    TOUT_PARCOURS_SIMPLIFIE("ToutParcoursSimplifie", ""),
    ARBITRAGE_SIMPLIFIE("ArbitrageSimplifie", ""),
    VERSEMENT_SIMPLIFIE("VersementSimplifie", ""),
    BIA_SIMPLIFIE("BiaSimplifie", ""),
    ONBOARDING_SIMPLIFIE("OnboardingSimplifie", ""),
    DETAILS_CONTRAT("DetailsContrat", ""),
    SIMULATEUR_FISCAL("SimulateurFiscal", ""),
    SIMULATEUR_OPTION_RENTE("SimulateurOptionRente", ""),
    SIMULATEUR_RENTE_VIF("SimulateurRenteVIF","");


    private final String label;
    private final String baseUrl;

    FonctionnaliteType(String label, String baseUrl) {
        this.label = label;
        this.baseUrl = baseUrl;
    }

    @JsonCreator
    public static FonctionnaliteType fromLabel(String label) {
        for (FonctionnaliteType value : values()) {
            if (value.getLabel().equalsIgnoreCase(label)) {
                return value;
            }
        }

        throw new IllegalArgumentException(label + " label inconnu");
    }

    @JsonValue
    public String getLabel() {
        return label;
    }
}
