package fr.ag2rlamondiale.trm.domain.csv;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LibelleSupportInvestissement implements Serializable {
	private static final long serialVersionUID = -4708341589045290864L;

	@NonNull
	private String id;

	@NonNull
	private String libelle;

	@NonNull
	private String langue;

	@NonNull
	private String libelleFront;
}
