package fr.ag2rlamondiale.trm.domain.exception;

public class ContratException extends Exception {
    private static final long serialVersionUID = 2828924081883097610L;

    public static final String CANT_FIND_CONTRACTS = "Can't find documents";
    public static final String NO_PARAMETERS = "Empty arguments";

    public ContratException(String message, Throwable cause) {
        super(message, cause);
    }

    public ContratException(String message) {
        super(message);
    }

    public ContratException(Throwable cause) {
        super(cause);
    }
}
