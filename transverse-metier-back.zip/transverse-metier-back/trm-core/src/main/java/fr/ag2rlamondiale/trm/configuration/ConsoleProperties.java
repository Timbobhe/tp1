package fr.ag2rlamondiale.trm.configuration;


import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Objects;

@Slf4j
@Data
@Component("consoleProps")
public class ConsoleProperties {
    @Value("${consolev2.active:false}")
    private boolean consoleV2Active = false;

    @Value("${consolev2.api.url:#{null}}")
    private String consoleV2ApiUrl;

    @Value("${demo.active:false}")
    private boolean demoActive;

    @PostConstruct
    public void valid() {
        log.info("consolev2.active={}", consoleV2Active);
        log.info("consolev2.api.url={}", consoleV2ApiUrl);
        log.info("demo.active={}", demoActive);

        if (!consoleV2Active) {
            return;
        }

        Objects.requireNonNull(consoleV2ApiUrl, "consolev2.api.url");
    }
}
