package fr.ag2rlamondiale.trm.jahia;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public class DefaultJahiaUrlConnection implements JahiaUrlConnection {
    @Override
    public HttpURLConnection getUrlConnection(URL url) throws IOException {
        return (HttpURLConnection) url.openConnection();
    }
}
