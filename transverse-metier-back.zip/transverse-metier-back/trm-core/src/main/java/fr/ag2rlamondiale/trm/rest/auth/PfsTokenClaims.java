package fr.ag2rlamondiale.trm.rest.auth;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PfsTokenClaims {
    private String codeCassiniAppli;
    private String idGdi;
    private String codePartenaire;
}
