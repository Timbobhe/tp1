/*
 * Cree le 9 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.personne.detail;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * POJO de Détail Client utilisé dans la Recherche des Personnes Physiques Utilise les POJO Adresse,
 * Téléphone & Email
 */
@Data
public class Details {
    @JsonProperty(value = "civilite")
    String civilite;

    @JsonProperty(value = "nom")
    String nom;

    @JsonProperty(value = "nomJeuneFille")
    String nomJeuneFille;

    @JsonProperty(value = "prenom")
    String prenom;

    @JsonProperty(value = "sexe")
    String sexe;

    @JsonProperty(value = "dateNaissance")
    @JsonSerialize(using = DateUtils.class)
    Date dateNaissance;

    @JsonProperty(value = "cpNaissance")
    String cpNaissance;

    @JsonProperty(value = "codeINSEEVilleNaissance")
    String codeINSEEVilleNaissance;

    @JsonProperty(value = "identiteConfirme")
    Boolean identiteConfirme;

    @JsonProperty(value = "villeNaissance")
    String libelleVilleNaissance;

    @JsonProperty(value = "nationalite")
    String nationalite;

    @JsonProperty(value = "paysResidenceFiscale")
    String paysResidenceFiscale;

    @JsonProperty(value = "nir")
    String nir;

    @JsonProperty(value = "etat")
    String etat;

    @JsonProperty(value = "siren")
    String siren;

    @JsonProperty(value = "siret")
    String siret;

    @JsonProperty(value = "codeApe")
    String codeApe;

    @JsonProperty(value = "adresse")
    Address address;

    @JsonIgnore
    String codePostal;

    @JsonProperty(value = "domicileConfirme")
    Boolean domicileConfirme;

    @JsonProperty(value = "telephones")
    List<Telephone> telephones;

    @JsonProperty(value = "emails")
    List<Email> emails;

    public Details() {
        this.telephones = new ArrayList<>();
        this.emails = new ArrayList<>();
    }
}
