package fr.ag2rlamondiale.trm.utils;

import com.google.common.hash.Hashing;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class SecurityUtils {
    private SecurityUtils() {
        // Utility class
    }

    public static String randomUuid() {
        return UUID.randomUUID().toString();
    }

    public static String sha512(String str) {
        return Hashing.sha512().hashString(str, StandardCharsets.UTF_8).toString();
    }
}
