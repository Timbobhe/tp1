package fr.ag2rlamondiale.trm.security;

import com.ag2r.common.security.habilitations.model.IAuthorizationData;
import lombok.Getter;

@Getter
public enum RolesEnum {

    FONDS_DE_PENSION("cla_fonds_pension"),
    IMPERSONATION_SALARIE("IMP-EERE-Salarie"),
    IMPERSONATION_MDPRO("EMDPRO-Admin"),
    FEDERATION("EERE-Federation"),
    PILOTAGE_ERE("NET-Pilotage");

    private String suffixe;

    RolesEnum(String suffixe) {
        this.suffixe = suffixe;
    }

    public String getCompleteRoleName() {
        return IAuthorizationData.ROLE_PREFIX + suffixe;
    }
}
