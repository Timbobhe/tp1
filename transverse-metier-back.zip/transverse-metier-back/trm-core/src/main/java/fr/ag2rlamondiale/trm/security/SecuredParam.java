package fr.ag2rlamondiale.trm.security;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.PARAMETER})
@Inherited
@Documented
public @interface SecuredParam {

    SecurityParamType[] paramType();
}
