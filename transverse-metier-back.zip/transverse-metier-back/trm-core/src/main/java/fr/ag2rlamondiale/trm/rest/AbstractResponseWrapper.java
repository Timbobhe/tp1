package fr.ag2rlamondiale.trm.rest;

@FunctionalInterface
public interface AbstractResponseWrapper<T> {

    T getResponseBody();
}
