package fr.ag2rlamondiale.trm.domain.document;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.Getter;

@SuppressWarnings("squid:S1192")
@Getter
public enum DocumentRefType implements DocRefType {
    FP("Fiche performance UC", false, false),
    FD("Fiche descriptive UC", false, false),
    NF("Notice financière", false, false),
    CU("La convention d’utilisation", false, false),
    LE("Formulaires administratifs", false, false),
    LF("Information versements", false, false),
    GR("Guide réforme des retraites", false, false),
    PO("Autorisation PO", false, false),
    BV("Bulletin de versement individuel", false, false),
    BF("Bulletin VIF", false, false),
    OR("Choix option de rente", false, false),
    DL("Demande de liquidation", false, false),
    FQ("Foire aux questions", false, false),
    CB("Modification clause bénéficiaire", false, false),
    MD("Modification donnée personnelle et bancaire", false, false),
    MF("Modification gestion financière", false, false),
    NS("Notice d’informations Salarié", false, false),
    GF("Annexe gestion financière", false, false),
    AF("Bulletin d’affiliation", false, false),
    CR("Compte rendu de gestion financière", false, false),
    DS("Disposition spécifique", false, false),
    IFU("Imprimé Fiscal Unique", false, false),
    NP("Guide du salarié", false, false),
    NH("Notice d’information DRH", false, false),
    NR("Notice d’information retraite", false, false),
    RC("Charte Réclamation", false, false),
    BI("Bulletin Initial VIF", false, false),
    BC("Bulletin Complémentaire VIF", false, false),
    DB("Désignation Bénéficiaire du décès", false, false),
    CG("Choix Gestion financière", false, false),
    RAS("Relevé de situation", false, false),
    DF("Déclaration fiscale", false, false),
    ECH("Échéancier", false, false),
    AC("Accusé de réception de versement", false, false),
    PIECE_JOINTE_DEMANDE("Pièce jointe de demande", false, false),
    CRGE("Compte-rendu de gestion", false, false),
    PRUN("Prélèvement unique", false, false),
    // Type Technique
    SIMUL_RENTE_CIBLE("AG2R-LA-MONDIALE-simulation-montant-rente-avec-VIF", false, false),
    // SIMUL_RENTE_AVEC_VIF("Simulation Rente Avec Vif"),
    SIMUL_RENTE_AVEC_VIF("AG2R-LA-MONDIALE-simulation-montant-rente-avec-VIF", false, false),
    // SIMUL_AVEC_OPTIONS("Simulation avec options"),
    SIMUL_AVEC_OPTIONS("AG2R-LA-MONDIALE-simulation-montant-rente-avec-option-de-rente", false, false),
    // SIMUL_FISCAL_SIMPLIFIE("Simulation fiscal simplifie"),
    SIMUL_FISCAL_SIMPLIFIE("AG2R-LA-MONDIALE-simulation-economie-impots-genere-par-VIF", false, false),
    // SIMUL_FISCAL_DETAILLE("Simulation fiscal_detaille"),
    SIMUL_FISCAL_DETAILLE("AG2R-LA-MONDIALE-simulation-economie-impots-genere-par-VIF", false, false),
    /* */
    DD("Désignation bénéficiaire du décès DRH", false, false),
    CD("Choix Gestion financière DRH", false, false),
    CPR("Convention_de_preuves", false, false),

    /* Resultat QAD en ligne */
    QAD_EN_LIGNE("QAD_en_ligne", true, false),
    /* Resultat QAD courrier */
    RESULTAT_QUAD("Resultat_QUAD", true, false),

    /* Resultat QAD en ligne */
    BIA_QAD_EN_LIGNE("QAD_en_ligne", true, false),
    /* Resultat QAD courrier */
    BIA_RESULTAT_QUAD("Resultat_QUAD", true, false),

    /* Resultat QAD en ligne */
    MODIFICATION_CLAUSE_BENEFICIAIRE_QAD_EN_LIGNE("QAD_en_ligne", true, false),
    /* Resultat QAD courrier */
    MODIFICATION_CLAUSE_BENEFICIAIRE_RESULTAT_QUAD("Resultat_QUAD", true, false),

    /* Resultat QAD en ligne */
    ARBITRAGE_QAD_EN_LIGNE("QAD_en_ligne", true, false),
    /* Resultat QAD courrier */
    ARBITRAGE_RESULTAT_QUAD("Resultat_QUAD", true, false),

    /* Arbitrage */
    DEMANDE_ARBITRAGE("Demande_Arbitrage", true, false),
    /* Arbitrage en ligne */
    ARBITRAGE_EN_LIGNE("Arbitrage_en_ligne", true, true),
    /* Parcours BIA */
    PARCOURS_BIA("Parcours_BIA", true, false),
    /* BIA_en_ligne */
    BIA_EN_LIGNE("BIA_en_ligne", true, true),


    /* Parcours Versement */
    PARCOURS_VERSEMENT("Parcours_Versement", true, false), // Le RIB peut être absent si chèque
    /* Parcours Versement en ligne */
    VERSEMENT_EN_LIGNE("Versement_en_ligne", true, true),
    /* Demande Courrier SEPA */
    DEMANDE_COURRIER_SEPA("Demande_Courrier_SEPA", true, false),
    /* Demande Courrier SEPA en ligne */
    DEMANDE_EN_LIGNE_SEPA("Demande_en_ligne_SEPA", true, true),
    MODIFICATION_CLAUSE_BENEFICIAIRE_EN_LIGNE("Modification_Clause_Beneficiaire_en_ligne", true, true),
    MODIFICATION_CLAUSE_BENEFICIAIRE("Modification_Clause_Beneficiaire", true, false),
    /* Parcours LIQUIDATION */
    PARCOURS_LIQUIDATION("Parcours_Liquidation", true, false),
    /* LIQUIDATION_en_ligne */
    LIQUIDATION_EN_LIGNE("Liquidation_en_ligne", true, true),
    /* Modification_RIB */
    MODIFICATION_RIB("Modification_RIB", true, true);

    private final String code;
    private final boolean acteEnLigne;
    private final boolean sigElec;

    DocumentRefType(String code, boolean acteEnLigne, boolean sigElec) {
        this.code = code;
        this.acteEnLigne = acteEnLigne;
        this.sigElec = sigElec;
    }


    @Override
    public MDProDocSectionType getSection() {
        return null;
    }

    @Override
    public CodeSiloType getCodeSilo() {
        return CodeSiloType.ERE;
    }

    @Override
    public boolean isSpecifique() {
        return false;
    }

    @Override
    public boolean isStandard() {
        return false;
    }

    @Override
    public boolean isEmptyCategorieDoc() {
        return false;
    }
}
