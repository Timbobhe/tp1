package fr.ag2rlamondiale.trm.supervision;

import com.ag2r.common.administration.model.AbstractTestManager;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Profile(BaseTestManager.PROFILE_TESTMANAGER)
@Component
public class TestManagerInterceptorFactory implements Serializable {
    private static final long serialVersionUID = 8071271495628566855L;

    @Lookup
    public TestManagerInterceptor createInterceptor(AbstractTestManager testManager) {
        return null;
    }
}
