package fr.ag2rlamondiale.trm.domain.document;

import lombok.Data;

@Data
public class ChampsPDFInfo {

    private String valeur;
    private boolean readonly;
    private TypeChampsPdfType type;

    public ChampsPDFInfo(String valeur, boolean readOnly, TypeChampsPdfType type) {
        this.valeur = valeur;
        this.readonly = readOnly;
        this.type = type;
    }

    public ChampsPDFInfo(String valeur, TypeChampsPdfType type) {
        this.valeur = valeur;
        this.readonly = true;
        this.type = type;
    }
}
