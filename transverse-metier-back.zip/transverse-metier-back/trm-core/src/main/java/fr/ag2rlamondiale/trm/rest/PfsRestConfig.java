package fr.ag2rlamondiale.trm.rest;

import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestJaxbConfig;
import fr.ag2rlamondiale.trm.rest.swagger.PfsRestSwaggerConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({PfsRestJaxbConfig.class, PfsRestSwaggerConfig.class})
public class PfsRestConfig {

}
