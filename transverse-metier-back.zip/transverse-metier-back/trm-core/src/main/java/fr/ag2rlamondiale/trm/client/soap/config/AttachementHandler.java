package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.util.FileCopyUtils;

import javax.xml.namespace.QName;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.SOAPException;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collections;
import java.util.Iterator;
import java.util.Set;

@Slf4j
public class AttachementHandler extends CommonHandler implements SOAPHandler<SOAPMessageContext> {
    private AttachmentResponse attachmentResponse;

    public AttachementHandler(int maxChars, AttachmentResponse attachmentResponse) {
        super(maxChars);
        this.attachmentResponse = attachmentResponse;
    }

    public AttachementHandler(AttachmentResponse attachmentResponse) {
        this(-1, attachmentResponse);
    }

    @Override
    public boolean handleMessage(SOAPMessageContext smc) {
        final boolean outboundProperty =
                (Boolean) smc.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        if (!outboundProperty) {
            @SuppressWarnings("unchecked")
            Iterator<AttachmentPart> iterator = smc.getMessage().getAttachments();

            if (iterator.hasNext()) {
                // On recupere le premier et on sort
                AttachmentPart element = iterator.next();
                ByteArrayOutputStream byteArrayOutStream = new ByteArrayOutputStream();
                try (InputStream inputStream = element.getDataHandler().getInputStream()) {
                    FileCopyUtils.copy(inputStream, byteArrayOutStream);
                } catch (IOException | SOAPException e) {
                    log.error("method handleMessage ()", e);
                }

                byte[] result = byteArrayOutStream.toByteArray();
                attachmentResponse.setAttachment(result);
            }
        }
        return true;
    }

    public AttachmentResponse getAttachmentResponse() {
        return attachmentResponse;
    }

    @Override
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }

    @Override
    public void close(MessageContext context) {
        // Empty
    }
}
