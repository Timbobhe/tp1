package fr.ag2rlamondiale.trm;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.core.Ordered;

/**
 * Plus la valeur donnée sera grande plus l’interception se fera proche de l’objet. À l’inverse, plus la valeur sera petite plus l’interception se fera loin de l’objet.
 * <p>
 * {@literal https://labs.alinto.com/spring-aop-inteceptors/}
 * </p>
 *
 * <br>
 * <p>
 * Remarque le Cache {@link EnableCaching#order()} est par défaut avec la valeur MAX_INTEGER
 * </p>
 * <br>
 *
 * <p>
 * A lire à l'envers : dès que l'on arrive sur une méthode on joue :
 *     <ol>
 *         <li>La sécurité en frontal</li>
 *         <li>La gestion des appels concurrents</li>
 *         <li>Le cache</li>
 *         <li>Le tracking du cache utilisateur</li>
 *         <li>Préparation pour les appels SOAP</li>
 *         <li>Le profiling de la méthode : log error, log temps, profile exécution</li>
 *     </ol>
 * </p>
 */
public final class InterceptorOrders {
    // On mesure le temps passé (au plus proche de la méthode)
    public static final int PROFILE_EXECUTION_ORDER = Ordered.LOWEST_PRECEDENCE; // Ne pas tracer en cas de CACHE
    public static final int LOG_EXECUTION_TIME_ORDER = PROFILE_EXECUTION_ORDER - 1;
    public static final int LOG_ERROR_ORDER = LOG_EXECUTION_TIME_ORDER;

    // Ensuite on prépare l'appel SOAP
    public static final int PREPARE_SOAP_REQUEST_ORDER = PROFILE_EXECUTION_ORDER - 2;

    // On gère le tracking du cache utilisateur
    public static final int TRACK_USER_CACHE_ORDER = PROFILE_EXECUTION_ORDER - 2;

    /**
     * Ensuite on cache tout ça
     * <p>
     * ecrs-api/src/main/resources/config/application-context.xml
     *
     * <div>
     *
     * <code>
     * &lt;cache:annotation-driven cache-manager="ehCacheManager" key-generator="withMethodSimpleKeyGenerator"
     * order="1000"/&gt;
     * </code>
     *
     * </div>
     */
    public static final int DEFAULT_CACHEABLE_ORDER = 1000;
    public static final int REQUEST_CACHING_ORDER = DEFAULT_CACHEABLE_ORDER;

    // On s'occupe de cache avec 1er la gestion de la concurrence d'appel ...
    public static final int CONCURRENT_CACHE_ORDER = DEFAULT_CACHEABLE_ORDER - 3;

    // La sécurité en frontal d'appel de la méthode
    public static final int SECURE_ORDER = 1;
}
