package fr.ag2rlamondiale.trm.jahia;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

public interface JahiaUrlConnection {

    HttpURLConnection getUrlConnection(URL url) throws IOException;
}
