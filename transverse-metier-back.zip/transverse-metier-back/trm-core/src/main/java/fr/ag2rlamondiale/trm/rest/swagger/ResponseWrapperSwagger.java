package fr.ag2rlamondiale.trm.rest.swagger;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.trm.rest.AbstractResponseWrapper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResponseWrapperSwagger<T> implements AbstractResponseWrapper<T> {
    @JsonProperty("Response")
    private T response;

    @Override
    public T getResponseBody() {
        return response;
    }
}
