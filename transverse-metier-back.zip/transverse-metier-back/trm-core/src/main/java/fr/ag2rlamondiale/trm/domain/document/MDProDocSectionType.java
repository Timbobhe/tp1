package fr.ag2rlamondiale.trm.domain.document;

public enum MDProDocSectionType {
    INFORMATION,

    CONTRACTUEL,

    OPERATION;
}
