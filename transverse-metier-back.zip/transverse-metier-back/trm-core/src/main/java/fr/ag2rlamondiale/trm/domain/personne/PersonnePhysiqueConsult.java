package fr.ag2rlamondiale.trm.domain.personne;

import fr.ag2rlamondiale.trm.csv.DepartementType;
import fr.ag2rlamondiale.trm.csv.SituationFamilialeType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.*;

import java.util.Date;
import java.util.List;

/**
 * POJO contenant les données d'une Personne Physique
 */
@Builder(toBuilder = true)
@Data
@NoArgsConstructor
@AllArgsConstructor
@With
public class PersonnePhysiqueConsult implements InfoPersonnePhysique {

    private CodeSiloType codeSilo;

    private String id;
    private String nom;
    private String prenom;
    private Date dateDeNaissance;
    private Integer age;

    /**
     * F ou M
     */
    private String codeSexe;

    private String codeCivilite;
    private String civilite;
    private String nomNaissance;
    private String lieuNaissance;
    private String codePostalNaissance;
    private String codeINSEENaissance;
    private SituationFamilialeType situationFamiliale;
    private List<String> pieceDidendite;
    private List<String> justifDomicile;

    private DepartementType departementNaissance;

    // Adresse
    private String etageAppt;
    private String batiment;
    private String numVoie;
    private String lieuDit;
    private String codePostal;
    private String ville;
    private String pays;
    private String codePaysISO;
    private String paysResidenceFiscale;
    private String codePaysResidenceFiscaleISO;
    // Contact
    private String telPortable;
    private String telPersonnel;
    private String telPro;
    private String emailPro;
    private String emailPerso;
    // Autorisation de prospection.
    private boolean optIn;
    private boolean npai;

    private int limiteAgeVIF;
    // Données validées
    private boolean donneesPersonnellesConfirmees;
    // PND
    private Integer nbeCourriersPND;
    private boolean pndDefinitif;


    @Override
    public String getEmailSigElec() {
        if (CodeSiloType.ERE.equals(codeSilo)) {
            return getEmailPro();
        }
        return getEmailPerso();
    }
}
