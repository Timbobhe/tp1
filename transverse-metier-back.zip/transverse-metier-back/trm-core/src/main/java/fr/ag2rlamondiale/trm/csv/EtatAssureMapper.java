package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class EtatAssureMapper extends AbstractCsvMapper<String> {
    public EtatAssureMapper() {
        super("csv/libelles_etat_assure.csv");
    }

    @Override
    protected AbstractCsvMapper.Key getNewKey(String code, String lang) {
        return new AbstractCsvMapper.Key(code, lang);
    }
}
