/*
 * Cree le 9 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.constantes;

public final class Constantes {
	public static final String CODE_APP_EPIN = "A1549";
	public static final String CODE_APP_EDITIQUE = "A1589";
	public static final String CODE_APP_PFS = "A1589";
	public static final String CODE_APP_KSL = "A0895";
	public static final String CODE_APP_8X = "A0443";
	public static final String CODE_APP_EGESP = "A0406";

	public static final String CODE_APP = "A1573";

	public static final String TYPE_CONTRAT = "CONTRAT";
	public static final String CODE_SYS_INFO = "MDP";

	public static final String MOCKDATA = "MockedData";

	public static final String EMPTY_STRING = "";

	public static final String DEFAULT_DATE_FORMAT = "dd/MM/yyyy";

	public static final String DEFAULT_DATE_FORMAT_EXTENDED_DF = "dd/MM/yyyy hh:mm:ss";

	public static final String CODE_PERSONNE_MORALE = "P";

	public static final String FILIALE_MDPRO = "LMX";

	public static final String DATE_LIMITE_LECTURE_SEULE_MADELIN_RACHETE = "22/01/2027";

	public static final String DATE_LIMITE_ALERTE_ARBITRAGE_SUR_SYNTHESE= "09/12/2021";

    public static final String DATE_LIMITE_ALERTE_TRANSFO_CONTRATS_SUR_SYNTHESE= "30/06/2022";


    /** Contient la liste des codes(types) numeros de phones */
	public enum CodesNatTel {
		PER, PRO, PO
	}

	/** Contient la liste des Produits autorisés */
	public enum cnt_aut {
		RC
	}

	/** Détermine les types de clauses bénéficiaires Epargne Handicap **/
	public enum ep_hand {
		EPHAT
	}

	/** Contient la liste des Couple Version/Produit autorisés */
	public enum ver_aut {
		RC03V01, RC03V02, RC03V03, RC08V01, RC08V02, RC08V09, RC08V21, RC08V22, RC08V41
	}

	/**
	 * Contient la liste des Couple Version/Produit autorisés à sélectionner les fonds lors du
	 * rachat partiel.
	 */
	public enum AutorizedProductsForSupportSelection {
		RC08V01, RC08V21, RC08V41
	}

	public enum fiscdsk_aut {
		RC08V02, RC08V22
	}

	/** Contient la liste des statuts autorisés */
	public enum stat_aut {
		EC, ECSSPRM
	}

	/** Contient la liste des types bénéficiaires interdits */
	public enum benef_non_aut {
		DGN, ACC
	}

	public static final String DPT_NOUVELLE_CALEDONIE = "988";
	public static final String DPT_POLYNESIE = "987";

	public static final String FISCALITE_DSK_COD = "FISCDSK";

	public static final String BOOL_TRUE = "true";
	public static final String BOOL_FALSE = "false";

	public static final String MANAGEMENT_ADDRESS = "GES";

	public static final String DATA_LABEL_NUM_PERSONNE = "NUMERO DE PERSONNE";
	public static final String DATA_LABEL_NOM = "NOM";
	public static final String DATA_LABEL_PRENOM = "PRENOM";
	public static final String DATA_LABEL_NATIONALITE = "NATIONALITE";
	public static final String DATA_LABEL_RES_FISCALE = "PAYS DE RESIDENCE FISCALE";
	public static final String DATA_LABEL_MONTANT = "MONTANT";
	public static final String DATA_LABEL_TYPE_PRODUIT = "TYPE PRODUIT";
	public static final String DATA_LABEL_CODE_VERSION = "CODE VERSION";
	public static final String DATA_LABEL_FISCALITE = "FISCALITE";

	public static final String KSL_PARAM_DATAFILE = "P_DataFile";
	public static final String KSL_PARAM_CODEDOC = "P_Code_doc";
	public static final String KSL_PARAM_DESTMAIL = "P_DestinataireMail";
	public static final String KSL_PARAM_DESTCOPY = "P_DestinataireCopieMail";
	public static final String KSL_PARAM_REPLYTO = "P_ReplyTo";
	public static final String KSL_PARAM_SERVICE = "kslService";

	/** SonarQube : Constructeur privé afin de masquer le constructeur implicite */
	private Constantes() {}
}
