package fr.ag2rlamondiale.trm.domain.exception;

public class DocumentException extends Exception {
    private static final long serialVersionUID = -9009434545253531120L;

    public static final String CANT_SAVE_DOCUMENT = "Can't save document";
    public static final String CANT_FILL_DOCUMENT = "Can't fill document form";
    public static final String CANT_INSERT_IMAGE = "Can't insert image";
    public static final String CANT_INSERT_QRCODE = "Can't insert qr code";
    public static final String CANT_MANAGE_LINE_BREAK = "Can't manage line breaks";
    public static final String CANT_ENCODE_VALUE = "Can't encode value";
    public static final String CANT_GET_ENCODING = "Can't get encoding";
    public static final String CANT_CONVERT_FROM_SVG = "Can't convert from svg";
    public static final String CANT_MERGE_DOCUMENT = "Can't merge document";
    public static final String CANT_FIND_DOCUMENTS = "Can't find documents";
    public static final String CANT_CONVERT_FROM_HTML = "Can't convert from html";
    public static final String NO_PARAMETERS = "Empty arguments";

    public DocumentException(String message, Throwable cause) {
        super(message, cause);
    }

    public DocumentException(String message) {
        super(message);
    }

    public DocumentException(Throwable cause) {
        super(cause);
    }
}
