/*
 * Cree le 11 avr. 2019. (c) Ag2r - La Mondiale, 2019. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain;

public enum ModeGestionMdproType {
    LIBRE, PILOTEE, HORIZON, DYNAMISATION, PEP, TERME;
}
