package fr.ag2rlamondiale.trm.domain.personne;

import lombok.Data;

/**
 * POJO contenant les données d'une Personne Physique
 */
@Data
public class PersonnePhysique {

    private String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
    private String nom;
    private String prenom;

    /**
     *  "Monsieur", "Madame" ou "Madame ou Monsieur" (si inconnu)
     */
    private String civilite;
    private String idExtranet;
}
