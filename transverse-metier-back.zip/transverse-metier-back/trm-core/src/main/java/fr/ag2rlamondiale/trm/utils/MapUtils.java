package fr.ag2rlamondiale.trm.utils;

import com.google.common.base.Splitter;

import java.util.HashMap;
import java.util.Map;

public final class MapUtils {
    private MapUtils() {
        // Utility class
    }


    public static Map<String, String> parseStringMap(String mapString) {
        if (mapString == null) {
            return null;
        }
        mapString = mapString.replaceAll("\u200B", "");
        if (mapString.startsWith("{") && mapString.endsWith("}")) {
            final Iterable<String> strings = Splitter.on(',')
                    .omitEmptyStrings()
                    .trimResults()
                    .split(mapString.substring(1, mapString.length() - 1));
            Map<String, String> map = new HashMap<>();
            strings.forEach(s -> {
                final String[] split = s.split("=");
                if (split.length == 2) {
                    map.put(split[0].trim(), split[1].trim());
                }
            });
            return map;
        }
        return null;
    }

}
