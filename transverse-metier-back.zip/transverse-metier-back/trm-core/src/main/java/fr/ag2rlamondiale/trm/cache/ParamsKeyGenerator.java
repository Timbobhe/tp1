package fr.ag2rlamondiale.trm.cache;

import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.interceptor.SimpleKeyGenerator;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Component(CacheConstants.SIMPLE_KEY_GENERATOR)
public class ParamsKeyGenerator implements KeyGenerator {

    private SimpleKeyGenerator generator = new SimpleKeyGenerator();

    @Override
    public Object generate(Object target, Method method, Object... params) {
        return generator.generate(target, method, params);
    }
}
