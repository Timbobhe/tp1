package fr.ag2rlamondiale.trm.rest.swagger;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

@Configuration
public class PfsRestSwaggerConfig {
    public static final String SWAGGER_REST_TEMPLATE = "restTemplateSwagger";
    public static final String SWAGGER_OBJECT_MAPPER = "objectMapperSwagger";
    public static final String DATE_FORMAT = "yyyy-MM-dd";

    @Bean(SWAGGER_REST_TEMPLATE)
    public RestTemplate restTemplateSwagger() {
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().stream()
                .filter(AbstractJackson2HttpMessageConverter.class::isInstance)
                .map(AbstractJackson2HttpMessageConverter.class::cast)
                .findFirst()
                .ifPresent(httpMessageConverter -> {
                    ObjectMapper mapper = httpMessageConverter.getObjectMapper();
                    DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
                    mapper.setDateFormat(dateFormat);
                    mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
                });
        return restTemplate;
    }

    @Bean(SWAGGER_OBJECT_MAPPER)
    public ObjectMapper buildSwaggerObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        DateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
        objectMapper.setDateFormat(dateFormat);
        objectMapper.registerModule(new JavaTimeModule());
        return objectMapper;
    }
}
