package fr.ag2rlamondiale.trm.security;

import com.fasterxml.jackson.annotation.JsonIgnore;

public interface ISecurityParamAccess {

    /**
     * A surcharger dans la classe du Type paramètre si la sécurité est basée sur {@link SecurityParamType#CONTRAT}
     * @return le numéro de contrat
     */
    @JsonIgnore
    default String secureForNumContrat() {
        throw new UnsupportedOperationException("Impl\u00e9ter \u00e0 l'usage");
    }

    /**
     * A surcharger dans la classe du Type paramètre si la sécurité est basée sur {@link SecurityParamType#IDASSURE}
     * @return l'identifiant de l'assuré
     */
    @JsonIgnore
    default String secureForIdentifiantAssure() {
        throw new UnsupportedOperationException("Impl\u00e9ter \u00e0 l'usage");
    }
}
