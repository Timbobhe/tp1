package fr.ag2rlamondiale.trm.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Map;

@Slf4j
@Service
public class JmxCacheManager implements JmxCacheManagerMBean, ApplicationContextAware {

    @Autowired
    private CacheManager cacheManager;

    @Autowired
    private ConcurrentCacheInterceptor concurrentCacheInterceptor;

    private ApplicationContext applicationContext;

    @Override
    public void clearCache() {
        clearStandardCache();
        clearClearableCache();
    }

    @Override
    public void setEnableConcurrentCache(boolean enable) {
        concurrentCacheInterceptor.setEnable(enable);
    }

    @Override
    public boolean getEnableConcurrentCache() {
        return concurrentCacheInterceptor.isEnable();
    }

    private void clearClearableCache() {
        final Map<String, ClearableCache> clearables = applicationContext.getBeansOfType(ClearableCache.class);
        clearables.forEach((beanName, clearableCache) -> {
            log.info("Clear ClearableCache bean {}", beanName);
            clearableCache.clearCache();
        });
    }

    private void clearStandardCache() {
        final Collection<String> cacheNames = cacheManager.getCacheNames();
        for (String cacheName : cacheNames) {
            final Cache cache = cacheManager.getCache(cacheName);
            log.info("Clear cache {}", cacheName);
            if (cache != null) {
                cache.clear();
            }
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = applicationContext;
    }
}
