package fr.ag2rlamondiale.trm.utils;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import javax.management.*;

@Slf4j
@Component
public class JmxBeanPostProcessor implements BeanPostProcessor {

    @Autowired
    private MBeanServer server;

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException /*NOSONAR*/ {
        return bean;
    }

    @SneakyThrows
    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException /*NOSONAR*/ {
        final Class<?> targetClass = AopProxyUtils.ultimateTargetClass(bean);

        final Class<?>[] interfaces = targetClass.getInterfaces();
        for (Class<?> i : interfaces) {
            if (i.getSimpleName().endsWith("MBean")) {
                ObjectName name = new ObjectName("fr.ag2rlamondiale.ecrs:type=" + beanName);
                if (!server.isRegistered(name)) {
                    try {
                        log.info("Register MBean : {}", name);
                        server.registerMBean(bean, name);
                    } catch (InstanceAlreadyExistsException | MBeanRegistrationException | NotCompliantMBeanException e) {
                        log.error("Erreur pendant registerMBean : {}", name, e);
                    }
                }
                break;
            }
        }


        return bean;
    }
}
