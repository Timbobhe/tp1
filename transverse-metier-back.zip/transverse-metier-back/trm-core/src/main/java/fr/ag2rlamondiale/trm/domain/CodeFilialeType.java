package fr.ag2rlamondiale.trm.domain;

public enum CodeFilialeType {
    FDP("Fonds de pension"),
    ARP("Arial PERE"),
    ACA("ARIAL CNP ASSURANCES"),
    LME("LA MONDIALE ENTREPRISES"),
    ACN("CNP Assurances"),
    LMR("AIR FRANCE PERE"),
    ARI("ARIAL ASSURANCE"),
    G2P("AG2R PREVOYANCE"),
    PRI("PRIMA EPARGNE"),
    LMX("LA MONDIALE EXPERT"),
    LMO("LA MONDIALE"),
    LMT("LA MONDIALE EXPERT PERP"),
    LMD("LA MONDIALE DIRECT"),
    LMP("LA MONDIALE PARTENAIRE"),
    MEP("LA MONDIALE EUROPARTNER");



    private final String libelle;

    CodeFilialeType(String libelle) {
        this.libelle = libelle;
    }

    public static String getLibelleFilialeFromCode(String code){
        for(CodeFilialeType filialeType : values()){
            if(filialeType.name().equals(code))
                return filialeType.libelle;
        }
        return null;
    }
}
