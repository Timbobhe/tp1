package fr.ag2rlamondiale.trm.domain.document;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.Getter;

/**
 * Documents MDPro.
 */
@SuppressWarnings("squid:S1192")
@Getter
public enum DocumentMDProRefType implements DocRefType {
    // Ordre dans lequel seront lancées les recherches :
    // Garder les documents à la personne en premier puisqu'ils necessitent potentiellement plus d'appels
    DASS("Déclaration Annuelle de Salaire", null, false, false),
    IFUS("Imprimé Fiscal Unique", null, false, false),
    ISFS("Impôt de Solidarité sur la Fortune", null, false, false),
    CRL("Certificat de rente", null, false, false),
    CGE("Conditions Générales", null, false, false),
    CPA("Conditions Particulières", null, false, false),
    RASS("Relevé Annuel de situation", null, false, false),
    ARB("Arbitrage", null, false, false),
    AVE("Avenant de changement de garantie", null, false, false),
    YAF("Clause bénéficiaire", null, false, false),
    VLI("Versement libre", null, false, false),
    CSP("Rachat partiel", null, false, false),
    DEFS("Attestation de versement", null, false, false), // Déclaration fiscale
    RC("La Charte réclamation", MDProDocSectionType.INFORMATION, false, false),
    GR("Guide de la réforme des retraites", MDProDocSectionType.INFORMATION, false, false),
    LF("Lettre d’information financière", MDProDocSectionType.INFORMATION, false, false),
    DI("DICI", MDProDocSectionType.CONTRACTUEL, true, true, false, false),
    KS("KID Support", MDProDocSectionType.CONTRACTUEL, true, true, false, false),
    CU("La convention d’utilisation de l’espace client", MDProDocSectionType.CONTRACTUEL, false, false),
    NO("Notice", MDProDocSectionType.CONTRACTUEL, true, true, false, false),
    NF("Fiche d’information fiscale et sociale", MDProDocSectionType.CONTRACTUEL, false, false),
    SA("Statuts Amphitéa", MDProDocSectionType.CONTRACTUEL, false, false),
    AF("Annexe Gestion Financière", MDProDocSectionType.CONTRACTUEL, true, true, false, false),
    KC("KID Contrat", MDProDocSectionType.CONTRACTUEL, true, true, false, false),
    SL("Statuts LM", MDProDocSectionType.CONTRACTUEL, false, false),
    FC("Fiches conseils", MDProDocSectionType.INFORMATION, false, false),
    FQ("Foire aux questions", MDProDocSectionType.INFORMATION, true, true, false, false),
    MD("Modification données personnelle et bancaire", MDProDocSectionType.OPERATION, true, true, false, false),
    BF("Bulletin VIF", MDProDocSectionType.OPERATION, true, true, false, false),
    FO("Formulaires d’opérations (versement, arbitrage, rachat)", MDProDocSectionType.OPERATION,
            true, true, false, false),
    FA("Formulaires annexes (non résident, +85 ans)", MDProDocSectionType.OPERATION, true, true, false, false),
    CB("Modification Clause Bénéficiaire", MDProDocSectionType.OPERATION, true, true, false, false),
    ILR("Imprimé de liquidation de Retraite", MDProDocSectionType.INFORMATION, false, false),

    DEMANDE_ARBITRAGE_MDPRO("Demande_Arbitrage_Mdpro", null, true, false),
    ARBITRAGE_MDPRO_EN_LIGNE("Arbitrage_Mdpro_en_ligne", null, true, true),

    // QAD
    DEVOIR_CONSEIL_MDPRO_EN_LIGNE("Devoir_Conseil_Mdpro_en_ligne", null, true, true),
    DEVOIR_CONSEIL_MDPRO("Devoir_Conseil_Mdpro", null, true, false),
    QAD_EN_LIGNE("QAD_en_ligne", null, true, false),
    // QAD pour Arbitrage
    ARBITRAGE_DEVOIR_CONSEIL_MDPRO_EN_LIGNE("Devoir_Conseil_Mdpro_en_ligne", null, true, true),
    ARBITRAGE_DEVOIR_CONSEIL_MDPRO("Devoir_Conseil_Mdpro", null, true, false),
    ARBITRAGE_QAD_EN_LIGNE("QAD_en_ligne", null, true, false),

    /* Parcours Versement */
    PARCOURS_VERSEMENT_MDPRO("Parcours_Versement_Mdpro", null, true, false),
    /* Parcours Versement en ligne */
    VERSEMENT_EN_LIGNE_MDPRO("Versement_en_ligne_Mdpro", null, true, true),
    /* Demande Courrier SEPA */
    DEMANDE_COURRIER_SEPA_MDPRO("Demande_Courrier_SEPA_Mdpro", null, true, false),
    /* Demande Courrier SEPA en ligne */
    DEMANDE_EN_LIGNE_SEPA_MDPRO("Demande_en_ligne_SEPA_Mdpro", null, true, true),

    MODIFICATION_RIB_MDPRO("Modification_RIB_Mdpro", null, true, true);

    private final String code;
    private final MDProDocSectionType section;
    private final boolean specifique;
    private final boolean standard;
    private final boolean acteEnLigne;
    private final boolean sigElec;

    DocumentMDProRefType(String code, MDProDocSectionType section, boolean acteEnLigne, boolean sigElec) {
        this(code, section, false, false, acteEnLigne, sigElec);
    }


    DocumentMDProRefType(String code, MDProDocSectionType section, boolean specifique, boolean standard, boolean acteEnLigne, boolean sigElec) {
        this.code = code;
        this.section = section;
        this.specifique = specifique;
        this.standard = standard;
        this.acteEnLigne = acteEnLigne;
        this.sigElec = sigElec;
    }

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public MDProDocSectionType getSection() {
        return section;
    }

    @Override
    public CodeSiloType getCodeSilo() {
        return CodeSiloType.MDP;
    }

    @Override
    public boolean isSpecifique() {
        return specifique;
    }

    @Override
    public boolean isStandard() {
        return standard;
    }

    @Override
    public boolean isEmptyCategorieDoc() {
        return !specifique && !standard;
    }
}
