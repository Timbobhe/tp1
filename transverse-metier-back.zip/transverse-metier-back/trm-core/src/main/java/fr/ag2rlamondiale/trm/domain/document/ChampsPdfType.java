package fr.ag2rlamondiale.trm.domain.document;

public enum ChampsPdfType {
    // Données Personnelles Contrat (informations communes)
    PRODUIT("Produit"),
    NUM_CONTRAT("Num_Contrat"),
    RAISON_SOCIALE("Raison_Sociale"),
    COLLEGE("College"),

    // Données Personnelles Salaries (informations communes)
    MADAME("Madame", TypeChampsPdfType.CHECKBOX),
    MONSIEUR("Monsieur", TypeChampsPdfType.CHECKBOX),
    IDENTIFIANT("Identifiant"),
    NOM("Nom"), NOM_NAISSANCE("Nom_Naissance"),
    PRENOM("Prenom"),

    DATE_NAISSANCE("Date_Naissance"),
    LIEU_NAISSANCE("Lieu_Naissance"),
    DEPARTEMENT_NAISSANCE("Departement_Naissance"),

    ADRESSE1("Adresse1"), ADRESSE2("Adresse2"),
    ADRESSE3("Adresse3"), ADRESSE4("Adresse4"),

    CODE_POSTAL("Code_Postal"),
    VILLE("Ville"),
    PAYS("Pays"),

    TELEPHONE_FIXE("Telephone_Fixe"),
    TELEPHONE_PORTABLE("Telephone_Portable"),
    TELEPHONE_PROFESSIONNEL("Telephone_Professionnel"),
    E_MAIL("E_Mail"),

    OPT_IN("Opt_in"),
    // Document « Modification de designation de bénéficiaire en cas de deces »
    CLAUSE_STANDARD("Clause_Standard", TypeChampsPdfType.CHECKBOX),
    CLAUSE_SPECIFIQUE("Clause_Specifique", TypeChampsPdfType.CHECKBOX),
    TEXTE_CLAUSESPECIFIQUE("Texte_ClauseSpecifique"),
    CODE_PRODUIT("codeProduit"),
    // Documents « BVif » et « BcVif »
    CHOIX_VL("Choix_VL"), MONTANT_VL("Montant_VL"),
    CHOIX_VP("Choix_VP"), MONTANT_VP("Montant_VP"),

    MENSUEL("Mensuel"), TRIMESTRIEL("Trimestriel"),
    SEMESTRIEL("Semestriel"), ANNUEL("Annuel"),

    DATE_VP("Date_VP"),
    COMPTEUR_SF("Compteur_SF"),
    // Document « BiVIF », « BIA » et « Demande de modification de gestion financière »
    // n'est pas un champs dans les forms pdf mais c'est une partie du nom de certains champs
    SF("SF"),
    OB_SF1("Ob_SF1", TypeChampsPdfType.CHECKBOX),
    OB_SF2("Ob_SF2", TypeChampsPdfType.CHECKBOX),
    OB_SF3("Ob_SF3", TypeChampsPdfType.CHECKBOX),
    OB_SF4("Ob_SF4", TypeChampsPdfType.CHECKBOX),
    OB_SF5("Ob_SF5", TypeChampsPdfType.CHECKBOX),
    OB_SF6("Ob_SF6", TypeChampsPdfType.CHECKBOX),
    OB_SF7("Ob_SF7", TypeChampsPdfType.CHECKBOX),
    //
    FA_SF1("Fa_SF1", TypeChampsPdfType.CHECKBOX),
    FA_SF2("Fa_SF2", TypeChampsPdfType.CHECKBOX),
    FA_SF3("Fa_SF3", TypeChampsPdfType.CHECKBOX),
    FA_SF4("Fa_SF4", TypeChampsPdfType.CHECKBOX),
    FA_SF5("Fa_SF5", TypeChampsPdfType.CHECKBOX),
    FA_SF6("Fa_SF6", TypeChampsPdfType.CHECKBOX),
    FA_SF7("Fa_SF7", TypeChampsPdfType.CHECKBOX),
    // n'est pas un champs dans les forms pdf mais c'est une partie du nom decertains champs
    TAUX_SF("Taux_SF"),
    OB_TAUX_SF1("Ob_Taux_SF1"),
    OB_TAUX_SF2("Ob_Taux_SF2"),
    OB_TAUX_SF3("Ob_Taux_SF3"),
    OB_TAUX_SF4("Ob_Taux_SF4"),
    OB_TAUX_SF5("Ob_Taux_SF5"),
    OB_TAUX_SF6("Ob_Taux_SF6"),
    OB_TAUX_SF7("Ob_Taux_SF7"),
    //
    FA_TAUX_SF1("Fa_Taux_SF1"),
    FA_TAUX_SF2("Fa_Taux_SF2"),
    FA_TAUX_SF3("Fa_Taux_SF3"),
    FA_TAUX_SF4("Fa_Taux_SF4"),
    FA_TAUX_SF5("Fa_Taux_SF5"),
    FA_TAUX_SF6("Fa_Taux_SF6"),
    FA_TAUX_SF7("Fa_Taux_SF7"),
    // n'est pas un champs dans les forms pdf mais c'est une partie du nom de certains champs
    STRATEGIE_FINANCIERE("Strategie_Financiere"),
    OB_STRATEGIE_FINANCIERE1("Ob_Strategie_Financiere1"),
    OB_STRATEGIE_FINANCIERE2("Ob_Strategie_Financiere2"),
    OB_STRATEGIE_FINANCIERE3("Ob_Strategie_Financiere3"),
    OB_STRATEGIE_FINANCIERE4("Ob_Strategie_Financiere4"),
    OB_STRATEGIE_FINANCIERE5("Ob_Strategie_Financiere5"),
    OB_STRATEGIE_FINANCIERE6("Ob_Strategie_Financiere6"),
    OB_STRATEGIE_FINANCIERE7("Ob_Strategie_Financiere7"),
    //
    FA_STRATEGIE_FINANCIERE1("Fa_Strategie_Financiere1"),
    FA_STRATEGIE_FINANCIERE2("Fa_Strategie_Financiere2"),
    FA_STRATEGIE_FINANCIERE3("Fa_Strategie_Financiere3"),
    FA_STRATEGIE_FINANCIERE4("Fa_Strategie_Financiere4"),
    FA_STRATEGIE_FINANCIERE5("Fa_Strategie_Financiere5"),
    FA_STRATEGIE_FINANCIERE6("Fa_Strategie_Financiere6"),
    FA_STRATEGIE_FINANCIERE7("Fa_Strategie_Financiere7"),

    FONDS_DEFAUT("Choix_Defaut"),

    QR_CODE("QRCODE", TypeChampsPdfType.QRCODE),

    LOGO("Logo", TypeChampsPdfType.GRAPHE),

    LOGOPART("LogoPart", TypeChampsPdfType.GRAPHE),

    ADRESSE_COURRIER("AdresseCourrier", TypeChampsPdfType.TEXT_LB),

    ADR_LEGALE("AdrLegale"),

    CONSENTEMENTS("Consentements");

    private final String champs;
    // ReadOnly true par defaut
    private final boolean readOnly;
    // Par defaut type TEXT
    private final TypeChampsPdfType type;

    ChampsPdfType(String champs) {
        this(champs, TypeChampsPdfType.TEXT);
    }

    ChampsPdfType(String field, TypeChampsPdfType type) {
        this.champs = field;
        this.type = type;
        this.readOnly = true;
    }

    public static ChampsPdfType fromString(String text) {
        if (text != null) {
            for (ChampsPdfType element : ChampsPdfType.values()) {
                if (element.getChamps().equalsIgnoreCase(text)) {
                    return element;
                }
            }
        }
        return null;
    }

    public String getChamps() {
        return champs;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    public TypeChampsPdfType getType() {
        return type;
    }
}
