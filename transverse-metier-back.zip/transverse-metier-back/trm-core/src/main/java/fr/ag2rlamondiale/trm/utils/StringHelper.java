package fr.ag2rlamondiale.trm.utils;

import com.google.common.base.Strings;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Static utility methods pertaining to strings.
 */
public final class StringHelper {
	private StringHelper() {
		/* Prevents instantiation */}

	public static String concatStringsWithoutNullOrEmpty(String separator, String... strings) {
		if (strings.length > 0) { // au moins une valeur string a été fournie

			StringBuilder builder = new StringBuilder();

			for (int i = 0; i < strings.length - 1; i++) {
				buildStringWithoutNullOrEmpty(builder, strings[i], separator);
			}
			buildStringWithoutNullOrEmpty(builder, strings[strings.length - 1], "");
			return builder.toString();
		}
		return null; // Aucune valeur fournie
	}

	public static StringBuilder buildStringWithoutNullOrEmpty(StringBuilder builder, String value,
															  String endingValue) {
		if (!Strings.isNullOrEmpty(value)) {
			builder.append(value).append(endingValue);
		}
		return builder;
	}

	/**
	 * Change a "." to a ","
	 *
	 * @param value the big decimal where we need to replace the "." by the ","
	 * @return the replaced value
	 */
	public static String decimalPointToComma(@Nonnull BigDecimal value) {
		return value.toString().replace('.', ',');
	}

	/**
	 * Compare deux chaines de caractères sans que la casse ne soit prise en compte.
	 *
	 * @param str1 première chaine de caractère
	 * @param str2 seconde chaine de caractère
	 * @return <b>true</b> si les chaines sont égales <br/>
	 *         <b>false</b> si les chaines sont différentes
	 */
	public static boolean compareStrings(final String str1, final String str2) {
		if (str1 == null || str1.trim().isEmpty()) {
			return (str2 == null || str2.trim().isEmpty());
		}
		return str1.equalsIgnoreCase(str2);
	}

	public static boolean stringWithSeparatorNotNullAndContains(String searchedIn, String lookedFor, String separator) {
		return searchedIn != null && Arrays.asList(searchedIn.split(separator)).contains(lookedFor);
	}

	public static boolean stringWithSeparatorNotNullAndContains(String searchedIn, String[] lookedFor,
			String separator) {
		if (searchedIn != null) {
			// Ne pas supprimer le new ArrayList car Arrays.asList renvoie une liste à
			// taille fixe
			// non modifiable
			List<String> searchedInList = new ArrayList<>(Arrays.asList(searchedIn.split(separator)));
			return searchedInList.removeAll(Arrays.asList(lookedFor));
		}
		return false;
	}
}
