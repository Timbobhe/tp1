package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.CacheOperationInvocationContext;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Cache pour scope Request (HTTP = {@link WebApplicationContext#SCOPE_REQUEST}) nettoyer au début et à la fin de chaque Request.
 */
@Component(CacheConstants.REQUEST_CACHE_RESOLVER)
public class RequestCacheResolver implements CacheResolver, Ordered {

    @Qualifier(CacheConstants.REQUEST_SCOPED_CACHE_MANAGER)
    @Autowired
    private RequestScopedCacheManager requestScopedCacheManager;

    @Override
    public Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> context) {

        List<String> cacheNames = new ArrayList<>(1);
        final Cacheable cacheable = context.getMethod().getAnnotation(Cacheable.class);
        if (cacheable != null && IQueryCache.cacheNames(cacheable).length > 0) {
            cacheNames.addAll(Arrays.asList(IQueryCache.cacheNames(cacheable)));
        } else {
            cacheNames.add(context.getMethod().toString());
        }

        return cacheNames.stream().map(n -> requestScopedCacheManager.getCache(n)).collect(Collectors.toList());
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.REQUEST_CACHING_ORDER;
    }
}
