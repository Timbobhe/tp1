package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class LimiteAgeVIFMapper extends AbstractCsvMapper<Integer> {
    public LimiteAgeVIFMapper() {
        super("csv/limite_age_vif.csv");
    }

    @Override
    protected void processLine(String line) {
        String[] items = line.split(";");
        values.put(getNewKey(items[0], null), Integer.parseInt(items[1]));
    }

    public Integer getAgeLimite(String codeSexe) {
        return getValue(codeSexe, null);
    }
}
