package fr.ag2rlamondiale.trm.rest.auth;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import javax.xml.bind.DatatypeConverter;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import java.util.Map;

public final class JwtTokenUtils {
    private JwtTokenUtils() {
        // Utility class
    }

    private static final String BEARER_PREFIX = "Bearer ";
    private static final String PRIVATE_KEY_PREFIX = "-----BEGIN PRIVATE KEY-----";
    private static final String PRIVATE_KEY_SUFFIX = "-----END PRIVATE KEY-----";

	public static String createToken(Map<String, Object> claims, Date expirationDate,
            String subject, String audience, String issuer, Date issueAt, String key) {
        PrivateKey privateKey;
        try {
            String privateKeyContent = key;
            privateKeyContent = privateKeyContent.replaceAll("\\n", "")
                    .replace(PRIVATE_KEY_PREFIX, "").replace(PRIVATE_KEY_SUFFIX, "");

            KeyFactory kf = KeyFactory.getInstance("RSA");

            PKCS8EncodedKeySpec keySpecPKCS8 = 
                    new PKCS8EncodedKeySpec(DatatypeConverter.parseBase64Binary(privateKeyContent));

            privateKey = kf.generatePrivate(keySpecPKCS8);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Token creation error : " + e.getMessage());
        }
        
		return Jwts.builder().setClaims(claims).setExpiration(expirationDate).setSubject(subject)
                .setAudience(audience).setIssuer(issuer).setIssuedAt(issueAt).setHeaderParam("typ","JWT")
                .signWith(SignatureAlgorithm.RS256, privateKey).compact();
    }

    public static String createBearerToken(Map<String, Object> claims, Date expirationDate,
            String subject, String audience, String issuer, Date issueAt, String key) {
        return BEARER_PREFIX
                + createToken(claims, expirationDate, subject, audience, issuer, issueAt, key);
    }
}
