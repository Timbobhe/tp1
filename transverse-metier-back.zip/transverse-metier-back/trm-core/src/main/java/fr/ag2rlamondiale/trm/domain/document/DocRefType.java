package fr.ag2rlamondiale.trm.domain.document;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;

public interface DocRefType {
    String getCode();

    MDProDocSectionType getSection();

    boolean isSpecifique();

    boolean isStandard();

    boolean isEmptyCategorieDoc();

    CodeSiloType getCodeSilo();

    String name();

    boolean isActeEnLigne();

    boolean isSigElec();

    static DocRefType getDocumentRefType(String codeTypeDocument, CodeSiloType codeSilo) {
        return CodeSiloType.ERE.equals(codeSilo) ? DocumentRefType.valueOf(codeTypeDocument) :
                DocumentMDProRefType.valueOf(codeTypeDocument);
    }
}
