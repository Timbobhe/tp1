package fr.ag2rlamondiale.trm.rest.auth;

import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Service
public class AccessTokenOAuth2CasAppli implements IAccessTokenProvider {

    public static final String Bearer = "Bearer ";

    @Setter
    @Getter
    @Value("${pfs.token.oauth2.cas.appli:cas}")
    private String clientRegistrationId;

    @Autowired
    private PropertyResolver propertyResolver;

    @Autowired(required = false)
    private OAuth2AuthorizedClientManager authorizedClientManager;

    @Override
    public String getAccessToken(PfsRestServiceConfig pfsRestServiceConfig) {
        Objects.requireNonNull(authorizedClientManager, "Pas de authorizedClientManager");

        final String clientRegistrationId = findClientRegistrationId(pfsRestServiceConfig);
        OAuth2AuthorizeRequest authorizeRequest = OAuth2AuthorizeRequest.withClientRegistrationId(clientRegistrationId)
                .principal(new AnonymousAuthenticationToken("Anonymous", "Anonymous", AuthorityUtils.createAuthorityList("ROLE_ANONYMOUS")))
                .build();

        // Récupération d'un access_token
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        Objects.requireNonNull(authorizedClient, "authorization is not supported for the specified client " + clientRegistrationId);
        OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
        return Bearer + accessToken.getTokenValue();
    }

    @Override
    public AccessTokenType getAccessTokenType() {
        return AccessTokenType.OAUTH2_CAS_APPLI;
    }

    public String findClientRegistrationId(PfsRestServiceConfig pfsRestServiceConfig) {
        if (pfsRestServiceConfig == null || pfsRestServiceConfig.getServiceId() == null) throw new AssertionError();
        return getClientRegistrationId(pfsRestServiceConfig);
    }

    private String getClientRegistrationId(PfsRestServiceConfig pfsRestServiceConfig) {
        final String s = pfsRestServiceConfig.getServiceId();
        final String alternative = "pfs." + s.replace('/', '.') + ".oauth2";
        List<String> keys = Arrays.asList(alternative, pfsRestServiceConfig.getAlternativeAccessToken());
        for (String key : keys) {
            if (key != null && !key.isEmpty()) {
                final String evaluated = propertyResolver.findProperty(key);
                if (evaluated != null) {
                    return evaluated;
                }
            }
        }


        return clientRegistrationId;
    }
}
