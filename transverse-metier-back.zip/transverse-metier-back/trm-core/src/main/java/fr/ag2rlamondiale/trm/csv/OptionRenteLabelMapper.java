package fr.ag2rlamondiale.trm.csv;

import org.springframework.stereotype.Component;

@Component
public class OptionRenteLabelMapper extends AbstractCsvMapper<String> {
    private static final int CODE_POSITION = 0;
    private static final int LANG_POSITION = 2;
    private static final int LABEL_POSITION = 3;

    public OptionRenteLabelMapper() {
        super("csv/libelles_option_de_rente.csv");
    }

    @Override
    protected void processLine(String line) {
        String[] items = line.split(";");
        String code = items[CODE_POSITION];
        String lang = items[LANG_POSITION];
        String label = items[LABEL_POSITION];
        values.put(getNewKey(code, lang), label);
    }

    @Override
    protected AbstractCsvMapper.Key getNewKey(String code, String lang) {
        return new AbstractCsvMapper.Key(code, lang);
    }
}
