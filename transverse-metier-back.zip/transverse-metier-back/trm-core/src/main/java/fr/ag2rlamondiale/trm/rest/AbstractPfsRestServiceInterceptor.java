package fr.ag2rlamondiale.trm.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.type.TypeFactory;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.rest.auth.AccessTokenProviders;
import fr.ag2rlamondiale.trm.rest.jaxb.response.Header;
import fr.ag2rlamondiale.trm.rest.swagger.ResponseWrapperSwagger;
import fr.ag2rlamondiale.trm.utils.IEndpointResolver;
import fr.ag2rlamondiale.trm.utils.JsonMarshallerException;
import fr.ag2rlamondiale.trm.utils.LimitByteArrayOutputStream;
import fr.ag2rlamondiale.trm.utils.UrlUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public abstract class AbstractPfsRestServiceInterceptor<R extends AbstractResponseWrapper<?>> {
    private static final String APPLICATION = "Application";
    private static final String HEADER_APPLICATION = "Application";

    @Autowired
    private AccessTokenProviders accessTokenProviders;

    @Autowired
    private IEndpointResolver endpointResolver;

    @Autowired
    private ISupplierLibService supplierLibService;

    @Value("${rest.log.limit.chars.size:30000}")
    private int maxChars;


    public Object aroundAdvice(ProceedingJoinPoint joinPoint, PfsRestServiceConfig pfsRestService) throws Throwable {
        Object[] args = joinPoint.getArgs();
        if (args.length != 1) {
            return joinPoint.proceed();
        }


        final String url = getUrl(pfsRestService);
        final String jsonInput = toJsonRequest(args, pfsRestService.isEnableLog());

        final String accessToken = accessTokenProviders.getAccessToken(pfsRestService);
        final HttpHeaders headers = generateHeader(accessToken);
        final HttpEntity<?> request = new HttpEntity<>(args[0], headers);

        final long requestId = Thread.currentThread().getId();
        try {
            if (logger().isInfoEnabled()) {
                logger().info("REQUEST REST(#{}) {}\t{}", requestId, url, jsonInput);
            }

            final ResponseEntity<String> response = restTemplate().postForEntity(url, request, String.class);
            final String json = response.getBody();
            if (logger().isDebugEnabled()) {
                logger().debug("RESPONSE REST(#{}) {} {}\t{}", requestId, url, jsonInput, limitCharsSize(json));
            } else if (logger().isInfoEnabled()) {
                logger().info("RESPONSE REST(#{}) {}", requestId, url);
            }

            final R responseWrapper = unmarshallResponseWrapper(joinPoint, json, pfsRestService);
            checkError(url, jsonInput, requestId, responseWrapper);


            return responseWrapper.getResponseBody();

        } catch (HttpStatusCodeException e) {
            final String json = e.getResponseBodyAsString();
            logger().error("ERROR REST(#{}) {} {} : {}\n{}", requestId, url, jsonInput, e.getStatusCode().value(), limitCharsSize(json));

            R responseWrapper = null;
            try {
                responseWrapper = unmarshallResponseWrapper(joinPoint, json, pfsRestService);
            } catch (JsonProcessingException ignore) {
                // ignore
            }

            if (responseWrapper != null) {
                handleError(responseWrapper, e);
            }

            throw new PfsRestException(Header.empty(e.getMessage()), e);
        }
    }

    protected void checkError(String url, String jsonInput, long requestId, R responseWrapper) {
    }

    protected void handleError(R responseWrapper, HttpStatusCodeException e) {
    }


    private HttpHeaders generateHeader(String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HttpHeaders.AUTHORIZATION, accessToken);
        final String codeCassiniAppli = supplierLibService.getCodeCassiniAppli();
        headers.set(HEADER_APPLICATION, codeCassiniAppli);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(HttpHeaders.ACCEPT_CHARSET, StandardCharsets.UTF_8.name());
        return headers;
    }

    public String toJsonRequest(Object[] args, boolean isRestServiceLogEnabled) throws IOException {
        if (!isRestServiceLogEnabled) {
            return "$$$NOLOG$$$";
        }

        final ObjectWriter ow = jsonMapper().writer();
        try (LimitByteArrayOutputStream out = new LimitByteArrayOutputStream(maxChars, "...", true)) {
            try {
                ow.writeValue(out, args[0]);
            } catch (JsonProcessingException e) {
                throw new JsonMarshallerException(e);
            } catch (IOException | LimitByteArrayOutputStream.LimitReachedException ignore) {
            }
            return out.toString();
        }
    }

    public String limitCharsSize(String string) {
        if (string == null || maxChars <= 0 || string.length() <= maxChars) {
            return string;
        }

        return string.substring(0, maxChars) + "...";
    }

    protected String getUrl(PfsRestServiceConfig pfsRestServiceConfig) {
        final String codeCassiniAppli = supplierLibService.getCodeCassiniAppli();
        final String endpoint = endpointResolver.getRestUrl(pfsRestServiceConfig);
        return UrlUtils.appendQueryParams(endpoint, APPLICATION, codeCassiniAppli);
    }


    protected R unmarshallResponseWrapper(ProceedingJoinPoint joinPoint, String json, PfsRestServiceConfig pfsRestService) throws JsonProcessingException {
        try {
            final JavaType javaTypeResponseWrapper = javaTypeResponseWrapper(joinPoint, pfsRestService);
            final Object value = jsonMapper().readValue(json, javaTypeResponseWrapper);
            if (pfsRestService.isRestful()) {
                return (R) new ResponseWrapperSwagger(value);
            }
            return (R) value;

        } catch (JsonProcessingException e) {
            logger().error("Unable to parse JSON [{}] response.", json, e);
            throw e;
        }
    }

    protected JavaType javaTypeResponseWrapper(ProceedingJoinPoint joinPoint, PfsRestServiceConfig pfsRestService) {
        final TypeFactory typeFactory = jsonMapper().getTypeFactory();
        final Class<?> returnType = ((MethodSignature) joinPoint.getSignature()).getReturnType();
        final JavaType javaReturnType = typeFactory.constructType(returnType);
        if (pfsRestService.isRestful()) {
            return javaReturnType;
        }

        return typeFactory.constructParametricType(responseWrapperClass(), javaReturnType);
    }

    protected abstract Class responseWrapperClass();

    protected abstract RestTemplate restTemplate();

    protected abstract ObjectMapper jsonMapper();

    protected abstract Logger logger();
}
