package fr.ag2rlamondiale.trm.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class SelfReferencingBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException /*NOSONAR*/ {
		return bean;
	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException /*NOSONAR*/ {
		if (bean instanceof SelfReferencingBean) {
			((SelfReferencingBean) bean).setProxy(bean);
		}
		return bean;
	}
}
