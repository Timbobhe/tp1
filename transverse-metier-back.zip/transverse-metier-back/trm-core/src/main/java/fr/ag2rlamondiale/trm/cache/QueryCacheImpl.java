package fr.ag2rlamondiale.trm.cache;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.function.BiConsumer;

@Slf4j
@Service
public class QueryCacheImpl implements IQueryCache, ApplicationContextAware {

    @Autowired
    private CacheManager cacheManager;

    @Qualifier(CacheConstants.DEFAULT_KEY_GENERATOR)
    @Autowired
    private KeyGenerator defaultKeyGenerator;

    private ApplicationContext applicationContext;

    @Override
    public boolean isCached(Object target, Method method, Object[] params) {
        final Cacheable cacheable = method.getAnnotation(Cacheable.class);
        if (cacheable == null) {
            return false;
        }

        final KeyGenerator keyGenerator = keyGenerator(cacheable);
        final Object key = keyGenerator.generate(target, method, params);

        for (String cacheName : IQueryCache.cacheNames(cacheable)) {
            final Cache cache = cacheManager.getCache(cacheName);
            if (cache != null) {
                final Cache.ValueWrapper valueWrapper = cache.get(key);
                if (valueWrapper == null) {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    public void withCache(Object target, Method method, Object[] params, BiConsumer<Cache, Object> consumer) {
        final Cacheable cacheable = method.getAnnotation(Cacheable.class);
        if (cacheable == null) {
            return;
        }

        final KeyGenerator keyGenerator = keyGenerator(cacheable);
        final Object key = keyGenerator.generate(target, method, params);

        for (String cacheName : IQueryCache.cacheNames(cacheable)) {
            final Cache cache = cacheManager.getCache(cacheName);
            if (cache != null) {
                consumer.accept(cache, key);
            }
        }
    }

    @Override
    public void withCache(CacheEvict cacheEvict, Object[] params, BiConsumer<Cache, Object> consumer) {
        final KeyGenerator keyGenerator = keyGenerator(cacheEvict);
        final Object key = keyGenerator.generate((Object) null, (Method) null, params);

        for (String cacheName : cacheEvict.cacheNames()) {
            final Cache cache = cacheManager.getCache(cacheName);
            if (cache != null) {
                consumer.accept(cache, key);
            }
        }
    }

    private KeyGenerator keyGenerator(Cacheable cacheable) {
        final String name = cacheable.keyGenerator();
        return keyGenerator(name);
    }

    private KeyGenerator keyGenerator(CacheEvict cacheEvict) {
        final String name = cacheEvict.keyGenerator();
        return keyGenerator(name);
    }

    @Override
    public KeyGenerator keyGenerator(String name) {
        if (name.isEmpty()) {
            return defaultKeyGenerator;
        }
        try {
            return (KeyGenerator) applicationContext.getBean(name);
        } catch (BeansException e) {
            log.error("Impossible de r\u00E9cup\u00E9rer le KeyGenerator '{}'", name, e);
            throw e;
        }
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }
}
