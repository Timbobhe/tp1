package fr.ag2rlamondiale.trm.cache;

public interface JmxCacheManagerMBean {

    void clearCache();


    void setEnableConcurrentCache(boolean enable);

    boolean getEnableConcurrentCache();
}
