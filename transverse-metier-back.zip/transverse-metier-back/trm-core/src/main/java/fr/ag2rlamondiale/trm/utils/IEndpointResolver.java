package fr.ag2rlamondiale.trm.utils;

import fr.ag2rlamondiale.trm.rest.PfsRestServiceConfig;
import fr.ag2rlamondiale.trm.soap.PortInitializer;

public interface IEndpointResolver {

    String getSoapUrl(PortInitializer portInitializer);

    String getRestUrl(PfsRestServiceConfig pfsRestServiceConfig);

    String getSoapUrlForLog(PortInitializer portInitializer);

    String getRestUrlForLog(PfsRestServiceConfig pfsRestServiceConfig);
}
