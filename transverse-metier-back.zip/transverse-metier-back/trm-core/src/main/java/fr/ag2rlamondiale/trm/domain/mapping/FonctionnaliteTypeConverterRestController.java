package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

//@RestController
@RequestMapping(path = "/public")
public class FonctionnaliteTypeConverterRestController {

    // http://localhost:8080/ecrs/api/public/fonctionnalite-type?fonctionnaliteType=VosCoordonneesBancaires
    // http://localhost:8080/ecrs/api/public/fonctionnalite-type?fonctionnaliteType=COORDONNEES_BANCAIRES
    @GetMapping("/fonctionnalite-type")
    public String get(@RequestParam("fonctionnaliteType") FonctionnaliteType fonctionnaliteType) {
        return fonctionnaliteType.name();
    }

}
