package fr.ag2rlamondiale.trm.domain.upload;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.common.base.MoreObjects;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import static org.apache.commons.lang3.StringUtils.isNotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class UploadFileDto implements Serializable {
    private static final long serialVersionUID = 1072518573369022457L;
    private String fileName;
    private String fileContent;

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("fileName", fileName)
                .add("fileContent", isNotBlank(fileContent) ? "<FILECONTENT>" : null)
                .toString();
    }
}
