package fr.ag2rlamondiale.trm;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.util.Arrays;

@Slf4j
@Component
public class SuppliersLib implements BeanPostProcessor {

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        Arrays.stream(bean.getClass().getInterfaces())
                .forEach(aClass -> {
                    final SupplierLib supplierLib = aClass.getAnnotation(SupplierLib.class);
                    if (supplierLib != null) {
                        log.info("SupplierLib {} => {} ({})", aClass, beanName, bean.getClass());
                        Arrays.stream(aClass.getMethods())
                                .filter(method -> method.getAnnotation(SupplierLib.LogOnStartup.class) != null)
                                .forEach(method -> {
                                    final Object value = ReflectionUtils.invokeMethod(method, bean);
                                    log.info("SupplierLib {} => {} ({}) - {}={}", aClass, beanName, bean.getClass(), method.getName(), value);
                                });
                    }
                });

        return bean;
    }
}
