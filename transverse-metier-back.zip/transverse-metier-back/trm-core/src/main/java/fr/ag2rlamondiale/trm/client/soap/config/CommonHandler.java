package fr.ag2rlamondiale.trm.client.soap.config;

import fr.ag2rlamondiale.trm.utils.LimitByteArrayOutputStream;
import lombok.extern.slf4j.Slf4j;

import javax.xml.soap.SOAPException;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.IOException;

@Slf4j
public class CommonHandler {

    protected final int maxChars;

    public CommonHandler(int maxChars) {
        this.maxChars = maxChars;
    }

    public boolean handleFault(SOAPMessageContext context) {
        try (LimitByteArrayOutputStream out = new LimitByteArrayOutputStream(maxChars, "...", true)) {
            String str = toString(context, out);
            log.error("SOAP FAULT =>\n{}", str);
        } catch (IOException e) {
            log.error("IOException exception", e);
        } catch (Exception e) {
            log.error("Exception exception", e);
        }

        return false;
    }

    private String toString(SOAPMessageContext context, LimitByteArrayOutputStream out) {
        try {
            context.getMessage().writeTo(out);
        } catch (LimitByteArrayOutputStream.LimitReachedException | SOAPException | IOException ignore) {
            // ignore
        }
        return out.toString();
    }
}
