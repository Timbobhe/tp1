package fr.ag2rlamondiale.trm.pdf;

/**
 * Classe d'exception pour les PDF
 *
 */
public class PDFException extends Exception {
    /**
     * Commentaire pour <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = -2674118030356138779L;

    public PDFException(String message, Throwable cause) {
        super(message, cause);
    }

    public PDFException(String message) {
        super(message);
    }

    public PDFException(Throwable cause) {
        super(cause);
    }
}
