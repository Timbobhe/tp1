package fr.ag2rlamondiale.trm.supervision;

import com.ag2r.common.administration.model.AbstractTestManager;
import com.ag2r.common.administration.model.TestReport;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;

@Component
@ActiveTest
@Slf4j
public class MemoryUsage extends AbstractTestManager {
    private static final long MEGABYTE_FACTOR = 1024L * 1024L;
    private static final String MIB = "MiB";

    public MemoryUsage() {
        setName("MemoryUsage");
    }

    @Override
    public TestReport performTest() {
        TestReport report = new TestReport(TestReport.RESULT_OK);
        report.setReport(memoryStats().toString());
        return report;
    }


    @Scheduled(fixedRateString = "${memoryUsage.log.fixedRate:600000}") // 10min
    public MemoryStats memoryStats() {
        Runtime instance = Runtime.getRuntime();
        MemoryStats memoryStats = new MemoryStats();
        final long totalMemory = instance.totalMemory();
        final long freeMemory = instance.freeMemory();
        final long maxMemory = instance.maxMemory();
        final long usedMemory = totalMemory - freeMemory;

        memoryStats.setTotalMemory(formatBytesToMiB(totalMemory));
        memoryStats.setMaxMemory(formatBytesToMiB(maxMemory));
        memoryStats.setUsedMemory(formatBytesToMiB(usedMemory));
        memoryStats.setFreeMemory(formatBytesToMiB(freeMemory));

        DecimalFormat decimalFormat = new DecimalFormat("####0.00");
        decimalFormat.setGroupingUsed(false);
        final double percentageUsed = ((double) usedMemory / maxMemory) * 100;
        memoryStats.setPercentageUsed(decimalFormat.format(percentageUsed) + "%");
        log.info("MemoryUsage = {}", memoryStats);
        return memoryStats;
    }

    private String formatBytesToMiB(long bytes) {
        DecimalFormat decimalFormat = new DecimalFormat("####0.00");
        decimalFormat.setGroupingUsed(false);
        double mib = (double) bytes / MEGABYTE_FACTOR;
        return String.format("%s %s", decimalFormat.format(mib), MIB);
    }


    @Data
    public static class MemoryStats {
        private String totalMemory;
        private String freeMemory;
        private String maxMemory;
        private String usedMemory;
        private String percentageUsed;
    }
}
