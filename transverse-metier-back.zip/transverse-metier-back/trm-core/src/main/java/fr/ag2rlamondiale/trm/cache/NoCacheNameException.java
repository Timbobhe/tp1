package fr.ag2rlamondiale.trm.cache;

public class NoCacheNameException extends CacheException {

    public NoCacheNameException(String message) {
        super(message);
    }
}
