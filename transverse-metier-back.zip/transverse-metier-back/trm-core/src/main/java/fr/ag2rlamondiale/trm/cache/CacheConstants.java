package fr.ag2rlamondiale.trm.cache;

public final class CacheConstants {
    public static final String REQUEST_CACHE_RESOLVER = "requestCacheResolver";
    public static final String RUNTIME_CACHE_RESOLVER = "runtimeCacheResolver";
    public static final String SIMPLE_KEY_GENERATOR = "simpleKeyGenerator";
    public static final String DEFAULT_KEY_GENERATOR = "withMethodSimpleKeyGenerator";
    public static final String WITH_XCALLER_KEY_GENERATOR = "withMethodAndXCallerSimpleKeyGenerator";
    public static final String XCALLER_SIMPLE_KEY_GENERATOR = "xCallerSimpleKeyGenerator";
    public static final String DEFAULT_EHCACHE_MANAGER = "ehCacheManager";
    public static final String SOAP_CACHE = "soapCache";
    public static final String CONSOLE_PARAM_CACHE = "consoleParamCache";
    public static final String UPLOAD_FILE_VALID_CACHE = "uploadFileValidCache";
    public static final String JAHIA_CACHE = "jahiaCache";

    static final String REQUEST_SCOPED_CACHE_MANAGER = "requestScopedCacheManager";

    private CacheConstants() {
    }
}
