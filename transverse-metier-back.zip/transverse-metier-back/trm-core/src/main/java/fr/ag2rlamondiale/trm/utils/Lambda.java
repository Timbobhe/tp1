package fr.ag2rlamondiale.trm.utils;

import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;

import java.util.concurrent.Callable;

public class Lambda {

    private Lambda() {
    }


    public static <V> V handleException(Callable<V> callable) {
        try {
            return callable.call();
        } catch (Exception e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    public static void handleException(Code code) {
        try {
            code.run();
        } catch (Exception e) {
            throw new TechnicalRuntimeException(e);
        }
    }


    public static Runnable sneakyThrows(Code code) {
        return () -> handleException(code);
    }


    @FunctionalInterface
    public interface Code {
        @SuppressWarnings("squid:S00112")
        void run() throws Exception;
    }

}
