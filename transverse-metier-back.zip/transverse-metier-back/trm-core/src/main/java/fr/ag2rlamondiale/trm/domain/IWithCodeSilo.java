package fr.ag2rlamondiale.trm.domain;

@FunctionalInterface
public interface IWithCodeSilo {

    CodeSiloType getCodeSilo();
}
