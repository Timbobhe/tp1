package fr.ag2rlamondiale.trm.supervision;

import com.ag2r.common.administration.model.AbstractTestManager;
import com.ag2r.common.administration.model.TestReport;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.security.UserSecurityContext;
import fr.ag2rlamondiale.trm.security.UserSecurityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import static com.ag2r.common.administration.model.TestReport.RESULT_KO;

@Profile(BaseTestManager.PROFILE_TESTMANAGER)
@Slf4j
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class TestManagerInterceptor extends AbstractTestManager {

    @Autowired
    private UserSecurityService userSecurityService;

    @Autowired
    private UserSecurityContext securityContext;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private UserTestManager userTestManager;

    private final AbstractTestManager testManager;

    public TestManagerInterceptor(AbstractTestManager testManager) {
        this.testManager = testManager;
    }

    private void initContext() {
        userSecurityService.initSecurityContext(userTestManager);
    }

    private void clearContext() {
        securityContext.clear();
        userContextHolder.clean();
    }

    @Override
    public TestReport performTest() {
        final long start = System.currentTimeMillis();
        try {
            log.info("Debut d'ex\u00e9cution du test {}", getName());
            initContext();
            return testManager.performTest();
        } catch (Exception e) {
            log.error("Erreur \u00e0 l'ex\u00e9cution du test {}", getName(), e);
            TestReport report = new TestReport();
            report.setName(testManager.getName());
            report.setCause(e);
            report.setResult(RESULT_KO);
            return report;
        } finally {
            clearContext();
            final long time = System.currentTimeMillis() - start;
            log.info("Fin d'ex\u00e9cution du test {} en {} ms", getName(), time);
        }
    }

    @Override
    public String getName() {
        return testManager.getName();
    }
}
