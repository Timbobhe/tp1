package fr.ag2rlamondiale.trm.utils;

import lombok.extern.slf4j.Slf4j;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.function.Supplier;

@Slf4j
public class LockCache {
    private volatile boolean cacheValid;
    private volatile boolean writeLocking = false;
    private final ReentrantReadWriteLock rwl = new ReentrantReadWriteLock();

    private Object keyLock;
    private final AtomicReference<Instant> timestamp = new AtomicReference<>();

    public LockCache() {
    }

    public LockCache(Object keyLock) {
        this.keyLock = keyLock;
    }

    public void resetCache() {
        this.cacheValid = false;
    }

    public boolean isCacheValid() {
        return cacheValid;
    }

    public <T> T concurrent(Supplier<T> reader, Runnable writer) {
        rwl.readLock().lock();
        invoke(writer);
        try {
            log.trace("READ");
            return reader.get();
        } finally {
            rwl.readLock().unlock();
        }
    }

    private void invoke(Runnable writer) {
        if (!cacheValid) {
            // Must release read lock before acquiring write lock
            rwl.readLock().unlock();
            rwl.writeLock().lock();
            try {
                this.writeLocking = true;
                // Recheck state because another thread might have
                // acquired write lock and changed state before we did.
                if (!cacheValid) {
                    writer.run();
                    timestamp.set(Instant.now());
                    cacheValid = true;
                    log.trace("WRITE");
                }
                // Downgrade by acquiring read lock before releasing write lock
                rwl.readLock().lock();
            } finally {
                rwl.writeLock().unlock(); // Unlock write, still hold read
                this.writeLocking = false;
            }
        }
    }

    public boolean isWriteLocking() {
        return this.writeLocking;
    }

    public Instant writeTimestamp() {
        return timestamp.get();
    }

    public Object getKeyLock() {
        return keyLock;
    }
}
