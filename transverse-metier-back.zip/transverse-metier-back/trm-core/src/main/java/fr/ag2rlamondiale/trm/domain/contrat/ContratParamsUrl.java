package fr.ag2rlamondiale.trm.domain.contrat;

import fr.ag2rlamondiale.trm.security.ISecurityParamAccess;
import lombok.Data;

@Data
public class ContratParamsUrl implements ISecurityParamAccess {
    private String contrat;
    private String idCollege;

    @Override
    public String secureForNumContrat() {
        return contrat;
    }

    public String getNomContrat() {
        return contrat;
    }
}
