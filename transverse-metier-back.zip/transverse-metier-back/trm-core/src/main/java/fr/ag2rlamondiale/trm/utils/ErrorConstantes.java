/*
 * Cree le 15 nov. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.utils;

/**
 * Constantes des codes erreurs remontés dans l'application
 */
public class ErrorConstantes {
    /**********************
     * Niveau d'erreur (métier ou technique)
     */
    public static final String ERREUR_METIER = "business-error";
    public static final String ERREUR_TECHNIQUE = "technical-error";

    /**********************
     * Codes d'erreurs métiers
     */
    public static final String UTILISATEUR_NON_TROUVE = "user-not-found";
    public static final String LISTE_CONTRAT_VIDE = "contract-empty-list";
    public static final String ENCOURS_CONTRAT_INDISPONIBLE = "amount-contrat-unavailable";
    public static final String INFOS_CONTRAT_INDISPONIBLE = "info-contrat-unavailable";
    public static final String INFOS_CLAUSES_BENEF_INDISPONIBLE = "info-clause-unavailable";
    public static final String PAS_CONTRAT_ELIGIBLE = "no-eligible-contract";
    public static final String PIECE_JOINTE_INVALIDE_CODE = "30";

    private ErrorConstantes() {}
}
