package fr.ag2rlamondiale.trm.rest;


import fr.ag2rlamondiale.trm.rest.jaxb.response.Header;

public class PfsRestException extends RuntimeException {
    private static final long serialVersionUID = -1040685742619352789L;

    private final transient Header header;

    public PfsRestException(Header header) {
        this(header, null);
    }

    public PfsRestException(Header header, Throwable cause) {
        super(header.getErrorMessage(), cause);
        this.header = header;
    }

    public Header getHeader() {
        return header;
    }
}
