package fr.ag2rlamondiale.trm.soap;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import fr.ag2rlamondiale.trm.client.soap.config.SoapRequestContext;
import fr.ag2rlamondiale.trm.client.soap.config.SoapRequestContextHolder;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.IWithCodeSilo;
import fr.ag2rlamondiale.trm.security.AuthentificationUtils;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.SecurityServiceConfig;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
public class SoapRequestInterceptor implements Ordered {

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private SecurityServiceConfig securityServiceConfig;

    @Before("@annotation(soapRequest)")
    public void beforeAdvice(JoinPoint joinPoint, SoapRequest soapRequest) {
        log.debug("Before soapRequest [{}]", Thread.currentThread().getId());
        SoapRequestContext soapRequestContext = new SoapRequestContext();
        if (soapRequest.connectedRequest() && userContextHolder.get().isConnectedUser()) {
            soapRequestContext.setIdGdi(getIdGdi());
            soapRequestContext.setEnableXCaller(soapRequest.enableXCaller());
        }
        soapRequestContext.setHasSecurityHeader(soapRequest.hasSecurityHeader());
        soapRequestContext.setForceLogBody(soapRequest.forceLogBody());
        if (soapRequest.useSharepointToken()) {
            final Object firstArg = joinPoint.getArgs()[0];
            if (!(firstArg instanceof CodeSiloType) && !(firstArg instanceof IWithCodeSilo)) {
                log.error("Attention, lors d'un appel ged ou sharepoint, "
                        + "le silo [CodeSiloType] doit \u00eatre renseign\u00e9 en 1er argument (Il faut passer le Sil impl\u00e9menter l'interface IWithCodeSilo)");
            }

            CodeSiloType codeSilo = null;
            if (firstArg instanceof CodeSiloType) {
                codeSilo = (CodeSiloType) firstArg;
            } else if (firstArg instanceof IWithCodeSilo) {
                codeSilo = ((IWithCodeSilo) firstArg).getCodeSilo();
            }

            soapRequestContext.setHasSharepointTokenEre(CodeSiloType.ERE == codeSilo);
            soapRequestContext.setHasSharepointTokenMdpro(CodeSiloType.MDP == codeSilo);
        } else {
            soapRequestContext.setHasSharepointTokenEre(false);
            soapRequestContext.setHasSharepointTokenMdpro(false);
        }

        if (!soapRequest.externalSecurityHeader().isEmpty()) {
            soapRequestContext.setSecurityHeaderInfo(securityServiceConfig.getSecurityHeaderInfo(soapRequest.externalSecurityHeader()));
        }

        soapRequestContext.setArg(null, joinPoint.getArgs());

        SoapRequestContextHolder.set(soapRequestContext);
    }


    @After("@annotation(soapRequest)")
    public void afterAdvice(JoinPoint joinPoint, SoapRequest soapRequest) {
        SoapRequestContextHolder.clean();
    }

    private String getIdGdi() {
        final UserContext userContext = userContextHolder.get();
        if (!userContext.isConnectedUser()) {
            return null;
        }

        if (userContext.isForSupervision()) {
            return userContext.getIdGdi();
        }

        try {
            return AuthentificationUtils.getIdGdi();
        } catch (Exception e) {
            log.warn("Impossible de r\u00e9cup\u00e9rer l'idgdi depuis le contexte "
                    + "de s\u00e9curit\u00e9 spring lors d'un appel soap", e);
            return userContext.getIdGdi();
        }
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.PREPARE_SOAP_REQUEST_ORDER;
    }
}
