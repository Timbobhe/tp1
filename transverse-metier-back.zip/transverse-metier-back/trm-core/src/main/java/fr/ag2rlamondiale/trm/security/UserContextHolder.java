package fr.ag2rlamondiale.trm.security;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpSession;
import java.util.Objects;

@Slf4j
@Component
public class UserContextHolder {

    public static final String SESSION_USER_CONTEXT = "USER_CONTEXT";
    private static final InheritableThreadLocal<UserContext> USER_CONTEXT = new InheritableThreadLocal<>();

    @Getter
    @Value("${disconnect.technical.idgdi:#{null}}")
    private String technicalIdGdi;


    @Autowired
    private ISupplierLibService supplierLibService;

    public void setDisconnectUserContext() {
        set(new DisconnectUserContext(technicalIdGdi == null ? supplierLibService.getCodeCassiniAppli() : technicalIdGdi));
    }

    public void set(UserContext requestContext) {
        USER_CONTEXT.set(requestContext);
    }

    public UserContext get() {
        UserContext userContext = USER_CONTEXT.get();
        if (userContext == null) {
            userContext = new UserContext();
            set(userContext);
        }
        return userContext;
    }

    public static UserContext getUserContext(HttpSession httpSession) {
        return (UserContext) httpSession.getAttribute(SESSION_USER_CONTEXT);
    }

    public static UserContext getUserContext() {
        return USER_CONTEXT.get();
    }

    public static void setUserContext(UserContext requestContext) {
        USER_CONTEXT.set(requestContext);
    }

    public static void reset() {
        USER_CONTEXT.remove();
    }

    public void clean() {
        USER_CONTEXT.remove();
    }

    /**
     * @return element session {@link HttpSession}
     */
    private HttpSession getHttpSession() {
        HttpSession httpSession;
        try {
            ServletRequestAttributes attr =
                    (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            httpSession = attr.getRequest().getSession(false);
        } catch (Exception e) {
            log.debug("Impossible de r\u00e9cup\u00e9rer la session : {}", e.toString());
            return null;
        }
        return httpSession;
    }

    /**
     * Sauvegarde le {@link UserContext} dans la SESSION HTTP
     *
     * @param userContext
     */
    public void save(UserContext userContext) {
        set(userContext);
        Objects.requireNonNull(userContext);
        final HttpSession httpSession = getHttpSession();
        Objects.requireNonNull(httpSession);
        httpSession.setAttribute(SESSION_USER_CONTEXT, userContext);
    }

    /**
     * Sauvegarde le {@link UserContext} COURANT dans la SESSION HTTP
     */
    public void save() {
        save(get());
    }

    public String getSessionId() {
        final HttpSession httpSession = getHttpSession();
        if (httpSession == null) {
            return null;
        }

        return httpSession.getId();
    }

    public UserContextHolder setCurrentIdContrat(String idContrat) {
        get().setCurrentIdContrat(idContrat);
        return this;
    }


    public UserContextHolder setCurrentCodeSilo(String codeSilo) {
        get().setCurrentCodeSilo(codeSilo);
        return this;
    }
}
