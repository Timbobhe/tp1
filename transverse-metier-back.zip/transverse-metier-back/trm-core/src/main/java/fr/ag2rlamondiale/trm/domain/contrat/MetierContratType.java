package fr.ag2rlamondiale.trm.domain.contrat;

public enum MetierContratType {
    RETRAITE_SUPPLEMENTAIRE, EPARGNE;
}
