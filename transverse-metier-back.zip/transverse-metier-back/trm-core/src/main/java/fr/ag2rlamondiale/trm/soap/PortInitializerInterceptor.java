package fr.ag2rlamondiale.trm.soap;

import com.sun.xml.ws.developer.WSBindingProvider;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.client.soap.config.*;
import fr.ag2rlamondiale.trm.utils.IEndpointResolver;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.MessageContext;
import java.util.*;
import java.util.function.Consumer;

@Aspect
@Component
public class PortInitializerInterceptor {

    @Autowired
    private SoapClientHandlerResolverFactory soapClientHandlerResolverFactory;

    @Autowired
    private IEndpointResolver endpointResolver;

    @Autowired
    private ISupplierLibService supplierLib;

    @Autowired
    private IHeadersProvider headersProvider;

    @AfterReturning(pointcut = "@annotation(portInitializer)", returning = "result")
    public void afterReturning(JoinPoint joinPoint, Object result, PortInitializer portInitializer) {
        if (result instanceof WSBindingProvider) {
            WSBindingProvider bp = (WSBindingProvider) result;

            String url = endpointResolver.getSoapUrl(portInitializer);
            initPort(bp, url);

            final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
            Objects.requireNonNull(soapRequestContext, "Il doit manquer @SoapRequest dans la methode d'appel");
            soapRequestContext.setEndpoint(url);

            SoapClientHandlerResolver soapClientHandlerResolver =
                    soapClientHandlerResolverFactory.createSoapClientHandlerResolver();

            if (portInitializer.withAttachment()) {
                AttachmentResponse attachmentResponse = attachmentResponse(joinPoint.getArgs());
                if (attachmentResponse != null) {
                    soapClientHandlerResolver.addHandler(new AttachementHandler(attachmentResponse));
                } else {
                    throw new IllegalArgumentException(
                            "Le Port Soap " + joinPoint.toShortString() + " doit avoir en 1er argument un objet "
                                    + AttachmentResponse.class);
                }
            }

            Object[] args = joinPoint.getArgs();
            if (portInitializer.handleSoapClientHandler()) {
                handleSoapClientHandlerResolver(soapClientHandlerResolver, args[args.length - 1]);
            }

            @SuppressWarnings("rawtypes")
            List<Handler> handlerChain = soapClientHandlerResolver.getHandlerChain(portInitializer.enableLog());
            bp.getBinding().setHandlerChain(handlerChain);

            final Object header = headersProvider.buildHeader();
            if (header != null) {
                bp.setOutboundHeaders(header);
            }
        }
    }

    public void handleSoapClientHandlerResolver(SoapClientHandlerResolver soapClientHandlerResolver, Object last) {
        if (last instanceof Consumer) {
            ((Consumer<SoapClientHandlerResolver>) last).accept(soapClientHandlerResolver);
        }
    }


    private AttachmentResponse attachmentResponse(Object[] args) {
        if (args == null || args.length == 0) {
            return null;
        }

        if (args[0] instanceof AttachmentResponse) {
            return (AttachmentResponse) args[0];
        }

        return null;
    }

    /*
     * Fonction permettant d'ajouter l'entete http exigé par la pfs pour identifier notre applicatif
     */
    private Map<String, List<String>> getRequestHeaders() {
        Map<String, List<String>> requestHeaders = new HashMap<>();
        requestHeaders.put("X-Forwarded-For", Collections.singletonList(supplierLib.getCodeCassiniAppli()));
        return requestHeaders;
    }

    protected void initPort(BindingProvider port, String url) {
        port.getRequestContext().put(MessageContext.HTTP_REQUEST_HEADERS, getRequestHeaders());
        port.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, url);
    }
}
