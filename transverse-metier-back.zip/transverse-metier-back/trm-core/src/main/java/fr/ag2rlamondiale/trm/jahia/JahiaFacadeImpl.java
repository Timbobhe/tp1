package fr.ag2rlamondiale.trm.jahia;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.trm.cache.CacheConstants;
import fr.ag2rlamondiale.trm.domain.document.DictionaryKeyType;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

@Slf4j
@Service
public class JahiaFacadeImpl implements IJahiaFacade, SelfReferencingBean {

    private static final String HTTP_METHOD = "GET";
    private static final String EXTENSION_PDF = ".pdf";
    private static final String SEPARATOR = "_";
    private static final String HEAD = "HEAD";

    @Value("${ere.jahia.ressources.root}")
    private String jahiaUrl;

    @Value("${ere.jahia.ressources.document.root}")
    private String documentUrl;

    private static final String DEFAULT = "default";

    private IJahiaFacade springProxy;

    @Setter
    private JahiaUrlConnection jahiaUrlConnection = new DefaultJahiaUrlConnection();

    @Override
    public String findDictionaryEntry(DictionaryKeyType dictionaryKeyType, String key) throws IOException {
        JsonNode dictionary = this.springProxy.findDictionary(dictionaryKeyType);
        final JsonNode dicoEntry = dictionary.get(key);
        if (dicoEntry == null) {
            return null;
        }
        return StringEscapeUtils.unescapeHtml4(StringEscapeUtils.unescapeXml(String.valueOf(dicoEntry.textValue())));
    }

    @Override
    public boolean dictionaryContainsEntry(DictionaryKeyType dictionaryKeyType, String key) throws IOException {
        return this.findDictionaryEntry(dictionaryKeyType, key) != null;
    }

    @Override
    public String findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType dictionaryKeyType, String numContrat, String codeFiliale) throws IOException {
        String entry = null;
        if (this.springProxy.findDictionary(dictionaryKeyType) != null) {

            if (this.dictionaryContainsEntry(dictionaryKeyType, numContrat)) {
                entry = this.findDictionaryEntry(dictionaryKeyType, numContrat);
            } else if (this.dictionaryContainsEntry(dictionaryKeyType, codeFiliale)) {
                entry = this.findDictionaryEntry(dictionaryKeyType, codeFiliale);
            } else {
                return this.findDictionaryEntry(dictionaryKeyType, "DEFAULT");
            }
        }
        return entry;
    }


    @Override
    public String locateDocument(String documentType, String numContrat) {
        return numContrat != null ? documentUrl +
                documentType + SEPARATOR + numContrat + EXTENSION_PDF
                : documentUrl + documentType + EXTENSION_PDF;
    }

    @LogExecutionTime
    @Cacheable(CacheConstants.JAHIA_CACHE)
    @NoAuthRequired
    public byte[] getDocument(String documentPath) throws IOException {
        URL url = new URL(documentPath);
        HttpURLConnection connection = getUrlConnection(url);
        connection.setDoOutput(true);
        connection.setRequestMethod(HTTP_METHOD);
        return IOUtils.toByteArray(connection.getInputStream());
    }

    private HttpURLConnection getUrlConnection(URL url) throws IOException {
        return this.jahiaUrlConnection.getUrlConnection(url);
    }


    @Override
    public String getExistingFileName(String pathAQE, String extension, String numContrat, String codeFiliale) {
        final String contratFilename = pathAQE + numContrat + extension;
        if (exists(contratFilename)) {
            return contratFilename;
        }
        final String filialeFilename = pathAQE + codeFiliale + extension;
        if (exists(filialeFilename)) {
            return filialeFilename;
        }

        return pathAQE + DEFAULT + extension;
    }


    @Override
    @Cacheable(CacheConstants.JAHIA_CACHE)
    @NoAuthRequired
    public JsonNode findDictionary(DictionaryKeyType dictionaryKeyType) throws IOException {
        URL urlFinal = getUrl(dictionaryKeyType);
        HttpURLConnection connection = getUrlConnection(urlFinal);
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readTree(connection.getInputStream()).get("entries");
    }

    public URL getUrl(DictionaryKeyType dictionaryKeyType) throws MalformedURLException {
        String path = jahiaUrl + dictionaryKeyType.getUrl() + ".apiDico.html.ajax";
        return new URL(path);
    }

    @Override
    public String getLastModified(String documentPath) throws IOException {
        URL url = new URL(documentPath);
        HttpURLConnection connection = getUrlConnection(url);
        return String.valueOf(connection.getLastModified());
    }

    private boolean exists(String urlName) {
        try {
            HttpURLConnection con = getUrlConnection(new URL(urlName));
            con.setRequestMethod(HEAD);
            return con.getResponseCode() == HttpURLConnection.HTTP_OK;
        } catch (Exception e) {
            log.debug(e.getMessage());
            return false;
        }
    }

    @Override
    public void setProxy(Object proxy) {
        this.springProxy = (IJahiaFacade) proxy;
    }
}
