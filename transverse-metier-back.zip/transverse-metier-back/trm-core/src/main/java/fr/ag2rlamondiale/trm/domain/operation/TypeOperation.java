package fr.ag2rlamondiale.trm.domain.operation;

import lombok.Data;

import java.io.Serializable;
@Data
public class TypeOperation implements Serializable {
    private static final long serialVersionUID = 5530143131678853562L;

    private String code;
    private String libelleOutil;
    private String langue;
    private String libelleFrontExtranet;
    private boolean afficher;
    private boolean avecMontant;
    private boolean avecDetail;

    public TypeOperation() {
        // Constructeur vide
    }

    public TypeOperation(String code, String libelleOutil, String langue,
            String libelleFrontExtranet, boolean afficher, boolean avecMontant,
            boolean avecDetail) {
        this.code = code;
        this.libelleOutil = libelleOutil;
        this.langue = langue;
        this.libelleFrontExtranet = libelleFrontExtranet;
        this.afficher = afficher;
        this.avecMontant = avecMontant;
        this.avecDetail = avecDetail;
    }
}
