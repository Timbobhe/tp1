package fr.ag2rlamondiale.trm.client.soap.config;

import lombok.extern.slf4j.Slf4j;

import javax.annotation.Nullable;
import javax.xml.namespace.QName;
import javax.xml.soap.SOAPException;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Set;

@Slf4j
public class HolderXmlResponseHandler extends CommonHandler implements SOAPHandler<SOAPMessageContext> {

    private String xmlResponse;

    public HolderXmlResponseHandler() {
        super(-1);
    }

    @Override
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }

    @Override
    public boolean handleMessage(SOAPMessageContext smc) {
        if(!Boolean.TRUE.equals(smc.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY))){
            try{
                setXmlResponse(getMessageBody(smc));
            }catch (SOAPException | IOException e){
                log.error("Exception lors de la gestion de la reponse", e);
            }
        }
        return true;
    }

    @Nullable
    public String getMessageBody(SOAPMessageContext smc) throws IOException, SOAPException {
        final String str;
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            smc.getMessage().writeTo(out);
            str = out.toString();
        }
        return str;
    }

    @Override
    public void close(MessageContext smc) {

    }

    public String getXmlResponse() {
        return xmlResponse;
    }

    public void setXmlResponse(String xmlResponse) {
        this.xmlResponse = xmlResponse;
    }
}
