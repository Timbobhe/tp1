package fr.ag2rlamondiale.trm.utils;

public class XmlMarshallerException extends RuntimeException {
    private static final long serialVersionUID = -2020685978172301723L;

    public XmlMarshallerException() {
        // Constructeur vide
    }

    public XmlMarshallerException(String message) {
        super(message);
    }

    public XmlMarshallerException(String message, Throwable cause) {
        super(message, cause);
    }

    public XmlMarshallerException(Throwable cause) {
        super(cause);
    }

    public XmlMarshallerException(String message, Throwable cause, boolean enableSuppression,
            boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
