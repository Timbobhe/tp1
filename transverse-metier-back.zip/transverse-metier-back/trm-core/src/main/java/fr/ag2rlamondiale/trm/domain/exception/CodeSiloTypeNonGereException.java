package fr.ag2rlamondiale.trm.domain.exception;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;

public class CodeSiloTypeNonGereException extends RuntimeException {

    public CodeSiloTypeNonGereException() {
    }

    public CodeSiloTypeNonGereException(CodeSiloType codeSiloType) {
        this(codeSiloType + " non géré");
    }

    public CodeSiloTypeNonGereException(String message) {
        super(message);
    }

    public CodeSiloTypeNonGereException(String message, Throwable cause) {
        super(message, cause);
    }

    public CodeSiloTypeNonGereException(Throwable cause) {
        super(cause);
    }

    public CodeSiloTypeNonGereException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
