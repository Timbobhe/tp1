package fr.ag2rlamondiale.trm.domain.error;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * Erreur retournée par un service REST
 */
@Data
public class RestError {
    /**
     * Niveau de l'erreur (métier ou technique)
     */
    @JsonProperty(value = "errorLevel")
    private String level;

    /**
     * Code de l'erreur (fixé dans l'application ou récupéré à partir de l'exception remontée du
     * serveur)
     */
    @JsonProperty(value = "errorCode")
    private String code;

    /**
     * Messages supplémentaires précisant l'erreur (optionnel)
     */
    @JsonProperty(value = "additionnalMessages")
    private List<String> additionnalMessages = new ArrayList<>();

    /**
     * Constructeur.
     * 
     * @param level niveau de l'erreur
     * @param code code de l'erreur
     */
    public RestError(String level, String code) {
        this.level = level;
        this.code = code;
        this.additionnalMessages = new ArrayList<>();
    }

    /**
     * Constructeur.
     * 
     * @param level niveau de l'erreur
     * @param code code de l'erreur
     */
    public RestError(String level, String code, List<String> additionnalMessages) {
        this.level = level;
        this.code = code;
        this.additionnalMessages = additionnalMessages;
    }

    public RestError addMessage(String additionnalMessage) {
        this.additionnalMessages.add(additionnalMessage);
        return this;
    }

    public RestError addMessages(List<String> additionnalMessages) {
        this.additionnalMessages.addAll(additionnalMessages);
        return this;
    }
}
