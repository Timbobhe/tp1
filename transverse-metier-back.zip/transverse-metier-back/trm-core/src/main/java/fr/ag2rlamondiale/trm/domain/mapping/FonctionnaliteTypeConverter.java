package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import lombok.Setter;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.core.convert.converter.ConverterRegistry;
import org.springframework.stereotype.Component;

@Component
public class FonctionnaliteTypeConverter implements Converter<String, FonctionnaliteType>, InitializingBean {

    @Autowired
    @Setter
    private ConverterRegistry converterRegistry;

    @Override
    public FonctionnaliteType convert(String label) {
        return FonctionnaliteType.fromLabel(label);
    }

    @Override
    public void afterPropertiesSet() {
        converterRegistry.addConverter(String.class, FonctionnaliteType.class, this);
    }
}
