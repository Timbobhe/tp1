package fr.ag2rlamondiale.trm;

@SupplierLib
public interface ISupplierLibService {

    /**
     * Retourne le Code Cassini Appli de l'application intégrante
     *
     * @return
     */
    @SupplierLib.LogOnStartup
    String getCodeCassiniAppli();

    @SupplierLib.LogOnStartup
    String getLibelleAppli();

    @SupplierLib.LogOnStartup
    String getUrlFront();
}
