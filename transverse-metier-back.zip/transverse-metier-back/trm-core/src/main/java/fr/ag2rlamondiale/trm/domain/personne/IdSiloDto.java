package fr.ag2rlamondiale.trm.domain.personne;

import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.Data;

import java.io.Serializable;

@Data
public class IdSiloDto implements Serializable {
    private static final long serialVersionUID = 3832785686826378869L;
    private String libIdPersonne;
    private String codeAppli;
    private String codeSysInfo;

    public IdSiloDto(String libIdPersonne, String codeAppli, String codeSysInfo) {
        this.libIdPersonne = libIdPersonne;
        this.codeAppli = codeAppli;
        this.codeSysInfo = codeSysInfo;
    }

    public static IdSiloDto forAppli(String libIdPersonne, CodeApplicationType codeApplicationType) {
        final CodeSiloType silo = codeApplicationType.getSilo();
        return new IdSiloDto(libIdPersonne, codeApplicationType.getCode(), silo != null ? silo.getLibelle() : null);
    }
}
