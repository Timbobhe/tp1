package fr.ag2rlamondiale.trm.spring;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.ConfigurationCondition;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.util.MultiValueMap;

import java.util.Objects;

/**
 * Cette condition va s'assurer que l'implémentation fournie par la libraire ne doit être utilisée que si elle est la seule implémentation existante.<br>
 * A utiliser de concert avec {@link ConditionnalAppImpl} car on ne connait pas l'ordre de traitement des beans par Spring.
 */
@Slf4j
public class ConditionnalDefaultImpl implements ConfigurationCondition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        MultiValueMap<String, Object> attrs = metadata.getAllAnnotationAttributes(DefaultImpl.class.getName());
        if (attrs != null) {
            for (Object value : attrs.get("implemtationOf")) {
                final Class<?> implemtationOf = (Class<?>) value;
                try {
                    Objects.requireNonNull(context.getBeanFactory()).getBean(implemtationOf);
                } catch (NoUniqueBeanDefinitionException e) {
                    return false;
                } catch (NoSuchBeanDefinitionException e) {
                    return true;
                } catch (BeanCreationException ignore) {
                    // la création du Bean sera (re)faite correctement par Spring ensuite
                }
            }
        }
        return true;
    }

    @Override
    public ConfigurationPhase getConfigurationPhase() {
        return ConfigurationPhase.REGISTER_BEAN;
    }
}
