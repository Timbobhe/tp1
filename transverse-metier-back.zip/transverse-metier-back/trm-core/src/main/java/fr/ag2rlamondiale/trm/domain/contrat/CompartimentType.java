package fr.ag2rlamondiale.trm.domain.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CompartimentType {
    C1("Votre \u00e9pargne individuelle d\u00e9ductible", "LABEL_COMPARTIMENT_C1") {
        @Override
        public String getLabel(CodeSiloType codeSilo, boolean pacte) {
            if (CodeSiloType.MDP.equals(codeSilo)) {
                return super.getLabel(codeSilo, pacte);
            }

            return pacte ? "Vos versements volontaires déductibles" : "Vos versements individuels et facultatifs";
        }
    },
    C4("Votre \u00e9pargne individuelle non d\u00e9ductible", "LABEL_COMPARTIMENT_C4") {
        @Override
        public String getLabel(CodeSiloType codeSilo, boolean pacte) {
            if (CodeSiloType.MDP.equals(codeSilo)) {
                return super.getLabel(codeSilo, pacte);
            }

            return pacte ? "Vos versements volontaires non déductibles" : "Vos versements individuels et facultatifs";
        }
    },
    C2("Votre \u00e9pargne salariale", "LABEL_COMPARTIMENT_C2"),
    C3("Votre \u00e9pargne entreprise", "LABEL_COMPARTIMENT_C3") {
        @Override
        public String getLabel(CodeSiloType codeSilo, boolean pacte) {
            if (CodeSiloType.MDP.equals(codeSilo)) {
                return super.getLabel(codeSilo, pacte);
            }

            return pacte ? "Vos versements obligatoires" : "Vos cotisations périodiques";
        }
    };

    private final String defaultLabel;
    private final String labelKey;

    public String getLabel(CodeSiloType codeSilo, boolean pacte) {
        return defaultLabel;
    }
}
