package fr.ag2rlamondiale.trm.supervision;

import com.ag2r.common.administration.model.AbstractTestManager;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static com.ag2r.common.keys.spring.FrmkSpringBeansKeys.DEFAULT_TEST_MANAGER_LIST;

@Profile(BaseTestManager.PROFILE_TESTMANAGER)
@Slf4j
@EqualsAndHashCode(callSuper = false)
@Component(DEFAULT_TEST_MANAGER_LIST)
public class TestManagerList extends ArrayList<AbstractTestManager> implements BeanPostProcessor {
    private static final long serialVersionUID = -443237548940839141L;

    @Autowired
    private TestManagerInterceptorFactory testManagerInterceptorFactory;

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) {
        final ActiveTest activeTest = bean.getClass().getAnnotation(ActiveTest.class);
        if (bean instanceof AbstractTestManager && activeTest != null && activeTest.value()) {
            final TestManagerInterceptor test =
                    testManagerInterceptorFactory.createInterceptor((AbstractTestManager) bean);
            log.info("Rajout du TestManager {}", test.getName());
            add(test);
        }

        return bean;
    }
}
