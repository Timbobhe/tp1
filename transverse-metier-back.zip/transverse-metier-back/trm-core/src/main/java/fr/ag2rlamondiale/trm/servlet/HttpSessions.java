package fr.ag2rlamondiale.trm.servlet;

import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

import javax.servlet.http.HttpSession;
import java.io.Serializable;
import java.util.function.Supplier;


/**
 * Rajouter dans web.xml (ou programmativement) le Listener org.springframework.web.util.HttpSessionMutexListener
 *
 *
 * <pre>
 *     		<listener>
 *             <listener-class>
 *                 org.springframework.web.util.HttpSessionMutexListener
 *             </listener-class>
 *         </listener>
 * </pre>
 *
 */
@Component
public class HttpSessions {

    public HttpSession getSession() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest().getSession(false);
    }


    public <T extends Serializable> T getOrCreate(String key, Supplier<T> supplier) {
        final HttpSession session = getSession();
        final Object mutex = WebUtils.getSessionMutex(session);
        synchronized (mutex) {
            T value = (T) session.getAttribute(key);
            if (value == null) {
                value = supplier.get();
                session.setAttribute(key, value);
            }
            return value;
        }
    }
}
