package fr.ag2rlamondiale.trm.utils;

/**
 * Permet d'activer le cache local, les AOP, pour des appels internes de la classe
 */
@FunctionalInterface
public interface SelfReferencingBean {
	void setProxy(Object proxy);
}
