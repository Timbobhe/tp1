package fr.ag2rlamondiale.trm.security;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

@Slf4j
@Aspect
@Component
public class SecureInterceptor implements Ordered {

    @Autowired
    private UserSecurityService securityService;

    @Before("@annotation(secure)")
    public void beforeAdvice(JoinPoint joinPoint, Secure secure) {
        log.debug("Before secure");
        securityService.isAuthorized(joinPoint, secure);
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.SECURE_ORDER;
    }
}
