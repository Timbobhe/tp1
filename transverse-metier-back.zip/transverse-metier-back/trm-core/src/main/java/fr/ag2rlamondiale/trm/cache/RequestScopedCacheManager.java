package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * {@link org.springframework.cache.CacheManager} that stores the caches in a ThreadLocal variable, and, therefore,
 * caching the values for the current thread. Useful if caching is just needed on a per request basis.
 * <p>
 * IMPORTANT: This cachedManager needs to be cleared before each request by using {@link #clearCaches()}. It is also
 * advisable to clear the cache also after the request has completed, in order to free up the cache.
 */
@Component(CacheConstants.REQUEST_SCOPED_CACHE_MANAGER)
public class RequestScopedCacheManager implements CacheManager, Ordered {

    private static final InheritableThreadLocal<Map<String, Cache>> threadLocalCache =
            new InheritableThreadLocal<Map<String, Cache>>() {
                @Override
                protected Map<String, Cache> initialValue() {
                    return new ConcurrentHashMap<>();
                }
            };

    @Override
    public Cache getCache(String name) {
        final Map<String, Cache> cacheMap = threadLocalCache.get();
        return cacheMap.computeIfAbsent(name, this::createCache);
    }

    private Cache createCache(String name) {
        return new ConcurrentMapCache(name);
    }

    @Override
    public Collection<String> getCacheNames() {
        return threadLocalCache.get().keySet();
    }

    public void clearCaches() {
        threadLocalCache.remove();
    }

    @Override
    public int getOrder() {
        return InterceptorOrders.REQUEST_CACHING_ORDER;
    }

}
