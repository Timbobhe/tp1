package fr.ag2rlamondiale.trm.domain.operation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public enum CodeTypeOperationEREType {
    // Non exhaustif
    // arbitrage à l'initiative de l'assure
    GARB_A("Arbitrage à la demande de l'assuré/société", "Arbitrage", false, true, true),
    // arbitrage suite à BIA
    GARB_B("Arbitrage suite à BIA", "Arbitrage suite au choix initial", false, true, true),
    GTPB("Arbitrage Complément de rémunération (transfert interne) ", "Attribution des intérêts - Transfert", true, true, true),
    GTRF("Transfert interne", "Transfert", true, true, true),
    P_11("Prestation Transfert sortant", "Transfert sortant", true, false, true),
    P_17("Prestation Rachat partiel", "Rachat partiel", true, false, true),
    P_18("Prestation Rachat total", "Rachet total", true, false, true),
    P_19("Prestation Rachat social", "Rachat exceptionnel", true, false, true),
    P_20("Prestation Sortie capital décès", "Sortie Capital décès", true, false, true),
    P_21("Prestation Sortie rente", "Sortie en rente", true, false, true),
    P_22("Prestation Sortie rente conjoint/orphelin", "Sortie en rente", true, false, true),
    P_24("Prestation Sortie capital", "Prestation", true, false, true),
    P_25("Prestation Prélèvements sociaux annuels", "Prélèvements sociaux annuels", true, false, true),
    P_31("Retrait Indemnité de fin de carrière", "Prestation", true, false, true),
    P_32("Retrait Indemnité de licenciement", "Prestation", true, false, true),
    P_33("Retrait pour motif: Retraite", "Prestation", true, false, true),
    P_35("Retrait Pré-retraite", "Prestation", true, false, true),
    P_36("Retrait spécifique", "Prestation", true, false, true),
    P_37("Retrait pour motif: Transfert sortant", "Prestation", true, false, true),
    P_38("Retrait pour motif: Transfert interne", "Prestation", true, false, true),
    P_42("Retrait Arrérage de rente", "Prestation", true, false, true),
    P_46("Retrait exceptionnel", "Prestation", true, false, true),
    P_47("Retrait Frais sur arrérage de rente", "Prestation", true, false, true),
    P_48("Solder une catégorie", "Retrait total", true, false, true),
    P_49("Retrait Reprise de rente", "Prestation", true, false, true),
    P_50("Retrait Régularisation Taxe IL", "Prestation", true, false, true),
    P_52("Prestation Transfert filiale", "Transfert", true, false, true),
    P_53("Retrait Complément de rémunération (prestation)", "Prestation", true, false, true),
    P_57("Régularisation contribution L137-11", "Régularisation contribution L137-11", true, false, true),
    RCN("Régularisation (Cotisation négative)", "Régularisation cotisation", true, true, true),
    RCP("Cotisation périodique", "Cotisation obligatoire du", true, true, true),
    RDP("Dotation périodique", "Dotation obligatoire du", true, true, true),
    RPO("Prélèvement d’office (assuré)", "Versement programmé", true, true, true),
    RPX_01("Cotisation exceptionnelle pour rattrapage d’intérêts", "Cotisation exceptionnelle", true, true, true),
    RPX_02("Cotisation exceptionnelle pour Transfert entrant externe", "Cotisation exceptionnelle", true, true, true),
    RPX_03("Cotisation exceptionnelle pour Transfert entrant intra groupe", "Cotisation exceptionnelle", true, true, true),
    RPX_04("Cotisation exceptionnelle pour Prime de rattrapage", "Cotisation exceptionnelle", true, true, true),
    RPX_05("Cotisation exceptionnelle pour Versement exceptionnel", "Cotisation exceptionnelle", true, true, true),
    RPX_06("Dotation exceptionnelle pour Dotation pour pré-retraite", "Dotation Exceptionnelle", true, true, true),
    RPX_07("Dotation exceptionnelle pour Transfert entrant externe", "Dotation Exceptionnelle", true, true, true),
    RPX_08("Dotation exceptionnelle pour Dotation libre", "Dotation Exceptionnelle", true, true, true),
    RPX_09("Dotation exceptionnelle pour Dotation initiale", "Dotation Exceptionnelle", true, true, true),
    RPX_10("Dotation exceptionnelle pour Rachat de dotation exceptionnelle", "Dotation Exceptionnelle", true, true, true),
    RPX_11_PB("Complément de rémunération (transfert interne)", "Attribution des intérêts - Transfert", true, true, true),
    RPX_11("Dotation exceptionnelle pour Transfert Interne", "Dotation Exceptionnelle", true, true, true),
    RPX_13("Dotation exceptionnelle pour Revalorisation des PM de rente", "Dotation Exceptionnelle", true, true, true),
    RPX_14("Dotation exceptionnelle pour Solde technique pur", "Dotation Exceptionnelle", true, true, true),
    RPX_15("Dotation exceptionnelle pour Revalorisation des préretraités", "Dotation Exceptionnelle", true, true, true),
    RPX_16("Dotation exceptionnelle pour Intérêts attribués", "Dotation Exceptionnelle", true, true, true),
    RPX_17("Dotation exceptionnelle pour Dotation au titre de la 1ère année", "Dotation Exceptionnelle", true, true, true),
    RPX_18("Cotisation exceptionnelle pour transfert filiale", "Cotisation exceptionnelle", true, true, true),
    RPX_19("Cotisation exceptionnelle pour Versement CET déductible", "Versement CET déductible", true, true, true),
    RPX_20("Cotisation exceptionnelle pour Versement CET / Congé non déduct.", "Versement CET / Congé non déduct.", true, true, true),
    RPX_21("Dotation exceptionnelle pour Contribution L137-11 ", "Contribution L137-11", true, true, true),
    RPX_22("Cotisation exceptionnelle pour Investissement Exo incapacité", "Cotisation exceptionnelle", true, true, true),
    RPX_23("Cotisation exceptionnelle pour Investissement Exo invalidité", "Cotisation exceptionnelle", true, true, true),
    RPX_24("Dotation exceptionnelle pour Contribution L137-11 > 8PASS", "Contribution L137-11 > 8PASS", true, true, true),
    RPX_25("Cotisation exceptionnelle pour Inv Except Exo Chômage", "Cotisation exceptionnelle", true, true, true),
    RPX_26("Cotisation exceptionnelle", "Cotisation exceptionnelle", true, true, true),
    RPX_27("Cotisation exceptionnelle pour Participation", "Cotisation exceptionnelle", true, true, true),
    RPX_28("Cotisation exceptionnelle pour Abondement", "Cotisation exceptionnelle", true, true, true),
    RPX_29("Cotisation exceptionnelle pour Intéressement", "Cotisation exceptionnelle", true, true, true),
    RPX_30("Cotisation exceptionnelle pour Versement CET", "Cotisation exceptionnelle", true, true, true),
    RPX_31("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat MADELIN", "Cotisation exceptionnelle", true, true, true),
    RPX_32("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERP", "Cotisation exceptionnelle", true, true, true),
    RPX_33("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERE (art83)", "Cotisation exceptionnelle", true, true, true),
    RPX_34("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERI", "Cotisation exceptionnelle", true, true, true),
    RPX_35("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERCO", "Cotisation exceptionnelle", true, true, true),
    RPX_36("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PER", "Cotisation exceptionnelle", true, true, true),
    RPX_37("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat MADELIN (8X)", "Cotisation exceptionnelle", true, true, true),
    RPX_38("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERP (8X)", "Cotisation exceptionnelle", true, true, true),
    RPX_39("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERE (art83) (8X)", "Cotisation exceptionnelle", true, true, true),
    RPX_40("Cotisation exceptionnelle pour Transfert entrant externe en provenance d'un contrat PERI (8X)", "Cotisation exceptionnelle", true, true, true),
    RPX_RA("Régul Paiement des arrérages ", "Prestation", true, false, true),
    RPX_RF("Régul Paiement frais sur arrérage", "Prestation", true, false, true),
    RPX_RN("Dotation exceptionnelle pour Régul CC négative", "Dotation Exceptionnelle", true, true, true),
    RVL("Versement libre ", "Versement libre ", true, true, true),
    A_R("Réalignement", "Réalignement", false, false, true),
    A_Y("Dynamisation", "Dynamisation", true, true, true),
    RPU("Prélèvement unique", "Versement libre ", true, true, true),
    A_G("Désensibilisation progressive", "Désensibilisation progressive", false, true, true),
    // Arbitrage à la demande de l’assuré/société dans le futur
    SARB_A,
    // Arbitrage suite à avenant dans le futur
    SARB_V,
    // Arbitrage suite à erreur dans le futur
    SARB_R,
    GARB_R("Arbitrage suite à erreur", "Arbitrage", false, false, false),

    A_H("Changement d'horizon", "Changement d'horizon", false, true, true),

    GARB_V("Arbitrage suite à avenant", "Arbitrage", false, true, true),

    A_P("Nouvelle sélection spécifique", "Nouvelle Sélection", false, false, true),

    A_S("Nouvelle sélection standard", "Nouvelle Sélection", false, false, true),

    A_B("Complément de rémunération", "Attribution des intérêts", false, false, false);



    private String libelleOutil;
    private String libelleFront;
    private boolean avecMontant;
    private boolean avecDetail;
    private boolean afficher;

    public static CodeTypeOperationEREType getTypeOperationFromcode(String code) {
        for (CodeTypeOperationEREType operationEREType : values()) {
            if (operationEREType.name().equals(code))
                return operationEREType;
        }
        return null;
    }


}
