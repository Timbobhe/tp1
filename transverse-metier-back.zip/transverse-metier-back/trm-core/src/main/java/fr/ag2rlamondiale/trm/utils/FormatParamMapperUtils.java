package fr.ag2rlamondiale.trm.utils;

import com.google.common.base.Strings;
import org.apache.commons.lang3.StringUtils;

public final class FormatParamMapperUtils {
	// Indicateur recherche partielle à saisir par l'utilisateur
	private static final String INDIC_RECH_PARTIELLE_FRONT = "*";
	// Indicateur recherche partielle attendu par le webservice
	private static final String INDIC_RECH_PARTIELLE_WS = "%";
	// Indicateur recherche exacte sortie masque
	private static final String INDIC_RECH_EXACTE_OUT = "=";
	// Pour l'objet GrilleInvType lors de l'appel du WS consulterCompteEncours
	private static final String GRILLE_NAME_PREFIX = "GESTION";

	// Evite l'instanciation
	private FormatParamMapperUtils() {
		// Empty
	}

	/**
	 * Formate le paramètre nom pour répondre à la syntaxe du webservice
	 * RechercherPP
	 */
	public static String formatNameRechPPWS(final String in) {
		// On verifie si l'indicateur de recherche partielle côté front est présent
		if (in != null && in.trim().endsWith(INDIC_RECH_PARTIELLE_FRONT)) {
			// On remplace l'indicateur de recherche partielle autorisé côté front par celui
			// attendu
			// par le webservice
			return in.substring(0, in.lastIndexOf(INDIC_RECH_PARTIELLE_FRONT)) + INDIC_RECH_PARTIELLE_WS;
		}
		return INDIC_RECH_EXACTE_OUT + Strings.nullToEmpty(in);
	}

	/**
	 * Formate le paramètre nom pour répondre à la syntaxe du webservice
	 * RechercherAssuresContrat
	 */
	public static String formatNameRechercherAssuresContratWS(final String in) {
		// On verifie si l'indicateur de recherche partielle côté front est présent
		if (in != null && in.trim().endsWith(INDIC_RECH_PARTIELLE_FRONT)) {
			// On remplace l'indicateur de recherche partielle autorisé côté front par celui
			// attendu
			// par le webservice
			return in.substring(0, in.lastIndexOf(INDIC_RECH_PARTIELLE_FRONT)) + INDIC_RECH_PARTIELLE_WS;
		} else {
			return in;
		}
	}

	/**
	 * Corrige le nom de GrilleInvType retourné par le WS
	 *
	 * @param name
	 * @return
	 */
	public static String formatGrilleInvTypeName(String name) {
		// Split String returned from WS
		if (StringUtils.isNotBlank(name) && name.contains(GRILLE_NAME_PREFIX)) {
			return name.replaceFirst(GRILLE_NAME_PREFIX, " " + GRILLE_NAME_PREFIX);
		}
		return name;
	}
}
