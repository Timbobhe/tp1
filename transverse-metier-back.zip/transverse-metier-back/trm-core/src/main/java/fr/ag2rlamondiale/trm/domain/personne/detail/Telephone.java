/*
 * Cree le 9 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.personne.detail;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

/**
 * POJO Téléphone utilisé dans la Recherche des Personnes Physiques
 */
@Data
public class Telephone {
    @JsonProperty(value = "type")
    String type;

    @JsonProperty(value = "numero")
    String numero;
}
