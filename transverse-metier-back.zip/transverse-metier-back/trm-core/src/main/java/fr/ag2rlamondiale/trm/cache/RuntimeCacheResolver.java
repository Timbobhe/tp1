package fr.ag2rlamondiale.trm.cache;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.CacheOperationInvocationContext;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.jcache.JCacheCache;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.stereotype.Component;

import javax.cache.CacheManager;
import javax.cache.configuration.Configuration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/**
 * Permet de créer des <code>org.springframework.cache.Cache</code> au Runtime;<br>
 * le(s) nom(s) du cache est(sont) récupérés depuis l'annotation {@link Cacheable} ou {@link CacheEvict}.<br>
 * L'objectif est de simplifier l'éviction des données depuis un cache "nommée" (autre que le {@value CacheConstants#SOAP_CACHE} défini par défaut).<br>
 *
 * <p>
 * Les <code>org.springframework.cache.Cache</code> sont créés depuis la même config que {@value CacheConstants#SOAP_CACHE}
 * </p>
 */
@Slf4j
@Component(CacheConstants.RUNTIME_CACHE_RESOLVER)
public class RuntimeCacheResolver implements CacheResolver, InitializingBean {

    @Qualifier(CacheConstants.DEFAULT_EHCACHE_MANAGER)
    @Autowired
    private JCacheCacheManager cacheCacheManager;

    private CacheManager cacheManager;

    private Configuration<?, ?> configuration;

    @Setter
    @Getter
    private String cacheNameModel = CacheConstants.SOAP_CACHE;

    public RuntimeCacheResolver() {
        // default constructor
    }

    public RuntimeCacheResolver(String cacheNameModel) {
        this.cacheNameModel = cacheNameModel;
    }

    public RuntimeCacheResolver(JCacheCacheManager cacheCacheManager) {
        this.cacheCacheManager = cacheCacheManager;
    }

    @Override
    public Collection<? extends Cache> resolveCaches(CacheOperationInvocationContext<?> context) {
        List<String> cacheNames = new ArrayList<>(1);
        final Cacheable cacheable = context.getMethod().getAnnotation(Cacheable.class);
        final CacheEvict cacheEvict = context.getMethod().getAnnotation(CacheEvict.class);
        if (cacheable != null && IQueryCache.cacheNames(cacheable).length > 0) {
            cacheNames.addAll(Arrays.asList(IQueryCache.cacheNames(cacheable)));
        } else if (cacheEvict != null && cacheEvict.cacheNames().length > 0) {
            cacheNames.addAll(Arrays.asList(cacheEvict.cacheNames()));
        } else {
            // On ne calcule pas de Cache dynamiquement pour forcer l'usage des Caches déclarés depuis ehcache.xml (soapCache, cguCache)
            // si l'on doit gérer des Evictions
            throw new NoCacheNameException("Impossible de r\u00e9cup\u00e9rer le cacheName pour la m\u00e9thode : " + context.getMethod());
        }

        final Collection<Cache> caches = new ArrayList<>(cacheNames.size());
        for (String cacheName : cacheNames) {
            javax.cache.Cache cache = getJCache(cacheName);
            caches.add(new JCacheCache(cache));
        }

        return caches;
    }

    private javax.cache.Cache getJCache(String cacheName) {
        javax.cache.Cache cache = cacheManager.getCache(cacheName);
        if (cache == null) {
            try {
                cache = cacheManager.createCache(cacheName, this.configuration);
            } catch (javax.cache.CacheException e) {
                if (e.getMessage().endsWith("already exists")) {
                    cache = cacheManager.getCache(cacheName);
                } else {
                    throw e;
                }
            }
        }
        return cache;
    }

    @Override
    public void afterPropertiesSet() {
        this.cacheManager = cacheCacheManager.getCacheManager();
        this.configuration = getSoapCacheConfiguration();
    }

    @SuppressWarnings("unchecked")
    private Configuration getSoapCacheConfiguration() {
        try {
            return (this.cacheManager.getCache(getCacheNameModel()).getConfiguration(Configuration.class));
        } catch (NullPointerException npe) {
            log.error("Il faut d\u00e9clarer un cache nomm\u00e9 " + getCacheNameModel() + ", utilis\u00e9 comme Configuration de cache par d\u00e9faut", npe);
            throw npe;
        }
    }

}
