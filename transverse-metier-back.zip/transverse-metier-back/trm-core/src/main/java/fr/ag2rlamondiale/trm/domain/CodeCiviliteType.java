package fr.ag2rlamondiale.trm.domain;

public enum CodeCiviliteType {
    DR("Docteur","DR"),
    M("Monsieur","MR"),
    MME("Madame","MM"),
    MLE("Mademoiselle","ML"),
    ME("Maître","ME");

    private final String libelle;
    private final String cleNomenclature;

    CodeCiviliteType(String libelle, String cleNomenclature) {
        this.libelle = libelle;
        this.cleNomenclature = cleNomenclature;
    }

    public static String getCodeFromLibelleCivilite(String libelle){
        for(CodeCiviliteType civiliteType : values()){
            if(civiliteType.libelle.equals(libelle))
                return civiliteType.name();
        }
        return null;
    }


}
