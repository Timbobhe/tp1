package fr.ag2rlamondiale.trm.demo;

import fr.ag2rlamondiale.trm.soap.PortInitializer;

public interface ICompteDemoEndpointResolver {
    String getUrl(PortInitializer portInitializer);

    String getUrl(String serviceId);

    String getUrl(String serviceId, CompteDemo compteDemo);

    boolean isDemoActive();
}
