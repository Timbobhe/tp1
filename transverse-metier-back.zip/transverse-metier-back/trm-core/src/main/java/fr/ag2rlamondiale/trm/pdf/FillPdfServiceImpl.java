package fr.ag2rlamondiale.trm.pdf;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.Dimension;
import com.google.zxing.EncodeHintType;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.datamatrix.DataMatrixWriter;
import fr.ag2rlamondiale.trm.domain.document.ChampsPDFInfo;
import fr.ag2rlamondiale.trm.domain.document.TypeChampsPdfType;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;
import org.apache.batik.gvt.renderer.ImageRenderer;
import org.apache.batik.transcoder.SVGAbstractTranscoder;
import org.apache.batik.transcoder.TranscoderException;
import org.apache.batik.transcoder.TranscoderInput;
import org.apache.batik.transcoder.TranscoderOutput;
import org.apache.batik.transcoder.image.ImageTranscoder;
import org.apache.batik.transcoder.image.JPEGTranscoder;
import org.apache.batik.transcoder.image.PNGTranscoder;
import org.apache.commons.io.IOUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.fontbox.encoding.Encoding;
import org.apache.fontbox.encoding.MacRomanEncoding;
import org.apache.fontbox.encoding.StandardEncoding;
import org.apache.pdfbox.cos.COSArray;
import org.apache.pdfbox.cos.COSDictionary;
import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.cos.COSObject;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDDocumentCatalog;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDCheckBox;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.util.Matrix;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.xhtmlrenderer.resource.XMLResource;
import org.xhtmlrenderer.swing.Java2DRenderer;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class FillPdfServiceImpl implements FillPdfService {
    private static final Logger LOGGER = LoggerFactory.getLogger(FillPdfServiceImpl.class);

    private static final int UNICODE_EURO_SYMBOL = 8364;
    private static final int UNICODE_RIGHT_SINGLE_QUOTATION_MARK = 8217;
    private static final int UNICODE_OPENING_PARENTHESIS = 40;
    private static final int UNICODE_CLOSING_PARENTHESIS = 41;
    private static final int UNICODE_NON_BREAKING_SPACE = 160; // 8239, 8199
    private static final String OPENING_PARENTHESIS = "(";
    private static final String CLOSING_PARENTHESIS = ")";
    private static final String QUOTATION_MARK = "'";
    private static final String SPACE = "space";
    private static final String LINE_BREAK_CHAR = "\n";
    private static final int MAX_MENTION_LINE_LENGTH = 93;
    private static final int MAX_OPTION_LINE_LENGTH = 83;
    private static final String MENTION_FIELD_PATTERN = "mention";
    private static final String OPTION_FIELD_PATTERN = "option";

    private static final int QR_CODE_WIDTH = 1024;
    private static final int QR_CODE_HEIGHT = 1024;

    private static final String ENCODING = "UTF-8";


    @Override
    public void fillPdfForm(InputStream documentInputStream, OutputStream documentOutputStream,
                            Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle, boolean isNeedAppearances)
            throws DocumentException, IOException {
        try (PDDocument document = PDDocument.load(documentInputStream)) {
            if (document.isEncrypted()) {
                if (documentInputStream instanceof ByteArrayInputStream) {
                    saveDocument(documentOutputStream, (ByteArrayInputStream) documentInputStream);
                } else {
                    documentOutputStream.close();
                    throw new DocumentException(DocumentException.CANT_SAVE_DOCUMENT);
                }
                return;
            }

            PDDocumentCatalog catalog = document.getDocumentCatalog();
            PDAcroForm form = catalog.getAcroForm();

            if (form == null) {
                if (documentInputStream instanceof ByteArrayInputStream) {
                    saveDocument(documentOutputStream, (ByteArrayInputStream) documentInputStream);
                } else {
                    saveDocument(documentOutputStream, document);
                }
                return;
            }
            form.setNeedAppearances(isNeedAppearances);
            Encoding encoding = getEncoding();

            List<PDField> fieldsList = form.getFields();

            StringBuilder stringBuffer = new StringBuilder();
            for (PDField formField : fieldsList) {
                fillPdfField(formFieldsValues, document, encoding, stringBuffer, formField, bodyStyle);
            }
            saveDocument(documentOutputStream, document);
        } catch (IOException ioException) {
            documentOutputStream.close();
            throw new DocumentException(DocumentException.CANT_FILL_DOCUMENT, ioException);
        }
    }

    /**
     * @param formFieldsValues
     * @param document
     * @param encoding
     * @param stringBuffer
     * @param formField
     */
    private void fillPdfField(Map<String, ChampsPDFInfo> formFieldsValues, PDDocument document,
                              Encoding encoding, StringBuilder stringBuffer, PDField formField, String bodyStyle) {
        String fieldName = formField.getFullyQualifiedName();
        if (formFieldsValues.containsKey(fieldName)) {
            ChampsPDFInfo fieldInfo = formFieldsValues.get(fieldName);
            try {
                formField.setReadOnly(false);
                TypeChampsPdfType fieldType = fieldInfo.getType();
                switch (fieldType) {
                    case TEXT:
                        if (mustManageLineBreak(fieldName)) {
                            formField.setValue(manageLineBreak(fieldName, encodeValue(stringBuffer,
                                    fieldInfo.getValeur(), encoding, true), encoding));
                        } else {
                            formField.setValue(encodeValue(stringBuffer, fieldInfo.getValeur(),
                                    encoding, true));
                        }
                        break;
                    case TEXT_LB:

                        formField.setValue(
                                encodeValue(stringBuffer, fieldInfo.getValeur(), encoding, false));
                        break;
                    case CHECKBOX:
                        if (formField instanceof PDCheckBox && fieldInfo.getValeur() != null) {
                            formField.setValue(((PDCheckBox) formField).getOnValue());
                        }

                        break;

                    case GRAPHE:
                        insertGraphe(document, fieldInfo, formField);
                        break;

                    case LOGO:
                        insertImage(document, fieldInfo, formField);
                        break;
                    case QRCODE:
                        insertQRCode(document, fieldInfo, formField);
                        break;

                    case HTML:
                        insertHTMLCode(document, fieldInfo, formField, bodyStyle);
                        break;

                    default:
                        break;
                }
            } catch (Exception exception) {
                LOGGER.error("method fillPdfForm()", exception);
            }
        }

        stringBuffer.delete(0, stringBuffer.length());

        // Mettre les champs en lecture seul apres les avoir rempli
        formField.setReadOnly(true);
    }

    /* */
    @Override
    public void fillPdfForm(InputStream documentInputStream, OutputStream documentOutputStream,
                            Map<String, ChampsPDFInfo> formFieldsValues, String bodyStyle) throws DocumentException, IOException {
        fillPdfForm(documentInputStream, documentOutputStream, formFieldsValues, bodyStyle, true);
    }

    private void insertGraphe(PDDocument document, ChampsPDFInfo fieldInfo, PDField pdfField)
            throws DocumentException {
        try {
            COSArray rectArray =
                    (COSArray) pdfField.getCOSObject().getDictionaryObject(COSName.RECT);
            PDRectangle box = new PDRectangle(rectArray);
            byte[] imageContents = fromSvgCodeToImageByte(fieldInfo.getValeur(), box);
            ByteArrayInputStream byteArray = new ByteArrayInputStream(imageContents);
            ImageInputStream imageInputStream = ImageIO.createImageInputStream(byteArray);
            BufferedImage img = ImageIO.read(imageInputStream);
            PDImageXObject pdxObjectImage = LosslessFactory.createFromImage(document, img);
            PDPage page = document.getDocumentCatalog().getPages().get(0);
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page,
                    PDPageContentStream.AppendMode.APPEND, false)) {
                AffineTransform transform = new AffineTransform(img.getWidth(null), 0.0F, 0.0F,
                        img.getHeight(null), box.getLowerLeftX(), box.getLowerLeftY());
                transform.scale(0.5, 0.5);
                contentStream.drawImage(pdxObjectImage, new Matrix(transform));
            }
        } catch (IOException ioException) {
            throw new DocumentException(DocumentException.CANT_INSERT_IMAGE, ioException);
        }
    }

    private byte[] fromSvgCodeToImageByte(String svgString, PDRectangle rectangle)
            throws DocumentException {
        try {
            PNGTranscoder transcoder = new InitializingPNGTranscoder();
            transcoder.addTranscodingHint(ImageTranscoder.KEY_FORCE_TRANSPARENT_WHITE, true);
            transcoder.addTranscodingHint(JPEGTranscoder.KEY_QUALITY, 1.0f);
            transcoder.addTranscodingHint(SVGAbstractTranscoder.KEY_HEIGHT,
                    rectangle.getHeight() * 2);

            byte[] result;
            try (InputStream inputStream = new ByteArrayInputStream(svgString.getBytes(StandardCharsets.UTF_8));
                 ByteArrayOutputStream ostream = new ByteArrayOutputStream()) {
                TranscoderInput input = new TranscoderInput(inputStream);
                TranscoderOutput output = new TranscoderOutput(ostream);
                transcoder.transcode(input, output);

                ostream.flush();
                result = ostream.toByteArray();
            }

            return result;
        } catch (IOException | TranscoderException transcoderException) {
            throw new DocumentException(DocumentException.CANT_CONVERT_FROM_SVG, transcoderException);
        }
    }

    private void insertImage(PDDocument document, ChampsPDFInfo fieldInfo, PDField pdfField)
            throws DocumentException {
        try {
            COSDictionary dictonary = pdfField.getCOSObject();

            if (dictonary.containsKey(COSName.RECT)) {
                COSArray rectArray = (COSArray) dictonary.getDictionaryObject(COSName.RECT);
                drawImage(document, fieldInfo, 0, new PDRectangle(rectArray));
            } else {
                COSArray rectArrayx = (COSArray) dictonary.getDictionaryObject(COSName.KIDS);
                if (rectArrayx != null) {
                    COSObject obj;
                    COSArray rectArray;
                    for (int i = 0; i < rectArrayx.size(); i++) {
                        obj = (COSObject) rectArrayx.get(i).getCOSObject();
                        rectArray = (COSArray) obj.getDictionaryObject(COSName.RECT);
                        drawImage(document, fieldInfo, i, new PDRectangle(rectArray));
                    }
                }
            }
        } catch (IOException ioException) {
            throw new DocumentException(DocumentException.CANT_INSERT_IMAGE, ioException);
        }
    }

    private void drawImage(PDDocument document, ChampsPDFInfo fieldInfo, int i, PDRectangle box)
            throws IOException, DocumentException {
        byte[] imageContents = getImageFromURI(fieldInfo.getValeur());
        ByteArrayInputStream byteArray = new ByteArrayInputStream(imageContents);
        ImageInputStream imageInputStream = ImageIO.createImageInputStream(byteArray);
        BufferedImage img = ImageIO.read(imageInputStream);
        PDImageXObject pdxObjectImage = LosslessFactory.createFromImage(document, img);
        PDPage page = document.getDocumentCatalog().getPages().get(i);
        try (PDPageContentStream contentStream = new PDPageContentStream(document, page,
                PDPageContentStream.AppendMode.APPEND, false)) {
            AffineTransform transform = new AffineTransform(img.getWidth(null), 0.0F, 0.0F,
                    img.getHeight(null), box.getLowerLeftX(), box.getLowerLeftY());
            transform.scale(0.5, 0.5);
            contentStream.drawImage(pdxObjectImage, new Matrix(transform));
        }
    }

    private byte[] getImageFromURI(String filePath) throws DocumentException {
        try {
            URLConnection connection = new URL(filePath).openConnection();
            byte[] result;
            try (InputStream inputStream = connection.getInputStream()) {
                result = IOUtils.toByteArray(inputStream);
            }

            return result;
        } catch (Exception transcoderException) {
            throw new DocumentException(DocumentException.CANT_CONVERT_FROM_SVG, transcoderException);
        }
    }

    public void insertQRCode(PDDocument document, ChampsPDFInfo fieldInfo, PDField pdfField)
            throws DocumentException {
        try {
            COSDictionary dictonary = pdfField.getCOSObject();
            if (dictonary.containsKey(COSName.RECT)) {
                COSArray rectArray = (COSArray) dictonary.getDictionaryObject(COSName.RECT);
                drawQRCODE(document, fieldInfo, 0, new PDRectangle(rectArray));
            } else {
                COSArray rectArrayx = (COSArray) dictonary.getDictionaryObject(COSName.KIDS);
                if (rectArrayx != null) {
                    COSObject obj;
                    COSArray rectArray;
                    for (int i = 0; i < rectArrayx.size(); i++) {
                        obj = (COSObject) rectArrayx.get(i).getCOSObject();
                        rectArray = (COSArray) obj.getDictionaryObject(COSName.RECT);
                        drawQRCODE(document, fieldInfo, i, new PDRectangle(rectArray));
                    }
                }
            }
        } catch (IOException ioException) {
            throw new DocumentException(DocumentException.CANT_INSERT_QRCODE, ioException);
        }
    }

    private void drawQRCODE(PDDocument document, ChampsPDFInfo fieldInfo, int i, PDRectangle box)
            throws IOException {
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.MAX_SIZE, new Dimension(20, 20));

        DataMatrixWriter writer = new DataMatrixWriter();
        BitMatrix bitMatrix = writer.encode(fieldInfo.getValeur(), BarcodeFormat.DATA_MATRIX,
                QR_CODE_WIDTH, QR_CODE_HEIGHT, hints);

        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        MatrixToImageWriter.writeToStream(bitMatrix, "jpeg", outputStream);

        ByteArrayInputStream inputStream = new ByteArrayInputStream(outputStream.toByteArray());

        BufferedImage img = ImageIO.read(inputStream);
        PDImageXObject pdxObjectImage = LosslessFactory.createFromImage(document, img);
        PDPage page = document.getDocumentCatalog().getPages().get(i);

        try (PDPageContentStream contentStream = new PDPageContentStream(document, page,
                PDPageContentStream.AppendMode.APPEND, false)) {
            AffineTransform transform = new AffineTransform(img.getWidth(null), 0.0F, 0.0F,
                    img.getHeight(null), box.getLowerLeftX(), box.getLowerLeftY());
            double yScale = box.getHeight() / img.getHeight(null);
            double xScale = box.getWidth() / img.getWidth(null);

            transform.scale(xScale, yScale);
            contentStream.drawImage(pdxObjectImage, new Matrix(transform));
        }
    }

    private String manageLineBreak(String fieldName, String rawFieldValue, Encoding encoding) {
        String fieldValue = rawFieldValue.replaceAll("\n", "").trim();
        int maxLineLength = getLineLengthForField(fieldName);
        String[] words =
                fieldValue.split(String.valueOf(Character.toChars(encoding.getCode(SPACE))));
        StringBuilder paragraph = new StringBuilder();
        StringBuilder sentence = new StringBuilder();
        int futureSentenceLength;

        for (String word : words) {
            futureSentenceLength = sentence.length() + word.trim().length();
            if (futureSentenceLength < maxLineLength) {
                sentence.append(String.valueOf(Character.toChars(encoding.getCode(SPACE))));
            } else {
                paragraph.append(sentence.toString().trim());
                paragraph.append(LINE_BREAK_CHAR);
                sentence.delete(0, sentence.length());
            }
            sentence.append(word.trim());
        }

        if (sentence.length() != 0) {
            paragraph.append(sentence);
        }

        return paragraph.toString().trim();
    }

    private static String encodeValue(StringBuilder stringBuilder, String fieldValue,
                                      Encoding encoding, boolean transformLinebreaks) {
        if (fieldValue == null) {
            return "";
        }

        Encoding otherEncoding = getOtherEncoding();
        String tmp;
        if (!transformLinebreaks) {
            tmp = fieldValue.replace("\\r", "\r").replace("\\n", "\n");
        } else {
            tmp = fieldValue;
        }
        char[] charArray = tmp.trim().toCharArray();

        for (char chr : charArray) {
            try {
                encodeChar(stringBuilder, encoding, transformLinebreaks, chr);
            } catch (Exception e) {
                try {
                    Integer code = otherEncoding.getCode(otherEncoding.getName(chr));
                    char[] chars = Character.toChars(code);
                    stringBuilder.append(String.valueOf(chars));
                } catch (Exception ex) {
                    LOGGER.error(new StringBuilder("Erreur sur le caractère : ").append(chr).toString(), ex);
                    stringBuilder
                            .append(String.valueOf(Character.toChars(encoding.getCode(SPACE))));
                }
            }
        }

        return stringBuilder.toString().trim();
    }

    /**
     * @param stringBuilder
     * @param encoding
     * @param transformLinebreaks
     * @param chr
     */
    private static void encodeChar(StringBuilder stringBuilder, Encoding encoding,
                                   boolean transformLinebreaks, char chr) {
        if (Character.isWhitespace(chr) || chr == UNICODE_NON_BREAKING_SPACE) {
            if (!transformLinebreaks && chr == '\n') {
                stringBuilder.append(LINE_BREAK_CHAR);
            } else {
                stringBuilder.append(String.valueOf(Character.toChars(encoding.getCode(SPACE))));
            }
        } else if (chr == UNICODE_EURO_SYMBOL) {
            stringBuilder.append(chr);
        } else if (chr == UNICODE_OPENING_PARENTHESIS) {
            stringBuilder.append(OPENING_PARENTHESIS);
        } else if (chr == UNICODE_CLOSING_PARENTHESIS) {
            stringBuilder.append(CLOSING_PARENTHESIS);
        } else if (chr == UNICODE_RIGHT_SINGLE_QUOTATION_MARK) {
            stringBuilder.append(QUOTATION_MARK);
        } else if (chr == 9834) {
            stringBuilder.append(LINE_BREAK_CHAR);
        } else {
            Integer code = encoding.getCode(encoding.getName(chr));
            char[] chars = Character.toChars(code);
            stringBuilder.append(String.valueOf(chars));
        }
    }

    private static boolean mustManageLineBreak(String fieldName) {
        String trimedFieldName = fieldName.toLowerCase().trim();

        return trimedFieldName.contains(MENTION_FIELD_PATTERN)
                || trimedFieldName.contains(OPTION_FIELD_PATTERN);
    }

    private static int getLineLengthForField(String fieldName) {
        int lineLength = 0;
        String trimedFieldName = fieldName.toLowerCase().trim();

        if (trimedFieldName.contains(MENTION_FIELD_PATTERN)) {
            lineLength = MAX_MENTION_LINE_LENGTH;
        }

        if (trimedFieldName.contains(OPTION_FIELD_PATTERN)) {
            lineLength = MAX_OPTION_LINE_LENGTH;
        }
        return lineLength;
    }

    private Encoding getEncoding() {
        return MacRomanEncoding.INSTANCE;
    }

    private static Encoding getOtherEncoding() {
        return StandardEncoding.INSTANCE;
    }

    private void saveDocument(OutputStream documentOutputStream, PDDocument document)
            throws DocumentException {
        try {
            document.save(documentOutputStream);
            document.close();
        } catch (IOException ioException) {
            throw new DocumentException(DocumentException.CANT_SAVE_DOCUMENT, ioException);
        }
    }

    private void saveDocument(OutputStream documentOutputStream,
                              ByteArrayInputStream byteArrayInputStream) throws DocumentException {
        try {
            byteArrayInputStream.reset();
            IOUtils.copy(byteArrayInputStream, documentOutputStream);
        } catch (IOException ioException) {
            throw new DocumentException(DocumentException.CANT_SAVE_DOCUMENT, ioException);
        }
    }

    private class InitializingPNGTranscoder extends PNGTranscoder {
        @Override
        protected ImageRenderer createRenderer() {
            ImageRenderer imageRenderer = super.createRenderer();

            RenderingHints renderingHints = imageRenderer.getRenderingHints();
            renderingHints.add(new RenderingHints(RenderingHints.KEY_ALPHA_INTERPOLATION,
                    RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BICUBIC));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_COLOR_RENDERING,
                    RenderingHints.VALUE_COLOR_RENDER_QUALITY));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_DITHERING,
                    RenderingHints.VALUE_DITHER_DISABLE));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_RENDERING,
                    RenderingHints.VALUE_RENDER_QUALITY));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_STROKE_CONTROL,
                    RenderingHints.VALUE_STROKE_DEFAULT));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_FRACTIONALMETRICS,
                    RenderingHints.VALUE_FRACTIONALMETRICS_ON));
            renderingHints.add(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_OFF));

            imageRenderer.setRenderingHints(renderingHints);

            return imageRenderer;
        }
    }

    public void insertHTMLCode(PDDocument document, ChampsPDFInfo fieldInfo, PDField pdfField, String bodystyle)
            throws DocumentException {
        try {
            COSArray rectArray =
                    (COSArray) pdfField.getCOSObject().getDictionaryObject(COSName.RECT);
            PDRectangle box = new PDRectangle(rectArray);
            BufferedImage img = fromHTMLCodeToBufferedImage(fieldInfo.getValeur(), box, bodystyle);

            PDImageXObject pdxObjectImage = LosslessFactory.createFromImage(document, img);
            PDPage page = document.getDocumentCatalog().getPages().get(0);
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page,
                    PDPageContentStream.AppendMode.APPEND, false)) {
                double yScale = box.getHeight() / img.getHeight(null);
                double xScale = box.getWidth() / img.getWidth(null);
                AffineTransform transform = new AffineTransform(img.getWidth(null), 0.0F, 0.0F,
                        img.getHeight(null), box.getLowerLeftX(), box.getLowerLeftY());
                transform.scale(xScale, yScale);

                contentStream.drawImage(pdxObjectImage, new Matrix(transform));
            }
        } catch (Exception e) {
            throw new DocumentException(DocumentException.CANT_INSERT_IMAGE, e);
        }
    }

    private BufferedImage fromHTMLCodeToBufferedImage(String htmlString, PDRectangle rectangle, String bodyStyle) {
        Document doc = Jsoup.parse(htmlString);
        LOGGER.debug("html string :" + htmlString);
        // Supprime les balises images
        Elements elements = doc.getElementsByTag("img");
        elements.remove();
        Element head = doc.head();

        head.append("<style>" + bodyStyle + "</style>");

        final String cleanHtml = StringEscapeUtils.unescapeHtml4(doc.outerHtml())
                .replaceAll("&([^lg]|(g|l)[^t])", "&amp;");

        LOGGER.debug("clean html :" + cleanHtml);

        LOGGER.debug("Prepare to render image");
        Map<RenderingHints.Key, Object> hints = new HashMap<>();
        hints.put(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);

        ByteArrayInputStream bais = new ByteArrayInputStream(cleanHtml.getBytes(StandardCharsets.UTF_8));
        final org.w3c.dom.Document xmlDocument = XMLResource.load(bais).getDocument();
        final int dotsPerPixel = Math.round(rectangle.getWidth() * 2 + 10);
        Java2DRenderer renderer = new Java2DRenderer(xmlDocument, dotsPerPixel, -1);
        renderer.setBufferedImageType(BufferedImage.TYPE_INT_RGB);
        renderer.setRenderingHints(hints);
        BufferedImage image = renderer.getImage();

        if (rectangle.getHeight() / image.getHeight(null) >= 0.6) {
            renderer = new Java2DRenderer(xmlDocument, Math.round(rectangle.getWidth() * 2 + 10),
                    Math.round(rectangle.getHeight() * 2));
            renderer.setBufferedImageType(BufferedImage.TYPE_INT_RGB);
            renderer.setRenderingHints(hints);
            image = renderer.getImage();
        }

        return image;
    }
}
