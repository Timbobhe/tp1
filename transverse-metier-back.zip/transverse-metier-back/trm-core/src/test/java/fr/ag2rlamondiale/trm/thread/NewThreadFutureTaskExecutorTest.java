package fr.ag2rlamondiale.trm.thread;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import static org.junit.Assert.*;

@Slf4j
public class NewThreadFutureTaskExecutorTest extends AbstractExecutorTest {

    @Override
    public void setUp() {
        executor = new NewThreadFutureTaskExecutor();
    }

    @Test
    public void test_userContext() {
        try {
            super.test_userContext();
        } catch (Exception e) {
            fail();
        }
    }
}
