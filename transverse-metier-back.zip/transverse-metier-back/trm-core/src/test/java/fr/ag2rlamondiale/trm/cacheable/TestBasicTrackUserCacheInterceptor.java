package fr.ag2rlamondiale.trm.cacheable;

import fr.ag2rlamondiale.trm.async.AsyncMethodInterceptorTest;
import fr.ag2rlamondiale.trm.cache.*;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.TimestampObject;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.cache.jcache.JCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.URI;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@EnableCaching
@ContextConfiguration(classes = TestBasicTrackUserCacheInterceptor.class)
public class TestBasicTrackUserCacheInterceptor {

    public static final String IDGDI = "IDGDI";
    @Value("classpath:ehcache.xml")
    URI ehcacheConfig;

    @Autowired
    ITrackUserCache trackUserCache;

    TrackUserCacheImplMBean trackUserCacheImplMBean;

    @Autowired
    CacheManager cacheManager;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Primary
    @Bean("ehCacheManager")
    public JCacheCacheManager cacheManager() {
        JCacheCacheManager cacheCacheManager = new JCacheCacheManager();
        final JCacheManagerFactoryBean factory = new JCacheManagerFactoryBean();
        factory.setCacheManagerUri(ehcacheConfig);
        factory.afterPropertiesSet();
        cacheCacheManager.setCacheManager(factory.getObject());
        return cacheCacheManager;
    }

    @Bean(CacheConstants.DEFAULT_KEY_GENERATOR)
    public KeyGenerator defaulKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }

    @Bean(CacheConstants.SIMPLE_KEY_GENERATOR)
    public KeyGenerator simpleKeyGenerator() {
        return new ParamsKeyGenerator();
    }

    @Bean
    public IQueryCache queryCache() {
        return new QueryCacheImpl();
    }

    @Bean(CacheConstants.RUNTIME_CACHE_RESOLVER)
    public CacheResolver runtimeCacheResolver() {
        return new RuntimeCacheResolver();
    }

    @Bean
    public ITrackUserCache trackUserCache() {
        return new TrackUserCacheImpl();
    }

    @Before
    public void prepare() {
        this.trackUserCacheImplMBean = (TrackUserCacheImplMBean) this.trackUserCache;
        clearStandardCache();
        ((ClearableCache) trackUserCache).clearCache();
        AsyncMethodInterceptorTest.initSecurityContext(IDGDI);
    }

    private void clearStandardCache() {
        final Collection<String> cacheNames = cacheManager.getCacheNames();
        for (String cacheName : cacheNames) {
            final Cache cache = cacheManager.getCache(cacheName);
            log.info("Clear cache {}", cacheName);
            if (cache != null) {
                cache.clear();
            }
        }
    }

    public ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>> userCacheEntries() {
        return (ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>>) ReflectionTestUtils.getField(trackUserCache, "userCacheEntries");
    }

    @Test
    public void test_trackUserCache() throws Exception {
        trackUserCache.trackUserCache(this, getClass().getMethod("methode1", String.class), new Object[]{"123"});
        final val entries = userCacheEntries().get(IDGDI);
        assertEquals(1, entries.getObject().size());

        trackUserCacheImplMBean.logUserCacheEntries(IDGDI);
        trackUserCacheImplMBean.logUserCacheEntries();

        trackUserCache.clearUserCache(IDGDI);
        assertNull(userCacheEntries().get(IDGDI));
    }

    @Test
    public void test_cleanUserCacheEntries() throws Exception {
        trackUserCache.trackUserCache(this, getClass().getMethod("methode1", String.class), new Object[]{"123"});
        final val entries = userCacheEntries().get(IDGDI);
        assertEquals(1, entries.getObject().size());

        AtomicReference<Instant> timestamp = (AtomicReference<Instant>) ReflectionTestUtils.getField(entries, "timestamp");
        timestamp.set(Instant.now().minus(40, ChronoUnit.MINUTES));
        trackUserCache.cleanUserCacheEntries();

        final val entries2 = userCacheEntries().get(IDGDI);
        assertNull(entries2);
    }

    @Test
    public void test_trackUserCache_NoAuthRequired() throws Exception {
        trackUserCache.trackUserCache(this, getClass().getMethod("methode2", String.class, String.class), new Object[]{"123", "456"});
        final val entries = userCacheEntries().get(IDGDI);
        assertNull(entries);
    }

    @Cacheable("soapCache")
    public String methode1(String x) {
        return "methode1 : " + x;
    }

    @NoAuthRequired
    @Cacheable(cacheNames = "methode2", keyGenerator = "specialKeyGen")
    public String methode2(String x, String y) {
        return "methode2 : " + x + ", " + y;
    }

    @Cacheable(cacheNames = "methode3", keyGenerator = "specialKeyGen")
    public String methode3() {
        return "methode3 : ";
    }

    @Cacheable(keyGenerator = "specialKeyGen")
    public String methode4() {
        return "methode4 : ";
    }

    @Cacheable(cacheNames = {"a", "b"}, keyGenerator = "specialKeyGen")
    public String methode5(String x) {
        return "methode5 : " + x;
    }

}
