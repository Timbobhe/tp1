package fr.ag2rlamondiale.trm.cache;

import org.junit.Test;
import org.springframework.cache.interceptor.SimpleKey;

import java.lang.reflect.Method;

import static org.junit.Assert.*;

public class WithMethodSimpleKeyGeneratorTest {

    @Test
    public void generate_0arg() throws Exception {
        WithMethodSimpleKeyGenerator keyGen = new WithMethodSimpleKeyGenerator();
        final Method isEmptyMethod = String.class.getMethod("isEmpty");
        final Object key = keyGen.generate(null, isEmptyMethod);
        assertEquals(isEmptyMethod, key);
    }

    @Test
    public void generate_1arg() throws Exception {
        WithMethodSimpleKeyGenerator keyGen = new WithMethodSimpleKeyGenerator();
        final Method startsWithMethod = String.class.getMethod("startsWith", String.class);
        final Object key = keyGen.generate(null, startsWithMethod, "TOTO");
        SimpleKey expected = new SimpleKey(startsWithMethod, "TOTO");
        assertEquals(expected, key);
    }

    @Test
    public void generate_1arg_array() throws Exception {
        WithMethodSimpleKeyGenerator keyGen = new WithMethodSimpleKeyGenerator();
        final Method valueOfMethod = String.class.getMethod("valueOf", char[].class);
        final char[] chars = "TOTO".toCharArray();
        final Object key = keyGen.generate(null, valueOfMethod, (Object) chars);
        SimpleKey expected = new SimpleKey(valueOfMethod, (Object) chars);
        assertEquals(expected, key);
    }

    @Test
    public void generate_2args() throws Exception {
        WithMethodSimpleKeyGenerator keyGen = new WithMethodSimpleKeyGenerator();
        final Method startsWithMethod = String.class.getMethod("startsWith", String.class, int.class);
        final Object key = keyGen.generate(null, startsWithMethod, "TOTO", 1);
        SimpleKey expected = new SimpleKey(startsWithMethod, "TOTO", 1);
        assertEquals(expected, key);
    }
}
