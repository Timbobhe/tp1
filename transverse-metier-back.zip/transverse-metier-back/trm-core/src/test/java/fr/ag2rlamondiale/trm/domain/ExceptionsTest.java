package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.domain.exception.*;
import org.junit.Test;

import static org.junit.Assert.*;

public class ExceptionsTest {

	Throwable t = new Throwable();

	@Test
	public void testContextNotInitializedException() {
	    assertNotNull(new ContextNotInitializedException(t));
	    assertNotNull(new ContextNotInitializedException());
	    assertNotNull(new ContextNotInitializedException(""));
		assertNotNull(new ContextNotInitializedException("", t));
	}

	@Test
	public void testContratException() {
	    assertNotNull(new ContratException(t));
	    assertNotNull(new ContratException(""));
	    assertNotNull(new ContratException("", t));
	}

	@Test
	public void testDocumentException() {
	    assertNotNull(new DocumentException(t));
	    assertNotNull(new DocumentException(""));
	    assertNotNull(new DocumentException("", t));
	}

	@Test
	public void testWSSecurityException() {
	    assertNotNull(new WSSecurityException(t));
		assertNotNull(new WSSecurityException(""));
		assertNotNull(new WSSecurityException("", t));
		assertNotNull(new WSSecurityException());
	}

	@Test
	public void testUnknownEnumerationValueException() {
	    assertNotNull(new UnknownEnumerationValueException(TestEnum.class, ""));
	    assertNotNull(new UnknownEnumerationValueException(TestEnum.A, ""));
	}

	private enum TestEnum {
		A;
	}
}
