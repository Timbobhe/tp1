package fr.ag2rlamondiale.trm.soap;

import com.sun.xml.ws.api.Component;
import com.sun.xml.ws.api.addressing.WSEndpointReference;
import com.sun.xml.ws.api.client.WSPortInfo;
import com.sun.xml.ws.api.message.Header;
import com.sun.xml.ws.developer.WSBindingProvider;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.client.soap.config.HolderXmlResponseHandler;
import fr.ag2rlamondiale.trm.client.soap.config.SoapClientHandlerResolver;
import fr.ag2rlamondiale.trm.client.soap.config.SoapClientHandlerResolverFactory;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.IEndpointResolver;
import fr.ag2rlamondiale.trm.utils.SecurityServiceConfig;
import org.glassfish.gmbal.ManagedObjectManager;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.EndpointReference;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;

@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = SoapRequestInterceptorAspectJTest.class)
public class SoapRequestInterceptorAspectJTest {

    @Autowired
    ServiceTest serviceTest;

    @Autowired
    PortInitializerInterceptor portInitializerInterceptor;

    @Bean
    SoapRequestInterceptor soapRequestInterceptor() {
        return new SoapRequestInterceptor();
    }

    @Bean
    PortInitializerInterceptor portInitializerInterceptor() {
        final PortInitializerInterceptor portInitializerInterceptor = Mockito.spy(new PortInitializerInterceptor());
        return portInitializerInterceptor;
    }

    @Bean
    IHeadersProvider headersProvider() {
        return new IHeadersProvider() {
            @Override
            public Object buildHeader() {
                return null;
            }
        };
    }

    @Bean
    SoapClientHandlerResolverFactory soapClientHandlerResolverFactory() {
        return new SoapClientHandlerResolverFactory() {
            @Override
            public SoapClientHandlerResolver createSoapClientHandlerResolver() {
                return new SoapClientHandlerResolver();
            }
        };
    }

    @Bean
    IEndpointResolver endpointResolver() {
        return Mockito.mock(IEndpointResolver.class);
    }


    @Bean
    ISupplierLibService supplierLibService() {
        return Mockito.mock(ISupplierLibService.class);
    }


    @Bean
    UserContextHolder userContextHolder() {
        return new UserContextHolder();
    }

    @Bean
    ServiceTest serviceTest() {
        return new ServiceTest();
    }

    @Bean
    Port port() {
        return new Port();
    }

    @Bean
    SecurityServiceConfig mapperUtils() {
        return Mockito.mock(SecurityServiceConfig.class);
    }

    @Test
    public void test_withConsumer() throws Exception {
        Mockito.reset(portInitializerInterceptor);
        HolderXmlResponseHandler holderXmlResponseHandler = new HolderXmlResponseHandler();
        final int res = serviceTest.addition_withConsumer(1, 1, soapClientHandlerResolver -> {
            soapClientHandlerResolver.addHandler(holderXmlResponseHandler);
            holderXmlResponseHandler.setXmlResponse("SAMPLE");
        });

        assertEquals(2, res);
        assertEquals("SAMPLE", holderXmlResponseHandler.getXmlResponse());
        Mockito.verify(portInitializerInterceptor).handleSoapClientHandlerResolver(any(), any());
    }

    @Test
    public void test_withConsumerNULL() throws Exception {
        Mockito.reset(portInitializerInterceptor);
        HolderXmlResponseHandler holderXmlResponseHandler = new HolderXmlResponseHandler();
        final int res = serviceTest.addition_withConsumer(1, 1, null);

        assertEquals(2, res);
        assertNull(holderXmlResponseHandler.getXmlResponse());
        Mockito.verify(portInitializerInterceptor).handleSoapClientHandlerResolver(any(), any());
    }

    @Test
    public void test_withoutConsumer() throws Exception {
        Mockito.reset(portInitializerInterceptor);
        final int res = serviceTest.addition_withoutConsumer(1, 1);

        assertEquals(2, res);
        Mockito.verify(portInitializerInterceptor, Mockito.never()).handleSoapClientHandlerResolver(any(), any());
    }

    static class ServiceTest {

        @Autowired
        Port port;

        @SoapRequest
        public int addition_withConsumer(int a, int b, Consumer<SoapClientHandlerResolver> consumer) {
            port.port_withConsumer(consumer);

            return a + b;
        }

        @SoapRequest
        public int addition_withoutConsumer(int a, int b) {
            port.port_withoutConsumer();

            return a + b;
        }
    }

    static class Port {
        @PortInitializer(serviceId = "ServiceId", handleSoapClientHandler = true)
        public BindingProvider port_withConsumer(Consumer<SoapClientHandlerResolver> consumer) {
            return new BindingProviderMock();
        }

        @PortInitializer(serviceId = "ServiceId")
        public BindingProvider port_withoutConsumer() {
            return new BindingProviderMock();
        }
    }


    static class BindingProviderMock implements WSBindingProvider {

        @Override
        public Map<String, Object> getRequestContext() {
            return new HashMap<>();
        }

        @Override
        public Map<String, Object> getResponseContext() {
            return new HashMap<>();
        }

        @Override
        public Binding getBinding() {
            return Mockito.mock(Binding.class);
        }

        @Override
        public EndpointReference getEndpointReference() {
            return null;
        }

        @Override
        public <T extends EndpointReference> T getEndpointReference(Class<T> clazz) {
            return null;
        }

        @Override
        public void setOutboundHeaders(List<Header> headers) {

        }

        @Override
        public void setOutboundHeaders(Header... headers) {

        }

        @Override
        public void setOutboundHeaders(Object... headers) {

        }

        @Override
        public List<Header> getInboundHeaders() {
            return null;
        }

        @Override
        public void setAddress(String address) {

        }

        @Override
        public WSEndpointReference getWSEndpointReference() {
            return null;
        }

        @Override
        public WSPortInfo getPortInfo() {
            return null;
        }

        @Override
        public ManagedObjectManager getManagedObjectManager() {
            return null;
        }

        @Override
        public Set<Component> getComponents() {
            return null;
        }

        @Override
        public <S> S getSPI(Class<S> spiType) {
            return null;
        }

        @Override
        public void close() throws IOException {

        }
    }

}
