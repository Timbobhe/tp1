package fr.ag2rlamondiale.trm.security;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class AuthentificationUtilsTest {

    @Test
    public void hasRole() {
        UserDetails userDetails = mock(UserDetails.class, RETURNS_DEEP_STUBS);
        when(userDetails.getAuthorities()).thenAnswer(invocation -> {
            final ArrayList<SimpleGrantedAuthority> value = new ArrayList<>();
            value.add(new SimpleGrantedAuthority("ROLE_EERE-Federation"));
            return value;
        });

        assertTrue(AuthentificationUtils.hasRole(userDetails, RolesEnum.FEDERATION));
        assertFalse(AuthentificationUtils.hasRole(null, null));
    }
}
