package fr.ag2rlamondiale.trm.domain.error;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.*;

public class RestErrorTest {

    @Test
    public void test() {
        RestError restError1 = new RestError("a", "b", new ArrayList<>());
        RestError restError2 = new RestError("a", "b");
        restError1.addMessage("c");
        restError1.addMessage("d");
        restError2.addMessages(Arrays.asList("c", "d"));
        assertEquals(restError1, restError2);
    }
}
