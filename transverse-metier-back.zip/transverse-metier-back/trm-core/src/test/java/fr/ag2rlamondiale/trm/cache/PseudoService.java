package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.REQUEST_CACHE_RESOLVER;

@Slf4j
@Component
public class PseudoService {

    private final AtomicBoolean sansCache = new AtomicBoolean(false);

    private Map<RequetePersonnePhysique, PersonnePhysique> jdd = new HashMap<>();

    public PseudoService put(RequetePersonnePhysique key, PersonnePhysique value) {
        jdd.put(key, value);
        return this;
    }

    @Cacheable(cacheResolver = REQUEST_CACHE_RESOLVER)
    public PersonnePhysique rechercheRequestCache(RequetePersonnePhysique criteres) {
        log.info("Recherche PP (sans cache) {}", criteres);
        setSansCache(true);
        return jdd.get(criteres);
    }

    public PersonnePhysique rechercheSansCache(RequetePersonnePhysique criteres) {
        log.info("Recherche Other PP (sans cache) {}", criteres);
        setSansCache(true);
        return jdd.get(criteres);
    }

    public boolean isSansCache() {
        return sansCache.get();
    }

    public PseudoService setSansCache(boolean sansCache) {
        this.sansCache.set(sansCache);
        return this;
    }

    public void resetSansCache() {
        this.setSansCache(false);
    }

}
