package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.convert.converter.ConverterRegistry;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class FonctionnaliteTypeJsonDeserializerTest {

    @InjectMocks
    FonctionnaliteTypeConverter fonctionnaliteTypeConverter;

    @Mock
    ConverterRegistry converterRegistry;


    @Test
    public void test_deserialize() {
        final FonctionnaliteType vosCoordonneesBancaires = JsonMarshaller.fromJSON("\"VosCoordonneesBancaires\"", FonctionnaliteType.class);
        assertEquals(FonctionnaliteType.COORDONNEES_BANCAIRES, vosCoordonneesBancaires);
    }

    @Test
    public void test_serialize() {
        final String s = JsonMarshaller.toJSON(FonctionnaliteType.COORDONNEES_BANCAIRES);
        assertEquals("\"VosCoordonneesBancaires\"", s);
    }

    @Test
    public void test_converter() {
        fonctionnaliteTypeConverter.setConverterRegistry(converterRegistry);
        fonctionnaliteTypeConverter.afterPropertiesSet();
        verify(converterRegistry, times(1)).addConverter(String.class, FonctionnaliteType.class, fonctionnaliteTypeConverter);

        final FonctionnaliteType vosCoordonneesBancaires = fonctionnaliteTypeConverter.convert("VosCoordonneesBancaires");
        assertEquals(FonctionnaliteType.COORDONNEES_BANCAIRES, vosCoordonneesBancaires);
    }

    private Map<String, ConverterRegistry> converterRegistryMap() {
        Map<String, ConverterRegistry> converterRegistryMap = new HashMap<>();
        converterRegistryMap.put("test", converterRegistry);
        return converterRegistryMap;
    }
}
