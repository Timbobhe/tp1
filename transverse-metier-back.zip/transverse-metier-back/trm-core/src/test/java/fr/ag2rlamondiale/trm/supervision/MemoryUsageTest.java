package fr.ag2rlamondiale.trm.supervision;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;

import static org.junit.Assert.*;

@Slf4j
public class MemoryUsageTest {

    @Test
    public void test_stats() throws Exception {
        final MemoryUsage.MemoryStats memoryStats = new MemoryUsage().memoryStats();
        assertNotNull(memoryStats);
        log.info(memoryStats.toString());
    }
}
