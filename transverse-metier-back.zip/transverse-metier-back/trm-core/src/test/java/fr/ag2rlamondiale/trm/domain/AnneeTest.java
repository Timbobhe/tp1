package fr.ag2rlamondiale.trm.domain;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Date;

import static org.junit.Assert.*;

public class AnneeTest {

    @Test
    public void test_should_equals() throws Exception {
        Annee c1 = Annee.Courante;
        Annee c2 = Annee.Courante;
        assertEquals(c1, c2);
        assertAnnee(c1);

        Annee p1 = Annee.Precedente;
        Annee p2 = Annee.Precedente;
        assertEquals(p1, p2);
        assertAnnee(p1);

        Annee pr1 = Annee.Prochaine;
        Annee pr2 = Annee.Prochaine;
        assertEquals(pr1, pr2);
        assertAnnee(pr1);

        assertEquals(Annee.Courante.toLocalDate().getYear() + 1, Annee.Prochaine.toLocalDate().getYear());
        assertEquals(Annee.Courante.toLocalDate().getYear() - 1, Annee.Precedente.toLocalDate().getYear());

        assertEquals(pr2, Annee.fromYear(pr2.getYear()));
    }

    private void assertAnnee(Annee annee) {
        final Date date = annee.toDate();
        final LocalDate localDate = annee.toLocalDate();
        final String localDateStr = localDate.format(DateTimeFormatter.ISO_LOCAL_DATE);
        final String dateStr = new SimpleDateFormat("yyyy-MM-dd").format(date);
        assertEquals(localDateStr, dateStr);
        assertTrue(annee.toString().contains("" + annee.getYear()));
    }

    @Test
    public void test_should_return_bornes() throws Exception {
        final Annee.BorneAnnee borneAnneeCourante = Annee.Courante.borneAnnee();
        assertBornes(borneAnneeCourante);
        final Annee.BorneAnnee borneAnneePrecedente = Annee.Precedente.borneAnnee();
        assertBornes(borneAnneePrecedente);
        final Annee.BorneAnnee borneAnneeProchaine = Annee.Prochaine.borneAnnee();
        assertBornes(borneAnneeProchaine);
    }

    private void assertBornes(Annee.BorneAnnee borneAnnee) {
        assertNotNull(borneAnnee);

        assertEquals(1, borneAnnee.getFirstDate().getDayOfMonth());
        assertEquals(1, borneAnnee.getFirstDate().getMonthValue());
        assertEquals("01-01", new SimpleDateFormat("MM-dd").format(borneAnnee.toFirstDate()));

        assertEquals(31, borneAnnee.getLastDate().getDayOfMonth());
        assertEquals(12, borneAnnee.getLastDate().getMonthValue());
        assertEquals("12-31", new SimpleDateFormat("MM-dd").format(borneAnnee.toLastDate()));

        assertTrue(borneAnnee.toString().contains("firstDate"));
        assertTrue(borneAnnee.toString().contains("lastDate"));
    }
}
