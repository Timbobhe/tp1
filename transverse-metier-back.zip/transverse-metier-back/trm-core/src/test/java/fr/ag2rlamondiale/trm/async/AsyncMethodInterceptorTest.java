package fr.ag2rlamondiale.trm.async;

import com.ag2r.common.exceptions.TechnicalException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.jasig.cas.client.authentication.AttributePrincipalImpl;
import org.jasig.cas.client.validation.AssertionImpl;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = AsyncMethodInterceptorTest.class)
public class AsyncMethodInterceptorTest {

    @Autowired
    ServiceTest serviceTest;

    static {
        System.setProperty(SecurityContextHolder.SYSTEM_PROPERTY, SecurityContextHolder.MODE_GLOBAL);
    }

    @Test
    public void test_callAsyncSansUser() throws Exception {
        try {
            final Future<String> future = serviceTest.asyncMethodWithReturnType();
            System.out.println(future.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            final Throwable cause = ExceptionUtils.getRootCause(e);
            assertEquals("Aucun utilisateur n'est identifie", cause.getMessage());
        }
    }

    @Test
    @Ignore("Ce test ne passe pas sur Jenkins sur la release/2 - raison inconnue pour le moment")
    public void test_callAsyncAvecUser() throws Exception {
        initSecurityContext("IDGDI");

        assertNotNull(SecurityContextHolder.getContext());
        assertNotNull(SecurityContextHolder.getContext().getAuthentication());

        final Future<String> future = serviceTest.asyncMethodWithReturnType();
        System.out.println(future.get());
    }

    public static void initSecurityContext(String idgdi) {
        SecurityContext context = new SecurityContextImpl();
        context.setAuthentication(buildAuthentication(idgdi));
        SecurityContextHolder.setContext(context);
    }

    @Test(expected = ExecutionException.class)
    public void test_callErrorAsyncAvecUser() throws Exception {
        initSecurityContext("IDGDI");

        assertNotNull(SecurityContextHolder.getContext());
        assertNotNull(SecurityContextHolder.getContext().getAuthentication());

        final Future<String> future = serviceTest.asyncMethodWithError();
        System.out.println(future.get());
    }


    @Bean
    ServiceTest serviceTest() {
        return new ServiceTest();
    }

    static class ServiceTest {

        @Async
        public Future<String> asyncMethodWithReturnType() {
            System.out.println("Execute method asynchronously - " + Thread.currentThread().getName());
            try {
                Thread.sleep(500);
                return new AsyncResult<>("hello world !!!!");
            } catch (InterruptedException e) {
                //
            }

            return null;
        }

        @Async
        public Future<String> asyncMethodWithError() throws TechnicalException {
            System.out.println("Execute method asynchronously - " + Thread.currentThread().getName());
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                //
            }

            throw new TechnicalException("test-error-async");
        }

    }


    public static CasAssertionAuthenticationToken buildAuthentication(String idgdi) {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", idgdi);
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        attributes.put("roles", Arrays.asList("NET-Utilisateur", "EERE-Salarie"));
        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");
        AttributePrincipalImpl principal = new AttributePrincipalImpl(idgdi, attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }
}
