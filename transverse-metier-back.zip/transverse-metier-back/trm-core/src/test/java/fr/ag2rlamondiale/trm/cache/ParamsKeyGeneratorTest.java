package fr.ag2rlamondiale.trm.cache;

import org.junit.Test;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.SimpleKey;

import java.lang.reflect.Method;

import static org.junit.Assert.*;

public class ParamsKeyGeneratorTest {

    @Test
    public void test() throws NoSuchMethodException, SecurityException {
        ParamsKeyGenerator gen = new ParamsKeyGenerator();
        
     // Cas 0
        Method testNothing = this.getClass().getMethod("testNothing");
        Object o0 = gen.generate(null, testNothing);
        assertEquals(SimpleKey.EMPTY, o0);
        // Cas 1
        Method testCacheEvict = this.getClass().getMethod("testCacheEvict");
        Object o1 = gen.generate(null, testCacheEvict);
        assertEquals(SimpleKey.EMPTY, o1);
     // Cas 2
        Method testCacheable1 = this.getClass().getMethod("testCacheable1");
        Object o2 = gen.generate(null, testCacheable1);
        assertEquals(SimpleKey.EMPTY, o2);
     // Cas 3
        Method testCacheable2 = this.getClass().getMethod("testCacheable2");
        Object o3 = gen.generate(null, testCacheable2);
        assertEquals(SimpleKey.EMPTY, o3);
     // Cas 4
        Method testCacheable3 = this.getClass().getMethod("testCacheable3");
        Object o4 = gen.generate(null, testCacheable3);
        assertEquals(SimpleKey.EMPTY, o4);
    }
    
    public void testNothing() {
        
    }
    
    @CacheEvict
    public void testCacheEvict() {

    }

    @Cacheable
    public void testCacheable1() {
        
    }

    @Cacheable(cacheNames = {})
    public void testCacheable2() {
        
    }
    
    @Cacheable(cacheNames = "employee")
    public void testCacheable3() {

    }

    @Cacheable(cacheNames = "soapCache")
    public void testCacheable4() {
        
    }
}
