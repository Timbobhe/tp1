package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.domain.constantes.Constantes;
import fr.ag2rlamondiale.trm.domain.operation.CodeIdentifiantType;
import fr.ag2rlamondiale.trm.domain.operation.CodeSituationOperationType;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationEREType;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationMDPType;
import org.junit.Test;

import static org.junit.Assert.*;

public class MrEnumTest {

	@Test
	public void testCodeActionType() {
		assertEquals(CodeActionType.TP_SM_CTR_RECHCTR, CodeActionType.valueOf("TP_SM_CTR_RECHCTR"));
	}

	@Test
	public void testCodeApplicationType() {
		assertEquals("A1324", CodeApplicationType.AQEA.getCode());
		assertEquals(CodeApplicationType.AQEA, CodeApplicationType.getTypeByCode("A1324"));
		assertEquals(null,CodeApplicationType.getTypeByCode("A0000"));
	}

	@Test
	public void testCodeCategorieDocType() {
		assertEquals("S", CodeCategorieDocType.SPECIFIQUE.getLibelle());
	}

	@Test
	public void test() {
		assertEquals("S", CodeDestinataireType.SALARIE.getLibelle());
		assertEquals(CodeDestinataireType.ASSURE, CodeDestinataireType.fromLibelle("A"));
		assertEquals(null,CodeDestinataireType.fromLibelle("B"));
	}

	@Test
	public void testCodeLangueType() {
		assertEquals("FRA", CodeLangueType.FRANCAIS.getLibelle());
	}

	@Test
	public void testCodeSiloType() {
		assertEquals("MDP", CodeSiloType.MDP.getLibelle());
		assertEquals("ERE", CodeSiloType.ERE.getLibelle());
	}

	@Test
	public void testConstantes() {
		assertEquals("PER", Constantes.CodesNatTel.PER.name());
		assertEquals("RC", Constantes.cnt_aut.RC.name());
		assertEquals("EPHAT", Constantes.ep_hand.EPHAT.name());
		assertEquals("RC03V01", Constantes.ver_aut.RC03V01.name());
		assertEquals("RC08V01", Constantes.AutorizedProductsForSupportSelection.RC08V01.name());
		assertEquals("RC08V02", Constantes.fiscdsk_aut.RC08V02.name());
		assertEquals("EC", Constantes.stat_aut.EC.name());
		assertEquals("DGN", Constantes.benef_non_aut.DGN.name());
	}

	@Test
	public void testCodeIdentifiantType() {
		assertEquals("AFFILIE", CodeIdentifiantType.AFFILIE.getLibelle());
	}

	@Test
	public void testCodeSituationOperationType() {
		assertEquals("V", CodeSituationOperationType.VALOR.getCodeSilo());
		assertEquals(CodeSituationOperationType.VALOR, CodeSituationOperationType.fromString("VALOR"));
		assertEquals(null, CodeSituationOperationType.fromString("AAA"));
	}

	@Test
	public void testCodeTypeOperationEREType() {
		assertEquals("GARB_A", CodeTypeOperationEREType.GARB_A.name());
	}

	@Test
	public void testCodeTypeOperationMDPType() {
		assertEquals("AF", CodeTypeOperationMDPType.AF.name());
	}
}
