package fr.ag2rlamondiale.trm.jahia;

import lombok.Setter;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.function.Supplier;

public class MockHttpURLConnection extends HttpURLConnection {

    @Setter
    private Supplier<InputStream> inputStream;

    @Setter
    private int responseCode;

    public MockHttpURLConnection(URL u) {
        super(u);
    }

    @Override
    public InputStream getInputStream() throws IOException {
        return inputStream.get();
    }

    @Override
    public int getResponseCode() throws IOException {
        return responseCode;
    }

    @Override
    public void disconnect() {

    }

    @Override
    public boolean usingProxy() {
        return false;
    }

    @Override
    public void connect() throws IOException {

    }
}
