package fr.ag2rlamondiale.trm.soap;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.client.soap.config.AttachmentResponse;
import fr.ag2rlamondiale.trm.client.soap.config.SoapClientHandlerResolver;
import fr.ag2rlamondiale.trm.client.soap.config.SoapClientHandlerResolverFactory;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DefaultEndpointResolver;
import org.aspectj.lang.JoinPoint;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.StringValueResolver;

import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;
import java.util.ArrayList;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class PortInitializerInterceptorTest {

    @InjectMocks
    PortInitializerInterceptor portInitializerInterceptor;

    @Mock
    private SoapClientHandlerResolverFactory soapClientHandlerResolverFactory;

    @Mock
    StringValueResolver stringValueResolver;

    @Mock
    DefaultEndpointResolver endpointResolver;

    @Mock
    SoapClientHandlerResolver soapClientHandlerResolver;

    @Mock
    ISupplierLibService supplierLibService;
    
    @Mock
    private UserContextHolder userContextHolder;

    @Before
    public void init() {
        when(stringValueResolver.resolveStringValue(any())).thenAnswer(invocation -> invocation.getArguments()[0]);
        when(endpointResolver.getSoapUrl(any(PortInitializer.class))).thenAnswer(invocation -> {
            PortInitializer portInitializer = (PortInitializer) invocation.getArguments()[0];
            return portInitializer.serviceId();
        });


        when(soapClientHandlerResolver.getHandlerChain(null)).thenReturn(new ArrayList<>(0));
        when(soapClientHandlerResolverFactory.createSoapClientHandlerResolver()).then(invocation -> soapClientHandlerResolver);
        ReflectionTestUtils.setField(portInitializerInterceptor, "endpointResolver", endpointResolver);
    }

    @Test
    public void test_afterReturning() {
        // Given
        JoinPoint joinPoint = mock(JoinPoint.class);
        PortInitializer portInitializer = mock(PortInitializer.class);
        try {
            // When
            portInitializerInterceptor.afterReturning(joinPoint, null, portInitializer);
            // Then no error
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void test_afterReturning_2() throws NoSuchMethodException {
        // Given
        JoinPoint joinPoint = mock(JoinPoint.class);

        PortInitializer portInitializer = mock(PortInitializer.class);
        when(portInitializer.serviceId()).thenReturn("GestMandat_1/RechercherMandat_1");
        when(userContextHolder.get()).thenReturn(new UserContext());

        BindingProvider pb = mock(BindingProvider.class, RETURNS_DEEP_STUBS);
        Binding binding = mock(Binding.class);
        doNothing().when(binding).setHandlerChain(anyList());
        when(pb.getBinding()).thenReturn(binding);

        try {
            // When
            portInitializerInterceptor.afterReturning(joinPoint, pb, portInitializer);
            // Then no error
        } catch (Exception e) {
            fail();
        }
    }


    @Test
    public void test_afterReturning_4() {
        // Given
        JoinPoint joinPoint = mock(JoinPoint.class);
        AttachmentResponse attachement = new AttachmentResponse();
        when(joinPoint.getArgs()).thenReturn(new Object[]{attachement});

        PortInitializer portInitializer = mock(PortInitializer.class);
        when(portInitializer.serviceId()).thenReturn("GestMandat_1/RechercherMandat_1");
        when(portInitializer.withAttachment()).thenReturn(true);
        when(userContextHolder.get()).thenReturn(new UserContext());
        
        BindingProvider pb = mock(BindingProvider.class, RETURNS_DEEP_STUBS);
        Binding binding = mock(Binding.class);
        doNothing().when(binding).setHandlerChain(anyList());
        when(pb.getBinding()).thenReturn(binding);

        try {
            // When
            portInitializerInterceptor.afterReturning(joinPoint, pb, portInitializer);
            // Then no Error
        } catch (Exception e) {
            fail();
        }
    }
}
