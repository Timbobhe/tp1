package fr.ag2rlamondiale.trm.pdf;

import fr.ag2rlamondiale.trm.domain.document.ArbitrageChampsPdfType;
import fr.ag2rlamondiale.trm.domain.document.ChampsPDFInfo;
import fr.ag2rlamondiale.trm.domain.document.ChampsPdfType;
import fr.ag2rlamondiale.trm.domain.document.TypeChampsPdfType;
import fr.ag2rlamondiale.trm.domain.exception.DocumentException;
import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;

@RunWith(MockitoJUnitRunner.class)
public class FillPdfServiceImplTest {

    @InjectMocks
    private FillPdfServiceImpl sut;

    File file = new File("src/test/resources/document/BIA_en_ligne.pdf");
    File out = new File("src/test/resources/document/BIA_en_ligne_filled.pdf");


    @Test
    public void should_fill_Pdf_form_without_appearances() throws IOException, DocumentException {
        HashMap<String, ChampsPDFInfo> expected = generateMapParameters();
        sut.fillPdfForm(new FileInputStream(file), new FileOutputStream(out), generateMapParameters(),"test", false);

        PDAcroForm document = PDDocument.load(out).getDocumentCatalog().getAcroForm();

        Assert.assertEquals(expected.get(ChampsPdfType.ADR_LEGALE.getChamps()).getValeur(),
                document.getField(ChampsPdfType.ADR_LEGALE.getChamps()).getValueAsString());
    }

    @Test
    public void should_fill_Pdf_form_with_appearances() throws IOException, DocumentException {
        HashMap<String, ChampsPDFInfo> expected = generateMapParameters();
        sut.fillPdfForm(new FileInputStream(file), new FileOutputStream(out), generateMapParameters(), "test");

        PDAcroForm document = PDDocument.load(out).getDocumentCatalog().getAcroForm();

        Assert.assertEquals(expected.get(ChampsPdfType.ADR_LEGALE.getChamps()).getValeur(),
                document.getField(ChampsPdfType.ADR_LEGALE.getChamps()).getValueAsString());
    }

    @Test
    public void should_fill_pdf_form_with_byte_array_as_input_without_appearances() throws IOException, DocumentException {
        HashMap<String, ChampsPDFInfo> expected = generateMapParameters();

        sut.fillPdfForm(FileUtils.readFileToByteArray(file), new FileOutputStream(out), generateMapParameters(),"test" , false);
        PDAcroForm document = PDDocument.load(out).getDocumentCatalog().getAcroForm();

        Assert.assertEquals(expected.get(ChampsPdfType.ADR_LEGALE.getChamps()).getValeur(),
                document.getField(ChampsPdfType.ADR_LEGALE.getChamps()).getValueAsString());

    }

    @Test
    public void should_fill_pdf_form_with_byte_array_as_input_with_appearances() throws IOException, DocumentException {
        HashMap<String, ChampsPDFInfo> expected = generateMapParameters();

        sut.fillPdfForm(FileUtils.readFileToByteArray(file), new FileOutputStream(out), generateMapParameters(), "test");
        PDAcroForm document = PDDocument.load(out).getDocumentCatalog().getAcroForm();

        Assert.assertEquals(expected.get(ChampsPdfType.ADR_LEGALE.getChamps()).getValeur(),
                document.getField(ChampsPdfType.ADR_LEGALE.getChamps()).getValueAsString());

    }


    private HashMap<String, ChampsPDFInfo> generateMapParameters() {
        HashMap<String, ChampsPDFInfo> params = new HashMap<>();
        params.put(ChampsPdfType.ADR_LEGALE.getChamps(), new ChampsPDFInfo("adresse légale", TypeChampsPdfType.TEXT_LB));
        params.put(ChampsPdfType.ADRESSE1.getChamps(), new ChampsPDFInfo("adresse 1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE2.getChamps(), new ChampsPDFInfo("adresse 2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE3.getChamps(), new ChampsPDFInfo("adresse 3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE4.getChamps(), new ChampsPDFInfo("adresse 4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ADRESSE_COURRIER.getChamps(), new ChampsPDFInfo("adresse courrier", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.ANNUEL.getChamps(), new ChampsPDFInfo("annuel", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VL.getChamps(), new ChampsPDFInfo("choix vl", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CHOIX_VP.getChamps(), new ChampsPDFInfo("choix vp", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_SPECIFIQUE.getChamps(), new ChampsPDFInfo("clause spécifique", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CLAUSE_STANDARD.getChamps(), new ChampsPDFInfo("clause Standard", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_POSTAL.getChamps(), new ChampsPDFInfo("code postal", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CODE_PRODUIT.getChamps(), new ChampsPDFInfo("code produit", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COLLEGE.getChamps(), new ChampsPDFInfo("college", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.COMPTEUR_SF.getChamps(), new ChampsPDFInfo("compteur SF", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.CONSENTEMENTS.getChamps(), new ChampsPDFInfo("consentements", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_NAISSANCE.getChamps(), new ChampsPDFInfo("02/10/1991", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DATE_VP.getChamps(), new ChampsPDFInfo("02/10/1991", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.DEPARTEMENT_NAISSANCE.getChamps(), new ChampsPDFInfo("departement de naissance", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.E_MAIL.getChamps(), new ChampsPDFInfo("email", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF1.getChamps(), new ChampsPDFInfo("fa sf1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF2.getChamps(), new ChampsPDFInfo("fa sf2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF3.getChamps(), new ChampsPDFInfo("fa sf3)", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF4.getChamps(), new ChampsPDFInfo("fa sf4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF5.getChamps(), new ChampsPDFInfo("fa sf5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF6.getChamps(), new ChampsPDFInfo("fa sf6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_SF7.getChamps(), new ChampsPDFInfo("fa sf7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("FA_STRATEGIE_FINANCIERE7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF1.getChamps(), new ChampsPDFInfo("FA_TAUX_SF1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF2.getChamps(), new ChampsPDFInfo("FA_TAUX_SF2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF3.getChamps(), new ChampsPDFInfo("FA_TAUX_SF3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF4.getChamps(), new ChampsPDFInfo("FA_TAUX_SF4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF5.getChamps(), new ChampsPDFInfo("FA_TAUX_SF5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF6.getChamps(), new ChampsPDFInfo("FA_TAUX_SF6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FA_TAUX_SF7.getChamps(), new ChampsPDFInfo("FA_TAUX_SF7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.FONDS_DEFAUT.getChamps(), new ChampsPDFInfo("FONDS_DEFAUT", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.IDENTIFIANT.getChamps(), new ChampsPDFInfo("IDENTIFIANT", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LIEU_NAISSANCE.getChamps(), new ChampsPDFInfo("LIEU_NAISSANCE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.LOGO.getChamps(), new ChampsPDFInfo("http://inscription-dev/jahia7/files/live/sites/aqe/files/contributed/images/logos/ARI.png", TypeChampsPdfType.LOGO));
        params.put(ChampsPdfType.MADAME.getChamps(), new ChampsPDFInfo(ChampsPdfType.MADAME.getChamps(), TypeChampsPdfType.CHECKBOX));
        params.put(ChampsPdfType.MENSUEL.getChamps(), new ChampsPDFInfo("MENSUEL", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONSIEUR.getChamps(), new ChampsPDFInfo(ChampsPdfType.MONSIEUR.getChamps(), TypeChampsPdfType.CHECKBOX));
        params.put(ChampsPdfType.MONTANT_VL.getChamps(), new ChampsPDFInfo("MONTANT_VL", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.MONTANT_VP.getChamps(), new ChampsPDFInfo("MONTANT_VP", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM_NAISSANCE.getChamps(), new ChampsPDFInfo("NOM_NAISSANCE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NOM.getChamps(), new ChampsPDFInfo("NOM", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.NUM_CONTRAT.getChamps(), new ChampsPDFInfo("NUM_CONTRAT", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF1.getChamps(), new ChampsPDFInfo("OB_SF1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF2.getChamps(), new ChampsPDFInfo("OB_SF2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF3.getChamps(), new ChampsPDFInfo("OB_SF3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF4.getChamps(), new ChampsPDFInfo("OB_SF4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF5.getChamps(), new ChampsPDFInfo("OB_SF5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF6.getChamps(), new ChampsPDFInfo("OB_SF6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_SF7.getChamps(), new ChampsPDFInfo("OB_SF7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE1.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE2.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE3.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE4.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE5.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE6.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_STRATEGIE_FINANCIERE7.getChamps(), new ChampsPDFInfo("OB_STRATEGIE_FINANCIERE7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF1.getChamps(), new ChampsPDFInfo("OB_TAUX_SF1", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF2.getChamps(), new ChampsPDFInfo("OB_TAUX_SF2", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF3.getChamps(), new ChampsPDFInfo("OB_TAUX_SF3", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF4.getChamps(), new ChampsPDFInfo("OB_TAUX_SF4", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF5.getChamps(), new ChampsPDFInfo("OB_TAUX_SF5", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF6.getChamps(), new ChampsPDFInfo("OB_TAUX_SF6", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OB_TAUX_SF7.getChamps(), new ChampsPDFInfo("OB_TAUX_SF7", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.OPT_IN.getChamps(), new ChampsPDFInfo("OPT_IN", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRENOM.getChamps(), new ChampsPDFInfo("PRENOM", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PAYS.getChamps(), new ChampsPDFInfo("PAYS", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.PRODUIT.getChamps(), new ChampsPDFInfo("PRODUIT", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.QR_CODE.getChamps(), new ChampsPDFInfo("RG151312337" + "numPers" + "1001BIA", TypeChampsPdfType.QRCODE));
        params.put(ChampsPdfType.RAISON_SOCIALE.getChamps(), new ChampsPDFInfo("RAISON_SOCIALE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SEMESTRIEL.getChamps(), new ChampsPDFInfo("SEMESTRIEL", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.SF.getChamps(), new ChampsPDFInfo("SF", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.STRATEGIE_FINANCIERE.getChamps(), new ChampsPDFInfo("STRATEGIE_FINANCIERE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TAUX_SF.getChamps(), new ChampsPDFInfo("TAUX_SF", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("TELEPHONE_FIXE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PORTABLE.getChamps(), new ChampsPDFInfo("TELEPHONE_PORTABLE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_FIXE.getChamps(), new ChampsPDFInfo("TELEPHONE_FIXE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TELEPHONE_PROFESSIONNEL.getChamps(), new ChampsPDFInfo("TELEPHONE_PROFESSIONNEL", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TEXTE_CLAUSESPECIFIQUE.getChamps(), new ChampsPDFInfo("TEXTE_CLAUSESPECIFIQUE", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.TRIMESTRIEL.getChamps(), new ChampsPDFInfo("TRIMESTRIEL", TypeChampsPdfType.TEXT));
        params.put(ChampsPdfType.VILLE.getChamps(), new ChampsPDFInfo("VILLE", TypeChampsPdfType.TEXT));
        params.put(ArbitrageChampsPdfType.GRAPHIQUE.getChamps(), new ChampsPDFInfo("test", TypeChampsPdfType.HTML));
        return params;
    }
}
