package fr.ag2rlamondiale.trm.security;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.Objects;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class UserContextHolderTest {

    @InjectMocks
    private UserContextHolder userContextHolder;

    public void set() {
        UserContext userContext = new UserContext();
        userContextHolder.set(userContext);
    }

    @Test
    public void get1() {
        userContextHolder.clean();
        RequestContextHolder.resetRequestAttributes();
        UserContext userContext = userContextHolder.get();
        assertNotNull(userContext);
        // User existant
        userContextHolder.get();
        String sessionId = userContextHolder.getSessionId();
        assertNotNull(userContext);
        assertNull(sessionId);
    }

    @Test
    public void get2() {
        userContextHolder.clean();
        RequestContextHolder.resetRequestAttributes();
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        Objects.requireNonNull(attributes);
        RequestContextHolder.setRequestAttributes(attributes);
        UserContext userContext = userContextHolder.get();
        assertNotNull(userContext);
    }

    @Test
    public void get3() {
        userContextHolder.clean();
        RequestContextHolder.resetRequestAttributes();
        userContextHolder.getSessionId();
        UserContext user = new UserContext();
        user.setIdGdi("id");
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        Objects.requireNonNull(attributes);
        attributes.setAttribute(UserContextHolder.SESSION_USER_CONTEXT, user,
                RequestAttributes.SCOPE_SESSION);
        RequestContextHolder.setRequestAttributes(attributes);
        userContextHolder.save(user);
        UserContext userContext = userContextHolder.get();
        assertNotNull(userContext);
        String sessionId = userContextHolder.getSessionId();
        userContextHolder.setCurrentIdContrat("");
        userContextHolder.setCurrentCodeSilo("");
        assertNotNull(userContext);
        assertEquals("id", userContext.getIdGdi());
        assertEquals("1", sessionId);
    }
}
