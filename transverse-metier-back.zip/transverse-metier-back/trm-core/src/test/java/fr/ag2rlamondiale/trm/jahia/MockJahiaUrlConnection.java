package fr.ag2rlamondiale.trm.jahia;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class MockJahiaUrlConnection implements JahiaUrlConnection {

    static final String DOCUMENT_URL = "http://inscription-dev/jahia7/files/live/sites/aqe/files/contributed/DOCUMENTS/";
    static final String LOGO_URL = "http://inscription-dev/jahia7/files/live/sites/aqe/files/contributed/images/logos/";

    private Map<URL, MockHttpURLConnection> mocks = new HashMap<>();

    public MockHttpURLConnection put(URL key, MockHttpURLConnection value) {
        return mocks.put(key, value);
    }

    public MockJahiaUrlConnection put(URL key, Supplier<InputStream> inputStream, int responseCode, Consumer<MockHttpURLConnection> consumer) {
        MockHttpURLConnection mock = new MockHttpURLConnection(key);
        mock.setInputStream(inputStream);
        mock.setResponseCode(responseCode);

        if (consumer != null) {
            consumer.accept(mock);
        }

        mocks.put(key, mock);
        return this;
    }

    public MockJahiaUrlConnection put(URL key, String resourcePath, int responseCode, Consumer<MockHttpURLConnection> consumer) {
        return put(key, () -> MockJahiaUrlConnection.class.getResourceAsStream(resourcePath), responseCode, consumer);
    }


    @Override
    public HttpURLConnection getUrlConnection(URL url) throws IOException {
        MockHttpURLConnection defaultMock = new MockHttpURLConnection(url);
        defaultMock.setResponseCode(404);
        final MockHttpURLConnection res = mocks.getOrDefault(url, defaultMock);
        return res;
    }
}
