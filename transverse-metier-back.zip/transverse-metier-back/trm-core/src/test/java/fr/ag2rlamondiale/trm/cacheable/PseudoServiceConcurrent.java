package fr.ag2rlamondiale.trm.cacheable;

import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import fr.ag2rlamondiale.trm.thread.Boom;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.RUNTIME_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

@Slf4j
@Component
class PseudoServiceConcurrent {

    private AtomicInteger counter = new AtomicInteger(0);

    private ConcurrentMap<RequetePersonnePhysique, AtomicInteger> counterByCritere = new ConcurrentHashMap<>();

    private boolean sansCache = false;

    private Map<RequetePersonnePhysique, PersonnePhysique> jdd = new HashMap<>();

    public PseudoServiceConcurrent put(RequetePersonnePhysique key, PersonnePhysique value) {
        jdd.put(key, value);
        return this;
    }

    @Cacheable(cacheNames = "soapCache")
    public PersonnePhysique rechercheSoapCache(RequetePersonnePhysique criteres) {
        log.info("Recherche PP (sans cache) {}", criteres);
        counter.incrementAndGet();
        counterByCritere.computeIfAbsent(criteres, requetePersonnePhysique -> new AtomicInteger()).incrementAndGet();
        setSansCache(true);
        Boom.pause(0);
        return jdd.computeIfAbsent(criteres, this::create);
    }

    PersonnePhysique create(RequetePersonnePhysique criteres) {
        final String i = criteres.getIdGDI();
        PersonnePhysique pp = new PersonnePhysique();
        pp.setIdGdi("" + i);
        pp.setNom("NOM" + i);
        pp.setPrenom("PRENOM" + i);
        pp.setNumeroPersonneEre("NUMERE" + i);
        pp.setNumeroPersonneMdpro("NUMMDPRO" + i);
        return pp;
    }

    @Cacheable(cacheNames = "soapCache", keyGenerator = SIMPLE_KEY_GENERATOR)
    public PersonnePhysique rechercheSoapCacheWithSimpleKeyGenerator(RequetePersonnePhysique criteres) {
        log.info("Recherche PP (sans cache) {}", criteres);
        counter.incrementAndGet();
        setSansCache(true);
        return jdd.computeIfAbsent(criteres, this::create);
    }

    @Cacheable("otherCache")
    public PersonnePhysique rechercheOtherCache(RequetePersonnePhysique criteres) {
        log.info("Recherche Other PP (sans cache) {}", criteres);
        counter.incrementAndGet();
        setSansCache(true);
        return jdd.computeIfAbsent(criteres, this::create);
    }

    @Cacheable(cacheNames = "rechercheCache", cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public PersonnePhysique rechercheCache(RequetePersonnePhysique criteres) {
        log.info("Recherche Other PP (cache) {}", criteres);
        counter.incrementAndGet();
        setSansCache(true);
        return jdd.get(criteres);
    }

    @CacheEvict(cacheNames = "rechercheCache", cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public void evictRechercheCache(RequetePersonnePhysique criteres) {
        log.info("EVICT Recherche Other PP (cache) {}", criteres);
        setSansCache(true);
        counter.set(0);
    }

    public boolean isSansCache() {
        return sansCache;
    }

    public PseudoServiceConcurrent setSansCache(boolean sansCache) {
        this.sansCache = sansCache;
        return this;
    }

    public void resetSansCache() {
        this.setSansCache(false);
        this.counter.set(0);
    }

    public AtomicInteger getCounter() {
        return counter;
    }

    public ConcurrentMap<RequetePersonnePhysique, AtomicInteger> getCounterByCritere() {
        return counterByCritere;
    }
}
