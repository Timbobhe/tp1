package fr.ag2rlamondiale.trm.configuration;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

@PropertySource("classpath:/console-properties-inactive.properties")
@ContextConfiguration(classes = ConsolePropertiesInactiveTest.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class ConsolePropertiesInactiveTest {

    @Value("#{consoleProps.demoActive}")
    private Boolean demoActive;

    @Autowired
    ConsoleProperties consoleProperties;

    @Bean("consoleProps")
    ConsoleProperties consoleProperties() {
        return new ConsoleProperties();
    }

    @Test
    public void test_inactive() throws Exception {
        assertFalse(consoleProperties.isConsoleV2Active());
        assertFalse(consoleProperties.isDemoActive());
        assertFalse(demoActive);
    }
}
