package fr.ag2rlamondiale.trm.csv;

import fr.ag2rlamondiale.trm.domain.csv.LabelOffreCom;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import org.junit.Test;

import java.util.Locale;

import static org.junit.Assert.*;

public class AllCsvMapperTest {
    private class Testing extends AbstractCsvMapper<LabelOffreCom> {
        public Testing() {
            super("Inexistant");
        }
    }

    @Test(expected = TechnicalRuntimeException.class)
    public void fileNotExisting() {
        new Testing();
    }

    @Test
    public void civiliteMapperTest() {
        CiviliteMapper civ = new CiviliteMapper();
        assertEquals("Maitre", civ.getValueFR("ME"));
    }

    @Test
    public void departementTypeTest() {
        // Arrays.asList(DepartementType.values());
        assertEquals("AIN", DepartementType.AIN.getLibelle());
        assertEquals("01 - AIN", DepartementType.AIN.getCodeEtLibelle());
        assertEquals("FRANCE", DepartementType.FRANCE.getCodeEtLibelle());
        assertNull(DepartementType.getDepartementByCodeInsee(null));
        assertEquals(DepartementType.AIN, DepartementType.getDepartementByCodeInsee("01"));
        assertEquals(DepartementType.MAYOTTE, DepartementType.getDepartementByCodeInsee("985"));
        assertEquals(114, DepartementType.getAllElementsIncludingNull().size());
    }

    @Test
    public void etatAssureMapperTest() {
        String codeSituationAffiliationSilo = "C";
        EtatAssureMapper.Key key = new EtatAssureMapper.Key(codeSituationAffiliationSilo, Locale.FRANCE.getCountry());
        assertEquals(codeSituationAffiliationSilo, key.getCode());
        assertEquals(Locale.FRANCE.getCountry(), key.getLang());
        // Test Constructor
        new EtatAssureMapper();
    }

    @Test
    public void etatCompteCsvMapperTest() {
        EtatCompteCsvMapper.Key key = new EtatCompteCsvMapper.Key("E", Locale.FRANCE.getCountry());
        assertEquals("E", key.getCode());
        // Test Constructor
        new EtatCompteCsvMapper();
    }

    @Test
    public void fractionnementMapperTest() {
        FractionnementMapper.Key key = new FractionnementMapper.Key("M", Locale.FRANCE.getCountry());
        assertEquals("M", key.getCode());
        // Test Constructor
        new FractionnementMapper();
    }


    @Test
    public void limiteAgeVIFMapperTest() {
        LimiteAgeVIFMapper limite = new LimiteAgeVIFMapper();
        assertEquals(Integer.valueOf("73"), limite.getAgeLimite("M"));
    }

    @Test
    public void optionRenteLabelMapperTest() {
        String codeOptionRente = "DEC";
        OptionRenteLabelMapper.Key key = new OptionRenteLabelMapper.Key(codeOptionRente, Locale.FRANCE.getCountry());

        assertEquals("DEC", key.getCode());
        assertEquals("FR", key.getLang());
        // Test Constructor
        new OptionRenteLabelMapper();
    }

    @Test
    public void paysMapperTest() {
        PaysMapper mapper = new PaysMapper();
        assertFalse(mapper.isPaysEtranger("FRA"));
        assertTrue(mapper.isPaysEtranger("DNK"));
        assertFalse(mapper.isPaysEtranger(null));
        PaysMapper.Key key = mapper.getKeyFromValue("FRANCE");
        assertNull(mapper.getCodeFromLabel(null));
        assertEquals("FRA", mapper.getIso("0"));
        assertNull(mapper.getIso("200000"));
        assertEquals("000", mapper.getCodeFromLabel("FRANCE"));
        assertEquals(216, mapper.getLabels().size());
        assertEquals("FRANCE", mapper.getLabelPays(key));
        assertNull(mapper.getLabelPays(null));

        PaysMapper.Pays pays = new PaysMapper.Pays("UTOPIA", "10000");
        mapper.getKeyFromValue(pays);
    }
}
