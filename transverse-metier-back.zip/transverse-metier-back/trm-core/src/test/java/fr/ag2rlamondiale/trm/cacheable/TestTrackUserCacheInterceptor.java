package fr.ag2rlamondiale.trm.cacheable;

import fr.ag2rlamondiale.trm.async.AsyncMethodInterceptorTest;
import fr.ag2rlamondiale.trm.cache.*;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import fr.ag2rlamondiale.trm.utils.TimestampObject;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.cache.jcache.JCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.net.URI;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.*;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@EnableCaching
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = TestTrackUserCacheInterceptor.class)
public class TestTrackUserCacheInterceptor {

    public static final String IDGDI = "IDGDI";
    public static final String IDGDICIBLE = "IDGDICIBLE";

    @Value("classpath:ehcache.xml")
    URI ehcacheConfig;

    @Autowired
    PseudoServiceConcurrent pseudoServiceConcurrent;

    @Autowired
    CacheManager cacheManager;

    @Autowired
    ITrackUserCache trackUserCache;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Primary
    @Bean("ehCacheManager")
    public JCacheCacheManager cacheManager() {
        JCacheCacheManager cacheCacheManager = new JCacheCacheManager();
        final JCacheManagerFactoryBean factory = new JCacheManagerFactoryBean();
        factory.setCacheManagerUri(ehcacheConfig);
        factory.afterPropertiesSet();
        cacheCacheManager.setCacheManager(factory.getObject());
        return cacheCacheManager;
    }

    @Bean(CacheConstants.DEFAULT_KEY_GENERATOR)
    public KeyGenerator defaulKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }

    @Bean(CacheConstants.SIMPLE_KEY_GENERATOR)
    public KeyGenerator simpleKeyGenerator() {
        return new ParamsKeyGenerator();
    }

    @Bean
    public IQueryCache queryCache() {
        return new QueryCacheImpl();
    }

    @Bean(CacheConstants.RUNTIME_CACHE_RESOLVER)
    public CacheResolver runtimeCacheResolver() {
        return new RuntimeCacheResolver();
    }

    @Bean
    public ConcurrentCacheInterceptor concurrentCacheInterceptor() {
        return new ConcurrentCacheInterceptor();
    }

    @Bean
    public TrackUserCacheInterceptor trackUserCacheInterceptor() {
        return new TrackUserCacheInterceptor();
    }

    @Bean
    public ITrackUserCache trackUserCache() {
        return new TrackUserCacheImpl();
    }

    @Bean
    public PseudoServiceConcurrent pseudoService() {
        return new PseudoServiceConcurrent();
    }

    @Before
    public void prepare() {
        clearStandardCache();
        ((ClearableCache) trackUserCache).clearCache();
        AsyncMethodInterceptorTest.initSecurityContext(IDGDI);
        for (int i = 0; i < 20; i++) {
            RequetePersonnePhysique critere = new RequetePersonnePhysique();
            critere.setIdGDI("" + i);
            PersonnePhysique pp = new PersonnePhysique();
            pp.setIdGdi("" + i);
            pp.setNom("NOM" + i);
            pp.setPrenom("PRENOM" + i);
            pp.setNumeroPersonneEre("NUMERE" + i);
            pp.setNumeroPersonneMdpro("NUMMDPRO" + i);
            pseudoServiceConcurrent.put(critere, pp);
        }
    }

    private void clearStandardCache() {
        final Collection<String> cacheNames = cacheManager.getCacheNames();
        for (String cacheName : cacheNames) {
            final Cache cache = cacheManager.getCache(cacheName);
            log.info("Clear cache {}", cacheName);
            if (cache != null) {
                cache.clear();
            }
        }
    }

//    @Test
//    public void testRechercheSoapCache() throws Exception {
//        for (int i = 0; i < 20; i++) {
//
//            pseudoServiceConcurrent.resetSansCache();
//            for (int j = 0; j < 5; j++) {
//                RequetePersonnePhysique critere = new RequetePersonnePhysique();
//                critere.setIdGDI("" + i);
//
//                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheSoapCache(critere);
//                log.info("RES = {}", pp);
//                if(i == 0) {
//                    assertEquals(1, pseudoServiceConcurrent.getCounter().get());
//                }
//            }
//        }
//    }


    @Test
    public void testRechercheCache() throws Exception {
        for (int i = 0; i < 20; i++) {

            for (int j = 0; j < 5; j++) {
                pseudoServiceConcurrent.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                if (j == 2) {
                    pseudoServiceConcurrent.evictRechercheCache(critere);
                }
                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheCache(critere);
                log.info("RES[{}] = {}", j, pp);
                assertEquals(j == 0 || j == 2, pseudoServiceConcurrent.isSansCache());
            }
        }

        ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>> userCacheEntries = userCacheEntries();
        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> entries = userCacheEntries.get(IDGDI);
        assertEquals(20, entries.getObject().size());

        trackUserCache.migrateTrackUserCache(IDGDI, IDGDICIBLE);
        assertNull(userCacheEntries.get(IDGDI));
        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> entriesCibles = userCacheEntries.get(IDGDICIBLE);
        assertEquals(20, entriesCibles.getObject().size());
    }

    public ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>> userCacheEntries() {
        return (ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>>) ReflectionTestUtils.getField(trackUserCache, "userCacheEntries");
    }

    @Test
    @Ignore("Ce test ne passe pas sur Jenkins sur la release/2 - raison inconnue pour le moment")
    public void testRechercheCache_MT() {
        final ExecutorService executorService = Executors.newFixedThreadPool(4);
        List<Future<?>> futures = new ArrayList<>();
        ConcurrentMap<Integer, Integer> sansCacheCounter = new ConcurrentHashMap<>();
        synchronized (executorService) {
            pseudoServiceConcurrent.resetSansCache();


            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < 5; j++) {
                    int finalJ = j;
                    int finalI = i;
                    final Future<?> future = executorService.submit(() -> {
                        synchronized (executorService) {
                        }
                        RequetePersonnePhysique critere = new RequetePersonnePhysique();
                        critere.setIdGDI("" + finalI);

                        final PersonnePhysique pp = pseudoServiceConcurrent.rechercheSoapCache(critere);

                        log.info("RES[{}] = {}", finalJ, pp);
                        sansCacheCounter.put(finalI, pseudoServiceConcurrent.getCounterByCritere().get(critere).get());
                    });

                    futures.add(future);
                }
            }
        }

        futures.forEach(future -> {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                fail();
            }
        });

        sansCacheCounter.forEach((i, counter) -> assertEquals(1, (int) counter));

        ConcurrentMap<String, TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>>> userCacheEntries = userCacheEntries();
        final TimestampObject<ConcurrentMap<UserCacheEntry, Boolean>> entries = userCacheEntries.get(IDGDI);
        assertEquals(20, entries.getObject().size());
    }

    @Test
    public void testRechercheOther() throws Exception {
        // le cache otherCache n'est pas configuré dans le fichier ehcache.xml/dans la config
        thrown.expect(IllegalArgumentException.class);
        for (int i = 0; i < 20; i++) {

            for (int j = 0; j < 5; j++) {
                pseudoServiceConcurrent.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheOtherCache(critere);
                log.info("RES[{}] = {}", j, pp);
                assertEquals(j == 0, pseudoServiceConcurrent.isSansCache());
            }
        }
    }

}
