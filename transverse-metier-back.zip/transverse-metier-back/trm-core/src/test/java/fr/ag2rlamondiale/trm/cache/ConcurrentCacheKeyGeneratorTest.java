package fr.ag2rlamondiale.trm.cache;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.interceptor.SimpleKey;

import java.lang.reflect.Method;

import static org.junit.Assert.*;

@Slf4j
public class ConcurrentCacheKeyGeneratorTest {

    private ConcurrentCacheKeyGenerator keyGenerator = new ConcurrentCacheKeyGenerator();

    @Test
    public void test_methode1() throws Exception {
        Method m1 = getClass().getDeclaredMethod("methode1", String.class);
        final Object key = keyGenerator.generate(m1, "123");
        final Object key2 = keyGenerator.generate(m1, "123");
        assertTrue(key instanceof SimpleKey);
        assertTrue(key2 instanceof SimpleKey);
        assertEquals(key, key2);

        Method cacheEvictM1 = getClass().getDeclaredMethod("cacheEvictMethode1", String.class);
        try {
            final Object key3 = keyGenerator.generate(cacheEvictM1, "123");
            fail("Dans ce cas on ne peut pas retrouver la clé de cache à partir de CacheEvict");
        } catch (IllegalArgumentException e) {
            log.error("{}", e.toString());
        }
    }

    @Test
    public void test_methode2() throws Exception {
        Method m2 = getClass().getDeclaredMethod("methode2", String.class, String.class);
        final Object key = keyGenerator.generate(m2, "123", "456");
        final Object key2 = keyGenerator.generate(m2, "123", "456");
        assertTrue(key instanceof SimpleKey);
        assertTrue(key2 instanceof SimpleKey);
        assertEquals(key2, key2);

        Method cacheEvictM2 = getClass().getDeclaredMethod("cacheEvictMethode2", String.class, String.class);
        final Object key3 = keyGenerator.generate(cacheEvictM2, "123", "456");
        assertEquals(key, key3);
    }

    @Test
    public void test_methode3() throws Exception {
        Method m3 = getClass().getDeclaredMethod("methode3");
        final Object key = keyGenerator.generate(m3);
        final Object key2 = keyGenerator.generate(m3);
        assertEquals(key2, key2);

        Method cacheEvictM3 = getClass().getDeclaredMethod("cacheEvictMethode3");
        final Object key3 = keyGenerator.generate(cacheEvictM3);
        assertEquals(key, key3);
    }

    @Test
    public void test_methode4() throws Exception {
        Method m4 = getClass().getDeclaredMethod("methode4");
        final Object key = keyGenerator.generate(m4);
        final Object key2 = keyGenerator.generate(m4);
        assertEquals(key2, key2);

        Method cacheEvictM4 = getClass().getDeclaredMethod("cacheEvictMethode4");
        final Object key3 = keyGenerator.generate(cacheEvictM4);
        assertEquals(key, key3);
    }

    @Test
    public void test_methode5() throws Exception {
        Method m5 = getClass().getDeclaredMethod("methode5", String.class);
        final Object key = keyGenerator.generate(m5, "123");
        final Object key2 = keyGenerator.generate(m5, "123");
        assertEquals(key2, key2);

        Method cacheEvictM5 = getClass().getDeclaredMethod("cacheEvictMethode5", String.class);
        final Object key3 = keyGenerator.generate(cacheEvictM5, "123");
        assertEquals(key, key3);
    }

    @Cacheable("soapCache")
    public String methode1(String x) {
        return "methode1 : " + x;
    }

    @CacheEvict("soapCache")
    public void cacheEvictMethode1(String x) {
    }

    @Cacheable(cacheNames = "methode2", keyGenerator = "specialKeyGen")
    public String methode2(String x, String y) {
        return "methode2 : " + x + ", " + y;
    }

    @CacheEvict(cacheNames = "methode2", keyGenerator = "specialKeyGen")
    public void cacheEvictMethode2(String x, String y) {

    }

    @Cacheable(cacheNames = "methode3", keyGenerator = "specialKeyGen")
    public String methode3() {
        return "methode3 : ";
    }

    @CacheEvict(cacheNames = "methode3", keyGenerator = "specialKeyGen")
    public void cacheEvictMethode3() {

    }

    @Cacheable(keyGenerator = "specialKeyGen")
    public String methode4() {
        return "methode4 : ";
    }

    @CacheEvict(keyGenerator = "specialKeyGen")
    public void cacheEvictMethode4() {

    }

    @Cacheable(cacheNames = {"a", "b"}, keyGenerator = "specialKeyGen")
    public String methode5(String x) {
        return "methode5 : " + x;
    }

    @CacheEvict(cacheNames = {"a", "b"}, keyGenerator = "specialKeyGen")
    public void cacheEvictMethode5(String x) {

    }
}
