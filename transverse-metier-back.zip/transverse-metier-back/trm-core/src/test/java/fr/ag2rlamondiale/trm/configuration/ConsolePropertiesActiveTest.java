package fr.ag2rlamondiale.trm.configuration;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

@PropertySource("classpath:/console-properties-active.properties")
@ContextConfiguration(classes = ConsolePropertiesActiveTest.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class ConsolePropertiesActiveTest {

    @Value("#{consoleProps.demoActive}")
    private Boolean demoActive;

    @Value("#{consoleProps.consoleV2Active}")
    private Boolean consoleV2Active;

    @Value("#{consoleProps.consoleV2ApiUrl}")
    private String consoleV2ApiUrl;

    @Autowired
    ConsoleProperties consoleProperties;

    @Bean("consoleProps")
    ConsoleProperties consoleProperties() {
        return new ConsoleProperties();
    }

    @Test
    public void test_active() throws Exception {
        assertTrue(consoleProperties.isConsoleV2Active());
        assertFalse(consoleProperties.isDemoActive());
        assertTrue(consoleV2Active);
        assertEquals("http://consolev2", consoleV2ApiUrl);
    }
}
