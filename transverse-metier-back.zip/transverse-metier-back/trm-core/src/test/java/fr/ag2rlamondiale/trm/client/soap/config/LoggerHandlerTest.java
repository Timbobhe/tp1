/*
 * Cree le 27 sept. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.soap.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.soap.*;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test de la classe LoggerHandler
 */
@RunWith(MockitoJUnitRunner.class)
public class LoggerHandlerTest {
    @Spy
    LoggerHandler handler;

    @Test
    public void testHandler() throws Exception {
        String myMessageId = "MyMessageID1";
        Node messageIdNode = mock(Node.class);
        when(messageIdNode.getLocalName()).thenReturn("MessageID");
        when(messageIdNode.getValue()).thenReturn(myMessageId);
        ArrayList<Node> headers = new ArrayList<>();
        headers.add(messageIdNode);
        SOAPMessageContext context = mock(SOAPMessageContext.class, RETURNS_DEEP_STUBS);
        when(context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(Boolean.TRUE);
        when(context.getMessage().getSOAPPart().getEnvelope().getHeader()
                .examineAllHeaderElements()).thenAnswer(i -> headers.iterator());
        handler.handleMessage(context);
        Assert.assertTrue(myMessageId != null);
    }

    @Test
    public void testHandleFault() throws Exception {
        String myMessageId = "MyMessageID1";
        Node messageIdNode = mock(Node.class);
        when(messageIdNode.getLocalName()).thenReturn("MessageID");
        when(messageIdNode.getValue()).thenReturn(myMessageId);
        ArrayList<Node> headers = new ArrayList<>();
        headers.add(messageIdNode);
        SOAPMessageContext context = mock(SOAPMessageContext.class, RETURNS_DEEP_STUBS);
        when(context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(Boolean.TRUE);
        when(context.getMessage().getSOAPPart().getEnvelope().getHeader()
                .examineAllHeaderElements()).thenAnswer(i -> headers.iterator());
        handler.handleFault(context);
        Assert.assertTrue(myMessageId != null);
    }

    @Test
    public void testHandleFaultSOAPException() throws Exception {
        String myMessageId = "MyMessageID1";
        Node messageIdNode = mock(Node.class);
        when(messageIdNode.getLocalName()).thenReturn("MessageID");
        when(messageIdNode.getValue()).thenReturn(myMessageId);
        ArrayList<Node> headers = new ArrayList<>();
        headers.add(messageIdNode);
        SOAPMessageContext context = mock(SOAPMessageContext.class, RETURNS_DEEP_STUBS);
        SOAPMessage msg = mock(SOAPMessage.class);
        SOAPPart part = mock(SOAPPart.class);
        SOAPEnvelope envelope = mock(SOAPEnvelope.class);
        SOAPHeader header = mock(SOAPHeader.class);
        when(context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(Boolean.TRUE);
        when(context.getMessage()).thenReturn(msg);
        when(msg.getSOAPPart()).thenReturn(part);
        when(part.getEnvelope()).thenReturn(envelope);
        when(envelope.getHeader()).thenReturn(header);
        when(header.examineAllHeaderElements()).thenAnswer(i -> headers.iterator());
        doThrow(SOAPException.class).when(msg).writeTo(any(OutputStream.class));
        handler.handleFault(context);
        Assert.assertTrue(myMessageId != null);
    }

    @Test
    public void testHandleFaultIOException() throws Exception {
        String myMessageId = "MyMessageID1";
        Node messageIdNode = mock(Node.class);
        when(messageIdNode.getLocalName()).thenReturn("MessageID");
        when(messageIdNode.getValue()).thenReturn(myMessageId);
        ArrayList<Node> headers = new ArrayList<>();
        headers.add(messageIdNode);
        SOAPMessageContext context = mock(SOAPMessageContext.class, RETURNS_DEEP_STUBS);
        SOAPMessage msg = mock(SOAPMessage.class);
        SOAPPart part = mock(SOAPPart.class);
        SOAPEnvelope envelope = mock(SOAPEnvelope.class);
        SOAPHeader header = mock(SOAPHeader.class);
        when(context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(Boolean.TRUE);
        when(context.getMessage()).thenReturn(msg);
        when(msg.getSOAPPart()).thenReturn(part);
        when(part.getEnvelope()).thenReturn(envelope);
        when(envelope.getHeader()).thenReturn(header);
        when(header.examineAllHeaderElements()).thenAnswer(i -> headers.iterator());
        doThrow(IOException.class).when(msg).writeTo(any(OutputStream.class));
        handler.handleFault(context);
        handler.getHeaders();
        Assert.assertTrue(myMessageId != null);
    }

    @Test
    public void testHandleFaultException() throws Exception {
        String myMessageId = "MyMessageID1";
        Node messageIdNode = mock(Node.class);
        when(messageIdNode.getLocalName()).thenReturn("MessageID");
        when(messageIdNode.getValue()).thenReturn(myMessageId);
        ArrayList<Node> headers = new ArrayList<>();
        headers.add(messageIdNode);
        SOAPMessageContext context = mock(SOAPMessageContext.class, RETURNS_DEEP_STUBS);
        SOAPMessage msg = mock(SOAPMessage.class);
        SOAPPart part = mock(SOAPPart.class);
        SOAPEnvelope envelope = mock(SOAPEnvelope.class);
        SOAPHeader header = mock(SOAPHeader.class);
        when(context.get(SOAPMessageContext.MESSAGE_OUTBOUND_PROPERTY)).thenReturn(Boolean.TRUE);
        when(context.getMessage()).thenReturn(msg);
        when(msg.getSOAPPart()).thenReturn(part);
        when(part.getEnvelope()).thenReturn(envelope);
        when(envelope.getHeader()).thenReturn(header);
        when(header.examineAllHeaderElements()).thenAnswer(i -> headers.iterator());
        doThrow(Exception.class).when(msg).writeTo(any(OutputStream.class));
        handler.handleFault(context);
        Assert.assertTrue(myMessageId != null);
    }
}
