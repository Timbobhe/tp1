package fr.ag2rlamondiale.trm.demo;

import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.soap.PortInitializer;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CompteDemoEndpointResolverTest {

    private final static String MOCKDATA = "MockedData";

    @Mock
    private UserContextHolder userContextHolder;

    @InjectMocks
    CompteDemoEndpointResolver compteDemoEndpointResolver;

    @Before
    public void setUp() throws Exception {
        compteDemoEndpointResolver.setDemoActive(true);
        compteDemoEndpointResolver.setPrefixUrlDemoApiConsole("http://console-v2/api/unsecure/demo");
    }

    @Test
    public void test_getUrl_SansCompteDemo() throws Exception {
        PortInitializer portInitializer = mock(PortInitializer.class);
        when(portInitializer.serviceId()).thenReturn("GestMandat_1/RechercherMandat_1");

        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA, false, null));
        String url = compteDemoEndpointResolver.getUrl(portInitializer);
        assertNull(url);
    }

    @Test
    public void test_getUrl_AvecCompteDemo() throws Exception {
        PortInitializer portInitializer = mock(PortInitializer.class);
        when(portInitializer.serviceId()).thenReturn("GestMandat_1/RechercherMandat_1");

        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA, false, new CompteDemo(1)));
        String url = compteDemoEndpointResolver.getUrl(portInitializer);
        assertEquals("http://console-v2/api/unsecure/demo/GestMandat_1/RechercherMandat_1?cdm=1", url);
    }


    @Test
    public void test_getUrl_AvecDemoInactive() throws Exception {
        compteDemoEndpointResolver.setDemoActive(false);
        PortInitializer portInitializer = mock(PortInitializer.class);
        when(portInitializer.serviceId()).thenReturn("GestMandat_1/RechercherMandat_1");

        when(userContextHolder.get()).thenReturn(createUserContext(MOCKDATA, false, new CompteDemo(1)));
        String url = compteDemoEndpointResolver.getUrl(portInitializer);
        assertNull(url);
    }

    @Test(expected = IllegalStateException.class)
    public void test_config_active() throws Exception {
        compteDemoEndpointResolver.setDemoActive(true);
        compteDemoEndpointResolver.setPrefixUrlDemoApiConsole(null);
        compteDemoEndpointResolver.afterPropertiesSet();
    }

    @Test
    public void test_config_inactive() throws Exception {
        compteDemoEndpointResolver.setDemoActive(false);
        compteDemoEndpointResolver.setPrefixUrlDemoApiConsole(null);
        compteDemoEndpointResolver.afterPropertiesSet();
        assertNull(compteDemoEndpointResolver.getPrefixUrlDemoApiConsole());
    }

    private UserContext createUserContext(String numPP, boolean nie, CompteDemo compteDemo) {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneEre(numPP);
        if (nie) {
            Partenaire partenaire = new Partenaire();
            partenaire.setCodePartenaire("49505");
            userContext.setPartenaire(partenaire);
        }
        userContext.setCompteDemo(compteDemo);
        return userContext;
    }
}
