package fr.ag2rlamondiale.trm.rest;

import fr.ag2rlamondiale.trm.rest.auth.PfsTokenBuilder;
import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestService;
import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.util.StringValueResolver;

import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class PfsTokenBuilderTest {

    @Mock
    StringValueResolver stringValueResolver;

    PropertyResolver propertyResolver = new PropertyResolver();

    @InjectMocks
    PfsTokenBuilder pfsTokenBuilder;

    @Before
    public void setUp() {
        propertyResolver.setEmbeddedValueResolver(stringValueResolver);
        pfsTokenBuilder.setPropertyResolver(propertyResolver);
        pfsTokenBuilder.setPrivateKeyName("private-key");
    }

    @Test
    public void test_findToken() throws Exception {
        when(stringValueResolver.resolveStringValue(any())).thenAnswer(invocation -> {
            final Object string = invocation.getArguments()[0];
            if ("${pfs.GestHabili_1.RechercherHabiliPers_1.token}".equals(string)) {
                return "123";
            }
            if ("${pfs.consulterContratTechnique.token}".equals(string)) {
                return "456";
            }

            return string;
        });
        PfsRestService pfsRestService = getClass().getMethod("pfsRestServiceAnno").getAnnotation(PfsRestService.class);
        final String token = pfsTokenBuilder.findToken(PfsRestServiceConfig.from(pfsRestService));
        assertEquals("123", token);


        PfsRestService pfsRestService2 = getClass().getMethod("pfsRestServiceAnno2").getAnnotation(PfsRestService.class);
        final String token2 = pfsTokenBuilder.findToken(PfsRestServiceConfig.from(pfsRestService2));
        assertEquals("private-key", token2);

        PfsRestService pfsRestService3 = getClass().getMethod("pfsRestServiceAnno3").getAnnotation(PfsRestService.class);
        final String token3 = pfsTokenBuilder.findToken(PfsRestServiceConfig.from(pfsRestService3));
        assertEquals("456", token3);
    }

    @PfsRestService(serviceId = "GestHabili_1/RechercherHabiliPers_1")
    public void pfsRestServiceAnno() {

    }

    @PfsRestService(serviceId = "ContratConsult_3/ConsulterContratTechniques_1")
    public void pfsRestServiceAnno2() {

    }

    @PfsRestService(serviceId = "ContratConsult_3/ConsulterContratTechniques_1", alternativeAccessToken = "${pfs.consulterContratTechnique.token}")
    public void pfsRestServiceAnno3() {

    }

}
