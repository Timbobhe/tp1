package fr.ag2rlamondiale.trm.cacheable;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import fr.ag2rlamondiale.trm.cache.*;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheResolver;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.cache.jcache.JCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@EnableCaching(order = InterceptorOrders.DEFAULT_CACHEABLE_ORDER)
@EnableAspectJAutoProxy
@EnableAsync
@ContextConfiguration(classes = TestConcurrentCacheInterceptor.class)
public class TestConcurrentCacheInterceptor {

    @Value("classpath:ehcache.xml")
    URI ehcacheConfig;

    @Autowired
    PseudoServiceConcurrent pseudoServiceConcurrent;

    @Autowired
    ConcurrentCacheInterceptor concurrentCacheInterceptor;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Primary
    @Bean("ehCacheManager")
    public JCacheCacheManager cacheManager() {
        JCacheCacheManager cacheCacheManager = new JCacheCacheManager();
        final JCacheManagerFactoryBean factory = new JCacheManagerFactoryBean();
        factory.setCacheManagerUri(ehcacheConfig);
        factory.afterPropertiesSet();
        cacheCacheManager.setCacheManager(factory.getObject());
        return cacheCacheManager;
    }

    @Bean(CacheConstants.DEFAULT_KEY_GENERATOR)
    public KeyGenerator defaulKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }

    @Bean(CacheConstants.SIMPLE_KEY_GENERATOR)
    public KeyGenerator simpleKeyGenerator() {
        return new ParamsKeyGenerator();
    }

    @Bean
    public IQueryCache queryCache() {
        return new QueryCacheImpl();
    }

    @Bean(CacheConstants.RUNTIME_CACHE_RESOLVER)
    public CacheResolver runtimeCacheResolver() {
        return new RuntimeCacheResolver();
    }

    @Bean
    public ConcurrentCacheInterceptor concurrentCacheInterceptor() {
        return new ConcurrentCacheInterceptor();
    }

    @Bean
    public ITrackUserCache trackUserCache() {
        return new TrackUserCacheImpl();
    }

    @Bean
    public PseudoServiceConcurrent pseudoService() {
        return new PseudoServiceConcurrent();
    }

    @Before
    public void prepare() {
        for (int i = 0; i < 20; i++) {
            RequetePersonnePhysique critere = new RequetePersonnePhysique();
            critere.setIdGDI("" + i);
            PersonnePhysique pp = new PersonnePhysique();
            pp.setIdGdi("" + i);
            pp.setNom("NOM" + i);
            pp.setPrenom("PRENOM" + i);
            pp.setNumeroPersonneEre("NUMERE" + i);
            pp.setNumeroPersonneMdpro("NUMMDPRO" + i);
            pseudoServiceConcurrent.put(critere, pp);
        }
    }

//    @Test
//    public void testRechercheSoapCache() throws Exception {
//        for (int i = 0; i < 20; i++) {
//
//            pseudoServiceConcurrent.resetSansCache();
//            for (int j = 0; j < 5; j++) {
//                RequetePersonnePhysique critere = new RequetePersonnePhysique();
//                critere.setIdGDI("" + i);
//
//                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheSoapCache(critere);
//                log.info("RES = {}", pp);
//                if(i == 0) {
//                    assertEquals(1, pseudoServiceConcurrent.getCounter().get());
//                }
//            }
//        }
//    }

    @Test
    public void testRechercheCache() throws Exception {
        for (int i = 0; i < 20; i++) {

            for (int j = 0; j < 5; j++) {
                pseudoServiceConcurrent.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                if (j == 2) {
                    pseudoServiceConcurrent.evictRechercheCache(critere);
                }
                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheCache(critere);
                log.info("RES[{}] = {}", j, pp);
                assertEquals(j == 0 || j == 2, pseudoServiceConcurrent.isSansCache());
            }
        }
    }

    @Test
    public void test_orderVerify() {
        RequetePersonnePhysique critere = new RequetePersonnePhysique();
        critere.setIdGDI("" + 1);

        final PersonnePhysique pp = pseudoServiceConcurrent.rechercheSoapCache(critere);
        log.info("RES = {}", pp);

        assertNotNull(pp);
    }

    @Test
    public void testRechercheCache_MT() {
        final ExecutorService executorService = Executors.newFixedThreadPool(4);
        List<Future<?>> futures = new ArrayList<>();
        ConcurrentMap<Integer, Integer> sansCacheCounter = new ConcurrentHashMap<>();
        synchronized (executorService) {
            pseudoServiceConcurrent.resetSansCache();


            for (int i = 0; i < 20; i++) {
                for (int j = 0; j < 5; j++) {
                    int finalJ = j;
                    int finalI = i;
                    final Future<?> future = executorService.submit(() -> {
                        synchronized (executorService) {
                        }
                        RequetePersonnePhysique critere = new RequetePersonnePhysique();
                        critere.setIdGDI("" + finalI);

                        log.info("APPEL[{},{}]", finalI, finalJ);
                        final PersonnePhysique pp = pseudoServiceConcurrent.rechercheSoapCache(critere);

                        log.info("RES[{},{}] = {}", finalI, finalJ, pp);
                        sansCacheCounter.put(finalI, pseudoServiceConcurrent.getCounterByCritere().get(critere).get());
                    });

                    futures.add(future);
                }
            }
        }

        futures.forEach(future -> {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
                fail();
            }
        });

        sansCacheCounter.forEach((i, counter) -> log.info("idGdi={} => {}", i, counter));
        sansCacheCounter.forEach((i, counter) -> assertEquals("idGdi=" + i, 1, (int) counter));

        concurrentCacheInterceptor.cleanLock(true);
        assertEquals(0, concurrentCacheInterceptor.getLocksCounter());
    }

    @Test
    public void testRechercheOther() throws Exception {
        // le cache otherCache n'est pas configuré dans le fichier ehcache.xml/dans la config
        thrown.expect(IllegalArgumentException.class);
        for (int i = 0; i < 20; i++) {

            for (int j = 0; j < 5; j++) {
                pseudoServiceConcurrent.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                final PersonnePhysique pp = pseudoServiceConcurrent.rechercheOtherCache(critere);
                log.info("RES[{}] = {}", j, pp);
                assertEquals(j == 0, pseudoServiceConcurrent.isSansCache());
            }
        }
    }

}
