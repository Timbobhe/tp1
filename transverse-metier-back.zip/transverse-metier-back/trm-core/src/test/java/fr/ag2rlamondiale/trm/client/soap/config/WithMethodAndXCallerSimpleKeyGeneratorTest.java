package fr.ag2rlamondiale.trm.client.soap.config;

import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.cache.interceptor.SimpleKey;

import java.lang.reflect.Method;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WithMethodAndXCallerSimpleKeyGeneratorTest {

    @InjectMocks
    WithMethodAndXCallerSimpleKeyGenerator generator;

    @Mock
    UserContextHolder userContextHolder;

    @Test
    public void test_generate_with_partenaire() throws Exception {
        when(userContextHolder.get()).thenAnswer(invocation -> {
            UserContext u = new UserContext();
            Partenaire partenaire = new Partenaire();
            partenaire.setCodePartenaire(Partenaire.CODE_NIE);
            u.setPartenaire(partenaire);
            return u;
        });


        final Method sample = getClass().getDeclaredMethod("sample", String.class);
        final Object key = generator.generate(this, sample, "hello");
        SimpleKey expected = new SimpleKey(sample, "hello", "A1573");
        assertEquals(expected, key);
    }

    @Test
    public void test_generate_without_partenaire() throws Exception {
        when(userContextHolder.get()).thenAnswer(invocation -> new UserContext());

        final Method sample = getClass().getDeclaredMethod("sample", String.class);
        final Object key = generator.generate(this, sample, "hello");
        SimpleKey expected = new SimpleKey(sample, "hello");
        assertEquals(expected, key);
    }

    void sample(String string) {

    }
}
