package fr.ag2rlamondiale.trm.jahia;

import fr.ag2rlamondiale.trm.domain.document.DictionaryKeyType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import static fr.ag2rlamondiale.trm.jahia.MockJahiaUrlConnection.DOCUMENT_URL;

@RunWith(MockitoJUnitRunner.class)
public class JahiaFacadeImplTest {

    private static final String LOGO_URL = MockJahiaUrlConnection.LOGO_URL;

    @InjectMocks
    JahiaFacadeImpl sut;

    @Before
    public void init() throws Exception {
        sut.setProxy(sut);
        ReflectionTestUtils.setField(sut, "jahiaUrl", "http://inscription-dev/jahia7");
        ReflectionTestUtils.setField(sut, "documentUrl", DOCUMENT_URL);
        final MockJahiaUrlConnection jahiaUrlConnection = new MockJahiaUrlConnection();
        jahiaUrlConnection.put(sut.getUrl(DictionaryKeyType.CLAUSE_BENEFICIAIRE_COMMUN), "/jahia/dico/clause_beneficiaire_commun_dictionnaire_de_libelles.dico.json", 200, null);
        jahiaUrlConnection.put(sut.getUrl(DictionaryKeyType.ADRESSES_CONTRATS_PDF), "/jahia/dico/ADRESSES_CONTRATS_PDF.dico.json", 200, null);
        jahiaUrlConnection.put(new URL(DOCUMENT_URL + "BIA_en_ligne.pdf"), "/jahia/documents/BIA_en_ligne.pdf", 200, null);
        jahiaUrlConnection.put(new URL(LOGO_URL + "ARI.png"), "/trm-core/src/test/resources/jahia/images/ARI.png", 200, null);
        jahiaUrlConnection.put(new URL(LOGO_URL + "RG151095348.png"), "/trm-core/src/test/resources/jahia/images/RG151095348.png", 200, null);
        jahiaUrlConnection.put(new URL(LOGO_URL + "default.png"), "/trm-core/src/test/resources/jahia/images/default.png", 200, null);


        sut.setJahiaUrlConnection(jahiaUrlConnection);
    }

    @Test
    public void should_find_dictionary_entry_by_key() throws IOException {

        String actual = sut.findDictionaryEntry(DictionaryKeyType.CLAUSE_BENEFICIAIRE_COMMUN, "CLAUSE_BENEFICIAIRE_TITRE");

        Assert.assertNotNull(actual);
    }

    @Test
    public void should_find_dictionary_entry_by_contract() throws IOException {

        String expected = "ARIAL CNP ASSURANCES | Entreprise régie par le code des assurances | Société anonyme au capital de 10 848 004,80 € \\r\\n" +
                "Siège social : 32, avenue Emile Zola 59370 Mons-en-Baroeul | 410 241 657 RCS Lille Métropole";

        String actual = sut.findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType.ADRESSES_CONTRATS_PDF,
                "RG151650770", null);

        Assert.assertEquals(expected, actual);

    }


    @Test
    public void should_find_dictionary_entry_by_filiale() throws IOException {

        String expected = "ARIAL CNP ASSURANCES | Entreprise régie par le code des assurances | Société anonyme au " +
                "capital de 10 848 000 € Siège social : 32, avenue Emile Zola 59370 Mons-en-Baroeul | 410 241 657 RCS Lille Métropole";
        String actual = sut.findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType.ADRESSES_CONTRATS_PDF, null, "ACA");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void should_find_dictionary_entry_by_default() throws IOException {
        String expected = "ARIAL CNP ASSURANCES | Entreprise régie par le code des assurances | Société anonyme au capital de 10 848 004,80 € \\r\\n" +
                "Siège social : 32, avenue Emile Zola 59370 Mons-en-Baroeul | 410 241 657 RCS Lille Métropole";

        String actual = sut.findDictionaryEntryByNumContratOrCodeFiliale(DictionaryKeyType.ADRESSES_CONTRATS_PDF, null, null);
        Assert.assertEquals(expected, actual);
    }


    @Test
    public void should_locate_document() {
        String expected = DOCUMENT_URL + "BIA_en_ligne.pdf";
        String actual = sut.locateDocument("BIA_en_ligne", null);

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void should_retrieve_document() throws IOException {
        byte[] actual = sut.getDocument(DOCUMENT_URL + "BIA_en_ligne.pdf");

        Assert.assertNotNull(actual);
    }

    @Test
    public void should_get_logo_url_by_filiale() {
        String expected = LOGO_URL + "ARI.png";

        String actual = sut.getExistingFileName(LOGO_URL, ".png", "RG123456", "ARI");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void should_get_logo_url_by_num_contrat() {
        String expected = LOGO_URL + "RG151095348.png";

        String actual = sut.getExistingFileName(LOGO_URL, ".png", "RG151095348", "ARI");

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void should_get_default_logo_url() {
        String expected = LOGO_URL + "default.png";

        String actual = sut.getExistingFileName(LOGO_URL, ".png", "test", "test");

        Assert.assertEquals(expected, actual);
    }
}
