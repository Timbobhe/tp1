package fr.ag2rlamondiale.trm.thread;

import lombok.SneakyThrows;

public class Boom extends Exception {
    public Boom(String message) {
        super(message);
    }

    @SuppressWarnings("squid:S2925")
    @SneakyThrows
    public static void pause(long millis) {
        if (millis > 0) {
            Thread.sleep(millis);
        }
    }
}
