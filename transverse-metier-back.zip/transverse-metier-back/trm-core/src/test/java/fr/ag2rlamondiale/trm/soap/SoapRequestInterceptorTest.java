package fr.ag2rlamondiale.trm.soap;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import fr.ag2rlamondiale.trm.client.soap.config.SecurityHeaderInfo;
import fr.ag2rlamondiale.trm.client.soap.config.SoapRequestContext;
import fr.ag2rlamondiale.trm.client.soap.config.SoapRequestContextHolder;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.IWithCodeSilo;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.SecurityServiceConfig;
import org.aspectj.lang.JoinPoint;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class SoapRequestInterceptorTest {
    @InjectMocks
    SoapRequestInterceptor soapRequestInterceptor;

    UserContextHolder userContextHolder;

    @Mock
    SecurityServiceConfig securityServiceConfig;

    @Before
    public void init() {
        initUserContext(false);
        MockitoAnnotations.initMocks(this);
        SecurityHeaderInfo securityHeaderInfo = new SecurityHeaderInfo();
        when(securityServiceConfig.getSecurityHeaderInfo("mandat")).thenReturn(new SecurityHeaderInfo());
    }

    private void initUserContext(boolean supervision) {
        UserContext userContext = new UserContext();
        userContext.setIdGdi("IDGDI");
        userContext.setForSupervision(supervision);
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");

        userContextHolder = mock(UserContextHolder.class, Mockito.RETURNS_DEEP_STUBS);

        when(userContextHolder.get()).thenReturn(userContext);
    }

    @Test
    public void test_beforeAdviceWhithoutExternalSecurityHeader() throws Exception {
        JoinPoint joinPoint = mock(JoinPoint.class);
        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(false);
        when(soapRequest.externalSecurityHeader()).thenReturn("mandat");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
        assertNotNull(soapRequestContext.getSecurityHeaderInfo());
    }

    @Test
    public void test_beforeAdviceWithExternalSecurityHeader() throws Exception {
        JoinPoint joinPoint = mock(JoinPoint.class);
        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(false);
        when(soapRequest.externalSecurityHeader()).thenReturn("");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
        assertNull(soapRequestContext.getSecurityHeaderInfo());
    }

    @Test
    public void test_beforeAdvice_supervision() throws Exception {
        initUserContext(true);
        MockitoAnnotations.initMocks(this);
        JoinPoint joinPoint = mock(JoinPoint.class);
        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(false);
        when(soapRequest.externalSecurityHeader()).thenReturn("");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
    }

    @Test
    public void test_beforeAdvice_useSharepointToken() throws Exception {
        initUserContext(true);
        MockitoAnnotations.initMocks(this);
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(joinPoint.getArgs()).thenReturn(new Object[]{CodeSiloType.MDP});

        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(true);
        when(soapRequest.externalSecurityHeader()).thenReturn("");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
        assertTrue(soapRequestContext.isHasSharepointTokenMdpro());
    }

    @Test
    public void test_beforeAdvice_useSharepointToken_2() throws Exception {
        initUserContext(true);
        MockitoAnnotations.initMocks(this);
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(joinPoint.getArgs()).thenReturn(new Object[]{(IWithCodeSilo) () -> CodeSiloType.ERE});

        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(true);
        when(soapRequest.externalSecurityHeader()).thenReturn("");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
        assertTrue(soapRequestContext.isHasSharepointTokenEre());
    }

    @Test
    public void test_beforeAdvice_useSharepointToken_3() throws Exception {
        initUserContext(true);
        MockitoAnnotations.initMocks(this);
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(joinPoint.getArgs()).thenReturn(new Object[]{12});

        SoapRequest soapRequest = mock(SoapRequest.class);
        when(soapRequest.connectedRequest()).thenReturn(true);
        when(soapRequest.useSharepointToken()).thenReturn(true);
        when(soapRequest.externalSecurityHeader()).thenReturn("");

        soapRequestInterceptor.beforeAdvice(joinPoint, soapRequest);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertEquals("IDGDI", soapRequestContext.getIdGdi());
        assertFalse(soapRequestContext.isHasSharepointTokenEre());
        assertFalse(soapRequestContext.isHasSharepointTokenMdpro());
    }

    @Test
    public void test_order() throws Exception {
        Assert.assertEquals(InterceptorOrders.PREPARE_SOAP_REQUEST_ORDER, soapRequestInterceptor.getOrder());
    }

    @Test
    public void test_afterAdvice() throws Exception {
        soapRequestInterceptor.afterAdvice(null, null);
        final SoapRequestContext soapRequestContext = SoapRequestContextHolder.get();
        assertNull(soapRequestContext);

    }

}
