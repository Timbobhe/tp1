package fr.ag2rlamondiale.trm.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@Configuration
@EnableAspectJAutoProxy
@ContextConfiguration(classes = LogAspectTest.class)
public class LogAspectTest {

    @Autowired
    ServiceTest serviceTest;

    @Test
    public void test_logTime() throws Exception {
        assertTrue(serviceTest.doSomething());
    }


    @Test(expected = RuntimeException.class)
    public void test_logError() throws Exception {
        serviceTest.boom();
    }


    static class ServiceTest {

        @SuppressWarnings("WeakerAccess")
        @LogExecutionTime
        public boolean doSomething() {
            System.out.println("doSomething");
            return true;
        }

        @LogError(category = "TEST")
        public void boom() {
            throw new RuntimeException("Boom", new RuntimeException("Root cause : Boom"));
        }

    }

    @Bean
    LogExecutionTimeInterceptor logExecutionTimeInterceptor() {
        return new LogExecutionTimeInterceptor();
    }

    @Bean
    LogErrorInterceptor logErrorInterceptor() {
        return new LogErrorInterceptor();
    }

    @Bean
    ServiceTest serviceTest() {
        return new ServiceTest();
    }
}
