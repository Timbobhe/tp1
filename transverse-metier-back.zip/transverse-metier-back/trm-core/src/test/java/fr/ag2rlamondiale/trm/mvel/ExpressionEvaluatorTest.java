package fr.ag2rlamondiale.trm.mvel;

import org.junit.Test;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

public class ExpressionEvaluatorTest {
    private ExpressionEvaluator evaluator = new ExpressionEvaluator();

    @Test
    public void eval_true() {
        final String condition = "!( (liste_num_contrat contains $ in ['RGXXXXXXXXX',' RG151218732','RG150025438','RG151887159','RG151887256','RG151970288','RG152080189']) contains true )";
        Map<String, Object> context = new HashMap<>();
        context.put("liste_num_contrat", "");
        final boolean res = evaluator.eval(condition, context);
        assertTrue(res);
    }

    @Test
    public void eval_false() {
        final String condition = "!( (liste_num_contrat contains $ in ['RGXXXXXXXXX',' RG151218732','RG150025438','RG151887159','RG151887256','RG151970288','RG152080189']) contains true )";
        Map<String, Object> context = new HashMap<>();
        context.put("liste_num_contrat", Collections.singletonList("RG150025438"));
        final boolean res = evaluator.eval(condition, context);
        assertFalse(res);
    }
}
