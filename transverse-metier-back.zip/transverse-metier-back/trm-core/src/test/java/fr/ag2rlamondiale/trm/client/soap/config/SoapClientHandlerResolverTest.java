/*
 * Cree le 11 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.soap.config;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.xml.ws.handler.Handler;
import javax.xml.ws.handler.PortInfo;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

@SuppressWarnings("rawtypes")
@RunWith(MockitoJUnitRunner.class)
public class SoapClientHandlerResolverTest {
    @InjectMocks
    SoapClientHandlerResolver handlerResolver;


    @Test
    public void testHandlerResolver() throws Exception {
        Handler handler = mock(Handler.class);
        handlerResolver.addHandler(handler);
        PortInfo portInfo = mock(PortInfo.class);
        List<Handler> liste = handlerResolver.getHandlerChain(portInfo);
        Assert.assertTrue(!liste.isEmpty());
    }
    
    @Test
    public void testSoapClientHandlerResolverFactory() {
    	SoapClientHandlerResolverFactory f = new SoapClientHandlerResolverFactory();
    	assertNull(f.createSoapClientHandlerResolver());
    }
}
