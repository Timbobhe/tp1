package fr.ag2rlamondiale.trm.thread;

import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.task.AsyncTaskExecutor;

import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import static fr.ag2rlamondiale.trm.thread.Boom.pause;
import static org.junit.Assert.*;

@Slf4j
public abstract class AbstractExecutorTest {

    public static final int PAUSE_MILLIS = 500;
    public static final int LONG_PAUSE_MILLIS = PAUSE_MILLIS * 5;
    public static final int TIMEOUT_EXCEEDED_MILLIS = PAUSE_MILLIS / 2;
    public static final int TIMEOUT_NOT_EXCEEDED_MILLIS = PAUSE_MILLIS * 2;

    AsyncTaskExecutor executor;

    final UserContextHolder userContextHolder = new UserContextHolder();

    @Before
    public abstract void setUp();

    @Test
    public void execute_nominal() throws InterruptedException {
        AtomicBoolean terminated = new AtomicBoolean(false);
        final Object waiter = new Object();
        synchronized (waiter) {
            executor.execute(() -> {
                synchronized (waiter) {
                    log.info("Start task");
                    pause(PAUSE_MILLIS);
                    log.info("End task");
                    terminated.set(true);
                    waiter.notify();
                }
            });

            waiter.wait();
        }
        assertTrue(terminated.get());
    }

    @Test
    public void testExecute_nominal() throws InterruptedException {
        AtomicBoolean terminated = new AtomicBoolean(false);
        final Object waiter = new Object();
        synchronized (waiter) {
            executor.execute(() -> {
                synchronized (waiter) {
                    log.info("Start task");
                    pause(PAUSE_MILLIS);
                    log.info("End task");
                    terminated.set(true);
                    waiter.notify();
                }
            }, 10);

            waiter.wait();
        }
        assertTrue(terminated.get());
    }

    @Test
    public void submit_nominal() throws ExecutionException, InterruptedException {
        AtomicBoolean terminated = new AtomicBoolean(false);
        final Future<?> future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            terminated.set(true);
        });

        future.get();
        assertTrue(future.isDone());
        assertFalse(future.isCancelled());
        assertTrue(terminated.get());
    }

    @Test
    public void testSubmit_nominal() throws ExecutionException, InterruptedException {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        assertTrue(future.get());
        assertTrue(future.isDone());
        assertFalse(future.isCancelled());
    }

    @Test
    public void testSubmit_nominal_executionException() throws InterruptedException {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            throw new Boom("Boom");
        });

        try {
            future.get();
            fail();
        } catch (ExecutionException e) {
            log.error("ExecutionException attendue !", e);
            assertEquals("Boom", e.getCause().getMessage());
            assertTrue(e.getCause() instanceof Boom);
        }
        assertTrue(future.isDone());
        assertFalse(future.isCancelled());
    }

    @Test
    public void testSubmit_nominal_timeout_not_exceeded() throws InterruptedException, TimeoutException, ExecutionException {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        assertTrue(future.get(TIMEOUT_NOT_EXCEEDED_MILLIS, TimeUnit.MILLISECONDS));
        assertTrue(future.isDone());
        assertFalse(future.isCancelled());
    }

    @Test
    public void testSubmit_nominal_timeout_exceeded() throws InterruptedException, ExecutionException {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        try {
            future.get(TIMEOUT_EXCEEDED_MILLIS, TimeUnit.MILLISECONDS);
            fail();
        } catch (TimeoutException e) {
            assertFalse(future.isDone());
            assertFalse(future.isCancelled());
            log.info("TimeoutException => OK");
        }
    }

    @Test
    public void testSubmit_nominal_cancel_terminate() throws InterruptedException, ExecutionException {
        final Future<Boolean> future;
        future = executor.submit(() -> {
            log.info("Start task");
            pause(PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        future.get();
        assertFalse(future.cancel(true));
        assertTrue(future.isDone());
        assertFalse(future.isCancelled());
    }

    @Test
    public void testSubmit_nominal_cancel_not_terminated() {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(LONG_PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        pause(PAUSE_MILLIS);
        final boolean cancel = future.cancel(true);
        if (cancel) {
            log.info("Cancelled");
            assertTrue(future.isDone());
            assertTrue(future.isCancelled());
        } else {
            log.info("No Cancelled");
            assertFalse(future.isCancelled());
            assertFalse(future.isDone());
        }
    }

    @Test
    public void testSubmit_nominal_cancel_not_terminated_no_interrupt() {
        final Future<Boolean> future = executor.submit(() -> {
            log.info("Start task");
            pause(LONG_PAUSE_MILLIS);
            log.info("End task");
            return true;
        });

        pause(PAUSE_MILLIS);
        final boolean cancel = future.cancel(false);
        if (cancel) {
            log.info("Cancelled");
            assertTrue(future.isDone());
            assertTrue(future.isCancelled());
        } else {
            log.info("No Cancelled");
            assertFalse(future.isDone());
            assertFalse(future.isCancelled());
        }
    }

    public void test_userContext() throws ExecutionException {

        Set<Future<?>> futures = new CopyOnWriteArraySet<>();
        AtomicInteger counterIdGdi = new AtomicInteger(0);
        final int max = 10;
        final int nbChildren = 5;
        final long waitMillis = 100;
        for (int i = 0; i < max; i++) {
            final Future<?> future = executor.submit(new RecursiveTask(executor, futures, userContextHolder, nbChildren, counterIdGdi, waitMillis));
            futures.add(future);
        }

        pause(max * nbChildren * waitMillis);

        for (int i = 0; i < max * nbChildren; i++) {
            for (Future<?> f : futures) {
                try {
                    f.get();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException e) {
                    log.error("ExecutionException", e);
                    throw e;
                }
            }
        }
    }

}
