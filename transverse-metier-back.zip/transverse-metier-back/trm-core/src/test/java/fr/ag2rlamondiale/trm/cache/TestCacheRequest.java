package fr.ag2rlamondiale.trm.cache;

import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RequetePersonnePhysique;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@EnableCaching
@ContextConfiguration(classes = TestCacheRequest.class)
public class TestCacheRequest {

    @Autowired
    PseudoService pseudoService;

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Autowired
    RequestScopedCacheManager requestScopedCacheManager;

    @Bean
    PseudoService pseudoService() {
        return new PseudoService();
    }

    @Bean
    RequestScopedCacheManager requestScopedCacheManager() {
        return new RequestScopedCacheManager();
    }

    @Bean
    RequestCacheResolver requestCacheResolver() {
        return new RequestCacheResolver();
    }

    @Before
    public void prepare() {
        for (int i = 0; i < 20; i++) {
            RequetePersonnePhysique critere = new RequetePersonnePhysique();
            critere.setIdGDI("" + i);
            PersonnePhysique pp = new PersonnePhysique();
            pp.setIdGdi("" + i);
            pp.setNom("NOM" + i);
            pp.setPrenom("PRENOM" + i);
            pp.setNumeroPersonneEre("NUMERE" + i);
            pp.setNumeroPersonneMdpro("NUMMDPRO" + i);
            pseudoService.put(critere, pp);
        }
        requestScopedCacheManager.clearCaches();
    }

    @Test
    public void testRechercheCache() throws Exception {
        for (int i = 0; i < 20; i++) {

            for (int j = 0; j < 5; j++) {
                pseudoService.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                final PersonnePhysique pp = pseudoService.rechercheRequestCache(critere);
                log.info("RES ({}.{}) = {}", i, j, pp);
                assertEquals(j == 0, pseudoService.isSansCache());
            }
        }
    }

    @Test
    public void testRechercheCacheAsync() throws Exception {
        for (int i = 0; i < 20; i++) {

            int finalI = i;
            CompletableFuture.runAsync(() -> {
                requestScopedCacheManager.clearCaches();
                for (int j = 0; j < 5; j++) {
                    pseudoService.resetSansCache();
                    RequetePersonnePhysique critere = new RequetePersonnePhysique();
                    critere.setIdGDI("" + finalI);

                    final PersonnePhysique pp = pseudoService.rechercheRequestCache(critere);
                    log.info("RES ({}.{}) = {}", finalI, j, pp);
                    assertEquals(j == 0, pseudoService.isSansCache());
                }
            }).get();
        }
    }

    @Test
    public void testRechercheSansCache() throws Exception {
        for (int i = 0; i < 20; i++) {
            for (int j = 0; j < 5; j++) {
                pseudoService.resetSansCache();
                RequetePersonnePhysique critere = new RequetePersonnePhysique();
                critere.setIdGDI("" + i);

                final PersonnePhysique pp = pseudoService.rechercheSansCache(critere);
                log.info("RES ({}.{}) = {}", i, j, pp);
                assertTrue(pseudoService.isSansCache());
            }
        }
    }
}
