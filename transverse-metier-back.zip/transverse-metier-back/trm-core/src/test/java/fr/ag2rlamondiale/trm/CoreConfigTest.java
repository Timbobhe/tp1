package fr.ag2rlamondiale.trm;

import org.junit.Test;
import org.meanbean.test.BeanTester;

public class CoreConfigTest {
    @Test
    public void testCoreConfigBean() {
        new BeanTester().testBean(CoreConfig.class);
    }
}
