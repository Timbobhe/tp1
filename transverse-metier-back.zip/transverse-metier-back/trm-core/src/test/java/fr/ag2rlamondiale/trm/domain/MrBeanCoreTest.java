package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.CoreConfig;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.testing.MrBeanTester;
import org.junit.Test;

import static org.junit.Assert.*;

public class MrBeanCoreTest {

    @Test
    public void testCoreBean() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addClasses("fr.ag2rlamondiale.trm.domain", CoreConfig.class);
        beanTester.addClasses("fr.ag2rlamondiale.trm.dto", CoreConfig.class);

        beanTester.test();
        assertNotNull(beanTester);
  }

    @Test
    public void test_UserContext() throws Exception {
        MrBeanTester beanTester = new MrBeanTester();
        beanTester.beanTester(UserContext.class);
        assertNotNull(beanTester);
  }

    private MrBeanTester newMrBeanTester() {
        MrBeanTester beanTester = new MrBeanTester();
        beanTester.setClassPredicate(
                beanTester.getClassPredicate().and(clazz -> !clazz.getSimpleName().endsWith("MapperImpl")));

        return beanTester;
    }

}
