package fr.ag2rlamondiale.trm.cas.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Ticket {
    private String uid;
    private String password;
    private String partenaire;
    private String refExterne;
    private String idEpargneRetraite;
    private boolean impersonation;
}
