package fr.ag2rlamondiale.trm.cas.api;

import fr.ag2rlamondiale.trm.cas.dto.CasMockConstants;
import fr.ag2rlamondiale.trm.cas.dto.Ticket;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Profile(CasMockConstants.CASMOCK)
@Slf4j
@RestController
@RequestMapping
public class CasMockService {
    private static final String SERVICELOCALHOST = "http://localhost:8080/ecrs/j_spring_cas_security_check";

    @LogExecutionTime
    @GetMapping(path = "/*/login/**", produces = MediaType.TEXT_HTML_VALUE)
    public String getLoginPage() {
        return "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "    <title>Connexion</title>\n" +
                "    <style>\n" +
                "        html {\n" +
                "            font-family: \"Relative\", Arial, sans-serif;\n" +
                "        }\n" +
                "        body {\n" +
                "            color: #381a0a;\n" +
                "            font-size: 1.1rem;\n" +
                "        }\n" +
                "\t\t\n" +
                "\t\t.connection {\n" +
                "\t\tcursor: pointer;\n" +
                "\t\tborder: none;\n" +
                "\t\tcolor: white;\n" +
                "\t\tline-height: 2rem;\n" +
                "\t\tbackground-color: #0052FF;\n" +
                "\t\t}\n" +
                "\n" +
                "\t\t.connection:hover {\n" +
                "\t\tbackground-color: #381A0A;\n" +
                "\t\t}\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "<div class=\"header\">\n" +
                "    <header>\n" +
                "        <div class=\"logo\">\n" +
                "            <img src=\"data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAANIAAAA3CAMAAABOzuRBAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMAUExURTgaCjkbCzseDj8iEzMtIUQnGEQoGUcvIUkyJEozJUo0Jk0yJE4zJVA2KFE3KVM6LFU7LkhFOkhGOkhGO1ZEN11EN11FOGFJPWVOQmhRRWlTR25YTG9ZTnNdUnZhVnF1bQfO4ADo/wbp/wvp/x/l+R/m+R7r/ynN3CfR4CjR4CDm+SLr/yTr/y7k9ins/y/s/zTt/1qNjFeTk03R3EDu/03v/1rw/1/x/3LX32vy/23y/3Tm8Xnz/33z/4JvZYNwZot5cI9+dY9/dpB/dpiIgJqLg5uMhJyNhZ6Ph5qVj5CalqCSiqSXkKaZkaiak6iblKufmLGln6i0sbSoorSpo7WqpLetp720rr+1sJDX3I71/6D2/6f3/7j5/775/8G3ssG4s8zFwc3GwtDJxtPNydXPy9rU0drV0tzX1Mr6/9b7/9r8/+Tg3uXh3+bi4Ofj4ejk4uvo5u3r6e7r6uH8/+f9/+j9/+79//Px8Pb19PX+//r6+fv7+vr///39/f7//wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADIruVMAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAUbSURBVGhD7Zn3t9tEEIWHIlOCTbUBAQZDEkjoEHrih4FI1PcoCiUUgwKCUBRKABPK/uvcOzu2ivVeHj+uyU1yNNoyO9/saNfnRNzG6RJSCPr/IH388LtmhadOpPPHJpODd/9ob6GpC+n0fRPo4I1v23tgWkf69jECkemmO7+2tqDURvr7xL1GNJkculleteaQ1EI6+4jhqMB06xfWE44aSBeeN5alwCQv/2W9oaiO9NlhI6lEpus/tP5AVCH9/oxhNEQmmf5sY4JQhXTCIFo6SqY3bEwQqhVe+0MyHboyLKLGt/SCQbR09HXrD0Q1pHMHHjeIlh761UaEoQrp3AGRjWBaIZFoM5iWSJ5oI5gMaUm0CUweqSLaACZFqhOFz0SkJlHwTEBqE4XOJB1EgTNJF1HYTHKbQbS0C9NTNk2VpblZxc5Wesqb8zR+ic1lSn2+8K0uTzOzoCJNzXJukZqXebqjT5efyv2sLC2WD/W2U/L1/ZMnf8ID8/S1cpzpimkm5XUG0VIn04O/2XRqITLw1kxnDBiAN7FKrob0NCrnEom9QY1FrFnHac+iJ3r6JjpNkWPvP5Zk6W0LrO/JHWzNRGZ8Vo5jPyYW9x+YGkRuG4M0sim8z+dj6ZWugJnPaOXST5KkL2Md20BCLmRqtgZLLwiRSDGm5ZjG0Ygx0QeR4A3roNmQkJYen3WkKVZMMrjZN1OTyA2RECYKQc35zre5DLUnRyuXmvvUN5G2BfhmKxL5+niya8iiWxCDSMiNIXE6EpYZUinRUJetI/kK5or7ZGoRwWmpkY3N6SJHzecs8BXSYmu5YB0JsYx9FiAgRbIAO5iciywsBM8Y8aeOhLIeG9K2TPEXRjfS/phaRHA/ZXB+yYYQpc8+ZR9vDQm5QJlZQXJcAgdwglklZ6pYjYiRC9SQ5jIyJHSgfrGjdSRV7l3sxvSE4UBtIlRK4SMbyjY9U9pR9NhgSD5xDSTmwodDYRw2u5QhE5GvCpIbDaRcBlqEhsQxilQgLSgP5Gs3pIszrRHBexyPGJnuUoWU97QgGASSvjzZakh9GcSxYlOMcioDyWis7RK6ZjWkDA9FwgkUxwPsWQOpVnjQRZjWiHjMqTJY8AwxJj259DTTIKbehqqVMUzlJ+ks/Iv89MgKVY8VxriIgLtCGsOfIvEwoco9kPZmWifi4nmeJ4isjPw1MpW+EvkvS4NA1vU+rCNNZYyJeWQ9SjLUqGEk0mNcqF098WDzcF8i4drIFWkuEX1w//ZA2oupgyhj/HrFlFxptLU1kGHJ7KIi4nhmQeCu4DCNle1xhlzYZaY3pScp8XtBDcBJnOKr4F3gY9TbCR8Zi5WgRLLJGe7iynEsI7UqpN2ZOohQAj6iMVeZRxwX6/njFRsSQvHHwLIDN6HmAvD+p4cnqQw/UJ17JOy0biHU58kPJPzS0LQgocXKMdm92GV69mpra+k166+rsN9hJS4jvmZ+00vWA1ToLQXlq3FepU1gT/NpE9CQ2Rxbo8Bdt9C52vrVmTM/LOega+UYL141pOOTe64xiJaqH5khqEI6jmPggWsNoqW3bEwQqpDOP02mrn267MU/bEwQqn9LnxzuZLrhS+sPRHUkd+G5dabLX/nTekNRA8m5Tx9tMY2+sZ5w1ELi/5wdqZiuePMfaw5Ia0ju7LEjVxnR7d9bW1BaR3Lu9P3KFL1j74GpC8l99ySY7vrF3kJTJ5JzH93ygVnhaRekkHUJKQRtHJJz/wKi5twfQ1AzXQAAAABJRU5ErkJggg==\"\n" +
                "                 alt=\"AG2R LA MONDIALE\">\n" +
                "        </div>\n" +
                "    </header>\n" +
                "</div>\n" +
                "        <h2>Connexion</h2>\n" +
                "        <form method=\"POST\">\n" +
                "            <p>Login <input id=\"username\" type=\"text\" name=\"username\"></p>\n" +
                "            <p>Password <input id=\"password\" type=\"text\" name=\"password\"></p>\n" +
                "            <p>Impersonation <input id=\"impersonation\" type=\"checkbox\" name=\"impersonation\" value=\"active\"></p>\n" +
                "            <p><input class=\"connection\" id=\"connection\" type=\"submit\" name=\"Connexion\"></p>\n" +
                "        </form>\n" +
                "        <hr>\n" +
                "        <h2>Partenaire</h2>\n" +
                "        <form method=\"POST\">\n" +
                "            <p>RefExterne <input id=\"refExterne\" type=\"text\" name=\"refExterne\" value=\"990000000000000001\"></p>\n" +
                "            <p>idEpargneRetraite <input id=\"idEpargneRetraite\" type=\"text\" name=\"idEpargneRetraite\" value=\"\"></p>\n" +
                "            <p>Partenaire <input id=\"partenaire\" type=\"text\" name=\"partenaire\" value=\"49505\"></p>\n" +
                "            <p>Impersonation <input id=\"impersonation\" type=\"checkbox\" name=\"impersonation\" value=\"active\"></p>\n" +
                "            <p><input class=\"connection\" id=\"connectionPartenaire\" type=\"submit\" name=\"Connexion\"></p>\n" +
                "        </form>\n" +
                "<div class=\"footer\">\n" +
                "    <footer>\n" +
                "        © 2011-\n" +
                "        <script>document.write(new Date().getFullYear());</script>\n" +
                "        AG2R LA MONDIALE\n" +
                "    </footer>\n" +
                "\t        <hr>\n" +
                "</div>\n" +
                "</body>\n" +
                "</html>\n";
    }

    @LogExecutionTime
    @PostMapping(path = "/*/login/**")
    public void sendlogin(HttpServletRequest request, HttpServletResponse response) throws IOException {

        Ticket ticket = Ticket.builder()
                .uid(request.getParameter("username"))
                .password(request.getParameter("passport"))
                .refExterne(request.getParameter("refExterne"))
                .partenaire(request.getParameter("partenaire"))
                .idEpargneRetraite(request.getParameter("idEpargneRetraite"))
                .impersonation("active".equals(request.getParameter("impersonation")))
                .build();

        String ticketString = Base64.getEncoder().encodeToString(JsonMarshaller.toJSON(ticket).getBytes(StandardCharsets.UTF_8));
        String service = request.getParameter("service");

        String url = (service != null ? service : SERVICELOCALHOST) + "?ticket=" + ticketString;

        response.sendRedirect(url);
    }

    @LogExecutionTime
    @GetMapping(path = "/*/proxyValidate/**", produces = MediaType.TEXT_XML_VALUE)
    public String getProxyValidate(HttpServletRequest request) {
        String data = new String(Base64.getDecoder().decode(request.getParameter("ticket")), StandardCharsets.UTF_8);

        Ticket ticketObject = JsonMarshaller.fromJSON(data, Ticket.class);
        return ticketObject.getPartenaire() != null ? getCasPartenaire(ticketObject) : getCas(ticketObject);
    }

    private String getCas(Ticket data) {
        List<String> roles = new ArrayList<>();
        roles.add("NET-Utilisateur");
        if (data.isImpersonation()) {
            roles.add("IMP-EERE-Salarie");
        } else {
            roles.add("EERE-Salarie");
        }
        final String rolesXml = roles.stream().map(role -> "      <cas:roles>" + role + "</cas:roles>")
                .collect(Collectors.joining("\n"));


        return "<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>\n" +
                "  <cas:authenticationSuccess>\n" +
                "    <cas:user>" + data.getPartenaire() + "</cas:user>\n" +
                "    <cas:attributes>\n" +
                "      <cas:uid>" + data.getUid() + "</cas:uid>\n" +
                "      <cas:agGDIModeCreation>indirect</cas:agGDIModeCreation>\n" +
                "      <cas:mail>" + data.getUid() + "@mail.com</cas:mail>\n" +
                "      <cas:sn>NOM_" + data.getUid() + "</cas:sn>\n" +
                "      <cas:agIdTechnique>1000015478</cas:agIdTechnique>\n" +
                "      <cas:agGDIDateDerniereConnexion>20200322190743+0100</cas:agGDIDateDerniereConnexion>\n" +
                "      <cas:cn>NOM_" + data.getUid() + "PRENOM_" + data.getUid() + "</cas:cn>\n" +
                rolesXml +
                "      <cas:entryDN>uid=" + data.getUid() + ",ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr</cas:entryDN>\n" +
                "      <cas:agDateNaissance>19580901000000+0100</cas:agDateNaissance>\n" +
                "      <cas:givenName>PRENOM_" + data.getUid() + "</cas:givenName>\n" +
                "      <cas:agGDIDateModification>20180523111313+0200</cas:agGDIDateModification>\n" +
                "    </cas:attributes>\n" +
                "    </cas:authenticationSuccess>\n" +
                "</cas:serviceResponse>";
    }

    private String getCasPartenaire(Ticket data) {
        String businessIdMap = "";
        if (data.getRefExterne() != null && data.getRefExterne().trim().length() > 0) {
            businessIdMap = "refExterne=" + data.getRefExterne();
        } else if (data.getIdEpargneRetraite() != null && data.getIdEpargneRetraite().trim().length() > 0) {
            businessIdMap = "idEpargneRetraite=" + data.getIdEpargneRetraite();
        }

        List<String> roles = new ArrayList<>();
        roles.add("EERE-Federation");
        if (data.isImpersonation()) {
            roles.add("IMP-EERE-Salarie");
        } else {
            roles.add("EERE-Salarie");
        }
        final String rolesXml = roles.stream().map(role -> "      <cas:roles>" + role + "</cas:roles>")
                .collect(Collectors.joining("\n"));

        return "<cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>\n" +
                "  <cas:authenticationSuccess>\n" +
                "       <cas:user>A622873A-CFF7-4CB7-A7C9-${data.refExterne}</cas:user>\n" +
                "        <cas:attributes>\n" +
                "            <cas:agDateNaissance></cas:agDateNaissance>\n" +
                "            <cas:clientIpAddress>10.120.239.68</cas:clientIpAddress>\n" +
                "            <cas:fdiPerimeterName>" + data.getPartenaire() + "</cas:fdiPerimeterName>\n" +
                "            <cas:isFromNewLogin>true</cas:isFromNewLogin>\n" +
                "            <cas:authenticationDate>2021-11-10T12:00:25.113778Z</cas:authenticationDate>\n" +
                "            <cas:clientName>ping</cas:clientName>\n" +
                rolesXml +
                "            <cas:successfulAuthenticationHandlers>DelegatedClientAuthenticationHandler</cas:successfulAuthenticationHandlers>\n" +
                "            <cas:userAgent>Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36 Edg/93.0.961.38</cas:userAgent>\n" +
                "            <cas:seeAlso></cas:seeAlso>\n" +
                "            <cas:employeeNumber></cas:employeeNumber>\n" +
                "            <cas:authMode>trusted</cas:authMode>\n" +
                "            <cas:credentialType>ClientCredential</cas:credentialType>\n" +
                "            <cas:samlAuthenticationStatementAuthMethod>urn:oasis:names:tc:SAML:1.0:am:unspecified</cas:samlAuthenticationStatementAuthMethod>\n" +
                "            <cas:businessIdMap>{" + businessIdMap + "}</cas:businessIdMap>\n" +
                "            <cas:uid>A622873A-CFF7-4CB7-A7C9-" + data.getRefExterne() + "</cas:uid>\n" +
                "            <cas:police></cas:police>\n" +
                "            <cas:authenticationMethod>DelegatedClientAuthenticationHandler</cas:authenticationMethod>\n" +
                "            <cas:geoLocation>unknown</cas:geoLocation>\n" +
                "            <cas:serverIpAddress>10.55.35.123</cas:serverIpAddress>\n" +
                "            <cas:longTermAuthenticationRequestTokenUsed>false</cas:longTermAuthenticationRequestTokenUsed>\n" +
                "            </cas:attributes>\n" +
                "  </cas:authenticationSuccess>\n" +
                "</cas:serviceResponse>";
    }
}

