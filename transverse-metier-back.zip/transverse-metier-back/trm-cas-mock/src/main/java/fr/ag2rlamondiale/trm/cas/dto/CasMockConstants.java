package fr.ag2rlamondiale.trm.cas.dto;

public final class CasMockConstants {
    public static final String CASMOCK = "casmock";
}
