## 2.5.0 - 16/07/2021

- Module `trm-paiement-digital`
- Activation/Désactivation GPS MDP possible
- Activation/Désactivation des traces consoles
- Gestion correcte des switch d'env pour les services PFS REST (avec token JWT associé à l'environnement)
- 


## 3.0.0 - 22/06/2021

- Modification de `fr.ag2rlamondiale.trm.domain.sigelec.DemandeCreationSigElec` pour gérer plusieurs 
  Conventions de Preuve.

- Rajout de l'argument ORIGINE dans `fr.ag2rlamondiale.rib.api.secure.GestionMandatRestController.startChangeCoordonneesBancaires` 
pour filtrer les contrats Metiers principales selon l'application d'origine.
