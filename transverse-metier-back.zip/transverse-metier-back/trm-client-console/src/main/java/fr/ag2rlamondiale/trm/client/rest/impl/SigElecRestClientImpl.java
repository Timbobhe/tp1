package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ISigElecRestClient;
import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecCriteria;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecRequest;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecUpdate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

@Service
@Slf4j
public class SigElecRestClientImpl implements ISigElecRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/getDmdSigElecParEtatsOperationsPersonneContrat")
    private String urlFindSigElecJson;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/createDmdSigElec")
    private String urlCreateDmdSigElec;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/updateDmdSigElec")
    private String urlUpdateDmdSigElec;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/updateDmdSigElecDocument")
    private String updateDmdSigElecDocument;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/getDmdSigElecParEtatsOperationType")
    private String urlFindSigElecByEtatType;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/deleteDmdSigElec/")
    private String urlDeleteSigElecById;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/deleteDmdSigElecParIdExt/")
    private String urlDeleteSigElecByIdExt;

    @Override
    public List<SigElecJson> getDmdSigElecParEtatsOperationsPersonneContrat(SigElecCriteria cre) {
        final SigElecJson[] sigElecJsons = restTemplate.postForObject(urlFindSigElecJson, JsonHttpEntityUtils.jsonHttpEntity(cre),
                SigElecJson[].class);
        return JsonHttpEntityUtils.toList(sigElecJsons);
    }

    @Override
    public List<SigElecJson> getDmdSigElecEncoursNonSignees(String idGDI, String numContrat, OperationType operationType) {
        return getDmdSigElecParEtats(idGDI, numContrat, EtatSigELec.encours(false), operationType);
    }

    @Override
    public List<SigElecJson> getDmdSigElecEncoursSignees(String idGDI, String numContrat, OperationType operationType) {
        return getDmdSigElecParEtats(idGDI, numContrat, EtatSigELec.encours(true), operationType);
    }

    @Override
    public List<SigElecJson> getDmdSigElecEncours(String idGDI, String numContrat, OperationType operationType) {
        return getDmdSigElecParEtats(idGDI, numContrat, EtatSigELec.encours(), operationType);
    }

    @Override
    public List<SigElecJson> getDmdSigElecParEtats(String idGDI, String numContrat, List<EtatSigELec> etats, OperationType operationType) {
        SigElecCriteria cre = new SigElecCriteria();
        cre.setIdGDI(idGDI);
        cre.setContrats(Collections.singletonList(numContrat));
        cre.setEtats(etats);
        cre.setTypesOperation(Collections.singletonList(operationType));
        return getDmdSigElecParEtatsOperationsPersonneContrat(cre);
    }

    @Override
    public List<SigElecJson> getDmdSigElecParEtatsOperationType(SigElecCriteria cre) {
        final SigElecJson[] sigElecJsons = restTemplate.postForObject(urlFindSigElecByEtatType, JsonHttpEntityUtils.jsonHttpEntity(cre),
                SigElecJson[].class);
        return JsonHttpEntityUtils.toList(sigElecJsons);
    }

    @Override
    public boolean annulerDemandeSigElec(long idDemande) {
        restTemplate.put(urlDeleteSigElecById + idDemande, null);
        return true;
    }

    @Override
    public boolean annulerDemandeSigElecParIdExt(String idExt) {
        restTemplate.put(urlDeleteSigElecByIdExt + idExt, null);
        return true;
    }

    @Override
    public boolean createDmdSigElec(SigElecRequest sigElecJson) {
        try {
            final ResponseEntity<String> response = restTemplate.postForEntity(urlCreateDmdSigElec, JsonHttpEntityUtils.jsonHttpEntity(sigElecJson), String.class);
            return HttpStatus.OK.equals(response.getStatusCode());
        } catch (RestClientException e) {
            return false;
        }
    }

    @Override
    public boolean updateDmdSigElec(SigElecUpdate sigElecUpdate) {
        try {
            final ResponseEntity<String> response = restTemplate.postForEntity(urlUpdateDmdSigElec, JsonHttpEntityUtils.jsonHttpEntity(sigElecUpdate), String.class);
            return HttpStatus.OK.equals(response.getStatusCode());
        } catch (RestClientException e) {
            return false;
        }
    }

    @Override
    public boolean updateDmdSigElecDocument(SigElecUpdate sigElecUpdate) {
        Objects.requireNonNull(sigElecUpdate.getIdCustomExt());
        Objects.requireNonNull(sigElecUpdate.getListDocs());

        try {
            final ResponseEntity<String> response = restTemplate.postForEntity(updateDmdSigElecDocument, JsonHttpEntityUtils.jsonHttpEntity(sigElecUpdate), String.class);
            return HttpStatus.OK.equals(response.getStatusCode());
        } catch (RestClientException e) {
            return false;
        }
    }
}
