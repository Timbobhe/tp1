package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.paiement.FindRequestPaiementCbJson;
import fr.ag2rlamondiale.trm.domain.paiement.FindRequestPaiementCbUtilisateurJson;
import fr.ag2rlamondiale.trm.domain.paiement.PaiementCbJson;
import fr.ag2rlamondiale.trm.domain.paiement.UpdateRequestPaiementCbJson;

import java.util.List;

public interface IPaiementCbRestClient {

    PaiementCbJson createPaiement(PaiementCbJson paiementCbJson);

    PaiementCbJson updatePaiement(UpdateRequestPaiementCbJson updateRequest);

    PaiementCbJson findPaiement(FindRequestPaiementCbJson findRequest);

    List<PaiementCbJson> findPaiementsUtilisateur(FindRequestPaiementCbUtilisateurJson findRequest);
}
