package fr.ag2rlamondiale.trm.domain.blocage;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.PerimetreType.TOUT;

public class Blocages {

    /**
     * Les blocages Console
     */
    @Getter
    private final List<BlocageJson> blocageJsonList;

    public Blocages(Collection<BlocageJson> blocageJsonList) {
        this.blocageJsonList = blocageJsonList == null ? Collections.emptyList() : new ArrayList<>(blocageJsonList);
    }

    /**
     * Permet d'obtenir les blocages direct et indirects concernant un numero de
     * personne
     *
     * @param numPersonne
     * @return
     */
    private List<BlocageJson> getBlocagesPersonne(String numPersonne, List<ProduitContratJson> contrats, CodeSiloType silo) {
        return blocageJsonList.stream()
                .filter(blocageJson -> blocageJson.matchPersonne(numPersonne)
                        && blocageJson.noneMatchException(numPersonne)
                        && contrats.stream().allMatch(blocageJson::noneMatchException)
                        && silo.getLibelle().equals(blocageJson.getCodeSiloType()))
                .collect(Collectors.toList());
    }

    /**
     * Permet d'obtenir les fonctionnalitesBloquees par contrat, a partir des
     * blocages directs et indirects sur les contrats.<br>
     * La MAP contient <u>tous les contrats</u>, seule la Valeur change :
     * {@link Fonctionnalites#isAucune()} si le contrat n'a pas aucune fonctionnalité
     * bloqué
     *
     * @param contrats
     * @return
     */
    public Map<String, Fonctionnalites> calculerFonctionnalitesBloqueesContrats(List<ProduitContratJson> contrats) {
        Map<String, Fonctionnalites> fonctionnalitesBloquees = new HashMap<>();
        for (ProduitContratJson contrat : contrats) {
            final Fonctionnalites fonctionnalites = fonctionnalitesBloquees
                    .computeIfAbsent(contrat.getNumContrat(), k -> new Fonctionnalites());
            for (BlocageJson blocage : blocageJsonList) {
                if (!TOUT.equals(blocage.getTypePerimetre())
                        && blocage.matchContrat(contrat)
                        && blocage.noneMatchException(contrat)) {
                    fonctionnalites.add(blocage);
                }
            }
        }
        return fonctionnalitesBloquees;
    }

    /**
     * Retourne la liste des fonctionnalité bloquées a la personne pour un num de
     * personne donne
     *
     * @param numPersonne
     * @return la liste des fonctionnalites bloquees specifiquement a la personne ou
     * sur un blocage total
     */
    public List<String> calculerFonctionnalitesBloqueesAlaPersonne(String numPersonne, List<ProduitContratJson> contrats, CodeSiloType silo) {
        return getBlocagesPersonne(numPersonne, contrats, silo).stream()
                .filter(blocageJson -> StringUtils.equalsIgnoreCase(silo.getLibelle(), blocageJson.getCodeSiloType()))
                .map(BlocageJson::getFonctionnalites)
                .flatMap(Collection::stream)
                .map(FonctionnaliteJson::getCodeFct)
                .distinct()
                .collect(Collectors.toList());
    }

    public boolean isPersonneTotalementBloquee(String numPersonne, List<ProduitContratJson> contrats, CodeSiloType silo) {
        return StringUtils.isEmpty(numPersonne)
                || getBlocagesPersonne(numPersonne, contrats, silo).stream().anyMatch(BlocageJson::isToutesFonctionnalites);
    }
}
