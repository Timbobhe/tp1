package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ICompteDemoRestClient;
import fr.ag2rlamondiale.trm.domain.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.trm.domain.comptedemo.FindCompteDemoRequestDto;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.utils.UrlUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class CompteDemoRestClientImpl implements ICompteDemoRestClient {

    @Value("#{consoleProps.consoleV2ApiUrl}/compte-demo/find")
    private String findCompteDemoUrl;

    @Autowired
    private RestTemplate restTemplate;

    @LogError(category = "REST")
    @Override
    public CompteDemoDto findCompteDemo(FindCompteDemoRequestDto req) {

        String url;
        if (req.getNumReferenceExterne() != null && !req.getNumReferenceExterne().trim().isEmpty()) {
            url = UrlUtils.appendQueryParams(findCompteDemoUrl, "numReferenceExterne", req.getNumReferenceExterne());
        } else if (req.getNumPersonne() != null && !req.getNumPersonne().trim().isEmpty()) {
            url = UrlUtils.appendQueryParams(findCompteDemoUrl, "numPersonne", req.getNumPersonne());
        } else {
            throw new IllegalArgumentException();
        }

        try {
            final CompteDemoDto res = restTemplate.getForObject(url, CompteDemoDto.class);
            return res;
        } catch (HttpClientErrorException.NotFound e) {
            return null;
        }
    }
}
