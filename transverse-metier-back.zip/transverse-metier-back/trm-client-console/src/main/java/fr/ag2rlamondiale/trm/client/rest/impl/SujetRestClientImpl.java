package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ISujetRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestListJson;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.CONSOLE_PARAM_CACHE;

@Slf4j
@Service
public class SujetRestClientImpl implements ISujetRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/getSujets")
    private String getSujetsUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/getSujetsParUtilisateur")
    private String getSujetsParUtilisateurUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/createSujetParUtilisateur")
    private String createSujetParUtilisateurUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/updateSujetParUtilisateur")
    private String updateSujetParUtilisateurUrl;

    @NoAuthRequired
    @Cacheable(CONSOLE_PARAM_CACHE)
    @LogExecutionTime
    @LogError(category = "REST")
    @Override
    public List<SujetJson> getSujets(Set<CodeSiloType> silos) {
        final SujetJson[] sujets = restTemplate.getForObject(getSujetsUrl, SujetJson[].class);
        List<SujetJson> sujetJsonList = JsonHttpEntityUtils.toList(sujets);

        // Pour un Utilisateur ERE&MDP on conserve les sujets ROOT ERE&MDP ...
        sujetJsonList = filtreSujets(sujetJsonList, silos);

        Set<CodeSiloType> silosNoMixtes = new HashSet<>(silos);
        // Par contre pour les sous-sujets, si l'utilisateur est à la fois ERE & MDP alors on ne conserve que les sujets ERE
        if (silosNoMixtes.contains(CodeSiloType.ERE)) {
            silosNoMixtes.remove(CodeSiloType.MDP);
        }
        sujetJsonList.forEach(sujet -> {
            if (sujet.getCodeSilo() == null) {
                // on filtre les sous-sujets uniquement pour les sujets Mixtes
                sujet.setSousSujets(filtreSujets(sujet.getSousSujets(), silosNoMixtes));
            }
        });

        return sujetJsonList;
    }

    private List<SujetJson> filtreSujets(List<SujetJson> sujets, Set<CodeSiloType> silos) {
        if (sujets == null) {
            return Collections.emptyList();
        }

        return sujets.stream()
                .filter(sujet -> sujet.getCodeSilo() == null || silos.contains(sujet.getCodeSilo()))
                .collect(Collectors.toList());
    }

    @LogExecutionTime
    @Override
    @LogError(category = "REST")
    public List<LectureSujetJson> getSujetsParUtilisateur(SujetRequestJson requete) {
        final LectureSujetJson[] sujets = restTemplate
                .postForObject(getSujetsParUtilisateurUrl, JsonHttpEntityUtils.jsonHttpEntity(requete),
                        LectureSujetJson[].class);
        return JsonHttpEntityUtils.toList(sujets);
    }

    @Override
    @LogError(category = "REST")
    public List<LectureSujetJson> createSujetParUtilisateur(SujetRequestListJson requete) {
        try {
            final LectureSujetJson[] sujets = restTemplate
                    .postForObject(createSujetParUtilisateurUrl, JsonHttpEntityUtils.jsonHttpEntity(requete),
                            LectureSujetJson[].class);
            return JsonHttpEntityUtils.toList(sujets);
        } catch (RestClientException ex) {
            log.error("Erreur lors de creation ou existe deja", ex);
        }
        return new ArrayList<>(0);
    }

    @Override
    @LogError(category = "REST")
    public LectureSujetJson updateSujetLuParUtilisateur(SujetRequestJson requete) {
        return restTemplate.postForObject(updateSujetParUtilisateurUrl, JsonHttpEntityUtils.jsonHttpEntity(requete),
                LectureSujetJson.class);
    }
}
