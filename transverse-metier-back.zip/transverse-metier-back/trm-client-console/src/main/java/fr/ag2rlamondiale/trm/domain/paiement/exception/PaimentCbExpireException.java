package fr.ag2rlamondiale.trm.domain.paiement.exception;

public class PaimentCbExpireException extends PaimentCbException {

    public PaimentCbExpireException() {
    }

    public PaimentCbExpireException(String message) {
        super(message);
    }

    public PaimentCbExpireException(String message, Throwable cause) {
        super(message, cause);
    }

    public PaimentCbExpireException(Throwable cause) {
        super(cause);
    }

    public PaimentCbExpireException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
