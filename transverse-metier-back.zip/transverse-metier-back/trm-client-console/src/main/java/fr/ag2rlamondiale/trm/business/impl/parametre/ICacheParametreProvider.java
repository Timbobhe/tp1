package fr.ag2rlamondiale.trm.business.impl.parametre;

import fr.ag2rlamondiale.trm.business.IParamConsoleProvider;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import org.springframework.cache.annotation.Cacheable;

import java.util.List;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

interface ICacheParametreProvider extends IParamConsoleProvider {
    String CACHE_FIND_PARAMETRE_BY_TYPE_ANNEE = "CACHE_FIND_PARAMETRE_BY_TYPE_ANNEE";

    @NoAuthRequired
    @Cacheable(cacheNames = CACHE_FIND_PARAMETRE_BY_TYPE_ANNEE, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    List<ParametreDto> getParametresCachable(String typeParam, Annee annee);
}
