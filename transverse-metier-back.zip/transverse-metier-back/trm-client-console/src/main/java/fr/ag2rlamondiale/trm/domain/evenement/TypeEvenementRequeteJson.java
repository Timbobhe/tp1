/*
 * Cree le 4 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Date;

/**
 * Objet utilisé pour requêter sur les types d'évènements.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class TypeEvenementRequeteJson implements Serializable {
    private static final long serialVersionUID = -5391935989545342567L;

    @EqualsAndHashCode.Include
    @JsonProperty(value = "codeApp")
    private String codeApp;

    @JsonProperty(value = "date")
    private Date date;
}
