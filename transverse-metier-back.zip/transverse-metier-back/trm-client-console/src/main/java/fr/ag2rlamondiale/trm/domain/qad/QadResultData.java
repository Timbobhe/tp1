package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Représente une ligne du tableau récapitulatif du QAD.
 */
@Data
@NoArgsConstructor
public class QadResultData {
	private long idQuestion;
	private int ordre;
	private CodeProfilType codeProfil;
	private String labelCourt;
	private List<String> reponsesLabels;
	private int reponseWeight;
	private int index;

	public QadResultData(long idQuestion, int ordre, CodeProfilType codeProfil, String labelCourt,
			List<String> reponsesLabels, int reponseWeight) {
		this.idQuestion = idQuestion;
		this.ordre = ordre;
		this.codeProfil = codeProfil;
		this.labelCourt = labelCourt;
		this.reponsesLabels = reponsesLabels;
		this.reponseWeight = reponseWeight;
	}

	public static int getScoreFromResults(List<QadResultData> resultData, CodeProfilType codeProfil) {
		int score = 0;
		for (QadResultData singleResult : resultData) {
			if (codeProfil == singleResult.getCodeProfil()) {
				score += singleResult.getReponseWeight();
			}
		}
		return score;
	}
}
