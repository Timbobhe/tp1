package fr.ag2rlamondiale.trm.domain.paiement.exception;

public class PaimentCbNotFoundException extends PaimentCbException {

    public PaimentCbNotFoundException() {
    }

    public PaimentCbNotFoundException(String message) {
        super(message);
    }

    public PaimentCbNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    public PaimentCbNotFoundException(Throwable cause) {
        super(cause);
    }

    public PaimentCbNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
