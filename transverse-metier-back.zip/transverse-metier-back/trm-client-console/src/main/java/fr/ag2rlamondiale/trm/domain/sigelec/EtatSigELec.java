package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
public enum EtatSigELec {
    // Encours + non signée
    INIT("Initialisé", true, false),
    TRAN("Transmis Universign", true, false),
    PRET("Prêt", true, false),

    // Encours + signée
    WAIT("En attente", true, true),
    SIGN("Document signé", true, true),
    REPR("A reprendre", true, true),

    // Termine
    ANNU("Annulé", false, false),
    EXPI("Expiré", false, false),
    ERRO("En erreur", false, false),
    TERM("Terminé", false, true),
    ERRF("En erreur P.J", false, false);

    private final String label;

    private final boolean encours;

    private final boolean signe;

    EtatSigELec(String label, boolean encours, boolean signe) {
        this.label = label;
        this.encours = encours;
        this.signe = signe;
    }

    public static List<EtatSigELec> encours(boolean signe) {
        return Stream.of(EtatSigELec.values())
                .filter(EtatSigELec::isEncours)
                .filter(e -> e.isSigne() == signe)
                .collect(Collectors.toList());
    }

    public static List<EtatSigELec> encours() {
        return Stream.of(EtatSigELec.values())
                .filter(EtatSigELec::isEncours)
                .collect(Collectors.toList());
    }
}
