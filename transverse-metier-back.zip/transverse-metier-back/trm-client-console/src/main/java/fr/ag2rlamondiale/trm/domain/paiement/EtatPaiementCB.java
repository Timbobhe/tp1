package fr.ag2rlamondiale.trm.domain.paiement;

import lombok.Getter;

@Getter
public enum EtatPaiementCB {
    INIT("Initialisé", false, false, false),
    ANNU("Annulé", false, false, false),
    AUTHDMD("Authorisation demandée", true, false, false),
    AUTHOK("Authorisation OK", true, false, true),
    AUTHERR("Authorisation en Erreur ou Refusée", true, false, false),

    CAPTDMD("Capture demandée", false, true, false),
    CAPTOK("Capture OK", false, true, true),
    CAPTERR("Capture en Erreur ou Refusée", false, true, false);

    private final String label;
    private final boolean etapeAuth;
    private final boolean etapeCapture;
    private final boolean indicateurSucces;

    EtatPaiementCB(String label, boolean etapeAuth, boolean etapeCapture, boolean indicateurSucces) {
        this.label = label;
        this.etapeAuth = etapeAuth;
        this.etapeCapture = etapeCapture;
        this.indicateurSucces = indicateurSucces;
    }

    public static EtatPaiementCB getEtatFromLabel(String label) {
        for (EtatPaiementCB etat : values()) {
            if (etat.getLabel().equals(label)) {
                return etat;
            }
        }
        return null;
    }
}
