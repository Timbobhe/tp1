package fr.ag2rlamondiale.trm.domain.paiement;

import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FindRequestPaiementCbJson {
    private Long id;

    /**
     * Identifiant externe utiliser pour revenir sur l'espace client suite à redirection 3DS
     */
    private String idExterne;

    private String idGDI;

    private AccesApp codeApp;

    /**
     * Id de la transaction retourné par le service CreerTransactionPaiementDigital
     */
    private String idTransactionPaiementCB;

    private boolean withContext;

    private boolean withHistorique;

    private boolean withSigElec;
}
