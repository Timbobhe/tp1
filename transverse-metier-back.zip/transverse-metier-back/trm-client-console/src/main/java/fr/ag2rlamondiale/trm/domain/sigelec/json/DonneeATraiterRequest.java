package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.TypeDonneeATraiter;
import lombok.Data;

@Data
public class DonneeATraiterRequest {
    private TypeDonneeATraiter typeDonneeATraitee;
    private String contenu;
    private Integer codeEtatWF;
    private Integer idDemandeWF;
}
