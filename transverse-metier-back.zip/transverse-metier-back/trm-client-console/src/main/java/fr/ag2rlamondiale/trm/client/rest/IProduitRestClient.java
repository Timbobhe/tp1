package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;

import java.util.List;

public interface IProduitRestClient {

    ProduitJson findByCodeOffreCommerciale(String codeFiliale, String codeOffreComm);

    List<ProduitJson> findByFiliales(List<String> codesFiliale);

    List<ProduitJson> findAll();
}
