package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.EtatDonneeATraiter;
import fr.ag2rlamondiale.trm.domain.sigelec.TypeDonneeATraiter;
import lombok.Data;

import java.io.Serializable;

@Data
public class DonneeATraiterJson implements Serializable {
    private static final long serialVersionUID = 2952590383757206890L;

    private TypeDonneeATraiter typeDonneeATraitee;
    private String contenu;
    private EtatDonneeATraiter etatDonne;
    private Integer codeEtatWF;
    private Integer idDemandeWF;

}
