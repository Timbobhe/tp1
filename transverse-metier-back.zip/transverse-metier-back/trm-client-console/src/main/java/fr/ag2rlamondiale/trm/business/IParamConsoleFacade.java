package fr.ag2rlamondiale.trm.business;

import fr.ag2rlamondiale.trm.business.impl.parametre.IParametreProvider;
import fr.ag2rlamondiale.trm.business.impl.produit.IProduitProvider;
import fr.ag2rlamondiale.trm.business.impl.qad.IQadProvider;
import fr.ag2rlamondiale.trm.domain.parametre.LibelleSupportType;

public interface IParamConsoleFacade extends IProduitProvider, IQadProvider, IParametreProvider {
    /**
     * Récupération des libellés des supports de type "Support" depuis la table TBCLXPRM.
     * Récupération des libellés de types grilles profils horizon depuis la table TBCL0SUP.
     */
    String getLibelleFrontSupport(String codeSupport, LibelleSupportType type);
}
