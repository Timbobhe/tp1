package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecCriteria;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecRequest;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecUpdate;

import java.util.List;

public interface ISigElecRestClient {

    List<SigElecJson> getDmdSigElecParEtatsOperationsPersonneContrat(SigElecCriteria cre);

    List<SigElecJson> getDmdSigElecEncoursNonSignees(String idGDI, String numContrat, OperationType operationType);

    List<SigElecJson> getDmdSigElecEncoursSignees(String idGDI, String numContrat, OperationType operationType);

    List<SigElecJson> getDmdSigElecEncours(String idGDI, String numContrat, OperationType operationType);

    List<SigElecJson> getDmdSigElecParEtats(String idGDI, String numContrat,
                                            List<EtatSigELec> etats, OperationType operationType);

    boolean createDmdSigElec(SigElecRequest sigElecJson);

    boolean updateDmdSigElec(SigElecUpdate sigElecUpdate);

    boolean updateDmdSigElecDocument(SigElecUpdate sigElecUpdate);

    List<SigElecJson> getDmdSigElecParEtatsOperationType(SigElecCriteria cre);

    boolean annulerDemandeSigElec(long idDemande);

    boolean annulerDemandeSigElecParIdExt(String idExt);
}
