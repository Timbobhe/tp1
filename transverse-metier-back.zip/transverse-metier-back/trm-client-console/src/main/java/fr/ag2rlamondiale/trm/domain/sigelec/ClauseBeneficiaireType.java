/*
 * Cree le 24 août 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.sigelec;

public enum ClauseBeneficiaireType {
    STD("STD", "STANDARD", "La clause dite « standard »", "1.0"),
    DMB("DMB", "DEMEMBREE", "", "1.0"),
    PFN("PFN", "POMPE FUNEBRE", "", "1.0"),
    NTS("NTS", "NANTISSEMENT", "", "1.0"),
    DLG("DLG", "DELEGATION", "", "1.0"),
    ONX("ONX", "ONEREUX", "", "1.0"),
    SPR("SPR", "SPECIALE AIDE REDACTION", "", "1.0"),
    SPS("SPS", "SPECIALE SAISIE", "", "1.0"),
    NTR("NTR", "NOTARIEE", "", "1.0"),
    MNS("MNS", "MANUSCRITE PAPIER", "", "1.0"),
    TUT("TUT", "TUTELLE CURATELLE", "", "1.0"),
    CGAR("CGAR", "Cession en garantie", "", "1.1"),
    MEG("MEG", "Mise en gage", "", "1.1"),
    NTSA("NTSA", "Nantissement arbitrage", "", "1.1"),
    PVA("PVA", "PV sais Attribution", "", "1.1"),
    TIE("TIE", "Tiers dét", "", "1.1"),
    NSTD("NSTD", "Non standard", "", "1.1"),
    LIB("LIB", "Libre", "La clause dite « à texte libre »", "1.2");

    private String code;
    private String label;
    private String version;
    private String descMetier;

    private ClauseBeneficiaireType(String code, String label, String version, String descMetier) {
        this.code = code;
        this.label = label;
        this.version = version;
        this.descMetier = descMetier;
    }

    public String getCode() {
        return code;
    }

    public String getLabel() {
        return label;
    }

    public String getVersion() {
        return version;
    }

    public String getDescMetier() {
        return descMetier;
    }
}
