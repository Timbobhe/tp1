/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IEvenementRestClient;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementRequeteJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementRequeteJson;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.CONSOLE_PARAM_CACHE;
import static fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils.jsonHttpEntity;
import static fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils.toList;

@Service
@Qualifier(value = "EvenementRest")
public class EvenementRestClientImpl implements IEvenementRestClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/evenementService/findEvenements")
    private String urlRechercherEvenement;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/evenementService/findTypesEvenements")
    private String urlRechercherTypeEvenement;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/evenementService/getTypesEvenements")
    private String urlGetTypesEvenements;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/evenementService/insert/insertPost")
    private String urlInsertEvenement;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/evenementService/update/updatePost")
    private String urlUpdateEvenement;

    /**
     * <pre>
     * SELECT evt.*
     * FROM TBCL0NOT evt
     * INNER JOIN TBCLXNTP typeEvt ON typeEvt.CONTP = evt.CONTP
     * INNER JOIN TBCLXNTC categorie ON categorie.CONTC = typeEvt.CONTC
     * WHERE evt.DTDEBNOT < CURRENT_DATE
     * AND (typeEvt.DTDEBVAL is null or typeEvt.DTDEBVAL < CURRENT_DATE)
     * AND (typeEvt.DTFINVAL is null or typeEvt.DTFINVAL > CURRENT_DATE)
     * AND evt.IDGDI = 'x27cfn'
     * AND (categorie.COAPPORI = 'A1324' OR 'A1324' is null)
     * ORDER by categorie.NOORD, typeEvt.NOORD
     * </pre>
     */
    @Override
    @LogError(category = "REST")
    public List<EvenementJson> rechercherEvenements(EvenementRequeteJson requete) {
        final EvenementJson[] evens = restTemplate.postForObject(urlRechercherEvenement,
                jsonHttpEntity(requete), EvenementJson[].class);
        return toList(evens);
    }

    /**
     * <pre>
     * SELECT 
     * typeEvt.* 
     * , categorie.*
     * FROM TBCLXNTP typeEvt
     * INNER JOIN TBCLXNTC categorie ON categorie.CONTC = typeEvt.CONTC
     * WHERE (typeEvt.DTDEBVAL is null or typeEvt.DTDEBVAL < CURRENT_DATE)
     * AND (typeEvt.DTFINVAL is null or typeEvt.DTFINVAL > CURRENT_DATE)
     * AND (categorie.COAPPORI = 'A1324' OR 'A1324' is null)
     * ORDER by categorie.NOORD, typeEvt.NOORD
     * </pre>
     */
    @Override
    @LogError(category = "REST")
    @NoAuthRequired
    @Cacheable(CONSOLE_PARAM_CACHE)
    public List<TypeEvenementJson> rechercherTypesEvenements(TypeEvenementRequeteJson requete) {
        final TypeEvenementJson[] typeEvens = restTemplate.postForObject(urlRechercherTypeEvenement,
                jsonHttpEntity(requete), TypeEvenementJson[].class);

        return toList(typeEvens);
    }

    @Override
    @LogError(category = "REST")
    @NoAuthRequired
    @Cacheable(CONSOLE_PARAM_CACHE)
    public List<TypeEvenementJson> getTypesEvenements() {
        final TypeEvenementJson[] typeEvens = restTemplate.getForObject(urlGetTypesEvenements, TypeEvenementJson[].class);

        return toList(typeEvens);
    }

    @Override
    @LogError(category = "REST")
    public EvenementJson insertEvenement(EvenementJson evenement) {
        final EvenementJson dto = new EvenementJson();
        dto.setDateDebut(evenement.getDateDebut());
        dto.setDateFin(evenement.getDateFin());
        dto.setEtatTraitement(evenement.getEtatTraitement());
        dto.setIdGdi(evenement.getIdGdi());
        dto.setNumContrat(evenement.getNumContrat());
        final TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setCodeEvenement(evenement.getTypeEvenement().getCodeEvenement());
        dto.setTypeEvenement(typeEven);

        return restTemplate.postForObject(urlInsertEvenement, jsonHttpEntity(dto),
                EvenementJson.class);
    }

    @Override
    @LogError(category = "REST")
    public EvenementJson updateEvenement(EvenementJson evenement) {
        final EvenementJson dto = new EvenementJson();
        dto.setId(evenement.getId());
        dto.setIdGdi(evenement.getIdGdi());
        dto.setNumContrat(evenement.getNumContrat());
        dto.setDateDebut(evenement.getDateDebut());
        dto.setDateFin(evenement.getDateFin());
        dto.setEtatTraitement(evenement.getEtatTraitement());

        return restTemplate.postForObject(urlUpdateEvenement, jsonHttpEntity(dto),
                EvenementJson.class);
    }
}
