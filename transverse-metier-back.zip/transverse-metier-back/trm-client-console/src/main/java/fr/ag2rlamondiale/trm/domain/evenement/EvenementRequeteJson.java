/*
 * Cree le 4 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * Objet utilisé pour requêter sur les évènements.
 */
@Data
public class EvenementRequeteJson implements Serializable {
    private static final long serialVersionUID = -5985582452858460818L;

    @JsonProperty(value = "codeApp")
    private String codeApp;

    @JsonProperty(value = "idGdi")
    private String idGdi;

    @JsonProperty(value = "date")
    private Date date;
}
