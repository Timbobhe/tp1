package fr.ag2rlamondiale.trm.domain.paiement;

import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.annotation.Nullable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FindRequestPaiementCbUtilisateurJson {

    private String idGDI;

    private AccesApp codeApp;

    private OperationType typeOp;

    private Date dateValiditeMin;

    @Nullable
    private Date dateValiditeMax;

    private boolean withContext;

    private boolean withHistorique;

    private boolean withSigElec;
}
