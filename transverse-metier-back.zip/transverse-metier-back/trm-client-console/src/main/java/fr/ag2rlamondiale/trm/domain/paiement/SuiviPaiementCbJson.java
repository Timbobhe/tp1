package fr.ag2rlamondiale.trm.domain.paiement;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SuiviPaiementCbJson implements Comparable<SuiviPaiementCbJson> {
    private EtatPaiementCB etat;
    private String codeErreur;
    private String libelleErreur;
    private Date dateCreation;

    @Override
    public int compareTo(SuiviPaiementCbJson o) {
        return this.dateCreation.compareTo(o.dateCreation);
    }
}
