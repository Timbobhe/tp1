package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.client.rest.IProduitRestClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.constantes.Constantes;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.*;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

@Slf4j
@Service
@Primary
public class ProduitProviderImpl implements IProduitProvider, SelfReferencingBean, ICacheProduitProvider {

    @Autowired
    @Setter
    private IProduitRestClient produitRestClient;

    @Autowired
    @Setter
    private CacheManager cacheManager;

    private ICacheProduitProvider springProxy;


    @Override
    public ProduitJson findProduitMdpro(String codeOffreComm) {
        return loadProduitMdpro().get(codeOffreComm.trim().toUpperCase());
    }

    private Map<String, ProduitJson> loadProduitMdpro() {
        return this.springProxy.findProduitsByFiliale(Constantes.FILIALE_MDPRO);
    }

    private String getCodeOffreComm(ProduitJson produit) {
        return getkey(produit.getTypeContrat(), produit.getNumeroGeneration());
    }


    @Override
    public Optional<ProduitJson> findProduitEre(String filiale, String typeCon, String numGen) {
        String key = getkey(typeCon, numGen);
        final ProduitJson produitJson = this.springProxy.findProduitsByFiliale(filiale).get(key);
        return Optional.ofNullable(produitJson);
    }

    @Override
    public void reloadCache() {
        try {
            clearCache();
            loadProduitMdpro();
        } catch (Exception ignore) {
            // ignore
        }
    }

    @Override
    public void clearCache() {
        final Cache cache = cacheManager.getCache(CACHE_FIND_PRODUITS_BY_FILIALE);
        if (cache != null) {
            cache.clear();
        }
    }

    @NoAuthRequired
    @Override
    @Cacheable(cacheNames = CACHE_FIND_PRODUITS_BY_FILIALE, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public Map<String, ProduitJson> findProduitsByFiliale(String filiale) {
        log.info("Chargement des produits {}", filiale);
        try {
            List<ProduitJson> produits = produitRestClient.findByFiliales(Collections.singletonList(filiale));
            Map<String, ProduitJson> res = new HashMap<>();
            for (ProduitJson produit : produits) {
                String codeOffreComm = getCodeOffreComm(produit);
                res.put(codeOffreComm, produit);
            }
            log.info("Fin du chargement de {} produits {}", filiale, res.size());
            return Collections.unmodifiableMap(res);
        } catch (Exception e) {
            log.error("Erreur pendant le chargement des Produits {}", filiale, e);
            throw e;
        }
    }

    @Override
    public void setProxy(Object proxy) {
        springProxy = (ICacheProduitProvider) proxy;
    }
}
