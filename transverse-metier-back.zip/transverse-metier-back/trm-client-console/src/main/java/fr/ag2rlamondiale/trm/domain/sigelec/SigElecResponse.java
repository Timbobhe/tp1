/*
 * Cree le 25 août 2017.
 * (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.sigelec;

import java.io.Serializable;

public class SigElecResponse implements Serializable {
    /**
     * Commentaire pour <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = -7765165701915635199L;

    private Etat etat;

    public Etat getEtat() {
        return etat;
    }

    public void setEtat(Etat etat) {
        this.etat = etat;
    }

    public enum Etat {
        SUCCESS,
        FAILED;
    }
}
