package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.domain.blocage.ProduitContratJson;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerimetreJson implements Serializable {
    private static final long serialVersionUID = 5100089300109559702L;

    private PerimetreType typePerimetre;
    private String valeurPerimetre;

    public boolean matchContrat(ProduitContratJson data) {
        if (PerimetreType.TOUT.equals(typePerimetre)) {
            return true;
        }

        if (typePerimetre.isContrat()) {
            return PerimetreType.CONTRAT.matchPerimetre(data.getNumContrat(), this)
                    || PerimetreType.FILIALE.matchPerimetre(data.getFiliale(), this)
                    || PerimetreType.PRODUIT.matchPerimetre(data.getProduit(), this);
        }

        return false;
    }

    public boolean matchPersonne(ProduitContratJson data) {
        return matchPersonne(data.getNumPersonne());
    }

    public boolean matchPersonne(String numPersonne) {
        if (PerimetreType.TOUT.equals(typePerimetre)) {
            return true;
        }

        if (typePerimetre.isPersonne()) {
            return PerimetreType.PERSONNE.matchPerimetre(numPersonne, this);
        }
        return false;
    }

    public boolean match(ProduitContratJson data) {
        return matchContrat(data) || matchPersonne(data);
    }
}
