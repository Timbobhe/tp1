package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class SigElecUpdate {
    private String idCustomExt;
    private String idTransactionExt;
    private String idContrat;
    private String numeroAssure;
    private List<DocumentJson> listDocs;
    private EtatSigELec etatSuiviDemande;
    private String messageErreur;
    private Boolean analyse;
}
