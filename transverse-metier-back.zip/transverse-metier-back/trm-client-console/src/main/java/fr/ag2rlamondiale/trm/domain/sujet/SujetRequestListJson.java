package fr.ag2rlamondiale.trm.domain.sujet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SujetRequestListJson {
    private static final long serialVersionUID = 4312483975874423147L;

    private String idGdi;
    private List<Integer> idSujets;
}
