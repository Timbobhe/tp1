package fr.ag2rlamondiale.trm.domain.parametre;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RequestParametreDto {
    private String typeParam;
    private LocalDate date;
}
