package fr.ag2rlamondiale.trm.domain.sujet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LectureSujetJson {
    private static final long serialVersionUID = -2652841805921974864L;

    private String idGdi;
    private Date dateLecture;
    private SujetJson sujet;
}
