package fr.ag2rlamondiale.trm.domain.sigelec;

public enum EtatDonneeATraiter {
    TRAI("TRAI", "Traité"),
    ATRAI("ATRAI", "A traiter"),
    ERRO("ERRO", "En Erreur"),
    ENCO("ENCO", "En cours");

    private String code;
    private String label;

    private EtatDonneeATraiter(String code, String label) {
        this.code = code;
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public String getLabel() {
        return label;
    }

    public static EtatDonneeATraiter getEtatFromLabel(String label) {
        for (EtatDonneeATraiter etat : values()) {
            if (etat.getLabel().equals(label)) {
                return etat;
            }
        }
        return null;
    }
}
