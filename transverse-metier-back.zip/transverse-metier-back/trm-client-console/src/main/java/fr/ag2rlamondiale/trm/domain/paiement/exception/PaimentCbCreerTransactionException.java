package fr.ag2rlamondiale.trm.domain.paiement.exception;

import lombok.Getter;

@Getter
public class PaimentCbCreerTransactionException extends RuntimeException {

    private final String codeErreur;
    private final String libelleErreur;

    public PaimentCbCreerTransactionException(String codeErreur, String libelleErreur) {
        this((String) null, codeErreur, libelleErreur);
    }

    public PaimentCbCreerTransactionException(String message, String codeErreur, String libelleErreur) {
        super(message);
        this.codeErreur = codeErreur;
        this.libelleErreur = libelleErreur;
    }

    public PaimentCbCreerTransactionException(String message, Throwable cause, String codeErreur, String libelleErreur) {
        super(message, cause);
        this.codeErreur = codeErreur;
        this.libelleErreur = libelleErreur;
    }

    public PaimentCbCreerTransactionException(Throwable cause, String codeErreur, String libelleErreur) {
        super(cause);
        this.codeErreur = codeErreur;
        this.libelleErreur = libelleErreur;
    }

}
