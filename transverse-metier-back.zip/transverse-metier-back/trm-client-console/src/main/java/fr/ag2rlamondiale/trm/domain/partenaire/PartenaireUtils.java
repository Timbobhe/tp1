package fr.ag2rlamondiale.trm.domain.partenaire;

public class PartenaireUtils {
    private PartenaireUtils() {
        // Utility class
    }

    public static String temporaryUserId(Integer cxpId) {
        return "ID_" + cxpId;
    }
}
