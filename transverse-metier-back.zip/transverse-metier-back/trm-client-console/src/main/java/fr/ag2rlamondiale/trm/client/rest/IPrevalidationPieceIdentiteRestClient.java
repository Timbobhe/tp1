package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.prevalidpieceident.PrevalidationPieceIdentiteJson;

public interface IPrevalidationPieceIdentiteRestClient {
	
	PrevalidationPieceIdentiteJson getPrevalidationByIdGdi(String idGdi);

	PrevalidationPieceIdentiteJson createPrevalidation(PrevalidationPieceIdentiteJson prevalidation);

}
