package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.qad.*;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.CONSOLE_PARAM_CACHE;
import static fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils.toList;

@Slf4j
@Service
public class QadRestClientImpl implements IQadRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/qadService/getSupportsInvestissement")
    private String urlGetSupportsInvestissement;


    @Value("${ere.consoleadmin.ws.rest.root.uri}/qadService/getTypesProfilParProfils")
    private String urlGetTypesProfilParProfils;
    
    @Value("${ere.consoleadmin.ws.rest.root.uri}/qadService/getQuestionsParProfils")
    private String urlGetQuestionsReponses;
    
    @Value("${ere.consoleadmin.ws.rest.root.uri}/qadService/getPropositionsParProduit")
    private String urlGetPropositionParProduit;

    @NoAuthRequired
    @Cacheable(CONSOLE_PARAM_CACHE)
    @LogExecutionTime
    @LogError(category = "REST")
    @Override
    public List<SupportInvestissementJson> getSupportsInvestissement() {
        final SupportInvestissementJson[] supports = restTemplate
                .getForObject(urlGetSupportsInvestissement, SupportInvestissementJson[].class);

        return toList(supports);
    }

    @NoAuthRequired
    @Cacheable(CONSOLE_PARAM_CACHE)
    @LogExecutionTime
    @LogError(category = "REST")
    @Override
    public List<TypeProfilJson> getTypesProfilParProfils(Set<CodeProfilType> codeProfils) {
        TypeProfilRequest request = new TypeProfilRequest(new ArrayList<>(codeProfils));
        final TypeProfilJson[] typesProfil = restTemplate
                .postForObject(urlGetTypesProfilParProfils, request, TypeProfilJson[].class);
        return toList(typesProfil);
    }
    
    @Override
	public List<QuestionJson> getQuesRepByProfil(Set<CodeProfilType> codeProfils) {
		QuestionRequest request = new QuestionRequest();
		List<CodeProfilType> profilList = new ArrayList<>();
		profilList.addAll(codeProfils);
		request.setCodeProfils(profilList);
		QuestionJson[] questionsReponses = restTemplate.postForObject(urlGetQuestionsReponses, request, QuestionJson[].class);
		return toList(questionsReponses);
	}
    
    @Override
	public List<PropositionJson> getPropositionsParProduit(PropositionRequest requete) { 
	PropositionJson[] propositions = restTemplate.postForObject(urlGetPropositionParProduit, requete, PropositionJson[].class);
	return Arrays.asList(propositions);
	}
}
