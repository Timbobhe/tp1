package fr.ag2rlamondiale.trm.domain.paiement;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class PaiementCbJson {
    private Long id;

    /**
     * Identifiant externe utiliser pour revenir sur l'espace client suite à redirection 3DS
     */
    private String idExterne;

    /**
     * Id de la transaction retourné par le service CreerTransactionPaiementDigital
     */
    private String idTransactionPaiementCB;

    private AccesApp codeApp;

    private OperationType typeOp;


    // Identifiant interne Compte utilisateur HG
    private String idGDI;

    private String codePartenaire;

    // Identifiant contrat CL
    private String idContrat;

    // Numero d'assure
    private String numeroAssure;

    private String libCompartiment;

    private CodeSiloType codeSilo;

    private BigDecimal montant;

    private EtatPaiementCB etat;

    private String codeErreur;

    private String libelleErreur;

    private String codeFormatContexte;

    @ToString.Exclude
    private String valeurContexte;

    private Boolean analyse;

    private Date dateFinValidite;

    private Date dateCreation;

    private Date dateMiseAjour;

    private List<SuiviPaiementCbJson> historique;

    private List<SigElecJson> demandesSigElec;
}
