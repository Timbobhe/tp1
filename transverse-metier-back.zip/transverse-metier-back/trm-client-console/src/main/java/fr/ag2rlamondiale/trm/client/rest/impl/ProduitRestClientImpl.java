package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IProduitRestClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.commun.RechercheProduitJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class ProduitRestClientImpl implements IProduitRestClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/commun/produit/search")
    private String urlFindProduit;

    @Override
    public ProduitJson findByCodeOffreCommerciale(String codeFiliale, String codeOffreComm) {
        RechercheProduitJson requete = new RechercheProduitJson(codeFiliale, codeOffreComm);
        return restTemplate.postForObject(urlFindProduit, JsonHttpEntityUtils.jsonHttpEntity(requete), ProduitJson.class);
    }

    @Override
    public List<ProduitJson> findByFiliales(List<String> codesFiliale) {
        RechercheProduitJson requete = new RechercheProduitJson(codesFiliale, null);
        final ProduitJson[] produits = restTemplate.postForObject(urlFindProduit, JsonHttpEntityUtils.jsonHttpEntity(requete), ProduitJson[].class);
        return JsonHttpEntityUtils.toList(produits);
    }

    @Override
    public List<ProduitJson> findAll() {
        RechercheProduitJson requete = new RechercheProduitJson();
        final ProduitJson[] produits = restTemplate.postForObject(urlFindProduit, JsonHttpEntityUtils.jsonHttpEntity(requete), ProduitJson[].class);
        return JsonHttpEntityUtils.toList(produits);
    }
}
