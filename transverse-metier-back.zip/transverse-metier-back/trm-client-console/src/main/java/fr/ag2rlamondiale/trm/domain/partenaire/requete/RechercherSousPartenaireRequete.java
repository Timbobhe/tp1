/*
 * Cree le 19 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.partenaire.requete;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class RechercherSousPartenaireRequete implements Serializable {
    private static final long serialVersionUID = 6881416690554283974L;

    private String idPartenairePrincial;
    private List<String> idContratsPers;
}
