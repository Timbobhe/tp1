package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Data;

import java.util.List;

@Data
public class TypePropositionJson {
    private long idTypPro;
    private String libelleTypeProposition;
    private List<RepartitionSupportJson> repartitionSupports;
    private List<PropositionJson> propositions;
}
