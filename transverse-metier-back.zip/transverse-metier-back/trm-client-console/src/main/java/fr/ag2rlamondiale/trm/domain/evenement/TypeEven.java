package fr.ag2rlamondiale.trm.domain.evenement;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.apache.commons.collections4.CollectionUtils.isEmpty;

public enum TypeEven {

    ONBOARDING("RET_ONBR"),
    INDISPO_ERE("ERE_MSG_INDISPO"),
    INDISPO_MDP("MDP_MSG_INDISPO"),
    CGU("PRT_CGU"),
    PND3("ERE_PND_3"),
    PND1("ERE_PND_1"),
    CONFIRMATION_DONNEES_PERSO("ERE_CONF"),
    VALIDATION_PERIODIQUE_DONNEES_PERSO("ERE_VDPP");

    private String code;

    TypeEven(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static Set<String> convert(Collection<TypeEven> typesEven) {
        if (isEmpty(typesEven)) {
            return Collections.emptySet();
        }
        return typesEven.stream().map(TypeEven::getCode).collect(Collectors.toSet());
    }

    public Predicate<TypeEvenementJson> toPredicate() {
        return typeEvenementJson -> this.getCode().equals(typeEvenementJson.getCodeEvenement());
    }
}
