package fr.ag2rlamondiale.trm.domain.prevalidpieceident;

public enum TypePieceIdentite {
	CIN, PASSEPORT;
}
