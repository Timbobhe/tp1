/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.rest;


import fr.ag2rlamondiale.trm.domain.evenement.EvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.EvenementRequeteJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementRequeteJson;

import java.util.List;

/**
 * RestService qui appelle la Console
 */
public interface IEvenementRestClient {
    List<EvenementJson> rechercherEvenements(EvenementRequeteJson requete);

    List<TypeEvenementJson> rechercherTypesEvenements(TypeEvenementRequeteJson requete);

    List<TypeEvenementJson> getTypesEvenements();

    EvenementJson insertEvenement(EvenementJson evenement);

    EvenementJson updateEvenement(EvenementJson evenement);
}
