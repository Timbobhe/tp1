package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.parametre.RequestParametreDto;

import java.util.List;

public interface IParametreRestClient {
    List<ParametreDto> getParametres(RequestParametreDto req);
}
