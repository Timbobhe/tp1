package fr.ag2rlamondiale.trm.domain.commun;

import lombok.Data;

@Data
public class ProduitJson {

    private String typeContrat;
    private String codeFiliale;
    private String numeroGeneration;
    private String libelle;
    private String libelleFiscalite;
    private Boolean deductible;
}
