package fr.ag2rlamondiale.trm.domain.paiement.exception;

public class PaimentCbEtatException extends PaimentCbException {

    public PaimentCbEtatException() {
    }

    public PaimentCbEtatException(String message) {
        super(message);
    }

    public PaimentCbEtatException(String message, Throwable cause) {
        super(message, cause);
    }

    public PaimentCbEtatException(Throwable cause) {
        super(cause);
    }

    public PaimentCbEtatException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
