package fr.ag2rlamondiale.trm.domain.parametre;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
public class ParametreDto {
    @EqualsAndHashCode.Include
    private Long id;
    private String typeParam;
    private String codeParam;
    private String libelleParam;
    private String valeur1;
    private String valeur2;
    private Date dateDebutValidite;
    private Date dateFinValidite;
    private Date dateCreation;
    private Date dateMiseAjour;

}
