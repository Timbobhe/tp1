package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

@Getter
public enum OperationType {
    ARBI("ARBI", "Arbitrage"),
    VR("VR", "Versement"),
    VRLI("VRLI", "Versement Libre"),
    VRPG("VRPG", "Versement Programmé"),
    CBF("CBF", "Clause Bénéficiaire"),
    RIBA("RIBA", "RIB"),
    EBIA("EBIA", "BIA"),
    LIQR("LIQR", "Liquidation Retraite");

    private String code;
    private String label;

    OperationType(String code, String label) {
        this.code = code;
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public String getLabel() {
        return label;
    }

    public static OperationType getOperationTypeFromLabel(String label) {
        for (OperationType etat : values()) {
            if (etat.getLabel().equals(label)) {
                return etat;
            }
        }

        return null;
    }
}
