package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ICguRestClient;
import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import fr.ag2rlamondiale.trm.log.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Slf4j
@Service
@Qualifier(value = "cguRest")
public class CguRestClientImpl implements ICguRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.pc.ws.inscriptionERE.token}")
    private String token;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/cguService/getaccepted")
    private String uriAcceptedCgu;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/cguService/create")
    private String uriCreateAcceptationCgu;

    @Value("${ere.pc.ws.rest.root.uri}/cgu")
    private String uriPCCgu;

    @Override
    @LogError(category = "REST")
    public CguDetails getCguDetails() {
        try {
            return restTemplate.exchange(uriPCCgu, HttpMethod.GET, jsonHttpEntityWithAuthorization(), CguDetails.class).getBody();
        } catch (RestClientException ex) {
            log.error("Erreur lors de la récupération des détails CGU", ex);
        }
        return null;
    }

    @Override
    @LogError(category = "REST")
    public List<String> getAcceptedGguIds(Integer idCxp) {
        try {
            final String[] cguIds = restTemplate.postForObject(uriAcceptedCgu,
                    idCxp.toString(), String[].class);
            return Arrays.asList(cguIds);
        } catch (RestClientException ex) {
            log.error("Erreur lors de la recupération des CGU Ids", ex);
        }
        return Collections.emptyList();
    }

    @Override
    @LogError(category = "REST")
    public boolean createAcceptationCgu(Integer idCxp, String idCgu) {
        try {
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            map.add("idCxp", idCxp.toString());
            map.add("idCgu", idCgu);

            final ResponseEntity<String> response = restTemplate.exchange(uriCreateAcceptationCgu, HttpMethod.POST, formHttpEntity(map), String.class);
            log.info("Acceptation cr\u00e9\u00e9e {}", response);
            return response != null;
        } catch (RestClientException ex) {
            log.error("Erreur lors de la cr\u00e9ation de l'Acceptation CGU", ex);
            return false;
        }
    }

    private HttpEntity<MultiValueMap<String, String>> formHttpEntity(MultiValueMap<String, String> map) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return new HttpEntity<>(map, headers);
    }

    private HttpEntity<String> jsonHttpEntityWithAuthorization() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", token);
        return new HttpEntity<>(headers);
    }
}
