package fr.ag2rlamondiale.trm.domain.prevalidpieceident;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
public class PrevalidationPieceIdentiteJson {

    @EqualsAndHashCode.Include
    private String idGdi;

    private String cleValidation;
    private TypePieceIdentite typePieceIdentite;
    private String doc1;
    private String doc2;
}
