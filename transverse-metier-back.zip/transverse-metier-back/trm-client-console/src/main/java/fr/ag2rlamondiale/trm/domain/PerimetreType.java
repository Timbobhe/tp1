package fr.ag2rlamondiale.trm.domain;

public enum PerimetreType {
    CONTRAT, FILIALE, IDGDI, PERSONNE, PRODUIT, TOUT;

    public boolean isPersonne() {
        return this == TOUT || this == PERSONNE || this == IDGDI;
    }

    public boolean isContrat() {
        return this == TOUT || this == FILIALE || this == PRODUIT || this == CONTRAT;
    }

    public boolean matchPerimetre(String value, PerimetreJson perimetre) {
        if (this != perimetre.getTypePerimetre() || value == null) {
            return false;
        }
        return value.equalsIgnoreCase(perimetre.getValeurPerimetre()) || "*".equals(perimetre.getValeurPerimetre());
    }
}
