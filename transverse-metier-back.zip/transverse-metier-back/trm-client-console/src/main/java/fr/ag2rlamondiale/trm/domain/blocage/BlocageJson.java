package fr.ag2rlamondiale.trm.domain.blocage;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.ag2rlamondiale.trm.domain.PerimetreJson;
import lombok.*;

import java.util.List;

@Data
@Builder(builderMethodName = "blocageJsonBuilder")
@EqualsAndHashCode(of = "idBlo", callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class BlocageJson extends PerimetreJson {
    private static final long serialVersionUID = -4345291747986613629L;

    private Integer idBlo;
    private String typeAcces;
    private String commentaire;
    private String lidBlocage;
    private String lidDeblocage;
    private String dateCreation;
    private String codeSiloType;
    private List<FonctionnaliteJson> fonctionnalites;
    private List<ExceptionBlocageJson> exceptionBlocages;

    public boolean noneMatchException(ProduitContratJson data) {
        if (exceptionBlocages == null || exceptionBlocages.isEmpty()) {
            return true;
        }
        return exceptionBlocages.stream().noneMatch(exceptionBlocageJson -> exceptionBlocageJson.match(data));
    }

    public boolean noneMatchException(String numPersonne) {
        ProduitContratJson data = new ProduitContratJson();
        data.setNumPersonne(numPersonne);
        return noneMatchException(data);
    }

    @JsonIgnore
    public boolean isToutesFonctionnalites() {
        return getFonctionnalites() == null || getFonctionnalites().isEmpty();
    }
}
