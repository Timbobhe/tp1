package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.EtatDonneeATraiter;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class SuiviDemandeJson implements Serializable {
    /**
     * Commentaire pour <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = -7864857829931419365L;

    private EtatDonneeATraiter etatDemande;

    private Date dateMiseAJour;

}
