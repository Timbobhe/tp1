package fr.ag2rlamondiale.trm.domain.blocage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProduitContratJson implements Serializable {
    private static final long serialVersionUID = -704026107162689986L;

    private String numContrat;
    private String produit;
    private String filiale;
    private String numPersonne;
    private String codeSiloType;

    private List<FonctionnaliteJson> fonctionnalites;
    private List<ExceptionBlocageJson> exceptionBlocages;
}
