package fr.ag2rlamondiale.trm.domain.sujet;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class SujetJson {
    private static final long serialVersionUID = 5529865317883515553L;

    private Integer idSujet;
    private String titre;
    private String url;
    private CodeSiloType codeSilo;
    private Integer idSujetParent;
    private String typeSujet;
    private List<SujetJson> sousSujets;
}
