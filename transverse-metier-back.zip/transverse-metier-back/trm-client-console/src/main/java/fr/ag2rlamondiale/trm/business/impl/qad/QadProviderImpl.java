package fr.ag2rlamondiale.trm.business.impl.qad;

import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

@Slf4j
@Service
@Primary
public class QadProviderImpl implements IQadProvider, SelfReferencingBean, ICacheQadProvider {


    @Autowired
    private IQadRestClient qadRestClient;

    @Autowired
    @Setter
    private CacheManager cacheManager;

    private ICacheQadProvider springProxy;

    @Override
    public void reloadCache() {
        try {
            clearCache();
            this.springProxy.findSupportInvestissementJson();
        } catch (Exception ignore) {
            // ignore
        }
    }

    @Override
    public SupportInvestissementJson getSupportsInvestissement(String codeSupport) {
        return this.springProxy.findSupportInvestissementJson().get(codeSupport);
    }

    @Override
    public void clearCache() {
        final Cache cache = cacheManager.getCache(CACHE_FIND_SUPPORT_INVESTISSEMENT);
        if (cache != null) {
            cache.clear();
        }
    }

    @NoAuthRequired
    @Override
    @Cacheable(cacheNames = CACHE_FIND_SUPPORT_INVESTISSEMENT, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public Map<String, SupportInvestissementJson> findSupportInvestissementJson() {
        try {
            log.info("Chargement des supports investissement");
            final List<SupportInvestissementJson> supports = qadRestClient.getSupportsInvestissement();
            Map<String, SupportInvestissementJson> map = new HashMap<>();
            for (SupportInvestissementJson json : supports) {
                map.put(json.getCodeSupport(), json);
            }
            log.info("Fin du chargement des supports investissement {}", map.size());
            return map;
        } catch (Exception e) {
            log.error("Erreur pendant le chargement des supports Investissement", e);
            throw e;
        }
    }

    @Override
    public void setProxy(Object proxy) {
        springProxy = (ICacheQadProvider) proxy;
    }
}
