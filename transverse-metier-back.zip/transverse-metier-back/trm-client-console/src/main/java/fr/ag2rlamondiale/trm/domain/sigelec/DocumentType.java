package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

@Getter
public enum DocumentType {
    CPR(0, "Convention de preuve"),
    PIDE(0, "Pièce d'identité"),
    RIBA(0, "Relevé d'identité bancaire"),
    ACTE(0, "Acte de gestion"),
    QADE(0, "Résultat du QAD"),

    // Liquidation
    NR(0, "Non renseigné"),

    CID(39, "Carte d'identité"),
    LIAI(109, "Avis d'imposition"),
    RIB(149, "RIB"),
    JASM(230, "Justificatif assurance maladie"),
    JFPS(231, "Formulaire Prélèvements Sociaux"),
    JRFE(232, "Justificatif résidence fiscale étrangère"),
    JOF(233, "Justificatif Origines des fonds"),
    NSS(253, "Notification Sécurité Sociale"),
    ACNA(254, "Acte de naissance"),
    LVRT(255, "Livret de famille");

    private final int id;
    private final String label;

    DocumentType(int id, String aLabel) {
        this.id = id;
        this.label = aLabel;
    }
}
