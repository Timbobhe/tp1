/*
 * Cree le 19 oct. 2018.
 * (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.partenaire.requete;

import lombok.Data;

import java.io.Serializable;

@Data
public class MettreAJourIdgdiTemporaireRequete implements Serializable {
    private static final long serialVersionUID = -3252285974597236225L;

    private String codePartenaire;
    private String numPersEre;
    private String numPersMdp;
    private String idGdi;
}
