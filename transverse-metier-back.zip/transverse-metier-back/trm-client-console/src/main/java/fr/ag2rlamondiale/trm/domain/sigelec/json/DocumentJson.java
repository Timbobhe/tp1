package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.DocumentType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class DocumentJson implements Serializable {
    private static final long serialVersionUID = 7523549016573379085L;

    private String contenu;
    private DocumentType type;
}
