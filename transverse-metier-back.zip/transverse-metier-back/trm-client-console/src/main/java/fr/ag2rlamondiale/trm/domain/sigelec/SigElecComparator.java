package fr.ag2rlamondiale.trm.domain.sigelec;

import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecJson;

import java.util.Comparator;

public class SigElecComparator implements Comparator<SigElecJson> {
    @Override
    public int compare(SigElecJson o1, SigElecJson o2) {
        if (o1.getIdDemande() < o2.getIdDemande()) {
            return 1;
        } else if (o1.getIdDemande() > o2.getIdDemande()) {
            return -1;
        }
        return 0;
    }
}
