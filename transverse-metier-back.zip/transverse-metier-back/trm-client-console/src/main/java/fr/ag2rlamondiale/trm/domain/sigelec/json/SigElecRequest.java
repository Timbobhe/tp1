package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
public class SigElecRequest {
    private String idCustomExt;
    private OperationType typeOpe;
    private AccesApp codeApp;
    private String idGDI;
    private String numPersonne;
    private BigDecimal montant;
    private String codePartenaire;
    private String codeDepartement;
    private Date dateNaissancePersonne;
    private String libCompartiment;
    private Map<String, List<DonneeATraiterRequest>> donneeATraiter;
    private String idTransactionPaiementCB;
}
