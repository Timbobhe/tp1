package fr.ag2rlamondiale.trm.domain.commun;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Collections;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class RechercheProduitJson {
    private List<String> codesFiliale;

    private String codeOffreComm;

    public RechercheProduitJson(String codeFiliale, String codeOffreComm) {
        this(Collections.singletonList(codeFiliale), codeOffreComm);
    }
}
