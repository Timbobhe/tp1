package fr.ag2rlamondiale.trm.domain.paiement.exception;

public class PaimentCbException extends RuntimeException {

    public PaimentCbException() {
    }

    public PaimentCbException(String message) {
        super(message);
    }

    public PaimentCbException(String message, Throwable cause) {
        super(message, cause);
    }

    public PaimentCbException(Throwable cause) {
        super(cause);
    }

    public PaimentCbException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
