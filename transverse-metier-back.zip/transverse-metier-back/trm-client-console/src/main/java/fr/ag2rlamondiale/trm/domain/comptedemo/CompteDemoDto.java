package fr.ag2rlamondiale.trm.domain.comptedemo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CompteDemoDto {
    private Long id;
    private String numReferenceExterne;
    private String numPersonne;
    private String description;
    private Date dateCreation;
    private Date dateMiseAjour;
}

