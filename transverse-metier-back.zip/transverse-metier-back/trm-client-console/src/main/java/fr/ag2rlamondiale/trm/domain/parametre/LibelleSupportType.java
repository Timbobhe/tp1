package fr.ag2rlamondiale.trm.domain.parametre;

public enum LibelleSupportType {
    GRILLE_PROFIL_HORIZON,
    SUPPORT;
}
