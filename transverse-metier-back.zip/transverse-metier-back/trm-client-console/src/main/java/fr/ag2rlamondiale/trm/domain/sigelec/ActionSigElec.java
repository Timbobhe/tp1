package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

@Getter
public enum ActionSigElec {
    SUCCES("succes"), ANNULATION("annulation"), ECHEC("echec");

    private String code;

    ActionSigElec(String code) {
        this.code = code;
    }

    public static ActionSigElec get(String code) throws Exception {
        for (ActionSigElec value : ActionSigElec.values()) {
            if (code.equals(value.getCode())) {
                return value;
            }
        }
        return null;
    }
}
