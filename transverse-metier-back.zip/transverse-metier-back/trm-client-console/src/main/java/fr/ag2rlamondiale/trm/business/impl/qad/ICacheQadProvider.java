package fr.ag2rlamondiale.trm.business.impl.qad;

import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import org.springframework.cache.annotation.Cacheable;

import java.util.Map;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

interface ICacheQadProvider {
    String CACHE_FIND_SUPPORT_INVESTISSEMENT = "CACHE_FIND_SUPPORT_INVESTISSEMENT";

    @NoAuthRequired
    @Cacheable(cacheNames = CACHE_FIND_SUPPORT_INVESTISSEMENT, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    Map<String, SupportInvestissementJson> findSupportInvestissementJson();
}
