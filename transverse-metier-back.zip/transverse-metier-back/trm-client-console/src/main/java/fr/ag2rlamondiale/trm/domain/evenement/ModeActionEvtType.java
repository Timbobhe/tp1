package fr.ag2rlamondiale.trm.domain.evenement;

public enum ModeActionEvtType {
    OBLI("Obligatoire"), FACU("Facultatif"), INFO("Informatif");

    private String label;

    ModeActionEvtType(String label) {
        this.label = label;
    }

    /**
     * @return Renvoie label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * Renvoie le mode d'action en fonction du label.
     *
     * @param label
     * @return
     */
    public static ModeActionEvtType getModeActionFromLabel(String label) {
        for (ModeActionEvtType modeAction : values()) {
            if (modeAction.getLabel().equals(label)) {
                return modeAction;
            }
        }
        return null;
    }

    public boolean isObligatoire() {
        return OBLI.equals(this);
    }
}
