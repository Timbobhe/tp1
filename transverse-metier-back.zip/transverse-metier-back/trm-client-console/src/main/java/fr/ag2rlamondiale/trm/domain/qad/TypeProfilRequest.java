package fr.ag2rlamondiale.trm.domain.qad;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeProfilRequest {
    private List<CodeProfilType> codeProfils;
}
