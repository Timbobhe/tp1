package fr.ag2rlamondiale.trm.business.impl;

import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.business.impl.parametre.IParametreProvider;
import fr.ag2rlamondiale.trm.business.impl.produit.IProduitProvider;
import fr.ag2rlamondiale.trm.business.impl.qad.IQadProvider;
import fr.ag2rlamondiale.trm.cache.ClearableCache;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.mapping.ParamMapper;
import fr.ag2rlamondiale.trm.domain.parametre.LibelleSupportType;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class ParamConsoleFacadeImpl implements IParamConsoleFacade, ClearableCache, InitializingBean {

    public static final String DEPRECATED_RELOAD_CACHE_ACTIVE = "reloadCache.active";
    public static final String CONSOLE_PARAMS_RELOAD_CACHE_ACTIVE = "console.params.reloadCache.active";


    @Autowired
    private IProduitProvider produitProvider;

    @Autowired
    private IQadProvider qadProvider;

    @Autowired
    private IParametreProvider parametreProvider;

    @Autowired
    private PropertyResolver propertyResolver;

    @Autowired
    private ParamMapper paramMapper;

    @Getter
    @Setter
    private boolean reloadCacheActive = true;

    @Override
    public ProduitJson findProduitMdpro(String codeOffreComm) {
        return produitProvider.findProduitMdpro(codeOffreComm);
    }

    @Override
    public Optional<ProduitJson> findProduitEre(String filiale, String typeCon, String numGen) {
        return produitProvider.findProduitEre(filiale, typeCon, numGen);
    }

    @Override
    public SupportInvestissementJson getSupportsInvestissement(String codeSupport) {
        return qadProvider.getSupportsInvestissement(codeSupport);
    }

    @Override
    public List<ParametreDto> getParametres(String typeParam, Annee annee) {
        return parametreProvider.getParametres(typeParam, annee);
    }

    @Override
    public Optional<ParametreDto> getParametre(String typeParam, String codeParam, Annee annee) {
        return parametreProvider.getParametre(typeParam, codeParam, annee);
    }

    @Override
    public String getLibelleFrontSupport(String codeSupport, LibelleSupportType supportType) {
        if (LibelleSupportType.SUPPORT == supportType) {
            return getParametre("SUPPORT", codeSupport, null).map(ParametreDto::getLibelleParam).orElse(null);
        } else if (LibelleSupportType.GRILLE_PROFIL_HORIZON == supportType) {
            return getSupportsInvestissement(codeSupport) != null ? getSupportsInvestissement(codeSupport).getLibelleFront() : null;
        }
        return null;
    }

    @Scheduled(fixedRateString = "${console.param.cache.fixedRate:10800000}") // 3h
    public void reloadCache() {
        if (reloadCacheActive) {
            log.info("Début du rechargement du cache Param Console");
            produitProvider.reloadCache();
            qadProvider.reloadCache();
            parametreProvider.reloadCache();
            log.info("Fin du rechargement du cache Param Console");
        }
    }

    @NoAuthRequired
    @Async
    @EventListener(ContextRefreshedEvent.class)
    public void firstLoadCache() {
        reloadCache();
    }

    @Override
    public void clearCache() {
        reloadCache();
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        final String deprecatedParamReloadCache = propertyResolver.findProperty(DEPRECATED_RELOAD_CACHE_ACTIVE);
        final String paramReloadCache = propertyResolver.findProperty(CONSOLE_PARAMS_RELOAD_CACHE_ACTIVE);

        if (paramReloadCache == null && deprecatedParamReloadCache != null) {
            this.reloadCacheActive = Boolean.parseBoolean(deprecatedParamReloadCache);
        } else if (paramReloadCache != null) {
            this.reloadCacheActive = Boolean.parseBoolean(paramReloadCache);
        }

        if (deprecatedParamReloadCache != null) {
            log.warn("Le parametre {} est deprecated, utiliser {}", DEPRECATED_RELOAD_CACHE_ACTIVE, CONSOLE_PARAMS_RELOAD_CACHE_ACTIVE);
        }

        log.info("{}={}", CONSOLE_PARAMS_RELOAD_CACHE_ACTIVE, reloadCacheActive);
    }
}
