package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import org.mapstruct.Mapper;

@SuppressWarnings("squid:S1609") // Disable @FunctionalInterface warning
@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public interface PartenaireMapper {

    Partenaire map(PartenaireJson partenaireJson);
}
