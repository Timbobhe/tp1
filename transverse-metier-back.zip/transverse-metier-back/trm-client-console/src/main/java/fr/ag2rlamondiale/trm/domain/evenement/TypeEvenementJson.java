package fr.ag2rlamondiale.trm.domain.evenement;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@NoArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class TypeEvenementJson implements Serializable, Comparable<TypeEvenementJson> {
    private static final long serialVersionUID = 1393406195797909086L;

    @EqualsAndHashCode.Include
    private String codeEvenement;

    private CategorieJson categorie;
    private int ordre;
    private Long dateDebut;
    private Long dateFin;
    private Integer nbDeclenchementsMaxPeriode;

    /**
     * en jours
     */
    private Integer periodeDeclenchement;

    /**
     * en jours
     */
    private Integer delaiAvantReactivation;

    private ModeActionEvtType modeAction;
    private String titre;
    private String contenu;
    private String actionTraiter;
    private String actionAnnuler;
    private String lienRedirection;

    @EqualsAndHashCode.Exclude
    private List<PerimetreEvenementJson> perimetreEvenements;

    private String libEvenement;

    @JsonIgnore
    private boolean isDirty;

    public TypeEvenementJson(String codeEvenement) {
        this.codeEvenement = codeEvenement;
    }

    @Override
    public int compareTo(TypeEvenementJson o) {
        if (o == null) {
            return 1;
        }

        final int first = this.categorie.compareTo(o.getCategorie());
        if (first != 0) {
            return first;
        }

        return Integer.compare(this.ordre, o.getOrdre());
    }

    @JsonIgnore
    public boolean isObligatoire() {
        if (modeAction == null) {
            return false;
        }
        return modeAction.isObligatoire();
    }
}
