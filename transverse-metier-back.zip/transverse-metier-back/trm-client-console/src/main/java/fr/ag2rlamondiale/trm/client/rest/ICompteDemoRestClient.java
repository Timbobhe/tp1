package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.trm.domain.comptedemo.FindCompteDemoRequestDto;

public interface ICompteDemoRestClient {

    CompteDemoDto findCompteDemo(FindCompteDemoRequestDto req);

}
