package fr.ag2rlamondiale.trm.domain.qad;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PropositionJson {
    private int numeroProposition;
    private TypeProfilJson typeProfilEpargnant;
    private TypeProfilJson typeProfilInvestissement;
    private TypeProfilJson typeProfilERE;
    private TypePropositionJson typeProposition;
    private String typeContrat;
    private String numGenContrat;
}
