package fr.ag2rlamondiale.trm.domain.evenement;

import java.util.List;
import java.util.function.Predicate;

/**
 * Type Inclusion ou Exclusion du périmètre.
 *
 * @author mbarek
 */
public enum OperationPerimetre {
    INC("Inclusion"), EXC("Exclusion");

    private String label;

    OperationPerimetre(String label) {
        this.label = label;
    }

    /**
     * @return Renvoie label.
     */
    public String getLabel() {
        return label;
    }

    public boolean anyMatch(List<PerimetreEvenementJson> perimetresEvenements,
            Predicate<PerimetreEvenementJson> predicate) {
        return perimetresEvenements.stream()
                .anyMatch(perimetre -> perimetre.getOperationPerimetre() == this && predicate.test(perimetre));
    }
}
