package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of = "codeSupport", callSuper = false)
public class SupportInvestissementJson {
    private String codeSupport;
    private String libelleSupport;
    private String libelleFront;
    private String modeGestion;
}
