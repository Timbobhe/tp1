package fr.ag2rlamondiale.trm.domain.blocage;

import lombok.Data;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Data
public class Fonctionnalites {
    private boolean toute;
    private Set<String> details = new HashSet<>();

    public void add(BlocageJson blocageJson) {
        if (blocageJson.isToutesFonctionnalites()) {
            this.toute = true;
        } else {
            blocageJson.getFonctionnalites()
                    .forEach(fonctionnaliteJson -> add(fonctionnaliteJson.getCodeFct()));
        }
    }

    public boolean add(String code) {
        return details.add(code);
    }

    public boolean addAll(Collection<? extends String> codes) {
        return details.addAll(codes);
    }

    public boolean contains(String code) {
        if (isToute()) {
            return true;
        }
        return this.details.contains(code);
    }

    public boolean containsAll(List<String> codes) {
        if (isToute()) {
            return true;
        }
        return this.details.containsAll(codes);
    }

    /**
     * Si un contrat est bloque sur toutes les fonctionnalites, la liste sera vide
     *
     * @return
     */
    public Set<String> toOldSemantic() {
        if (toute) {
            return Collections.emptySet();
        }
        return new HashSet<>(details);
    }

    /**
     * Si un contrat est bloque sur toutes les fonctionnalites, la liste sera vide
     *
     * @param map
     * @return
     */
    public static Map<String, Set<String>> toOldSemantic(Map<String, Fonctionnalites> map) {
        Map<String, Set<String>> res = new HashMap<>();
        map.forEach((code, fonctionnalies) -> {
            if (!fonctionnalies.isAucune()) {
                res.put(code, fonctionnalies.toOldSemantic());
            }
        });
        return res;
    }

    public static Set<String> cumulFonctionnalites(Collection<Fonctionnalites> fonctionnalies) {
        return fonctionnalies.stream().map(Fonctionnalites::getDetails).flatMap(Collection::stream).collect(Collectors.toSet());
    }

    public int size() {
        return details.size();
    }

    public void forEach(Consumer<? super String> action) {
        details.forEach(action);
    }

    public boolean isAucune() {
        return !toute && details.isEmpty();
    }
}
