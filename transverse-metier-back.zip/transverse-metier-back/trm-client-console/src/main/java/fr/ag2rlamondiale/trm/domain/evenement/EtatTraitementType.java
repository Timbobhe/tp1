/*
 * Cree le 24 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

public enum EtatTraitementType {
    TRAI, ANNU;
}
