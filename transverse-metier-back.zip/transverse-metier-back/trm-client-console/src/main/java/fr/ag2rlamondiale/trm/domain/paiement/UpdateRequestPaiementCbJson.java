package fr.ag2rlamondiale.trm.domain.paiement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Permet d'indiquer les attributs qui seront mis à jour
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpdateRequestPaiementCbJson {
	private boolean etat;
	private boolean idTransaction;
	private boolean erreur;
	private boolean analyse;

	/**
	 * Retour avec le contexte
	 */
	private boolean withContext;

	private PaiementCbJson dto;
}
