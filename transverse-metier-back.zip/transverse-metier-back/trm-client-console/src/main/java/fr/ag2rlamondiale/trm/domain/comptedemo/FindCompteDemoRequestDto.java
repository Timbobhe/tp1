package fr.ag2rlamondiale.trm.domain.comptedemo;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@NonNull
@Builder
@Data
public class FindCompteDemoRequestDto {
    private String numReferenceExterne;
    private String numPersonne;
}
