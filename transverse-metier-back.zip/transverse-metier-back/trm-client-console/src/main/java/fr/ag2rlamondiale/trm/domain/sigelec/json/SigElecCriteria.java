package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import lombok.Data;

import java.util.List;

@Data
public class SigElecCriteria {
    private String idCustomExt;

    private List<OperationType> typesOperation;

    private List<String> contrats;

    private List<String> numerosPersonne;

    private String idGDI;

    private List<EtatSigELec> etats;

    private long dateDebut;

    private long dateFin;

}
