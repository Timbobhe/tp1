package fr.ag2rlamondiale.trm.business.impl.parametre;

import fr.ag2rlamondiale.trm.business.IParamConsoleProvider;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;

import java.util.List;
import java.util.Optional;

public interface IParametreProvider extends IParamConsoleProvider {

    List<ParametreDto> getParametres(String typeParam, Annee annee);

    Optional<ParametreDto> getParametre(String typeParam, String codeParam, Annee annee);
}
