/*
 * Cree le 4 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class CategorieJson implements Serializable, Comparable<CategorieJson> {
    private static final long serialVersionUID = -7223194417525428893L;

    @EqualsAndHashCode.Include
    private String codeCategorie;

    private String codeApplication;

    private int ordre;

    private String description;

    @Override
    public int compareTo(CategorieJson o) {
        if(o == null){
            return 1;
        }
        return Integer.compare(this.ordre, o.getOrdre());
    }
}
