package fr.ag2rlamondiale.trm.client.rest;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.blocage.BlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.ProduitContratJson;

import javax.annotation.Nonnull;
import java.util.List;

public interface IBlocageRestClient {

    List<BlocageJson> rechercherBlocages(String numPersonne, @Nonnull CodeApplicationType typeAcces,
                                                List<ProduitContratJson> produitContratJsonList) throws TechnicalException;
}
