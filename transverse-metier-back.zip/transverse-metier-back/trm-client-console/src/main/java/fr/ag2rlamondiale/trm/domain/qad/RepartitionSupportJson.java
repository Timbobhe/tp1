package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Data;

@Data
public class RepartitionSupportJson {
    private int pourcentage;
    private TypePropositionJson typeProposition;
    private SupportInvestissementJson supportInvestissement;
}
