package fr.ag2rlamondiale.trm.domain.trace;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.base.MoreObjects;
import fr.ag2rlamondiale.trm.domain.CodeActionType;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class TraceJson implements Serializable {

    private static final long serialVersionUID = 2459821735921505787L;

    @JsonProperty(value = "codeApp")
    @EqualsAndHashCode.Include
    private String codApp;

    @EqualsAndHashCode.Include
    private String idGdi;

    private String codePartenaire;
    private String codeSilo;

    @JsonIgnore
    @EqualsAndHashCode.Include
    private String codeAction;

    @JsonProperty(value = "dateDebut")
    private Date startInteraction;

    @JsonProperty(value = "dateFin")
    private Date endInteraction;

    @JsonProperty(value = "numPerson")
    @EqualsAndHashCode.Include
    private String numPer;

    @JsonProperty(value = "numContrat")
    @EqualsAndHashCode.Include
    private String numCon;

    /**
     * Pour ERE la raison sociale de la contractante.
     */
    @JsonProperty(value = "titulaireContrat")
    private String titulaire;

    @JsonProperty(value = "lidImpersonation")
    private String topImpersonnation;

    @JsonProperty(value = "navigateurWeb")
    private String nav;

    private String zone1;
    private String zone2;
    private String zone3;

    @JsonIgnore
    private boolean traceErreur;


    @JsonProperty(value = "codeAction")
    public String getCodeAction() {
        return (codeAction != null) ? codeAction : null;
    }

    @JsonIgnore
    public String getCodeActionName() {
        return (codeAction != null) ? codeAction : null;
    }

    @JsonIgnore
    public long getDuree() {
        if (endInteraction == null || startInteraction == null) {
            return 0;
        }
        return endInteraction.getTime() - startInteraction.getTime();
    }

    @JsonIgnore
    public String getNav() {
        return nav;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .omitNullValues()
                .add("codApp", codApp)
                .add("idGdi", idGdi)
                .add("codePartenaire", codePartenaire)
                .add("codeSilo", codeSilo)
                .add("codeAction", codeAction)
                .add("startInteraction", startInteraction)
                .add("endInteraction", endInteraction)
                .add("numPer", numPer)
                .add("numCon", numCon)
                .add("titulaire", titulaire)
                .add("topImpersonnation", topImpersonnation)
                .add("nav", nav)
                .add("zone1", traceErreur ? "ERREUR" : zone1)
                .add("zone2", zone2)
                .add("zone3", zone3)
                .toString();
    }
}
