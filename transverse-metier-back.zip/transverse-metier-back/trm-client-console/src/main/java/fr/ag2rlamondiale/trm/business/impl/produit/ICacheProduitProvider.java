package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import org.springframework.cache.annotation.Cacheable;

import java.util.Map;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

interface ICacheProduitProvider {
    String CACHE_FIND_PRODUITS_BY_FILIALE = "CACHE_FIND_PRODUITS_BY_FILIALE";

    @NoAuthRequired
    @Cacheable(cacheNames = CACHE_FIND_PRODUITS_BY_FILIALE, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    Map<String, ProduitJson> findProduitsByFiliale(String filiale);
}
