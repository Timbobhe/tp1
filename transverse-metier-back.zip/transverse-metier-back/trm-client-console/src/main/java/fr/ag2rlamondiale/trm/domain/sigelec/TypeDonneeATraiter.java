package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

@Getter
public enum TypeDonneeATraiter {
    MAIL("MAIL"), WORK("WORK");

    String code;

    TypeDonneeATraiter(String code) {
        this.code = code;
    }
}
