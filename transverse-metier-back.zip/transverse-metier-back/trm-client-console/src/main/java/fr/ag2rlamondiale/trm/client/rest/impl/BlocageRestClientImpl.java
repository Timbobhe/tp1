package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IBlocageRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.blocage.BlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.ProduitContratJson;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BlocageRestClientImpl implements IBlocageRestClient {

    @Getter
    @Setter
    @Value("${ecrs.blocage.active:true}")
    private boolean active = true;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/blocageFindService/findBlocageByPersAndProduitPost")
    private String findBlocageByPersAndProduitPostUrl;

    @Autowired
    private RestTemplate restTemplate;

    @LogError(category = "REST")
    @Override
    public List<BlocageJson> rechercherBlocages(
            String numPersonne, @Nonnull CodeApplicationType typeAcces, List<ProduitContratJson> produitContratJsonList) {
        if (!active) {
            log.warn("La récupération des blocages est désactivée");
            return new ArrayList<>(0);
        }

        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(findBlocageByPersAndProduitPostUrl)
                .queryParam("numPersonne", numPersonne)
                .queryParam("typeAcces", typeAcces.getCode());

        List<String> listeProduitsContrats = produitContratJsonList.stream()
                .map(JsonMarshaller::toJSON)
                .collect(Collectors.toList());

        final BlocageJson[] blocageJsons = restTemplate.postForObject(uriBuilder.toUriString(), JsonHttpEntityUtils.jsonHttpEntity(listeProduitsContrats), BlocageJson[].class);
        List<BlocageJson> blocagesList = JsonHttpEntityUtils.toList(blocageJsons);
        log.info("rechercherBlocages : " + blocagesList);
        return blocagesList;
    }

}
