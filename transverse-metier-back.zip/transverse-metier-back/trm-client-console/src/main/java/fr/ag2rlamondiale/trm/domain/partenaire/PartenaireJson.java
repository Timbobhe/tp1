/*
 * Cree le 19 oct. 2018.
 * (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.partenaire;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.trm.domain.blocage.FonctionnaliteJson;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class PartenaireJson implements Serializable {
    private static final long serialVersionUID = 7063257037866468426L;

    private String codePartenaire;
    private String codePartenairePrincipal;
    private String label;
    private String urlHeader;
    private String urlFooter;
    private String urlError;
    private String urlMenu;
    private String nomCss;
    private List<String> idContrats;
    @JsonProperty("fonctionnnalites")
    private List<FonctionnaliteJson> fonctionnnalitesBloquees;
}
