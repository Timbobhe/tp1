package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ITraceRestClient;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.log.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class TraceRestClientImpl implements ITraceRestClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/traceInsertService/insertPost")
    private String urlInsertTrace;

    @Override
    @LogError(category = "REST")
    public boolean insert(TraceJson traceJson) {
        try {
            final Integer idTrace = restTemplate.postForObject(urlInsertTrace, traceJson, Integer.class);
            if (log.isDebugEnabled()) {
                log.debug("ID Trace = {}, Trace = {}", idTrace, traceJson);
            }
            return idTrace != null;
        } catch (RestClientException e) {
            log.error("Erreur à l'insertion de la trace = {} : {}", traceJson, e);
            return false;
        }
    }
}
