package fr.ag2rlamondiale.trm.domain.sigelec;

public enum AccesApp {
    A1335("Entreprise"),
    A1324("Particulier"),
    A1573("Particulier"),
    A1549("Arbitrage"),
    A1649("Certificats Mutualistes"),
    A1672("Devoir de Conseil");

    private String libelle;

    AccesApp(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelle() {
        return libelle;
    }
}
