package fr.ag2rlamondiale.trm.domain.sigelec;

import lombok.Getter;

@Getter
public enum Groupe {
    TYPEOPERATION("TYPEOPERATION"), ETATDMD("ETATDMD"), TYPEDONNEEATRAITER(
            "TYPEDONNEEATRAITER"), ETATPRISEENCHARGEDEMANDE("PRISEENCHARGEDEMANDE");

    private String code;

    Groupe(String code) {
        this.code = code;
    }
}
