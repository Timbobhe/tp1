package fr.ag2rlamondiale.trm.business;

import fr.ag2rlamondiale.trm.cache.ClearableCache;

public interface IParamConsoleProvider extends ClearableCache {

    void reloadCache();

    default void firstLoadCache() {
        reloadCache();
    }
}
