/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.MettreAJourIdgdiTemporaireRequete;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.RechercherSousPartenaireRequete;

public interface IPartenaireRestClient {
    PartenaireJson findById(String id);
    
    PartenaireJson findSousPartenaire(RechercherSousPartenaireRequete requete);

    Integer updateIdgdiTemporaire(MettreAJourIdgdiTemporaireRequete requete);
}
