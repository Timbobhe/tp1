package fr.ag2rlamondiale.trm.domain.qad;


import java.io.Serializable;
import java.util.List;

/**
 *
 */
public class QuestionJson implements Serializable {
    private static final long serialVersionUID = 297314653445605739L;

    private long idQue;
    private CodeProfilType codeProfil;
    private int ordre;
    private String libelleLong;
    private String libelleCourt;
    private boolean choixMultiple;
    private String virtualPageName;
    private List<ReponseJson> reponses;

    public long getIdQue() {
        return idQue;
    }

    public void setIdQue(long idQue) {
        this.idQue = idQue;
    }

    public CodeProfilType getCodeProfil() {
        return codeProfil;
    }

    public void setCodeProfil(CodeProfilType codeProfil) {
        this.codeProfil = codeProfil;
    }

    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    public String getLibelleLong() {
        return libelleLong;
    }

    public void setLibelleLong(String libelleLong) {
        this.libelleLong = libelleLong;
    }

    public String getLibelleCourt() {
        return libelleCourt;
    }

    public void setLibelleCourt(String libelleCourt) {
        this.libelleCourt = libelleCourt;
    }

    public boolean isChoixMultiple() {
        return choixMultiple;
    }

    public void setChoixMultiple(boolean choixMultiple) {
        this.choixMultiple = choixMultiple;
    }

    public String getVirtualPageName() {
        return virtualPageName;
    }

    public void setVirtualPageName(String virtualPageName) {
        this.virtualPageName = virtualPageName;
    }

    public List<ReponseJson> getReponses() {
        return reponses;
    }

    public void setReponses(List<ReponseJson> reponses) {
        this.reponses = reponses;
    }

    @Override
    public String toString() {
        return "QuestionJson [idQue=" + idQue + ", codeProfil=" + codeProfil + ", ordre=" + ordre
                + ", libelleLong=" + libelleLong + ", libelleCourt=" + libelleCourt
                + ", choixMultiple=" + choixMultiple + ", virtualPageName=" + virtualPageName
                + ", reponses=" + reponses + "]";
    }
}
