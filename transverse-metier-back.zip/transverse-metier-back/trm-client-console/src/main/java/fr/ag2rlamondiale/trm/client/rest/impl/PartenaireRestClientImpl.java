/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IPartenaireRestClient;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.MettreAJourIdgdiTemporaireRequete;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.RechercherSousPartenaireRequete;
import fr.ag2rlamondiale.trm.log.LogError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import static fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils.jsonHttpEntity;

@Service
public class PartenaireRestClientImpl implements IPartenaireRestClient {


    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/partenaireService/find/id")
    private String partenaireFindByIdUrl;
    @Value("${ere.consoleadmin.ws.rest.root.uri}/partenaireService/find/souspartenaire")
    private String partenaireFindSousPartenaireUrl;
    @Value("${ere.consoleadmin.ws.rest.root.uri}/partenaireService/update/idgdi")
    private String partenaireupdateIdGdiTemporaireUrl;

    @Override
    @LogError(category = "REST")
    public PartenaireJson findById(String id) {
        return restTemplate.postForObject(partenaireFindByIdUrl, id, PartenaireJson.class);
    }

    @Override
    @LogError(category = "REST")
    public PartenaireJson findSousPartenaire(RechercherSousPartenaireRequete requete) {
        return restTemplate.postForObject(partenaireFindSousPartenaireUrl, jsonHttpEntity(requete), PartenaireJson.class);
    }

    @Override
    @LogError(category = "REST")
    public Integer updateIdgdiTemporaire(MettreAJourIdgdiTemporaireRequete requete) {
        // La console doit etre corrigée avec @Produces({MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON}) sur l'API
//        return restTemplate.postForObject(partenaireupdateIdGdiTemporaireUrl, jsonHttpEntity(requete), Integer.class);
        final String s = restTemplate
                .postForObject(partenaireupdateIdGdiTemporaireUrl, jsonHttpEntity(requete, MediaType.TEXT_PLAIN),
                        String.class);

        return s == null ? null : Integer.valueOf(s, 10);
    }
}
