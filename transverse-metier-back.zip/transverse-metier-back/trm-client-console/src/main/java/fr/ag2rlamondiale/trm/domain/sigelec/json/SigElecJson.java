package fr.ag2rlamondiale.trm.domain.sigelec.json;

import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import fr.ag2rlamondiale.trm.domain.sigelec.EtatSigELec;
import fr.ag2rlamondiale.trm.domain.sigelec.OperationType;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

@Data
public class SigElecJson implements Serializable {
    private static final long serialVersionUID = 1925386042101025129L;

    private long idDemande;
    private AccesApp codeApp;
    private EtatSigELec etatDmd;

    // Identifiant contrat CL
    private String idContrat;

    // Numero d'assure
    private String numeroAssure;

    // Identifiant Demande Signature Systeme EXTERNE CL
    private String idExt;

    // Identifiant interne Compte utilisateur HG
    private String idGdi;

    // numero personne
    private String numPersonne;

    private String dateCreation;
    private String dateMiseAjour;
    private OperationType typeOp;
    private String idTransaction;
    private String libelleMsgAno;
    private Boolean analyse;
    private BigDecimal montant;
    private String codePartenaire;
    private String codeDepartement;
    private String dateNaissancePersonne;
    private String libCompartiment;

    private Set<DocumentJson> documents;
    private Set<DonneeATraiterJson> donneeATraiters;

    private boolean isDirty;

    private String idTransactionPaiementCB;
}
