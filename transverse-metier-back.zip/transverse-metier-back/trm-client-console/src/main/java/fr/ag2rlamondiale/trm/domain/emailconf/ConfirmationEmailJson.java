package fr.ag2rlamondiale.trm.domain.emailconf;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sigelec.AccesApp;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
public class ConfirmationEmailJson implements Serializable {
    private static final long serialVersionUID = 791406713806694097L;

    @EqualsAndHashCode.Include
    private Long id;

    private CodeSiloType codeSilo;
    private AccesApp codeApplication;
    private String numeroPersonne;
    private String email;
    private EtatConfirmation etat;
    private String token;
    private Date dateCreation;
    private Date dateModification;
}
