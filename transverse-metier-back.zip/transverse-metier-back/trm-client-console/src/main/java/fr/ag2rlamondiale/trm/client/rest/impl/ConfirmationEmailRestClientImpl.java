package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IConfirmationEmailRestClient;
import fr.ag2rlamondiale.trm.domain.emailconf.ConfirmationEmailJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Service
public class ConfirmationEmailRestClientImpl implements IConfirmationEmailRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/confEmailService/create")
    private String createConfirmationEmailUrl;

    @Override
    public ConfirmationEmailJson createConfirmation(ConfirmationEmailJson confirmation) {
        try {
            return restTemplate.postForObject(createConfirmationEmailUrl, JsonHttpEntityUtils.jsonHttpEntity(confirmation), ConfirmationEmailJson.class);
        } catch (RestClientException ex) {
            log.error("Erreur lors de creation ou existe deja", ex);
        }
        return null;
    }
}
