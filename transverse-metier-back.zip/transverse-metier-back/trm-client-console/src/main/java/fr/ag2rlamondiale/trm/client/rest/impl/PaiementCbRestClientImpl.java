package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IPaiementCbRestClient;
import fr.ag2rlamondiale.trm.domain.paiement.*;
import fr.ag2rlamondiale.trm.domain.paiement.exception.PaimentCbNotFoundException;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils.toList;

@Service
public class PaiementCbRestClientImpl implements IPaiementCbRestClient {

    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/paiementCb/create")
    private String createUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/paiementCb/update")
    private String updateUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/paiementCb/find")
    private String findUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/paiementCb/find-for-user")
    private String findPaiementsUtilUrl;

    @LogExecutionTime
    @Override
    public PaiementCbJson createPaiement(PaiementCbJson paiementCbJson) {
        PaiementCbJson res = restTemplate.postForObject(createUrl, paiementCbJson, PaiementCbJson.class);
        return res;
    }

    @LogExecutionTime
    @Override
    public PaiementCbJson updatePaiement(UpdateRequestPaiementCbJson updateRequest) {
        try {
            PaiementCbJson res = restTemplate.postForObject(updateUrl, updateRequest, PaiementCbJson.class);
            return res;
        } catch (HttpClientErrorException.NotFound e) {
            throw new PaimentCbNotFoundException("depuis " + updateRequest);
        }
    }

    @LogExecutionTime
    @Override
    public PaiementCbJson findPaiement(FindRequestPaiementCbJson findRequest) {
        try {
            PaiementCbJson res = restTemplate.postForObject(findUrl, findRequest, PaiementCbJson.class);
            return res;
        } catch (HttpClientErrorException.NotFound e) {
            throw new PaimentCbNotFoundException("depuis " + findRequest);
        }
    }

    @LogExecutionTime
    @Override
    public List<PaiementCbJson> findPaiementsUtilisateur(FindRequestPaiementCbUtilisateurJson findRequest) {
        try {
            PaiementCbJson[] res = restTemplate.postForObject(findPaiementsUtilUrl, findRequest, PaiementCbJson[].class);
            return toList(res);
        } catch (HttpClientErrorException.NotFound e) {
            throw new PaimentCbNotFoundException("depuis " + findRequest);
        }
    }
}
