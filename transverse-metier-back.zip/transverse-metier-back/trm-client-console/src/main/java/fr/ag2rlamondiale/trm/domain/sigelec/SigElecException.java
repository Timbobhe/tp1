package fr.ag2rlamondiale.trm.domain.sigelec;

public class SigElecException extends RuntimeException{

    public SigElecException(String message) {
        super(message);
    }
}
