package fr.ag2rlamondiale.trm.domain.qad;

public class PropositionRequest {
    private long idTypPflEpargnant;
    private long idTypPflInvestissement;
    private long idTypPro;
    private String typeContrat;
    private String numGenContrat;

    public long getIdTypPflEpargnant() {
        return idTypPflEpargnant;
    }

    public void setIdTypPflEpargnant(long idTypPflEpargnant) {
        this.idTypPflEpargnant = idTypPflEpargnant;
    }

    public long getIdTypPflInvestissement() {
        return idTypPflInvestissement;
    }

    public void setIdTypPflInvestissement(long idTypPflInvestissement) {
        this.idTypPflInvestissement = idTypPflInvestissement;
    }

    public long getIdTypPro() {
        return idTypPro;
    }

    public void setIdTypPro(long idTypPro) {
        this.idTypPro = idTypPro;
    }

    public String getTypeContrat() {
        return typeContrat;
    }

    public void setTypeContrat(String typeContrat) {
        this.typeContrat = typeContrat;
    }

    public String getNumGenContrat() {
        return numGenContrat;
    }

    public void setNumGenContrat(String numGenContrat) {
        this.numGenContrat = numGenContrat;
    }

    @Override
    public String toString() {
        return "PropositionRequest [idTypPflEpargnant=" + idTypPflEpargnant
                + ", idTypPflInvestissement=" + idTypPflInvestissement + ", idTypPro=" + idTypPro
                + ", typeContrat=" + typeContrat + ", numGenContrat=" + numGenContrat + "]";
    }
}
