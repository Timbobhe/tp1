/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvenementJson implements Serializable {
    private static final long serialVersionUID = 2090688527409224310L;

    private Integer id;

    private TypeEvenementJson typeEvenement;

    private String idGdi;

    private String numContrat;

    private EtatTraitementType etatTraitement;

    private Date dateDebut;

    private Date dateFin;

    public EvenementJson(TypeEvenementJson typeEvenement) {
        this.typeEvenement = typeEvenement;
    }
}
