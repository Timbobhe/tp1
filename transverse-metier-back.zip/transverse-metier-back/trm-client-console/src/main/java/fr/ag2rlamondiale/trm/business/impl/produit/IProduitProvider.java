package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.business.IParamConsoleProvider;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;

import java.util.Optional;

public interface IProduitProvider extends IParamConsoleProvider {

    ProduitJson findProduitMdpro(String codeOffreComm);

    default ProduitJson findProduitMdpro(String typeContrat, String numGen) {
        return findProduitMdpro(getkey(typeContrat, numGen));
    }

    default String getkey(String typeCon, String numGen) {
        String key = typeCon.trim();
        if (numGen != null) {
            key += numGen.trim();
        }
        return key.toUpperCase();
    }

    Optional<ProduitJson> findProduitEre(String filiale, String typeCon, String numGen);

}
