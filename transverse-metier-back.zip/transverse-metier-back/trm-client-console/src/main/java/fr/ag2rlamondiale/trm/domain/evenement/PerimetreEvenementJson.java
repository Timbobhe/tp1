/*
 * Cree le 6 avr. 2017. (c) Ag2r - La Mondiale, 2017. Tous droits reserves.
 */
package fr.ag2rlamondiale.trm.domain.evenement;

import fr.ag2rlamondiale.trm.domain.PerimetreJson;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class PerimetreEvenementJson extends PerimetreJson {
    private static final long serialVersionUID = -169553817309809260L;

    private String codeEvenement;
    private OperationPerimetre operationPerimetre;
}
