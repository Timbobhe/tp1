package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Getter;

@Getter
public enum CodeProfilType {
    EPAR("Profil d'\u00e9pargnant"),
    INVEST("Profil d'investissement"),
    PART("Particulier"),
    PACTE("Particulier");

    private String libelle;

    CodeProfilType(String libelle) {
        this.libelle = libelle;
    }
}
