package fr.ag2rlamondiale.trm;

import fr.ag2rlamondiale.trm.cache.CacheConstants;
import fr.ag2rlamondiale.trm.cache.RuntimeCacheResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableScheduling
@Configuration
@ComponentScan
@Import({CoreConfig.class})
public class ClientConsoleConfig {
    public static final String RUNTIME_CONSOLE_CACHE_RESOLVER = "runtimeConsoleCacheResolver";

    @Bean(RUNTIME_CONSOLE_CACHE_RESOLVER)
    public RuntimeCacheResolver runtimeConsoleCacheResolver(@Autowired JCacheCacheManager cacheCacheManager) {
        RuntimeCacheResolver runtimeCacheResolver = new RuntimeCacheResolver(cacheCacheManager);
        runtimeCacheResolver.setCacheNameModel(CacheConstants.CONSOLE_PARAM_CACHE);
        return runtimeCacheResolver;
    }
}
