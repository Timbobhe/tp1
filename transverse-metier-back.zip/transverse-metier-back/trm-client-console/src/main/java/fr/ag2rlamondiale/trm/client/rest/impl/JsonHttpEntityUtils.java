package fr.ag2rlamondiale.trm.client.rest.impl;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static fr.ag2rlamondiale.trm.utils.JsonMarshaller.toJSON;

public class JsonHttpEntityUtils {

    private JsonHttpEntityUtils() {
    }

    public static <T> HttpEntity<String> jsonHttpEntity(T value) {
        return jsonHttpEntity(value, MediaType.APPLICATION_JSON);
    }

    public static <T> HttpEntity<String> jsonHttpEntity(T value, MediaType... mediaTypes) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(mediaTypes));
        return new HttpEntity<>(toJSON(value), headers);
    }

    public static <T> List<T> toList(T[] array) {
        if (array == null) {
            return Collections.emptyList();
        }
        return Arrays.asList(array);
    }

}
