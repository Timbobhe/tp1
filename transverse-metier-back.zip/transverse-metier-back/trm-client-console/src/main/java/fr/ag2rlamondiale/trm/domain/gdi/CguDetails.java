package fr.ag2rlamondiale.trm.domain.gdi;

import lombok.Data;

import java.io.Serializable;

@Data
public class CguDetails implements Serializable {
    private static final long serialVersionUID = -1150393475234308560L;

    private String idCgu;
    private String textCgu;
    private String urlPdfCgu;
}
