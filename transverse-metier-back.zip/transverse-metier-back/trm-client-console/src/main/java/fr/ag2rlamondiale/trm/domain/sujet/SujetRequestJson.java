package fr.ag2rlamondiale.trm.domain.sujet;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SujetRequestJson {
    private static final long serialVersionUID = 4312483975874423147L;

    private String idGdi;
    private Integer idSujet;
}
