package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IPrevalidationPieceIdentiteRestClient;
import fr.ag2rlamondiale.trm.domain.prevalidpieceident.PrevalidationPieceIdentiteJson;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PrevalidationPieceIdentiteRestClientImpl implements IPrevalidationPieceIdentiteRestClient {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/prevalidPieceIdent")
    private String getPrevalidationPieceIdentiteUrl;

    @LogExecutionTime
    @LogError(category = "REST")
    @Override
    public PrevalidationPieceIdentiteJson getPrevalidationByIdGdi(String idGdi) {
        String getPrevalidationPieceIdentiteByIdGdiUrl = getPrevalidationPieceIdentiteUrl.concat("/{idGdi}");
        return restTemplate.getForObject(getPrevalidationPieceIdentiteByIdGdiUrl, PrevalidationPieceIdentiteJson.class,
                idGdi);
    }

    @LogExecutionTime
    @LogError(category = "REST")
    @Override
    public PrevalidationPieceIdentiteJson createPrevalidation(PrevalidationPieceIdentiteJson prevalidation) {
        return restTemplate.postForObject(getPrevalidationPieceIdentiteUrl, JsonHttpEntityUtils.jsonHttpEntity(prevalidation), PrevalidationPieceIdentiteJson.class);
    }


}
