package fr.ag2rlamondiale.trm.domain.qad;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import lombok.Getter;

import java.util.Set;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.trm.domain.FonctionnaliteType.*;
import static fr.ag2rlamondiale.trm.utils.Sets.set;

@Getter
public enum QadType {
	ARBITRAGE_ERE_PACTE(ARBITRAGE, ERE, set(CodeProfilType.PACTE), true, null),
	COMPLETER_BIA_ERE_PACTE(COMPLETER_BIA, ERE, set(CodeProfilType.PACTE), true, null),
	VERSEMENT_ERE_PACTE(VERSEMENT, ERE, set(CodeProfilType.PACTE), true, null),

	ARBITRAGE_ERE(ARBITRAGE, ERE, set(CodeProfilType.PART), false, ARBITRAGE_ERE_PACTE),
	ARBITRAGE_MDP(ARBITRAGE, MDP, set(CodeProfilType.EPAR, CodeProfilType.INVEST), false, null),
    ARBITRAGE_MDP_PACTE(ARBITRAGE, MDP, set(CodeProfilType.EPAR, CodeProfilType.INVEST), true, null),
    COMPLETER_BIA_ERE(COMPLETER_BIA, ERE, set(CodeProfilType.PART), false, COMPLETER_BIA_ERE_PACTE),
	VERSEMENT_ERE(VERSEMENT, ERE, set(CodeProfilType.PART), false, VERSEMENT_ERE_PACTE),
	VERSEMENT_MDP(VERSEMENT, MDP, set(CodeProfilType.EPAR, CodeProfilType.INVEST), false, null);

	private final FonctionnaliteType fonctionnalite;

	private final CodeSiloType codeSilo;

	private final Set<CodeProfilType> listeCodeProfil;

	private final boolean pacte;

	private final QadType qadTypePacte;

	QadType(FonctionnaliteType fonctionnaliteType, CodeSiloType codeSilo, Set<CodeProfilType> listeCodeProfil,
			boolean pacte, QadType typePacte) {
		this.fonctionnalite = fonctionnaliteType;
		this.codeSilo = codeSilo;
		this.listeCodeProfil = listeCodeProfil;
		this.pacte = pacte;
		this.qadTypePacte = typePacte == null ? this : typePacte;

	}

	public boolean isFonctionnalite(FonctionnaliteType fonctionnalite) {
		return this.fonctionnalite.equals(fonctionnalite);
	}

	public static QadType find(FonctionnaliteType fonctionnalite, CodeSiloType silo, boolean pacte) {
		return Stream.of(values()).filter(qadType -> qadType.isFonctionnalite(fonctionnalite)
				&& qadType.getCodeSilo().equals(silo) && qadType.isPacte() == pacte).findFirst().orElse(null);
	}

	public QadType getTypeforPacte(boolean pacte) {
		if (!this.pacte && pacte) {
			return this.qadTypePacte;
		}
		return this;
	}
}
