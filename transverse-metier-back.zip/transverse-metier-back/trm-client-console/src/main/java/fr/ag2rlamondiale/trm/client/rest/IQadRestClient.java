package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.qad.*;

import java.util.List;
import java.util.Set;

public interface IQadRestClient {
    List<SupportInvestissementJson> getSupportsInvestissement();

    List<TypeProfilJson> getTypesProfilParProfils(Set<CodeProfilType> codeProfils);
    
	List<QuestionJson> getQuesRepByProfil(Set<CodeProfilType> set);
	
	List<PropositionJson> getPropositionsParProduit(PropositionRequest requete);


}
