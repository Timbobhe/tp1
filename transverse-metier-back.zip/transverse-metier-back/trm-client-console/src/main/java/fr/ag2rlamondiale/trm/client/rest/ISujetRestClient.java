package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestListJson;

import java.util.List;
import java.util.Set;

public interface ISujetRestClient {

    List<SujetJson> getSujets(Set<CodeSiloType> silos);

    List<LectureSujetJson> getSujetsParUtilisateur(SujetRequestJson request);

    List<LectureSujetJson> createSujetParUtilisateur(SujetRequestListJson request);

    LectureSujetJson updateSujetLuParUtilisateur(SujetRequestJson request);
}
