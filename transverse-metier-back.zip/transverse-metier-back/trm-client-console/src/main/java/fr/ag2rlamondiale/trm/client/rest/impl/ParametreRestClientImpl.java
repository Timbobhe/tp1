package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IParametreRestClient;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.parametre.RequestParametreDto;
import fr.ag2rlamondiale.trm.log.LogError;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Slf4j
@Service
public class ParametreRestClientImpl implements IParametreRestClient {

    @Value("#{consoleProps.consoleV2ApiUrl}/parametre/find")
    private String findParamsUrl;

    @Autowired
    private RestTemplate restTemplate;

    @LogError(category = "REST")
    @Override
    public List<ParametreDto> getParametres(RequestParametreDto req) {
        final ParametreDto[] array = restTemplate.postForObject(findParamsUrl, req, ParametreDto[].class);
        return JsonHttpEntityUtils.toList(array);
    }
}
