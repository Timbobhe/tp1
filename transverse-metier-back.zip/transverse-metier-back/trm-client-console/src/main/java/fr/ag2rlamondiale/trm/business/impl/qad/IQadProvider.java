package fr.ag2rlamondiale.trm.business.impl.qad;

import fr.ag2rlamondiale.trm.business.IParamConsoleProvider;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;

public interface IQadProvider extends IParamConsoleProvider {
    /**
     * Récupération des libellés des structures d'investissement de type "Profil", "Grille" ou
     * "Horizon" dans la table TBCL0SUP.
     */
    SupportInvestissementJson getSupportsInvestissement(String codeSupport);
}
