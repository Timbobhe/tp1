package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;

import java.util.List;

public interface ICguRestClient {
    CguDetails getCguDetails();

    List<String> getAcceptedGguIds(Integer idCxp);

    boolean createAcceptationCgu(Integer idCxp, String idCgu);
}
