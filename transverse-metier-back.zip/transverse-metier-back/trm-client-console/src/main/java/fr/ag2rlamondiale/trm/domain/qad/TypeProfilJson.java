package fr.ag2rlamondiale.trm.domain.qad;

import lombok.Data;

import java.util.List;

@Data
public class TypeProfilJson {
    private long idTypPfl;
    private CodeProfilType codeProfil;
    private int scoreInf;
    private String libelleTypeProfil;
    private String codeSupport;
    private List<PropositionJson> propositionsEpargnant;
    private List<PropositionJson> propositionsInvestissement;
}
