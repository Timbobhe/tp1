package fr.ag2rlamondiale.trm.domain.emailconf;

public enum EtatConfirmation {
    ENVO, CONF;
}
