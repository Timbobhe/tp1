package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", builder = @org.mapstruct.Builder(disableBuilder = true))
public interface ParamMapper {

    @Mapping(source = "codeParam", target = "codeSupport")
    @Mapping(source = "libelleParam", target = "libelleFront")
    @Mapping(source = "valeur1", target = "libelleSupport")
    SupportInvestissementJson map(ParametreDto parametreDto);
}
