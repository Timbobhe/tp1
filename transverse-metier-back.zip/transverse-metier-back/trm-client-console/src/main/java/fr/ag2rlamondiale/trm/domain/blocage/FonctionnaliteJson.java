package fr.ag2rlamondiale.trm.domain.blocage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class FonctionnaliteJson implements Serializable {
    private static final long serialVersionUID = 6394740814779491686L;

    private static final String TYPE_MENU = "MENU";
    private static final String TYPE_OPERATION = "OPER";

    private Integer idFct;
    private String typeFct;
    private String codeFct;
    private String libelleFct;
    private String typeAcces;

    public FonctionnaliteJson(String codeFct) {
        this.codeFct = codeFct;
    }
}
