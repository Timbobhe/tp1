package fr.ag2rlamondiale.trm.domain.blocage;

import fr.ag2rlamondiale.trm.domain.PerimetreJson;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@EqualsAndHashCode(callSuper = true)
public class ExceptionBlocageJson extends PerimetreJson {
    private static final long serialVersionUID = 1791033109221440259L;

    public ExceptionBlocageJson(PerimetreType typePerimetre, String valeurPerimetre) {
        super(typePerimetre, valeurPerimetre);
    }
}
