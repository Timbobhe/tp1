package fr.ag2rlamondiale.trm.business.impl.parametre;

import fr.ag2rlamondiale.trm.client.rest.IParametreRestClient;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.parametre.RequestParametreDto;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import static fr.ag2rlamondiale.trm.ClientConsoleConfig.RUNTIME_CONSOLE_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

@Slf4j
@Service
@Primary
public class ParametreProviderImpl implements IParametreProvider, ICacheParametreProvider, SelfReferencingBean {

    @Autowired
    @Setter
    private CacheManager cacheManager;

    @Autowired
    private IParametreRestClient parametreRestClient;


    private ICacheParametreProvider springProxy;

    @Override
    public void reloadCache() {
        clearCache();
//        final List<ParametreDto> tmi = this.springProxy.getParametres("TMI", Annee.Courante);
    }

    @Override
    public List<ParametreDto> getParametres(String typeParam, Annee annee) {
        return this.springProxy.getParametresCachable(typeParam, annee);
    }

    @Override
    @NoAuthRequired
    @Cacheable(cacheNames = CACHE_FIND_PARAMETRE_BY_TYPE_ANNEE, cacheResolver = RUNTIME_CONSOLE_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public List<ParametreDto> getParametresCachable(String typeParam, Annee annee) {
        return parametreRestClient.getParametres(RequestParametreDto.builder().typeParam(typeParam).date(annee != null ? annee.toLocalDate() : Annee.Courante.toLocalDate()).build());
    }

    @Override
    public Optional<ParametreDto> getParametre(String typeParam, String codeParam, Annee annee) {
        final List<ParametreDto> parametres = this.springProxy.getParametresCachable(typeParam, annee);
        if (parametres == null || parametres.isEmpty()) {
            return Optional.empty();
        }
        return parametres.stream()
                .filter(e -> e.getCodeParam().equals(codeParam))
                .findFirst();
    }

    @Override
    public void clearCache() {
        final Cache cache = cacheManager.getCache(CACHE_FIND_PARAMETRE_BY_TYPE_ANNEE);
        if (cache != null) {
            cache.clear();
        }
    }

    @Override
    public void setProxy(Object proxy) {
        springProxy = (ICacheParametreProvider) proxy;
    }
}
