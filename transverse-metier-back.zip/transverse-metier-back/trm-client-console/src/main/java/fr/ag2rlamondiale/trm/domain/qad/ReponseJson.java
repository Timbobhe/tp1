package fr.ag2rlamondiale.trm.domain.qad;

import java.io.Serializable;

/**
 *
 */
public class ReponseJson implements Serializable {
    private static final long serialVersionUID = 8236403553360486921L;

    private long idQue;
    private int ordre;
    private String libelleLong;
    private String libelleCourt;
    private int score;

    public long getIdQue() {
        return idQue;
    }

    public void setIdQue(long idQue) {
        this.idQue = idQue;
    }

    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    public String getLibelleLong() {
        return libelleLong;
    }

    public void setLibelleLong(String libelleLong) {
        this.libelleLong = libelleLong;
    }

    public String getLibelleCourt() {
        return libelleCourt;
    }

    public void setLibelleCourt(String libelleCourt) {
        this.libelleCourt = libelleCourt;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @Override
    public String toString() {
        return "ReponseJson [idQue=" + idQue + ", ordre=" + ordre + ", libelleLong=" + libelleLong
                + ", libelleCourt=" + libelleCourt + ", score=" + score + "]";
    }
}
