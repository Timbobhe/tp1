package fr.ag2rlamondiale.trm.client.rest;

import fr.ag2rlamondiale.trm.domain.trace.TraceJson;

@FunctionalInterface
public interface ITraceRestClient {
    boolean insert(TraceJson traceJson);
}
