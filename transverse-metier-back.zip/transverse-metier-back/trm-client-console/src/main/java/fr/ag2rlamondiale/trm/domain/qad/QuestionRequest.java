package fr.ag2rlamondiale.trm.domain.qad;


import java.util.List;

public class QuestionRequest {
    private List<CodeProfilType> codeProfils;

    public List<CodeProfilType> getCodeProfils() {
        return codeProfils;
    }

    public void setCodeProfils(List<CodeProfilType> codeProfils) {
        this.codeProfils = codeProfils;
    }

    @Override
    public String toString() {
        return "QuestionRequete [codeProfils=" + codeProfils + "]";
    }
}
