package fr.ag2rlamondiale.trm.domain.sigelec;

import fr.ag2rlamondiale.trm.domain.exception.UnknownEnumerationValueException;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public enum CodeStatutSignatureType {
    READY("ready"),
    CODE_SENT("code-sent"),
    EXPIRED("expired"),
    COMPLETED("completed"),
    CANCELED("canceled"),
    FAILED("failed"),
    WAITING("waiting"),
    PENDING("pending"),
    PENDING_VALIDATION("pending-validation");

    private static final Map<String, CodeStatutSignatureType> ENUM_MAP;

    static {
        Map<String, CodeStatutSignatureType> map = new ConcurrentHashMap<>();
        for (CodeStatutSignatureType instance : CodeStatutSignatureType.values()) {
            map.put(instance.getCode(), instance);
        }
        ENUM_MAP = Collections.unmodifiableMap(map);
    }

    private String code;

    private CodeStatutSignatureType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static CodeStatutSignatureType fromCode(String code) {
        CodeStatutSignatureType result = ENUM_MAP.get(code);

        if (result != null) {
            return result;
        }
        throw new UnknownEnumerationValueException(CodeStatutSignatureType.class,
                "Aucune valeure correspondant à " + code + " pour l'enum CodeStatutSignatureType");
    }
}
