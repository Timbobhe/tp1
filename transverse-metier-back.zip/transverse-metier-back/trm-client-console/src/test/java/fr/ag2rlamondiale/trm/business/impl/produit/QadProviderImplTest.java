package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.TestCacheConfig;
import fr.ag2rlamondiale.trm.TestConsoleConfig;
import fr.ag2rlamondiale.trm.business.impl.qad.IQadProvider;
import fr.ag2rlamondiale.trm.business.impl.qad.QadProviderImpl;
import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import static java.util.Arrays.asList;
import static org.junit.Assert.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {TestConsoleConfig.class, TestCacheConfig.class, QadProviderImplTest.QadProviderImplTestConfig.class})
public class QadProviderImplTest {

    @Autowired
    IQadProvider qadProvider;

    IQadRestClient qadRestClient;

    @Autowired
    CacheManager cacheManager;

    @Configuration
    static class QadProviderImplTestConfig {

        @Bean
        IQadProvider qadProvider() {
            return new QadProviderImpl();
        }

        @Bean
        IQadRestClient qadRestClient() {
            IQadRestClient qadRestClient = Mockito.mock(IQadRestClient.class);
            when(qadRestClient.getSupportsInvestissement()).thenReturn(asList(
                    supportInvestissement("9495", "24 trimestres"),
                    supportInvestissement("9262", "Allocation Diversifiée"),
                    supportInvestissement("9470", "Grille Equilibre RECOSUP")));

            return qadRestClient;
        }

    }

    @Before
    public void setUp() {
        qadRestClient = new QadProviderImplTestConfig().qadRestClient();
        ReflectionTestUtils.setField(qadProvider, "qadRestClient", qadRestClient);
    }

    @Test
    public void getSupportsInvestissement() {
        final SupportInvestissementJson sup9495 = qadProvider.getSupportsInvestissement("9495");
        assertEquals("24 trimestres", sup9495.getLibelleFront());

        final SupportInvestissementJson sup9262 = qadProvider.getSupportsInvestissement("9262");
        assertEquals("Allocation Diversifiée", sup9262.getLibelleFront());

        final SupportInvestissementJson inconnu = qadProvider.getSupportsInvestissement("inconnu");
        assertNull(inconnu);
    }

    @Test
    public void reloadCache() {
        qadProvider.reloadCache();

        final SupportInvestissementJson sup9495 = qadProvider.getSupportsInvestissement("9495");
        assertEquals("24 trimestres", sup9495.getLibelleFront());

        verify(qadRestClient).getSupportsInvestissement();
    }


    @Test
    public void reloadCache_error_qad() {
        when(qadRestClient.getSupportsInvestissement()).thenThrow(new RuntimeException("Boom"));
        ReflectionTestUtils.setField(qadProvider, "qadRestClient", qadRestClient);

        qadProvider.reloadCache();

        try {
            qadProvider.getSupportsInvestissement("9495");
            fail();
        } catch (Exception ignored) {
        }
    }

    @Test
    public void firstLoadCache() {
        qadProvider.firstLoadCache();

        final SupportInvestissementJson sup9495 = qadProvider.getSupportsInvestissement("9495");
        assertEquals("24 trimestres", sup9495.getLibelleFront());

        verify(qadRestClient).getSupportsInvestissement();
    }

    @Test
    public void clearCache() {
        qadProvider.clearCache();
        final SupportInvestissementJson sup9495 = qadProvider.getSupportsInvestissement("9495");
        assertEquals("24 trimestres", sup9495.getLibelleFront());

        verify(qadRestClient).getSupportsInvestissement();
    }


    private static SupportInvestissementJson supportInvestissement(String code, String libelle) {
        SupportInvestissementJson support = new SupportInvestissementJson();
        support.setCodeSupport(code);
        support.setLibelleFront(libelle);
        return support;
    }
}
