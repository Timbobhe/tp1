package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.TestCacheConfig;
import fr.ag2rlamondiale.trm.TestConsoleConfig;
import fr.ag2rlamondiale.trm.client.rest.IProduitRestClient;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.constantes.Constantes;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.junit.Assert.*;
import static org.mockito.Matchers.anyList;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {TestConsoleConfig.class, TestCacheConfig.class, ProduitProviderImplTest.ProduitProviderImplTestConfig.class})
public class ProduitProviderImplTest {

    @Autowired
    IProduitProvider produitProvider;

    IProduitRestClient produitRestClient;

    @Autowired
    CacheManager cacheManager;

    @Configuration
    static class ProduitProviderImplTestConfig {

        @Bean
        IProduitProvider produitProvider() {
            return new ProduitProviderImpl();
        }

        @Bean
        IProduitRestClient produitRestClient() {
            final IProduitRestClient produitRestClient = Mockito.mock(IProduitRestClient.class);
            final List<ProduitJson> produitsMDP = asList(
                    produitMDP("PF71", null, "Rente à vie une tête"),
                    produitMDP("RF10", "V04", "Mondiale Retraite Plus"),
                    produitMDP("TV02", "V01", "Rente Viagère"));


            final List<ProduitJson> produitsERE = asList(
                    produit("RG01", "001", "PERO_1", "ARI"),
                    produit("RG01", "002", "PERO_2", "ARI"),
                    produit("RG01", "003", "Mondial Retraite", "ARI"));

            when(produitRestClient.findByFiliales(any())).thenAnswer(invocation -> {
                final List<String> filiales = invocation.getArgumentAt(0, List.class);
                if (Collections.singletonList("LMX").equals(filiales)) {
                    return produitsMDP;
                }
                if (Collections.singletonList("ARI").equals(filiales)) {
                    return produitsERE;
                }
                return new ArrayList<>(0);
            });

            return produitRestClient;
        }
    }

    @Before
    public void setUp() {
        produitRestClient = new ProduitProviderImplTestConfig().produitRestClient();
        ReflectionTestUtils.setField(produitProvider, "produitRestClient", produitRestClient);
    }

    @Test
    public void findProduitMdpro() {
        final ProduitJson inconnu = produitProvider.findProduitMdpro("inconnu");
        assertNull(inconnu);

        final ProduitJson pf71 = produitProvider.findProduitMdpro("PF71");
        assertEquals("Rente à vie une tête", pf71.getLibelle());

        final ProduitJson pf71___ = produitProvider.findProduitMdpro("PF71   ");
        assertEquals("Rente à vie une tête", pf71___.getLibelle());

        final ProduitJson rf10V04 = produitProvider.findProduitMdpro("RF10V04");
        assertEquals("Mondiale Retraite Plus", rf10V04.getLibelle());

        final ProduitJson tv02V01 = produitProvider.findProduitMdpro("TV02V01");
        assertEquals("Rente Viagère", tv02V01.getLibelle());
    }

    @Test
    public void findProduitEre() {
        Optional<ProduitJson> rg01001ari = produitProvider.findProduitEre("ARI", "RG01", "001");
        Assert.assertTrue(rg01001ari.isPresent());
        Assert.assertNotNull(rg01001ari.get());
        assertEquals("PERO_1", rg01001ari.get().getLibelle());

        Optional<ProduitJson> rg01002ari = produitProvider.findProduitEre("ARI", "RG01", "002");
        Assert.assertTrue(rg01002ari.isPresent());
        Assert.assertNotNull(rg01002ari.get());
        assertEquals("PERO_2", rg01002ari.get().getLibelle());

        Optional<ProduitJson> rg01003ari = produitProvider.findProduitEre("ARI", "RG01", "003");
        Assert.assertTrue(rg01003ari.isPresent());
        Assert.assertNotNull(rg01003ari.get());
        assertEquals("Mondial Retraite", rg01003ari.get().getLibelle());

        Optional<ProduitJson> rg02003ari = produitProvider.findProduitEre("ARI", "RG02", "003");
        Assert.assertFalse(rg02003ari.isPresent());

        Optional<ProduitJson> rg01004ari = produitProvider.findProduitEre("ARI", "RG01", "004");
        Assert.assertFalse(rg01004ari.isPresent());

        Optional<ProduitJson> rg01001aca = produitProvider.findProduitEre("ACA", "RG01", "001");
        Assert.assertFalse(rg01001aca.isPresent());

    }


    @Test
    public void reloadCache() {
        produitProvider.reloadCache();

        final ProduitJson pf71 = produitProvider.findProduitMdpro("PF71");
        assertEquals("Rente à vie une tête", pf71.getLibelle());

        verify(produitRestClient).findByFiliales(Collections.singletonList(Constantes.FILIALE_MDPRO));
    }


    @Test
    public void reloadCache_error_produit() {
        when(produitRestClient.findByFiliales(anyList())).thenThrow(new RuntimeException("Boom"));
        ReflectionTestUtils.setField(produitProvider, "produitRestClient", produitRestClient);

        produitProvider.reloadCache();

        try {
            produitProvider.findProduitMdpro("PF71");
            fail();
        } catch (Exception ignored) {
        }

        verify(produitRestClient, times(2)).findByFiliales(Collections.singletonList(Constantes.FILIALE_MDPRO));
    }

    @Test
    public void firstLoadCache() {
        produitProvider.firstLoadCache();

        final ProduitJson pf71 = produitProvider.findProduitMdpro("PF71");
        assertEquals("Rente à vie une tête", pf71.getLibelle());

        verify(produitRestClient).findByFiliales(Collections.singletonList(Constantes.FILIALE_MDPRO));
    }

    @Test
    public void clearCache() {
        produitProvider.clearCache();
        final ProduitJson pf71 = produitProvider.findProduitMdpro("PF71");
        assertEquals("Rente à vie une tête", pf71.getLibelle());

        verify(produitRestClient).findByFiliales(Collections.singletonList(Constantes.FILIALE_MDPRO));
    }


    private static ProduitJson produitMDP(String typeContrat, String numGene, String libelle) {
        return produit(typeContrat, numGene, libelle, "LMX");
    }

    private static ProduitJson produit(String typeContrat, String numGene, String libelle, String filiale) {
        ProduitJson p = new ProduitJson();
        p.setCodeFiliale(filiale);
        p.setTypeContrat(typeContrat);
        p.setNumeroGeneration(numGene);
        p.setLibelle(libelle);
        return p;
    }
}
