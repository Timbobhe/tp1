package fr.ag2rlamondiale.trm.domain.partenaire;

import org.junit.Test;

import static org.junit.Assert.*;

public class PartenaireUtilsTest {

    @Test
    public void temporaryUserId() {
        assertEquals("ID_18", PartenaireUtils.temporaryUserId(18));
    }
}
