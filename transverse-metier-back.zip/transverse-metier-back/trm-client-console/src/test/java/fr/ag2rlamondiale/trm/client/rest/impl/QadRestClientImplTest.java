package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IQadRestClient;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringTestConfig.class})
public class QadRestClientImplTest {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.qadService.getSupportsInvestissement.url}")
    private String urlGetSupportsInvestissement;

    @Autowired
    private IQadRestClient qadRestClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    private MockRestServiceServer mockServer;

    @Before
    public void setUp() throws Exception {
        mockServer = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    public void getSupportsInvestissementTest() throws Exception {
        mockServer.expect(requestTo(new URI(urlGetSupportsInvestissement)))
                .andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/qadService-getSupportsInvestissement.json")));

        final List<SupportInvestissementJson> supports = qadRestClient.getSupportsInvestissement();

        mockServer.verify();
        List<Predicate<SupportInvestissementJson>> predicates = new ArrayList<>();
        predicates.add(isSupportInvestissement("1"));
        predicates.add(isSupportInvestissement("3024"));
        predicates.add(isSupportInvestissement("8891"));
        predicates.add(isSupportInvestissement("averti"));
        predicates.add(isSupportInvestissement("dynamique"));

        int index = 0;
        for (SupportInvestissementJson json : supports) {
            log.info("{}", json);
            assertTrue(predicates.get(index++).test(json));
        }
    }

    private Predicate<SupportInvestissementJson> isSupportInvestissement(String codeSupport) {
        return e -> e.getCodeSupport().equals(codeSupport);
    }

    private String jsonResource(String resourcePath) {
        InputStream in = getClass().getResourceAsStream(resourcePath);
        String result = new BufferedReader(new InputStreamReader(in)).lines()
                .collect(Collectors.joining("\n"));
        return result;
    }
}
