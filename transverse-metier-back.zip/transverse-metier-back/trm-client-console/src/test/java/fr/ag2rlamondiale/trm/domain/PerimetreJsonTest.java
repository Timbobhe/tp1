package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.domain.blocage.ProduitContratJson;
import org.junit.Test;

import static org.junit.Assert.*;

public class PerimetreJsonTest {

    public static final String NUMERSONNE = "NUMERSONNE";
    private static final String OTHERNUMERSONNE = "OTHERNUMERSONNE";
    private static final String NUMCONTRAT = "NUMCONTRAT";
    private static final String OTHERNUMCONTRAT = "OTHERNUMCONTRAT";
    private static final String PRODUIT = "PRODUIT";
    private static final String OTHERRODUIT = "OTHERPRODUIT";
    private static final String FILIALE = "FILIALE";
    private static final String OTHERFILIALE = "OTHERFILIALE";

    @Test
    public void test_tout() {
        final PerimetreJson tout = perimetre(PerimetreType.TOUT, "*");
        assertTrue(tout.matchPersonne(NUMERSONNE));
        assertTrue(tout.matchContrat(new ProduitContratJson()));
        assertTrue(tout.match(new ProduitContratJson()));
    }

    @Test
    public void test_personne() {
        final PerimetreJson personne = perimetre(PerimetreType.PERSONNE, NUMERSONNE);
        assertTrue(personne.matchPersonne(NUMERSONNE));
        assertTrue(personne.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(personne.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
        assertFalse(personne.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).build()));
    }

    @Test
    public void test_personne_Etoile() {
        final PerimetreJson personneEtoile = perimetre(PerimetreType.PERSONNE, "*");
        assertTrue(personneEtoile.matchPersonne(NUMERSONNE));
        assertTrue(personneEtoile.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertTrue(personneEtoile.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
        assertFalse(personneEtoile.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).build()));
    }

    @Test
    public void test_contrat() {
        final PerimetreJson contrat = perimetre(PerimetreType.CONTRAT, NUMCONTRAT);
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).build()));
        assertFalse(contrat.matchContrat(ProduitContratJson.builder().numContrat(OTHERNUMCONTRAT).build()));
        assertFalse(contrat.matchPersonne(NUMERSONNE));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
    }

    @Test
    public void test_contrat_Etoile() {
        final PerimetreJson contratEtoile = perimetre(PerimetreType.CONTRAT, "*");
        assertTrue(contratEtoile.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).build()));
        assertTrue(contratEtoile.matchContrat(ProduitContratJson.builder().numContrat(OTHERNUMCONTRAT).build()));
        assertFalse(contratEtoile.matchPersonne(NUMERSONNE));
        assertFalse(contratEtoile.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(contratEtoile.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
    }

    @Test
    public void test_contrat_produit() {
        final PerimetreJson contrat = perimetre(PerimetreType.PRODUIT, PRODUIT);
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).produit(PRODUIT).build()));
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(OTHERNUMCONTRAT).produit(PRODUIT).build()));
        assertFalse(contrat.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).produit(OTHERRODUIT).build()));
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().produit(PRODUIT).build()));

        assertFalse(contrat.matchPersonne(NUMERSONNE));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
    }

    @Test
    public void test_contrat_filiale() {
        final PerimetreJson contrat = perimetre(PerimetreType.FILIALE, FILIALE);
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().filiale(FILIALE).build()));
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).produit(PRODUIT).filiale(FILIALE).build()));
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(OTHERNUMCONTRAT).produit(PRODUIT).filiale(FILIALE).build()));
        assertTrue(contrat.matchContrat(ProduitContratJson.builder().numContrat(OTHERNUMCONTRAT).produit(PRODUIT).numPersonne(NUMERSONNE).filiale(FILIALE).build()));
        assertFalse(contrat.matchContrat(ProduitContratJson.builder().numContrat(NUMCONTRAT).produit(OTHERRODUIT).filiale(OTHERFILIALE).build()));

        assertFalse(contrat.matchPersonne(NUMERSONNE));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(contrat.match(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
    }

    PerimetreJson perimetre(PerimetreType typePerimetre, String valeurPerimetre) {
        return new PerimetreJson(typePerimetre, valeurPerimetre);
    }
}
