package fr.ag2rlamondiale.trm.domain.blocage;

import org.junit.Test;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static fr.ag2rlamondiale.trm.utils.Sets.set;
import static org.junit.Assert.*;

public class FonctionnalitesTest {

    @Test
    public void add_code() {
        Fonctionnalites fonctionnalites = new Fonctionnalites();
        fonctionnalites.add("CODE");
        assertTrue(fonctionnalites.contains("CODE"));
        assertFalse(fonctionnalites.isToute());
    }

    @Test
    public void addAll_codes() {
        Fonctionnalites fonctionnalites = new Fonctionnalites();
        final List<String> codes = Arrays.asList("C1", "C2");
        fonctionnalites.addAll(codes);
        assertTrue(fonctionnalites.containsAll(codes));
        assertFalse(fonctionnalites.isToute());
    }

    @Test
    public void add_blocageJson() {
        Fonctionnalites fonctionnalites = new Fonctionnalites();
        fonctionnalites.add(new BlocageJson());
        assertEquals(0, fonctionnalites.size());
        assertTrue(fonctionnalites.isToute());
    }

    @Test
    public void add_blocageJson_1() {
        Fonctionnalites fonctionnalites = new Fonctionnalites();
        final BlocageJson blocageJson = new BlocageJson();
        blocageJson.setFonctionnalites(Stream.of("C1", "C2").map(FonctionnaliteJson::new).collect(Collectors.toList()));
        fonctionnalites.add(blocageJson);
        assertEquals(2, fonctionnalites.size());
        assertFalse(fonctionnalites.isToute());
    }

    @Test
    public void forEach() {
        Fonctionnalites fonctionnalites = new Fonctionnalites();
        final BlocageJson blocageJson = new BlocageJson();
        blocageJson.setFonctionnalites(Stream.of("C1", "C2").map(FonctionnaliteJson::new).collect(Collectors.toList()));
        fonctionnalites.add(blocageJson);
        AtomicInteger counter = new AtomicInteger(0);
        fonctionnalites.forEach(s -> counter.incrementAndGet());

        assertEquals(2, fonctionnalites.size());
        assertEquals(2, counter.get());
        assertFalse(fonctionnalites.isToute());
    }

    @Test
    public void cumulFonctionnalites() {
        Fonctionnalites fonctionnalites1 = new Fonctionnalites();
        final BlocageJson blocageJson = new BlocageJson();
        blocageJson.setFonctionnalites(Stream.of("C1", "C2").map(FonctionnaliteJson::new).collect(Collectors.toList()));
        fonctionnalites1.add(blocageJson);

        Fonctionnalites fonctionnalites2 = new Fonctionnalites();
        fonctionnalites2.add(blocageJson);

        final Set<String> codes = Fonctionnalites.cumulFonctionnalites(Arrays.asList(fonctionnalites1, fonctionnalites2));
        assertEquals(2, codes.size());
        assertTrue(codes.contains("C1"));
        assertTrue(codes.contains("C2"));
    }

    @Test
    public void toOldSemantic() {
        Fonctionnalites fonctionnalites1 = new Fonctionnalites();
        final BlocageJson blocageJson = new BlocageJson();
        blocageJson.setFonctionnalites(Stream.of("C1", "C2").map(FonctionnaliteJson::new).collect(Collectors.toList()));
        fonctionnalites1.add(blocageJson);

        Fonctionnalites fonctionnalites2 = new Fonctionnalites();
        fonctionnalites2.add(blocageJson);

        Fonctionnalites fonctionnalites3 = new Fonctionnalites();
        fonctionnalites3.setToute(true);

        Map<String, Fonctionnalites> map = new HashMap<>();
        map.put("F1", fonctionnalites1);
        map.put("F2", fonctionnalites2);
        map.put("F3", fonctionnalites3);

        final Map<String, Set<String>> oldMap = Fonctionnalites.toOldSemantic(map);
        assertEquals(3, oldMap.size());
        assertEquals(set("C1", "C2"), oldMap.get("F1"));
        assertEquals(set("C1", "C2"), oldMap.get("F2"));
        assertTrue(oldMap.get("F3").isEmpty());
    }


}
