package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IEvenementRestClient;
import fr.ag2rlamondiale.trm.domain.evenement.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static org.junit.Assert.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringTestConfig.class})
public class EvenementRestClientImplTest {

    // A1324 AQEA, A1325 AREA

    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.rechercherevenement.url}")
    private String urlRechercherEvenement;

    @Value("${ere.consoleadmin.ws.rest.recherchertypeevenement.url}")
    private String urlRechercherTypeEvenement;

    @Value("${ere.consoleadmin.ws.rest.insertevenement.url}")
    private String urlInsertEvenement;

    @Value("${ere.consoleadmin.ws.rest.updateevenement.url}")
    private String urlUpdateEvenement;

    @Autowired
    private IEvenementRestClient evenementRestClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    private MockRestServiceServer mockServer;

    @Before
    public void setUp() throws Exception {
        mockServer = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    public void rechercherEvenements() throws Exception {
        mockServer.expect(requestTo(new URI(urlRechercherEvenement)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource(
                                "/fixtures/evenementService-findEvenements-A1324-x27cfn.json")));

        List<Predicate<EvenementJson>> predicates = new ArrayList<>();
        predicates.add(evenHasType("ERE_CONF").and(e -> e.getId().equals(20679)));
        predicates.add(evenHasType("ERE_CONF").and(e -> e.getId().equals(20656)));
        predicates.add(evenHasType("ERE_CONF").and(e -> e.getId().equals(20657)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(10091)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(13330)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(15438)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(16361)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(5970)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(6688)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(4203)));
        predicates.add(evenHasType("ERE_VDPP").and(e -> e.getId().equals(16263)));
        predicates.add(evenHasType("ERE_BIA").and(e -> e.getId().equals(20684)));
        predicates.add(evenHasType("ERE_BIA").and(e -> e.getId().equals(19371)));
        predicates.add(evenHasType("ERE_BIA").and(e -> e.getId().equals(20630)));

        EvenementRequeteJson requete = new EvenementRequeteJson();
        requete.setCodeApp("A1324");
        requete.setDate(new Date());
        requete.setIdGdi("x27cfn");
        List<EvenementJson> evens = evenementRestClient.rechercherEvenements(requete);
        mockServer.verify();

        int index = 0;
        for (EvenementJson even : evens) {
            log.info("{}", even);
            assertTrue(predicates.get(index++).test(even));
        }
    }

    private Predicate<EvenementJson> evenHasType(String codeEven) {
        return e -> e.getTypeEvenement().getCodeEvenement().equals(codeEven);
    }

    private Predicate<TypeEvenementJson> isTypeEven(String codeEven) {
        return e -> e.getCodeEvenement().equals(codeEven);
    }

    @Test
    public void rechercherTypesEvenements() throws Exception {
        mockServer.expect(requestTo(new URI(urlRechercherTypeEvenement)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON).body(
                        jsonResource("/fixtures/evenementService-findTypesEvenements-A1324.json")));

        TypeEvenementRequeteJson requete = new TypeEvenementRequeteJson();
        requete.setCodeApp("A1324");
        requete.setDate(new Date());
        final List<TypeEvenementJson> typesEven =
                evenementRestClient.rechercherTypesEvenements(requete);

        mockServer.verify();
        List<Predicate<TypeEvenementJson>> predicates = new ArrayList<>();
        predicates.add(isTypeEven("ERE_CONF"));
        predicates.add(isTypeEven("ERE_PND_3"));
        predicates.add(isTypeEven("ERE_VDPP"));
        predicates.add(isTypeEven("ERE_BIA"));
        predicates.add(isTypeEven("ERE_MDMD"));

        int index = 0;
        for (TypeEvenementJson typeEven : typesEven) {
            log.info("{}", typeEven);
            assertTrue(predicates.get(index++).test(typeEven));
        }
    }

    @Test
    public void insertEvenement() throws Exception {
        mockServer.expect(requestTo(new URI(urlInsertEvenement))).andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON).body(
                        jsonResource("/fixtures/evenementService-insertPost-A1324-x27cfn.json")));

        EvenementJson even = new EvenementJson();
        even.setIdGdi("x27cfn");
        even.setDateDebut(new Date());
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setCodeEvenement("ERE_MDMD");
        even.setTypeEvenement(typeEven);
        EvenementJson ie = evenementRestClient.insertEvenement(even);
        mockServer.verify();

        log.info("INSERTED EVEN {}", ie);
        assertTrue(ie.getId().equals(21926));
    }

    @Test
    public void updateEvenement() throws Exception {
        mockServer.expect(requestTo(new URI(urlUpdateEvenement))).andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON).body(
                        jsonResource("/fixtures/evenementService-updatePost-A1324-x27cfn2.json")));

        EvenementJson even = new EvenementJson();
        even.setId(21925);
        even.setIdGdi("x27cfn");
        even.setDateDebut(new Date());
        even.setDateFin(date("22/01/2019"));
        even.setEtatTraitement(EtatTraitementType.TRAI);
        TypeEvenementJson typeEven = new TypeEvenementJson();
        typeEven.setCodeEvenement("ERE_MDMD");
        even.setTypeEvenement(typeEven);
        EvenementJson ue = evenementRestClient.updateEvenement(even);
        mockServer.verify();

        log.info("UPDATED EVEN {}", ue);
        assertEquals(new Integer(21926), ue.getId());
        assertEquals("22/01/2019", dateToString(ue.getDateFin()));
        assertEquals(EtatTraitementType.TRAI, ue.getEtatTraitement());
    }

    private String jsonResource(String resourcePath) {
        InputStream in = getClass().getResourceAsStream(resourcePath);
        String result = new BufferedReader(new InputStreamReader(in)).lines()
                .collect(Collectors.joining("\n"));
        return result;
    }

    private Date date(String dt) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(dt);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    private String dateToString(Date dt) {
        return new SimpleDateFormat("dd/MM/yyyy").format(dt);
    }
}
