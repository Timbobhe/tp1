
package fr.ag2rlamondiale.trm.domain.blocage;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

/**
* Test InfosBlocagesClient
*/
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class InfosBlocagesClientTest {
    @Test
    public void contratGeneralBean() {
        new BeanTester().testBean(InfosBlocagesClient.class);
    }

    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(InfosBlocagesClient.class)
                .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
}
