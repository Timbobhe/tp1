package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.domain.gdi.CguDetails;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@Configuration
@RunWith(MockitoJUnitRunner.class)
public class CguRestClientImplTest {
    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private CguRestClientImpl cguRestClient;

    @Before
    public void init() {
        ReflectionTestUtils.setField(cguRestClient, "token", "ABCDEF");
        ReflectionTestUtils.setField(cguRestClient, "uriAcceptedCgu", "http://uriAcceptedCgu");
        ReflectionTestUtils.setField(cguRestClient, "uriCreateAcceptationCgu",
                "http://uriCreateAcceptationCgu");
        ReflectionTestUtils.setField(cguRestClient, "uriPCCgu", "http://uriPCCgu");

    }

    private <T> HttpEntity<String> jsonHttpEntityWithAuthorization() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "ABCDEF");
        return new HttpEntity<>(headers);
    }

    @Test
    public void getCguDetails() {
        CguDetails cguMock = new CguDetails();
        cguMock.setIdCgu("idCgu");
        cguMock.setTextCgu("textCgu");
        cguMock.setUrlPdfCgu("urlPdfCgu");
        ResponseEntity<CguDetails> rep = new ResponseEntity<>(cguMock, HttpStatus.ACCEPTED);
        when(restTemplate.exchange("http://uriPCCgu", HttpMethod.GET,
                jsonHttpEntityWithAuthorization(), CguDetails.class)).thenReturn(rep);
        CguDetails details = cguRestClient.getCguDetails();
        assertTrue("idCgu".equals(details.getIdCgu()));
        assertTrue("textCgu".equals(details.getTextCgu()));
        assertTrue("urlPdfCgu".equals(details.getUrlPdfCgu()));
    }

    @Test
    public void getCguDetailsFail() {
        when(restTemplate.exchange("http://uriPCCgu", HttpMethod.GET,
                jsonHttpEntityWithAuthorization(), CguDetails.class))
                        .thenThrow(RestClientException.class);
        CguDetails details = cguRestClient.getCguDetails();
        assertTrue(details == null);
    }

    @Test
    public void getAcceptedGguIds() {
        final String[] rep = {"a"};
        when(restTemplate.postForObject("http://uriAcceptedCgu", "1", String[].class))
                .thenReturn(rep);

        List<String> liste = cguRestClient.getAcceptedGguIds(1);
        assertEquals(1, liste.size());
    }

    @Test
    public void getAcceptedGguIdsFail() {
        when(restTemplate.postForObject("http://uriAcceptedCgu", "1", String[].class))
                .thenThrow(RestClientException.class);

        List<String> liste = cguRestClient.getAcceptedGguIds(1);
        assertEquals(0, liste.size());
    }

    @Test
    public void createAcceptationCgu() {
        ResponseEntity<String> rep = new ResponseEntity<>(HttpStatus.ACCEPTED);

        when(restTemplate.exchange("http://uriCreateAcceptationCgu", HttpMethod.POST,
                formHttpEntity(1,"idCgu"), String.class)).thenReturn(rep);
        assertTrue(cguRestClient.createAcceptationCgu(1, "idCgu"));
    }

    @Test
    public void createAcceptationCguFail() {
        
        when(restTemplate.exchange("http://uriCreateAcceptationCgu", HttpMethod.POST,
                formHttpEntity(1,"idCgu"), String.class)).thenThrow(RestClientException.class);
        assertFalse(cguRestClient.createAcceptationCgu(1, "idCgu"));

    }
    
    private HttpEntity<MultiValueMap<String, String>> formHttpEntity(Integer idCxp,String idCgu) {
        MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
        map.add("idCxp", idCxp.toString());
        map.add("idCgu", idCgu);
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return new HttpEntity<>(map, headers);
    }
}
