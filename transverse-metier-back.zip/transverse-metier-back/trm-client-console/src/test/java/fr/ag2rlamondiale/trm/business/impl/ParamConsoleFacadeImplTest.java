package fr.ag2rlamondiale.trm.business.impl;

import fr.ag2rlamondiale.trm.business.impl.parametre.IParametreProvider;
import fr.ag2rlamondiale.trm.business.impl.produit.IProduitProvider;
import fr.ag2rlamondiale.trm.business.impl.qad.IQadProvider;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ParamConsoleFacadeImplTest {

    @InjectMocks
    ParamConsoleFacadeImpl paramConsoleFacade;

    @Mock
    IProduitProvider produitProvider;

    @Mock
    IQadProvider qadProvider;

    @Mock
    IParametreProvider parametreProvider;

    @Before
    public void setUp() {
        when(qadProvider.getSupportsInvestissement(eq("9495"))).thenReturn(
                supportInvestissement("9495", "24 trimestres"));

        when(qadProvider.getSupportsInvestissement(eq("9262"))).thenReturn(
                supportInvestissement("9262", "Allocation Diversifiée"));

        when(qadProvider.getSupportsInvestissement(eq("9470"))).thenReturn(
                supportInvestissement("9470", "Grille Equilibre RECOSUP"));


        when(produitProvider.findProduitMdpro(eq("PF71"), eq(null))).thenReturn(
                produitMDP("PF71", null, "Rente à vie une tête"));

        when(produitProvider.findProduitMdpro(eq("RF10"), eq("V04"))).thenReturn(
                produitMDP("RF10", "V04", "Mondiale Retraite Plus"));

        when(produitProvider.findProduitMdpro(eq("TV02"), eq("V01"))).thenReturn(
                produitMDP("TV02", "V01", "Rente Viagère"));


        when(produitProvider.findProduitEre(eq("ARI"), eq("RG01"), eq("001"))).thenReturn(
                Optional.of(produit("RG01", "001", "PERO_1", "ARI")));

        when(produitProvider.findProduitEre(eq("ARI"), eq("RG01"), eq("002"))).thenReturn(
                Optional.of(produit("RG01", "002", "PERO_2", "ARI")));

        when(produitProvider.findProduitEre(eq("ARI"), eq("RG01"), eq("003"))).thenReturn(
                Optional.of(produit("RG01", "003", "Mondial Retraite", "ARI")));
    }

    @Test
    public void findProduitMdpro() {
        paramConsoleFacade.findProduitMdpro("inconnu");
        verify(produitProvider).findProduitMdpro("inconnu");

        paramConsoleFacade.findProduitMdpro("PF71");
        verify(produitProvider).findProduitMdpro("PF71");

        paramConsoleFacade.findProduitMdpro("PF71   ");
        verify(produitProvider).findProduitMdpro("PF71   ");

        paramConsoleFacade.findProduitMdpro("RF10V04");
        verify(produitProvider).findProduitMdpro("RF10V04");

        paramConsoleFacade.findProduitMdpro("TV02V01");
        verify(produitProvider).findProduitMdpro("TV02V01");
    }

    @Test
    public void findProduitEre() {
        Optional<ProduitJson> rg01001ari = paramConsoleFacade.findProduitEre("ARI", "RG01", "001");
        Assert.assertTrue(rg01001ari.isPresent());
        Assert.assertNotNull(rg01001ari.get());
        assertEquals("PERO_1", rg01001ari.get().getLibelle());

        Optional<ProduitJson> rg01002ari = paramConsoleFacade.findProduitEre("ARI", "RG01", "002");
        Assert.assertTrue(rg01002ari.isPresent());
        Assert.assertNotNull(rg01002ari.get());
        assertEquals("PERO_2", rg01002ari.get().getLibelle());

        Optional<ProduitJson> rg01003ari = paramConsoleFacade.findProduitEre("ARI", "RG01", "003");
        Assert.assertTrue(rg01003ari.isPresent());
        Assert.assertNotNull(rg01003ari.get());
        assertEquals("Mondial Retraite", rg01003ari.get().getLibelle());

        Optional<ProduitJson> rg02003ari = paramConsoleFacade.findProduitEre("ARI", "RG02", "003");
        verify(produitProvider).findProduitEre("ARI", "RG02", "003");

        Optional<ProduitJson> rg01004ari = paramConsoleFacade.findProduitEre("ARI", "RG01", "004");
        verify(produitProvider).findProduitEre("ARI", "RG01", "004");

        Optional<ProduitJson> rg01001aca = paramConsoleFacade.findProduitEre("ACA", "RG01", "001");
        verify(produitProvider).findProduitEre("ACA", "RG01", "001");

    }

    @Test
    public void getSupportsInvestissement() {
        final SupportInvestissementJson sup9495 = paramConsoleFacade.getSupportsInvestissement("9495");
        assertEquals("24 trimestres", sup9495.getLibelleFront());

        final SupportInvestissementJson sup9262 = paramConsoleFacade.getSupportsInvestissement("9262");
        assertEquals("Allocation Diversifiée", sup9262.getLibelleFront());

        final SupportInvestissementJson inconnu = paramConsoleFacade.getSupportsInvestissement("inconnu");
        assertNull(inconnu);
    }

    @Test
    public void reloadCache() {
        paramConsoleFacade.reloadCache();

        final ProduitJson pf71 = paramConsoleFacade.findProduitMdpro("PF71");
        verify(produitProvider).findProduitMdpro("PF71");

        final SupportInvestissementJson sup9495 = paramConsoleFacade.getSupportsInvestissement("9495");
        verify(qadProvider).getSupportsInvestissement("9495");

        verify(qadProvider).reloadCache();
        verify(produitProvider).reloadCache();
    }


    @Test
    public void firstLoadCache() {
        paramConsoleFacade.firstLoadCache();

        paramConsoleFacade.findProduitMdpro("PF71");
        verify(produitProvider).findProduitMdpro("PF71");

        paramConsoleFacade.getSupportsInvestissement("9495");
        verify(qadProvider).getSupportsInvestissement("9495");

        verify(qadProvider).reloadCache();
        verify(produitProvider).reloadCache();
    }

    @Test
    public void clearCache() {
        paramConsoleFacade.clearCache();
        verify(qadProvider).reloadCache();
        verify(produitProvider).reloadCache();
    }

    private SupportInvestissementJson supportInvestissement(String code, String libelle) {
        SupportInvestissementJson support = new SupportInvestissementJson();
        support.setCodeSupport(code);
        support.setLibelleFront(libelle);
        return support;
    }

    private ProduitJson produitMDP(String typeContrat, String numGene, String libelle) {
        return produit(typeContrat, numGene, libelle, "LMX");
    }

    private ProduitJson produit(String typeContrat, String numGene, String libelle, String filiale) {
        ProduitJson p = new ProduitJson();
        p.setCodeFiliale(filiale);
        p.setTypeContrat(typeContrat);
        p.setNumeroGeneration(numGene);
        p.setLibelle(libelle);
        return p;
    }
}
