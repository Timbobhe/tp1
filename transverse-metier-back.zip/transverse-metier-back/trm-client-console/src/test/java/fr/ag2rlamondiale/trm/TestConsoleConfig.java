package fr.ag2rlamondiale.trm;

import fr.ag2rlamondiale.trm.utils.SelfReferencingBeanPostProcessor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConsoleConfig {

    @Bean
    public SelfReferencingBeanPostProcessor selfReferencingBeanPostProcessor() {
        return new SelfReferencingBeanPostProcessor();
    }
}
