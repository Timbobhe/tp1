package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.*;
import fr.ag2rlamondiale.trm.log.LogErrorInterceptor;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.stream.Collectors;

@Configuration
@Import(value = {RestConfig.class})
// @TestPropertySource(locations = "classpath:webservices-rest.properties")
public class SpringTestConfig {

    @Bean
    public LogErrorInterceptor logErrorInterceptor() {
        return new LogErrorInterceptor();
    }

    @Bean
    public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer() throws IOException {
        final PropertyPlaceholderConfigurer ppc = new PropertyPlaceholderConfigurer();
        ppc.setLocations(
                new PathMatchingResourcePatternResolver().getResources("classpath:webservices-rest.properties"));

        return ppc;
    }

    @Bean
    public IPartenaireRestClient partenaireRestClient() {
        return new PartenaireRestClientImpl();
    }

    @Bean
    public IEvenementRestClient evenementRestClient() {
        return new EvenementRestClientImpl();
    }

    @Bean
    public IQadRestClient qadRestClient() {
        return new QadRestClientImpl();
    }

    @Bean
    public ISujetRestClient sujetRestClient() {
        return new SujetRestClientImpl();
    }

    @Bean
    public IPaiementCbRestClient paiementCbRestClient() {
        return new PaiementCbRestClientImpl();
    }

    public static Date date(String dt) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy").parse(dt);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    public static String dateToString(Date dt) {
        return new SimpleDateFormat("dd/MM/yyyy").format(dt);
    }
}
