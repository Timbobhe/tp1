
package fr.ag2rlamondiale.trm.domain.blocage;

import fr.ag2rlamondiale.trm.domain.PerimetreType;
import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.asList;
import static org.junit.Assert.*;

/**
 * Test BlocageJson
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class BlocageJsonTest {

    public static final String NUMERSONNE = "NUMERSONNE";
    private static final String OTHERNUMERSONNE = "OTHERNUMERSONNE";
    private static final String NUMCONTRAT = "NUMCONTRAT";
    private static final String OTHERNUMCONTRAT = "OTHERNUMCONTRAT";
    private static final String PRODUIT = "PRODUIT";
    private static final String OTHERRODUIT = "OTHERPRODUIT";
    private static final String FILIALE = "FILIALE";
    private static final String OTHERFILIALE = "OTHERFILIALE";

    @Test
    public void contratGeneralBean() {
        new BeanTester().testBean(BlocageJson.class);
    }

    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(BlocageJson.class)
                .withOnlyTheseFields("idBlo")
                .withRedefinedSuperclass()
                .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }

    @Test
    public void test_isToutesFonctionnalites() {
        BlocageJson blocageJson1 = new BlocageJson();
        assertTrue(blocageJson1.isToutesFonctionnalites());

        BlocageJson blocageJson2 = new BlocageJson();
        blocageJson2.setFonctionnalites(new ArrayList<>(0));
        assertTrue(blocageJson2.isToutesFonctionnalites());

        BlocageJson blocageJson3 = new BlocageJson();
        blocageJson3.setFonctionnalites(Stream.of("F1").map(FonctionnaliteJson::new).collect(Collectors.toList()));
        assertFalse(blocageJson3.isToutesFonctionnalites());
    }

    @Test
    public void test_noneMatchException_true() {
        BlocageJson blocageJson1 = new BlocageJson();
        assertTrue(blocageJson1.noneMatchException(new ProduitContratJson()));
        assertTrue(blocageJson1.noneMatchException("NUMPERSONNE"));

        BlocageJson blocageJson3 = new BlocageJson();
        blocageJson3.setExceptionBlocages(asList(except(PerimetreType.PERSONNE, NUMERSONNE), except(PerimetreType.PERSONNE, OTHERNUMERSONNE)));
        assertTrue(blocageJson3.noneMatchException(ProduitContratJson.builder().numContrat(NUMCONTRAT).build()));
        assertTrue(blocageJson3.noneMatchException("xxx"));
        assertTrue(blocageJson3.noneMatchException(ProduitContratJson.builder().numPersonne("xxx").build()));
    }

    @Test
    public void test_noneMatchException_false() {
        BlocageJson blocageJson1 = new BlocageJson();
        blocageJson1.setExceptionBlocages(asList(except(PerimetreType.PERSONNE, NUMERSONNE)));
        assertFalse(blocageJson1.noneMatchException(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(blocageJson1.noneMatchException(NUMERSONNE));

        BlocageJson blocageJson2 = new BlocageJson();
        blocageJson2.setExceptionBlocages(asList(except(PerimetreType.PERSONNE, NUMERSONNE), except(PerimetreType.PERSONNE, OTHERNUMERSONNE)));
        assertFalse(blocageJson2.noneMatchException(ProduitContratJson.builder().numPersonne(NUMERSONNE).build()));
        assertFalse(blocageJson2.noneMatchException(NUMERSONNE));
        assertFalse(blocageJson2.noneMatchException(ProduitContratJson.builder().numPersonne(OTHERNUMERSONNE).build()));
        assertFalse(blocageJson2.noneMatchException(OTHERNUMERSONNE));
    }

    ExceptionBlocageJson except(PerimetreType typePerimetre, String valeurPerimetre) {
        return new ExceptionBlocageJson(typePerimetre, valeurPerimetre);
    }

}
