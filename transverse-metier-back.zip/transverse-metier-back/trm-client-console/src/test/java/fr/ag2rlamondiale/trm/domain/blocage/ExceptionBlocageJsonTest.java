
package fr.ag2rlamondiale.trm.domain.blocage;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

/**
* Test ExceptionBlocageJson
*/
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ExceptionBlocageJsonTest {
    @Test
    public void contratGeneralBean() {
        new BeanTester().testBean(ExceptionBlocageJson.class);
    }

    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(ExceptionBlocageJson.class)
                .withRedefinedSuperclass()
                .suppress(Warning.STRICT_INHERITANCE, Warning.STRICT_HASHCODE, Warning.NONFINAL_FIELDS).verify();
    }
}
