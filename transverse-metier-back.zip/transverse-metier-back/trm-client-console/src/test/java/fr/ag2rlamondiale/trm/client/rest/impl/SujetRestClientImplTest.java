package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.ISujetRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.sujet.LectureSujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestJson;
import fr.ag2rlamondiale.trm.domain.sujet.SujetRequestListJson;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.testing.json.JsonTestUtils.jsonResource;
import static fr.ag2rlamondiale.trm.utils.Sets.set;
import static org.junit.Assert.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringTestConfig.class})
public class SujetRestClientImplTest {
    @Autowired
    private RestTemplate restTemplate;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/getSujets")
    private String getSujetsUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/getSujetsParUtilisateur")
    private String getSujetsParUtilisateurUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/createSujetParUtilisateur")
    private String createSujetParUtilisateurUrl;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sujetService/updateSujetParUtilisateur")
    private String updateSujetParUtilisateurUrl;

    @Autowired
    private ISujetRestClient sujetRestClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    private MockRestServiceServer mockServer;

    private static final String IDGDI = "mgonif";
    private static final Integer IDSUJET = -1;

    @Before
    public void setUp() throws Exception {
        mockServer = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    public void createSujetParUtilisateurTest() throws Exception {
        mockServer.expect(requestTo(new URI(createSujetParUtilisateurUrl))).andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-createSujetParUtilisateur.json")));

        SujetRequestListJson request = new SujetRequestListJson();
        List<Integer> idSujets = new ArrayList<>();
        idSujets.add(-1);

        request.setIdSujets(idSujets);
        request.setIdGdi(IDGDI);
        List<LectureSujetJson> result = sujetRestClient.createSujetParUtilisateur(request);
        mockServer.verify();

        assertEquals(IDSUJET, result.get(0).getSujet().getIdSujet());
        assertEquals(IDGDI, result.get(0).getIdGdi());
        assertNull(result.get(0).getDateLecture());
    }

    @Test
    public void updateSujetParUtilisateurTest() throws Exception {
        mockServer.expect(requestTo(new URI(updateSujetParUtilisateurUrl))).andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-updateSujetParUtilisateur.json")));

        SujetRequestJson request = new SujetRequestJson();
        request.setIdSujet(IDSUJET);
        request.setIdGdi(IDGDI);
        LectureSujetJson result = sujetRestClient.updateSujetLuParUtilisateur(request);
        mockServer.verify();

        assertEquals(IDSUJET, result.getSujet().getIdSujet());
        assertEquals(IDGDI, result.getIdGdi());
        assertNotNull(result.getDateLecture());
    }

    @Test
    public void getSujetsParUtilisateurTest() throws Exception {
        mockServer.expect(requestTo(new URI(getSujetsParUtilisateurUrl))).andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-getSujetsParUtilisateur.json")));

        SujetRequestJson request = new SujetRequestJson();
        request.setIdGdi(IDGDI);
        List<LectureSujetJson> list = sujetRestClient.getSujetsParUtilisateur(request);
        mockServer.verify();

        assertEquals(1, list.size());
        assertEquals("Comprendre la retraite", list.get(0).getSujet().getTitre());
    }

    @Test
    public void getSujetsTest_ERE() throws Exception {
        mockServer.expect(requestTo(new URI(getSujetsUrl))).andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-getSujets.json")));

        final List<SujetJson> sujets = sujetRestClient.getSujets(set(CodeSiloType.ERE));
        mockServer.verify();

        assertEquals(5, sujets.size());
        for (SujetJson sujetJson : sujets) {
            assertTrue(sujetJson.getCodeSilo() == null || sujetJson.getCodeSilo().equals(CodeSiloType.ERE));
            for (SujetJson sousSujet : sujetJson.getSousSujets()) {
                assertTrue(sousSujet.getCodeSilo() == null || sousSujet.getCodeSilo().equals(CodeSiloType.ERE));
            }
        }

    }

    @Test
    public void getSujetsTest_ERE_prod() throws Exception {
        mockServer.expect(requestTo(new URI(getSujetsUrl))).andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-getSujets-prod.json")));

        final List<SujetJson> sujets = sujetRestClient.getSujets(set(CodeSiloType.ERE));
        mockServer.verify();

        assertEquals(5, sujets.size());
        for (SujetJson sujetJson : sujets) {
            assertTrue(sujetJson.getCodeSilo() == null || sujetJson.getCodeSilo().equals(CodeSiloType.ERE));
            for (SujetJson sousSujet : sujetJson.getSousSujets()) {
                assertTrue(sousSujet.getCodeSilo() == null || sousSujet.getCodeSilo().equals(CodeSiloType.ERE));
            }
        }

    }

    @Test
    public void getSujetsTest_MDP() throws Exception {
        mockServer.expect(requestTo(new URI(getSujetsUrl))).andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-getSujets.json")));

        final List<SujetJson> sujets = sujetRestClient.getSujets(set(CodeSiloType.MDP));
        mockServer.verify();

        assertEquals(5, sujets.size());
        for (SujetJson sujetJson : sujets) {
            assertTrue(sujetJson.getCodeSilo() == null || sujetJson.getCodeSilo().equals(CodeSiloType.MDP));
            for (SujetJson sousSujet : sujetJson.getSousSujets()) {
                assertTrue(sousSujet.getCodeSilo() == null || sousSujet.getCodeSilo().equals(CodeSiloType.MDP));
            }
        }
    }

    @Test
    public void getSujetsTest_ERE_MDP() throws Exception {
        mockServer.expect(requestTo(new URI(getSujetsUrl))).andExpect(method(HttpMethod.GET))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource("/fixtures/sujetService-getSujets.json")));

        final List<SujetJson> sujets = sujetRestClient.getSujets(set(CodeSiloType.MDP, CodeSiloType.ERE));
        mockServer.verify();

        assertEquals(6, sujets.size());

        final Map<Integer, SujetJson> sujetsMap = sujets.stream().collect(Collectors.toMap(SujetJson::getIdSujet, sujetJson -> sujetJson));
        assertNotNull(sujetsMap.get(-4));
        final SujetJson sujetJsonMDP = sujetsMap.get(-4);
        assertEquals(CodeSiloType.MDP, sujetJsonMDP.getCodeSilo());

        assertNotNull(sujetsMap.get(4));
        final SujetJson sujetJsonERE = sujetsMap.get(4);
        assertEquals(CodeSiloType.ERE, sujetJsonERE.getCodeSilo());

        assertNotNull(sujetsMap.get(3));
        final SujetJson sujetJsonMixte = sujetsMap.get(3);
        assertNull(sujetJsonMixte.getCodeSilo());
        assertTrue(sujetJsonMixte.getSousSujets().stream().allMatch(sujetJson -> sujetJson.getCodeSilo() == null || sujetJson.getCodeSilo().equals(CodeSiloType.ERE)));
    }

}
