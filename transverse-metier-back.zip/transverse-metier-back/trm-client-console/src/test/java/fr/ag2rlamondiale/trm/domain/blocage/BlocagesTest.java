package fr.ag2rlamondiale.trm.domain.blocage;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.PerimetreType;
import org.junit.Test;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static java.util.Arrays.asList;
import static junit.framework.Assert.assertFalse;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.assertTrue;

public class BlocagesTest {

    AtomicInteger atomicInteger = new AtomicInteger();

    private static final String NUM_PERSONNE_ERE_9KRXOA = "P3926647";
    private static final String NUM_PERSONNE_ERE_Z3GHY4 = "P4317436";
    private static final String NUM_PERSONNE_MDP_Z3GHY4 = "P2224552";

    private static final String CONTRAT1_9KRXOA = "RG150612579";
    private static final String CONTRAT2_9KRXOA = "RP150612773";

    private static final String CONTRAT_ERE_Z3GHYH = "RG151095348";
    private static final String CONTRAT_MDP_Z3GHYH = "RF049057071116";

    private static final String RG01_012_ARI = "RG01-012-ARI";
    private static final String RG01_001_ARI = "RG01-001-ARI";
    private static final String RP01_002_ARI = "RP01-002-ARI";
    private static final String RF02_V01_LMX = "RF02-V01-LMX";

    private static final String LMX = "LMX";
    private static final String ARI = "ARI";

    private static final String ERE = "ERE";
    private static final String MDP = "MDP";

    @Test
    public void testSansBlocages() {
        //Given
        Blocages blocages = new Blocages(new ArrayList<>());

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertTrue(blocagesContrat.values().stream().allMatch(Fonctionnalites::isAucune));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageTotal() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.TOUT, "*", ERE,
                Arrays.asList("ContactFormulaire", "vosDonnes"),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertEquals(2, blocagesPersonne.size());
        assertTrue(blocagesPersonne.containsAll(Arrays.asList("ContactFormulaire", "vosDonnes")));
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).isAucune());
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA).isAucune());
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageTotalAvecExceptionALaPersonne() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.TOUT, "*", ERE,
                Arrays.asList("ContactFormulaire", "vosDonnes"),
                mockExceptionBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_9KRXOA)));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).isAucune());
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA).isAucune());
        assertEquals(1, blocages.getBlocageJsonList().size());
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageALaPersonne() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_9KRXOA, ERE,
                asList("ContactFormulaire", "vosDonnes"),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertEquals(2, blocagesPersonne.size());
        assertTrue(blocagesPersonne.containsAll(asList("ContactFormulaire", "vosDonnes")));
        assertTrue(blocagesContrat.values().stream().allMatch(Fonctionnalites::isAucune));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageALaPersonneToutesFonctionnalites() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_9KRXOA, ERE,
                new ArrayList<>(),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertTrue(blocagesContrat.values().stream().allMatch(Fonctionnalites::isAucune));
        assertTrue(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurContrat() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(2, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).containsAll(asList("vosDonnees", "ContactFormulaire")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurContratAvecException() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                mockExceptionBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_9KRXOA)));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertTrue(blocagesContrat.values().stream().allMatch(Fonctionnalites::isAucune));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContrat() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                asList("vosDonnees", "versementLibre"),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(2, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertEquals(2, blocagesContrat.get(CONTRAT2_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).containsAll(asList("vosDonnees", "ContactFormulaire")));
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA).containsAll(asList("vosDonnees", "versementLibre")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContratEtBlocageFiliale() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                asList("vosDonnees", "versementLibre"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.FILIALE, ARI, ERE,
                asList("versementProgramme", "EvolutionEncours"),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(4, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertEquals(4, blocagesContrat.get(CONTRAT2_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA)
                .containsAll(asList("vosDonnees", "ContactFormulaire", "versementProgramme", "EvolutionEncours")));
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA)
                .containsAll(asList("vosDonnees", "versementLibre", "versementProgramme", "EvolutionEncours")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContratEtBlocageFilialeAvecExceptionSurContrat() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                asList("vosDonnees", "versementLibre"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.FILIALE, ARI, ERE,
                asList("versementProgramme", "EvolutionEncours"),
                mockExceptionBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA)));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(2, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertEquals(4, blocagesContrat.get(CONTRAT2_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).containsAll(asList("vosDonnees", "ContactFormulaire")));
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA)
                .containsAll(asList("vosDonnees", "versementLibre", "versementProgramme", "EvolutionEncours")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContratEtBlocageFilialeAvecExceptionSurPersonne() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                asList("vosDonnees", "versementLibre"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.FILIALE, ARI, ERE,
                asList("versementProgramme", "EvolutionEncours"),
                mockExceptionBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_9KRXOA)));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(2, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertEquals(2, blocagesContrat.get(CONTRAT2_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).containsAll(asList("vosDonnees", "ContactFormulaire")));
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA)
                .containsAll(asList("vosDonnees", "versementLibre")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContratEtBlocageFilialeAvecExceptionSurProduit() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                asList("vosDonnees", "ContactFormulaire"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                asList("vosDonnees", "versementLibre"),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.FILIALE, ARI, ERE,
                asList("versementProgramme", "EvolutionEncours"),
                mockExceptionBlocage(PerimetreType.PRODUIT, RP01_002_ARI)));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertEquals(4, blocagesContrat.get(CONTRAT1_9KRXOA).size());
        assertEquals(2, blocagesContrat.get(CONTRAT2_9KRXOA).size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).containsAll(asList("vosDonnees", "ContactFormulaire")));
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA).containsAll(asList("vosDonnees", "versementLibre")));
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testBlocageDirectSurTousLesContratToutesFonctionnalites() {
        //Given
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT1_9KRXOA, ERE,
                new ArrayList<>(),
                new ArrayList<>()));
        blocageJsonList.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT2_9KRXOA, ERE,
                new ArrayList<>(),
                new ArrayList<>()));
        Blocages blocages = new Blocages(blocageJsonList);

        //When
        List<String> blocagesPersonne = blocages.calculerFonctionnalitesBloqueesAlaPersonne(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE);
        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContrats9KRXOA());

        //Then
        assertTrue(blocagesPersonne.isEmpty());
        assertEquals(2, blocagesContrat.size());
        assertTrue(blocagesContrat.get(CONTRAT1_9KRXOA).isToute());
        assertTrue(blocagesContrat.get(CONTRAT2_9KRXOA).isToute());
        assertFalse(blocages.isPersonneTotalementBloquee(NUM_PERSONNE_ERE_9KRXOA, mockContrats9KRXOA(), CodeSiloType.ERE));
    }

    @Test
    public void testGetBlocagesPersonnesMultiEquipeEreMdPro() {
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.addAll(mockBlocagesERE());
        blocageJsonList.addAll(mockBlocagesMDPRO());
        Blocages blocages = new Blocages(blocageJsonList);

        List<String> blocagesPersonneERE = blocages.calculerFonctionnalitesBloqueesAlaPersonne("P4317436", mockContratsZ3GHY4(), CodeSiloType.ERE);
        List<String> blocagesPersonneMDPRO = blocages.calculerFonctionnalitesBloqueesAlaPersonne("P2224552", mockContratsZ3GHY4(), CodeSiloType.MDP);
        assertEquals(2, blocagesPersonneERE.size());
        assertEquals(2, blocagesPersonneMDPRO.size());
        assertTrue(blocagesPersonneERE.containsAll(asList("VosDonneesContract", "ContactFormulaire")));
        assertTrue(blocagesPersonneMDPRO.containsAll(asList("versementProgramme", "ContactFormulaire")));
    }

    @Test
    public void testGetBlocagesContratsMultiEquipeEreMdPro() {
        List<BlocageJson> blocageJsonList = new ArrayList<>();
        blocageJsonList.addAll(mockBlocagesERE());
        blocageJsonList.addAll(mockBlocagesMDPRO());
        Blocages blocages = new Blocages(blocageJsonList);

        Map<String, Fonctionnalites> blocagesContrat = blocages.calculerFonctionnalitesBloqueesContrats(mockContratsZ3GHY4());
        assertEquals(2, blocagesContrat.size());
        assertEquals(4, blocagesContrat.get("RF049057071116").size());
        assertEquals(2, blocagesContrat.get("RG151095348").size());
        assertTrue(blocagesContrat.get("RF049057071116")
                .containsAll(asList("versementLibre", "SimulateurFiscal", "GestionFinanciere", "EvolutionSupport")));
        assertTrue(blocagesContrat.get("RG151095348")
                .containsAll(asList("versementLibre", "VosCoordonneesBancaires")));

    }

    private List<ProduitContratJson> mockContratsZ3GHY4() {
        List<ProduitContratJson> contrats = new ArrayList<>();
        contrats.add(buildContrat(CONTRAT_ERE_Z3GHYH, RG01_012_ARI, ARI, NUM_PERSONNE_ERE_Z3GHY4, ERE));
        contrats.add(buildContrat(CONTRAT_MDP_Z3GHYH, RF02_V01_LMX, LMX, NUM_PERSONNE_MDP_Z3GHY4, MDP));
        return contrats;
    }

    private List<ProduitContratJson> mockContrats9KRXOA() {
        List<ProduitContratJson> contrats = new ArrayList<>();
        contrats.add(buildContrat(CONTRAT1_9KRXOA, RG01_001_ARI, ARI, NUM_PERSONNE_ERE_9KRXOA, ERE));
        contrats.add(buildContrat(CONTRAT2_9KRXOA, RP01_002_ARI, ARI, NUM_PERSONNE_ERE_9KRXOA, ERE));
        return contrats;
    }

    private ProduitContratJson buildContrat(String numContrat, String produit, String filiale, String numPersonne,
                                            String silo) {
        ProduitContratJson contrat = new ProduitContratJson();
        contrat.setNumContrat(numContrat);
        contrat.setProduit(produit);
        contrat.setFiliale(filiale);
        contrat.setNumPersonne(numPersonne);
        contrat.setCodeSiloType(silo);
        return contrat;
    }

    private List<FonctionnaliteJson> mockFonctionnalites(List<String> codesFct) {
        List<FonctionnaliteJson> fonctionnalites = new ArrayList<>();
        codesFct.forEach(codeFct -> {
            FonctionnaliteJson fonctionnalite = new FonctionnaliteJson();
            fonctionnalite.setIdFct(atomicInteger.getAndIncrement());
            fonctionnalite.setTypeFct("MENU");
            fonctionnalite.setCodeFct(codeFct);
            fonctionnalite.setLibelleFct("libelle");
            fonctionnalite.setTypeAcces("A1324");
            fonctionnalites.add(fonctionnalite);
        });
        return fonctionnalites;
    }

    private List<ExceptionBlocageJson> mockExceptionBlocage(PerimetreType perimetreType, String valeur) {
        List<ExceptionBlocageJson> exceptions = new ArrayList<>();
        ExceptionBlocageJson exception = new ExceptionBlocageJson();
        exception.setTypePerimetre(perimetreType);
        exception.setValeurPerimetre(valeur);
        exceptions.add(exception);
        return exceptions;
    }

    private BlocageJson buildBlocage(PerimetreType perimetre, String valeurPerimetre, String silo,
                                     List<String> fonctionnalites,
                                     List<ExceptionBlocageJson> exceptions) {
        BlocageJson blocage = BlocageJson.blocageJsonBuilder()
                .idBlo(atomicInteger.getAndIncrement())
                .typeAcces("A1324")
                .commentaire("aaa")
                .lidBlocage("AAAA")
                .dateCreation("1576599555000")
                .codeSiloType(silo)
                .fonctionnalites(mockFonctionnalites(fonctionnalites))
                .exceptionBlocages(exceptions)
                .build();
        blocage.setTypePerimetre(perimetre);
        blocage.setValeurPerimetre(valeurPerimetre);
        return blocage;
    }

    private List<BlocageJson> mockBlocagesERE() {
        List<BlocageJson> blocages = new ArrayList<>();
        blocages.add(buildBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_ERE_Z3GHY4, ERE,
                asList("VosDonneesContract", "ContactFormulaire"),
                new ArrayList<>()));
        blocages.add(buildBlocage(PerimetreType.CONTRAT, CONTRAT_ERE_Z3GHYH, ERE,
                Collections.singletonList("versementLibre"),
                new ArrayList<>()));
        blocages.add(buildBlocage(PerimetreType.PRODUIT, RG01_012_ARI, ERE,
                Collections.singletonList("VosCoordonneesBancaires"),
                new ArrayList<>()));
        blocages.add(buildBlocage(PerimetreType.FILIALE, ARI, ERE,
                Collections.singletonList("SimulateurFiscal"),
                mockExceptionBlocage(PerimetreType.PRODUIT, "RG01-012-ARI")));
        return blocages;
    }

    private List<BlocageJson> mockBlocagesMDPRO() {
        List<BlocageJson> blocages = new ArrayList<>();
        blocages.add(buildBlocage(PerimetreType.PERSONNE, NUM_PERSONNE_MDP_Z3GHY4, MDP,
                asList("versementProgramme", "ContactFormulaire"),
                new ArrayList<>()));
        blocages.add(buildBlocage(PerimetreType.PRODUIT, RF02_V01_LMX, MDP,
                asList("versementLibre", "SimulateurFiscal"),
                new ArrayList<>()));
        blocages.add(buildBlocage(PerimetreType.FILIALE, LMX, MDP,
                asList("GestionFinanciere", "EvolutionSupport"),
                mockExceptionBlocage(PerimetreType.PRODUIT, "RG01-012-ARI")));
        return blocages;
    }
}
