package fr.ag2rlamondiale.trm.domain;

import fr.ag2rlamondiale.trm.ClientConsoleConfig;
import fr.ag2rlamondiale.trm.domain.blocage.BlocageJson;
import fr.ag2rlamondiale.trm.domain.blocage.Blocages;
import fr.ag2rlamondiale.trm.domain.emailconf.ConfirmationEmailJson;
import fr.ag2rlamondiale.trm.domain.evenement.CategorieJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementJson;
import fr.ag2rlamondiale.trm.domain.evenement.TypeEvenementRequeteJson;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireUtils;
import fr.ag2rlamondiale.trm.domain.prevalidpieceident.PrevalidationPieceIdentiteJson;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.domain.trace.TraceJson;
import fr.ag2rlamondiale.trm.testing.MrBeanTester;
import org.junit.Test;

public class MrBeanClientConsoleTest {

    @Test
    public void testClientConsoleBean() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addClasses("fr.ag2rlamondiale.trm.domain", ClientConsoleConfig.class);
        beanTester.addClasses("fr.ag2rlamondiale.trm.dto", ClientConsoleConfig.class);
        beanTester.addClassExclusion(Blocages.class);

        beanTester.test();
    }

    private MrBeanTester newMrBeanTester() {
        MrBeanTester beanTester = new MrBeanTester();
        beanTester.setClassPredicate(
                beanTester.getClassPredicate().and(clazz -> !clazz.getSimpleName().endsWith("MapperImpl")));
        beanTester.addClassExclusion(PartenaireUtils.class);
        beanTester.ignorePropsHashEquals(TypeEvenementJson.class, "categorie", "ordre", "dateDebut", "dateFin",
                "nbDeclenchementsMaxPeriode", "periodeDeclenchement", "delaiAvantReactivation", "modeAction", "titre",
                "contenu", "actionTraiter", "actionAnnuler", "lienRedirection", "perimetreEvenements", "libEvenement",
                "isDirty");
        beanTester.ignorePropsHashEquals(TypeEvenementRequeteJson.class, "date");
        beanTester.ignorePropsHashEquals(TraceJson.class, "codePartenaire", "codeSilo", "startInteraction",
                "endInteraction", "titulaire", "topImpersonnation", "nav", "zone1", "zone2", "zone3", "traceErreur");
        beanTester.ignorePropsHashEquals(CategorieJson.class, "codeApplication", "ordre", "description");
        beanTester.ignorePropsHashEquals(BlocageJson.class, "typeAcces", "commentaire", "lidBlocage", "lidDeblocage",
                "dateCreation", "codeSiloType", "fonctionnalites", "exceptionBlocages", "typePerimetre",
                "valeurPerimetre");
        beanTester.ignorePropsHashEquals(SupportInvestissementJson.class, "libelleSupport", "libelleFront", "modeGestion");
        beanTester.ignorePropsHashEquals(PrevalidationPieceIdentiteJson.class, "doc1", "doc2");

        beanTester.setPropsHashEquals(ConfirmationEmailJson.class, "id");
        beanTester.setPropsHashEquals(PrevalidationPieceIdentiteJson.class, "idGdi");

        return beanTester;
    }

}
