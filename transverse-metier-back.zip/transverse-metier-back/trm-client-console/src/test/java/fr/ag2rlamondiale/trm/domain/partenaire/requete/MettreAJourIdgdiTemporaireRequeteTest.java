
package fr.ag2rlamondiale.trm.domain.partenaire.requete;

import nl.jqno.equalsverifier.EqualsVerifier;
import nl.jqno.equalsverifier.Warning;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.meanbean.test.BeanTester;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class MettreAJourIdgdiTemporaireRequeteTest {
    @Test
    public void contratGeneralBean() {
        new BeanTester().testBean(MettreAJourIdgdiTemporaireRequete.class);
    }

    @Test
    public void testEqualsAndHashcode() {
        EqualsVerifier.forClass(MettreAJourIdgdiTemporaireRequete.class)
                .suppress(Warning.STRICT_INHERITANCE, Warning.NONFINAL_FIELDS).verify();
    }
}
