package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.client.rest.IPaiementCbRestClient;
import fr.ag2rlamondiale.trm.domain.paiement.FindRequestPaiementCbJson;
import fr.ag2rlamondiale.trm.domain.paiement.PaiementCbJson;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoRule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;

import java.net.URI;

import static fr.ag2rlamondiale.trm.testing.json.JsonTestUtils.jsonResource;
import static org.junit.Assert.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withStatus;

@Slf4j
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {SpringTestConfig.class})
public class PaiementRestClientImplTest {

    @Value("${ere.consoleadmin.ws.rest.root.uri}/paiementCb/find")
    private String findUrl;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private IPaiementCbRestClient paiementCbRestClient;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    private MockRestServiceServer mockServer;

    @Before
    public void setUp() throws Exception {
        mockServer = MockRestServiceServer.createServer(restTemplate);
    }

    @Test
    public void findPaiement() throws Exception {
        mockServer.expect(requestTo(new URI(findUrl)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource(
                                "/fixtures/paiementCbService-findPaiement-14.json")));


        FindRequestPaiementCbJson findRequest = FindRequestPaiementCbJson.builder()
                .id(14L)
                .withContext(true)
                .withSigElec(true)
                .withHistorique(true)
                .build();
        final PaiementCbJson paiement = paiementCbRestClient.findPaiement(findRequest);
        mockServer.verify();

        assertNotNull(paiement);
        assertNotNull(paiement.getValeurContexte());
        assertNotNull(paiement.getDemandesSigElec());
        assertNotNull(paiement.getHistorique());
    }


    @Test
    public void findPaiement_avec_prop_inconnue() throws Exception {
        mockServer.expect(requestTo(new URI(findUrl)))
                .andExpect(method(HttpMethod.POST))
                .andRespond(withStatus(HttpStatus.OK).contentType(MediaType.APPLICATION_JSON)
                        .body(jsonResource(
                                "/fixtures/paiementCbService-findPaiement-14-champs-inconnu.json")));


        FindRequestPaiementCbJson findRequest = FindRequestPaiementCbJson.builder()
                .id(14L)
                .withContext(true)
                .withSigElec(true)
                .withHistorique(true)
                .build();
        final PaiementCbJson paiement = paiementCbRestClient.findPaiement(findRequest);
        mockServer.verify();

        assertNotNull(paiement);
        assertNotNull(paiement.getValeurContexte());
        assertNotNull(paiement.getDemandesSigElec());
        assertNotNull(paiement.getHistorique());
    }


}
