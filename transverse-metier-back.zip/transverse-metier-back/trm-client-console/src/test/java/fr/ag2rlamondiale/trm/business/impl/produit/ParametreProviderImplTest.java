package fr.ag2rlamondiale.trm.business.impl.produit;

import fr.ag2rlamondiale.trm.TestCacheConfig;
import fr.ag2rlamondiale.trm.TestConsoleConfig;
import fr.ag2rlamondiale.trm.business.impl.parametre.IParametreProvider;
import fr.ag2rlamondiale.trm.business.impl.parametre.ParametreProviderImpl;
import fr.ag2rlamondiale.trm.client.rest.IParametreRestClient;
import fr.ag2rlamondiale.trm.domain.Annee;
import fr.ag2rlamondiale.trm.domain.parametre.ParametreDto;
import fr.ag2rlamondiale.trm.domain.parametre.RequestParametreDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static java.util.Arrays.asList;
import static org.junit.Assert.*;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {TestConsoleConfig.class, TestCacheConfig.class, ParametreProviderImplTest.ParametreProviderImplTestConfig.class})
public class ParametreProviderImplTest {

    @Autowired
    IParametreProvider parametreProvider;

    IParametreRestClient parametreRestClient;

    @Autowired
    CacheManager cacheManager;

    @Configuration
    static class ParametreProviderImplTestConfig {

        @Bean
        IParametreProvider parametreProvider() {
            return new ParametreProviderImpl();
        }

        @Bean
        IParametreRestClient parametreRestClient() {
            IParametreRestClient parametreRestClient = Mockito.mock(IParametreRestClient.class);
            when(parametreRestClient.getParametres(any())).thenReturn(asList(
                    param("TMI", "11", "10226", "26070"),
                    param("TMI", "30", "26071", "74545"),
                    param("TMI", "41", "74546", "160336"),
                    param("TMI", "45", "160337", null)
            ));

            return parametreRestClient;
        }

    }

    @Before
    public void setUp() {
        parametreRestClient = new ParametreProviderImplTestConfig().parametreRestClient();
        ReflectionTestUtils.setField(parametreProvider, "parametreRestClient", parametreRestClient);
    }

    @Test
    public void getParametres() {
        final List<ParametreDto> parametresTMI = parametreProvider.getParametres("TMI", Annee.Courante);
        assertEquals(4, parametresTMI.size());
    }

    @Test
    public void getParametre() {
        final Optional<ParametreDto> parametreTMI = parametreProvider.getParametre("TMI", "11", Annee.Courante);
        assertTrue(parametreTMI.isPresent());
        assertEquals("10226", parametreTMI.get().getValeur1());
    }

    @Test
    public void reloadCache() {
        parametreProvider.reloadCache();

        // 1er appel
        final List<ParametreDto> parametresTMI = parametreProvider.getParametres("TMI", Annee.Courante);
        assertEquals(4, parametresTMI.size());

        // 2e appel
        parametreProvider.getParametres("TMI", Annee.Courante);

        verify(parametreRestClient).getParametres(any());
    }


    @Test
    public void reloadCache_error_param() {
        when(parametreRestClient.getParametres(any())).thenThrow(new RuntimeException("Boom"));
        ReflectionTestUtils.setField(parametreProvider, "parametreRestClient", parametreRestClient);

        parametreProvider.reloadCache();

        try {
            parametreProvider.getParametres("TMI", Annee.Courante);
            fail();
        } catch (Exception ignored) {
        }
    }

    @Test
    public void firstLoadCache() {
        parametreProvider.firstLoadCache();

        final List<ParametreDto> parametresTMI = parametreProvider.getParametres("TMI", Annee.Courante);
        assertEquals(4, parametresTMI.size());

        verify(parametreRestClient).getParametres(any());
    }

    @Test
    public void clearCache() {
        parametreProvider.clearCache();
        final List<ParametreDto> parametresTMI = parametreProvider.getParametres("TMI", Annee.Courante);
        assertEquals(4, parametresTMI.size());

        verify(parametreRestClient).getParametres(any());
    }


    private static ParametreDto param(String type, String code, String valeur1, String valeur2) {
        ParametreDto param = new ParametreDto();
        param.setTypeParam(type);
        param.setCodeParam(code);
        param.setValeur1(valeur1);
        param.setValeur2(valeur2);
        return param;
    }
}
