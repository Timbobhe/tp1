package fr.ag2rlamondiale.trm.client.rest.impl;

import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.MettreAJourIdgdiTemporaireRequete;
import fr.ag2rlamondiale.trm.domain.partenaire.requete.RechercherSousPartenaireRequete;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;

import static fr.ag2rlamondiale.trm.utils.JsonMarshaller.toJSON;
import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class PartenaireRestClientImplTest {

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private PartenaireRestClientImpl partenaireRestClient;

    @Before
    public void init() {
        ReflectionTestUtils.setField(partenaireRestClient, "partenaireFindByIdUrl", "http://foo");
        ReflectionTestUtils.setField(partenaireRestClient, "partenaireFindSousPartenaireUrl", "http://foo");
        ReflectionTestUtils.setField(partenaireRestClient, "partenaireupdateIdGdiTemporaireUrl", "http://foo");
    }
 
    @Test
    public void findById() {
        when(restTemplate.postForObject("http://foo", "id", PartenaireJson.class)).thenReturn(new PartenaireJson());
        PartenaireJson json = partenaireRestClient.findById("id");
        assertNotNull(json);
    }
    
    @Test
    public void findSousPartenaire() {
        RechercherSousPartenaireRequete request = new RechercherSousPartenaireRequete();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity<String> http =  new HttpEntity<>(toJSON(request), headers);
        when(restTemplate.postForObject("http://foo", http, PartenaireJson.class)).thenReturn(new PartenaireJson());
        PartenaireJson json = partenaireRestClient.findSousPartenaire(request);
        assertNotNull(json);
    }
    
    @Test
    public void updateIdgdiTemporaire() {
        MettreAJourIdgdiTemporaireRequete request = new MettreAJourIdgdiTemporaireRequete();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.TEXT_PLAIN));
        HttpEntity<String> http =  new HttpEntity<>(toJSON(request), headers);
        when(restTemplate.postForObject("http://foo", http, String.class)).thenReturn("100");
        Integer i = partenaireRestClient.updateIdgdiTemporaire(request);
        assertNotNull(i);   
    }
    
    @Test
    public void updateIdgdiTemporaireNull() {
        MettreAJourIdgdiTemporaireRequete request = new MettreAJourIdgdiTemporaireRequete();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.TEXT_PLAIN));
        HttpEntity<String> http =  new HttpEntity<>(toJSON(request), headers);
        when(restTemplate.postForObject("http://foo", http, String.class)).thenReturn(null);
        Integer i = partenaireRestClient.updateIdgdiTemporaire(request);
        assertNull(i);   
    }
}
