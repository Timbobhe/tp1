package fr.ag2rlamondiale.trm.domain.mapping;

import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PartenaireMapperTest {

    @InjectMocks
    private PartenaireMapperImpl partenaireMapper;

    @Test
    public void test_map() throws Exception {
        PartenaireJson json = new PartenaireJson();

        json.setCodePartenaire("codePartenaire");
        json.setCodePartenairePrincipal("codePartenairePrincipal");
        json.setLabel("label");
        json.setUrlHeader("urlHeader");
        json.setUrlFooter("urlFooter");
        json.setUrlError("urlError");
        json.setUrlMenu("urlMenu");
        json.setNomCss("nomCss");
        json.setIdContrats(Arrays.asList("idContrats1", "idContrats2"));

        final Partenaire partenaire = partenaireMapper.map(json);

        assertEquals("codePartenaire", partenaire.getCodePartenaire());
        assertEquals("codePartenairePrincipal", partenaire.getCodePartenairePrincipal());
        assertEquals("label", partenaire.getLabel());
        assertEquals("urlHeader", partenaire.getUrlHeader());
        assertEquals("urlFooter", partenaire.getUrlFooter());
        assertEquals("urlError", partenaire.getUrlError());
        assertEquals("urlMenu", partenaire.getUrlMenu());
        assertEquals("nomCss", partenaire.getNomCss());
        assertEquals(Arrays.asList("idContrats1", "idContrats2"), partenaire.getIdContrats());
    }
}
