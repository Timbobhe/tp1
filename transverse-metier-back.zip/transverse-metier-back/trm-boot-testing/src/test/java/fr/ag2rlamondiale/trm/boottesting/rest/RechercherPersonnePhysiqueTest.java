package fr.ag2rlamondiale.trm.boottesting.rest;

import com.alm.esb.service.personnephysiquerecherche.rechercherpersonnesphysiquesreferentiel_31.CriteresRecherchePersonnePhysiqueIn;
import com.alm.esb.service.personnephysiquerecherche.rechercherpersonnesphysiquesreferentiel_31.Request;
import com.alm.esb.service.personnephysiquerecherche.rechercherpersonnesphysiquesreferentiel_31.Responses;
import fr.ag2rlamondiale.trm.boottesting.TrmBootTesting;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.IRechercherPersonnePhysiqueClient;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.impl.RechercherPersonnePhysiqueClientImpl;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.mapping.RechercherPersonnePhysiqueInMapper;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.mapping.RechercherPersonnePhysiqueInMapperImpl;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.mapping.RechercherPersonnePhysiqueOutMapper;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.mapping.RechercherPersonnePhysiqueOutMapperImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;


@Slf4j
@ContextConfiguration(classes = {RechercherPersonnePhysiqueTest.class})
@RunWith(SpringRunner.class)
@EnableWebSecurity
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = TrmBootTesting.class)
@TestPropertySource(locations = "classpath:application-test.properties")
public class RechercherPersonnePhysiqueTest {
    @Autowired
    IRechercherPersonnePhysiqueClient rechercherPersonnePhysiqueClient;


    @TestConfiguration
    static class RechercherPersonnePhysiqueTestConfig {
        @Bean
        IRechercherPersonnePhysiqueClient rechercherPersonnePhysiqueClient() {
            return new RechercherPersonnePhysiqueClientImpl();
        }

        @Bean
        RechercherPersonnePhysiqueInMapper rechercherPersonnePhysiqueInMapper() {
            return new RechercherPersonnePhysiqueInMapperImpl();
        }

        @Bean
        RechercherPersonnePhysiqueOutMapper rechercherPersonnePhysiqueOutMapper() {
            return new RechercherPersonnePhysiqueOutMapperImpl();
        }
    }

    @Test
    public void test_appel() throws Exception {
        CriteresRecherchePersonnePhysiqueIn criteres = new CriteresRecherchePersonnePhysiqueIn();
        criteres.setNom("FRAN IS");
        criteres.setPrenom("JEAN JACQUES");

        Request request = new Request();
        request.setCriteresRecherchePersonnePhysique(criteres);

        final Responses response = rechercherPersonnePhysiqueClient.restRechercherPersonnePhysique(request);
        log.info("Response = {}", response);
    }
}
