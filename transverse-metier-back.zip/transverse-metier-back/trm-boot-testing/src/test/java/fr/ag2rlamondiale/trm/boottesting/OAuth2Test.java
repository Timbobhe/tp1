package fr.ag2rlamondiale.trm.boottesting;

import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.oauth2.client.OAuth2AuthorizeRequest;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClient;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Nonnull;

import static org.junit.Assert.*;

@Slf4j
@RunWith(SpringRunner.class)
@EnableWebSecurity
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = TrmBootTesting.class)
@TestPropertySource(locations = "classpath:application-test.properties")
public class OAuth2Test {

//    @Autowired
//    private OAuth2ClientProperties properties;

//    @MockBean
//    private TrmBootTesting app;

    @Autowired
    private OAuth2AuthorizedClientManager authorizedClientManager;


    @Test
    public void test_check_configuration() throws Exception {
//        assertNotNull(properties);
        assertNotNull(authorizedClientManager);
    }

    @Test
    public void test_access_token_from_cas_dev() throws Exception {
        OAuth2AuthorizeRequest authorizeRequest = getAuthorizeRequest("cas-dev");

        // Récupération d'un access_token
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        assertNotNull(authorizedClient);
        OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
        final String tokenValue1 = accessToken.getTokenValue();
        log.info("1ere demande access_token : [{}]", tokenValue1);

        // Vérification qu'on récupère le même access_token la 2ème fois car il n'est pas encore expiré
        authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        final String tokenValue2 = authorizedClient.getAccessToken().getTokenValue();
        log.info("2eme demande access_token : [{}]", tokenValue2);
        assertEquals(tokenValue2, tokenValue1);
    }

    @Test
    public void test_access_token_from_cas_pp() throws Exception {
        OAuth2AuthorizeRequest authorizeRequest = getAuthorizeRequest("cas-pp");

        // Récupération d'un access_token
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        assertNotNull(authorizedClient);
        OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
        final String tokenValue1 = accessToken.getTokenValue();
        log.info("1ere demande access_token : [{}]", tokenValue1);

        // Vérification qu'on récupère le même access_token la 2ème fois car il n'est pas encore expiré
        authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        final String tokenValue2 = authorizedClient.getAccessToken().getTokenValue();
        log.info("2eme demande access_token : [{}]", tokenValue2);
        assertEquals(tokenValue2, tokenValue1);
    }

    @Test
    public void test_access_token_from_cas_interne() throws Exception {
        OAuth2AuthorizeRequest authorizeRequest = getAuthorizeRequest("cas-interne-hp");

        // Récupération d'un access_token
        OAuth2AuthorizedClient authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        assertNotNull(authorizedClient);
        OAuth2AccessToken accessToken = authorizedClient.getAccessToken();
        final String tokenValue1 = accessToken.getTokenValue();
        log.info("1ere demande access_token : [{}]", tokenValue1);

        // Vérification qu'on récupère le même access_token la 2ème fois car il n'est pas encore expiré
        authorizedClient = this.authorizedClientManager.authorize(authorizeRequest);
        final String tokenValue2 = authorizedClient.getAccessToken().getTokenValue();
        log.info("2eme demande access_token : [{}]", tokenValue2);
        assertEquals(tokenValue2, tokenValue1);
    }

    @Nonnull
    private OAuth2AuthorizeRequest getAuthorizeRequest(String clientRegistrationId) {
        return OAuth2AuthorizeRequest.withClientRegistrationId(clientRegistrationId)
                .principal(new AnonymousAuthenticationToken("Anonymous", "Anonymous",
                        AuthorityUtils.createAuthorityList("ROLE_ANONYMOUS")))
                .build();
    }
}
