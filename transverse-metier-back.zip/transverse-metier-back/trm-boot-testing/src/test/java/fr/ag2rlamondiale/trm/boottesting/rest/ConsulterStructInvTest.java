package fr.ag2rlamondiale.trm.boottesting.rest;

import com.alm.esb.service.infofin_1.consulterstructinv_3.IdDansSiloIn;
import com.alm.esb.service.infofin_1.consulterstructinv_3.IdentificationDansSiloIn;
import com.alm.esb.service.infofin_1.consulterstructinv_3.Request;
import com.alm.esb.service.infofin_1.consulterstructinv_3.Response;
import fr.ag2rlamondiale.trm.boottesting.TrmBootTesting;
import fr.ag2rlamondiale.trm.client.rest.IConsulterStructInvClient;
import fr.ag2rlamondiale.trm.client.rest.impl.ConsulterStructInvClientImpl;
import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@Slf4j
@ContextConfiguration(classes = {ConsulterStructInvTest.class})
@RunWith(SpringRunner.class)
@EnableWebSecurity
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK, classes = TrmBootTesting.class)
@TestPropertySource(locations = "classpath:application-test.properties")
public class ConsulterStructInvTest {

    @Autowired
    IConsulterStructInvClient consulterStructInvClient;


    @TestConfiguration
    static class ConsulterStructInvTestConfig {
        @Bean
        IConsulterStructInvClient consulterStructInvClient() {
            return new ConsulterStructInvClientImpl();
        }
    }


    @Ignore("java.net.UnknownHostException: int-a0487-fin-informationsfinancieres.appli")
    @Test
    public void test_appel() throws Exception {
        Request request = new Request();
        IdentificationDansSiloIn identificationDansSilo = new IdentificationDansSiloIn();
        IdDansSiloIn idDansSilo = new IdDansSiloIn();
        idDansSilo.setValeurId("RG151715275");
        idDansSilo.setTypeId("CONTRAT");
        identificationDansSilo.setIdDansSilo(idDansSilo);
        identificationDansSilo.setCodeApplication("A0252");
        request.setIdentificationDansSilo(identificationDansSilo);
        request.setIndSODA(true);
        request.setIndDetail(true);

        final Response response = consulterStructInvClient.restConsulterStructInv(request);
        log.info("Response = {}", response);
    }
}
