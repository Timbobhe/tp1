package fr.ag2rlamondiale.trm.boottesting;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import org.springframework.stereotype.Component;

@Component
public class TrmSupplierLibService implements ISupplierLibService {
    @Override
    public String getCodeCassiniAppli() {
        return "A1791";
    }

    @Override
    public String getLibelleAppli() {
        return "Console";
    }

    @Override
    public String getUrlFront() {
        return "http://localhost:4200";
    }
}
