package fr.ag2rlamondiale.trm.boottesting.config;

import fr.ag2rlamondiale.trm.rest.auth.AccessTokenOAuth2CasAppli;
import fr.ag2rlamondiale.trm.rest.auth.AccessTokenProviders;
import fr.ag2rlamondiale.trm.rest.auth.PfsTokenBuilder;
import fr.ag2rlamondiale.trm.rest.swagger.PfsRestServiceSwaggerInterceptor;
import fr.ag2rlamondiale.trm.rest.swagger.PfsRestSwaggerConfig;
import fr.ag2rlamondiale.trm.utils.DefaultEndpointResolver;
import fr.ag2rlamondiale.trm.utils.PropertyResolver;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(PfsRestSwaggerConfig.class)
public class TrmPfsRestConfig {

    @Bean
    PfsRestServiceSwaggerInterceptor pfsRestServiceSwaggerInterceptor() {
        return new PfsRestServiceSwaggerInterceptor();
    }

    @Bean
    PfsTokenBuilder pfsTokenBuilder() {
        return new PfsTokenBuilder();
    }

    @Bean
    PropertyResolver propertyResolver() {
        return new PropertyResolver();
    }

    @Bean
    AccessTokenProviders accessTokenProviders() {
        return new AccessTokenProviders();
    }

    @Bean
    AccessTokenOAuth2CasAppli accessTokenOAuth2CasAppli() {
        return new AccessTokenOAuth2CasAppli();
    }

    @Bean
    DefaultEndpointResolver defaultEndpointResolver() {
        return new DefaultEndpointResolver();
    }

}
