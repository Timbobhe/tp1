package fr.ag2rlamondiale.trm.boottesting;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.StandardEnvironment;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import java.util.Properties;

@EnableAspectJAutoProxy
@EnableWebSecurity
@SpringBootApplication
public class TrmBootTesting {
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(TrmBootTesting.class);
        ConfigurableEnvironment env = new StandardEnvironment();
        env.setActiveProfiles("whatever");

        Properties properties = new Properties();
        properties.put("pfs.reverseProxy", "pfs.reverseProxy");
        env.getPropertySources()
                .addFirst(new PropertiesPropertySource("initProps", properties));

        application.setEnvironment(env);
        application.run(args);
    }
}
