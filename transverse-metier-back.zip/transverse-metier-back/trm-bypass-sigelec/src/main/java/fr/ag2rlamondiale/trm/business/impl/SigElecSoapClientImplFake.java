package fr.ag2rlamondiale.trm.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import com.alm.esb.service.sigelec_4.consulterdemsigelec_1.ConsulterDemSigElecResponseType;
import com.alm.esb.service.sigelec_4.consulterdemsigelec_1.ConsulterDemSigElecType;
import com.alm.esb.service.sigelec_4.controlerdocidtsigelec_1.ControlerDocIdtSigElecResponseType;
import com.alm.esb.service.sigelec_4.controlerdocidtsigelec_1.ControlerDocIdtSigElecType;
import com.alm.esb.service.sigelec_4.recherchercmptsigelec_1.RechercherCmptSigElecResponseType;
import com.alm.esb.service.sigelec_4.recherchercmptsigelec_1.RechercherCmptSigElecType;
import fr.ag2rlamondiale.trm.business.IBlocageBypassSigelecFacade;
import fr.ag2rlamondiale.trm.client.rest.impl.JsonHttpEntityUtils;
import fr.ag2rlamondiale.trm.client.soap.impl.SigElecSoapClientImpl;
import fr.ag2rlamondiale.trm.domain.sigelec.*;
import fr.ag2rlamondiale.trm.dto.BypassSigelecConstants;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.soap.SoapRequest;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Profile(BypassSigelecConstants.BYPASS_SIGELEC)
@Primary
@Service
public class SigElecSoapClientImplFake extends SigElecSoapClientImpl {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private IBlocageBypassSigelecFacade blocageBypassSigelecFacade;

    @Value("${ere.consoleadmin.ws.rest.root.uri}/sigElecService/envoyerDocPourSigElecFake")
    private String urlEnvoyerDocPourSigElecFake;

    @Override
    @SoapRequest(forceLogBody = true)
    @LogError(category = "SOAP")
    public ControlerDocIdtSigElecResponseDto controlerDocIdtSigElec(ControlerDocIdtSigElecDto controlerDocIdtSigElecDto) throws TechnicalException {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.controlerDocIdtSigElec(controlerDocIdtSigElecDto);
        }
        ControlerDocIdtSigElecType in = controlerDocIdtSigElecMapper.controlerDocIdtSigEleDtoToType(controlerDocIdtSigElecDto);
        ControlerDocIdtSigElecResponseType mock = XmlMarshaller.convertSoapBodyToObject("/xml/ControlerDocIdtSigElec.xml", ControlerDocIdtSigElecResponseType.class);
        return docIdtSigElecResponseMapper.consulterDocIdtSigElecResponseTypeToDto(mock);
    }

    @Override
    @SoapRequest
    @LogError(category = "SOAP")
    public RechercherCmptSigElecResponseDto rechercherCmptSigElec(RechercherCmptSigElecDto rechercherCmptSigElecDto) throws TechnicalException {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.rechercherCmptSigElec(rechercherCmptSigElecDto);
        }
        RechercherCmptSigElecType in = rechercherCmptSigElecMapper.rechercherCmptSigElecDtoToType(rechercherCmptSigElecDto);
        RechercherCmptSigElecResponseType mock = XmlMarshaller.convertSoapBodyToObject("/xml/RechercherCmptSigElecResponse.xml", RechercherCmptSigElecResponseType.class);
        return rechercherCmptSigElecResponseMapper.rechercherCmptSigElecResponseTypeToDto(mock);
    }

    @LogExecutionTime
    @Override
    @SoapRequest
    @LogError(category = "SOAP")
    public EnvoyerDocPourSigElecResponseDto envoyerDocPourSigElec(EnvoyerDocPourSigElecDto envoyerDocPourSigElecDto) throws TechnicalException {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.envoyerDocPourSigElec(envoyerDocPourSigElecDto);
        }
        try {
            return restTemplate.postForObject(urlEnvoyerDocPourSigElecFake, JsonHttpEntityUtils.jsonHttpEntity(envoyerDocPourSigElecDto), EnvoyerDocPourSigElecResponseDto.class);
        } catch (HttpClientErrorException.NotFound e) {
            throw new RestClientException("envoyerDocPourSigElec not found" + envoyerDocPourSigElecDto);
        }
    }

    @Override
    @SoapRequest
    @LogError(category = "SOAP")
    public ConsulterDemSigElecResponseDto consulterDemSigElec(ConsulterDemSigElecDto consulterDemSigElecDto)
            throws TechnicalException {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.consulterDemSigElec(consulterDemSigElecDto);
        }
        final ConsulterDemSigElecType in = consulterDemSigElecMapper.map(consulterDemSigElecDto);
        ConsulterDemSigElecResponseType mock = XmlMarshaller.convertSoapBodyToObject("/xml/ConsulterDemSigElec.xml", ConsulterDemSigElecResponseType.class);
        return consulterDemSigElecMapper.consulterDemSigElecResponseTypeToDto(mock);
    }
}
