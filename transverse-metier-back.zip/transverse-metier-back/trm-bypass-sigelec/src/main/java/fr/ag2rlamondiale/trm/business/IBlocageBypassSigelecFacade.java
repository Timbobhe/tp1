package fr.ag2rlamondiale.trm.business;

public interface IBlocageBypassSigelecFacade {
    boolean testNoMock();
}
