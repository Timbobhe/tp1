package fr.ag2rlamondiale.trm.dto;

public final class BypassSigelecConstants {
    public static final String BYPASS_SIGELEC = "bypassSigelec";

    public static final String CACHE_INFOS_BLOCAGES_CLIENT_BYPASS_SIGELEC = "CACHE_INFOS_BLOCAGES_CLIENT_BYPASS_SIGELEC";

    private BypassSigelecConstants() {
    }
}
