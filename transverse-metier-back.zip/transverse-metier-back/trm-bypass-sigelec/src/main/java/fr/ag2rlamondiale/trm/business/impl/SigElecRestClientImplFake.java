package fr.ag2rlamondiale.trm.business.impl;

import fr.ag2rlamondiale.trm.dto.BypassSigelecConstants;
import fr.ag2rlamondiale.trm.business.IBlocageBypassSigelecFacade;
import fr.ag2rlamondiale.trm.client.rest.impl.SigElecRestClientImpl;
import fr.ag2rlamondiale.trm.domain.sigelec.json.SigElecUpdate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile(BypassSigelecConstants.BYPASS_SIGELEC)
@Primary
@Service
public class SigElecRestClientImplFake extends SigElecRestClientImpl {
    @Autowired
    private IBlocageBypassSigelecFacade blocageBypassSigelecFacade;

    @Override
    public boolean updateDmdSigElec(SigElecUpdate sigElecUpdate) {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.updateDmdSigElec(sigElecUpdate);
        }
        return true;
    }
}
