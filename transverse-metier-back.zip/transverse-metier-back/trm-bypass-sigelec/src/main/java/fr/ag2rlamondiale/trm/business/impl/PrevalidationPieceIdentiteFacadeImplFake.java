package fr.ag2rlamondiale.trm.business.impl;

import fr.ag2rlamondiale.trm.dto.BypassSigelecConstants;
import fr.ag2rlamondiale.trm.business.IBlocageBypassSigelecFacade;
import fr.ag2rlamondiale.trm.domain.prevalidpieceident.PrevalidationPieceIdentiteJson;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;


@Profile(BypassSigelecConstants.BYPASS_SIGELEC)
@Slf4j
@Service
@Primary
public class PrevalidationPieceIdentiteFacadeImplFake extends PrevalidationPieceIdentiteFacadeImpl {
    @Autowired
    private IBlocageBypassSigelecFacade blocageBypassSigelecFacade;

    @Override
    public PrevalidationPieceIdentiteJson getPrevalidationByIdGdi(String idGdi) {
        if (blocageBypassSigelecFacade.testNoMock()) {
            return super.getPrevalidationByIdGdi(idGdi);
        }
        return new PrevalidationPieceIdentiteJson();
    }
}
