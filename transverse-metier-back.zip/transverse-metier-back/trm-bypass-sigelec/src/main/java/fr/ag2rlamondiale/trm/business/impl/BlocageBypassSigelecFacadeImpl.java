package fr.ag2rlamondiale.trm.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.business.IBlocageBypassSigelecFacade;
import fr.ag2rlamondiale.trm.business.IPartenaireBypassSigelecFacade;
import fr.ag2rlamondiale.trm.client.rest.IBlocageRestClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.*;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.dto.BypassSigelecConstants;
import fr.ag2rlamondiale.trm.dto.PartenaireBypassSigelecException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Profile(BypassSigelecConstants.BYPASS_SIGELEC)
@Service
public class BlocageBypassSigelecFacadeImpl implements IBlocageBypassSigelecFacade, SelfReferencingBean {
    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IBlocageRestClient blocageRestClient;

    private BlocageBypassSigelecFacadeImpl springProxy;

    @Autowired
    private IPartenaireBypassSigelecFacade partenaireFacade;

    @Override
    public boolean testNoMock() {
        try {
            return getInfosBlocagesClient().getFonctionnalitesBloqueesALaPersonne().stream().noneMatch(b -> FonctionnaliteType.BYPASS_SIGELEC.getLabel().equals(b));
        } catch (TechnicalException e) {
            return false;
        }
    }

    private InfosBlocagesClient getInfosBlocagesClient() throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        String numPersonneEre = userContext.getNumeroPersonneEre();
        String numPersonneMdPro = userContext.getNumeroPersonneMdpro();
        return springProxy.getInfosBlocagesClient(numPersonneEre, numPersonneMdPro);
    }

    //@Cacheable(cacheNames = BypassSigelecConstants.CACHE_INFOS_BLOCAGES_CLIENT_BYPASS_SIGELEC, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public InfosBlocagesClient getInfosBlocagesClient(String numPersonneEre, String numPersonneMdPro) throws TechnicalException {
        final UserContext userContext = userContextHolder.get();
        InfosBlocagesClient infosBlocagesClient = new InfosBlocagesClient();
        Set<BlocageJson> blocagesList = new HashSet<>();

        // Recuperation des contrats et des blocages ERE et MDPRO

        recupererBlocages(numPersonneEre, CodeSiloType.ERE, infosBlocagesClient, blocagesList);
        recupererBlocages(numPersonneMdPro, CodeSiloType.MDP, infosBlocagesClient, blocagesList);

        Blocages blocagesEffectifs = new Blocages(blocagesList);

        // Traitement des blocages a la personne
        Fonctionnalites fonctionnalitesBloqueesAlaPersonneERE = new Fonctionnalites();
        Fonctionnalites fonctionnalitesBloqueesAlaPersonneMdpro = new Fonctionnalites();

        traiterBlocagesALaPersonne(numPersonneEre, CodeSiloType.ERE, infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneERE, blocagesEffectifs);
        traiterBlocagesALaPersonne(numPersonneMdPro, CodeSiloType.MDP, infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneMdpro, blocagesEffectifs);
        infosBlocagesClient.setPersonneTotalementBloquee(infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo()
                .values().stream().allMatch(bloquee -> bloquee));
        calculerBlocagesALaPersonneReels(infosBlocagesClient, fonctionnalitesBloqueesAlaPersonneERE, fonctionnalitesBloqueesAlaPersonneMdpro);

        recupereBlocagePartenaire(infosBlocagesClient, userContext);
        return infosBlocagesClient;
    }

    /**
     * Calculer Fonctionnalites Bloquees Tous Contrats
     *
     * @param infosBlocagesClient
     */
    private void calculerBlocagesSurContratsReels(InfosBlocagesClient infosBlocagesClient,
                                                  Map<String, Fonctionnalites> fonctionnalitesBloqueesContrats) {

        final Set<String> toutesFonctionnalites = Fonctionnalites.cumulFonctionnalites(fonctionnalitesBloqueesContrats.values());
        for (String fonctionnalite : toutesFonctionnalites) {
            if (fonctionnalitesBloqueesContrats.values().stream().allMatch(fonctionnalies -> fonctionnalies.contains(fonctionnalite))) {
                infosBlocagesClient.getFonctionnalitesBloqueesTousContrats().add(fonctionnalite);
            }
        }
    }

    private void calculerBlocagesALaPersonneReels(InfosBlocagesClient infosBlocagesClient,
                                                  Fonctionnalites fonctionnalitesBloqueesAlaPersonneERE,
                                                  Fonctionnalites fonctionnalitesBloqueesAlaPersonneMdpro) {

        Fonctionnalites fonctionnalitesBloqueesAlaPersonne = new Fonctionnalites();
        fonctionnalitesBloqueesAlaPersonneERE.forEach(fonc -> {
            if (fonctionnalitesBloqueesAlaPersonneERE.contains(fonc)) {
                fonctionnalitesBloqueesAlaPersonne.add(fonc);
            }
        });

        fonctionnalitesBloqueesAlaPersonneMdpro.forEach(fonc -> {
            if (fonctionnalitesBloqueesAlaPersonneMdpro.contains(fonc)) {
                fonctionnalitesBloqueesAlaPersonne.add(fonc);
            }
        });

        infosBlocagesClient.setFonctionnalitesBloqueesALaPersonne(fonctionnalitesBloqueesAlaPersonne.getDetails());
    }

    private void traiterBlocagesALaPersonne(String numPersonne, CodeSiloType silo,
                                            InfosBlocagesClient infosBlocagesClient, Fonctionnalites fonctionnalitesBloqueesAlaPersonne,
                                            Blocages blocages) {
        boolean personneTotalementBloquee = blocages.isPersonneTotalementBloquee(numPersonne, Collections.emptyList(), silo);
        infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo().put(silo, personneTotalementBloquee);
        fonctionnalitesBloqueesAlaPersonne.setToute(personneTotalementBloquee);
        if (!personneTotalementBloquee) {
            fonctionnalitesBloqueesAlaPersonne.addAll(blocages.calculerFonctionnalitesBloqueesAlaPersonne(numPersonne, Collections.emptyList(), silo));
        }
    }

    private void recupererBlocages(String numPersonne, CodeSiloType silo,
                                   InfosBlocagesClient infosBlocagesClient,
                                   Set<BlocageJson> blocagesList) throws TechnicalException {
        if (StringUtils.isNotEmpty(numPersonne)) {
            // Recuperation des blocages du Silo
            List<BlocageJson> blocagesDuSilo = blocageRestClient.rechercherBlocages(numPersonne,
                    CodeApplicationType.AQEA, Collections.emptyList());
            blocagesList.addAll(blocagesDuSilo);
        } else {
            infosBlocagesClient.getIsPersonneTotalementBloqueeParSilo().put(silo, true);
        }
    }

    private void recupereBlocagePartenaire(InfosBlocagesClient infosBlocagesClient, UserContext userContext)
            throws TechnicalException {
        final String primaryPartner = userContext.getPartenaire() != null
                ? userContext.getPartenaire().getCodePartenaire()
                : null;
        if (primaryPartner == null) {
            return; // Connexion directe, sans partenaire
        }

        final String secondaryPartner = userContext.getSousPartenaire();

        final String numeroPersonneEre = userContext.getNumeroPersonneEre();
        PartenaireJson partenaire = partenaireFacade.findPartenaire(primaryPartner, secondaryPartner, numeroPersonneEre);

        if (partenaire == null) {
            throw new PartenaireBypassSigelecException(PartenaireBypassSigelecException.ErrorCode.UNKNOWN_PARTENAIRE);
        }

        if (partenaire.getFonctionnnalitesBloquees() != null && !partenaire.getFonctionnnalitesBloquees().isEmpty()) {
            infosBlocagesClient.setFonctionnalitesBloqueesPartenaire(
                    partenaire.getFonctionnnalitesBloquees().stream().map(FonctionnaliteJson::getCodeFct)
                            .collect(Collectors.toSet()));
        }
    }

    @Override
    public void setProxy(Object proxy) {
        this.springProxy = (BlocageBypassSigelecFacadeImpl) proxy;
    }
}
