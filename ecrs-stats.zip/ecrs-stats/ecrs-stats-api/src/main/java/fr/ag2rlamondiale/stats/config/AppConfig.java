package fr.ag2rlamondiale.stats.config;

import fr.ag2rlamondiale.stats.main.business.IStatsSigelecFacade;
import fr.ag2rlamondiale.stats.main.business.impl.StatsSigelecFacadeImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public IStatsSigelecFacade statsSigelecFacade() {
        return new StatsSigelecFacadeImpl();
    }

    /*@Bean
    public StatistiqueSigelecRepository statistiqueSigelecRepository() {
        return new StatistiqueSigelecRepository();
    }*/
}
