package fr.ag2rlamondiale.stats.dao.repository;

import fr.ag2rlamondiale.stats.dao.domain.Trace;
import fr.ag2rlamondiale.stats.dto.IPeriodesOutput;
import fr.ag2rlamondiale.stats.dto.IStatsJour;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ITraceRepository extends CrudRepository<Trace, Long> {

    @Query(value = "select count(1) from TBCL0TRC where TYEVETRC= :codeAction " +
            " and LBMETCTR LIKE %:numContrat%" +
            " and TSDEBTRC between :startDate and :endDate ", nativeQuery = true)
    Long countConnexions(
            @Param("codeAction") String codeAction,
            @Param("startDate") Date startDate,
            @Param("endDate") Date endDate,
            @Param("numContrat") String numContrat
    );

    /**
     * This query get the list of connexions number in a period ( ex: 1 month ) grouped by slot of 60 min
     * excluding the base account ( le compte de la sonde : IDINTCPT = sdrtsp)
     * excluding impersonations ( les impersonations IDLIDIMP = NULL )
     *
     * @param codeApplication the code of appli ( example: A1573 )
     * @param codeAction      type of event to extract ( example: CQ_CONNEXION )
     * @param startDate       date from ( exemple '01/10/2021 )
     * @param endDate         date to ( exemple '01/11/2021 )
     * @param numContrat      contrat number ( exemple : RG152289321 )
     * @return the list of PicConnexion for each 1 hour by days
     */
    @Query(value = "SELECT " +
            " (TO_CHAR(TSDEBTRC, 'DD-MM-YYYY fmHH24') || ':00')  as day," +
            " (TO_CHAR(TSDEBTRC, 'HH24') || ':00') as startTime," +
            " COUNT (1) as numberOfConnexions " +
            " from TBCL0TRC " +
            " WHERE " +
            " COAPP = :codeApp " +
            " and IDLIDIMP is NULL " +
            " and IDINTCPT <> 'sdrtsp' " +
            " and TYEVETRC = :codeAction " +
            " and LBMETCTR LIKE %:numContrat% " +
            " and TSDEBTRC between TO_DATE(:startDate,'DD-MM-YYYY HH24:MI:SS') " +
            " and TO_DATE(:endDate,'DD-MM-YYYY HH24:MI:SS') " +
            " GROUP BY TO_CHAR(TSDEBTRC, 'DD-MM-YYYY fmHH24') || ':00', (TO_CHAR(TSDEBTRC, 'HH24') || ':00')"
            , nativeQuery = true)
    List<IPeriodesOutput> getTracesGroupedBy1hour(
            @Param("codeApp") String codeApplication,
            @Param("codeAction") String codeAction,
            @Param("startDate") String startDate,
            @Param("endDate") String endDate,
            @Param("numContrat") String numContrat);

    @Query(value = "select jour, max(nb) as picMinute, round(sum(nb)/1440,2) as moyCxnMinute " +
            " from (" +
            " select " +
            " (TO_CHAR(TSDEBTRC, 'DD-MM-YYYY')) as jour, " +
            " count(1) as nb " +
            " from TBCL0TRC where" +
            " COAPP = :codeApp" +
            " and IDLIDIMP is NULL" +
            " and IDINTCPT <> 'sdrtsp'" +
            " and TYEVETRC = :codeAction" +
            " and LBMETCTR LIKE %:numContrat%" +
            " and TSDEBTRC between TO_DATE(:startDate,'DD-MM-YYYY HH24:MI:SS')" +
            " and TO_DATE(:endDate,'DD-MM-YYYY HH24:MI:SS') " +
            " GROUP BY TO_CHAR(TSDEBTRC, 'DD-MM-YYYY'), trunc(TSDEBTRC, 'MI')" +
            ")" +
            " group by jour" +
            " order by TO_DATE(jour,'DD-MM-YYYY')"
            , nativeQuery = true)
    List<IStatsJour> getMaxTraceForDay(
            @Param("codeApp") String codeApplication,
            @Param("codeAction") String codeAction,
            @Param("startDate") String startDate,
            @Param("endDate") String endDate,
            @Param("numContrat") String numContrat);


}
