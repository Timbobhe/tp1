package fr.ag2rlamondiale.stats.dao.repository;

import fr.ag2rlamondiale.stats.dao.domain.Sigelec;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public abstract class StatistiqueSigelecRepository implements JpaRepository<Sigelec, Long> {
  /*Requete ERE*/
    //Clause Beneficaire
    @Query(value = "select count(*) from TBCL0DSG where TYOPECLI='CBF' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countCbfEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value= "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countCbfEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value = "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countCbfEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value = "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countCbfEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);
        //BIA

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='EBIA') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countBiaEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='EBIA') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countBiaEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='EBIA') " +
            "and COETADSG ='EXPI' " +
            "and  TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countBiaEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='EBIA') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",nativeQuery = true)
    public  abstract Long countBiaEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);
    //Liquidation
    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DS where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countLiquidationEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public  abstract Long countLiquidationEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countLiquidationEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='LIQR') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",nativeQuery = true)
    public  abstract Long countLiquidationEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    //Arbitrage

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countArbitrageEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countArbitrageEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='ERE' ",nativeQuery = true)
    public abstract Long countArbitrageEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI')" +
            " and COETADSG ='TERM' and " +
            "TSCRE BETWEEN :date1 and :date2  and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countArbitrageEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    //Versement Libre

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ANNU' " +
            "and  TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countVersementLibreEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    public abstract Long countVersementLibreEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI'" +
            "and COETADSG ='EXPI' and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementLibreEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM'and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementLibreEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and and COSYS='ERE' ",nativeQuery = true)
    public abstract Double countVersementLibreEreTermineeMontant(@Param("date1") Date date1, @Param("date2") Date date2);

    //Versement progarammé

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementProgrammeEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRPG') " +
            "and COETADSG ='ERRF'and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementProgrammeEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='EXPI'and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "aand COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementProgrammeEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM'and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countVersementProgrammeEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and MTTRS > 0 " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Double countVersementProgrammeEreTermineeMontant(@Param("date1") Date date1, @Param("date2") Date date2);

    //Arret Versement Programmé

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
    public abstract Long countArretVersementProgrammeEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRPG') " +
            "and COETADSG ='ERRF'and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
    public abstract Long countArretVersementProgrammeEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='EXPI'and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "aand COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
    public abstract Long countArretVersementProgrammeEreExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM'and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE' " +
            "and MTTRS < 0",nativeQuery = true)
    public abstract Long countArretVersementProgrammeEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and MTTRS < 0 " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Double countArretVersementProgrammeEreTermineeMontant(@Param("date1") Date date1, @Param("date2") Date date2);

  // RIB
    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='TERM'and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='ERE'",nativeQuery = true)
    public  abstract Long countRibEreTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ANNU'and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countRibEreAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='EXPI'and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countRibEreExprire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ERRF'and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countRibEreErreur(@Param("date1") Date date1, @Param("date2") Date date2);

   /*Requete MDPRO*/

    //////Arbitrage
    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='ERE'",nativeQuery = true)
    public abstract Long countArbitrageMdpAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countArbitrageMdpErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM' " +
            "and COSYS='MDP' ",nativeQuery = true)
    public abstract Long countArbitrageMdpExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI')" +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countArbitrageMdpTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    //Versement  Libre

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ANNU' " +
            "and  TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countVersementLibreMdpAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countVersementLibreMdpErreur(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='EXPI'and TSCRE BETWEEN  :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countVersementLibreMdpExpire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM'and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countVersementLibreMdpTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN :date1 and :date2 " +
            "and and COSYS='MDP'",nativeQuery = true)
    public abstract Double countMontantVersementLibreMdpTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    //RIB
    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN :date1 and :date2 " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countRibMdpTerminee(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ANNU'  and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countRibMdpAnnule(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA'  " +
            "and COETADSG ='EXPI'and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countRibMdpExprire(@Param("date1") Date date1, @Param("date2") Date date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ERRF'and TSCRE BETWEEN :date1 and :date2 " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
    public abstract Long countRibMdpErreur(@Param("date1") Date date1, @Param("date2") Date date2);

}

