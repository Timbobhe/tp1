package fr.ag2rlamondiale.stats.dao.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


@Entity
@Table(name = "TBCL0DSG")
public class Sigelec implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqDmdSig")
    @SequenceGenerator(name = "seqDmdSig", sequenceName = "CL0DSGQ", allocationSize = 1)
    private long iddsg;

    @Column(name = "COAPPORI", nullable = false, length = 10)
    private String codeApp;

    @Column(name = "COETADSG", nullable = false, length = 5)

    private String etatDmd;

    // Identifiant contrat CL
    @Column(name = "IDCTRSIL", nullable = false, length = 50)
    private String idContrat;

    // Numero d'assure
    @Column(name = "NOASS", length = 20)
    private String numeroAssure;

    // Identifiant Demande Signature Systeme EXTERNE CL
    @Column(name = "IDDSGEXT", nullable = false, length = 100)
    private String idExt;

    @Column(name = "IDTRS", length = 100)
    private String idTransactionExt;

    // Identifiant interne Compte utilisateur HG
    @Column(name = "IDGDI", nullable = false, length = 15)
    private String idGDI;

    // Identifiant interne Compte utilisateur HG
    @Column(name = "NOPER")
    private String numPersonne;

    @Column(name = "TSCRE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreation;

    @Column(name = "TSMAJ")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateMiseAjour;

    @Column(name = "TYOPECLI", nullable = false, length = 5)
    @JoinColumn(name = "codon")
    private String typeOp;

    @Column(name = "LBMSGANO")
    private String errorMessage;

    @Column(name = "INANOANA")
    private Boolean analyse;

    @Column(name = "MTTRS")
    private BigDecimal montant;

    @Column(name = "COPAR")
    private String codePartenaire;

    @Column(name = "CODEPPER")
    private String codeDepartement;

    @Column(name = "DTNAIPER")
    private Date dateNaissancePersonne;

    @Column(name = "LBCMP")
    private String libCompartiment;

    @Column(name = "COSYS")
    private String codeSilo;

    // @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.DETACH)
    //@JoinColumn(name = "IDTRSPCB", foreignKey = @ForeignKey(ConstraintMode.NO_CONSTRAINT), referencedColumnName = "IDTRSPCB")
    //private PaiementCB paiementCB;

}
