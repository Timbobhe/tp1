package fr.ag2rlamondiale.stats.dao.domain;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "TBCL0TRC")
@Data
public class Trace implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqReporting")
    @SequenceGenerator(name = "seqReporting", sequenceName = "CL0REP", allocationSize = 1)
    private long idtrc;

    @Column(name = "COAPP", length = 10)
    private String codeApp;

    @Column(name = "TYEVETRC", length = 50)
    private String codeAction;

    @Column(name = "IDINTCPT", length = 50)
    private String idGdiSalarie;

    @Column(name = "TSDEBTRC", length = 6)
    private Date startDate;

    @Column(name = "TSFINTRC", length = 6)
    private Date endDate;

    @Column(name = "LBMETPER", length = 50)
    private String numPersonne;

    @Column(name = "LBMETCTR", length = 50)
    private String numContrat;

    @Column(name = "LBMETTIT", length = 250)
    private String fullName;

    @Column(name = "IDLIDIMP", length = 50)
    private String impersonnation;

    @Column(name = "LBPTFWEB", length = 250)
    private String browser;

    @Column(name = "LBDON001", length = 250)
    private String comment1;

    @Column(name = "LBDON002", length = 250)
    private String comment2;

    @Column(name = "LBDON003", length = 250)
    private String comment3;

    @Column(name = "VADONCPL", length = 250)
    private String vadoncpl;

    @Column(name = "COPAR", length = 20)
    private String copar;

    @Column(name = "COSYS", length = 3)
    private String cosys;

}
