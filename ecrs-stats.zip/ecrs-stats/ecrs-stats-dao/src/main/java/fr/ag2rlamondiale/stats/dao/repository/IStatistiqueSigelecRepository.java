package fr.ag2rlamondiale.stats.dao.repository;

import fr.ag2rlamondiale.stats.dao.domain.Sigelec;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Date;

public interface IStatistiqueSigelecRepository extends JpaRepository<Sigelec, Long> {


    /*Requete ERE*/
    //Clause Beneficaire
    @Query(value = "select count(*) from TBCL0DSG where TYOPECLI='CBF' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countCbfEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value= "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countCbfEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value = "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countCbfEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value = "select count(*) from TBCL0DSG where (TYOPECLI='CBF') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countCbfEreTerminee(@Param("date1") String date1, @Param("date2") String date2);
    //BIA

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='EBIA') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countBiaEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='EBIA') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countBiaEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='EBIA') " +
            "and COETADSG ='EXPI' " +
            "and  TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countBiaEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='EBIA') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countBiaEreTerminee(@Param("date1") String date1, @Param("date2") String date2);
    //Liquidation
    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countLiquidationEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countLiquidationEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG  where (TYOPECLI='LIQR') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countLiquidationEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='LIQR') " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countLiquidationEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    //Arbitrage

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countArbitrageEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countArbitrageEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE' ",nativeQuery = true)
       Long countArbitrageEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI')" +
            " and COETADSG ='TERM' and " +
            "TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS')  and COSYS='ERE'",
            nativeQuery = true)
       Long countArbitrageEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    //Versement Libre

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ANNU' " +
            "and  TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countVersementLibreEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
       Long countVersementLibreEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI'" +
            "and COETADSG ='EXPI' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementLibreEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementLibreEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
       Double countVersementLibreEreTermineeMontant(@Param("date1") String date1, @Param("date2") String date2);

    //Versement libre avec CB

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ANNU' " +
            "and IDTRSPCB is not NULL " +
            "and  TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    Long countVersementLibreCBAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ERRF' " +
            "and IDTRSPCB is not NULL " +
            "and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",
            nativeQuery = true)
    Long countVersementLibreCBErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI'" +
            "and COETADSG ='EXPI' " +
            "and IDTRSPCB is not NULL " +
            "and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countVersementLibreCBExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and IDTRSPCB is not NULL " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countVersementLibreCBTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and IDTRSPCB is not NULL " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
    Double countVersementLibreCBTermineeMontant(@Param("date1") String date1, @Param("date2") String date2);

    //Versement progarammé

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementProgrammeEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRPG') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementProgrammeEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='EXPI' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementProgrammeEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countVersementProgrammeEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and MTTRS > 0 " +
            "and COSYS='ERE'",nativeQuery = true)
       Double countVersementProgrammeEreTermineeMontant(@Param("date1") String date1, @Param("date2") String date2);

    //Arret Versement Programmé

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            " and COETADSG ='ANNU' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
       Long countArretVersementProgrammeEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRPG') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
       Long countArretVersementProgrammeEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='EXPI' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE' " +
            "and MTTRS < 0 ",nativeQuery = true)
       Long countArretVersementProgrammeEreExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE' " +
            "and MTTRS < 0",nativeQuery = true)
       Long countArretVersementProgrammeEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRPG' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and MTTRS < 0 " +
            "and COSYS='ERE'",nativeQuery = true)
       Double countArretVersementProgrammeEreTermineeMontant(@Param("date1") String date1, @Param("date2") String date2);

    // RIB
    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='ERE'",nativeQuery = true)
    Long countRibEreTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ANNU' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countRibEreAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='EXPI' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countRibEreExprire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countRibEreErreur(@Param("date1") String date1, @Param("date2") String date2);

    /*Requete MDPRO*/

    //////Arbitrage
    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ANNU' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='ERE'",nativeQuery = true)
       Long countArbitrageMdpAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='ERRF' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countArbitrageMdpErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI') " +
            "and COETADSG ='EXPI' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP' ",nativeQuery = true)
       Long countArbitrageMdpExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='ARBI')" +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countArbitrageMdpTerminee(@Param("date1") String date1, @Param("date2") String date2);

    //Versement  Libre

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ANNU' " +
            "and  TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countVersementLibreMdpAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where (TYOPECLI='VRLI') " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countVersementLibreMdpErreur(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='EXPI' and TSCRE BETWEEN  TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countVersementLibreMdpExpire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countVersementLibreMdpTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select sum(MTTRS) from TBCL0DSG where TYOPECLI='VRLI' " +
            "and COETADSG ='TERM' " +
            "and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='MDP'",nativeQuery = true)
       Double countMontantVersementLibreMdpTerminee(@Param("date1") String date1, @Param("date2") String date2);

    //RIB
    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='TERM' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countRibMdpTerminee(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ANNU'  and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countRibMdpAnnule(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA'  " +
            "and COETADSG ='EXPI' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countRibMdpExprire(@Param("date1") String date1, @Param("date2") String date2);

    @Query(value="select count(*) from TBCL0DSG where TYOPECLI='RIBA' " +
            "and COETADSG ='ERRF' and TSCRE BETWEEN TO_DATE(:date1, 'DD/MM/YYYY HH24:MI:SS') and TO_DATE(:date2, 'DD/MM/YYYY HH24:MI:SS') " +
            "and IDGDI NOT IN (Select IDGDI from TBCL0DSG where COETADSG ='TERM') " +
            "and COSYS='MDP'",nativeQuery = true)
       Long countRibMdpErreur(@Param("date1") String date1, @Param("date2") String date2);

}
