package fr.ag2rlamondiale.stats;

import fr.ag2rlamondiale.stats.dao.repository.IStatistiqueSigelecRepository;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@ComponentScan(basePackageClasses = IStatistiqueSigelecRepository.class)
@EnableJpaRepositories(basePackages = "fr.ag2rlamondiale.stats.dao.repository")
@EntityScan(basePackages = "fr.ag2rlamondiale.stats.dao.domain")
@Import(DtoConfig.class)
public class DaoConfig {
}
