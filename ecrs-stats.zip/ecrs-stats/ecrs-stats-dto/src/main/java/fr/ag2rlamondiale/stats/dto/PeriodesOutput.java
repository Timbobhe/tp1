package fr.ag2rlamondiale.stats.dto;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.text.SimpleDateFormat;
import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PeriodesOutput implements IPeriodesOutput {
    private int numberOfConnexions;
    private String startTime;
    private String day;

    @JsonIgnore
    public Date getDayOfMonth() {
        return PeriodesOutput.getDayOfMonth(this);
    }

    @JsonIgnore
    public String getStringDayOfMonth() {
        final Date dayOfMonth = PeriodesOutput.getDayOfMonth(this);
        return formatDate(dayOfMonth);
    }

    @SneakyThrows
    public static Date getDayOfMonth(IPeriodesOutput periodesOutput) {
        final String day = periodesOutput.getDay();
        if (day != null) {
            return new SimpleDateFormat("dd-MM-yyyy").parse(day.substring(0, 10));
        }
        return null;
    }


    @JsonIgnore
    public static String formatDate(Date date) {
        if (date != null) {
            return new SimpleDateFormat("dd-MM-yyyy").format(date);
        }
        return null;
    }
}

