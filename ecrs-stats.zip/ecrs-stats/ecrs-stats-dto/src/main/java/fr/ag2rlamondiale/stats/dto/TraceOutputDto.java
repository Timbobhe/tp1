package fr.ag2rlamondiale.stats.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TraceOutputDto {

    private String periode;

    /**
     * periodes par date
     */
    @Builder.Default
    private Map<String, Integer> periodesOutputs = new HashMap<>();

    public TraceOutputDto(String periode) {
        this.periode = periode;
        this.periodesOutputs = new HashMap<>();
    }

    public void add(PeriodesOutput periodesOutput) {
        periodesOutputs.put(periodesOutput.getStringDayOfMonth(), periodesOutput.getNumberOfConnexions());
    }
}
