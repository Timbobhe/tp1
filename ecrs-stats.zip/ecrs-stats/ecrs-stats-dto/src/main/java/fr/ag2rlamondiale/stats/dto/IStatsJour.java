package fr.ag2rlamondiale.stats.dto;


public interface IStatsJour {
    String getJour();
    int getPicMinute();
    double getMoyCxnMinute();


}
