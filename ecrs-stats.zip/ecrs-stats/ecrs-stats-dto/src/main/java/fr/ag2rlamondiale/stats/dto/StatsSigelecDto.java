package fr.ag2rlamondiale.stats.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StatsSigelecDto {
    /*Ere*/
    //CBF
    private Long nbCbfEreAnnule;
    private Long nbCbfEreErreur;
    private Long nbCbfEreExpire;
    private Long nbCbfEreTermine;
    //BIA
    private Long nbBiaEreAnnule;
    private Long nbBiaEreErreur;
    private Long nbBiaEreExpire;
    private Long nbBiaEreTermine;
    //Liquidation
    private Long nbLiqEreAnnule;
    private Long nbLiqEreErreur;
    private Long nbLiqEreExpire;
    private Long NbLiqEreTermine;
    //Arbitrage
    private Long nbArbitrageEreAnnule;
    private Long nbArbitrageEreErreur;
    private Long nbArbitrageEreExpire;
    private Long nbArbitrageEreTermine;
    //Rib
    private Long nbRibEreAnnule;
    private Long nbRibEreErreur;
    private Long nbRibEreExpire;
    private Long nbRibEreTermine;
    //Versement Libre
    private Long nbVLEreAnnule;
    private Long nbVLEreErreur;
    private Long nbVLEreExpire;
    private Long nbVLEreTermine;
    private Double TotalMontantEreVL;
    //Versement Libre
    private Long nbVLCBAnnule;
    private Long nbVLCBErreur;
    private Long nbVLCBExpire;
    private Long nbVLCBTermine;
    private Double TotalMontantCBVL;

    //Versement Programmé
    private Long nbVPEreAnnule;
    private Long nbVPEreErreur;
    private Long nbVPEreExpire;
    private Long nbVPEreTermine;
    private Double TotalMontantEreVP;
    //Arrêt Versement Programmé
    private Long nbAVPEreAnnule;
    private Long nbAVPEreErreur;
    private Long nbAVPEreExpire;
    private Long nbAVPEreTermine;
    private Double TotalMontantEreAVP;
    /*MDPRO*/
    //Arbitrage
    private Long nbArbitrageMdpAnnule;
    private Long nbArbitrageMdpErreur;
    private Long nbArbitrageMdpExpire;
    private Long nbArbitrageMdpTermine;
    //Rib
    private Long nbRibMdpAnnule;
    private Long nbRibMdpErreur;
    private Long nbRibMdpExpire;
    private Long nbRibMdpTermine;
    //Versement Libre
    private Long nbVLMdpAnnule;
    private Long nbVLMdpErreur;
    private Long nbVLMdpExpire;
    private Long nbVLMdpTermine;
    private Double TotalMontantMdpVL;
}
