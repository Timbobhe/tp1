package fr.ag2rlamondiale.stats.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DateInputDto {
    private String startDate;
    private String endDate;
}
