package fr.ag2rlamondiale.stats.dto;


public interface IPeriodesOutput {

    int getNumberOfConnexions();

    String getStartTime();

    String getDay();
}

