package fr.ag2rlamondiale.stats;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan
@EntityScan
@Slf4j
public class EcrsStatsCliApplication {
	public static void main(String[] args) {
		new SpringApplicationBuilder(EcrsStatsCliApplication.class)
				.web(WebApplicationType.NONE)
				.run(args);
	}

//	@Autowired
//	ResultExlFile resultExlFile;
//
//	@EventListener
//	public void onApplicationEvent(ApplicationReadyEvent ae) throws Exception {
//		log.info("Execution de {}", this.getClass().getSimpleName());
//		resultExlFile.calculStats("c:/temp/stats.xls");
//	}
}

