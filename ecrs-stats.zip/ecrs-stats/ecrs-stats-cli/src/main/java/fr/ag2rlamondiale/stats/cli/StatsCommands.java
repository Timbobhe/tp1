package fr.ag2rlamondiale.stats.cli;

import fr.ag2rlamondiale.stats.main.business.ResultExlFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.shell.standard.ShellComponent;
import org.springframework.shell.standard.ShellMethod;
import org.springframework.shell.standard.ShellOption;

@ShellComponent
public class StatsCommands {

	private final ResultExlFile service;

	@Autowired
	public StatsCommands(ResultExlFile service) {
		this.service = service;
	}

	// calcul-stats --filename "c:/temp/stats.xlsx"
	@ShellMethod("generate stats file")
	public void calculStats(@ShellOption String filename) throws Exception {
		//service.calculStats(filename);
	}
}
