# ECRS STATS

## Architecture du projet

- `ecrs-stats-main` : le coeur de l'application (Les Facade + RestController)
- `ecrs-stats-dao` : les DOA (Repository, Entities)
- `ecrs-stats-dto` : les DTO (Objets)
- `ecrs-stats-api` : exposition des API Rest via un serveur 
- `ecrs-stats-cli` : exposition des Facade via un shell 

## Execution en API

- Exécuter `fr.ag2rlamondiale.stats.EcrsStatsApplication`
- Lancer http://localhost:8086/stats

## Execution en CLI

- Exécuter `fr.ag2rlamondiale.stats.EcrsStatsCliApplication`

- exécuter la commande

```shell
calcul-stats --filename "c:/temp/stats.xlsx"
```
