package fr.ag2rlamondiale.stats.main.business;

import fr.ag2rlamondiale.stats.dto.TraceInputDto;
import fr.ag2rlamondiale.stats.dto.TracesOutputDto;
import fr.ag2rlamondiale.stats.dto.TracesStatsDto;
import fr.ag2rlamondiale.stats.main.exceptions.MaxTraceExceedException;

import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;

public interface ITraceFacade {

    TracesOutputDto getTracesGroupedBy1hour(TraceInputDto input) throws MaxTraceExceedException;

    void calculTraces(OutputStream outputStream, TracesOutputDto tracesExcelDto) throws IOException;

    TracesStatsDto getMaxTraceForDay(TraceInputDto input) throws MaxTraceExceedException, ParseException;

    void generateExcelFile(OutputStream outputStream, TracesStatsDto tracesExcelDto) throws IOException;
}
