package fr.ag2rlamondiale.stats.main.business;

import fr.ag2rlamondiale.stats.dto.DateInputDto;
import fr.ag2rlamondiale.stats.dto.StatsSigelecDto;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.ServletOutputStream;
import java.io.IOException;

@Service
public class ResultExlFile {

	@Autowired
	IStatsSigelecFacade statsSigelecFacade;

	public StatsSigelecDto calculStats(DateInputDto inputDto) throws Exception {
		StatsSigelecDto statsSigelecDto = statsSigelecFacade.buildStats(inputDto);

		//prints the message on the console
		System.out.println("Excel file has been generated successfully.");
		return  statsSigelecDto;
	}

    public void exportCalculStats(ServletOutputStream outputStream, StatsSigelecDto statsSigelecDto) throws IOException {
        //declare file name to be create
        //creating an instance of HSSFWorkbook class
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {

            //invoking creatSheet() method and passing the name of the sheet to be created
            XSSFSheet sheetEre = workbook.createSheet("StatsEre");

            //creating the 0th row using the createRow() method

            XSSFRow rowhead = sheetEre.createRow((short) 0);
            //creating cell by using the createCell() method and setting the values to the cell by using the setCellValue() method
            rowhead.createCell(0).setCellValue("Type de demande");
            rowhead.createCell(1).setCellValue("Transactions OK");
            rowhead.createCell(2).setCellValue("Montant cumulé");
            rowhead.createCell(3).setCellValue("Transactions annulées");
            rowhead.createCell(4).setCellValue("Transactions non abouties");
            rowhead.createCell(5).setCellValue("Transactions en erreur");

            //inserting data in the  row 2
            XSSFRow row1 = sheetEre.createRow((short) 1);
            row1.createCell(0).setCellValue("Versement Libre");
            row1.createCell(1).setCellValue(statsSigelecDto.getNbVLEreTermine());
            row1.createCell(2).setCellValue(statsSigelecDto.getTotalMontantEreVL().toString());
            row1.createCell(3).setCellValue(statsSigelecDto.getNbVLEreAnnule());
            row1.createCell(4).setCellValue(statsSigelecDto.getNbVLEreExpire());
            row1.createCell(5).setCellValue(statsSigelecDto.getNbVLEreErreur());

            //inserting data in row 3
            XSSFRow row2 = sheetEre.createRow((short) 2);
            row2.createCell(0).setCellValue("Arbitrages");
            row2.createCell(1).setCellValue(statsSigelecDto.getNbArbitrageEreTermine());
            row2.createCell(2).setCellValue("");
            row2.createCell(3).setCellValue(statsSigelecDto.getNbArbitrageEreAnnule());
            row2.createCell(4).setCellValue(statsSigelecDto.getNbArbitrageEreExpire());
            row2.createCell(5).setCellValue(statsSigelecDto.getNbArbitrageEreErreur());

            //inserting data in row 4
            XSSFRow row3 = sheetEre.createRow((short) 3);
            row3.createCell(0).setCellValue("Versement programmé");
            row3.createCell(1).setCellValue(statsSigelecDto.getNbVPEreTermine());
            row3.createCell(2).setCellValue(statsSigelecDto.getTotalMontantEreVP());
            row3.createCell(3).setCellValue(statsSigelecDto.getNbVPEreAnnule());
            row3.createCell(4).setCellValue(statsSigelecDto.getNbVPEreExpire());
            row3.createCell(5).setCellValue(statsSigelecDto.getNbVPEreErreur());

            //inserting data in row 5
            XSSFRow row4 = sheetEre.createRow((short) 4);
            row4.createCell(0).setCellValue("Arrêt de VP");
            row4.createCell(1).setCellValue(statsSigelecDto.getNbAVPEreTermine());
            row4.createCell(2).setCellValue(statsSigelecDto.getTotalMontantEreAVP());
            row4.createCell(3).setCellValue(statsSigelecDto.getNbAVPEreAnnule());
            row4.createCell(4).setCellValue(statsSigelecDto.getNbAVPEreExpire());
            row4.createCell(5).setCellValue(statsSigelecDto.getNbAVPEreErreur());
            //inserting data in row 5
            XSSFRow row5 = sheetEre.createRow((short) 5);
            row5.createCell(0).setCellValue("Affiliation en ligne");
            row5.createCell(1).setCellValue(statsSigelecDto.getNbBiaEreTermine());
            row5.createCell(2).setCellValue("");
            row5.createCell(3).setCellValue(statsSigelecDto.getNbBiaEreAnnule());
            row5.createCell(4).setCellValue(statsSigelecDto.getNbBiaEreExpire());
            row5.createCell(5).setCellValue(statsSigelecDto.getNbBiaEreErreur());

            //inserting data in row 6
            XSSFRow row6 = sheetEre.createRow((short) 6);
            row6.createCell(0).setCellValue("Changement Clause bénéficiaire");
            row6.createCell(1).setCellValue(statsSigelecDto.getNbCbfEreTermine());
            row6.createCell(2).setCellValue("");
            row6.createCell(3).setCellValue(statsSigelecDto.getNbCbfEreAnnule());
            row6.createCell(4).setCellValue(statsSigelecDto.getNbCbfEreExpire());
            row6.createCell(5).setCellValue(statsSigelecDto.getNbCbfEreAnnule());
            //inserting data in row 7
            XSSFRow row7 = sheetEre.createRow((short) 7);
            row7.createCell(0).setCellValue("Liquidation");
            row7.createCell(1).setCellValue(statsSigelecDto.getNbLiqEreTermine());
            row7.createCell(2).setCellValue("");
            row7.createCell(3).setCellValue(statsSigelecDto.getNbLiqEreAnnule());
            row7.createCell(4).setCellValue(statsSigelecDto.getNbLiqEreExpire());
            row7.createCell(5).setCellValue(statsSigelecDto.getNbLiqEreErreur());
            //inserting data in row 7
            XSSFRow row8 = sheetEre.createRow((short) 8);
            row8.createCell(0).setCellValue("RIB");
            row8.createCell(1).setCellValue(statsSigelecDto.getNbRibEreTermine());
            row8.createCell(2).setCellValue("");
            row8.createCell(3).setCellValue(statsSigelecDto.getNbRibEreAnnule());
            row8.createCell(4).setCellValue(statsSigelecDto.getNbRibEreExpire());
            row8.createCell(5).setCellValue(statsSigelecDto.getNbRibEreErreur());

            //inserting data in the  row 3
            XSSFRow row9 = sheetEre.createRow((short) 9);
            row9.createCell(0).setCellValue("Versement Libre avec paiement CB");
            row9.createCell(1).setCellValue(statsSigelecDto.getNbVLCBTermine());
            row9.createCell(2).setCellValue(statsSigelecDto.getTotalMontantCBVL().toString());
            row9.createCell(3).setCellValue(statsSigelecDto.getNbVLCBAnnule());
            row9.createCell(4).setCellValue(statsSigelecDto.getNbVLCBExpire());
            row9.createCell(5).setCellValue(statsSigelecDto.getNbVLCBErreur());

            ////////////////////////////////MDP
            XSSFSheet sheetMdp = workbook.createSheet("StatsMdp");
            XSSFRow rowheadMdp = sheetMdp.createRow((short) 0);
            //creating cell by using the createCell() method and setting the values to the cell by using the setCellValue() method
            rowheadMdp.createCell(0).setCellValue("Type de demande");
            rowheadMdp.createCell(1).setCellValue("Transactions OK");
            rowheadMdp.createCell(2).setCellValue("Montant cumulé");
            rowheadMdp.createCell(3).setCellValue("Transactions annulées");
            rowheadMdp.createCell(4).setCellValue("Transactions non abouties");
            rowheadMdp.createCell(5).setCellValue("Transactions en erreur");
            /////first row
            XSSFRow rowMpd1 = sheetMdp.createRow((short) 1);
            rowMpd1.createCell(0).setCellValue("Arbitrages");
            rowMpd1.createCell(1).setCellValue(statsSigelecDto.getNbArbitrageMdpTermine());
            rowMpd1.createCell(2).setCellValue("");
            rowMpd1.createCell(3).setCellValue(statsSigelecDto.getNbArbitrageMdpAnnule());
            rowMpd1.createCell(4).setCellValue(statsSigelecDto.getNbArbitrageMdpExpire());
            rowMpd1.createCell(5).setCellValue(statsSigelecDto.getNbArbitrageMdpErreur());

            /////second row
            XSSFRow rowMdp2 = sheetMdp.createRow((short) 2);
            rowMdp2.createCell(0).setCellValue("RIB");
            rowMdp2.createCell(1).setCellValue(statsSigelecDto.getNbRibMdpTermine());
            rowMdp2.createCell(2).setCellValue("");
            rowMdp2.createCell(3).setCellValue(statsSigelecDto.getNbRibMdpAnnule());
            rowMdp2.createCell(4).setCellValue(statsSigelecDto.getNbRibMdpExpire());
            rowMdp2.createCell(5).setCellValue(statsSigelecDto.getNbRibMdpErreur());

            ////third row
            XSSFRow rowMdp3 = sheetMdp.createRow((short) 3);
            rowMdp3.createCell(0).setCellValue("Versement Libre");
            rowMdp3.createCell(1).setCellValue(statsSigelecDto.getNbVLMdpTermine());
            rowMdp3.createCell(2).setCellValue(statsSigelecDto.getTotalMontantMdpVL());
            rowMdp3.createCell(3).setCellValue(statsSigelecDto.getNbVLMdpAnnule());
            rowMdp3.createCell(4).setCellValue(statsSigelecDto.getNbVLMdpExpire());
            rowMdp3.createCell(5).setCellValue(statsSigelecDto.getNbVLMdpErreur());

            workbook.write(outputStream);
        }
        outputStream.close();
    }
}
