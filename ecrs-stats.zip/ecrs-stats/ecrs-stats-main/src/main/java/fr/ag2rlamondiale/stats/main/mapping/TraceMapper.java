package fr.ag2rlamondiale.stats.main.mapping;

import fr.ag2rlamondiale.stats.dto.IPeriodesOutput;
import fr.ag2rlamondiale.stats.dto.IStatsJour;
import fr.ag2rlamondiale.stats.dto.PeriodesOutput;
import fr.ag2rlamondiale.stats.dto.StatsJour;
import org.mapstruct.Mapper;

import java.util.Collection;
import java.util.List;

@Mapper(componentModel = "spring")
public abstract class TraceMapper {

	public abstract PeriodesOutput map(IPeriodesOutput in);

	public abstract Collection<PeriodesOutput> map(Collection<IPeriodesOutput> in);

    public abstract List<StatsJour> map(List<IStatsJour> in);
}
