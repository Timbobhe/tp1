package fr.ag2rlamondiale.stats.main.business.impl;

import fr.ag2rlamondiale.stats.dao.repository.ITraceRepository;
import fr.ag2rlamondiale.stats.dto.*;
import fr.ag2rlamondiale.stats.main.business.ITraceFacade;
import fr.ag2rlamondiale.stats.main.exceptions.MaxTraceExceedException;
import fr.ag2rlamondiale.stats.main.mapping.TraceMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TraceFacadeImpl implements ITraceFacade {

    private static final int MAX_NUMBER_OF_CONNEXIONS = 33;
    public static final String TS_FORMAT = "dd-MM-yyyy HH:mm:ss";

    @Autowired
    private ITraceRepository traceRepository;

    @Autowired
    private TraceMapper traceMapper;

    @SneakyThrows
    @Override
    public TracesOutputDto getTracesGroupedBy1hour(TraceInputDto input) throws MaxTraceExceedException {
        log.info("Connexion {}", input);
        DateFormat dateFormat = new SimpleDateFormat(TS_FORMAT);

        final long days = ChronoUnit.DAYS.between(dateFormat.parse(input.getStartDate()).toInstant(), dateFormat.parse(input.getEndDate()).toInstant()) + 1;
        if (days < 0 || days >= MAX_NUMBER_OF_CONNEXIONS) {
            log.error("Maximum number of connexion exceed {}, max = {} days", days, MAX_NUMBER_OF_CONNEXIONS);
            throw new MaxTraceExceedException("Maximum number of connexion exceed, max = " + MAX_NUMBER_OF_CONNEXIONS + " days");
        }
        Collection<PeriodesOutput> periodesOutputs = traceMapper.map(traceRepository.getTracesGroupedBy1hour(
                input.getCodeApplication(),
                input.getCodeAction(),
                input.getStartDate(),
                input.getEndDate(),
                input.getNumContrat()));

        Map<String, Map<String, PeriodesOutput>> tracesParPlageEtParDate = new HashMap<>();
        Set<Date> dates = new HashSet<>();
        periodesOutputs.forEach(e -> {
            dates.add(e.getDayOfMonth());
            tracesParPlageEtParDate.computeIfAbsent(e.getStartTime(), s -> new HashMap<>()).put(e.getStringDayOfMonth(), e);
        });

        final List<TraceOutputDto> traces = new ArrayList<>();
        final List<String> dateList = dates.stream().sorted()
                .map(PeriodesOutput::formatDate)
                .collect(Collectors.toList());

        tracesParPlageEtParDate.forEach((plage, tracesParDate) -> {
            TraceOutputDto r = new TraceOutputDto(plage);
            traces.add(r);
            dateList.forEach(date -> {
                final PeriodesOutput p = tracesParDate.getOrDefault(date, PeriodesOutput.builder()
                        .startTime(plage)
                        .day(date + " " + plage)
                        .numberOfConnexions(0)
                        .build());
                r.add(p);
            });
        });

        final TracesOutputDto result = new TracesOutputDto();
        result.setCodeApplication(input.getCodeApplication());
        result.setCodeAction(input.getCodeAction());
        result.setNumContrat(input.getNumContrat());

        result.setTraces(traces.stream()
                .sorted(Comparator.comparing(TraceOutputDto::getPeriode))
                .collect(Collectors.toList()));

        result.setDates(dateList);
        return result;
    }

    public void calculTraces(OutputStream outputStream, TracesOutputDto tracesExcelDto) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheetEre = workbook.createSheet("Traces " + tracesExcelDto.getCodeApplication() + "-" + tracesExcelDto.getCodeAction());
            XSSFRow rowhead = sheetEre.createRow((short) 0);
            rowhead.createCell(0).setCellValue("");

            List<String> dates = tracesExcelDto.getDates();

            for (int i = 0; i < dates.size(); i++) {
                rowhead.createCell(i + 1).setCellValue(dates.get(i));
            }

            List<TraceOutputDto> traces = tracesExcelDto.getTraces();

            for (int i = 0; i < traces.size(); i++) {
                XSSFRow row = sheetEre.createRow((short) i + 1);
                row.createCell(0).setCellValue(traces.get(i).getPeriode());

                for (int j = 0; j < dates.size(); j++) {
                    final String date = dates.get(j);
                    row.createCell(j + 1).setCellValue(traces.get(i).getPeriodesOutputs().get(date));
                }
            }

            workbook.write(outputStream);
        }
        outputStream.close();
        log.info("File downloaded successfully ");
    }

    @Override
    public TracesStatsDto getMaxTraceForDay(TraceInputDto input) throws MaxTraceExceedException, ParseException {
        log.info("Connexion {}", input);
        DateFormat dateFormat = new SimpleDateFormat(TS_FORMAT);

        final long days = ChronoUnit.DAYS.between(dateFormat.parse(input.getStartDate()).toInstant(), dateFormat.parse(input.getEndDate()).toInstant()) + 1;
        if (days < 0 || days >= MAX_NUMBER_OF_CONNEXIONS) {
            log.error("Maximum number of connexion exceed {}, max = {} days", days, MAX_NUMBER_OF_CONNEXIONS);
            throw new MaxTraceExceedException("Maximum number of connexion exceed, max = " + MAX_NUMBER_OF_CONNEXIONS + " days");
        }
        List<StatsJour> statsJours = traceMapper.map(traceRepository.getMaxTraceForDay(
                input.getCodeApplication(),
                input.getCodeAction(),
                input.getStartDate(),
                input.getEndDate(),
                input.getNumContrat()));

        return TracesStatsDto.builder()
                .codeAction(input.getCodeAction())
                .numContrat(input.getNumContrat())
                .codeApplication(input.getCodeApplication())
                .detailsDates(statsJours)
                .build();
    }

    @Override
    public void generateExcelFile(OutputStream outputStream, TracesStatsDto tracesExcelDto) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            XSSFSheet sheetEre = workbook.createSheet("Traces " + tracesExcelDto.getCodeApplication() + "-" + tracesExcelDto.getCodeAction());
            XSSFRow rowhead = sheetEre.createRow((short) 0);

            rowhead.createCell(0).setCellValue("date");
            rowhead.createCell(1).setCellValue("Moyenne de connexion par minute");
            rowhead.createCell(2).setCellValue("pic de connexion en minute");
            List<StatsJour> traces = tracesExcelDto.getDetailsDates();

            for (int i = 0; i < traces.size(); i++) {
                XSSFRow row = sheetEre.createRow((short) i + 1);
                row.createCell(0).setCellValue(traces.get(i).getJour());
                row.createCell(1).setCellValue(traces.get(i).getMoyCxnMinute());
                row.createCell(2).setCellValue(traces.get(i).getPicMinute());
            }

            workbook.write(outputStream);
        }
        outputStream.close();
        log.info("File downloaded successfully ");
    }

}
