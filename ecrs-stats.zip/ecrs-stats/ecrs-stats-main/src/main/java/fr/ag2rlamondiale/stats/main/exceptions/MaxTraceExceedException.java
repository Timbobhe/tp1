package fr.ag2rlamondiale.stats.main.exceptions;

public class MaxTraceExceedException  extends Exception{

    public MaxTraceExceedException(String errMessage) {
        super(errMessage);
    }
}
