package fr.ag2rlamondiale.stats.main.api;

import fr.ag2rlamondiale.stats.dto.*;
import fr.ag2rlamondiale.stats.main.business.IStatsSigelecFacade;
import fr.ag2rlamondiale.stats.main.business.ITraceFacade;
import fr.ag2rlamondiale.stats.main.business.ResultExlFile;
import fr.ag2rlamondiale.stats.main.exceptions.MaxTraceExceedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@RestController
@RequestMapping({"/unsecure", "/public"})
public class StatsApi {

    private static final String CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding";
    private static final String BINARY = "binary";
    private static final String APPLICATION_FORCE_DOWNLOAD = "application/force-download";
    private static final String ATTACHMENT_FILENAME = "attachment; filename=\"";

    @Autowired
    private IStatsSigelecFacade statsSigelecFacade;

    @Autowired
    private ITraceFacade traceFacade;

    @Autowired
    private ResultExlFile resultExlFile;

    @PostMapping("/stats/stats-sigelec")
    public ResponseEntity<StatsSigelecDto> statsSigelec(@RequestBody() DateInputDto inputDto, HttpServletResponse servletResponse) throws Exception {
        setDocumentHeaders(servletResponse, "stats-retraite-supp.xlsx");
        DateInputDto dateInputDto = new DateInputDto();
        dateInputDto.setStartDate(inputDto.getStartDate());
        dateInputDto.setEndDate(inputDto.getEndDate());

        StatsSigelecDto statsSigelecDto;
        try {
            statsSigelecDto = resultExlFile.calculStats(dateInputDto);
            System.out.println(statsSigelecDto.toString());
        } catch (Exception e) {
            log.error("Excel file has not been generated", e);
            throw e;
        }
        return ResponseEntity.ok(statsSigelecDto);
    }

    @PostMapping("/stats/stats-sigelec/export")
    public void exportStatsSigelec(@RequestBody() StatsSigelecDto statsSigelecDto, HttpServletResponse servletResponse) throws Exception {

        setDocumentHeaders(servletResponse, "stats-retraite-supp.xlsx");
        try (ServletOutputStream outputStream = servletResponse.getOutputStream()) {
            resultExlFile.exportCalculStats(outputStream, statsSigelecDto);
        } catch (Exception e) {
            log.error("Excel file has not been generated", e);
            throw e;
        }
    }

    /**
     * This end point is used to fetch the pics of connexion between date1 and date2 grouped by a given slot ( ex: 10 min )
     *
     * @param inputDto The input object containing
     *                 -- the start date
     *                 -- the end date
     *                 -- the number of contrat
     *                 -- the slot : the period by which we want to group the result ( accept 10, 30 and 60 )
     * @return the list of slot periods and the numbers of connexions in each slot
     */
    @PostMapping("/stats/trace-connexion")
    public ResponseEntity<TracesOutputDto> getTracesGroupedBy1hour(@RequestBody TraceInputDto inputDto) {
        TracesOutputDto pics;
        try {
            pics = traceFacade.getTracesGroupedBy1hour(inputDto);
        } catch (MaxTraceExceedException e) {
            return ResponseEntity.status(502).body(null);
        }
        return ResponseEntity.ok(pics);
    }

    /**
     * This end point is used to export an xlsx file containing the data passed in body input
     *
     * @param tracesExcelDto      contains the columns names and the data to export
     * @param httpServletResponse
     */
    @PostMapping("/stats/trace-connexion/export")
    public void downloadTraceConnexion(@RequestBody TracesOutputDto tracesExcelDto, HttpServletResponse httpServletResponse) throws Exception {
        setDocumentHeaders(httpServletResponse, "heures-de-connexions-retraite-supp.xlsx");

        try (ServletOutputStream outputStream = httpServletResponse.getOutputStream()) {
            traceFacade.calculTraces(outputStream, tracesExcelDto);
        } catch (Exception e) {
            log.error("Excel file has not been generated", e);
            throw e;
        }
    }

    @PostMapping("/stats/trace-connexion/pics")
    public ResponseEntity<TracesStatsDto> getMaxTraceForDay(@RequestBody TraceInputDto inputDto) throws Exception {
        TracesStatsDto pics;
        try {
            pics = traceFacade.getMaxTraceForDay(inputDto);
        } catch (MaxTraceExceedException e) {
            return ResponseEntity.status(502).body(null);
        }
        return ResponseEntity.ok(pics);
    }

    /**
     * This end point is used to export an xlsx file containing the data passed in body input
     *
     * @param tracesExcelDto      contains the columns names and the data to export
     * @param httpServletResponse
     */
    @PostMapping("/stats/pics-connexion/export")
    public void downloadPicsConnexion(@RequestBody TracesStatsDto tracesExcelDto, HttpServletResponse httpServletResponse) throws Exception {
        setDocumentHeaders(httpServletResponse, "heures-de-connexions-retraite-supp.xlsx");

        try (ServletOutputStream outputStream = httpServletResponse.getOutputStream()) {
            traceFacade.generateExcelFile(outputStream, tracesExcelDto);
        } catch (Exception e) {
            log.error("Excel file has not been generated", e);
            throw e;
        }
    }

    protected void setDocumentHeaders(HttpServletResponse response, String documentName) {
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_FILENAME + documentName + "\"");
        response.addHeader(CONTENT_TRANSFER_ENCODING, BINARY);
        response.addHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
        response.setContentType(APPLICATION_FORCE_DOWNLOAD);
    }
}
