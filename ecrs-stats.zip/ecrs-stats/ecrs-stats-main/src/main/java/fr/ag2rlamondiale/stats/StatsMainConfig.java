package fr.ag2rlamondiale.stats;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan(basePackages = {"fr.ag2rlamondiale.stats"})
@Import(DaoConfig.class)
public class StatsMainConfig {
}
