package fr.ag2rlamondiale.stats.main.business;

import fr.ag2rlamondiale.stats.dto.DateInputDto;
import fr.ag2rlamondiale.stats.dto.StatsSigelecDto;

public interface IStatsSigelecFacade {

    //void getStats() throws Exception;

    /*ERE*/
    //CBF
    Long countCbfEreAnnule(DateInputDto inputDto);
    Long countCbfEreErreur(DateInputDto inputDto);
    Long countCbfEreExpire(DateInputDto inputDto);
    Long countCbfEreTerminee(DateInputDto inputDto);

    //BIA
    Long countBiaEreAnnule(DateInputDto inputDto);
    Long countBiaEreErreur(DateInputDto inputDto);
    Long countBiaEreExpire(DateInputDto inputDto);
    Long countBiaEreTerminee(DateInputDto inputDto);

    //LIQUIDATION
    Long countLiqrEreAnnule(DateInputDto inputDto);
    Long countLiqrEreErreur(DateInputDto inputDto);
    Long countLiqrEreExpire(DateInputDto inputDto);
    Long countLiqrEreTerminee(DateInputDto inputDto);

    //ARBITRAGE
    Long countArbitrageEreAnnule(DateInputDto inputDto);
    Long countArbitrageEreErreur(DateInputDto inputDto);
    Long countArbitrageEreExpire(DateInputDto inputDto);
    Long countArbitrageEreTerminee(DateInputDto inputDto);

    //RIB
    Long countRibEreTerminee(DateInputDto inputDto);
    Long countRibEreAnnule(DateInputDto inputDto);
    Long countRibEreExpire(DateInputDto inputDto);
    Long countRibEreErreur(DateInputDto inputDto);

    //VERSEMENT LIBRE
    Long countVersementLibreEreAnnule(DateInputDto inputDto);
    Long countVersementLibreEreErreur(DateInputDto inputDto);
    Long countVersementLibreEreExpire(DateInputDto inputDto);
    Long countVersementLibreEreTerminee(DateInputDto inputDto);
    Double TotalMontanttVersementLibreEreTermine(DateInputDto inputDto);

    //VERSEMENT PROGRAMME
    Long countVersementProgrammeEreAnnule(DateInputDto inputDto);
    Long countVersementProgrammeEreErreur(DateInputDto inputDto);
    Long countVersementProgrammeEreExpire(DateInputDto inputDto);
    Long countVersementProgrammeEreTerminee(DateInputDto inputDto);
    Double TotalMontantVersementProgrammeEreTermine(DateInputDto inputDto);

    //ARRET VERSEMENT
    Long countArretVersementProgrammeEreAnnule(DateInputDto inputDto);
    Long countArretVersementProgrammeEreErreur(DateInputDto inputDto);
    Long countArretVersementProgrammeEreExpire(DateInputDto inputDto);
    Long countArretVersementProgrammeEreTerminee(DateInputDto inputDto);
    Double countArrretVersementProgrammeEreTermineeMontant(DateInputDto inputDto);

    /*MDPRO*/
    //RIB
    Long countRibMdpTerminee(DateInputDto inputDto);
    Long countRibMdpAnnule(DateInputDto inputDto);
    Long countRibMdpExpire(DateInputDto inputDto);
    Long countRibMdpErreur(DateInputDto inputDto);

    //Arbitrage
    Long countArbitrageMdpAnnule(DateInputDto inputDto);
    Long countArbitrageMdpErreur(DateInputDto inputDto);
    Long countArbitrageMdpExpire(DateInputDto inputDto);
    Long countArbitrageMdpTerminee(DateInputDto inputDto);

    //Versement Libre
    Long countVersementLibreMdpAnnule(DateInputDto inputDto);
    Long countVersementLibreMdpErreur(DateInputDto inputDto);
    Long countVersementLibreMdpExpire(DateInputDto inputDto);
    Long countVersementLibreMdpTerminee(DateInputDto inputDto);
    Double totalMontantVersementLibreMdpTerminee(DateInputDto inputDto);

    //Versement Libre avec Paiement CB
    Long countVersementLibreCBAnnule(DateInputDto inputDto);
    Long countVersementLibreCBErreur(DateInputDto inputDto);
    Long countVersementLibreCBExpire(DateInputDto inputDto);
    Long countVersementLibreCBTerminee(DateInputDto inputDto);
    Double totalMontantVersementLibreCBTerminee(DateInputDto inputDto);


    StatsSigelecDto buildStats(DateInputDto inputDto);
}
