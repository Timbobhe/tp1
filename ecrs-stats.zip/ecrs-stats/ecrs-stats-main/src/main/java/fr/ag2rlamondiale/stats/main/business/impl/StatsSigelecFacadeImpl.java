package fr.ag2rlamondiale.stats.main.business.impl;

import fr.ag2rlamondiale.stats.dao.repository.IStatistiqueSigelecRepository;
import fr.ag2rlamondiale.stats.dto.DateInputDto;
import fr.ag2rlamondiale.stats.dto.StatsSigelecDto;
import fr.ag2rlamondiale.stats.main.business.IStatsSigelecFacade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;

@Slf4j
@Service
public class StatsSigelecFacadeImpl implements IStatsSigelecFacade {

    @Autowired
    private IStatistiqueSigelecRepository statsSigelecRepository;


    /*ERE*/
    //CBF
    @Override
    public Long countCbfEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countCbfEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countCbfEreErreur(DateInputDto inputDto) {
        return statsSigelecRepository.countCbfEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countCbfEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countCbfEreExpire(inputDto.getStartDate(), inputDto.getEndDate());
    }


    @Override
    public Long countCbfEreTerminee(DateInputDto inputDto) {
        return statsSigelecRepository.countCbfEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());
    }

    //BIA
    @Override
    public Long countBiaEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countBiaEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countBiaEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countBiaEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countBiaEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countBiaEreExpire(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countBiaEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countBiaEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }
    //Liquidation

    @Override
    public Long countLiqrEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countLiquidationEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countLiqrEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countLiquidationEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countLiqrEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countLiquidationEreExpire(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countLiqrEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countLiquidationEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    //Arbitrage
    @Override
    public Long countArbitrageEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArbitrageEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArbitrageEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageEreExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArbitrageEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }


    //RIB
    @Override
    public Long countRibEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countRibEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countRibEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countRibEreExprire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countRibEreErreur(inputDto.getStartDate(), inputDto.getEndDate());
    }
    //Versement Libre

    @Override
    public Long countVersementLibreEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementLibreEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementLibreEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreEreExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementLibreEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Double TotalMontanttVersementLibreEreTermine(DateInputDto inputDto) {


        Double MontantVL = statsSigelecRepository.countVersementLibreEreTermineeMontant(inputDto.getStartDate(), inputDto.getEndDate());
        if (MontantVL == null) {
            return Double.valueOf(0);
        } else {
            return MontantVL;
        }


    }

    //Versement Programmé
    @Override
    public Long countVersementProgrammeEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementProgrammeEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementProgrammeEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementProgrammeEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementProgrammeEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementProgrammeEreExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementProgrammeEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementProgrammeEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Double TotalMontantVersementProgrammeEreTermine(DateInputDto inputDto) {

        Double MontantVP = statsSigelecRepository.countVersementProgrammeEreTermineeMontant(inputDto.getStartDate(), inputDto.getEndDate());
        if (MontantVP == null) {
            return Double.valueOf(0);
        } else {
            return MontantVP;
        }
    }

    //Arret Versement
    @Override
    public Long countArretVersementProgrammeEreAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countArretVersementProgrammeEreAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArretVersementProgrammeEreErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countArretVersementProgrammeEreErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArretVersementProgrammeEreExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countArretVersementProgrammeEreExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArretVersementProgrammeEreTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countArretVersementProgrammeEreTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Double countArrretVersementProgrammeEreTermineeMontant(DateInputDto inputDto) {

        Double montantAVP = statsSigelecRepository.countArretVersementProgrammeEreTermineeMontant(inputDto.getStartDate(), inputDto.getEndDate());
        if (montantAVP == null) {
            return Double.valueOf(0);
        } else {
            return montantAVP;
        }

    }

    /*MDPRO*/
    //RIB
    @Override
    public Long countRibMdpTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countRibMdpTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibMdpAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countRibMdpAnnule(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibMdpExpire(DateInputDto inputDto) {
        return statsSigelecRepository.countRibMdpExprire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countRibMdpErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countRibMdpErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }
    //Arbitrage

    @Override
    public Long countArbitrageMdpAnnule(DateInputDto inputDto) {
        return statsSigelecRepository.countArbitrageMdpAnnule(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countArbitrageMdpErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageMdpErreur(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countArbitrageMdpExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageMdpExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countArbitrageMdpTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countArbitrageMdpTerminee(inputDto.getStartDate(), inputDto.getEndDate());

    }

    //Versement Libre
    @Override
    public Long countVersementLibreMdpAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreMdpAnnule(inputDto.getStartDate(), inputDto.getEndDate());
    }


    @Override
    public Long countVersementLibreMdpExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreMdpExpire(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementLibreMdpErreur(DateInputDto inputDto) {
        return statsSigelecRepository.countVersementLibreMdpErreur(inputDto.getStartDate(), inputDto.getEndDate());

    }

    @Override
    public Long countVersementLibreMdpTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreMdpTerminee(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Double totalMontantVersementLibreMdpTerminee(DateInputDto inputDto) {

        Double MontantMdp = statsSigelecRepository.countMontantVersementLibreMdpTerminee(inputDto.getStartDate(), inputDto.getEndDate());

        if (MontantMdp == null) {
            return Double.valueOf(0);
        } else {
            return MontantMdp;
        }
    }

    @Override
    public Long countVersementLibreCBAnnule(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreCBAnnule(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countVersementLibreCBErreur(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreCBErreur(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countVersementLibreCBExpire(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreCBExpire(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Long countVersementLibreCBTerminee(DateInputDto inputDto) {

        return statsSigelecRepository.countVersementLibreCBTerminee(inputDto.getStartDate(), inputDto.getEndDate());
    }

    @Override
    public Double totalMontantVersementLibreCBTerminee(DateInputDto inputDto) {

        Double MontantMdp = statsSigelecRepository.countVersementLibreCBTermineeMontant(inputDto.getStartDate(), inputDto.getEndDate());

        if (MontantMdp == null) {
            return Double.valueOf(0);
        } else {
            return MontantMdp;
        }
    }

    @Override
    public StatsSigelecDto buildStats(DateInputDto inputDto) {
        StatsSigelecDto s = new StatsSigelecDto();

        /*ERE*/
        //Arbitrage
        s.setNbArbitrageEreAnnule(countArbitrageEreAnnule(inputDto));
        s.setNbArbitrageEreErreur(countArbitrageEreErreur(inputDto));
        s.setNbArbitrageEreExpire(countArbitrageEreExpire(inputDto));
        s.setNbArbitrageEreTermine(countArbitrageEreTerminee(inputDto));
        //CBF
        s.setNbCbfEreAnnule(countCbfEreAnnule(inputDto));
        s.setNbCbfEreExpire(countCbfEreExpire(inputDto));
        s.setNbCbfEreErreur(countCbfEreErreur(inputDto));
        s.setNbCbfEreTermine(countCbfEreTerminee(inputDto));
        //Liquidation
        s.setNbLiqEreAnnule(countLiqrEreAnnule(inputDto));
        s.setNbLiqEreErreur(countLiqrEreErreur(inputDto));
        s.setNbLiqEreExpire(countLiqrEreExpire(inputDto));
        s.setNbLiqEreTermine(countLiqrEreTerminee(inputDto));
        //RIB
        s.setNbRibEreAnnule(countRibEreAnnule(inputDto));
        s.setNbRibEreExpire(countRibEreExpire(inputDto));
        s.setNbRibEreErreur(countRibEreErreur(inputDto));
        s.setNbRibEreTermine(countRibEreTerminee(inputDto));
        //Versement Libre
        s.setNbVLEreAnnule(countVersementLibreEreAnnule(inputDto));
        s.setNbVLEreErreur(countVersementLibreEreErreur(inputDto));
        s.setNbVLEreExpire(countVersementLibreEreExpire(inputDto));
        s.setNbVLEreTermine(countVersementLibreEreTerminee(inputDto));
        s.setTotalMontantEreVL(TotalMontanttVersementLibreEreTermine(inputDto));
        //Versement Libre avec paiement CB
        s.setNbVLCBAnnule(countVersementLibreCBAnnule(inputDto));
        s.setNbVLCBErreur(countVersementLibreCBErreur(inputDto));
        s.setNbVLCBExpire(countVersementLibreCBExpire(inputDto));
        s.setNbVLCBTermine(countVersementLibreCBTerminee(inputDto));
        s.setTotalMontantCBVL(totalMontantVersementLibreCBTerminee(inputDto));
        //Versement Programmé
        s.setNbVPEreAnnule(countVersementProgrammeEreAnnule(inputDto));
        s.setNbVPEreExpire(countVersementProgrammeEreExpire(inputDto));
        s.setNbVPEreErreur(countVersementProgrammeEreErreur(inputDto));
        s.setNbVPEreTermine(countVersementProgrammeEreTerminee(inputDto));
        s.setTotalMontantEreVP(TotalMontantVersementProgrammeEreTermine(inputDto));
        //Arret Versement Programmé
        s.setNbAVPEreAnnule(countArretVersementProgrammeEreAnnule(inputDto));
        s.setNbAVPEreErreur(countArretVersementProgrammeEreErreur(inputDto));
        s.setNbAVPEreExpire(countArretVersementProgrammeEreExpire(inputDto));
        s.setNbAVPEreTermine(countArretVersementProgrammeEreTerminee(inputDto));
        s.setTotalMontantEreAVP(countArrretVersementProgrammeEreTermineeMontant(inputDto));
        //Bia
        s.setNbBiaEreAnnule(countBiaEreAnnule(inputDto));
        s.setNbBiaEreExpire(countBiaEreExpire(inputDto));
        s.setNbBiaEreTermine(countBiaEreTerminee(inputDto));
        s.setNbBiaEreErreur(countBiaEreErreur(inputDto));

        /*MDPRO*/
        //Arbitrage
        s.setNbArbitrageMdpAnnule(countArbitrageMdpAnnule(inputDto));
        s.setNbArbitrageMdpExpire(countArbitrageMdpExpire(inputDto));
        s.setNbArbitrageMdpErreur(countArbitrageMdpErreur(inputDto));
        s.setNbArbitrageMdpTermine(countArbitrageMdpTerminee(inputDto));
        //RIB
        s.setNbRibMdpAnnule(countRibMdpAnnule(inputDto));
        s.setNbRibMdpExpire(countRibMdpExpire(inputDto));
        s.setNbRibMdpErreur(countRibMdpErreur(inputDto));
        s.setNbRibMdpTermine(countRibMdpTerminee(inputDto));
        //Versement Libre
        s.setNbVLMdpAnnule(countVersementLibreMdpAnnule(inputDto));
        s.setNbVLMdpExpire(countVersementLibreMdpExpire(inputDto));
        s.setNbVLMdpErreur(countVersementLibreMdpErreur(inputDto));
        s.setNbVLMdpTermine(countVersementLibreMdpTerminee(inputDto));
        s.setTotalMontantMdpVL(totalMontantVersementLibreMdpTerminee(inputDto));
        return s;
    }

 /*   public void setStatsSigelecRepository(StatistiqueSigelecRepository statsSigelecRepository) {
        this.statsSigelecRepository = statsSigelecRepository;
    }*/
}
