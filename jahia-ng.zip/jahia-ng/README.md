# JahiaNg

La librairie **JahiaNg** a pour but d'intégrer des **contributions** et des **dictionnaires** `Jahia` dans une
application Angular.

---

## Installation

- `npm install @ag2rlamondiale/jahia-ng`

- Dans le module de l'application :

```typescript
import {jahiaConfig} from './jahia.config';

@NgModule({
  declarations: [AppComponent],

  imports: [
    BrowserModule,
    HttpClientModule,
    CommonModule,
    MetisNgModule.forRoot(),
    StoreModule.forRoot({}, {metaReducers}),
    // Il faut rajouter ces Effects avant d'importer JahiaNgModule corrige l'erreur :
    // StaticInjectorError(Platform: core)[ApiEffects -> Actions]: NullInjectorError: No provider for Actions!
    EffectsModule.forRoot([]),
    ReduxApiNgModule,
    JahiaNgModule.forRoot({config: jahiaConfig})
  ],
  providers: [
    HttpInterceptorProviders2,
    BackendService,
    {provide: ErrorHandler, useClass: GlobalErrorHandler}
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}

```

- L'import du Module `JahiaNgModule` prend en paramètre un
  objet [`jahiaConfig`](projects/jahia-ng/src/lib/actions/jahia-config.ts) permettant de configurer :
  - Le code du ENDPOINT `apiBase` paramétrés dans le fichier `src\assets\env-specific.js`
  - **OPTIONNEL** : code des ENDPOINTS `apiDictionnaire`, `apiContrib` paramétrés dans le
    fichier `src\assets\env-specific.js` si différents de `apiBase`
  - **OPTIONNEL** Les contributions Jahia (contribId -> chemin Jahia de la contribution)
  - **OPTIONNEL** les dictionnaires Jahia (dicoId -> chemin Jahia du dictionnaire)
  - **OPTIONNEL** les contributions "questions réponses" Jahia (contribId -> chemin Jahia de la contribution "question
    réponse")
  - **OPTIONNEL** les paths : un regroupement fonctionnel de la config (contributions, dictionnaires, questions
    réponses)

Exemple : `src\app\jahia.config.ts`

```typescript

const PATHS = {
  common: {
    contribsPath: {},

    dictionnariesPath: {
      dictionnaireCommonAppMessagesDictionnaire: '/sites/aqe/ecrs/body-content/dictionnairecommonappmessages.apiDico.html.ajax',
      dictionnaireClauseBeneficiaire: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/modifier-sa-clause-beneficiaire/area-simple-content/clausebeneficiairecommundictionn.apiDico.html.ajax',
      dictionnaireClauseContrat: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausecontratdictionnairedelibel.apiDico.html.ajax',
      dictionnaireClauseStandardContrat: '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausestandarddictionnairedelibe.apiDico.html.ajax',
    },

    questionsResponsesPath: {
      AIDE_PACTE_VERSEMENT:
        '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content.apiV2.html.ajax?blockId=aidepacteversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment',

      QUESTIONS_CLAUSE_BENEFICIAIRE:
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/clause-beneficiaire/area-simple-content.apiV2.html.ajax?blockId=clauseBeneficiaire&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  coordonneesBancaires: {
    contribsPath: {
      'CONTENU_RIB_NOUVELLE_DEMANDE': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=contenu_rib_nouvelle_demande&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      'TITLE_MODIFICATION_COORDONEES_BANCAIRES': '/sites/aqe/ecrs/coordonneesbancaires/body-content.apiV2.html.ajax?blockId=title_modification_coordonees_bancaires&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    }
  }
}

const CONTRIBS_PATH = {

  /*Evenements*/
  'ERE_BIA': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
  'ERE_CONF': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_conf&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
  'ERE_PND_3': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_3&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
  'ERE_PND_1': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_1&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
  'ERE_VDPP': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_vdpp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
  'ERE_INFO': '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_info&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
};

/*QuestionsReponses*/
QUESTIONS_CARACTERE_PERSONNEL:
  '/sites/aqe/home/retraite-supplementaire/mentions-legales/area-simple-content.apiV2.html.ajax?blockId=mentionscnil&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    AIDE_PACTE_VERSEMENT
:
'/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content.apiV2.html.ajax?blockId=aidepacteversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
  QUESTIONS_FREQUENTES
:
'/sites/aqe/home/retraite-supplementaire/en-savoir-plus/questions-frequentes/area-simple-content.apiV2.html.ajax?blockId=faqBlock&typeUrlResource=absolute&removeJS&removeCSS&removeComment'
}
;

const DICTIONNAIRES_TITLES_PATH = {
  titlesDictionnaireDeLibelles: '/sites/aqe/home/retraite-supplementaire/area-simple-content/titlesdictionnairedelibelles.apiDico.html.ajax',
  commonAppMessagesDictionnaire: '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content/commonappmessagesdictionnaire.apiDico.html.ajax',

  eventDictionnaireDeLibelles: '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content/eventdictionnairedelibelles.apiDico.html.ajax'
};

const RESOURCES_PATH = {
  addingHeader: '/files/live/sites/aqe/files/contributed/styles/partenaires/html/adding-header.html'
};

export const jahiaConfig = {
  apiBase: 'jahia_endpoint',
  apiJahiaEval: 'backend/jahiaConditionEval',
  contribsPath: CONTRIBS_PATH,
  dictionnariesPath: DICTIONNAIRES_PATH,
  questionsResponsesPath: QUESTIONS_REPONSES_PATH,
  paths: PATHS
};

```

---

## Usage Component

### Jahia-Contrib `<jahia-contrib>`

#### Affichage de la contribution Jahia depuis sont ID (`contribId` il s'agit d'un ID propre à l'application)

```html

<jahia-contrib contribId="ensavoirplus/header"></jahia-contrib>
```

#### Affichage de la contribution Jahia variabilisée

Il est possible de passer un `Context` au composant `jahia-contrib`. Ce `Context` sera probablement récupéré depuis
le **Store Redux**.

```typescript
import {Context} from 'jahia-ng';
```

```html

<jahia-contrib contribId="detailRente" [context]="ctx" (contribUpdate)="onUpdateContrib($event)"></jahia-contrib>
```

*Avec contribPath* : à noter qu'il est obligatoire de renseigner *contribId* pour sauvegarder la contrib dans le Store.

```html

<jahia-contrib contribId="qad_code_12692"
               contribPath="sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/qad/area-simple-content.apiV2.html.ajax?blockId=qad_code_12692&typeUrlResource=absolute&removeComments">

```

**Attributs disponibles :**

| Input/Output | Attribut      | Description                               | Obligatoire | Valeur par défaut |
| ------------ | ------------- | ----------------------------------------- | ----------- | ----------------- |
| Input        | contribId     | Identifiant de la contribution            | Obligatoire | N/A               |
| Input        | contribPath     | Path de la contribution (permet de récupérer une Contrib dynamiquement)           | Facultatif | N/A               |
| Output       | contribUpdate | EventEmitter à la reception de la contrib | Facultatif  | N/A               |

---

### Jahia-Dico `<jahia-dico>`

#### Récupération d'un dictionnaire depuis son `dicoId` et accès aux valeurs du dictionnaire via la méthode `#valeur(KEY)`

```html

<jahia-dico #dico dicoId="titles_dictionnaire_de_libelles" (dicoUpdate)="onUpdateDico($event)"></jahia-dico>

<h2 style="color: green">{{dico.valeur('ERE_TITLES_Arbitrage') | async}}</h2>
```

Attention : `title`  est déprécié au profit de `dicoId`.

**Attributs disponibles :**

| Input/Output | Attribut   | Description                         | Obligatoire | Valeur par défaut |
| ------------ | ---------- | ----------------------------------- | ----------- | ----------------- |
| Input        | dicoId     | Identifiant du dictionnaire         | Obligatoire | N/A               |
| Output       | dicoUpdate | EventEmitter à la reception du dico | Facultatif  | N/A               |

---

### Jahia-Dico-Entry `<jahia-dico-entry>`

#### Récupération d'une entrée de dictionnaire depuis son `dicoId` et sa `key`

```html

<jahia-dico-entry dicoId="titles_dictionnaire_de_libelles" key="ERE_TITLES_Arbitrage" [modeHtml]="true|false"
                  (dicoEntryUpdate)="onUpdateDicoEntry($event)"></jahia-dico-entry>
```

Attention : `title`  est déprécié au profit de `dicoId`.

**Attributs disponibles :**

| Input/Output | Attribut        | Description                                                       | Obligatoire | Valeur par défaut |
| ------------ | --------------- | ----------------------------------------------------------------- | ----------- | ----------------- |
| Input        | dicoId          | Identifiant du dictionnaire                                       | Obligatoire | N/A               |
| Input        | key             | Clé de l'entrée dans le dico                                      | Obligatoire | N/A               |
| Input        | modeHtml        | Indique si l'entrée doit être considérée comme du HTML ou du TEXT | Facultatif  | false             |
| Output       | dicoEntryUpdate | EventEmitter à la reception de l'entrée                           | Facultatif  | N/A               |

---

### Jahia-Resource `<jahia-resource>`

#### Récupération d'une resource statique depuis Jahia

```html

<jahia-resource resourceId="addingHeader"
                resourcePath="/files/live/sites/aqe/files/contributed/styles/partenaires/html/adding-header.html"
                storable="true"
                (resourceUpdate)="onUpdateResource($event)">
</jahia-resource>
```

**Attributs disponibles :**

| Input/Output | Attribut       | Description                                                                                | Obligatoire                              | Valeur par défaut |
| ------------ | -------------- | ------------------------------------------------------------------------------------------ | ---------------------------------------- | ----------------- |
| Input        | resourceId     | Identifiant de la resource permettant de la sauvegarder dans le STORE                      | Facultatif                               | N/A               |
| Input        | resourcePath   | Chemin Jahia qui sera concaténé avec config.jahia_files ou config.jahia_api_endpoint       | Facultatif si renseigné dans jahiaConfig | N/A               |
| Input        | storable       | Indique si la resource doit être sauvegardée dans le STORE (true = sauvegardée, false non) | Facultatif                               | true              |
| Output       | resourceUpdate | EventEmitter à la reception de la ressource                                                | Facultatif                               | N/A               |

### Jahia-Contrib `<jahia-gestions-reponses>`

#### Affichage de la contribution Jahia d'une faq (questions/reponses) depuis sont ID (`contribId` il s'agit d'un ID propre à l'application)

```html

<jahia-questions-reponses contribId="QUESTIONS_FREQUENTES"></jahia-questions-reponses>

```

#### Affichage de la contribution Jahia variabilisée

```html

<jahia-questions-reponses (questionsReponsesUpdate)="onUpdateQr($event)"
                          contribId="QUESTIONS_CARACTERE_PERSONNEL"></jahia-questions-reponses>

```

**Attributs disponibles :**

| Input/Output | Attribut                | Description                                         | Obligatoire | Valeur par défaut |
| ------------ | ----------------------- | --------------------------------------------------- | ----------- | ----------------- |
| Input        | contribId               | Identifiant de la contribution                      | Obligatoire | N/A               |
| Output       | questionsReponsesUpdate | EventEmitter à la reception de la questionsreponses | Facultatif  | N/A               |

---

## Usage Config

### Configuration des Contributions

L'URL vers les contributions est formée de 4 parties :

1. Chemin vers le Noeud Jahia : `/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content`
2. Suffixer par la 'Vue' : `.apiV2.html.ajax`
3. Ajouter l'ID du block Esigate dans la QueryString : `?blockId=contenu_ere_bia`
4. Rajouter dans la QueryString les paramètres suivants : `&typeUrlResource=absolute&removeJS&removeCSS&removeComments`

Soit au total, par exemple :

http://cdr-dev-jahia7/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments

### Configuration des Dictionnaires

L'URL vers le dictionnaire est formée des 2 parties ci-dessous :

1. Chemin vers le noeud
   Jahia : `/sites/aqe/home/retraite-supplementaire/area-simple-content/titlesdictionnairedelibelles`
2. Suffixer par la 'Vue' : `.apiDico.html.ajax`

Soit au total, par exemple :

http://cdr-dev-jahia7/sites/aqe/home/retraite-supplementaire/area-simple-content/titlesdictionnairedelibelles.apiDico.html.ajax


---

## Usage Service

En dehors des différents composants offerts par la librairie pour intégrer du contenu Jahia, il existe
un [`JahiaService`](projects/jahia-ng/src/lib/services/Jahia.service.ts) qui permet de récupérer les données Jahia côté
TS.

Toutes les API permettant de récupérer des données sont Asynchrones (retour `Observable`).

| API Récupération données | Description                                   |
| --------------------------- | --------------------------------------------- |
| getDico                     | Récupérer un dictionnaire Jahia             |
| getDicoEntry                | Récupérer une entrée de dictionnaire Jahia |
| getContrib                  | Récupérer une Contrib Jahia                 |
| getContribWithStatus        | Récupérer une Contrib Jahia                 |
| getResource                 | Récupérer une Resource Jahia                |
| getQuestionsReponses        | Récupérer une Contrib "Questions Reponses"  |

Toutes les API permettant de faire un Prefetch sont non bloquantes (asynchrones). Elles ne retournent rien.

| API Prefetch               | Description                                                           |
| -------------------------- | --------------------------------------------------------------------- |
| **prefetchPathsDomaines**  | Prefetch l'ensemble des Contribs, Dico, QR, ... d'une fonctionnalité |
| prefetchAll                |                                                                       |
| preFetchDico               | Prefetch Dictionnaire Jahia                                           |
| preFetchContrib            | Prefetch Contrib Jahia                                                |
| preFetchQuestionsResponses | Prefetch Contrib "Questions Reponses"                                 |
| preFetchResources          | Prefetch Resource Jahia                                               |

Exemple :

```typescript
this.jahia.prefetchPathsDomaines('common', 'coordonneesBancaires', 'prevalidation', 'identiteNum');
```

| API Déconnectée | Description                           |
| ----------------- | ------------------------------------- |
| dumpState         | Dump l'état du Store dans la console |
| loadState         | Charger l'état Jahia dans le Store   |

---

### Développement

- `npm run start` to compile library and run project.

- `ng generate component components/foo --project=jahia-ng` to generate a component named foo inside components folder
  in `jahia-ng` project.

To add a dependency to the library, you need to add it to peerDependencies so that the project that uses your library
get invited to install the dependency "example: adding bootstrap to peer peerDependencies".
