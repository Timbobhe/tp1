'use strict';

var proxy = require('express-http-proxy');
var app = require('express')();
var cors = require('cors');
var jahia = require('./data/jahia-data.json');

//CORS
var corsOptions = {
  origin: true,
  credentials: true,
  methods: ['GET', 'PUT', 'POST', 'DELETE']
};
app.use(cors(corsOptions));

app.use('/proxy-jahia', proxy('cdr-dev-jahia7', {
  preserveHostHdr: true,
  userResHeaderDecorator(headers, userReq, userRes, proxyReq, proxyRes) {
    // recieves an Object of headers, returns an Object of headers.
    // console.log("REQUEST", userReq);
    delete headers['access-control-allow-credentials'];
    Object.assign(headers, { 'access-control-allow-origin': `http://localhost:4200` });
    console.log("HEADERS", headers);
    return headers;
  }
}));

app.get('/json-data', function (req, res) {
  return res.status(200).json(jahia.DATA);
});


app.set('port', process.env.PORT || 9696);


app.listen(app.get('port'), function () {
  console.log(
    `✔Express server listening on http://localhost:%d`,
    app.get('port')
  );
});
