const beginBlock = '<!--$beginblock$';
const begin2Block = '$-->';
const endBlock = '<!--$endblock$';

/**
 * Retourne [le contenu, la dernière position]
 * @param string
 * @param startIndex
 */
function findContent(string, startIndex = 0) {
  const b = string.indexOf(beginBlock, startIndex);
  if (b < 0) {
    return null;
  }

  const b2 = string.indexOf(begin2Block, b);
  const s = b2 + begin2Block.length;
  const e = string.indexOf(endBlock, s);
  const content = string.substring(s, e);
  return [content, e];
}

// tslint:disable:max-line-length
/**
 * Découpage de la contribution Jahia via les délimiteurs Esigate :
 *
 * ```
 * <!--$beginblock$--> et <!--$endblock$-->
 * ```
 *
 * **Attention** Si Jamais on utilise une fonction de transcodage dans l'action JahiaContribFetch et que celle-ci utilise un DOMParser, il faudra corriger le fonctionnement du DOMParser via :
 *
 * ```typescript
 *   const parser = new DOMParser();
 *    const parsedHtml = parser.parseFromString(`<body>${html}</body>`, 'text/html');
 * ```
 *
 * Par exemple rajouter ``<body>${html}</body>`` avant le Parsing.
 *
 *
 * @param string
 */
export function findAllContents(string: string): string[] {
  const res = [];
  let startIndex = 0;
  while (true) {
    const item = findContent(string, startIndex);
    if (item === null) {
      break;
    } else {
      res.push(item[0]);
      startIndex = item[1];
    }
  }
  return res;
}
