export function forEach<V = any>(object: any, callback: (k: string, v: V) => any) {
  if (object) {
    for (const key in object) {
      if (object.hasOwnProperty(key)) {
        const value = object[key];
        callback(key, value);
      }
    }
  }
}
