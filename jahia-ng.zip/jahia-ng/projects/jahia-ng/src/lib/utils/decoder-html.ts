export const HTML_ENTITIES = {
  'amp': '&',
  'amp;#039': '\'',
  'apos': '\'',
  '#x27': '\'',
  '#x2F': '/',
  '#39': '\'',
  '#039': '\'',
  '#47': '/',
  '#047': '/',
  'lt': '<',
  'gt': '>',
  'nbsp': ' ',
  'quot': '"',
  '#34': '"',
  '#034': '"',
};

export function decodeHTMLEntities(text: string, htmlEntities = HTML_ENTITIES) {
  let res = text;
  for (const key in htmlEntities) {
    if (htmlEntities.hasOwnProperty(key)) {
      const conv = htmlEntities[key];
      res = res.replace(RegExp(`&${key};`, 'gi'), conv);
    }
  }
  return res;
}
