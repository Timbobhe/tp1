export interface Entries {
  [key: string]: string;
}

export class JahiaDictionnaireData {
  title: string;
  entries: Entries = {};
}

export class JahiaDictionnaire extends JahiaDictionnaireData {

  static fromObject(object: any): JahiaDictionnaire {
    if (!object) {
      return null;
    }

    if (object instanceof JahiaDictionnaire) {
      return object;
    }

    return Object.assign(new JahiaDictionnaire(), object);
  }

  add(key: string, value: string) {
    this.entries[key] = value;
    return this;
  }

  get(key: string): string {
    const label = this.entries[key];
    if (!label) {
      console.error(`Le dictionnaire ${this.title} ne contient pas l'entrée : "${key}"`);
    }
    return label;
  }

  isEmpty() {
    return Object.keys(this.entries).length === 0;
  }
}
