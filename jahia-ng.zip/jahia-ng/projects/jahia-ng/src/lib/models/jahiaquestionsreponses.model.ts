import { Observable } from 'rxjs';

export interface QuestionReponse {
  question: string;
  reponse: string;
}

export class QuestReponse {
  question: string;
  reponse: string;
  conditionQuest: string;
  showQuest: Observable<boolean>;
}

export interface FaqData {
  title: string;
  entries: QuestionReponse[];
  condition?: string;
}

export interface JahiaQuestionsReponsesData {
  faqs: FaqData[];
}

export class Faq implements FaqData {
  title: string;
  entries: QuestReponse[] = [];
  condition: string;
  show: Observable<boolean>;

  static fromObject(object: any): Faq {
    if (!object) {
      return null;
    }

    if (object instanceof Faq) {
      return object;
    }

    return Object.assign(new Faq(), object);
  }

  add(questReponse: QuestReponse) {
    this.entries.push(questReponse);
    return this;
  }

  isEmpty() {
    return this.entries.length === 0;
  }
}

export class JahiaQuestionsReponses implements JahiaQuestionsReponsesData {
  faqs: Faq[] = [];

  static fromObject(object: any): JahiaQuestionsReponses {
    if (!object) {
      return null;
    }

    if (object instanceof JahiaQuestionsReponses) {
      return object;
    }

    const r = Object.assign(new JahiaQuestionsReponses(), object);
    if (object.faqs) {
      r.faqs = object.faqs.map((e: any) => Faq.fromObject(e));
    }
    return r;
  }

  add(faq: Faq) {
    this.faqs.push(faq);
    return this;
  }

  isEmpty() {
    return this.faqs.length === 0;
  }
}

export class JahiaBasicQuestionsReponses {
  contribId: string;
  content: string;
}
