export interface JahiaContrib {

  /** **ID client** de la Contribution */
  contribId?: string;

  /** Contenu HTML */
  contentHtml: string;
}

// tslint:disable:max-line-length
/*
{
  "contribId": "ensavoirplus/header",

  "contentHtml": "\n\t\t    \n\r\n<div class=\"content\" >\r\n\t\r\n\t\r\n\t<h1 class='no-margin'> \r\n\t\tEn savoir plus\t\t\r\n\t</h1>\r\n\t\r\n\t<div class=\"introduction no-margin\">\r\n\t\r\n    </div>\t\r\n    \r\n</div>\n\t\t    "
}

*/
