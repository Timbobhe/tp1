export interface JahiaConditionPayload {
  expresssion: string;
  context: ContextCondition;
}

export class ContextCondition {
  [key: string]: any;
}

export interface ConditionsRequest {
  conditions: JahiaConditionPayload[];
}

export interface ConditionsResponse {
  resultatEvaluation: { [expression: string]: boolean };
}
