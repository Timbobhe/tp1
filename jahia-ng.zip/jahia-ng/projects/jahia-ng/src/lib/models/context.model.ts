import {EventEmitter} from '@angular/core';

export interface ContextEntry {
  key: string;
  value: any;
}

/** Cette classe représente une Contexte de valeurs (__values__).
 * Il est possible de suivre les modifications si _emitsChanges = true_
 */
export class Context {
  values: { [key: string]: any } = {};
  eventEmitter = new EventEmitter<ContextEntry>();

  constructor(readonly emitsChanges: boolean = true) {
  }

  static from(object: { [key: string]: any }, emitsChanges: boolean = true) {
    const c = new Context(emitsChanges);
    c.values = object;
    return c;
  }


  set(key: string, value: any) {
    if (this.values[key] !== value) {
      this.values[key] = value;
      if (this.emitsChanges) {
        this.eventEmitter.emit({key, value});
      }
    }
    return this;
  }

  get(key: string) {
    return this.values[key];
  }

  isEmpty() {
    return Object.keys(this.values).length !== 0;
  }

  forEach(callback: (value: any, key: string) => void) {
    for (const k in this.values) {
      if (this.values.hasOwnProperty(k)) {
        let v = this.values[k];
        callback(v, k);
      }
    }
  }

  toObject() {
    return {...this.values};
  }

  toString() {
    const res = [];
    this.forEach((k, v) => {
      res.push(`"${k}"="${v}"`);
    });
    return `\{${res.join(', ')}\}`;
  }

  applyContext(html: string) {
    if (html) {
      let res = html;
      this.forEach((value, key) => {
        res = res.replace(`$${key}$`, value);
      });
      return res;
    }
    return html;
  }

}
