export interface JahiaResource {

  id?: string;

  path?: string;

  content: string;

}
