import { ActionTester, ApiActionPayload, DataStatus } from '@ag2rlamondiale/redux-api-ng';
import * as JahiaAction from '../actions/jahia.actions';
import { JahiaAggregatePayload } from '../actions/jahia.actions';
import { JahiaContrib } from '../models/jahiacontrib.model';
import { forEach } from '../utils/object.utils';

export interface Contributions {
  [key: string]: JahiaContrib;
}

export interface DataStatusContributions {
  [key: string]: DataStatus<JahiaContrib>;
}

export class JahiaContribsState {
  contributions: DataStatusContributions = {};

  getContrib(contribId: string) {
    const ds = this.contributions[contribId];
    return ds ? ds.data : null;
  }
}

const initialState = new JahiaContribsState();

export function reducer(state: JahiaContribsState = initialState, action: JahiaAction.ClearJahiaContrib | JahiaAction.Actions) {
  const tester = new ActionTester(action);
  if (tester.isLoading(JahiaAction.JAHIA_CONTRIB_FETCH_ITEM)) {
    const acn = action as JahiaAction.JahiaContribFetch;
    const {contribId} = acn.payload.inputParams;
    const contribDataStatus: DataStatus<JahiaContrib> = acn.payload.dataStatus;
    if (contribDataStatus.data) {
      Object.assign(contribDataStatus.data, {contribId});
    }

    return Object.assign(new JahiaContribsState(), {
      contributions: {
        ...state.contributions,
        [contribId]: contribDataStatus
      }
    });
  }

  if (action.type === JahiaAction.CLEAR_JAHIA_CONTRIB) {
    const acn = action as JahiaAction.ClearJahiaContrib;
    const contribId = acn.payload;
    const contributions = {...state.contributions};
    delete contributions[contribId];
    return Object.assign(new JahiaContribsState(), {contributions});
  }

  if (action.type === JahiaAction.JAHIA_LOAD_STATE) {
    const acn = action as JahiaAction.JahiaLoadState;
    const contributions = acn.payload.contributions;
    if (contributions) {
      const ds: DataStatusContributions = {...state.contributions};
      forEach<JahiaContrib>(contributions, (k, v) => {
        ds[k] = {data: v, loading: false, fetched: true};
      });

      return Object.assign(new JahiaContribsState(), {contributions: ds});
    }
  }

  if (tester.isStart(JahiaAction.JAHIA_NG_SERVER_AGGREGATE)) {
    const p = action.payload as ApiActionPayload<any, JahiaAggregatePayload>;
    const query = p.inputParams;
    const pathsDomaines = query.pathsDomaines || Object.keys(query.paths);
    const ds: DataStatusContributions = {...state.contributions};
    pathsDomaines.forEach(k => {
      let contribsPath = query.paths[k].contribsPath;
      if (contribsPath) {
        forEach(contribsPath, (k, v) => {
          ds[k] = {data: null, loading: true, fetched: false};
        });
      }
    });
    const s = Object.assign(new JahiaContribsState(), {contributions: ds});
    return s;
  }

  return state;
}
