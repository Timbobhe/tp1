import { ActionTester, ApiActionPayload, DataStatus } from '@ag2rlamondiale/redux-api-ng';
import * as JahiaAction from '../actions/jahia.actions';
import { JahiaAggregatePayload } from '../actions/jahia.actions';
import { JahiaResource } from '../models/jahiaresource.model';
import { forEach } from '../utils/object.utils';

export interface Resources {
  [key: string]: JahiaResource;
}

export interface DataStatusResources {
  [key: string]: DataStatus<JahiaResource>;
}


export class JahiaResourceState {
  resources: DataStatusResources = {};

  getContrib(resourceId: string) {
    const ds = this.resources[resourceId];
    return ds ? ds.data : null;
  }
}

const initialState = new JahiaResourceState();

export function reducer(state: JahiaResourceState = initialState, action: JahiaAction.Actions) {
  const tester = new ActionTester(action);
  if (tester.isLoading(JahiaAction.JAHIA_RESOURCE_FETCH)) {
    const acn = action as JahiaAction.JahiaResourceFetch;
    const {resourceId, storable} = acn.payload.inputParams;
    if (storable && resourceId) {
      const data: DataStatus<JahiaResource> = acn.payload.dataStatus;
      return Object.assign(new JahiaResourceState(), {resources: {...state.resources, [resourceId]: data}});
    }
  }

  if (action.type === JahiaAction.JAHIA_LOAD_STATE) {
    const acn = action as JahiaAction.JahiaLoadState;
    const resources = acn.payload.resources;
    if (resources) {
      const ds: DataStatusResources = {...state.resources};
      forEach<JahiaResource>(resources, (k, v) => {
        ds[k] = {data: v, loading: false, fetched: true};
      });

      return Object.assign(new JahiaResourceState(), {resources: ds});
    }
  }


  if (tester.isStart(JahiaAction.JAHIA_NG_SERVER_AGGREGATE)) {
    const p = action.payload as ApiActionPayload<any, JahiaAggregatePayload>;
    const query = p.inputParams;
    const pathsDomaines = query.pathsDomaines || Object.keys(query.paths);
    const ds: DataStatusResources = {...state.resources};
    pathsDomaines.forEach(k => {
      let resourcesPath = query.paths[k].resourcesPath;
      if (resourcesPath) {
        forEach(resourcesPath, (k, v) => {
          ds[k] = {data: null, loading: true, fetched: false};
        });
      }
    });
    const s = Object.assign(new JahiaResourceState(), {resources: ds});
    return s;
  }

  return state;
}
