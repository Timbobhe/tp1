import { ActionTester, ApiActionPayload, DataStatus } from '@ag2rlamondiale/redux-api-ng';
import * as JahiaAction from '../actions/jahia.actions';
import { JahiaAggregatePayload } from '../actions/jahia.actions';
import { JahiaDictionnaire } from '../models/jahiadictionnaire.model';
import { forEach } from '../utils/object.utils';

export interface Dictionnaires {
  [key: string]: JahiaDictionnaire;
}

export interface DataStatusDictionnaires {
  [key: string]: DataStatus<JahiaDictionnaire>;
}

export class JahiaDictionnairesState {
  dictionnaires: DataStatusDictionnaires = {};

  getDico(title: string) {
    const ds = this.dictionnaires[title];
    return ds ? ds.data : null;
  }
}

const initialState = new JahiaDictionnairesState();

export function reducer(state: JahiaDictionnairesState = initialState, action: JahiaAction.Actions) {
  const tester = new ActionTester(action);
  if (tester.isLoading(JahiaAction.JAHIA_DICTIONNAIRE_FETCH_DICO)) {
    const acn = action as JahiaAction.JahiaDicoFetch;
    const dico: DataStatus<JahiaDictionnaire> = acn.payload.dataStatus;
    const dicoId = acn.payload.inputParams.title;
    return Object.assign(new JahiaDictionnairesState(), {
      dictionnaires: {
        ...state.dictionnaires,
        [dicoId]: dico
      }
    });
  }

  if (action.type === JahiaAction.JAHIA_LOAD_STATE) {
    const acn = action as JahiaAction.JahiaLoadState;
    const dictionnaires = acn.payload.dictionnaires;
    if (dictionnaires) {
      const dicosDs = {...state.dictionnaires};
      forEach(dictionnaires, (k, v) => {
        dicosDs[k] = {data: v, loading: false, fetched: true};
      });

      return Object.assign(new JahiaDictionnairesState(), {dictionnaires: dicosDs});
    }
  }

  if (tester.isStart(JahiaAction.JAHIA_NG_SERVER_AGGREGATE)) {
    const p = action.payload as ApiActionPayload<any, JahiaAggregatePayload>;
    const query = p.inputParams;
    const pathsDomaines = query.pathsDomaines || Object.keys(query.paths);
    const ds: DataStatusDictionnaires = {...state.dictionnaires};
    pathsDomaines.forEach(k => {
      let dictionnariesPath = query.paths[k].dictionnariesPath;
      if (dictionnariesPath) {
        forEach(dictionnariesPath, (k, v) => {
          ds[k] = {data: null, loading: true, fetched: false};
        });
      }
    });
    const s = Object.assign(new JahiaDictionnairesState(), {dictionnaires: ds});
    return s;
  }

  return state;
}
