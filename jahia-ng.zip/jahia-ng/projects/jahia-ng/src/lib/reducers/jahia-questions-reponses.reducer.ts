import { ActionTester, ApiActionPayload, DataStatus } from '@ag2rlamondiale/redux-api-ng';
import * as JahiaAction from '../actions/jahia.actions';
import { JahiaAggregatePayload } from '../actions/jahia.actions';
import { JahiaQuestionsReponses } from '../models/jahiaquestionsreponses.model';
import { forEach } from '../utils/object.utils';

export interface QR {
  [key: string]: JahiaQuestionsReponses;
}

export interface DataStatusQR {
  [key: string]: DataStatus<JahiaQuestionsReponses>;
}

export class JahiaQuestionsReponsesState {
  questionsReponses: DataStatusQR = {};

  getContrib(contribId: string) {
    const ds = this.questionsReponses[contribId];
    return ds ? ds.data : null;
  }
}

const initialState = new JahiaQuestionsReponsesState();

export function questionsResponsesReducer(state: JahiaQuestionsReponsesState = initialState, action: JahiaAction.Actions) {
  const tester = new ActionTester(action);
  if (tester.isLoading(JahiaAction.JAHIA_QUESTIONS_REPONSES_FETCH)) {
    const acn = action as JahiaAction.JahiaQuestionsReponsesFetch;
    const {contribId} = acn.payload.inputParams;
    const questionsReponsesDs: DataStatus<JahiaQuestionsReponses> = acn.payload.dataStatus;

    return Object.assign(new JahiaQuestionsReponsesState(), {
      questionsReponses: {
        ...state.questionsReponses,
        [contribId]: questionsReponsesDs
      }
    });
  }

  if (action.type === JahiaAction.JAHIA_LOAD_STATE) {
    const acn = action as JahiaAction.JahiaLoadState;
    const questionsReponses = acn.payload.questionsReponses;
    if (questionsReponses) {
      const qrDs = {...state.questionsReponses};
      forEach(questionsReponses, (k, v) => {
        qrDs[k] = {data: v, loading: false, fetched: true};
      });
      return Object.assign(new JahiaQuestionsReponsesState(), {questionsReponses: qrDs});
    }
  }

  if (tester.isStart(JahiaAction.JAHIA_NG_SERVER_AGGREGATE)) {
    const p = action.payload as ApiActionPayload<any, JahiaAggregatePayload>;
    const query = p.inputParams;
    const pathsDomaines = query.pathsDomaines || Object.keys(query.paths);
    const ds: DataStatusQR = {...state.questionsReponses};
    pathsDomaines.forEach(k => {
      let questionsResponsesPath = query.paths[k].questionsResponsesPath;
      if (questionsResponsesPath) {
        forEach(questionsResponsesPath, (k, v) => {
          ds[k] = {data: null, loading: true, fetched: false};
        });
      }
    });
    const s = Object.assign(new JahiaQuestionsReponsesState(), {questionsReponses: ds});
    return s;
  }

  return state;
}
