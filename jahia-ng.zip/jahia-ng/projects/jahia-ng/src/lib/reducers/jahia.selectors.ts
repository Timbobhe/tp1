import { createFeatureSelector, createSelector } from '@ngrx/store';
import { JahiaState } from './_index';


export const selectJahiaFeature = createFeatureSelector<any, JahiaState>('jahia');

export const selectJahiaDico = () => createSelector(
  selectJahiaFeature,
  (state: JahiaState, props: any) => state.jahiaDictionnaires.dictionnaires,
  (state, dicos, props) => dicos[props.dicoId]
);

export const selectJahiaStatus = () => createSelector(
  selectJahiaFeature,
  (state, props) => state.jahiaStatus
);
