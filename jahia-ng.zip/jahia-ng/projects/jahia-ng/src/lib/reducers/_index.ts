import { ActionReducerMap } from '@ngrx/store';
import { JahiaContribsState, reducer as jahiaContribReducer } from './jahia-contribs.reducer';
import { JahiaDictionnairesState, reducer as jahiaDicoReducer } from './jahia-dictionnaires.reducer';
import { JahiaQuestionsReponsesState, questionsResponsesReducer } from './jahia-questions-reponses.reducer';
import { JahiaResourceState, reducer as jahiaRsReducer } from './jahia-resources.reducer';
import { JahiaStatus, jahiaStatusReducer } from './jahia-status.reducer';

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente le State global.
 */
export interface JahiaState {
  jahiaStatus: JahiaStatus;
  jahiaContribs: JahiaContribsState;
  jahiaDictionnaires: JahiaDictionnairesState;
  jahiaResources: JahiaResourceState;
  jahiaQuestionsReponses: JahiaQuestionsReponsesState;
}

/*
 * A chaque ajout de reducer, ce dernier doit etre ajoute a l objet ci dessous qui represente l ensemble des reducers.
 */
export const reducers: ActionReducerMap<JahiaState> = {
  jahiaStatus: jahiaStatusReducer,
  jahiaContribs: jahiaContribReducer,
  jahiaDictionnaires: jahiaDicoReducer,
  jahiaResources: jahiaRsReducer,
  jahiaQuestionsReponses: questionsResponsesReducer
};
