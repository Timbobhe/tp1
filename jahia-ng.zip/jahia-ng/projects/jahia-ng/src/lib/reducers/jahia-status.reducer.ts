import { ActionTester, ApiActionPayload, DataStatus } from '@ag2rlamondiale/redux-api-ng';
import * as JahiaAction from '../actions/jahia.actions';
import { JahiaAggregatePayload } from '../actions/jahia.actions';

export interface DataStatusPaths {
  [key: string]: DataStatus;
}

export class JahiaStatus {
  paths: DataStatusPaths = {};
}

const initialState = new JahiaStatus();


export function jahiaStatusReducer(state: JahiaStatus = initialState, action: JahiaAction.Actions) {
  const tester = new ActionTester(action);

  if (tester.isLoading(JahiaAction.JAHIA_NG_SERVER_AGGREGATE)) {
    const p = action.payload as ApiActionPayload<any, JahiaAggregatePayload>;
    const dataStatus = p.dataStatus;
    const paths: DataStatusPaths = {...state.paths};
    const query = p.inputParams;
    const pathsDomaines = query.pathsDomaines || Object.keys(query.paths);
    pathsDomaines.forEach(k => paths[k] = {...dataStatus, data: 'DATA'});
    return Object.assign(new JahiaStatus(), {paths});
  }

  return state;
}
