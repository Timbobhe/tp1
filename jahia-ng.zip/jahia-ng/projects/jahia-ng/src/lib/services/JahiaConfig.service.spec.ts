/* tslint:disable:no-unused-variable */
import { TestBed } from '@angular/core/testing';
import { JahiaConfig } from '../actions/jahia-config';
import { JahiaConfigService } from './JahiaConfig.service';

describe('Service: JahiaConfig', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        JahiaConfigService,
        { provide: JahiaConfig, useValue: {} }
      ]
    });
  });

  it('should ...', () => {
    const service = TestBed.get(JahiaConfigService);
    expect(service).toBeTruthy();
  });
});
