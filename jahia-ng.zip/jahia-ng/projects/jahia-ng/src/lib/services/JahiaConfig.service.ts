import { Injectable } from '@angular/core';
import { JahiaConfig } from './../actions/jahia-config';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

@Injectable({
  providedIn: 'root'
})
export class JahiaConfigService {

  constructor(
    public readonly config: JahiaConfig,
    public readonly configService: ConfigService) {
    this.config = JahiaConfig.fromJahiaConfigData(config);
    console.log('Jahia Config', this.config);
  }

  getPathsDomaine(domaine: string) {
    return this.config.paths[domaine];
  }

  jahiaEndpoint() {
    return this.configService.config[this.config.apiBase];
  }

  isActiveJahiaNgServer(): boolean {
    return this.configService.config['jahia_ng_server_active'] && !!this.config.apiJahiaNgServer;
  }

}
