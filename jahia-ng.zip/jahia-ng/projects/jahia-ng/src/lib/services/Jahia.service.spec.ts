/* tslint:disable:no-unused-variable */

import { inject, TestBed } from '@angular/core/testing';
import { JahiaService } from './Jahia.service';

describe('Service: JahiaDico', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [JahiaService]
    });
  });

  it('should ...', inject([JahiaService], (service: JahiaService) => {
    expect(service).toBeTruthy();
  }));
});
