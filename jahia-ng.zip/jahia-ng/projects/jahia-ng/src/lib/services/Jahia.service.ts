import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { EMPTY, from, Observable, of } from 'rxjs';
import { catchError, concatMap, filter, map, reduce, scan, switchMap } from 'rxjs/operators';
import {
  ClearJahiaContrib,
  JahiaAggregatePayload,
  JahiaAggregatePrepareAction,
  JahiaConditionEval,
  JahiaConditionsEval,
  JahiaContribFetch,
  JahiaContribPayload,
  JahiaDicoFetch,
  JahiaLoadState,
  JahiaLoadStateRemote,
  JahiaQuestionsReponsesFetch,
  JahiaResourceFetch
} from '../actions/jahia.actions';
import { JahiaQuestionsReponses } from '../models/jahiaquestionsreponses.model';
import { JahiaState } from '../reducers/_index';
import {
  ConditionsRequest,
  ConditionsResponse,
  ContextCondition,
  JahiaConditionPayload
} from '../models/jahiacondition.model';
import { JahiaContrib } from '../models/jahiacontrib.model';
import { JahiaDictionnaire } from '../models/jahiadictionnaire.model';
import { JahiaResource } from '../models/jahiaresource.model';
import { JahiaConfigService } from './JahiaConfig.service';
import { Contributions, DataStatusContributions } from '../reducers/jahia-contribs.reducer';
import { forEach } from '../utils/object.utils';
import { DataStatus, ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { JahiaLoadStatePayload } from '../actions/jahia.transcoders';
import { DataStatusDictionnaires, Dictionnaires } from '../reducers/jahia-dictionnaires.reducer';
import { DataStatusQR, QR } from '../reducers/jahia-questions-reponses.reducer';
import { DataStatusResources, Resources } from '../reducers/jahia-resources.reducer';
import { findAllContents } from '../utils/contrib-parser';


@Injectable({
  providedIn: 'root'
})
export class JahiaService {

  multiEvalDispo = true;

  constructor(private readonly store: Store<JahiaState>,
              private readonly configurer: JahiaConfigService,
              private readonly reduxApi: ReduxApiService) {
  }

  // get multiEvalDispo(): boolean {
  //   return this.configurer.config.apiJahiaMultiEval !== 'jahia_multi_evaluator_endpoint';
  // }

  getDico(dicoId: string): Observable<JahiaDictionnaire> {
    return this.store.select('jahia', 'jahiaDictionnaires', 'dictionnaires', dicoId)
      .pipe(
        map(dico => dico || dicoId),
        switchMap(d => {
          if (typeof d === 'string') {
            this.store.dispatch(new JahiaDicoFetch({title: dicoId}, this.configurer.config));
            return EMPTY;
          }

          if (d.data) {
            return of(JahiaDictionnaire.fromObject(d.data));
          }
          return EMPTY;
        })
      );
  }

  getDicoEntry(dicoId: string, key: string): Observable<{ dico: JahiaDictionnaire, key: string, label: string }> {
    return this.getDico(dicoId).pipe(
      map(d => {
        const dico = JahiaDictionnaire.fromObject(d);
        const label = dico.get(key) || `??? ${key} ???`;
        return {dico, key, label};
      })
    );
  }

  loadState(data: JahiaLoadStatePayload) {
    this.store.dispatch(new JahiaLoadState(data));
  }

  loadStateRemote(endpoint: string = 'jahia_data') {
    this.store.dispatch(this.loadStateRemoteAction(endpoint));
  }

  loadStateRemoteAction(endpoint: string = 'jahia_data') {
    const acn = new JahiaLoadStateRemote(endpoint);
    acn.payload.onSuccess = (data) => this.loadState(data);
    return acn;
  }


  prefetchAll() {
    const contribIds = Object.keys(this.configurer.config.contribsPath || {});
    const questionsResponsesIds = Object.keys(this.configurer.config.questionsResponsesPath || {});
    const dicoIds = Object.keys(this.configurer.config.dictionnariesPath || {});
    const resourceIds = Object.keys(this.configurer.config.resourcesPath || {});

    this.preFetchContrib(contribIds);
    this.preFetchQuestionsResponses(questionsResponsesIds);
    this.preFetchDico(dicoIds);
    this.preFetchResources(resourceIds);
  }

  dumpState(callback?: (data: JahiaLoadStatePayload) => any) {
    this.store.select('jahia').pipe(
      map((state: JahiaState) => {
        return {
          contributions: this.extractDataContribs(state.jahiaContribs.contributions),
          dictionnaires: this.extractDataDicos(state.jahiaDictionnaires.dictionnaires),
          resources: this.extractDataResources(state.jahiaResources.resources),
          questionsReponses: this.extractDataQR(state.jahiaQuestionsReponses.questionsReponses)
        };
      })
    ).subscribe(data => {
      console.log('STORE_JAHIA', data);
      if (callback) {
        callback(data);
      }
    });
  }

  preFetchDico(dicoIds: string[]) {
    dicoIds.forEach(id => this.getDico(id).subscribe());
  }

  preFetchContrib(contribIds: string[]) {
    contribIds.forEach(id => this.getContrib({contribId: id}).subscribe());
  }

  preFetchQuestionsResponses(contribIds: string[]) {
    contribIds.forEach(id => this.getQuestionsReponses(id).subscribe());
  }

  preFetchResources(resourceIds: string[]) {
    resourceIds.forEach(id => this.getResource(id).subscribe());
  }

  prefetchPathsDomaines(...domaines: string[]) {
    if (this.configurer.isActiveJahiaNgServer()) {
      this.prefetchPathsDomainesJahiaNgServer(...domaines);
      return;
    }
    this.prefetchPathsDomainesBasic(...domaines);
  }

  prefetchPathsDomainesBasic(...domaines: string[]) {
    domaines.forEach(domaine => {
      const paths = this.configurer.getPathsDomaine(domaine);
      if (paths.dictionnariesPath) {
        this.preFetchDico(Object.keys(paths.dictionnariesPath));
      }
      if (paths.contribsPath) {
        this.preFetchContrib(Object.keys(paths.contribsPath));
      }

      if (paths.questionsResponsesPath) {
        this.preFetchQuestionsResponses(Object.keys(paths.questionsResponsesPath));
      }

      if (paths.resourcesPath) {
        this.preFetchResources(Object.keys(paths.resourcesPath));
      }
    });
  }

  prefetchPathsDomainesJahiaNgServer(...domaines: string[]) {
    const jahiaConfig = this.configurer.config;
    const query: JahiaAggregatePayload = {
      jahiaEndpoint: this.configurer.jahiaEndpoint(),
      paths: jahiaConfig.paths,
      pathsDomaines: domaines
    };
    this.store.dispatch(new JahiaAggregatePrepareAction({query, jahiaConfig}));
  }

  getContrib(params: JahiaContribPayload, option: { force: boolean } = {force: false}): Observable<JahiaContrib> {
    if (!params.contribId) {
      throw new Error('contribId ne doit pas etre NULL - ' + JSON.stringify(params));
    }
    return this.getContribWithStatus(params, option).pipe(map(c => c.data));
  }

  getContribWithStatus(params: JahiaContribPayload, option: { force: boolean } = {force: false}): Observable<DataStatus<JahiaContrib>> {
    if (!params.contribId) {
      throw new Error('contribId ne doit pas etre NULL - ' + JSON.stringify(params));
    }
    return this.store.select('jahia', 'jahiaContribs', 'contributions', params.contribId)
      .pipe(
        map(c => c as DataStatus<JahiaContrib>),
        map(c => c || params.contribId),
        switchMap(c => {
          if (typeof c === 'string' || option.force) {
            if (option) {
              option.force = false;
            }
            this.store.dispatch(new JahiaContribFetch(params, this.configurer.config));
            return EMPTY;
          }
          return of(c);
        })
      );
  }

  clearContrib(contribId: string) {
    this.store.dispatch(new ClearJahiaContrib(contribId));
  }

  evalCondition(payload: JahiaConditionPayload): Observable<boolean> {
    const acn = new JahiaConditionEval(payload, this.configurer.config);
    return this.reduxApi.execute(acn);
  }

  evalConditions(payload: ConditionsRequest): Observable<ConditionsResponse> {
    const acn = new JahiaConditionsEval(payload, this.configurer.config);
    return this.reduxApi.execute(acn);
  }

  applyCondition(data: string, contexteCondition: ContextCondition): Observable<string> {
    if (this.multiEvalDispo) {
      return this.basicApplyConditions(data, contexteCondition).pipe(
        catchError(err => {
          this.multiEvalDispo = false;
          return this.basicApplyCondition(data, contexteCondition);
        })
      );
    }
    return this.basicApplyCondition(data, contexteCondition);
  }

  basicApplyCondition(data: string, contexteCondition: ContextCondition): Observable<string> {
    if (!data) {
      return EMPTY;
    }
    const parser = new DOMParser();
    const parsedHtml = parser.parseFromString(data, 'text/html');
    const conditions = parsedHtml.querySelectorAll('[condition]');

    const nombreConditions = conditions.length;

    if (nombreConditions === 0) {
      return of(data);
    }

    return from(conditions).pipe(
      concatMap(content => {
        const expression = content.getAttribute('condition');
        return this.evalCondition({expresssion: expression, context: contexteCondition}).pipe(
          map((result: boolean) => {
            return {content, result};
          })
        );
      }),
      map(e => {
        if (e.result) {
          e.content.removeAttribute('condition');
          return e.content.outerHTML;
        } else {
          return '';
        }
      }),
      reduce((x, y) => x + y)
    );
  }

  basicApplyConditions(data: string, contexteCondition: ContextCondition): Observable<string> {
    if (!data) {
      return EMPTY;
    }
    const parser = new DOMParser();
    const parsedHtml = parser.parseFromString(data, 'text/html');
    const conditions = parsedHtml.querySelectorAll('[condition]');

    const nombreConditions = conditions.length;

    if (nombreConditions === 0) {
      return of(data);
    }

    const req: ConditionsRequest = {
      conditions: Array.from(conditions).map(e => {
        return {expresssion: e.getAttribute('condition'), context: contexteCondition};
      })
    };

    return this.evalConditions(req).pipe(
      map(res => {
        let html = '';
        conditions.forEach(e => {
          const expression = e.getAttribute('condition');
          if (res.resultatEvaluation[expression]) {
            e.removeAttribute('condition');
            html += e.outerHTML;
          }
        });

        return html;
      })
    );
  }

  /**
   * Récupère une contribution Jahia et la découpe en sous partis selon
   *
   * @param params la contribution Jahia
   * @param withCondition indique s'il faut appliquer l'evaluation des conditions sur chacune des strings
   * @param splitter une fonction permettant de découper la string de la contrib Jahia en plusieurs strings
   * @param option
   */
  getMultiContribs(params: JahiaContribPayload,
                   withCondition?: ContextCondition,
                   splitter?: (s: string) => string[],
                   option: { force: boolean } = {force: false}): Observable<string[]> {

    const splitContents = splitter || findAllContents;

    const strings$ = this.getContrib(params, option).pipe(
      filter(e => !!e),
      map(e => splitContents(e.contentHtml))
    );


    if (withCondition) {
      return strings$.pipe(
        concatMap(strings => from(strings)),
        concatMap(str => this.applyCondition(str, withCondition).pipe(
          map(r => ({str, res: r}))
        )),
        map(e => e.res),
        filter(e => !!e && e.length > 0),
        scan((acc, value) => [...acc, value], [])
      );
    }

    return strings$;
  }


  getResource(resourceId: string, resourcePath?: string): Observable<JahiaResource> {
    return this.store.select('jahia', 'jahiaResources', 'resources', resourceId)
      .pipe(
        map(rs => rs || resourceId),
        switchMap(rs => {
          if (typeof rs === 'string') {
            const critere = {resourceId, storable: true, resourcePath};
            this.store.dispatch(new JahiaResourceFetch(critere, this.configurer.config));
            return EMPTY;
          }

          if (rs.data) {
            return of(rs.data);
          }
          return EMPTY;
        })
      );
  }

  getQuestionsReponses(contribId: string): Observable<JahiaQuestionsReponses> {
    return this.store
      .select('jahia', 'jahiaQuestionsReponses', 'questionsReponses', contribId)
      .pipe(
        map(qr => qr || contribId),
        switchMap(qr => {
          if (typeof qr === 'string') {
            this.store.dispatch(
              new JahiaQuestionsReponsesFetch(
                {contribId},
                this.configurer.config
              )
            );
            return EMPTY;
          }

          if (qr.data) {
            return of(JahiaQuestionsReponses.fromObject(qr.data));
          }
          return EMPTY;
        })
      );
  }

  private extractDataContribs(contributions: DataStatusContributions): Contributions {
    const res: Contributions = {};
    forEach<DataStatus<JahiaContrib>>(contributions, (k, v) => {
      res[k] = v.data;
    });
    return res;
  }

  private extractDataDicos(dictionnaires: DataStatusDictionnaires): Dictionnaires {
    const res: Dictionnaires = {};
    forEach<DataStatus<JahiaDictionnaire>>(dictionnaires, (k, v) => {
      res[k] = v.data;
    });
    return res;
  }

  private extractDataQR(questionsReponses: DataStatusQR): QR {
    const res: QR = {};
    forEach<DataStatus<JahiaQuestionsReponses>>(questionsReponses, (k, v) => {
      res[k] = v.data;
    });
    return res;
  }

  private extractDataResources(resources: DataStatusResources): Resources {
    const res: Resources = {};
    forEach<DataStatus<JahiaResource>>(resources, (k, v) => {
      res[k] = v.data;
    });
    return res;
  }
}
