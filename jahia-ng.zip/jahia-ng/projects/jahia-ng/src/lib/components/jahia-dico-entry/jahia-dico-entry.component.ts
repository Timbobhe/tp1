import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { JahiaDictionnaire } from '../../models/jahiadictionnaire.model';
import { JahiaService } from '../../services/Jahia.service';
import { Context } from '../../models/context.model';

export interface EventType {
  dico: JahiaDictionnaire;
  key: string;
  label: string;
}

/** Affiche une entrée **key** du dictionnaire Jahia **dicoId** */
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'jahia-dico-entry',
  templateUrl: './jahia-dico-entry.component.html',
  styleUrls: ['./jahia-dico-entry.component.css']
})
export class JahiaDicoEntryComponent implements OnInit, OnChanges {
  @Input() dicoId: string; // Dictionnaire ID
  @Input() key: string; // Entry key

  @Input() modeHtml = false;

  _context: Context | any = null;

  @Output() dicoEntryUpdate = new EventEmitter<EventType>();

  label$: Observable<string>; // Entry value

  constructor(
    private readonly sanitizer: DomSanitizer,
    private readonly jahia: JahiaService) {
  }

  ngOnInit(): void {
  }


  ngOnChanges(changes: SimpleChanges): void {
    let dicoId = this.getDicoId(), key = this.getKey();
    if (changes.hasOwnProperty('dicoId')) {
      dicoId = changes.dicoId.currentValue;
    }
    if (changes.hasOwnProperty('key')) {
      key = changes.key.currentValue;
    }

    if (dicoId && key) {
      this.read(dicoId, key);
    }
  }

  private read(dicoId: string, key: string) {
    this.label$ = this.jahia.getDicoEntry(dicoId, key).pipe(
      map(e => {
        this.dicoEntryUpdate.emit(e);
        return e.label;
      }),
      catchError((err) => {
        throw err;
      })
    );
  }

  get isText() {
    return !this.modeHtml;
  }

  get isHtml() {
    return this.modeHtml;
  }

  getDicoId() {
    return this.dicoId;
  }

  getKey() {
    return this.key;
  }

  get context() {
    return this._context;
  }

  @Input('context')
  set context(ctx: Context | any) {
    if (ctx instanceof Context) {
      this._context = ctx;
    } else {
      this._context = Context.from(ctx);
    }
  }

  applyContext(data: string) {
    if (this.context) {
      return this.context.applyContext(data);
    }
    return data;
  }

}
