import { Component, Input, OnInit } from '@angular/core';
import { JahiaLoadStatePayload } from '../../actions/jahia.transcoders';
import { JahiaService } from '../../services/Jahia.service';

@Component({
  selector: 'jahia-offline-control',
  templateUrl: './jahia-offline-control.component.html',
  styleUrls: ['./jahia-offline-control.component.css']
})
export class JahiaOfflineControlComponent implements OnInit {

  @Input() data: JahiaLoadStatePayload;
  @Input() endpointJahiaData = 'jahia_data';
  @Input() filenameJahiaData = 'jahia-data.json';

  constructor(private readonly jahia: JahiaService) {
  }

  ngOnInit() {
  }

  prefetchAll() {
    this.jahia.prefetchAll();
  }

  loadData() {
    if (this.data) {
      this.jahia.loadState(this.data);
    } else {
      console.warn('Il faut fournir @Input() data pour pouvoir charger les données Jahia');
    }
  }

  loadDataRemote() {
    this.jahia.loadStateRemote(this.endpointJahiaData);
  }

  dump() {
    this.jahia.dumpState();
  }

  download(download: boolean) {
    this.jahia.dumpState(data => {
      this.open(JSON.stringify(data), this.filenameJahiaData, download);
    });
  }

  /**
   * Permet d'ouvrir/télécharger un fichier à partir de son contenu encodé en Base64
   *
   * @param fileContent contenu du fichier en base64
   * @param fileName Nom du fichier
   * @param download true pour télécharger le fichier; false pour l'ouvrir uniquement
   *
   * https://stackoverflow.com/questions/16245767/creating-a-blob-from-a-base64-string-in-javascript
   */
  open(fileContent: string, fileName = 'jahia-data.json', download = false) {
    const type = 'application/json';

    const blob = new Blob([fileContent], {type});
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.target = '_blank';
    link.href = url;
    if (download) {
      fileName = fileName || 'fichier.json';
      if (!fileName.endsWith('.json')) {
        fileName += '.json';
      }
      link.setAttribute('download', fileName);
    }
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  }

}
