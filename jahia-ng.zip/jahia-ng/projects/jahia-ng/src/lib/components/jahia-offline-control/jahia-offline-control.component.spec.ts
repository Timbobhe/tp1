/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { JahiaOfflineControlComponent } from './jahia-offline-control.component';

describe('JahiaOfflineControlComponent', () => {
  let component: JahiaOfflineControlComponent;
  let fixture: ComponentFixture<JahiaOfflineControlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JahiaOfflineControlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JahiaOfflineControlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
