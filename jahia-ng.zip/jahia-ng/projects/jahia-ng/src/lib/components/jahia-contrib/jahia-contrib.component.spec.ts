// tslint:disable:max-line-length
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { HttpTestingController } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { mockData as mockDetailRente } from '../../test/mock/detailRente.mock';
import { mockData } from '../../test/mock/enSavoirPLus.mock';
import { testingModule } from '../../test/test.module';
import { Context } from './../../models/context.model';
import { JahiaContribComponent } from './jahia-contrib.component';

describe('JahiaContribComponent', () => {
  let component: JahiaContribComponent;
  let fixture: ComponentFixture<JahiaContribComponent>;
  let configService: ConfigService;
  let httpTestingController: HttpTestingController;

  const jahiaConfig = {
    contribsPath: {
      'enSavoirPlus': '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/area-simple-content.apiV2.html.ajax?blockId=enSavoirPlus',
      'detailRente': '/sites/aqe/home/retraite-supplementaire/estimer-votre-retraite-supplemen/area-simple-content.apiV2.html.ajax?blockId=detailRente'
    }
  };

  beforeEach(async(() => {
    testingModule({ config: jahiaConfig }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JahiaContribComponent);
    component = fixture.componentInstance;

    httpTestingController = TestBed.get(HttpTestingController);
    configService = TestBed.get(ConfigService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show Contribution enSavoirPlus', async(() => {
    component.contribId = 'enSavoirPlus';
    fixture.detectChanges();

    const url = configService.config.api_contrib_jahia;
    const req = httpTestingController.expectOne(`${url}/sites/aqe/home/retraite-supplementaire/en-savoir-plus/area-simple-content.apiV2.html.ajax?blockId=enSavoirPlus`);
    req.flush(mockData);

    fixture.whenStable().then(() => {
      fixture.detectChanges();
      const compiled = fixture.debugElement;
      expect(compiled.nativeElement.outerHTML).toContain('<h3>Préparer sa retraite</h3>');
    });

  }));


  it('should show Contribution detailRente avec Contexte', async(() => {
    component.contribId = 'detailRente';
    const ctx = new Context();
    const randomValue = Math.random();
    ctx.set('RE/Euro', randomValue);
    component.context = ctx;

    fixture.detectChanges();

    const url = configService.config.api_contrib_jahia;
    const req = httpTestingController.expectOne(`${url}/sites/aqe/home/retraite-supplementaire/estimer-votre-retraite-supplemen/area-simple-content.apiV2.html.ajax?blockId=detailRente`);
    req.flush(mockDetailRente);

    fixture.whenStable().then(() => {
      fixture.detectChanges();
      const compiled = fixture.debugElement;
      expect(compiled.nativeElement.outerHTML).toContain('Cette estimation est réalisée avec projection');
      expect(compiled.nativeElement.outerHTML).toContain(randomValue);
    });

  }));

});
