import {Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges} from '@angular/core';
import {Observable, of} from 'rxjs';
import {catchError, filter, map, mergeMap} from 'rxjs/operators';
import {Context} from '../../models/context.model';
import {ContextCondition} from '../../models/jahiacondition.model';
import {JahiaContrib} from '../../models/jahiacontrib.model';
import {JahiaService} from '../../services/Jahia.service';

/** Affiche une **Contribution Jahia** à partir de son **contribId** */
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'jahia-contrib',
  templateUrl: './jahia-contrib.component.html'
})
export class JahiaContribComponent implements OnChanges, OnDestroy {
  @Input() contribId: string;
  @Input() contribPath: string;
  @Input() autoUpdate = false;

  @Input() avecCondition = false;
  @Input() contexteCondition: ContextCondition = null;

  @Output() contribUpdate = new EventEmitter<JahiaContrib>();

  _context: Context = null;

  data$: Observable<{ contrib: string, loading: boolean }>;

  private subscriptions = [];

  constructor(private readonly jahia: JahiaService) {
  }

  private read(contribId: string, contribPath: string, avecCondition: boolean, newCondition: ContextCondition, context: Context) {
    this.data$ = this.jahia.getContribWithStatus({contribId, contribPath}).pipe(
      filter(x => !!x),
      map(c => {
        if (c.fetched && c.data) {
          this.contribUpdate.emit(c.data);
          return {...c, data: {contentHtml: this.applyContext(c.data.contentHtml, context)}};
        }
        return c;
      }),
      mergeMap(c => {
        try {
          if (!avecCondition) {
            return of(c);
          }
          if (c.fetched && c.data) {
            return this.jahia.applyCondition(c.data.contentHtml, newCondition).pipe(map(s => {
              return {data: {contentHtml: s}, loading: false, fetched: true};
            }));
          }
          return of(c);
        } finally {
        }
      }),
      map(c => {
        return {contrib: c.data ? c.data.contentHtml : null, loading: c.loading};
      }),
      catchError((err) => {
        throw err;
      })
    );
  }


  ngOnChanges(changes: SimpleChanges): void {
    let contribId = this.contribId;
    let contribPath = this.contribPath;
    let newCondition = this.contexteCondition;
    let avecCondition = this.avecCondition;
    let context = this.context;
    if (changes.hasOwnProperty('contribId')) {
      contribId = changes.contribId.currentValue;
    }
    if (changes.hasOwnProperty('contribPath')) {
      contribPath = changes.contribPath.currentValue;
    }
    if (changes.hasOwnProperty('context')) {
      context = changes.context.currentValue;
    }

    /* changes on contexteCondition */
    if (changes.hasOwnProperty('contexteCondition')) {
      newCondition = changes.contexteCondition.currentValue;
    }
    if (changes.hasOwnProperty('avecCondition')) {
      avecCondition = changes.avecCondition.currentValue;
    }

    if (contribId && (!avecCondition || newCondition)) {
      this.read(contribId, contribPath, avecCondition, newCondition, context);
    } else {
      this.data$ = null;
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  get htmlId() {
    return this.contribId ? this.contribId.replace(/\//g, '_') : '';
  }

  @Input('context')
  set context(context: Context | any) {
    if (context instanceof Context) {
      this._context = context;
    } else {
      this._context = Context.from(context);
    }
    if (this.autoUpdate) {
      this._context.eventEmitter.subscribe(this.update.bind(this));
    }
  }

  get context() {
    return this._context;
  }

  update() {
    this.read(this.contribId, this.contribPath, this.avecCondition, this.contexteCondition, this.context);
  }

  applyContext(html: string, context: Context) {
    if (context && html) {
      return context.applyContext(html);
    }
    return html;
  }


}
