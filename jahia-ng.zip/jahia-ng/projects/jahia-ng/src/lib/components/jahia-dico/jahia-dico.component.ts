import { Component, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { EMPTY, Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { JahiaDictionnaire } from '../../models/jahiadictionnaire.model';
import { JahiaService } from './../../services/Jahia.service';

/** Charge un **Dictionnaire Jahia** identifié par son **dicoId** */
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'jahia-dico',
  template: ''
})
export class JahiaDicoComponent implements OnChanges, OnDestroy {
  @Input() title: string; // Dictionnaire title (deprecated)
  @Input() dicoId: string; // Dictionnaire ID

  @Output() dicoUpdate = new EventEmitter<JahiaDictionnaire>();

  dictionnaire$: Observable<JahiaDictionnaire>;
  subscriptions = [];

  constructor(private readonly jahia: JahiaService) { }

  read(dicoId: string) {
    this.unsubscribe();
    const sub = this.jahia.getDico(dicoId)
      .subscribe(dico => {
        this.dicoUpdate.emit(dico);
        this.dictionnaire$ = of(dico);
      });

    this.subscriptions.push(sub);
  }

  ngOnChanges(changes: SimpleChanges): void {
    let dicoId = this.getDicoId();
    if (changes.hasOwnProperty('dicoId')) {
      dicoId = changes.dicoId.currentValue;
    }

    if (dicoId) {
      this.read(dicoId);
    } else {
      this.dictionnaire$ = null;
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe();
  }

  unsubscribe() {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }


  /** Retourne l'entrée **key** du dictionnaire */
  valeur(key: string) {
    if (this.dictionnaire$) {
      return this.dictionnaire$.pipe(map(d => d.get(key)));
    }
    return EMPTY;
  }

  getDicoId() {
    return this.dicoId;
  }
}
