// tslint:disable:max-line-length
import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { HttpTestingController } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { mockData } from '../../test/mock/dico.commonappmessagesdictionnaire.mock';
import { testingModule } from '../../test/test.module';
import { JahiaConfig } from './../../actions/jahia-config';
import { JahiaDicoComponent } from './jahia-dico.component';

describe('JahiaDicoComponent', () => {
  let component: JahiaDicoComponent;
  let fixture: ComponentFixture<JahiaDicoComponent>;

  let configService: ConfigService;
  let httpTestingController: HttpTestingController;

  const jahiaConfig = new JahiaConfig().prepare(config => {
    config.appendDictionnariesPath({ common_app_messages_dictionnaire: '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content/commonappmessagesdictionnaire.full.json' });
    return config;
  });

  beforeEach(async(() => {
    testingModule({ config: jahiaConfig }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JahiaDicoComponent);
    component = fixture.componentInstance;

    httpTestingController = TestBed.get(HttpTestingController);
    configService = TestBed.get(ConfigService);
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should modified title', () => {
    component.dicoId = 'common_app_messages_dictionnaire';
    fixture.detectChanges();
    expect(component.dicoId).toEqual('common_app_messages_dictionnaire');
  });


  it('should get entry', async(() => {
    component.dicoId = 'common_app_messages_dictionnaire';
    fixture.detectChanges();
    const url = configService.config.api_dictionnaire_jahia;
    const req = httpTestingController.expectOne(`${url}/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content/commonappmessagesdictionnaire.full.json`);
    req.flush(mockData);

    fixture.whenStable().then(() => {
      fixture.detectChanges();
      component.valeur('ERROR_MESSAGE_EMPTY_FIELD').subscribe(label => {
        expect(label).toEqual('Obligatoire pour pouvoir signer votre acte en ligne');
      });
    });
  }));

});
