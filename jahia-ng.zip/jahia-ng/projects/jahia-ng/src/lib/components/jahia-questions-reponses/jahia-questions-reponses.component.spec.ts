/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { JahiaQuestionsReponsesComponent } from './jahia-questions-reponses.component';

describe('JahiaQuestionsReponsesComponent', () => {
  let component: JahiaQuestionsReponsesComponent;
  let fixture: ComponentFixture<JahiaQuestionsReponsesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [JahiaQuestionsReponsesComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JahiaQuestionsReponsesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
