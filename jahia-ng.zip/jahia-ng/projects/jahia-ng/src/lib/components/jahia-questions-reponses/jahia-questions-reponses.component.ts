import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges} from '@angular/core';
import { EMPTY, Observable, of } from 'rxjs';
import {catchError, tap} from 'rxjs/operators';
import {Faq, JahiaQuestionsReponses, QuestionReponse, QuestReponse} from '../../models/jahiaquestionsreponses.model';
import {JahiaService} from '../../services/Jahia.service';
import { ContextCondition } from '../../models/jahiacondition.model';

/** Charge un **QuestionsReponses Jahia** identifié par son **contribId** */
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'jahia-questions-reponses',
  templateUrl: './jahia-questions-reponses.component.html',
  styleUrls: ['./jahia-questions-reponses.component.css']
})
export class JahiaQuestionsReponsesComponent implements OnChanges {
  @Input() contribId: string;
  data$: Observable<JahiaQuestionsReponses>;
  loading: boolean;

  @Input() contexteCondition: ContextCondition = null;

  @Output() questionsReponsesUpdate = new EventEmitter<JahiaQuestionsReponses>();
  @Output() onOpenCloseQuestion = new EventEmitter<{ status: 'open' | 'close', qr: QuestReponse }>();

  constructor(private readonly jahia: JahiaService) {
  }

  read(contribId: string) {
    this.loading = true;
    this.data$ = this.jahia.getQuestionsReponses(contribId).pipe(
      tap(x => this.loading = false),
      tap(t => t.faqs.forEach(f => {
        f.show = this.evalCondition(f.condition);
        f.entries.forEach(qr => {
          if (qr.conditionQuest) {
            qr.showQuest = this.evalCondition(qr.conditionQuest);
          } else {
            qr.showQuest = of(true);
          }
        });
      })),
      tap(qr => this.questionsReponsesUpdate.emit(qr)),
      catchError((err) => {
        this.loading = false;
        throw err;
      })
    );
  }

  ngOnChanges(changes: SimpleChanges): void {
    let contribId = this.getContribId();
    if (changes.hasOwnProperty('contribId')) {
      contribId = changes.contribId.currentValue;
    }

    if (contribId) {
      this.read(contribId);
    } else {
      this.data$ = null;
    }
  }

  getContribId() {
    return this.contribId;
  }

  onOpen(qr: QuestReponse) {
    this.onOpenCloseQuestion.emit({qr, status: 'open'});
  }

  onClose(qr: QuestReponse) {
    this.onOpenCloseQuestion.emit({qr, status: 'close'});
  }

  evalCondition(condition: string): Observable<boolean> {
    if (this.contexteCondition == null) {
      return of(true);
    }
    return this.jahia.evalCondition({expresssion: condition, context: this.contexteCondition});
  }
}
