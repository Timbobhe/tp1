import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Store } from '@ngrx/store';
import { JahiaResourceFetch } from '../../actions/jahia.actions';
import { JahiaResource } from '../../models/jahiaresource.model';
import { JahiaState } from '../../reducers/_index';
import { JahiaService } from '../../services/Jahia.service';
import { JahiaConfigService } from '../../services/JahiaConfig.service';
import { catchError } from 'rxjs/operators';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'jahia-resource',
  templateUrl: './jahia-resource.component.html'
})
export class JahiaResourceComponent implements OnInit, OnDestroy {

  @Input() resourceId: string;
  @Input() resourcePath: string;
  @Input() storable: boolean | string = true;

  @Output() resourceUpdate = new EventEmitter<JahiaResource>();

  private _jahiaResource: JahiaResource;
  data: SafeHtml;
  loading: boolean;
  subscriptions = [];

  constructor(private readonly sanitizer: DomSanitizer
    , private readonly store: Store<JahiaState>
    , private readonly configurer: JahiaConfigService,
              private readonly jahia: JahiaService) {
  }

  ngOnInit() {
    if (this.storable === false || this.storable === 'false' || !this.resourceId) {
      const critere = {resourceId: this.resourceId, storable: false, resourcePath: this.resourcePath};
      const fetcher = new JahiaResourceFetch(critere, this.configurer.config);
      this.loading = true;
      fetcher.payload.onSuccess = (rs: JahiaResource) => this.jahiaResource = rs;
      fetcher.payload.onTerminate = () => this.loading = false;
      this.store.dispatch(fetcher);
      return;
    }

    this.loading = true;
    const sub = this.jahia.getResource(this.resourceId)
      .pipe(
        catchError((err) => {
          this.loading = false;
          throw err;
        })
      )
      .subscribe(rs => this.jahiaResource = rs);

    this.subscriptions.push(sub);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  set jahiaResource(rs: JahiaResource) {
    try {
      this._jahiaResource = rs;
      if (this._jahiaResource) {
        this.data = this.sanitizer.bypassSecurityTrustHtml(this._jahiaResource.content);
        this.resourceUpdate.emit(rs);
      }
    } finally {
      this.loading = false;
    }
  }

  get jahiaResource() {
    return this._jahiaResource;
  }

  get htmlId() {
    if (this.resourceId) {
      return this.resourceId.replace(/\//g, '_');
    }
    return this.resourcePath.replace(/\//g, '_');
  }

}
