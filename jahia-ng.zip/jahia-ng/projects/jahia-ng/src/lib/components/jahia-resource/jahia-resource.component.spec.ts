/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { JahiaResourceComponent } from './jahia-resource.component';

describe('JahiaResourceComponent', () => {
  let component: JahiaResourceComponent;
  let fixture: ComponentFixture<JahiaResourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JahiaResourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JahiaResourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
