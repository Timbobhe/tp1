import { BackendService, ConfigService } from '@ag2rlamondiale/metis-ng';
import * as Api from '@ag2rlamondiale/redux-api-ng';
import { API_SUCCESS, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { distinct, filter, map, mergeMap, switchMap, take } from 'rxjs/operators';
import {
  JAHIA_CONTRIB_FETCH_ITEM,
  JAHIA_DICTIONNAIRE_FETCH_DICO,
  JAHIA_LOAD_STATE_REMOTE,
  JAHIA_NG_SERVER_AGGREGATE,
  JAHIA_NG_SERVER_AGGREGATE_PREPARE,
  JAHIA_QUESTIONS_REPONSES_FETCH,
  JAHIA_RESOURCE_FETCH,
  JahiaAggregateAction,
  JahiaAggregatePrepareAction,
  JahiaLoadState
} from '../actions/jahia.actions';
import { JahiaService } from './../services/Jahia.service';
import { JahiaStatus } from '../reducers/jahia-status.reducer';

@Injectable({
  providedIn: 'root'
})
export class JahiaEffects {
  constructor(
    private readonly actions$: Actions,
    private readonly apiEffects: Api.ApiEffects,
    private readonly httpService: HttpClient,
    private readonly store: Store<any>,
    private readonly backendService: BackendService,
    private readonly configService: ConfigService,
    private readonly jahia: JahiaService) {
  }

  @Effect({dispatch: true})
  fetchDico$ = this.actions$.pipe(
    ofType(JAHIA_DICTIONNAIRE_FETCH_DICO),
    distinct(
      (action: any) => action.distinctKey,
      this.apiEffects.selectApiEnd()
    ),
    mergeMap(action => this.apiEffects.executeApi(action))
  );


  @Effect({dispatch: true})
  loadStateRemote$ = this.actions$.pipe(
    ofType(JAHIA_LOAD_STATE_REMOTE),
    switchMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  fetchContrib$ = this.actions$.pipe(
    ofType(JAHIA_CONTRIB_FETCH_ITEM),
    distinct(
      (action: any) => action.distinctKey,
      this.apiEffects.selectApiEnd()
    ),
    mergeMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  fetchResource$ = this.actions$.pipe(
    ofType(JAHIA_RESOURCE_FETCH),
    distinct(
      (action: any) => action.distinctKey,
      this.apiEffects.selectApiEnd()
    ),
    mergeMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  fetchQuestionsReponses$ = this.actions$.pipe(
    ofType(JAHIA_QUESTIONS_REPONSES_FETCH),
    distinct(
      (action: any) => action.distinctKey,
      this.apiEffects.selectApiEnd()
    ),
    mergeMap(action => this.apiEffects.executeApi(action))
  );

  @Effect({dispatch: true})
  fetchAggregateState$ = this.actions$.pipe(
    ofType(API_SUCCESS),
    map(a => (a as ApiAction).payload),
    filter(p => p.label === JAHIA_NG_SERVER_AGGREGATE),
    map(p => new JahiaLoadState(p.data))
  );

  @Effect({dispatch: true})
  prepareFetchAggregateState$ = this.actions$.pipe(
    ofType(JAHIA_NG_SERVER_AGGREGATE_PREPARE),
    map(a => a as JahiaAggregatePrepareAction),
    switchMap(a => this.store.select('jahia', 'jahiaStatus').pipe(
      take(1),
      map((jahiaStatus: JahiaStatus) => {
          const query = a.payload.query;
          const jahiaConfig = a.payload.jahiaConfig;

          const pathDomaines = query.pathsDomaines || Object.keys(query.paths);
          const filtered = pathDomaines.filter(e => !jahiaStatus.paths[e]);
          if (filtered.length === 0) {
            return {type: 'NOOP'};
          }
          query.pathsDomaines = filtered;

          return new JahiaAggregateAction(query, jahiaConfig);
        }
      ))
    )
  );

}
