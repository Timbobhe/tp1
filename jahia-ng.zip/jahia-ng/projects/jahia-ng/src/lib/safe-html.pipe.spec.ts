/* tslint:disable:no-unused-variable */
import { SafeHtmlPipe } from './safe-html.pipe';

describe('Pipe: SafeDatae', () => {
  it('create an instance', () => {
    const pipe = new SafeHtmlPipe(null);
    expect(pipe).toBeTruthy();
  });
});
