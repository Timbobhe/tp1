import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { JahiaDictionnaire, JahiaDictionnaireData } from '../models/jahiadictionnaire.model';
import {
  Faq,
  JahiaBasicQuestionsReponses,
  JahiaQuestionsReponses,
  JahiaQuestionsReponsesData, QuestReponse
} from '../models/jahiaquestionsreponses.model';
import { JahiaContrib } from '../models/jahiacontrib.model';
import { JahiaResource } from '../models/jahiaresource.model';
import { decodeHTMLEntities } from '../utils/decoder-html';
import { JahiaConfig } from './jahia-config';
import { forEach } from '../utils/object.utils';

export class JahiaLoadStatePayload {
  contributions?: { [key: string]: JahiaContrib };
  dictionnaires?: { [key: string]: JahiaDictionnaireData };
  resources?: { [key: string]: JahiaResource };
  questionsReponses?: { [key: string]: JahiaQuestionsReponsesData };
}

export const transcoderDico = (object: JahiaDictionnaireData, dicoId: string = null): JahiaDictionnaire => {
  if (!object) {
    return null;
  }

  const res = new JahiaDictionnaire();
  res.title = dicoId || object.title;
  const entries = object['entries'] || {};
  for (const key in entries) {
    if (entries.hasOwnProperty(key)) {
      const value = entries[key];
      const cleanValue = decodeHTMLEntities(value);
      res.add(key, cleanValue);
    }
  }

  return res;
};


export const transcoderContrib = (data: string, contribId: string, jahiaConfig: JahiaConfig, configService: ConfigService): JahiaContrib => {
  const htmlToJson = (html: string) => {
    return {contentHtml: html, contribId};
  };

  if (jahiaConfig.cleanerContentHtml) {
    const cleaner = (data: any, configService: ConfigService) =>
      jahiaConfig.cleanerContentHtml(
        data,
        jahiaConfig,
        configService
      );
    return htmlToJson(cleaner(data, configService));
  }

  return htmlToJson(data);
};


export const transcoderResource = (data: string, id: string, path: string): JahiaResource => {
  return {
    content: data,
    id,
    path
  };
};


/**
 * L'API V2 retourne un JSON : {"title":"CHOISIR UN TYPE DE VERSEMENT: DEDUCTIBLE OU NON ?","entries":{"question1":"reponse1"}}
 * @param data retourné par l'API
 * @returns JahiaQuestionsReponses
 */
const htmlToQuestionsReponses = (data: string): JahiaQuestionsReponses => {
  if (!data) {
    return null;
  }

  const res = new JahiaQuestionsReponses();
  const parser = new DOMParser();
  const parsedHtml = parser.parseFromString(data, 'text/html');

  const lesFaqs = parsedHtml.querySelectorAll('.contentFaq > .content');
  for (let i = 0; i < lesFaqs.length; i++) {
    const f = lesFaqs[i];
    const faq = new Faq();
    // Recuperation du< titre de la Faq
    faq.title = f.querySelector('div > h3').innerHTML;
    // Recuperation de la condition d'affichage de la faq
    faq.condition = f.getAttribute('condition');
    const questionsReponses = f.querySelectorAll('.question');
    for (let j = 0; j < questionsReponses.length; j++) {
      const questRep = new QuestReponse();
      const e = questionsReponses[j];
      questRep.conditionQuest = e.getAttribute('condition');
      questRep.question = e.querySelector('.question-title > h4').innerHTML;
      questRep.reponse = e.querySelector('.question-content').innerHTML;
      faq.add(questRep);
    }
    res.add(faq);
  }
  return res;
};

export const transcoderQuestionsReponses = (data: string, jahiaConfig: JahiaConfig, configService: ConfigService): JahiaQuestionsReponses => {

  if (jahiaConfig.cleanerContentHtml) {
    const cleaner = (data: any, configService: ConfigService) =>
      jahiaConfig.cleanerContentHtml(
        data,
        jahiaConfig,
        configService
      );
    return htmlToQuestionsReponses(cleaner(data, configService));
  }

  return htmlToQuestionsReponses(data);
};


export class JahiaAggregateState {
  contributions?: { [key: string]: JahiaContrib };
  dictionnaires?: { [key: string]: JahiaDictionnaireData };
  resources?: { [key: string]: JahiaResource };
  questionsReponses?: { [key: string]: JahiaBasicQuestionsReponses };
}

export const transcoderJahiaAggregateState = (data: JahiaAggregateState, jahiaConfig: JahiaConfig, configService: ConfigService): JahiaLoadStatePayload => {
  const res = new JahiaLoadStatePayload();
  res.contributions = {};
  forEach(data.contributions, (k, v: JahiaContrib) => {
    res.contributions[k] = transcoderContrib(v.contentHtml, v.contribId, jahiaConfig, configService);
  });

  res.dictionnaires = {};
  forEach(data.dictionnaires, (k, v: JahiaDictionnaireData) => {
    res.dictionnaires[k] = transcoderDico(v);
  });

  res.resources = {};
  forEach(data.resources, (k, v: JahiaResource) => {
    res.resources[k] = transcoderResource(v.content, v.id, v.path);
  });

  res.questionsReponses = {};
  forEach(data.questionsReponses, (k, v: JahiaBasicQuestionsReponses) => {
    res.questionsReponses[k] = transcoderQuestionsReponses(v.content, jahiaConfig, configService);
  });


  return res;
};
