import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Actions as ApiActions, ApiAction, LEVEL_SEVERITY_MINOR } from '@ag2rlamondiale/redux-api-ng';
import { Action } from '@ngrx/store';
import { ConditionsRequest, ConditionsResponse, JahiaConditionPayload } from '../models/jahiacondition.model';
import { JahiaContrib } from '../models/jahiacontrib.model';
import { JahiaDictionnaire } from '../models/jahiadictionnaire.model';
import { JahiaQuestionsReponses } from '../models/jahiaquestionsreponses.model';
import { JahiaResource } from './../models/jahiaresource.model';
import { JahiaConfig, JahiaConfigPathDomaineData } from './jahia-config';
import {
  JahiaAggregateState,
  JahiaLoadStatePayload,
  transcoderContrib,
  transcoderDico,
  transcoderJahiaAggregateState,
  transcoderQuestionsReponses,
  transcoderResource
} from './jahia.transcoders';

export const JAHIA_CONTRIB_FETCH_ITEM = 'JAHIA_CONTRIB_FETCH_ITEM';
export const JAHIA_DICTIONNAIRE_FETCH_DICO = 'JAHIA_DICTIONNAIRE_FETCH_DICO';
export const JAHIA_RESOURCE_FETCH = 'JAHIA_RESOURCE_FETCH';
export const JAHIA_QUESTIONS_REPONSES_FETCH = 'JAHIA_QUESTIONS_REPONSES_FETCH';
export const JAHIA_CONDITION_EVAL = 'JAHIA_CONDITION_EVAL';
export const JAHIA_CONDITIONS_EVAL = 'JAHIA_CONDITIONS_EVAL';
export const CLEAR_JAHIA_CONTRIB = 'CLEAR_JAHIA_CONTRIB';
export const JAHIA_NG_SERVER_AGGREGATE = 'JAHIA_NG_SERVER_AGGREGATE';
export const JAHIA_NG_SERVER_AGGREGATE_PREPARE = 'JAHIA_NG_SERVER_AGGREGATE_PREPARE';

export const JAHIA_LOAD_STATE = 'JAHIA_LOAD_STATE';
export const JAHIA_LOAD_STATE_REMOTE = 'JAHIA_LOAD_STATE_REMOTE';


export class JahiaLoadState implements Action {
  type = JAHIA_LOAD_STATE;

  constructor(readonly payload: JahiaLoadStatePayload) {
  }
}

export class JahiaLoadStateRemote extends ApiAction<JahiaLoadStatePayload> {
  type = JAHIA_LOAD_STATE_REMOTE;

  constructor(endpoint: string) {
    super(JAHIA_LOAD_STATE_REMOTE, endpoint, null);
  }
}

export class JahiaDicoPayload {
  title: string;
}

export class JahiaDicoFetch extends ApiAction<JahiaDictionnaire, JahiaDicoPayload> {
  type = JAHIA_DICTIONNAIRE_FETCH_DICO;

  constructor(critere: JahiaDicoPayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_DICTIONNAIRE_FETCH_DICO, jahiaConfig.apiDictionnaire, critere);
    this.payload.url = jahiaConfig.getDicoPath(critere.title);
    this.payload.transcoder = data => transcoderDico(data, this.payload.inputParams.title);
  }

  get distinctKey() {
    return this.payload.inputParams.title;
  }
}

export class JahiaContribPayload {
  contribId: string;
  contribPath?: string;
}

export class JahiaContribFetch extends ApiAction<JahiaContrib, JahiaContribPayload> {
  type = JAHIA_CONTRIB_FETCH_ITEM;

  constructor(critere: JahiaContribPayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_CONTRIB_FETCH_ITEM, jahiaConfig.apiContrib, critere);
    this.payload.url = critere.contribPath || jahiaConfig.getContribPath(critere.contribId);

    this.payload.responseType = 'text';
    const contribId = this.payload.inputParams.contribId;
    this.payload.transcoder = (data: any, configService: ConfigService) => transcoderContrib(data, contribId, jahiaConfig, configService);
  }

  get distinctKey() {
    return this.payload.inputParams.contribId;
  }
}


export class JahiaResourcePayload {
  resourceId: string;
  resourcePath?: string;
  storable = true;
}

export class JahiaResourceFetch extends ApiAction<JahiaResource, JahiaResourcePayload> {
  type = JAHIA_RESOURCE_FETCH;

  constructor(critere: JahiaResourcePayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_RESOURCE_FETCH, jahiaConfig.jahiaFiles, critere);
    this.payload.url =
      critere.resourcePath || jahiaConfig.getResourcePath(critere.resourceId);
    this.payload.responseType = 'text';
    this.payload.transcoder = (data) => transcoderResource(data, this.payload.inputParams.resourceId, this.payload.url);
  }

  get distinctKey() {
    if (this.payload.inputParams.storable) {
      return this.payload.inputParams.resourceId;
    }
    return Math.random();
  }
}


export class JahiaQuestionsReponsesFetch extends ApiAction<JahiaQuestionsReponses, JahiaContribPayload> {
  type = JAHIA_QUESTIONS_REPONSES_FETCH;

  constructor(critere: JahiaContribPayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_QUESTIONS_REPONSES_FETCH, jahiaConfig.apiContrib, critere);
    this.payload.url = jahiaConfig.getQuestionsResponsesPath(critere.contribId);
    this.payload.responseType = 'text';
    this.payload.transcoder = (data, configService) => transcoderQuestionsReponses(data, jahiaConfig, configService);
  }


  get distinctKey() {
    return this.payload.inputParams.contribId;
  }
}

export class JahiaConditionEval extends ApiAction<boolean, JahiaConditionPayload> {

  constructor(payload: JahiaConditionPayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_CONDITION_EVAL, jahiaConfig.apiJahiaEval, payload);
    this.payload.method = 'POST';
    this.payload.requestData = payload;
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

export class JahiaConditionsEval extends ApiAction<ConditionsResponse, ConditionsRequest> {

  constructor(payload: ConditionsRequest, jahiaConfig: JahiaConfig) {
    super(JAHIA_CONDITIONS_EVAL, jahiaConfig.apiJahiaMultiEval, payload);
    this.payload.method = 'POST';
    this.payload.requestData = payload;
    this.payload.severity = LEVEL_SEVERITY_MINOR;
  }
}

export class ClearJahiaContrib implements Action {
  type = CLEAR_JAHIA_CONTRIB;

  constructor(public payload: string) {
  }
}


export class JahiaAggregatePayload {
  jahiaEndpoint: string;
  paths: JahiaConfigPathDomaineData;
  pathsDomaines?: string[];
}


export class JahiaAggregateAction extends ApiAction<JahiaLoadStatePayload, JahiaAggregatePayload> {
  constructor(query: JahiaAggregatePayload, jahiaConfig: JahiaConfig) {
    super(JAHIA_NG_SERVER_AGGREGATE, jahiaConfig.apiJahiaNgServer, query);
    this.payload.url = '/aggregate';
    this.payload.method = 'POST';
    this.payload.requestData = query;
    this.payload.transcoder = (data: JahiaAggregateState, configService) => transcoderJahiaAggregateState(data, jahiaConfig, configService);
  }
}


export class JahiaAggregatePrepareAction implements Action {
  type = JAHIA_NG_SERVER_AGGREGATE_PREPARE;

  constructor(public readonly payload: { query: JahiaAggregatePayload, jahiaConfig: JahiaConfig }) {
  }
}

export type Actions =
  | JahiaQuestionsReponsesFetch
  | JahiaContribFetch
  | JahiaDicoFetch
  | JahiaResourceFetch
  | JahiaConditionEval
  | JahiaLoadState
  | JahiaAggregatePrepareAction
  | JahiaAggregateAction
  | ApiActions;
