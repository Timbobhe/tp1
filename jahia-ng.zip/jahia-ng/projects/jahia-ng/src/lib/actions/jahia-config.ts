import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { forEach } from '../utils/object.utils';

export interface JahiaConfigPathData {
  contribsPath?: any;
  dictionnariesPath?: any;
  questionsResponsesPath?: any;
  resourcesPath?: any;
}

export interface JahiaConfigPathDomaineData {
  [domain: string]: JahiaConfigPathData;
}

export interface JahiaConfigData extends JahiaConfigPathData {
  cleanerContentHtml?: (
    html: string,
    config: JahiaConfig,
    configService: ConfigService
  ) => string;
  apiBase?: string;
  apiDictionnaire?: string;
  apiContrib?: string;
  jahiaFiles?: string;
  apiJahiaEval?: string;
  apiJahiaMultiEval?: string;

  apiJahiaNgServer?: string;

  paths?: JahiaConfigPathDomaineData;
}

/**
 * Cette classe a pour rôle de contenir la CONF JAHIA :
 * - les chemins vers les Contributions (**contribsPath**)
 * - les chemins vers les dictionnaires (**dictionnariesPath**)
 *
 * - Il est également possible de rensigner la function qui permettra de nettoyer le contenu HTML des Contributions (**cleanerContentHtml**)
 *
 *  - Ainsi que les clés de **ConfigService** pour accèder aux URL des **apiDictionnaire** et **apiContrib** et **jahiaFiles**
 */
export class JahiaConfig implements JahiaConfigData {
  contribsPath?: any = {};
  questionsResponsesPath?: any = {};
  dictionnariesPath?: any = {};
  resourcesPath?: any = {};
  cleanerContentHtml?: (
    html: string,
    config: JahiaConfig,
    configService: ConfigService
  ) => string = cleanContentHtml;
  // tslint:disable-next-line:no-inferrable-types
  apiBase?: string = 'jahia_api_base';

  // tslint:disable-next-line:no-inferrable-types
  apiDictionnaire?: string = 'jahia_api_dictionnaire';

  // tslint:disable-next-line:no-inferrable-types
  apiContrib?: string = 'jahia_api_contrib';
  // tslint:disable-next-line:no-inferrable-types
  jahiaFiles?: string = 'jahia_files';
  // tslint:disable-next-line:no-inferrable-types
  apiJahiaEval?: string = 'jahia_evaluator_endpoint';
  // tslint:disable-next-line:no-inferrable-types
  apiJahiaMultiEval?: string = 'jahia_multi_evaluator_endpoint';

  activeJahiaNgServer?: boolean;
  apiJahiaNgServer?: string;

  paths?: JahiaConfigPathDomaineData = {};

  static fromJahiaConfigData(data: JahiaConfigData) {
    return new JahiaConfig(
      data.contribsPath,
      data.questionsResponsesPath,
      data.dictionnariesPath,
      data.resourcesPath,
      data.cleanerContentHtml,
      data.apiBase,
      data.apiDictionnaire,
      data.apiContrib,
      data.jahiaFiles,
      data.apiJahiaEval,
      data.apiJahiaMultiEval,
      data.paths,
      data.apiJahiaNgServer
    );
  }

  constructor(
    contribsPath: any = {},
    questionsResponsesPath: any = {},
    dictionnariesPath: any = {},
    resourcesPath: any = {},
    cleanerContentHtml = cleanContentHtml,
    apiBase = 'jahia_api_base',
    apiDictionnaire = null,
    apiContrib = null,
    jahiaFiles = null,
    apiJahiaEval = 'jahia_evaluator_endpoint',
    apiJahiaMuliEval = 'jahia_multi_evaluator_endpoint',
    paths: JahiaConfigPathDomaineData = {},
    apiJahiaNgServer = null
  ) {
    if (contribsPath) {
      this.contribsPath = contribsPath;
    }
    if (questionsResponsesPath) {
      this.questionsResponsesPath = questionsResponsesPath;
    }
    if (dictionnariesPath) {
      this.dictionnariesPath = dictionnariesPath;
    }
    if (resourcesPath) {
      this.resourcesPath = resourcesPath;
    }
    if (cleanContentHtml) {
      this.cleanerContentHtml = cleanerContentHtml;
    }

    this.apiBase = apiBase;
    this.apiJahiaEval = apiJahiaEval || this.apiBase;
    this.apiJahiaMultiEval = apiJahiaMuliEval || this.apiBase;
    this.apiDictionnaire = apiDictionnaire || this.apiBase;
    this.apiContrib = apiContrib || this.apiBase;
    this.jahiaFiles = jahiaFiles || this.apiBase;
    this.apiJahiaNgServer = apiJahiaNgServer;

    this.paths = paths || {};
    forEach(this.paths, (domain: string, chemins: JahiaConfigPathData) => {
      this.appender(this.contribsPath, chemins.contribsPath, `depuis le domain: ${domain}`);
      this.appender(this.dictionnariesPath, chemins.dictionnariesPath, `depuis le domain: ${domain}`);
      this.appender(this.questionsResponsesPath, chemins.questionsResponsesPath, `depuis le domain: ${domain}`);
      this.appender(this.resourcesPath, chemins.resourcesPath, `depuis le domain: ${domain}`);
    });
  }

  prepare(func: (config: JahiaConfig) => any) {
    func(this);
    return this;
  }

  appendContribsPath(contribsPath: {}) {
    Object.assign(this.contribsPath, contribsPath);
    return this;
  }

  appendDictionnariesPath(dictionnariesPath: {}) {
    Object.assign(this.dictionnariesPath, dictionnariesPath);
    return this;
  }

  appendResourcesPath(resourcesPath: {}) {
    Object.assign(this.resourcesPath, resourcesPath);
    return this;
  }

  appendQuestionsResponsesPath(questionsResponsesPath: {}) {
    Object.assign(this.questionsResponsesPath, questionsResponsesPath);
    return this;
  }

  appender(target: any, others: any, message = null) {
    forEach(others, (k, v) => {
      if (target.hasOwnProperty[k]) {
        throw new Error(`La clé ${k} a déjà été renseignée (${message})`);
      }
      target[k] = v;
    });
  }

  getContribPath(contribId: string) {
    const path = this.contribsPath[contribId];
    if (!path) {
      throw new Error(`Pas de PATH pour la contribution ID = ${contribId}`);
    }
    return path;
  }

  getQuestionsResponsesPath(contribId: string) {
    const path = this.questionsResponsesPath[contribId];
    if (!path) {
      throw new Error(`Pas de PATH pour la questionsResponses ID = ${contribId}`);
    }
    return path;
  }

  getDicoPath(title: string) {
    const path = this.dictionnariesPath[title];
    if (!path) {
      throw new Error(`Pas de PATH pour le dictionnaire ID = ${title}`);
    }
    return path;
  }

  getResourcePath(resourceId: string) {
    const path = this.resourcesPath[resourceId];
    if (!path) {
      throw new Error(`Pas de PATH pour la resource ID = ${resourceId}`);
    }
    return path;
  }

  append(other: JahiaConfig) {
    if (other.contribsPath) {
      this.appendContribsPath(other.contribsPath);
    }

    if (other.dictionnariesPath) {
      this.appendDictionnariesPath(other.dictionnariesPath);
    }

    if (other.resourcesPath) {
      this.appendResourcesPath(other.resourcesPath);
    }

    if (other.questionsResponsesPath) {
      this.appendQuestionsResponsesPath(other.questionsResponsesPath);
    }

    if (other.cleanerContentHtml) {
      this.cleanerContentHtml = other.cleanerContentHtml;
    }
  }
}

/**
 * Cette fonction permet de "nettoyer" le contenu HTML de la contribution Jahia.
 * C'est la fonction par défaut utilisée dans l'objet **JahiaConfig#cleanerContentHtml**
 *
 * - Suppression des éléments \<jahia:resource\>
 * - Modification des HREF à la mode Angular (href="#Dossier:preparer-sa-retraite" devient href="#/Dossier/preparer-sa-retraite")
 * - Correction des URL des images
 *  => construit une URL absolue à partir de l'URL du serveur des fichiers Jahia accessibles depuis **configService.config.jahia_files**
 *
 * @param contrib la Contribution reçue depuis requête HTTP à nettoyer
 * @param jahiaConfig la configuration permettant d'accèder au paramètre `jahiaFiles` (= pour corriger le HOST des images)
 * @param configService une référence vers la **ConfigService**
 */
export function cleanContentHtml(
  html: string,
  jahiaConfig: JahiaConfig,
  configService: ConfigService): string {
  if (!html) {
    return null;
  }

  // suppression <jahia:resource>
  // transformation lien adapter à Angular (1)
  const href1 = /#(\w.+):(\w.+)/gm;
  // transformation lien adapter à Angular (2)
  const href2 = /#(\w.+):/gm;

  // Correction des url localhost
  const jahia_files_host = configService.config[jahiaConfig.jahiaFiles];
  const defaultHost = /^(https?:)?\/\/localhost(:\d+)?(\/.+)/;

  const parser = new DOMParser();
  const parsedHtml = parser.parseFromString(html, 'text/html');

  const anchors = parsedHtml.getElementsByTagName('a');
  for (let i = 0; i < anchors.length; i++) {
    let tmpHref = anchors[i].href;

    // href="#Dossier:preparer-sa-retraite" devient href="#/Dossier/preparer-sa-retraite"
    tmpHref = tmpHref.replace(href1, '#/$1/$2');

    // href="#Dossier:" devient href="#/Dossier"
    tmpHref = tmpHref.replace(href2, '#/$1');

    // Correction des URL localhost
    tmpHref = tmpHref.replace(defaultHost, `${jahia_files_host}$3`);

    anchors[i].href = tmpHref;
  }

  // Correction des URL des images
  for (let i = 0; i < parsedHtml.images.length; i++) {
    const tmpSrc = parsedHtml.images[i].src.replace(defaultHost, `${jahia_files_host}$3`);
    parsedHtml.images[i].src = tmpSrc;
  }

  return parsedHtml.documentElement.innerHTML;
}
