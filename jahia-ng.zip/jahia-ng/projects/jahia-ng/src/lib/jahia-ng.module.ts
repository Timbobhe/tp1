import { MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { ReduxApiNgModule } from '@ag2rlamondiale/redux-api-ng';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, ModuleWithProviders, NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { AccordionModule } from 'primeng/accordion';
import { JahiaConfig, JahiaConfigData } from './actions/jahia-config';
import { JahiaContribComponent } from './components/jahia-contrib/jahia-contrib.component';
import { JahiaDicoEntryComponent } from './components/jahia-dico-entry/jahia-dico-entry.component';
import { JahiaDicoComponent } from './components/jahia-dico/jahia-dico.component';
import { JahiaOfflineControlComponent } from './components/jahia-offline-control/jahia-offline-control.component';
import { JahiaQuestionsReponsesComponent } from './components/jahia-questions-reponses/jahia-questions-reponses.component';
import { JahiaResourceComponent } from './components/jahia-resource/jahia-resource.component';
import { JahiaEffects } from './effects/jahia.effects';
import { reducers } from './reducers/_index';
import { SafeHtmlPipe } from './safe-html.pipe';

export interface JahiaConfigurer {
  config: JahiaConfigData;
}

@NgModule({
  imports: [
    CommonModule,
    MetisNgModule.forRoot(),
    ReduxApiNgModule,
    EffectsModule.forFeature([JahiaEffects]),
    StoreModule.forFeature('jahia', reducers),
    AccordionModule
  ],
  declarations: [
    JahiaContribComponent,
    JahiaDicoComponent,
    JahiaDicoEntryComponent,
    JahiaResourceComponent,
    JahiaQuestionsReponsesComponent,
    SafeHtmlPipe,
    JahiaOfflineControlComponent,
  ],
  exports: [
    JahiaContribComponent,
    JahiaDicoComponent,
    JahiaDicoEntryComponent,
    JahiaResourceComponent,
    JahiaQuestionsReponsesComponent,
    SafeHtmlPipe,
    JahiaOfflineControlComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: []
})
export class JahiaNgModule {
  static forRoot(configurer: JahiaConfigurer): ModuleWithProviders {
    return {
      ngModule: JahiaNgModule,
      providers: [{ provide: JahiaConfig, useValue: configurer.config }]
    };
  }
}
