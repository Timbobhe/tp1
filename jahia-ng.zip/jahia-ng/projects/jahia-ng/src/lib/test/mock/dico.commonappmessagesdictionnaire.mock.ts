// tslint:disable:quotemark
// tslint:disable:max-line-length
export const mockData = {
  title: 'common_app_messages_dictionnaire',
  entries:
  {
    ERROR_MESSAGE_INPUT_VALIDATION: 'Veuillez vérifier votre saisie.',
    ERROR_MESSAGE_MANDATORY_FIELDS: 'Merci de renseigner les zones obligatoires',
    ERROR_MESSAGE_MANDATORY_FIELD: 'Ce champ est obligatoire',
    LABEL_EMAIL_CONFIRMATION: 'CONFIRMATION COURRIEL',
    LABEL_TELEPHONE_MOBILE: 'TELEPHONE PORTABLE',
    LABEL_EMAIL: 'COURRIEL',
    HEADER_DONNEES_PERSONNELLES: 'VOS DONNEES PERSONNELLES',
    HEADER_MOYENS_PAIEMENT: 'VOS MOYENS DE PAIEMENT',
    HEADER_SIGNATURE_EN_LIGNE: 'SIGNATURE EN LIGNE',
    BUTTON_NEXT_TEXT: 'Suivant',
    BUTTON_PREVIOUS_TEXT: 'Précédent',
    ERROR_MESSAGE_EMPTY_FIELD: 'Obligatoire pour pouvoir signer votre acte en ligne',
    SUPPORT_ETIQUETTE_INFOBULLE_PAR_DEFAUT: 'Ce support est pré-sélectionné',
    SUPPORT_ETIQUETTE_INFOBULLE_RECOMMANDE: 'Ce support est recommandé pour vous',
    AGREMENTS_CONVENTION_PREUVE:
      'Convention de preuves : Agrément 1;Convention de preuves : Agrément 2;Convention de preuves : Agrément 3',
    AGREMENTS_CONVENTION_PREUVE_TITLE_DOC: 'Convention de preuves',
    MESSAGE_VERIFICATION_DONNEES_PERSONNELLES:
      'Merci de vérifier la validité de vos données personnelles ci-dessous. Celles-ci sont nécessaires à la signature électronique de votre acte.',
    ERE_CONTRAT_BLOCAGE:
      'Pour des raisons techniques, l\'accès au contrat est momentanément indisponible',
    ERE_FUNCTION_BLOCAGE:
      'Pour des raisons techniques, l\'accès à cette fonctionnalité est momentanément indisponible',
    ERE_METIER_BLOCAGE:
      'Les conditions de votre contrat ne vous permettent pas d\'accéder à cette fonctionnalité',
    ERREUR_ACCES_CONTRAT:
      'L’accès à votre compte est actuellement impossible, nous mettons tout en œuvre pour le rétablir au plus vite. Merci de vous reconnecter ultérieurement',
    ERE_FUNCTION_UNAVAILABLE_FOR_PARTNER: 'Vous n\'avez pas accès à cette fonctionnalité',
    ERREUR_AUCUN_CONTRAT: 'Vous n\'avez aucun contrat accessible.',
    AGREMENTS_QAD:
      'Résultat du Questionnaire d\'Aide à la Décision : Agrément 1;Résultat du Questionnaire d\'Aide à la Décision : Agrément 2;Résultat du Questionnaire d\'Aide à la Décision : Agrément 3',
    AGREMENTS_QAD_TITLE_DOC: 'Résultat du Questionnaire d\'Aide à la Décision',
    ERREUR_MAINTENANCE_PARTENAIRE:
      'En raison de maintenance technique, cette fonctionnalité est temporairement indisponible. Nous vous prions de nous en excuser.',
    LABEL_CIVILITE: 'CIVILITE',
    LABEL_NOM: 'NOM',
    LABEL_PRENOM: 'PRENOM',
    LABEL_NOM_NAISSANCE: 'NOM DE NAISSANCE',
    LABEL_DATE_NAISSANCE: 'DATE DE NAISSANCE',
    LABEL_NUM_SECU_SOCIAL: 'SECURITE SOCIAL',
    LABEL_DEPT_NAISSANCE: 'DEPARTEMENT DE NAISSANCE',
    LABEL_SITUATION_FAMILIALE: 'SITUATION FAMILIALE',
    LABEL_LIEU_NAISSANCE: 'LIEU NAISSANCE',
    POPUP_MESSAGE_ADRESSE_NON_VALIDEE:
      'ATTENTION : Cette adresse est correctement formée, mais elle n’existe peut-être pas.',
    POPUP_MESSAGE_ADRESSE_SAISIE:
      'L\'adresse que vous avez saisie n\'est pas connue dans le référentiel postal. Vous pouvez toutefois la confirmer en cochant cette case.',
    POPUP_ADRESSE_HEADER:
      'Nous avons vérifié la validité de votre adresse postale, vous pouvez choisir une adresse valide ou bien confirmer la saisie de votre adresse.',
    POPUP_ADRESSE_TITLE: 'VALIDATION D\'UNE ADRESSE POSTALE',
    POPUP_ADRESSE_VOTRE_SAISIE: 'VOTRE ADRESSE SAISIE',
    POPUP_ADRESSE_NOS_PROPOSITIONS: 'NOS PROPOSITIONS D\'ADRESSE(S) VALIDE(S)',
    POPUP_MESSAGE_ADRESSE_NON_VALIDEE_4:
      'ATTENTION : L\'adresse proposée est incomplète: pas de numéro dans la voie.',
    LABEL_TOUS_MES_CONTRATS: 'Tous mes contrats',
    LABEL_CHOIX_PAR_CONTRAT: 'Choix par contrat'
  }
};
