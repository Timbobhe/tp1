import { BackendService, ConfigService, EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { config } from './assets/config';
import { envSpecificConfig } from './assets/env-specific';

window['__app_env'] = { config: envSpecificConfig };
window['__env'] = { config: config };

const envSpecific = new EnvSpecificService();
// envSpecific.config = envSpecificConfig;

export const envSpecificProvider = { provide: EnvSpecificService, useValue: envSpecific };

const configService = new ConfigService(envSpecific);
// configService.config = config;
export const configServiceProvider = { provide: ConfigService, useValue: configService };

const backendService = new BackendService(configService);
export const backendServiceProvider = { provide: BackendService, useValue: backendService };

