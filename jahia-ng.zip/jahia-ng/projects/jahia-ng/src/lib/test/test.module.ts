import { ReduxApiNgModule, storeApiLogger } from '@ag2rlamondiale/redux-api-ng';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { EffectsModule } from '@ngrx/effects';
import { ActionReducer, MetaReducer, StoreModule } from '@ngrx/store';
import { JahiaConfigurer, JahiaNgModule } from '../jahia-ng.module';
import { backendServiceProvider, configServiceProvider, envSpecificProvider } from './conf.provider';

export function logger(reducer: ActionReducer<any>): ActionReducer<any> {
  return storeApiLogger(reducer);
}
export const metaReducers: MetaReducer<any>[] = [logger];

export const testingModule = (configurer: JahiaConfigurer) => TestBed.configureTestingModule({
  imports: [
    HttpClientTestingModule,
    StoreModule.forRoot({}, { metaReducers }),
    EffectsModule.forRoot([]),
    ReduxApiNgModule,
    JahiaNgModule.forRoot(configurer)
  ],
  providers: [
    envSpecificProvider,
    configServiceProvider,
    backendServiceProvider
  ]
});
