window.__app_env = {};
window.__app_env.config = {
    backend: {
        endpoints: {
            loginUrl: '/api/secure/redirectToJahia',
            casClientLogout: '/api/logout',
            demoResource: '/api/secure/demo',
            api_contrib_jahia: '/api/jahia',
            api_dictionnaire_jahia: '/cms/render/live/fr',
            api_jahia_eval: '/api/public/jahia/condition-eval',
            api_jahia_multi_eval: '/api/public/jahia/conditions-eval'
        }
    }
};
