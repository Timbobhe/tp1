// tslint:disable:max-line-length

import { JahiaConfig, JahiaConfigPathDomaineData } from '../../projects/jahia-ng/src/lib/actions/jahia-config';
import { ConfigService } from '@ag2rlamondiale/metis-ng';

const PATHS: JahiaConfigPathDomaineData = {
  synthese: {
    contribsPath: {
      /* Conditions */
      SYNTHESE_ENTETE:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=entete&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      CONDITION_BLOC_SIMU_VERSEMENT:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=Blocksimulerversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      CONDITION_LIQUIDATION_RETRAITE:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=liquidationRetraite&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      CONDITION_BLOC_SIMU_VERSEMENT_PERF:
        '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=BlocksimulerversementPerf&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },
  evens: {
    contribsPath: {
      ERE_BIA:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_bia&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      ERE_CONF:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_conf&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      ERE_PND_3:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_3&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      ERE_PND_1:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_pnd_1&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      ERE_VDPP:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_vdpp&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
      ERE_INFO:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content.apiV2.html.ajax?blockId=contenu_ere_info&typeUrlResource=absolute&removeJS&removeCSS&removeComments',
    },

    dictionnariesPath: {
      eventDictionnaireDeLibelles:
        '/sites/aqe/home/retraite-supplementaire/evenements/area-simple-content/eventdictionnairedelibelles.apiDico.html.ajax',
    }
  },

  nonClasse: {
    contribsPath: {
      'ensavoirplus/header':
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/area-simple-content.apiV2.html.ajax?blockId=entete&removeJS&removeCSS&removeComments&typeUrlResource=absolute',
      'ensavoirplus/block':
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/area-simple-content.apiV2.html.ajax?blockId=enSavoirPlus&removeJS&removeCSS&removeComments&typeUrlResource=absolute',


      /* Conditions */

      PHRASE_SAISIE_RECLAMATION: '/sites/aqe/ecrs/nouscontacter/body-content.apiV2.html.ajax?blockId=phrase_saisie_reclamation&typeUrlResource=absolute&removeJS&removeCSS&removeComments'
    },
    dictionnariesPath: {
      titlesDictionnaireDeLibelles:
        '/sites/aqe/home/retraite-supplementaire/area-simple-content/titlesdictionnairedelibelles.apiDico.html.ajax',
      commonAppMessagesDictionnaire:
        '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content/commonappmessagesdictionnaire.apiDico.html.ajax',


      clausestandarddictionnairedelibe:
        '/sites/aqe/home/retraite-supplementaire/demandes-en-ligne/completer-le-bia/clause-beneficiaire/area-simple-content/clausestandarddictionnairedelibe.apiDico.html.ajax',

      dictionnairePrevalidation: '/sites/aqe/ecrs/identitenum/body-content/dictionnaireidentitenum.apiDico.html.ajax',
    },
    resourcesPath: {
      addingHeader:
        '/files/live/sites/aqe/files/contributed/styles/partenaires/html/adding-header.html'
    },
    questionsResponsesPath: {
      /*QuestionsReponses*/
      QUESTIONS_CARACTERE_PERSONNEL:
        '/sites/aqe/home/retraite-supplementaire/mentions-legales/area-simple-content.apiV2.html.ajax?blockId=mentionscnil&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      AIDE_PACTE_VERSEMENT:
        '/sites/aqe/home/retraite-supplementaire/commonappmessages/area-simple-content.apiV2.html.ajax?blockId=aidepacteversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      QUESTIONS_FREQUENTES:
        '/sites/aqe/home/retraite-supplementaire/en-savoir-plus/questions-frequentes/area-simple-content.apiV2.html.ajax?blockId=faqBlock&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
    }
  },

  ensavoirplus: {
    contribsPath: {
      enSavoirPlusBody: '/sites/aqe/ecrs/ensavoirplus/body-content/area-simple-content.apiV2.html.ajax?blockId=enSavoirPlus&typeUrlResource=absolute&removeJS&removeCSS&removeComment',
      'A-G-LEXIQUE': '/sites/aqe/ecrs/ensavoirplus/lexique/body-content.apiV2.html.ajax?blockId=A-G&typeUrlResource=absolute&removeJS&removeCSS'
    }
  }
};

const CONTRIBS_PATH = {};

const QUESTIONS_REPONSES_PATH = {};


const DICTIONNAIRES_TITLES_PATH = {};

const RESOURCES_PATH = {};


/**
 * Cette fonction permet de "nettoyer" le contenu HTML de la contribution Jahia.
 * C'est la fonction par défaut utilisée dans l'objet **JahiaConfig#cleanerContentHtml**
 *
 * - Suppression des éléments \<jahia:resource\>
 * - Modification des HREF à la mode Angular (href="#Dossier:preparer-sa-retraite" devient href="#/Dossier/preparer-sa-retraite")
 * - Correction des URL des images
 *  => construit une URL absolue à partir de l'URL du serveur des fichiers Jahia accessibles depuis **configService.config.jahia_files**
 *
 * @param contrib la Contribution reçue depuis requête HTTP à nettoyer
 * @param jahiaConfig la configuration permettant d'accèder au paramètre `jahiaFiles` (= pour corriger le HOST des images)
 * @param configService une référence vers la **ConfigService**
 */
export function cleanContentHtml(
  html: string,
  jahiaConfig: JahiaConfig,
  configService: ConfigService): string {
  if (!html) {
    return null;
  }

  // suppression <jahia:resource>
  // transformation lien adapter à Angular (1)
  const href1 = /#(\w.+):(\w.+)/gm;
  // transformation lien adapter à Angular (2)
  const href2 = /#(\w.+):/gm;

  // Correction des url localhost
  const jahia_files_host = configService.config[jahiaConfig.jahiaFiles];
  const defaultHost = /^(https?:)?\/\/localhost(:\d+)?(\/.+)/;

  const parser = new DOMParser();
  const parsedHtml = parser.parseFromString(`<body>${html}</body>`, 'text/html');

  const anchors = parsedHtml.getElementsByTagName('a');
  for (let i = 0; i < anchors.length; i++) {
    let tmpHref = anchors[i].href;

    // href="#Dossier:preparer-sa-retraite" devient href="#/Dossier/preparer-sa-retraite"
    tmpHref = tmpHref.replace(href1, '#/$1/$2');

    // href="#Dossier:" devient href="#/Dossier"
    tmpHref = tmpHref.replace(href2, '#/$1');

    // Correction des URL localhost
    tmpHref = tmpHref.replace(defaultHost, `$3`);

    anchors[i].href = tmpHref;
  }

  // Correction des URL des images
  for (let i = 0; i < parsedHtml.images.length; i++) {
    const tmpSrc = parsedHtml.images[i].src.replace(defaultHost, `${jahia_files_host}$3`);
    parsedHtml.images[i].src = tmpSrc;
  }

  return parsedHtml.documentElement.innerHTML;
}


export const jahiaConfig = {
  apiBase: 'jahia_endpoint',
  apiJahiaEval: 'backend/api_jahia_eval',
  apiJahiaMultiEval: 'backend/api_jahia_multi_eval',
  apiJahiaNgServer: 'jahia_ng_server',
  contribsPath: CONTRIBS_PATH,
  questionsResponsesPath: QUESTIONS_REPONSES_PATH,
  dictionnariesPath: DICTIONNAIRES_TITLES_PATH,
  resourcesPath: RESOURCES_PATH,
  paths: PATHS,
  cleanerContentHtml: cleanContentHtml
};
