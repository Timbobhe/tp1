import { Component, OnInit } from '@angular/core';
import { JahiaService } from 'jahia-ng';
import { ContextCondition } from '../../../projects/jahia-ng/src/lib/models/jahiacondition.model';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-scratch-condition-multi',
  templateUrl: './scratch-condition-multi.component.html',
  styleUrls: ['./scratch-condition-multi.component.css']
})
export class ScratchConditionMultiComponent implements OnInit {

  multiContribs$: Observable<string[]>;

  constructor(private jahiaService: JahiaService) {
  }

  ngOnInit() {
    const contexte: ContextCondition = {
      arbitrage_lexique: false
    };
    this.multiContribs$ = this.jahiaService.getMultiContribs({contribId: 'A-G-LEXIQUE'}, contexte).pipe(
      tap(array => console.log('GetMulticontribs', array))
    );
  }

}
