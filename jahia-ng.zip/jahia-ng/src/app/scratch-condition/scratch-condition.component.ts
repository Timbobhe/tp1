import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Component, OnInit } from '@angular/core';
import { ContextCondition } from './../../../projects/jahia-ng/src/lib/models/jahiacondition.model';

@Component({
  selector: 'app-scratch-condition',
  templateUrl: './scratch-condition.component.html',
  styleUrls: ['./scratch-condition.component.css']
})
export class ScratchConditionComponent implements OnInit {

  rg04: ContextCondition = {
    liste_num_contrat: ['RG151887159'],
    simul_rente_autorise: true,
    vif_contrat: true,
    liquidation_retraite: true
  };

  constructor() { }

  ngOnInit() {
  }


  onUpdateContribCondition(contrib) {
    trace(`OnUpdateContribCondition:`, contrib);
  }

  changeContrat(contrat: string) {
    const tab = [];
    tab.push(contrat);
    const simul = this.rg04.simul_rente_autorise;
    const vif = this.rg04.vif_contrat;
    const liquidation = this.rg04.liquidation_retraite;
    this.rg04 = {
      liste_num_contrat: tab,
      simul_rente_autorise: simul,
      vif_contrat: vif,
      liquidation_retraite: liquidation
    };
  }

  changeSimulRente() {
    const simul = this.rg04.simul_rente_autorise;
    const contrat = this.rg04.liste_num_contrat;
    const vif = this.rg04.vif_contrat;
    const liquidation = this.rg04.liquidation_retraite;
    this.rg04 = {
      liste_num_contrat: contrat,
      simul_rente_autorise: !simul,
      vif_contrat: vif,
      liquidation_retraite: liquidation
    };
  }

  changeVif() {
    const simul = this.rg04.simul_rente_autorise;
    const contrat = this.rg04.liste_num_contrat;
    const vif = this.rg04.vif_contrat;
    const liquidation = this.rg04.liquidation_retraite;
    this.rg04 = {
      liste_num_contrat: contrat,
      simul_rente_autorise: simul,
      vif_contrat: !vif,
      liquidation_retraite: liquidation
    };
  }

  changeLiquidation() {
    const simul = this.rg04.simul_rente_autorise;
    const contrat = this.rg04.liste_num_contrat;
    const vif = this.rg04.vif_contrat;
    const liquidation = this.rg04.liquidation_retraite;
    this.rg04 = {
      liste_num_contrat: contrat,
      simul_rente_autorise: simul,
      vif_contrat: vif,
      liquidation_retraite: !liquidation
    };
  }

  clear() {
    this.rg04 = {
      liste_num_contrat: []
    };
  }

  show(): string {
    return JSON.stringify(this.rg04);
  }

}
