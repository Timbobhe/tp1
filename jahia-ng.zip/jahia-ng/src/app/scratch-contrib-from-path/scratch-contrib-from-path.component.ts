import {Component, OnInit} from '@angular/core';

interface Contrib {
  contribId: string;
  contribPath: string;
}

@Component({
  selector: 'app-scratch-contrib-from-path',
  templateUrl: './scratch-contrib-from-path.component.html',
  styleUrls: ['./scratch-contrib-from-path.component.css']
})
export class ScratchContribFromPathComponent implements OnInit {

  contribs: Array<Contrib> = [
    {
      contribId: 'contribA',
      contribPath: 'sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/qad/area-simple-content.apiV2.html.ajax?blockId=qad_code_12692&typeUrlResource=absolute&removeComments'
    },
    {
      contribId: 'contribB',
      contribPath: '/sites/aqe/ecrs/synthese/body-content/area-simple-content.apiV2.html.ajax?blockId=Blocksimulerversement&typeUrlResource=absolute&removeJS&removeCSS&removeComment'
    }
  ];

  currentContrib: Contrib;

  constructor() {
  }

  ngOnInit() {
    this.currentContrib = this.contribs[0];
  }

  changeContrib() {
    for (let contrib of this.contribs) {
      if (this.currentContrib.contribId !== contrib.contribId) {
        this.currentContrib = contrib;
        break;
      }
    }
  }
}
