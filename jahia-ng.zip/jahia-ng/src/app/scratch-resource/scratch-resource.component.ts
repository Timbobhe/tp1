import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scratch-resource',
  templateUrl: './scratch-resource.component.html',
  styleUrls: ['./scratch-resource.component.css']
})
export class ScratchResourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


  onUpdateResource(rs) {
    trace(`onUpdateResource:`, rs);
  }

}
