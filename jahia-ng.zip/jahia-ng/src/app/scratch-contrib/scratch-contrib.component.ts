import {ApiCallerService, trace} from '@ag2rlamondiale/redux-api-ng';
import {Component, OnDestroy, OnInit} from '@angular/core';
import {Context, JAHIA_CONTRIB_FETCH_ITEM} from 'jahia-ng';
import {delay} from 'rxjs/operators';

@Component({
  selector: 'app-scratch-contrib',
  templateUrl: './scratch-contrib.component.html',
  styleUrls: ['./scratch-contrib.component.css']
})
export class ScratchContribComponent implements OnInit, OnDestroy {


  ctx = new Context();

  nbDico = [1, 2, 3, 4];

  entry_keys = ['ERE_TITLES_DEFAULT', 'ERE_TITLES_Dossier', 'ERE_TITLES_Lexique'];
  entry_id = 0;

  contribs = ['ERE_BIA'
    , 'ERE_BIA'
    , 'ERE_CONF'
    , 'ERE_PND_3'
    , 'ERE_PND_1'
    , 'ERE_VDPP'
    , 'ERE_INFO'];

  contrib_id = 0;

  dynaContribId: string; // Export

  entryKey: string; // Export
  dicoId: string; // Export

  intervalsId = [];

  constructor(private readonly apiCaller: ApiCallerService) {
  }

  ngOnInit() {
    this.apiCaller.registerInterceptor(JAHIA_CONTRIB_FETCH_ITEM, (action, apiCaller) => {
      return apiCaller.basicRequest(action).pipe(delay(3000));
    });


    const randomValue = Math.random();
    this.ctx.set('RE/Euro', randomValue);

    this.intervalsId.push(
      setInterval(() => {
        this.entryKey = this.entry_keys[this.entry_id++];
        if (this.entry_id === this.entry_keys.length) {
          this.entry_id = 0;
        }
      }, 5000)
    );

    this.intervalsId.push(
      setInterval(() => {
        this.dynaContribId = this.contribs[this.contrib_id++];
        if (this.contrib_id === this.contribs.length) {
          this.contrib_id = 0;
        }
      }, 5000)
    );

    this.intervalsId.push(
      setInterval(() => {
        if (this.entry_id % 2 === 0) {
          this.dicoId = 'commonAppMessagesDictionnaire';
        } else {
          this.dicoId = null;
        }
      }, 1000)
    );

  }

  ngOnDestroy() {
    this.intervalsId.forEach(id => clearInterval(id));
  }

  getDico() {
    this.nbDico.push(0);
  }

  onUpdateContrib(contrib) {
    trace(`OnUpdateContrib:`, contrib);
  }

}
