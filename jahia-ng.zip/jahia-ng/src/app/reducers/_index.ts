import { storeApiLogger } from '@ag2rlamondiale/redux-api-ng';
import { ActionReducer, MetaReducer } from '@ngrx/store';
import { environment } from '../../environments/environment';

export function logger(reducer: ActionReducer<any>): ActionReducer<any> {
  return storeApiLogger(reducer);
}

export const metaReducers: MetaReducer<any>[] = !environment.production ? [logger] : [];
