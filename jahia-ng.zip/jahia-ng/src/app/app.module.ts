import { GlobalErrorHandler, MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { ReduxApiNgModule } from '@ag2rlamondiale/redux-api-ng';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { JahiaNgModule } from 'jahia-ng';
import { AccordionModule } from 'primeng/accordion';
import { AppComponent } from './app.component';
import { routing } from './app.routes';
import { HttpInterceptorProviders2 } from './interceptors';
import { jahiaConfig } from './jahia.config';
import { metaReducers } from './reducers/_index';
import { ScratchConditionComponent } from './scratch-condition/scratch-condition.component';
import { ScratchContribComponent } from './scratch-contrib/scratch-contrib.component';
import { ScratchDicoComponent } from './scratch-dico/scratch-dico.component';
import { ScratchOfflineComponent } from './scratch-offline/scratch-offline.component';
import { ScratchPrefechComponent } from './scratch-prefech/scratch-prefech.component';
import { ScratchQuestionresponseComponent } from './scratch-questionresponse/scratch-questionresponse.component';
import { ScratchResourceComponent } from './scratch-resource/scratch-resource.component';
import { BackendService } from './services/backend.service';
import { ScratchContribFromPathComponent } from './scratch-contrib-from-path/scratch-contrib-from-path.component';
import { ScratchEnsavoirplusComponent } from './scratch-ensavoirplus/scratch-ensavoirplus.component';
import { ScratchConditionMultiComponent } from './scratch-condition-multi/scratch-condition-multi.component';

@NgModule({
  declarations: [
    AppComponent,
    ScratchDicoComponent,
    ScratchContribComponent,
    ScratchResourceComponent,
    ScratchQuestionresponseComponent,
    ScratchConditionComponent,
    ScratchPrefechComponent,
    ScratchOfflineComponent,
    ScratchContribFromPathComponent,
    ScratchEnsavoirplusComponent,
    ScratchConditionMultiComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    CommonModule,
    MetisNgModule.forRoot(),
    StoreModule.forRoot({}, { metaReducers }),
    EffectsModule.forRoot([]),
    ReduxApiNgModule,
    JahiaNgModule.forRoot({ config: jahiaConfig }),
    routing,
    AccordionModule,
    BrowserAnimationsModule
  ],
  providers: [
    HttpInterceptorProviders2,
    BackendService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
