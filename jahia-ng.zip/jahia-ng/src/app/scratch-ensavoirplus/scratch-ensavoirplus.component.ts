import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scratch-ensavoirplus',
  templateUrl: './scratch-ensavoirplus.component.html',
  styleUrls: ['./scratch-ensavoirplus.component.css']
})
export class ScratchEnsavoirplusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
