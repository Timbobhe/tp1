import { RouterModule, Routes } from '@angular/router';
import { ScratchConditionComponent } from './scratch-condition/scratch-condition.component';
import { ScratchContribComponent } from './scratch-contrib/scratch-contrib.component';
import { ScratchDicoComponent } from './scratch-dico/scratch-dico.component';
import { ScratchOfflineComponent } from './scratch-offline/scratch-offline.component';
import { ScratchPrefechComponent } from './scratch-prefech/scratch-prefech.component';
import { ScratchQuestionresponseComponent } from './scratch-questionresponse/scratch-questionresponse.component';
import { ScratchResourceComponent } from './scratch-resource/scratch-resource.component';
import { ScratchContribFromPathComponent } from './scratch-contrib-from-path/scratch-contrib-from-path.component';
import { ScratchEnsavoirplusComponent } from './scratch-ensavoirplus/scratch-ensavoirplus.component';
import { ScratchConditionMultiComponent } from './scratch-condition-multi/scratch-condition-multi.component';

const ROUTES: Routes = [
  {
    path: '',
    children: [
      {
        path: 'jahia-contrib',
        component: ScratchContribComponent,
      },
      {
        path: 'jahia-contrib-condition',
        component: ScratchConditionComponent,
      },
      {
        path: 'jahia-contrib-condition-multi',
        component: ScratchConditionMultiComponent,
      },
      {
        path: 'jahia-contrib-path',
        component: ScratchContribFromPathComponent,
      },
      {
        path: 'jahia-dico',
        component: ScratchDicoComponent,
      },
      {
        path: 'jahia-prefetch',
        component: ScratchPrefechComponent,
      },
      {
        path: 'jahia-questionreponse',
        component: ScratchQuestionresponseComponent,
      },
      {
        path: 'jahia-resource',
        component: ScratchResourceComponent
      },
      {
        path: 'jahia-offline',
        component: ScratchOfflineComponent
      },
      {
        path: 'jahia-ensavoirplus',
        component: ScratchEnsavoirplusComponent
      },
      {
        path: '**',
        redirectTo: '',
        pathMatch: 'full'
      }
    ]
  }
];

export const routing = RouterModule.forRoot(ROUTES, { useHash: true, scrollPositionRestoration: 'enabled' });
