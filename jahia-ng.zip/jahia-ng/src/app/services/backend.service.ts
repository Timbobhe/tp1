import { BackendService as BackEndProvider, EnvSpecificService } from '@ag2rlamondiale/metis-ng';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable()
export class BackendService {
  readonly backendUrls: any;
  readonly jahiaUrl: string;

  constructor(
    private readonly _http: HttpClient,
    private readonly backendService: BackEndProvider,
    private readonly envSpecificService: EnvSpecificService
  ) {
    this.backendUrls = backendService._backendUrls;
  }

  getDemoResource(): Observable<any> {
    return this._http.get<any>(this.backendUrls.demoResource, { responseType: 'json' });
  }
}
