import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Component, OnInit } from '@angular/core';
import { ContextCondition } from '../../../projects/jahia-ng/src/lib/models/jahiacondition.model';

@Component({
  selector: 'app-scratch-questionresponse',
  templateUrl: './scratch-questionresponse.component.html',
  styleUrls: ['./scratch-questionresponse.component.css']
})
export class ScratchQuestionresponseComponent implements OnInit {

  rg04: ContextCondition = {
    liste_num_contrat: ['RG151236289'],
    simul_rente_autorise: true,
    vif_contrat: true,
    liquidation_retraite: true
  };

  constructor() { }

  ngOnInit() {
  }

  onUpdateQr(qr: any) {
    trace('onUpdateQr', qr);
  }

}
