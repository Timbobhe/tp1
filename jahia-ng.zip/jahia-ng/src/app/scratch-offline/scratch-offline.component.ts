import { Component, OnInit } from '@angular/core';
import { JahiaLoadStatePayload, JahiaService } from 'jahia-ng';
import { DATA } from './data/jahia-data.json';


@Component({
  selector: 'app-scratch-offline',
  templateUrl: './scratch-offline.component.html',
  styleUrls: ['./scratch-offline.component.css']
})
export class ScratchOfflineComponent implements OnInit {

  data: JahiaLoadStatePayload = DATA;

  constructor(private readonly jahia: JahiaService) { }

  ngOnInit() {
  }

}
