export const STATE = {
  contributions: {
    "BENEFICAIRE_ACCORDION_CLOSE_TITLE": {
      "contentHtml": "<head></head><body>Afficher votre clause standard en détail</body>",
      "contribId": "BENEFICAIRE_ACCORDION_CLOSE_TITLE"
    },
    "BENEFICAIRE_ACCORDION_OPEN_TITLE": {
      "contentHtml": "<head></head><body>Masquer votre clause standard</body>",
      "contribIb": "BENEFICAIRE_ACCORDION_OPEN_TITLE"
    },
    "BENEFICIAIRE_ACCORDION_CONTENT": {
      "contentHtml": "<head></head><body><p class=\"font-weight-bold\">votre clause standard</p><div class=\"\\accordion-separator\\\"></div><div>Au décès de l’assuré, le capital sera versé : au conjoint non séparé judiciairement, ou, à défaut au partenaire lié par un PACS au participant, à défaut, le capital est versé par parts égales entre eux :<p>- aux enfants du participant nés ou à naître, vivants ou représentés comme en matière de succession, dont la filiation, y compris adoptive, est légalement établie,</p><p>- à défaut de descendance directe, à ses parents ou à défaut, à ses grands-parents survivants,</p><p>- à défaut de tous les susnommés, aux héritiers.</p></div></body>",
      "contribIb": "BENEFICIAIRE_ACCORDION_CONTENT"
    },
    "BENEFICIAIRE_CONTENT": {
      "contentHtml": "<head></head><body>En cas de décès, l'encours de votre contrat sera versé à des personnes que vous choisissez, on appelle cela la \"clause de désignation de bénéficiaires\".<p>Par défaut, votre contrat prévoit une clause standard.</p></body>",
      "contribIb": "BENEFICIAIRE_CONTENT"
    },
    "CONTENU_ETAPE_BIENVENUE": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Bienvenue !</span></h1><div class=\"introduction no-margin\"><p>Ibi victu recreati et quiete, postquam abierat timor, vicos opulentos adorti equestrium adventu cohortium, quae casu propinquabant, nec resistere planitie porrecta conati digressi sunt retroque concedentes omne iuventutis robur relictum in sedibus acciverunt.</p></div></div></body>",
      "contribIb": "CONTENU_ETAPE_BIENVENUE"
    },
    "CONTENU_ETAPE_COMPARTIMENTS": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Vos 3 types d'épargne</span></h1><div class=\"introduction no-margin\"><p>Cliquez ou faites glisser les onglets pour voir son contenu</p></div></div></body>",
      "contribIb": "CONTENU_ETAPE_COMPARTIMENTS"
    },
    "CONTENU_ETAPE_CONTRATS": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Vos contrats répartis par disponibilité</span></h1><div class=\"introduction no-margin\"><p>Vous pouvez effectuer un versement sur le contrat souhaité</p></div></div></body>",
      "contribIb": "CONTENU_ETAPE_CONTRATS"
    },
    "CONTENU_ETAPE_DOUGHNUT": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Répartition de votre encours en fonction du type d'épargne</span></h1><div class=\"introduction no-margin\"><p>Cliquez sur une icone pour voir le résumé de votre épargne</p></div></div></body>",
      "contribIb": "CONTENU_ETAPE_DOUGHNUT"
    },
    "CONTENU_ETAPE_ENCOURS": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1 class=\"no-margin\"><span class=\"txt-blue\">Résumé de chaque épargne</span></h1><div class=\"introduction no-margin\"></div></div></body>",
      "contribIb": "CONTENU_ETAPE_ENCOURS"
    },
    "CONTENU_ETAPE_SIMULATEUR": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Le bloc du simulateur</span></h1><div class=\"introduction no-margin\"><p>Prudens tamquam leges cervices venerabilis fundamenta sempiterna oppressas et parens leges gentium prudens sempiterna libertatis venerabilis cervices prudens tamquam suis frugi dives patrimonii Caesaribus velut tamquam patrimonii et superbas efferatarum.</p></div></div></body>",
      "contribIb": "CONTENU_ETAPE_SIMULATEUR"
    },
    "CONTENU_ETAPE_VOS_ACTIONS": {
      "contentHtml": "<head></head><body><div class=\"content\"><h1><span class=\"txt-blue\">Vos actions liées à l'épargne, la gestion et la réception de votre retraite</span></h1><div class=\"introduction no-margin\"><p>Déroulez le menu pour réaliser toutes vos actions</p></div></div></body>",
      "contribId": "CONTENU_ETAPE_VOS_ACTIONS"
    },
    "ERE_BIA": {
      "contentHtml": "<head></head><body><p>Vous n'avez pas complété votre Bulletin individuel d'affiliation.</p><p>Vous allez être redirigé afin d'effectuer cette action.</p></body>",
      "contribIb": "ERE_BIA"
    },
    "ERE_CONF": {
      "contentHtml": "<head></head><body><p>Afin de fiabiliser les données présentes dans nos bases et vous garantir ainsi le versement de votre rente supplémentaire à terme, nous vous invitons à confirmer vos données personnelles.</p></body>",
      "contribIb": "ERE_CONF"
    },
    "ERE_INFO": {
      "contentHtml": "<head></head><body><p>↵ Exemple de texte informatif</p></body>",
      "contribIb": "ERE_INFO"
    },
    "ERE_PND_1": {
      "contentHtml": "<head></head><body><p>Votre adresse n'a pas été renseignée.</p><p>Nous vous invitons à confirmer votre adresse.</p></body>",
      "contribIb": "ERE_PND_1"
    },
    "ERE_PND_3": {
      "contentHtml": "<head></head><body><p>Votre adresse n'a pas été renseignée.</p><p>Vous allez être redirigé vers la page de Modification des données personnelles afin d'effectuer cette action.</p></body>",
      "contribIb": "ERE_PND_3"
    },
    "ERE_VDPP": {
      "contentHtml": "<head></head><body><p>Avant toute opération sur vos différents contrats, assurrez-vous de&nbsp;contrôler vos données personnelles et de les modifier si besoin. C'est une nécessité pour&nbsp;fiabiliser les données présentes dans nos bases et qui vous garantira ainsi le versement de votre rente supplémentaire à terme.</p></body>",
      "contribIb": "ERE_VDPP"
    },
    "GESTION_FINANCIERE_ACCORDION_CONTENT": {
      "contentHtml": "<head></head><body><p>La gestion choisie par défaut a un niveau de risque faible mais suffisant pour vous apporter des avantages financiers.</p><p>Cette gestion financière permet de gérer automatiquement la répartition du capital disponible sur votre contrat et de tous vos versements, en fonction de la date prévisionnelle de votre départ à la retraite.</p></body>",
      "contribIb": "GESTION_FINANCIERE_ACCORDION_CONTENT"
    },
    "GESTION_FINANCIERE_ACCORDION_TITLE": {
      "contentHtml": "<head></head><body>Toutes les infos sur la gestion par défaut</body>",
      "contribIb": "GESTION_FINANCIERE_ACCORDION_TITLE"
    },
    "GESTION_FINANCIERE_CONTENT": {
      "contentHtml": "<head></head><body>Votre entreprise a choisi une gestion pilotée par horizon Prudente. La gestion pilotée signifie que vous nous faites confiance pour optimiser votre épargne retraite.</body>",
      "contribIb": "GESTION_FINANCIERE_CONTENT"
    },
    "MODIFICATION_CLAUSE_BENEFICIAIRE": {
      "contentHtml": "<head></head><body>Vous pourrez modifier cette clause à tout moment dans la rubrique \"Gestion des bénéficiaires\"</body>",
      "contribIb": "MODIFICATION_CLAUSE_BENEFICIAIRE"
    },
    "MODIFICATION_CLAUSE_GESTION_FINANCIERE": {
      "contentHtml": "<head></head><body>Vous pourrez modifier cette gestion directement sur votre espace personnel à tout moment.</body>",
      "contribIb": "MODIFICATION_CLAUSE_GESTION_FINANCIERE"
    },
    "bienvenueContent": {
      "contentHtml": "<head></head><body><p>Votre espace client est pensé pour vous faciliter la vie et vous accompagner dans vos démarches grâce à nos aides et nos recommandations personnalisées.</p><p>Commençons dès maintenant à configurer votre espace en 3 étapes afin de mieux vous connaître.</p></body>",
      "contribIb": "bienvenueContent"
    },
    "OBJECTIFS_CONTENT": {
      "contentHtml": "<head></head><body>Choisissez autant d’objectifs que souhaité pour retrouver nos conseils\r\n  personnalisés.</body>",
      "contribIb": "OBJECTIFS_CONTENT"
    },
    "SYNTHESE_ENTETE": {
      "contentHtml": "<head></head><body><div class=\"content\" condition=\"(liste_num_contrat contains $ in ['RGXXXXXXXXX']) contains true\"><h1></h1><div class=\"introduction no-margin\"><p>Bienvenue sur votre espace de retraite supplémentaire. Vous disposez en complément d’un régime PERCO. Un simulateur est mis à disposition sous l’url suivante&nbsp;<a href=\"https://clients.retraite.ag2rlamondiale.fr/extranet/\" target=\"_blank\" title=\"Regime PERCO\">https://clients.retraite.ag2rlamondiale.fr/extranet/</a></p></div></div><div class=\"content\" condition=\"(liste_num_contrat contains $ in ['RGXXXXXXXXXX']) contains true\"><h1></h1><div class=\"introduction no-margin\"><p> Nous vous rappellons que les conditions contractuelles de votre contrat prévoient une liquidation de retraite au plus tôt à l’âge de 65 ans.</p></div></div><div condition=\"(liste_num_contrat contains $ in ['RG152082420','RG152079219','RG152082323','RG151095348']) contains true\"><div style=\"background-color: white; padding: 20px; margin-bottom: 10px;\">La spécificité du régime RVEA ne permet pas la consultation de l’encours et du montant de la rente sur votre espace client.</div></div><div condition=\"(liste_num_contrat contains $ in ['RG151887159']) contains true\"><div style=\"background-color: white; padding: 20px; margin-bottom: 10px;\"><div class=\"ui-g\"><div class=\"ui-g-12 ui-md-4 ui-g-nopad\"><img alt=\"logo TOTAL.PNG\" src=\"http://cdr-dev-jahia7/files/live/sites/aqe/files/contributed/images/logo%20TOTAL.png\" style=\"width: 248px; height: 114px;\"></div><div class=\"ui-g-12 ui-md-8\"><p>Bienvenue sur votre espace client <strong>RECOSUP.</strong></p><span>L'encours constitué jusqu'au 31.12.2018 intègre bien les éventuels Versements Individuels Facultatifs.</span></div></div></div></div><div condition=\"(liste_num_contrat contains $ in ['RG151312337']) contains true\"><div style=\"background-color: white; padding: 20px; margin-bottom: 10px;\">Nous vous rappellons que les conditions contractuelles de votre contrat prévoient une liquidation de retraite au plus tôt à l’âge de 65 ans.</div></div><!--$endblock$entete$--></body>",
      "contribIb": "SYNTHESE_ENTETE"
    }
  }
}
