import {Component, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {Observable} from 'rxjs';
import {JahiaService} from './../../../projects/jahia-ng/src/lib/services/Jahia.service';

@Component({
  selector: 'app-scratch-prefech',
  templateUrl: './scratch-prefech.component.html',
  styleUrls: ['./scratch-prefech.component.css']
})
export class ScratchPrefechComponent implements OnInit {

  store$: Observable<any>;

  constructor(private readonly jahia: JahiaService, private store: Store<any>) {
  }

  ngOnInit() {
    this.store$ = this.store.select('jahia');
  }

  prefetchContrib(contribId: string) {
    this.jahia.preFetchContrib([contribId]);
  }

  prefetchDico(dicoId: string) {
    this.jahia.preFetchDico([dicoId]);
  }

  prefetchPathsDomaines(...domaines: string[]) {
    this.jahia.prefetchPathsDomaines(...domaines);
  }

}
