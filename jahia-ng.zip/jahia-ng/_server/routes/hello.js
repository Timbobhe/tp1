var express = require('express');
var router = express.Router();

router.get('/', function (req, res) {
  let rsApi = [];
  rsApi.push('/hello');
  res.json(rsApi);
});

router.get('/say/:id', function (req, res) {
  if (req.query.boom) {
    throw new Error('boom');
  }

  res.json({message: `Hello ${req.params.id}`});
});

module.exports = router;
