var express = require('express');
var router = express.Router();

var jahiaData = require('./jahia-data/ensavoirplus');

router.get('/', function (req, res) {
    let rsApi = [];
    rsApi.push('/contrib');
    Object.keys(jahiaData.ensavoirplus).forEach(key => {
        rsApi.push(`/contrib/${key}`)
    });
    res.json(rsApi);
});

router.get('/contrib/:id', function (req, res) {
    let contrib = jahiaData.ensavoirplus[req.params.id];
    res.json(Object.assign({}, {code: req.params.id}, contrib));
});

router.post('/condition-eval', function (req, res) {
    const {expresssion, context} = req.body;
    if(context.liste_num_contrat && context.liste_num_contrat.indexOf('RG151887159') >= 0 && expresssion.indexOf('RG151887159') >= 0) {
        res.json(true);
    }
    else if(context.arbitrage_lexique && expresssion === "arbitrage_lexique == true") {
        res.json(true);
    }
    else {
        res.json(false);
    }
});


module.exports = router;
