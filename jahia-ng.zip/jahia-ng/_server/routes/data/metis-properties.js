'use strict';

exports.metisProperties = [
  {
    "roles": ["ROLE_UTBD","ROLE_MKSA","ROLE_UTF1","ROLE_ICON","ROLE_UTND"]
  }
]
