'use strict';

// récupération des contributions en mode "live",
// 1) modification des liens href="#ListeArticles:" en href="#/ListeArticles:"
// 2) modification des url des images src="/files/XXX" en src="http://cdr-dev-jahia7:8080/files/live/XXX"

// http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/fondements.jpg
//                           /files/live/sites/aqe/files/contributed/ImagesArticles/fondements.jpg


exports.ensavoirplus = {
  header: {
    contentHtml: `<div class="content">
    <h1 class="no-margin">
      En savoir plus
    </h1>

    <div class="introduction no-margin">

      </div>

  </div>`
  },
  block: {
    contentHtml: `
    <div class="row-fluid">
	<div class="span6">

<div class="content">


					<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/fondements.jpg" alt="fondements.jpg" title="fondements.jpg">

	<h5 class="txt-green">
		Dossier
	</h5>


			<h3>Le fonctionnement de la retraite</h3>
		<p>
 La retraite par répartition, la retraite par capitalisation ....</p>

			<div class="divider"></div>

	<a class="txt-green pedagoPromotedFolderGA" href="#/ensavoirplus/Dossier:le-fonctionnement-de-la-retraite" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div>



<div class="content">


					<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/gestion%20fi.jpg" alt="gestion fi.jpg" title="gestion fi.jpg">

	<h5 class="txt-green">
		Dossier
	</h5>


			<h3>La gestion de mon compte</h3>
		<p>
 La gestion financière de mon compte, l'importance de la clause bénéficiaire, ...</p>

			<div class="divider"></div>

	<a class="txt-green pedagoPromotedFolderGA" href="#/ensavoirplus/Dossier:la-gestion-de-mon-compte" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div>



<div class="content">


	<h5 class="txt-green">
		Actualité
	</h5>

	<p>
 Information sur la Loi de finance - prélèvement à la source</p>

			<div class="divider"></div>

	<a class="txt-green pedagoPromotedFolderGA" href="#/Article:information--prelevement-a-la-so" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div><div class="content">

   	<h2 class="txt-blue">
   		Mode de gestion financière : la Gestion par Horizon
	</h2>
   	<div class="row-fluid">
   		<div class="span7">

       		<span class="date date-left">
       			21 / 07 / 2017
       		</span>


     	</div>


      	<div class="span5">


<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/dossier/la-gestion-de-mon-compte.html -->
		<a class="txt-green" href="#/ensavoirplus/Dossier:la-gestion-de-mon-compte" title="Voir tous nos articles et dossiers">

				<span class="ico-arrow-left"></span>
			Voir tous nos articles et dossiers
		</a>

    	</div>
   	</div>

   	<div class="divider divider-dotted"></div>


   	<div class="content-detail">
		<p>
 <iframe align="middle" allowfullscreen="" frameborder="0" height="315" scrolling="no" src="https://www.youtube.com/embed/1Y2LxV7vbtE" width="330"></iframe></p>

   	</div>
</div>



<div class="content">


	<h5 class="txt-green">
		Lexique
	</h5>


	<a class="txt-green pedagoPromotedFolderGA" href="#/Lexique:" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div>

</div><div class="span6">
	<div class="content content-detail">
	<h3>Questions du moment</h3>
    <ul>
    	<li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#/QuestionsFrequentes:?id=quid83" title="Qu'est-ce qu'un Plan d'Épargne Retraite Entreprises ?">
						Qu'est-ce qu'un Plan d'Épargne Retraite Entreprises ?
					</a>
				</li><li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#/QuestionsFrequentes:?id=dispo83" title="Mon épargne retraite est-elle à tout moment disponible ?">
						Mon épargne retraite est-elle à tout moment disponible ?
					</a>
				</li><li class="" condition="vif == true &amp;&amp; !((liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true)">

					<a class="txt-grey" href="#/QuestionsFrequentes:?id=versementvif" title="Comment faire un versement individuel et facultatif ?">
						Comment faire un versement individuel et facultatif ?
					</a>
				</li>
    </ul>


	<a class="txt-green" href="#/QuestionsFrequentes:" target="_self" title="Voir toutes les questions fréquentes">
		Voir toutes les questions fréquentes<span class="ico-arrow-right"></span>
	</a>


</div><div class="content">

   	<h2 class="txt-blue">
   		PRÉPARONS MA RETRAITE
	</h2>
   	<div class="row-fluid">
   		<div class="span7">

       		<span class="date date-left">
       			08 / 03 / 2017
       		</span>


     	</div>


      	<div class="span5">


<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">

				<span class="ico-arrow-left"></span>
			Voir tous nos articles et dossiers
		</a>

    	</div>
   	</div>

   	<div class="divider divider-dotted"></div>


   	<div class="content-detail">
		<p>
 <span style="color:#a9a9a9;">Le site communautaire d'AG2R LA MONDIALE</span></p>
<p>
 <iframe align="middle" allowfullscreen="" frameborder="0" height="250" scrolling="no" src="https://www.youtube.com/embed/pzmPsfQFaZw" width="300"></iframe></p>

   	</div>
</div>



<div class="content">


					<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/retraites-10_17564.jpg" alt="retraites-10_17564.jpg" title="retraites-10_17564.jpg">

	<h5 class="txt-green">
		Dossier
	</h5>


			<h3>Préparer sa retraite</h3>
		<p>
 Quand et comment demander le paiement de sa retraite supplémentaire ? quel type d'options de rente choisir ?&nbsp; ...</p>

			<div class="divider"></div>

	<a class="txt-green pedagoPromotedFolderGA" href="#/ensavoirplus/Dossier:preparer-sa-retraite" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#/ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div><div class="content">

   	<h2 class="txt-blue">
   		Les différentes options de rente du PER ENTREPRISES
	</h2>
   	<div class="row-fluid">
   		<div class="span7">

       		<span class="date date-left">
       			03 / 08 / 2017
       		</span>


     	</div>


      	<div class="span5">


<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">

							<span class="ico-arrow-left"></span>
						Voir tous nos articles et dossiers
					</a>


    	</div>
   	</div>

   	<div class="divider divider-dotted"></div>


   	<div class="content-detail">
		<p>
 <iframe allowfullscreen="" frameborder="0" height="315" scrolling="no" src="https://www.youtube.com/embed/X61ZHdt5eEg" width="330"></iframe></p>

   	</div>
</div>

</div>

</div>
    `
  },
  filAriane: {
    contentHtml: `
    <ul id="fil">

            <li>
                <a href="http://esigate-dev/accueil/#accueil:" title="Accueil">
                    Accueil
                    </a>
                    </li>

            <li> &gt; </li>

            <li>
                <a href="http://esigate-dev/accueil/#retraitesupplementaire:" title="Retraite supplémentaire">
                    Retraite supplémentaire
                    </a>
                    </li>

            <li> &gt; </li>

            <li>
                <a class="active" href="#/EnSavoirPlus:" title="En savoir plus">
                    En savoir plus
                    </a>
                    </li>

</ul>
`
  },
  listearticles: {
    contentHtml: `

    <div class="content" >


      <h1 class='no-margin'>
        <span class="txt-blue">Liste</span>
            <br/>
          des articles
      </h1>

      <div class="introduction no-margin">

        </div>

    </div>



    <div class="content">
      <form method="get" name="myForm" id="myForm">

            <h1>NOS ARTICLES ET DOSSIERS</h1>

        </form>
    </div>




    <!-- pagePath = /sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles -->



       <div class="content">
        <div class="move-right">
            <div class="btn-group btn-group-nav-array" data-toggle="buttons-radio">

                         <span class="btn is-active">1</span>

                        <a class="btn" title="Aller &agrave; la page 2" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=7%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">2</a>

                        <a class="btn" title="Aller &agrave; la page 3" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=8%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=11%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">3</a>

                        <a class="btn" title="Aller &agrave; la page 4" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=12%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=15%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">4</a>

                        <a class="btn" title="Aller &agrave; la page 5" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=16%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=19%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">5</a>


                    <a class="btn" title="Aller &agrave; la page suivante" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=7%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">&gt;</a>


                     <a class="btn" title="Aller &agrave; la derni&egrave;re page" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=16%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=20%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">&gt;|</a>

            </div>
        </div>

        </div>

        <div class="clear"></div>


        <!--stop pagination-->




    <div class="content content-detail">


        <span class="date">
           14 / 02 / 2018
        </span>

        <div class="min-divider"></div>


        <h2 class="txt-blue">
          INFORMATION SUR LA LOI DE FINANCES 2017 – PRÉLÈVEMENT À LA SOURCE
        </h2>

      <a class="articleListGA" href="#/Article:information--prelevement-a-la-so" title="Lire la suite">
        Lire la suite
      </a>

     </div>



    <div class="content content-detail">


        <span class="date">
           05 / 01 / 2018
        </span>

        <div class="min-divider"></div>


        <h2 class="txt-blue">
          Marchés financiers : bilan 2017 et perspective 2018
        </h2>
      <p>
     Bilan 2017 : une reflation mondiale men&eacute;e par les volumes plus que par les prix.</p>
    <p>
     Perspectives 2018 : croissance sans inflation.</p>
    <p>
     &nbsp;</p>

          <div class="min-divider"></div>

      <a class="articleListGA" href="#/Article:marches-financiers--bilan-2017-e" title="Lire la suite">
        Lire la suite
      </a>

     </div>



    <div class="content content-detail">


        <span class="date">
           24 / 07 / 2017
        </span>

        <div class="min-divider"></div>


        <h2 class="txt-blue">
          Retraite : la durée de cotisation
        </h2>

      <a class="articleListGA" href="#/Article:retraite--la-duree-de-cotisation" title="Lire la suite">
        Lire la suite
      </a>

     </div>



    <div class="content content-detail">


        <span class="date">
           21 / 07 / 2017
        </span>

        <div class="min-divider"></div>


        <h2 class="txt-blue">
          La retraite : un enjeu de société
        </h2>

      <a class="articleListGA" href="#/Article:la-retraite--un-enjeu-de-societe" title="Lire la suite">
        Lire la suite
      </a>

     </div>

       <div class="content">
        <div class="move-right">
            <div class="btn-group btn-group-nav-array" data-toggle="buttons-radio">

                         <span class="btn is-active">1</span>

                        <a class="btn" title="Aller &agrave; la page 2" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=7%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">2</a>

                        <a class="btn" title="Aller &agrave; la page 3" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=8%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=11%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">3</a>

                        <a class="btn" title="Aller &agrave; la page 4" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=12%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=15%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">4</a>

                        <a class="btn" title="Aller &agrave; la page 5" class="paginationPageUrl" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=16%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=19%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">5</a>


                    <a class="btn" title="Aller &agrave; la page suivante" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=7%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">&gt;</a>


                     <a class="btn" title="Aller &agrave; la derni&egrave;re page" href="#/ListeArticles:begin6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=16%26end6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=20%26pagesize6bcf760b-5a1b-4c8b-a06a-c2e3804f2113=4">&gt;|</a>

            </div>
        </div>

        </div>

        <div class="clear"></div>


        <!--stop pagination-->
    `
  },
  detailRente: {
    contentHtml: `<div>

    <div>
      <p style="font-variant-ligatures: normal; orphans: 2; widows: 2;">
   <span style="color: rgb(57, 25, 9);">Cette estimation est réalisée avec projection, jusqu’à l’âge de départ à la retraite choisi, des futurs rendements anticipés des placements de votre compte et le cas échéant des cotisations et versements à venir selon l' (les) hypothèse (s) suivante (s) :</span></p>
  <ul style="font-variant-ligatures: normal; orphans: 2; widows: 2;">
   <li>
    <span style="color: rgb(57, 25, 9);"><span dir="LTR">La rémunération annuelle de l’épargne en Euro fixée à &nbsp;$RE/Euro$ % brute</span>&nbsp;l’an.</span></li>
   <li>
    <span style="color: rgb(57, 25, 9);"><span dir="LTR">La rémunération annuelle de l’épargne en Unités de Compte fixée à &nbsp;$RE/UC$ % brute</span>&nbsp;l’an.</span></li>
   <li>
    <span style="color: rgb(57, 25, 9);"><span dir="LTR">La croissance de $RCOT$ % l’an du montant des cotisations futures versées par votre employeur.</span></span></li>
   <li>
    <span style="color: rgb(57, 25, 9);"><span dir="LTR">La croissance de $RVP$ % l’an du montant des Versements Individuels et Facultatifs programmés.</span></span></li>
  </ul>

      <div class="divider"></div>
    </div>
  </div>`
  },
  "dossier:le-fonctionnement-de-la-retraite": {
    contentHtml: `
    <div class="content">


    <h1 class="no-margin">
      <span class="txt-blue">dossier</span>
          <br>
        le fonctionnement de la retraite
    </h1>

    <div class="introduction no-margin">

      </div>

  </div>
  <div class="row-fluid">
	<div class="span6">
	<div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/verser.jpg" alt="verser.jpg" title="verser.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Retraite : la durée de cotisation
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:retraite--la-duree-de-cotisation" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/repartition_mev.jpg" alt="repartition_mev.jpg" title="repartition_mev.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	La retraite par répartition
	</h3>
<p>
 Le principe de la retraite par répartition.</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:la-retraite-par-repartition" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Mon droit à l'information retraite
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:mon-droit-a-linformation-retrait" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div>



<div class="content">


	<h5 class="txt-green">
		Lexique
	</h5>


	<a class="txt-green pedagoPromotedFolderGA" href="#Lexique:" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>


</div>

</div><div class="span6">
	<div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/enjeu_ste_mev.jpg" alt="enjeu_ste_mev.jpg" title="enjeu_ste_mev.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	La retraite : un enjeu de société
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:la-retraite--un-enjeu-de-societe" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Réforme des retraites
	</h3>
<p>
 Ce qu'il faut savoir</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:reforme-des-retraites-2013--ce-q" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/signature%20clause%20-1.jpg" alt="signature clause -1.jpg" title="signature clause -1.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Un accord pour les Retraites Complémentaires
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:un-accord-pour-les-retraites-com" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content content-detail">
	<h3>Questions fréquentes</h3>
    <ul>
    	<li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#QuestionsFrequentes:?id=dispo83" title="Mon épargne retraite est-elle à tout moment disponible ?">
						Mon épargne retraite est-elle à tout moment disponible ?
					</a>
				</li>
    </ul>


	<a class="txt-green" href="#QuestionsFrequentes:" target="_self" title="Voir toutes les questions fréquentes">
		Voir toutes les questions fréquentes<span class="ico-arrow-right"></span>
	</a>


</div><div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Guide retraite 2017
	</h3>
<p>
 Le Guide sur la retraite actualisé</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:guide-retraite-2017" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div>

</div>

</div>
    `
  },
  "dossier:la-gestion-de-mon-compte" : {
    contentHtml: `
    <div class="content">


    <h1 class="no-margin">
      <span class="txt-blue">DOSSIER</span>
          <br>
        la gestion de mon compte de retraite supplémentaire
    </h1>

    <div class="introduction no-margin">

      </div>

  </div>
  <div class="row-fluid">
	<div class="span6">
	<div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Bien rédiger sa clause bénéficiaire
	</h3>
<p>
 Renseigner sa clause bénéficiaire est essentiel</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:bien-rediger-sa-clause-beneficia" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/argent-3_20699.jpg" alt="argent-3_20699.jpg" title="argent-3_20699.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	La gestion financière
	</h3>
<p>
 Comprendre la gestion financière</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:la-gestion-financiere" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content content-detail">
	<h3>Questions du moment</h3>
    <ul>
    	<li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#QuestionsFrequentes:?id=dispo83" title="Mon épargne retraite est-elle à tout moment disponible ?">
						Mon épargne retraite est-elle à tout moment disponible ?
					</a>
				</li>
    </ul>


	<a class="txt-green" href="#QuestionsFrequentes:" target="_self" title="Voir toutes les questions fréquentes">
		Voir toutes les questions fréquentes<span class="ico-arrow-right"></span>
	</a>


</div>

</div><div class="span6">
	<div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Mode de gestion financière : la Gestion par Horizon
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Dossier:la-gestion-de-mon-compte" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#ListeArticles:" title="Voir tous nos articles et dossiers">
			Voir tous nos articles et dossiers
				<span class="ico-arrow-right"></span>
				<br>

		</a>
</div><div class="content">

   	<h2 class="txt-blue">
   		Mode de gestion financière : la Gestion par Horizon
	</h2>
   	<div class="row-fluid">
   		<div class="span7">

       		<span class="date date-left">
       			24 / 07 / 2017
       		</span>


     	</div>


      	<div class="span5">


<!-- not empty pageTousArticles = true-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->


		<!-- pageTousArticles = /cms/render/live/fr/sites/aqe/home/retraite-supplementaire/en-savoir-plus/les-articles.html -->
		<a class="txt-green" href="#ListeArticles:" title="Voir tous nos articles et dossiers">

				<span class="ico-arrow-left"></span>
			Voir tous nos articles et dossiers
		</a>

    	</div>
   	</div>

   	<div class="divider divider-dotted"></div>


   	<div class="content-detail">
		<iframe align="middle" allowfullscreen="" frameborder="0" height="315" scrolling="no" src="https://www.youtube.com/embed/1Y2LxV7vbtE" width="330"></iframe><p></p>
   	</div>
</div>

</div>

</div>
<div class="content content-link">


	<a class="content-link" href="#Lexique:" target="_self" title="Accéder au lexique">
		<h3>lexique</h3>

    <div class="row-fluid">
      	<div class="span10">
      		<p>Accéder au lexique</p>
     		</div>
      	<div class="span2">
        	<span class="ico-40 ico-big-arrow-right"></span>
      	</div>
   	</div>
	</a>


</div>
    `
  },

  "dossier:preparer-sa-retraite":{
    contentHtml: `
    <div class="content">


    <h1 class="no-margin">
      <span class="txt-blue">DOSSIER</span>
          <br>
        Préparer sa retraite
    </h1>

    <div class="introduction no-margin">

      </div>

  </div>
  <div class="content">


	<h5 class="txt-green">
		Lexique
	</h5>


	<a class="txt-green pedagoPromotedFolderGA" href="#Lexique:" title="Lire la suite">
		Lire la suite
		<span class=" ico-arrow-right"></span><br>
	</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>



</div>
<div class="row-fluid">
	<div class="span6">
	<div class="content content-detail">
	<h3>Questions du moment</h3>
    <ul>
    	<li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#QuestionsFrequentes:?id=rente" title="Ma rente de retraite supplémentaire est-elle imposable ?">
						Ma rente de retraite supplémentaire est-elle imposable ?
					</a>
				</li><li class="" condition="!( (liste_num_contrat contains $ in ['RG151095348','RG151106794','RG151110868','RG151246377','RG151218732','RG151097482','RG151444257','RG151449495','RG151594510','RG151580348','RG151154227','RG151140162','RG151478304','RG151478401']) contains true )">

					<a class="txt-grey" href="#QuestionsFrequentes:?id=optionRente" title="A quoi servent les options de rente ?">
						A quoi servent les options de rente ?
					</a>
				</li>
    </ul>


	<a class="txt-green" href="#QuestionsFrequentes:" target="_self" title="Voir toutes les questions fréquentes">
		Voir toutes les questions fréquentes<span class="ico-arrow-right"></span>
	</a>


</div><div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/liquider_mev.jpg" alt="liquider_mev.jpg" title="liquider_mev.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Quand et comment liquider ma retraite supplémentaire ?
	</h3>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:quand-et-comment-liquider-votre" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div><div class="content">



<h5 class="txt-green">
	Article
</h5>


    <h3>
    	La garantie décès
	</h3>
<p>
 Fiche pratique</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:a-quoi-penser-a-lapproche-de-la" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>


	<div class="divider"></div>

			<a class="txt-green" href="/files/live/sites/aqe/files/contributed/Entreprises/Fiches%20pratiques/fiche%20pratique%20d%c3%a9c%c3%a8s.pdf" target="_blank" title="Télécharger ">
				<span class="ico-35 ico-pdf-green"></span>
				Télécharger <br>
			</a>
</div>

</div><div class="span6">
	<div class="content">



			<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/rente_simu_mev.jpg" alt="rente_simu_mev.jpg" title="rente_simu_mev.jpg">

<h5 class="txt-green">
	Article
</h5>


    <h3>
    	Quel type de rente choisir ?
	</h3>
<p>
 Personnalisez votre rente avec des options</p>

	<div class="divider"></div>

<a class="txt-green articlePromotedPedagoViewGA" href="#Article:quel-type-doptions-de-rente-choi" title="Lire la suite">
	Lire la suite
	<span class=" ico-arrow-right"></span><br>
</a>



<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>
</div>




<div class="content">


	<a data-titre="Vidéo " href="http://www.youtube.com/embed/pzmPsfQFaZw" rel="shadowbox[Movies];;height=530;width=720;options={continuous:true,flashParams:{allowFullScreen:true,allowscriptaccess:always}}" title="Vidéo ">
		<img src="http://cdr-dev-jahia7:8080/files/live/sites/aqe/files/contributed/ImagesArticles/video_preparer_retraite.jpg" alt="video_preparer_retraite.jpg">
	</a>


		<span class="txt-green">Durée : 1:30</span><br>

	<h5 class="txt-green">
		Vidéo
	</h5>


		<h3>Préparons ma retraite</h3>
	<p>
 Le site communautaire d'AG2R LA MONDIALE</p>

		<div class="divider"></div>


<!-- not empty pageTousArticles = false-->
<!-- not empty articleOrActu && articleOrActu.string == 'actu' = false-->
<!-- not empty renderContext.site.properties['actusListLink'] && not empty renderContext.site.properties['actusListLinkLabel'] = false -->
<!-- not empty renderContext.site.properties['articlesListLink'] && not empty renderContext.site.properties['articlesListLinkLabel'] = true -->



					<a class="txt-green" href="#" title="Voir tous nos articles et dossiers">
						Voir tous nos articles et dossiers
							<span class="ico-arrow-right"></span>
							<br>

					</a>



</div>

</div>

</div>
    `
  }
};
