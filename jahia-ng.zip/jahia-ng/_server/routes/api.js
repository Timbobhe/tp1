'use strict';

var _ = require('underscore');
var USER = require('./data/user').user;
var METIS_PROPERTIES = require('./data/metis-properties').metisProperties;
var CONTEXTUAL_PROPERTIES = require('./data/contextual-properties').contextualProperties;


exports.getMetisUser = function (req, res) {
  return res.status(200).json(USER[0]);
};

exports.getSecurePlace = function (req, res) {
  return res.status(200);
};

exports.logout = function (req, res) {
  return res.status(200).json({});
};

exports.getMetisProperties = function (req, res) {
  return res.status(200).json(METIS_PROPERTIES[0]);
};

exports.getMetisContextualProperties = function (req, res) {
  return res.status(200).json(CONTEXTUAL_PROPERTIES[0]);
};

exports.getServiceA = function (req, res) {
  var msg = getParam(req, 'msg');
  return res.status(200).send("Result A using arg : [" + msg + "]");
};


function getParam(req, param) {
  return req.params[param];
}

function getId(req) {
  var param = getParam(req, 'id');
  return parseInt(param);
}

function createId() {
  return new Date().getTime() + "";
}
