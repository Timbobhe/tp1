# JahiaNg : CHANGELOG

## 2.2.0 (20/11/19)

- Nouveau composant `jahia-resource` permettant d'inclure une ressource (HTML) récupérée depuis les `/files` de Jahia
- Sur les composants `jahia-dico` et `jahia-dico-entry` l'attribut `title` est déprécié au profit de `dicoId` : pour ne pas afficher le **title HTML**
- MAJ de `redux-api-ng` avec la version `2.4.0` (usage de `ActionTester`,...)

___
