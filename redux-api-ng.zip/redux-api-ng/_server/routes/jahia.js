var express = require('express');
var router = express.Router();

var jahiaData = require('./jahia-data/ensavoirplus');

router.get('/', function (req, res) {
  let rsApi = [];
  rsApi.push('/contrib');
  Object.keys(jahiaData.ensavoirplus).forEach(key => {
    rsApi.push(`/contrib/${key}`)
  });
  res.json(rsApi);
});

router.get('/contrib/:id', function (req, res) {
  let contrib = jahiaData.ensavoirplus[req.params.id];
  res.json(Object.assign({}, { code: req.params.id }, contrib));
});

module.exports = router;
