'use strict';

exports.people = [
    {
      "id": 1,
      "lastName": "Gagnon",
      "firstName": "Abdon"
    },
    {
      "id": 2,
      "lastName": "Roy",
      "firstName": "Abdonie"
    },
    {
      "id": 3,
      "lastName": "Cote",
      "firstName": "Abdonise"
    }
  ]
