'use strict';

//require('colors');

var express = require('express'),
  bodyParser = require('body-parser'),
  http = require('http'),
  path = require('path'),
  api = require('./routes/api'),
  cors = require('cors');

var app = express();
var router = express.Router();
var contextName = '/ecrs';

app.set('port', process.env.PORT || 8080);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

//CORS
var corsOptions = {
  origin: true,
  credentials: true,
  methods: ['GET', 'PUT', 'POST', 'DELETE']
};
app.use(cors(corsOptions));

app.get(contextName, function (req, res) {
  res.status(200).send(`Seveur MOCK ${contextName}`);
});

// JSON API
app.get(`${contextName}/api/metis/metis-user`, api.getMetisUser);
app.get(`${contextName}/api/metis/properties`, api.getMetisProperties);
app.get(
  `${contextName}/api/metis/contextual-properties`,
  api.getMetisContextualProperties
);

app.get(`${contextName}/securePlace`, api.getSecurePlace);
app.post(`${contextName}/j_spring_security_logout`, api.logout);

app.get(`${contextName}/api/serviceA/:msg`, api.getServiceA);

// MOCK JAHIA
app.use(`${contextName}/api/jahia`, require('./routes/jahia'));

// HELLO
app.use(`${contextName}/api/hello`, require('./routes/hello'));

app.listen(app.get('port'), function () {
  console.log(
    `✔Express server listening on http://localhost:%d${contextName}`,
    app.get('port')
  );
});
