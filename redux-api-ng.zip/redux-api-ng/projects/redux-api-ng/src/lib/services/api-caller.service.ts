import {Injectable} from '@angular/core';
import {HttpClient, HttpEvent} from '@angular/common/http';
import {BackendService, ConfigService} from '@ag2rlamondiale/metis-ng';
import {Observable} from 'rxjs';
import * as Api from '../actions/api.actions';

export type Interceptor<R = any> = (action: Api.ApiAction<R>, apiCaller: ApiCallerService) => Observable<HttpEvent<R>>;

export interface InterceptorsApiCall {
  [id: string]: Interceptor;
}

@Injectable({
  providedIn: 'root'
})
export class ApiCallerService {

  private interceptors: InterceptorsApiCall = {};
  private globalInterceptor: Interceptor;

  constructor(
    private readonly httpService: HttpClient,
    private readonly backendService: BackendService,
    private readonly configService: ConfigService) {
  }

  request<R = any>(action: Api.ApiAction<R>): Observable<HttpEvent<R>> {
    const id = action.payload.label;
    const interceptor = this.interceptors[id];
    if (interceptor) {
      return interceptor(action, this);
    }

    if (this.globalInterceptor) {
      return this.globalInterceptor(action, this);
    }

    return this.basicRequest(action);
  }

  basicRequest<R = any>(action: Api.ApiAction<R>): Observable<HttpEvent<R>> {
    const req = action.toHttpRequest(this.configService, this.backendService);
    return this.httpService.request(req);
  }

  registerInterceptor<R = any>(actionLabel: string, interceptor: Interceptor<R>) {
    this.interceptors[actionLabel] = interceptor;
  }

  removeInterceptor(actionLabel: string) {
    delete this.interceptors[actionLabel];
  }

  registerGlobalInterceptor<R = any>(interceptor: Interceptor<R>) {
    this.globalInterceptor = interceptor;
  }

  removeGlobalInterceptor() {
    this.globalInterceptor = null;
  }


}
