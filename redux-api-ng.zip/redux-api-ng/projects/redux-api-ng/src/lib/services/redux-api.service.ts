import {Injectable} from '@angular/core';
import {Store} from '@ngrx/store';
import {ApiAction} from '../actions/api.actions';
import {Observable, Subject} from 'rxjs';
import {HttpHeaders} from '@angular/common/http';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReduxApiService {

  constructor(private readonly store: Store<any>) {
  }

  executeAction<R, I>(action: ApiAction<R, I>): Observable<{ data: R, headers?: HttpHeaders }> {
    const obs = new Subject<{ data: R, headers?: HttpHeaders }>();
    action.payload.onSuccess = (data, headers) => obs.next({data, headers});
    action.payload.onTerminate = () => obs.complete();
    action.payload.onFailure = (error: Error) => obs.error(error);
    this.store.dispatch(action);
    return obs;
  }


  execute<R, I>(action: ApiAction<R, I>): Observable<R> {
    return this.executeAction(action).pipe(map(e => e.data));
  }
}
