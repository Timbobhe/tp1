import {BackendService, ConfigService} from '@ag2rlamondiale/metis-ng';
import {HttpClient, HttpEvent, HttpEventType, HttpResponse} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {Store} from '@ngrx/store';
import {Observable, of} from 'rxjs';
import {catchError, debounceTime, filter, mergeMap} from 'rxjs/operators';
import * as Api from '../actions/api.actions';
import {selectApiEnd} from '../reducers/api.reducer';
import {ApiCallerService} from '../services/api-caller.service';
import {Performance} from '../utils/performance';

// pour passer la COMPILE Typescript 	:angry: >:( !!!!!!
const obs = Observable;

/**
 * ApiEffects déclenché si l'Action est de type Api.API.
 * Permet de gérer l'exécution de l'API dans Redux : Dispatch l'Action correspondante (ApiStart, ApiSuccess, ApiError)
 */
@Injectable()
export class ApiEffects {

  constructor(
    private readonly actions$: Actions,
    private readonly httpService: HttpClient,
    private readonly store: Store<any>,
    private readonly backendService: BackendService,
    private readonly configService: ConfigService,
    private readonly apiCaller: ApiCallerService,
  ) {
  }

  mergeCall$ = mergeMap((action: Api.ApiAction<any>) => this.executeApi(action));

  @Effect({dispatch: true})
  api$ = this.actions$.pipe(
    ofType(Api.API),
    this.mergeCall$
  );

  executeApi(action: Api.ApiAction) {
    Performance.markApiAction(action, 'start');
    this.store.dispatch(new Api.ApiStart({
      ...action.payload,
      dataStatus: {loading: true, fetched: false, data: null}
    }));

    return this.apiCaller
      .request(action)
      .pipe(
        filter((event: HttpEvent<any>) => event.type === HttpEventType.Response),
        mergeMap((result: HttpResponse<any>) => {
          Performance.measureApiAction(action, 'time-success', 'start', 'success');

          const data = action.payload.transcoder(result.body, this.configService);
          if (action.payload.onSuccess) {
            action.payload.onSuccess(data, result.headers);
          }
          if (action.payload.onTerminate) {
            action.payload.onTerminate();
          }
          return of(
            new Api.ApiSuccess({
              ...action.payload,
              data,
              responseHeaders: result.headers,
              dataStatus: {loading: false, fetched: true, data}
            }),
            new Api.ApiEnd({...action.payload}),
          );
        }),
        catchError(error => {
          Performance.measureApiAction(action, 'time-error', 'start', 'error');
          if (action.payload.onFailure) {
            action.payload.onFailure(error);
          }
          if (action.payload.onTerminate) {
            action.payload.onTerminate();
          }
          return of(
            new Api.ApiError({
              ...action.payload,
              error,
              dataStatus: {data: null, error, fetched: false, loading: false}
            }),
            new Api.ApiEnd({...action.payload}),
          );
        })
      );
  }


  /**
   * Méthode utilisée pour flusher l'opérateur distinct() utilisé par les Effects.
   * @param dueTime temps (milliseconds) après le dernier API_END lequel on flush
   */
  selectApiEnd(dueTime = 500) {
    return this.store.select(selectApiEnd).pipe(
      filter(isEnd => isEnd),
      debounceTime(dueTime)
    );
  }

}

