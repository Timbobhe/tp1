import { ApiAction } from './../actions/api.actions';
import { ActionTester } from './action-tester';
describe('ActionTester', () => {

  it('Instanciate ActionTester', () => {
    const tester = new ActionTester({ type: 'ACN' });
    expect(tester.action).toBeTruthy();
  });


  it('Test ofType passant', () => {
    const tester = new ActionTester({ type: 'ACN' });
    expect(tester.ofType('ACN')).toBeTruthy();
  });

  it('Test ofType non passant', () => {
    const tester = new ActionTester({ type: 'TOTO' });
    expect(tester.ofType('ACN')).toBeFalsy();
  });

  it('Test isApi passant', () => {
    const tester = new ActionTester({ type: 'API', payload: { label: 'FETCH' } });
    expect(tester.isApi()).toBeTruthy();
  });

  it('Test isApi pour classe ApiAction passant', () => {
    class FetchAction extends ApiAction<any> {
      constructor() {
        super('FETCH', 'endpoint', null);
      }
    }

    const tester = new ActionTester(new FetchAction());
    expect(tester.isApi()).toBeTruthy();
  });

  it('Test isApi pour classe ApiAction surcharge TYPE passant', () => {
    class FetchAction extends ApiAction<any> {
      type = 'FETCH';
      constructor() {
        super('FETCH', 'endpoint', null);
      }
    }

    const tester = new ActionTester(new FetchAction());
    expect(tester.isApi()).toBeTruthy();
  });

  it('Test isApi pour label passant', () => {
    const tester = new ActionTester({ type: 'API', payload: { label: 'FETCH' } });
    expect(tester.isApi('FETCH')).toBeTruthy();
  });

  it('Test isApi non passant', () => {
    const tester = new ActionTester({ type: 'ACN', payload: { label: 'FETCH' } });
    expect(tester.isApi()).toBeFalsy();
  });

  it('Test isApi pour label non passant', () => {
    const tester = new ActionTester({ type: 'API', payload: { label: 'WRITE' } });
    expect(tester.isApi('FETCH')).toBeFalsy();
  });


  it('Test isSuccess pour label passant', () => {
    const tester = new ActionTester({ type: 'API_SUCCESS', payload: { label: 'FETCH' } });
    expect(tester.isSuccess('FETCH')).toBeTruthy();
  });

  it('Test isSuccess sans label passant', () => {
    const tester = new ActionTester({ type: 'API_SUCCESS', payload: { label: 'WRITE' } });
    expect(tester.isSuccess()).toBeTruthy();
  });

  it('Test isSuccess pour label + non API non passant', () => {
    const tester = new ActionTester({ type: 'ACN', payload: { label: 'FETCH' } });
    expect(tester.isSuccess()).toBeFalsy();
  });

  it('Test isStart pour label passant', () => {
    const tester = new ActionTester({ type: 'API_START', payload: { label: 'FETCH' } });
    expect(tester.isStart('FETCH')).toBeTruthy();
  });

  it('Test isStart sans label passant', () => {
    const tester = new ActionTester({ type: 'API_START', payload: { label: 'WRITE' } });
    expect(tester.isStart()).toBeTruthy();
  });

  it('Test isStart pour label + non API non passant', () => {
    const tester = new ActionTester({ type: 'ACN', payload: { label: 'FETCH' } });
    expect(tester.isStart()).toBeFalsy();
  });

  it('Test isError pour label passant', () => {
    const tester = new ActionTester({ type: 'API_ERROR', payload: { label: 'FETCH' } });
    expect(tester.isError('FETCH')).toBeTruthy();
  });

  it('Test isError sans label passant', () => {
    const tester = new ActionTester({ type: 'API_ERROR', payload: { label: 'WRITE' } });
    expect(tester.isError()).toBeTruthy();
  });

  it('Test isError pour label + non API non passant', () => {
    const tester = new ActionTester({ type: 'ACN', payload: { label: 'FETCH' } });
    expect(tester.isError()).toBeFalsy();
  });


  it('Test isEnd pour label passant', () => {
    const tester = new ActionTester({ type: 'API_END', payload: { label: 'FETCH' } });
    expect(tester.isEnd('FETCH')).toBeTruthy();
  });

  it('Test isEnd sans label passant', () => {
    const tester = new ActionTester({ type: 'API_END', payload: { label: 'WRITE' } });
    expect(tester.isEnd()).toBeTruthy();
  });

  it('Test isEnd pour label + non API non passant', () => {
    const tester = new ActionTester({ type: 'ACN', payload: { label: 'FETCH' } });
    expect(tester.isEnd()).toBeFalsy();
  });

});
