import {Action} from '@ngrx/store';
import {API, ApiAction, API_END, API_ERROR, API_START, API_SUCCESS, DataStatus} from './../actions/api.actions';
import {Lifecycle} from "../reducers/api.reducer";

export class ActionTester {
  constructor(public readonly action: ApiAction | Action) {
  }

  ofType(type: string) {
    return type === this.action.type;
  }

  isApi(label?: string) {
    if (this.action instanceof ApiAction) {
      return label ? label === this.action.payload.label : true;
    }

    const labelAcn = this.labelAction();
    if (this.action.type === API && labelAcn) {
      return label ? label === labelAcn : true;
    }

    return false;
  }

  labelAction() {
    const payload: any = this.action['payload'];
    if (payload && payload.label) {
      return payload.label;
    }
    return null;
  }

  dataStatus<R = any>(): DataStatus<R> {
    const payload: any = this.action['payload'];
    if (payload && payload.dataStatus) {
      return payload.dataStatus;
    }
    return null;
  }

  isStart(label?: string): boolean {
    return API_START === this.action.type && (!label || label === this.labelAction());
  }

  isSuccess(label?: string): boolean {
    return API_SUCCESS === this.action.type && (!label || label === this.labelAction());
  }

  isError(label?: string): boolean {
    return API_ERROR === this.action.type && (!label || label === this.labelAction());
  }

  isEnd(label?: string): boolean {
    return API_END === this.action.type && (!label || label === this.labelAction());
  }

  isLoadingSuccess(label?: string): boolean {
    return this.isStart(label) || this.isSuccess(label);
  }

  isLoadingError(label?: string): boolean {
    return this.isStart(label) || this.isError(label);
  }

  isLoading(label?: string): boolean {
    return this.isStart(label) || this.isSuccess(label) || this.isError(label);
  }

  loading<R = any>(label: string, callback: (dataStatus: DataStatus<R>, lifecycle: Lifecycle) => any, withEnd = false) {
    let ds = this.dataStatus<R>();
    if (this.isStart(label)) {
      return callback(ds, "start");
    }
    if (this.isSuccess(label)) {
      return callback(ds, "success");
    }
    if (this.isError(label)) {
      return callback(ds, "error");
    }
    if (withEnd && this.isEnd(label)) {
      return callback(ds, "end");
    }
  }
}
