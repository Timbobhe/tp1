/** Construit une URL en concaténant les différents morceaux de chaine de caractère, gère les '/' */
export function buildUrl(...pieces: string[]): string {
  let result = '';
  pieces.forEach((v: string, i: number) => {
    if (v) {
      if (i === 0 || result.length === 0) {
        result = v;
      } else if (result.endsWith('/') && v.startsWith('/')) {
        result = result + v.substring(1);
      } else if (result.endsWith('/') && !v.startsWith('/')) {
        result = result + v;
      } else if (!result.endsWith('/') && v.startsWith('/')) {
        result = result + v;
      } else if (!result.endsWith('/') && !v.startsWith('/')) {
        result = result + '/' + v;
      }
    }
  });
  return result;
}
