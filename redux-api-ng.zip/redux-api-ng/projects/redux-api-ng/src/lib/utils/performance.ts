import * as Api from '../actions/api.actions';

const g: any = window;

export interface PerformanceConfig {
  active: boolean;
  log?: boolean;
  maxMeasure?: number;
}

const CONFIG: PerformanceConfig = (g.__env ? g.__env.config : {}).performance || {active: true, log: false, maxMeasure: 200};
console.log('PerformanceConfig = ', CONFIG);

const MAX_ERREUR = 10;

export class Performance {

  static nombreErreurs = 0;

  static mark(markName: string): void {
    if (CONFIG.active && performance) {
      try {
        performance.mark(markName);
      } catch (e) {
        if (Performance.nombreErreurs < MAX_ERREUR) {
          ++Performance.nombreErreurs;
          console.error(`performance.mark(${markName})`, e);
        }
      }
    }
  }

  static measure(measureName: string, startMark?: string, endMark?: string, markStepEnd = true): void {
    if (CONFIG.active && performance) {
      try {
        if (markStepEnd) {
          performance.mark(endMark);
        }
        performance.measure(measureName, startMark, endMark);
      } catch (e) {
        if (Performance.nombreErreurs < MAX_ERREUR) {
          ++Performance.nombreErreurs;
          console.error(`performance.measure(${measureName}, ${startMark}, ${endMark})`, e);
        }
      }
    }
  }

  static markApiAction(action: Api.ApiAction, step: string) {
    if (CONFIG.active && performance) {
      Performance.mark(`${Performance.apiActionName(action)}-${step}`);
    }
  }

  static measureApiAction(action: Api.ApiAction, name: string, stepStart: string, stepEnd: string, markStepEnd = true) {
    if (CONFIG.active && performance) {
      Performance.measure(`${Performance.apiActionName(action)}-${name}`,
        `${Performance.apiActionName(action)}-${stepStart}`,
        `${Performance.apiActionName(action)}-${stepEnd}`,
        markStepEnd);
    }
  }

  private static apiActionName(action: Api.ApiAction) {
    return `${action.payload.label}::${action.payload.uid}`;
  }

  static installConfig() {
    if (CONFIG.log && performance) {
      try {
        const logMeasure = (list, observer) => {
          const entries = list.getEntries();
          for (let i = 0; i < entries.length; i++) {
            console.log(entries[i]);
          }
        };

        new PerformanceObserver(logMeasure).observe({entryTypes: ['measure']});
      } catch (e) {
        console.error('performance-logging', e);
      }
    }


    if (CONFIG.maxMeasure && performance) {
      try {
        let numberMeasure = 0;

        const maxMeasure = (list, observer) => {
          const entries = list.getEntries();
          numberMeasure += entries.length;
          if (CONFIG.maxMeasure <= numberMeasure) {
            performance.clearMeasures();
            performance.clearMarks();
            numberMeasure = 0;
          }
        };

        new PerformanceObserver(maxMeasure).observe({entryTypes: ['measure']});
      } catch (e) {
        console.error('performance-cleaning', e);
      }
    }
  }

}

Performance.installConfig();





