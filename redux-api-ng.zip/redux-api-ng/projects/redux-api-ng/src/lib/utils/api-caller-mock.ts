import {Observable, ReplaySubject} from "rxjs";
import {HttpErrorResponse, HttpEvent, HttpEventType, HttpHeaders, HttpResponse} from "@angular/common/http";

const DefaultHttpParams: {
  headers?: HttpHeaders;
  status?: number;
  statusText?: string;
  url?: string;
} = {
  headers: new HttpHeaders(),
  status: 200,
  statusText: 'OK'
};

export function callMock<T = any>(data: T, httpParams?: {
  headers?: HttpHeaders;
  status?: number;
  statusText?: string;
  url?: string;
}): Observable<HttpEvent<T>> {
  const res = new ReplaySubject<HttpEvent<T>>(2);
  res.next({type: HttpEventType.Sent});

  const hp = httpParams ? {...DefaultHttpParams, ...httpParams} : DefaultHttpParams;

  if (hp.status >= 200 && hp.status < 300) {
    const httpResponse = new HttpResponse<T>({...hp, body: data});
    res.next(httpResponse);
  } else {
    const httpErrorResponse = new HttpErrorResponse({...hp, error: data});
    res.error(httpErrorResponse);
  }

  res.complete();
  return res;

}
