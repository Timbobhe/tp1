// const cryptoObj = window.crypto || window['msCrypto']; // for IE 11
//
// export function createUID() {
//   const array = new Uint32Array(10);
//   cryptoObj.getRandomValues(array);
//
//   let text = '';
//   for (let i = 0; i < array.length; i++) {
//     if (i === 0) {
//       text += array[i];
//     } else {
//       text += "-" + array[i];
//     }
//   }
//   return text;
// }

let counter = 0;

export function createUID() {
  return '' + (counter++);
}
