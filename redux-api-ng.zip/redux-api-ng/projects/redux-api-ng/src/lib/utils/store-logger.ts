import { ActionReducer } from '@ngrx/store';
import { LoggerOptions, storeLogger } from 'ngrx-store-logger';
import * as Api from '../actions/api.actions';

const API_ACTIONS = [Api.API
  , Api.API_START
  , Api.API_END
  , Api.ACCESS_DENIED
  , Api.API_SUCCESS
  , Api.API_ERROR];

export function storeApiLogger(reducer: ActionReducer<any>, opts?: LoggerOptions): ActionReducer<any> {
  const actionTransformer = (actn: any) => {
    if (API_ACTIONS.indexOf(actn.type) !== -1 && actn.payload && actn.payload.label) {
      return { ...actn, type: `**${actn.type}::${actn.payload.label}::${actn.payload.uid}**` };
    }
    return actn;
  };
  const defautlOpts = opts || {};

  return storeLogger({ ...defautlOpts, actionTransformer: defautlOpts.actionTransformer || actionTransformer })(reducer);
}
