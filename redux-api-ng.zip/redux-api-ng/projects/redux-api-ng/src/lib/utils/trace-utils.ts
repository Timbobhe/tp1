export const trace = (message: any, ...params: any[]) => {
  if (params && params[0] instanceof Error) {
    window.console.error(`[${new Date().toLocaleTimeString('fr-FR')}]\t${message}`, ...params);
  } else {
    window.console.log(`[${new Date().toLocaleTimeString('fr-FR')}]\t${message}`, ...params);
  }
};
