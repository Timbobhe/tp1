import {Action, createSelector} from '@ngrx/store';
import * as Api from '../actions/api.actions';

export type Lifecycle = 'start' | 'success' | 'error' | 'end';

export class State {
  uid: string;
  label: string;
  isLoadingData: boolean;

  lifecycle?: null | Lifecycle;
  url: string;

  baseUrl?: string;
  inputParams?: any;
  requestData?: any;
  data?: any;
  error?: Error;
  severity?: number;

  /** compteur des api-actions non terminées  */
  alive = 0;
  aliveActions: [];
}

export const initialState: State = Object.assign(new State(), {
  label: null,
  isLoadingData: false,
  url: null,
  inputParams: null,
  requestData: null,
  data: null,
  error: null,
  lifecycle: null,
  severity: null,
  alive: 0,
  aliveActions: []
});

export const DATA_MOCK = 'ok - the data has been recovered';

export function reducer(state: State = initialState, action: Api.Actions): State {
  switch (action.type) {
    case Api.API_START:
      const a = action.payload as Api.ApiActionPayload<any>;
      return Object.assign(new State(), {
        ...initialState, ...a,
        isLoadingData: true,
        lifecycle: 'start',
        alive: state.alive + 1,
        aliveActions: [...state.aliveActions, a.uid]
      });

    case Api.API_SUCCESS:
      const b = action.payload as Api.ApiActionPayload<any>;
      return Object.assign(new State(),
        {...state, ...b, isLoadingData: false, data: DATA_MOCK, lifecycle: 'success'}); // on ne conserve pas les data

    case Api.API_ERROR:
      const c = action.payload as Api.ApiActionPayload<any>;
      return Object.assign(new State(), {...state, ...c, lifecycle: 'error'});

    case Api.API_END:
      const d = action.payload as Api.ApiActionPayload<any>;
      let alive = state.alive - 1;
      let aliveActions = state.aliveActions.filter(e => e !== d.uid);
      return Object.assign(new State(), {...state, label: d.label, isLoadingData: false, lifecycle: 'end', alive, aliveActions});

    default:
      return state;
  }
}


export function idAction(action: Api.Actions | Action) {
  if (action['payload']) {
    // return [action.type, action['payload'].label];
    return {type: action.type, label: action['payload'].label};
  }
  // return [action.type];
  return {type: action.type};
}


export const selectApiEnd = createSelector((state: any) => state.api, api => api.lifecycle === 'end');
