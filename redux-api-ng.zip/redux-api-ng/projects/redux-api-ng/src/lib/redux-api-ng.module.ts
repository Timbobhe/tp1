import { MetisNgModule } from '@ag2rlamondiale/metis-ng';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SampleLibCompComponent } from './components/sample-lib-comp/sample-lib-comp.component';
import { ApiEffects } from './effects/api.effect';
import { reducer as apiReducer } from './reducers/api.reducer';


@NgModule({
  imports: [
    CommonModule,
    MetisNgModule.forRoot(),
    EffectsModule.forFeature([ApiEffects]),
    StoreModule.forFeature('api', apiReducer)
  ],
  declarations: [
    SampleLibCompComponent
  ],
  exports: [
    SampleLibCompComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: []
})
export class ReduxApiNgModule { }
