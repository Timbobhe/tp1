import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ra-sample-lib-comp',
  templateUrl: './sample-lib-comp.component.html',
  styleUrls: ['./sample-lib-comp.component.css']
})
export class SampleLibCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
