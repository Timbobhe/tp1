import {BackendService, ConfigService} from '@ag2rlamondiale/metis-ng';
import {HttpHeaders, HttpRequest} from '@angular/common/http';
import {Action} from '@ngrx/store';
import {buildUrl} from '../utils/urlBuilder';
import {createUID} from '../utils/uid';


// tslint:disable-next-line:no-inferrable-types
export const API: string = 'API';
// tslint:disable-next-line:no-inferrable-types
export const API_START: string = 'API_START';
// tslint:disable-next-line:no-inferrable-types
export const API_HTTP_START: string = 'API_HTTP_START';
// tslint:disable-next-line:no-inferrable-types
export const API_END: string = 'API_END';
// tslint:disable-next-line:no-inferrable-types
export const ACCESS_DENIED: string = 'ACCESS_DENIED';
// tslint:disable-next-line:no-inferrable-types
export const API_SUCCESS: string = 'API_SUCCESS';
// tslint:disable-next-line:no-inferrable-types
export const API_ERROR: string = 'API_ERROR';


export class ApiStart implements Action {
  readonly type = API_START;

  constructor(public payload: ApiActionPayload<any>) {
  }
}

export class ApiHttpStart implements Action {
  readonly type = API_HTTP_START;

  constructor(public payload: ApiActionPayload<any>) {
  }
}

export class ApiEnd implements Action {
  readonly type = API_END;

  constructor(public payload: ApiActionPayload<any>) {
  }
}

export class ApiSuccess<T> implements Action {
  readonly type = API_SUCCESS;

  constructor(public payload: ApiActionPayload<T>) {
  }
}

export class ApiError implements Action {
  readonly type = API_ERROR;

  constructor(public payload: ApiActionPayload<any>) {
  }
}

export class AccessDenied implements Action {
  readonly type = ACCESS_DENIED;

  constructor(public payload: ApiActionPayload<any>) {
  }
}

export const INNER_BACKEND = 'backend/';

export const LEVEL_SEVERITY_MAJOR = 0;
export const LEVEL_SEVERITY_MODERATE = 1;
export const LEVEL_SEVERITY_MINOR = 2;

export interface DataStatus<R = any> {
  data: R;
  loading: boolean;
  fetched: boolean;
  /** L'erreur récue (en cas d'erreur) */
  error?: Error;
}

export class ApiActionPayload<R = any, I = any> {
  /** Identifiant de l'action */
  uid: string;

  /** Identifiant de l'API */
  label: string;
  /** Endpoint de l'API : inner backend (mon back) commence par 'backend/mon_endpoint_local', extern backend sinon : 'externe_endpoint' */
  endpoint: string;
  /** Fin de l'URL à compléter : /endpoint[/url] */
  url = '';
  /** Method HTTP */
  method: 'DELETE' | 'GET' | 'HEAD' | 'POST' | 'PUT' | 'TRACE' | 'PATCH' | 'OPTIONS' = 'GET';
  /** Input data : data passée dans le Body de la request */
  requestData: any = null;
  /** Resultat */
  data: R = null;
  responseHeaders: HttpHeaders = null;
  dataStatus: DataStatus<R>;
  /** Type de réponse attendue */
  responseType?: 'arraybuffer' | 'blob' | 'json' | 'text' = 'json';
  /** Critere d'appel (le payload de la sous classe ApiAction) */
  inputParams: I = null;
  accessToken = null;
  headersOverride = null;
  /** L'erreur récue (en cas d'erreur) */
  error: Error = null;

  /** Niveau de gravité */
  severity: number = LEVEL_SEVERITY_MAJOR;

  onSuccess = (data: R, headers?: HttpHeaders) => {
  }
  onFailure = (error: Error) => console.log(`Error occured API called ${this.label} : ${this.url}`, error);
  onTerminate = () => console.log(`Terminate API called ${this.label}`);
  transcoder = (data: any, configService?: ConfigService): R => data;
}

export class ApiAction<R = any, I = any> implements Action {
  type = API;
  payload = new ApiActionPayload<R, I>();

  constructor(label: string | ApiActionPayload<R, I>, endpoint: string, inputParams: I, rest?: any);
  constructor(un: string | ApiActionPayload<R, I>, deux: string, trois: string | any, quatre?: any) {
    if (typeof un === 'string') {
      this.payload.label = un;
      this.payload.endpoint = deux;
      this.payload.inputParams = trois;
    } else {
      // console.warn(`[DEPRECATED] ${this.constructor.name} [action Type=${this.type}, Label=${deux}] `
      //   + `Il n'est plus nécessaire de passer new ApiActionPayload<T>() en 1er argument du constructeur`);

      this.payload = un || new ApiActionPayload<R, I>();
      this.payload.label = deux;
      this.payload.endpoint = trois;
      this.payload.inputParams = quatre;
    }
    this.payload.uid = createUID();
  }

  toHttpRequest(configService: ConfigService, backendService: BackendService): HttpRequest<R> {
    let baseUrl = this.payload.endpoint;
    if (this.payload.endpoint && this.payload.endpoint.startsWith(INNER_BACKEND)) {
      const u = this.payload.endpoint.substring(INNER_BACKEND.length); // backend/xxx => xxx
      baseUrl = backendService.getEndpointUrl(u);
    } else if (this.payload.endpoint) {
      baseUrl = configService.config[this.payload.endpoint];
    }
    const url = baseUrl ? buildUrl(baseUrl, this.payload.url) : this.payload.url;
    const req = new HttpRequest<R>(this.payload.method, url, this.inputData(), {
      responseType: this.payload.responseType
    });
    return req;
  }

  inputData() {
    if (this.payload.requestData) {
      return this.payload.requestData;
    }

    if (this.payload.data) {
      console.warn(`[DEPRECATED] [action Type=${this.type}, Label=${this.payload.label}] `
        + `Utiliser this.payload.requestData au lieu de this.payload.data pour renseigner les data de la request`);
      return this.payload.data;
    }
    return null;
  }

  /**
   * Retourne la valeur de la clé permettant d'indiquer que l'on souhaite un accès exclusif à l'API.
   * Si la valeur de la clé est NULL alors il n'y a pas d'exclusion d'appel sur l'API (toutes les actions seront exécutées).
   */
  get distinctKey(): null | any {
    return null;
  }

}


export type Actions = ApiAction | ApiStart | ApiHttpStart | ApiEnd | ApiSuccess<any> | ApiError | AccessDenied;
