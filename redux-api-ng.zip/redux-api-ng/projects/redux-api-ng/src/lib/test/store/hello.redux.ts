import { Actions as ApiActions, ApiAction, ApiActionPayload } from 'redux-api-ng';

export const HELLO_SAY = 'HELLO_SAY';
export const HELLO_PRESENCE = 'HELLO_PRESENCE';

export class HelloPayload {
  who: string;
}


export class HelloFetch extends ApiAction<string> {

  constructor(critere: HelloPayload) {
    super(new ApiActionPayload<any>(), HELLO_SAY, 'hello_api', critere);
    this.payload.url = `/say/${critere.who}`;
    this.payload.transcoder = this.extractMessage.bind(this);
  }

  extractMessage(object: any) {
    return object.message;
  }
}

export class HelloBackendFetch extends ApiAction<string> {

  constructor(critere: HelloPayload) {
    super(new ApiActionPayload<any>(), HELLO_SAY, 'backend/api_hello', critere);
    this.payload.url = `/say/${critere.who}`;
    this.payload.transcoder = this.extractMessage.bind(this);
  }

  extractMessage(object: any) {
    return object.message;
  }
}

export class HelloPresence extends ApiAction<string> {

  constructor(critere: HelloPayload) {
    super(new ApiActionPayload<any>(), HELLO_PRESENCE, 'backend/api_hello', critere);
    this.payload.url = `/presence`;
    this.payload.method = 'POST';
    this.payload.requestData = critere;
    this.payload.transcoder = this.extractMessage.bind(this);
  }

  extractMessage(object: any) {
    return object.message;
  }
}


export type Actions = HelloFetch | HelloBackendFetch | HelloPresence | ApiActions;
