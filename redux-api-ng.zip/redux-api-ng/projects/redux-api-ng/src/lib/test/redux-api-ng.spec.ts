// tslint:disable:max-line-length
import { BackendService, ConfigService } from '@ag2rlamondiale/metis-ng';
import { HttpTestingController } from '@angular/common/http/testing';
import { async, TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';
import { DATA_MOCK, idAction, State as ApiState } from '../reducers/api.reducer';
import { HelloBackendFetch, HelloFetch, HelloPresence } from './store/hello.redux';
import { testingModule } from './test.module';


describe('ReduxApiNg', () => {
  let configService: ConfigService;
  let backendService: BackendService;
  let httpTestingController: HttpTestingController;
  let store: Store<ApiState>;

  beforeEach(async(() => {
    testingModule().compileComponents();
  }));

  beforeEach(() => {
    store = TestBed.get(Store);

    httpTestingController = TestBed.get(HttpTestingController);
    configService = TestBed.get(ConfigService);
    backendService = TestBed.get(BackendService);
  });

  it('should create store', async(() => {
    expect(store).toBeTruthy();
  }));

  it('should return external hello_api', async(() => {
    console.log('configService', configService);
    const url = configService.config.hello_api;
    expect(url).toEqual('http://localhost/api/hello');
  }));

  it('should return backend api_hello', () => {
    console.log('backendService', backendService);
    const url = backendService.getEndpointUrl('api_hello');
    expect(url).toEqual('http://localhost:8080/eib/api/hello');
  });


  it('should dispatch action Hello - API_SUCCESS', () => {
    const who = 'Toto';
    const message = `Hello ${who}`;
    const fetcher = new HelloFetch({ who });
    fetcher.payload.onSuccess = (data: string) => {
      // CHECK SUCCESS
      expect(data).toEqual(message);
    };
    fetcher.payload.onFailure = (error: Error) => {
      fail('should have failed with the network success');
    };
    store.dispatch(fetcher);

    // MOCK API
    const url = configService.config.hello_api;
    const req = httpTestingController.expectOne(`${url}/say/${who}`);
    req.flush({ message });

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toEqual(DATA_MOCK);
      }
    });
  });

  it('should dispatch action Hello - API_ERROR', () => {
    const who = 'Toto';
    const fetcher = new HelloFetch({ who });
    fetcher.payload.onSuccess = (data: string) => {
      fail('should have failed with the network error');
    };
    fetcher.payload.onFailure = (error: Error) => {
      expect(error).toBeTruthy();
    };
    store.dispatch(fetcher);


    // MOCK API
    const url = configService.config.hello_api;
    const req = httpTestingController.expectOne(`${url}/say/${who}`);
    // Create mock ErrorEvent, raised when something goes wrong at the network level.
    // Connection timeout, DNS error, offline, etc
    const mockError = new ErrorEvent('Network error', { message: 'simulated network error' });

    // Respond with mock error
    req.error(mockError);

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toBeNull();
      }

      if (api.error) {
        expect(api.error).toBeTruthy();
      }
    });
  });


  it('should dispatch action HelloBackend - API_SUCCESS', () => {
    const who = 'Toto';
    const message = `Hello ${who}`;
    const fetcher = new HelloBackendFetch({ who });
    fetcher.payload.onSuccess = (data: string) => {
      // CHECK SUCCESS
      expect(data).toEqual(message);
    };
    fetcher.payload.onFailure = (error: Error) => {
      fail('should have failed with the network success');
    };
    store.dispatch(fetcher);

    // MOCK API
    const url = backendService.getEndpointUrl('api_hello');
    const req = httpTestingController.expectOne(`${url}/say/${who}`);
    req.flush({ message });

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toEqual(DATA_MOCK);
      }
    });
  });

  it('should dispatch action HelloBackend - API_ERROR', () => {
    const who = 'Toto';
    const fetcher = new HelloBackendFetch({ who });
    fetcher.payload.onSuccess = (data: string) => {
      fail('should have failed with the network error');
    };
    fetcher.payload.onFailure = (error: Error) => {
      expect(error).toBeTruthy();
    };
    store.dispatch(fetcher);


    // MOCK API
    const url = backendService.getEndpointUrl('api_hello');
    const req = httpTestingController.expectOne(`${url}/say/${who}`);
    // Create mock ErrorEvent, raised when something goes wrong at the network level.
    // Connection timeout, DNS error, offline, etc
    const mockError = new ErrorEvent('Network error', { message: 'simulated network error' });

    // Respond with mock error
    req.error(mockError);

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toBeNull();
      }

      if (api.error) {
        expect(api.error).toBeTruthy();
      }
    });
  });

  it('should dispatch action HelloPresence (POST) - API_SUCCESS', () => {
    const who = 'Toto';
    const message = `Register ${who}`;
    const register = new HelloPresence({ who });
    register.payload.onSuccess = (data: string) => {
      // CHECK SUCCESS
      expect(data).toEqual(message);
    };
    register.payload.onFailure = (error: Error) => {
      fail('should have failed with the network success');
    };
    store.dispatch(register);

    // MOCK API
    const url = backendService.getEndpointUrl('api_hello');
    // const req = httpTestingController.expectOne({ url: `${url}/presence`, method: 'POST' });
    const req = httpTestingController.expectOne((x) => x.url === `${url}/presence` && x.method === 'POST' && x.body.who === who);
    req.flush({ message });

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.requestData) {
        expect(api.requestData.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toEqual(DATA_MOCK);
      }
    });
  });


  it('should dispatch action HelloPresence (POST) - API_ERROR', () => {
    const who = 'Toto';
    const message = `Register ${who}`;
    const register = new HelloPresence({ who });
    register.payload.onSuccess = (data: string) => {
      fail('should have failed with the network success');
    };
    register.payload.onFailure = (error: Error) => {
      expect(error).toBeTruthy();
    };
    store.dispatch(register);

    // MOCK API
    const url = backendService.getEndpointUrl('api_hello');
    // const req = httpTestingController.expectOne({ url: `${url}/presence`, method: 'POST' });
    const req = httpTestingController.expectOne((x) => x.url === `${url}/presence` && x.method === 'POST' && x.body.who === who);

    // Create mock ErrorEvent, raised when something goes wrong at the network level.
    // Connection timeout, DNS error, offline, etc
    const mockError = new ErrorEvent('Network error', { message: 'simulated network error' });

    // Respond with mock error
    req.error(mockError);

    // CHECK STATE
    store.select('api').subscribe((api: ApiState) => {
      if (api.inputParams) {
        expect(api.inputParams.who).toEqual(who);
      }
      if (api.requestData) {
        expect(api.requestData.who).toEqual(who);
      }
      if (api.data) {
        expect(api.data).toBeNull();
      }

      if (api.error) {
        expect(api.error).toBeTruthy();
      }
    });
  });

  it('test idAction', () => {
    const id1 = idAction(new HelloBackendFetch({ who: 'Foo' }));
    expect(id1).toEqual({ type: 'API', label: 'HELLO_SAY' });

    const id2 = idAction({ type: 'TYPE_ACTION' });
    expect(id2).toEqual({ type: 'TYPE_ACTION' });
  });


  it('test IF case idAction', () => {
    const id2 = idAction({ type: 'TYPE_ACTION' });
    const { type, label } = id2;
    console.log('type, label', type, label);
    expect(id2).toEqual({ type: 'TYPE_ACTION' });

    if (type === 'API' && label === 'HELLO_SAY') {
      fail('Ne dois pas matcher [\'API\', \'HELLO_SAY\']');
    } else if (type === 'API' && label === 'FETCH_CONTRAT') {
      fail('Ne dois pas matcher [\'API\', \'FETCH_CONTRAT\']');
    } else if (type === 'TYPE_ACTION') {
      console.log('case ok');
    } else {
      fail('Ne dois pas matcher le default (id2)');
    }
  });

});
