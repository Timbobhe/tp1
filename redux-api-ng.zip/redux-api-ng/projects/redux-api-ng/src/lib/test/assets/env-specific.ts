export const envSpecificConfig = {
  backend_base: {
    protocol: 'http',
    host: 'localhost',
    port: '8080',
    contextRoot: 'eib'
  },
  // backend: {
  //   endpoints: {
  jahia_endpoint: 'http://cdr-dev-jahia7:8080',
  jahia_header_script: '/files/live/sites/alm-angular-utils/files/javascript/angular-header-footer.js',
  cas_server_logout_url: 'http://loginalm-qualif/cas/sso/dev$alm2014/logout',
  // jahia_api_contrib: 'http://localhost:8080/ecrs/api/jahia',
  jahia_api_contrib: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  jahia_api_dictionnaire: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  jahia_files: 'http://cdr-dev-jahia7:8080/',
  hello_api: 'http://localhost/api/hello',
  should_logout_cas_client: true
  //   }
  // }
};
