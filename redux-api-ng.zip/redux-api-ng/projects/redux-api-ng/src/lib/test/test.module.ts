import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { ReduxApiNgModule } from '../redux-api-ng.module';
import { backendServiceProvider, configServiceProvider, envSpecificProvider } from './conf.provider';


export const testingModule = () => TestBed.configureTestingModule({
  imports: [
    HttpClientTestingModule,
    StoreModule.forRoot({}),
    EffectsModule.forRoot([]),
    ReduxApiNgModule
  ],
  providers: [
    envSpecificProvider,
    configServiceProvider,
    backendServiceProvider
  ]
});
