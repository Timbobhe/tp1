
// tslint:disable:max-line-length
import { buildUrl } from '../utils/urlBuilder';

describe('urlBuilder', () => {

  it('buildUrl', () => {
    expect(buildUrl).toBeTruthy();
  });

  it('buildUrl 0 args', () => {
    expect(buildUrl()).toEqual('');
  });

  it('buildUrl 1 args', () => {
    expect(buildUrl('backend/')).toEqual('backend/');
    expect(buildUrl('backend')).toEqual('backend');
  });

  it('buildUrl 2 args', () => {
    expect(buildUrl('backend/', 'login')).toEqual('backend/login');
    expect(buildUrl('backend/', '/login')).toEqual('backend/login');
    expect(buildUrl('backend', '/login')).toEqual('backend/login');
    expect(buildUrl('backend', 'login')).toEqual('backend/login');
  });

  it('buildUrl 3 args', () => {
    expect(buildUrl('backend/', 'login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend/', '/login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend', '/login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend', '/login/', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend/', '/login/', '/foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend', 'login', 'foo')).toEqual('backend/login/foo');
  });

  it('buildUrl 3 args, avec null', () => {
    expect(buildUrl('backend', 'login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend/', null, 'login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl(null, 'backend/', '/login', 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend', '/login', null, 'foo')).toEqual('backend/login/foo');
    expect(buildUrl('backend', '/login/', 'foo', null)).toEqual('backend/login/foo');
    expect(buildUrl(null, 'backend/', null, '/login/', null, '/foo')).toEqual('backend/login/foo');
  });

});

