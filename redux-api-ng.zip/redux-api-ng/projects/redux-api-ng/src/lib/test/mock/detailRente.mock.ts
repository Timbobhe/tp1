// tslint:disable:quotemark
// tslint:disable:max-line-length

export const mockData = {
  'blockId': 'detailRente',
  'workspace': 'live',
  'lastPublished': '2018-02-27T11:44:45.053+01:00',
  'pagePath': '/sites/aqe/home/retraite-supplementaire/estimer-votre-retraite-supplemen',
  'contentHtml': '\n\t\t    <div >\r\n\t\r\n\t<div>\r\n\t\t<p style="font-variant-ligatures: normal; orphans: 2; widows: 2;">\n <span style="color: rgb(57, 25, 9);">Cette estimation est r&eacute;alis&eacute;e avec projection, jusqu&rsquo;&agrave; l&rsquo;&acirc;ge de d&eacute;part &agrave; la retraite choisi, des futurs rendements anticip&eacute;s des placements de votre compte et le cas &eacute;ch&eacute;ant des cotisations et versements &agrave; venir selon l&#39; (les) hypoth&egrave;se (s) suivante (s) :</span></p>\n<ul style="font-variant-ligatures: normal; orphans: 2; widows: 2;">\n <li>\n  <span style="color: rgb(57, 25, 9);"><span dir="LTR">La r&eacute;mun&eacute;ration annuelle de l&rsquo;&eacute;pargne en Euro fix&eacute;e &agrave; &nbsp;$RE/Euro$ % brute</span>&nbsp;l&rsquo;an.</span></li>\n <li>\n  <span style="color: rgb(57, 25, 9);"><span dir="LTR">La r&eacute;mun&eacute;ration annuelle de l&rsquo;&eacute;pargne en Unit&eacute;s de Compte fix&eacute;e &agrave; &nbsp;$RE/UC$ % brute</span>&nbsp;l&rsquo;an.</span></li>\n <li>\n  <span style="color: rgb(57, 25, 9);"><span dir="LTR">La croissance de $RCOT$ % l&rsquo;an du montant des cotisations futures vers&eacute;es par votre employeur.</span></span></li>\n <li>\n  <span style="color: rgb(57, 25, 9);"><span dir="LTR">La croissance de $RVP$ % l&rsquo;an du montant des Versements Individuels et Facultatifs programm&eacute;s.</span></span></li>\n</ul>\n\r\n\t\t<div class="divider"></div>\t\r\n\t</div>\r\n</div>\n\t\t    ',
  'uuid': '7e74e3ea-5d75-4d71-9892-a7761c92515f',
  'code': 'detailRente'
};
