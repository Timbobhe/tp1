# ReduxApiNg

La librairie **ReduxApiNg** a pour but de gérer la mise à jour du **Store Redux** suite à l'appel d'API HTTP.

## Liens

Cette librairie repose sur les [**Effects**](https://ngrx.io/guide/effects) de **NgRx** et permet de **factoriser** son usage pour tout appel d'API
 : **Une seule classe Effects pour toute cette problématique.**

Adaptation **NgRx** depuis [Documentation Medium](https://blog.logrocket.com/data-fetching-in-redux-apps-a-100-correct-approach-4d26e21750fc).

## Installation

- `npm install @ag2rlamondiale/redux-api-ng`

- Dans le module de l'application :

```javascript
@NgModule({
  declarations: [AppComponent],

  imports: [
    BrowserModule,
    HttpClientModule,
    CommonModule,
    MetisNgModule.forRoot(),

    // INTEGRATION NgRx DEBUT
    StoreModule.forRoot({}, { metaReducers }),
    // Rajouter EffectsModule avant d'importer ReduxApiNgModule corrige l'erreur NgRx :
    // StaticInjectorError(Platform: core)[ApiEffects -> Actions]: NullInjectorError: No provider for Actions!
    EffectsModule.forRoot([]),
    // INTEGRATION NgRx FIN

    ReduxApiNgModule, // <-- Après l'import des Modules NgRx
  ],
  providers: [
    HttpInterceptorProviders2,
    BackendService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
```

## Usage

### Action API

Les **Actions** qui déclenchent un appel d'API doivent hériter de la classe `ApiAction<T>`.

_Exemple :_
Cette Action permet de récupérer un Dictionnaire depuis Jahia à partir de son title.

```typescript
// Critère d'appel de l'action (le title du dico)
export class JahiaDicoPayload {title: string;}

// Classe de l'Action
export class JahiaDicoFetch extends ApiAction<JahiaDictionnaire> {

  constructor(critere: JahiaDicoPayload) {
    super(JAHIA_DICTIONNAIRE_FETCH_DICO, 'apiDictionnaire', critere);
    this.payload.url = JAHIA_CONFIG.getDicoPath(critere.title);
    this.payload.transcoder = this.buildJahiaDictionnaire.bind(this);
  }
```

Les arguments du constructeur de la classe `ApiAction<T>` :

1. le label de l'API exécutée, ex : `JAHIA_DICTIONNAIRE_FETCH_DICO`
2. la clé du ENDPOINT de l'API  :
   1. qui sera récupérée depuis le `BackendService` si commence par `backend/xxx` (API interne au Back de l'application)
   2. sinon, qui sera récupérée depuis `ConfigService`, ex : `'apiDictionnaire'` (API externe au back de l'application)
3. le payload de l'action cible, ex : `critere`

### A) Le **ENDPOINT** est déclaré dans le fichier `assets/config.js` mis en place par la librairie [`metis-ng`](http://amidev/wiki/index.php/Support_METIS_ANGULAR).

```javascript
window.__app_env = {};
window.__app_env.config = {
  backend: {
    endpoints: {
      loginUrl: '/api/secure/redirectToJahia',
      casClientLogout: '/api/logout',
      demoResource: '/api/secure/demo',
      xxx: '/api/xxx'
    }
  }
};
```

### B) Le **ENDPOINT** est déclaré dans le fichier `assets/env_specific.js` mis en place par la librairie [`metis-ng`](http://amidev/wiki/index.php/Support_METIS_ANGULAR).

```javascript
window.__env = {};
window.__env.config = {
  backend_base: {
    protocol: 'http',
    host: 'localhost',
    port: '8080',
    contextRoot: 'eib'
  },
  // Déclaration des ENDPOINT externes à l'application
  jahiaFiles: 'http://cdr-dev-jahia7:8080/',
  apiDictionnaire: 'http://cdr-dev-jahia7:8080/cms/render/live/fr'
};

```

### Description du Payload de l'API Action

```typescript
export class ApiActionPayload<T> {
  /** Identifiant de l'API */
  label: string;
  /** Endpoint de l'API : inner backend (mon back) commence par 'backend/mon_endpoint_local', extern backend sinon : 'externe_endpoint' */
  endpoint: string;
  /** Fin de l'URL à compléter : /endpoint[/url] */
  url = '';
  /** Method HTTP */
  method: 'DELETE' | 'GET' | 'HEAD' | 'POST' | 'PUT' | 'TRACE' | 'PATCH' | 'OPTIONS' = 'GET';
  /** Input data : data passée dans le Body de la request */
  requestData: any = null;
  /** Resultat */
  data: T = null;
  /** Type de réponse attendue */
  responseType?: 'arraybuffer' | 'blob' | 'json' | 'text' = 'json';
  /** Critere d'appel (le payload de la sous classe ApiAction) */
  inputParams = null;
  accessToken = null;
  headersOverride = null;
  /** L'erreur récue (en cas d'erreur) */
  error: Error = null;

  onSuccess = (data: T) => { };
  onFailure = (error: Error) => console.log(`Error occured API called ${this.label} : ${this.url}`, error);
  onTerminate = () => console.log(`Terminate API called ${this.label}`);
  transcoder = (data: any, configService?: ConfigService): T => data;
}
```

| Attribut     | Description                                                                                                                                    |
| ------------ | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| label        | Identifiant de l'API déclenchée                                                                                                                |
| endpoint     | Endpoint de l'API (début de l'URL déclarée dans le dans le fichier `assets/env_specific.js`)                                                   |
| url          | La fin de l'URL de l'API, construit dynamiquement selon critère de l'action                                                                    |
| method       | Verbe HTTP utiliser pour exécuter l'appel d'API                                                                                                |
| requestData  | Les données émises dans le Body de la Request HTTP (POST, PUT, ...)                                                                            |
| data         | Les données de retour de l'API                                                                                                                 |
| responseType | Indique le type des données en retour                                                                                                          |
| error        | L'objet Error s'il y a une erreur à l'appel de l'API                                                                                           |
| severity     | Niveau de gravité de l'Action (LEVEL_SEVERITY_MAJOR = 0 **(par défaut)**, LEVEL_SEVERITY_MODERATE = 1, LEVEL_SEVERITY_MINOR = 2)               |
| inputParams  | Paramètre d'appel de l'API                                                                                                                     |
| onSuccess    | Fonction callback appelée en cas de succès avec les data en paramètre d'appel                                                                  |
| onFailure    | Fonction callback appelée en cas d'échec avec l'error en paramètre d'appel                                                                     |
| onTerminate  | Fonction callback appelée à la fin de l'appel de l'API (succès ou échec)                                                                       |
| transcoder   | Fonction permettant de transcoder le résultat de l'API, appelée tout de suite au succès de l'API, onSuccess() récupère les données transcodées |

### Reducer API

Les **Reducer API** doivent tester que le `TYPE` de l'action est égale à `API_START ou API_END ou API_SUCCESS ou API_ERROR` et que le label est égale à `XXX` selon l'API gérée.

**ATTENTION** : Le Reducer doit produire une nouvelle instance du State.

_Exemple :_
_Mettre à jour l'état uniquement si `TYPE = 'API_SUCCESS'` et `label = 'JAHIA_DICTIONNAIRE_FETCH_DICO'`_


```typescript
export function reducer(state: JahiaDictionnairesState = initialState, action: JahiaAction.Actions) {
  if (action.type === ApiAction.API_SUCCESS && action.payload.label === JahiaAction.JAHIA_DICTIONNAIRE_FETCH_DICO) {
    const dico: JahiaDictionnaire = action.payload.data;
    if (dico && dico.title && !dico.isEmpty()) {
      return Object.assign(new JahiaDictionnairesState(), { ...state.add(dico) });
    }

  }
  return state;
}
```


## Développement

- `npm run start` to compile library and run project.

- `ng generate component components/foo --project=redux-api-ng` to generate a component named foo inside components folder in redux-api-ng project.

To add a dependency to the library, you need to add it to peerDependencies so that the project that uses your library get invited to install the dependency "example: adding bootstrap to peer peerDependencies".

