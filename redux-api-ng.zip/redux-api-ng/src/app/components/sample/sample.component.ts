import {Component, OnDestroy, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {GlobalState, SampleState} from '../../reducers';
import {Observable} from 'rxjs';
import {HelloFetch} from '../../actions/sample.actions';

@Component({
  selector: 'app-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.css']
})
export class SampleComponent implements OnInit, OnDestroy {
  sample$: Observable<SampleState>;

  private subscriptions = [];

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.sample$ = this.store.select('sample');
  }

  ngOnDestroy(): void {
  }


  launch(number: number) {
    for (let i = 0; i < number; i++) {
      this.subscriptions.push(
        this.store.select('sample').subscribe(x => {
          if (!x.helloMessage || !x.helloMessage.loading && !x.helloMessage.fetched) {
            this.store.dispatch(new HelloFetch({who: 'Toto'}));
          }
        })
      );
    }
  }
}
