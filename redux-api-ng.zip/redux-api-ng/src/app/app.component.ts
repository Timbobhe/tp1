import {Component, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {EMPTY, Observable} from 'rxjs';
import {HELLO_SAY, HelloFetch} from './actions/sample.actions';
import {ApiCallerService, callMock, ReduxApiService} from 'redux-api-ng';
import {catchError, delay, map, tap} from 'rxjs/operators';


@Component({
  selector: 'app-root',
  styleUrls: ['./app.component.css'],
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

  api$: Observable<any>;
  message: string;
  private helloFromService$: Observable<string>;

  constructor(
    private readonly store: Store<any>,
    private readonly apiCaller: ApiCallerService,
    private readonly reduxApi: ReduxApiService) {
  }

  ngOnInit() {
    this.api$ = this.store.select('api');
  }

  hello(number = 1, boom = false) {
    for (let i = 0; i < number; i++) {
      const fetcher = new HelloFetch({who: 'Yohan', boom});
      fetcher.payload.onSuccess = this.helloResult.bind(this);
      fetcher.payload.onFailure = (error => this.helloResult(`error ${error.name} ${error.message}`));
      this.store.dispatch(fetcher);
    }
  }

  helloFromReduxApiService(number = 1, boom = false) {
    for (let i = 0; i < number; i++) {
      const fetcher = new HelloFetch({who: 'Yohan', boom});
      this.reduxApi.execute(fetcher).pipe(
        tap(m => this.helloResult(m)),
        catchError(e => {
          this.helloResult(`error ${e.name} ${e.message}`);
          return EMPTY;
        })
      );
    }
  }

  registerMock() {
    this.apiCaller.registerInterceptor(HELLO_SAY,
      (action) => {
        const a = action as HelloFetch;
        if (a.payload.inputParams.boom) {
          return callMock('Error From Mock', {status: 500, statusText: 'Boom'}).pipe(delay(5000));
        }
        return callMock<{ message: string }>({message: `Hello ${a.payload.inputParams.who} From Mock`});//.pipe(delay(5000));
      });
  }


  removeMock() {
    this.apiCaller.removeInterceptor(HELLO_SAY);
  }


  helloResult(message: string) {
    this.message = message;
  }

  executeActionFromReduxApiService() {
    this.helloFromService$ = this.reduxApi.execute(new HelloFetch({who: 'Yohan', boom: false}));
  }
}
