import {ActionReducer, ActionReducerMap, MetaReducer} from '@ngrx/store';
import {ActionTester, ApiActionPayload, DataStatus, storeApiLogger} from 'redux-api-ng';
import {environment} from '../../environments/environment';
import * as sampleActions from "../actions/sample.actions";
import {HelloPayload} from "../actions/sample.actions";

export function logger(reducer: ActionReducer<any>): ActionReducer<any> {
  return storeApiLogger(reducer);
}

export const metaReducers: MetaReducer<any>[] = !environment.production ? [logger] : [];


export class SampleState {
  who: string;
  helloMessage: DataStatus<string>;
}

export function sampleReducer(state: SampleState = new SampleState(), action: sampleActions.Actions): SampleState {
  const tester = new ActionTester(action);

  if (tester.isLoading(sampleActions.HELLO_SAY)) {
    const payload = action.payload as ApiActionPayload<string, HelloPayload>;
    return {helloMessage: payload.dataStatus, who: action.payload.inputParams.who};
  }

  return state;
}

export interface GlobalState {
  sample: SampleState;
}

export const reducers: ActionReducerMap<GlobalState> = {
  sample: sampleReducer
}


