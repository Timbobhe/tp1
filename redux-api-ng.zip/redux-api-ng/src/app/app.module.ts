import {GlobalErrorHandler, MetisNgModule} from '@ag2rlamondiale/metis-ng';
import {CommonModule} from '@angular/common';
import {HttpClientModule} from '@angular/common/http';
import {ErrorHandler, NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {EffectsModule} from '@ngrx/effects';
import {StoreModule} from '@ngrx/store';
import {ReduxApiNgModule} from 'redux-api-ng';
import {AppComponent} from './app.component';
import {HttpInterceptorProviders2} from './interceptors';
import {metaReducers, reducers} from './reducers';
import {BackendService} from './services/backend.service';
import { SampleComponent } from './components/sample/sample.component';

@NgModule({
  declarations: [AppComponent, SampleComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    CommonModule,
    MetisNgModule.forRoot(),
    StoreModule.forRoot(reducers, {metaReducers}),
    // Il faut rajouter ces Effects avant d'importer ReduxApiNgModule
    // corrige l'erreur StaticInjectorError(Platform: core)[ApiEffects -> Actions]: NullInjectorError: No provider for Actions!
    EffectsModule.forRoot([]),
    ReduxApiNgModule],
  providers: [
    HttpInterceptorProviders2,
    BackendService,
    {provide: ErrorHandler, useClass: GlobalErrorHandler}
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
