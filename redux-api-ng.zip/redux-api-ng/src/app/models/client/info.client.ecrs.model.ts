import { ClientEspaceCourtier } from "./client.espace.courtier.model";

export class InfoClientEcrsModel {
  numeroPersonne = '';
  infoPersonne: ClientEspaceCourtier = new ClientEspaceCourtier();
}
