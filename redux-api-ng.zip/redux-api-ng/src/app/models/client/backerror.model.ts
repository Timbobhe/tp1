export class BackErrorModel {
  errorLevel = '';
  errorCode = '';
  constructor(errorLevel: string, errorCode: string) {
    this.errorLevel = errorLevel;
    this.errorCode = errorCode;
  }
}
