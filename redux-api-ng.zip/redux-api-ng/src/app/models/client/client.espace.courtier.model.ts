export class ClientEspaceCourtier {
  civilite = '';
  nom = '';
  prenom = '';
  constructor() {}
}
