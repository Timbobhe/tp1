export class JahiaDictionnaire {
  title: string;
  entries = new Map<string, string>();

  add(key: string, value: string) {
    this.entries.set(key, value);
    return this;
  }

  get(key: string): string {
    const label = this.entries.get(key);
    if (!label) {
      console.error(`Le dictionnaire ${this.title} ne contient pas l'entrée : "${key}"`);
    }
    return label;
  }

  isEmpty() {
    return this.entries.size === 0;
  }
}
