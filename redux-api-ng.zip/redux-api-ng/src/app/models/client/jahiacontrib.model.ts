export class JahiaContrib {
  code: string;
  contentHtml: string;
}
