import {Actions as ApiActions, ApiAction} from 'redux-api-ng';

export const HELLO_SAY = 'HELLO_SAY';

export class HelloPayload {
  who: string;
  boom?: boolean;
}


export class HelloFetch extends ApiAction<string, HelloPayload> {

  constructor(critere: HelloPayload) {
    super(HELLO_SAY, 'api_hello', critere);
    this.payload.url = `/say/${critere.who}`;
    if (critere.boom) {
      this.payload.url += '?boom=1';
    }
    this.payload.transcoder = this.extractMessage.bind(this);
  }

  extractMessage(object: any) {
    return object.message;
  }
}


export type Actions = HelloFetch | ApiActions;
