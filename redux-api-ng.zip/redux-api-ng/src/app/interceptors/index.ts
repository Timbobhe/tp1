import { LoaderHttpInterceptor } from '@ag2rlamondiale/metis-ng';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { WithCredentialsHttpInterceptor2 } from './with-credentials/with-credentials-http.interceptor';

export const HttpInterceptorProviders2 = [
  {
    provide: HTTP_INTERCEPTORS,
    useClass: WithCredentialsHttpInterceptor2,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: LoaderHttpInterceptor,
    multi: true
  }
];
