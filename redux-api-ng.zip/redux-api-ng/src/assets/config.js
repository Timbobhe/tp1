window.__app_env = {};
window.__app_env.config = {
  backend: {
    endpoints: {
      loginUrl: '/api/secure/redirectToJahia',
      casClientLogout: '/api/logout',
      demoResource: '/api/secure/demo',
      api_contrib_jahia: '/api/jahia',
      api_dictionnaire_jahia: '/cms/render/live/fr'
    }
  }
};
