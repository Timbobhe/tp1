window.__env = {};
window.__env.config = {
  backend_base: {
    protocol: 'http',
    host: 'localhost',
    port: '8080',
    contextRoot: 'eib'
  },
  jahia_endpoint: 'http://cdr-dev-jahia7:8080',
  // api_contrib_jahia: 'http://localhost:8080/ecrs/api/jahia',
  api_contrib_jahia: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  jahia_files: 'http://cdr-dev-jahia7:8080/',
  api_dictionnaire_jahia: 'http://cdr-dev-jahia7:8080/cms/render/live/fr',
  api_hello: 'http://localhost:8080/ecrs/api/hello',

  // Utilisation des l'API performance pour mark et measure
  performance: {
    active: true,
    log: true,
    maxMeasure: 200
  }
};
