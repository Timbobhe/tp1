# ReduxApiNg : CHANGELOG

## 2.4.0 (13/11/19)

- Nouvel attribut `severity` sur l'`ApiActionPayload`. Permettra d'afficher une page d'erreur par exemple selon niveau de gravité de l'action.

___

## 2.3.0 (12/11/19)

- Simplification des tests des `ApiAction` avec `ActionTester`

___

## 2.2.0 (12/11/19)

- Simplification du constructeur de la classe `ApiAction` : Il n'est plus nécessaire de passer une instance de `ApiActionPayload` en 1er argument

___

## 2.1.0 (07/11/19)

- Fourniture de la fonction `storeApiLogger` pour une meilleure log des API Actions, ex : `**API_[START]::LABEL**` (affiche le LABEL directement dans le titre de l'action)
