package fr.ag2rlamondiale.erb.client.business.impl;


import fr.ag2rlamondiale.erb.client.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RechercherHabiliFacadeImpl implements IRechercherHabiliFacade {
    @Autowired
    private IRechercherHabiliPersClient rechercherHabiliPersClient;

    @Override
    public PersonnePhysique rechercherParIdGdi(String idGdi) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setIdGdi(idGdi);
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }

}
