package fr.ag2rlamondiale.erb.client.mapping.habilitation;

import fr.ag2rlamondiale.erb.client.business.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.trm.domain.habilitation.CreerHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.ArrayList;
import java.util.List;

@Mapper(componentModel = "spring")
public abstract class CreerHabiliPersMapper {

    @Mapping(source = "identiteNumerique.login", target = "login")
    @Mapping(source = "identiteNumerique.identifiantFournisseurIdentiteNumerique", target = "identifiantFournisseurIdentiteNumerique")
    @Mapping(source = "personnePhysiqueConsult.nom", target = "nom")
    @Mapping(source = "personnePhysiqueConsult.prenom", target = "prenom")
    @Mapping(source = "personnePhysiqueConsult.codeSexe", target = "codeSexe")
    @Mapping(source = "personnePhysiqueConsult.codePostalNaissance", target = "codePostalCommuneNaissance")
    @Mapping(source = "personnePhysiqueConsult.dateDeNaissance", target = "dateNaissance")
    @Mapping(source = "personnePhysiqueConsult.emailSigElec", target = "email")
    @Mapping(expression = "java(personnePhysiqueConsult.getCodeSilo().egesper().getCode())", target = "identifiantSilo.typeId")
    @Mapping(source = "personnePhysiqueConsult.id", target = "identifiantSilo.valeurId")
    @Mapping(source = "personnePhysiqueConsult", target = "telephones", qualifiedByName = "mapTelephones")
    public abstract CreerHabiliIn map(PersonnePhysiqueConsult personnePhysiqueConsult, IdentiteNumeriqueHabilitation identiteNumerique);


    @Named("mapTelephones")
    public List<String> mapTelephones(PersonnePhysiqueConsult ppc) {
        final List<String> tels = new ArrayList<>(3);
        if (StringUtils.isNotBlank(ppc.getTelPortable())) {
            tels.add(ppc.getTelPortable());
        }
        if (StringUtils.isNotBlank(ppc.getTelPersonnel())) {
            tels.add(ppc.getTelPersonnel());
        }
        if (StringUtils.isNotBlank(ppc.getTelPro())) {
            tels.add(ppc.getTelPro());
        }
        return tels;
    }
}
