package fr.ag2rlamondiale.erb.client.business;

import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;


public interface IRechercherHabiliFacade {

    PersonnePhysique rechercherParIdGdi(String idGdi);


}
