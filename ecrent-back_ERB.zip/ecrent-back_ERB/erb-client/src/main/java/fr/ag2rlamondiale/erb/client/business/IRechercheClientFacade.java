package fr.ag2rlamondiale.erb.client.business;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;

public interface IRechercheClientFacade {
    /**
     * @param idGdi
     * @return
     * @throws CommonException
     */
    PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException;

}
