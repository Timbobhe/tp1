package fr.ag2rlamondiale.erb.client.mapping;

import fr.ag2rlamondiale.erb.client.dto.ClientDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.security.UserContext;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

@Mapper(componentModel = "spring")
public interface ClientMapper {

    @Mapping(source = "silos", target = "silos", qualifiedByName = "CodeSilo")
    ClientDto map(UserContext userContext);

    @Named("CodeSilo")
    default String map(CodeSiloType codeSiloType) {
        return codeSiloType != null ? codeSiloType.name() : null;
    }
}


