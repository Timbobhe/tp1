package fr.ag2rlamondiale.erb.client.business.impl;

import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.erb.client.business.IRechercheClientFacade;
import fr.ag2rlamondiale.erb.client.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.erb.client.exception.UtilisateurException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static fr.ag2rlamondiale.trm.utils.ErrorConstantes.UTILISATEUR_NON_TROUVE;
@Service
public class RechercheClientFacadeImpl  implements IRechercheClientFacade {


    @Autowired
    private IRechercherHabiliFacade habiliService;

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException {
        PersonnePhysique user = habiliService.rechercherParIdGdi(idGdi);
        if (null == user || null == user.getNumeroPersonneEre() && null == user.getNumeroPersonneMdpro()) {
            throw new UtilisateurException(UTILISATEUR_NON_TROUVE);
        }
        return user;
    }
}
