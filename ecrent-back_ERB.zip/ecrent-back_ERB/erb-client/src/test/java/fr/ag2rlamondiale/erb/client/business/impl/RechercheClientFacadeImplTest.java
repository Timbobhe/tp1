package fr.ag2rlamondiale.erb.client.business.impl;


import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.CommonException;
import fr.ag2rlamondiale.erb.client.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.client.soap.IRecherchePersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IRechercherPPSiloClient;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RechercheClientFacadeImplTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";

    @Mock
    private IRecherchePersonneClient recherchePersonneClient;

    @Mock
    private UserContextHolder userContextHolder;
    @Mock
    private IRechercherHabiliFacade habiliService;

    @InjectMocks
    RechercheClientFacadeImpl clientFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Test
    public void testRecupereListeContrat() throws CommonException {
        when(habiliService.rechercherParIdGdi(ID_GDI))
                .thenAnswer((Answer<PersonnePhysique>) invocation -> {
                    PersonnePhysique personne = new PersonnePhysique();
                    personne.setNumeroPersonneEre(NUM_PERS_ERE);
                    return personne;
                });

        PersonnePhysique retour = clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);

        Assert.assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail1() throws Exception {
        when(habiliService.rechercherParIdGdi(any()))
                .thenReturn(null);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail2() throws Exception {

        PersonnePhysique user = new PersonnePhysique();
        when(habiliService.rechercherParIdGdi(any()))
                .thenReturn(user);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }


}