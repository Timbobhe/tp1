package fr.ag2rlamondiale.erb.security;

import fr.ag2rlamondiale.erb.client.business.IRechercheClientFacade;
import fr.ag2rlamondiale.metis.boot.security.dao.IApplicationRolesRetriever;
import fr.ag2rlamondiale.metis.boot.security.dao.MetisBootCasUserDetailsService;
import fr.ag2rlamondiale.metis.boot.security.dao.UserDetailsImpl;
import fr.ag2rlamondiale.trm.cache.ITrackUserCache;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ErbCasUserDetailsService extends MetisBootCasUserDetailsService {
    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private UserSecurityService securityService;

    @Autowired
    private PreCache preCache;

    @Autowired
    private ITrackUserCache trackUserCache;

    @Autowired
    private IRechercheClientFacade clientFacade;


    /**
     * Constructeur
     *
     * @param applicationRolesRetriever retriever des roles applicatifs
     */
    public ErbCasUserDetailsService(IApplicationRolesRetriever applicationRolesRetriever) {
        super(new String[]{"roles"}, applicationRolesRetriever);
    }

    @Override
    public UserDetails loadUserDetails(CasAssertionAuthenticationToken authentication) {
        long start = System.currentTimeMillis();
        log.info("Tentative de connexion avec {}", authentication);
        final UserDetails userDetails = basicLoadUserDetails(authentication);
        trackUserCacheImpersonation(authentication).run();
        log.info("Connexion réussie pour {} en {} ms", userDetails, System.currentTimeMillis() - start);
        return userDetails;
    }


    private UserDetails basicLoadUserDetails(CasAssertionAuthenticationToken authentication) {
        try {
            SecurityContextHolder.getContext().setAuthentication(authentication);
            UserDetailsImpl userDetails = (UserDetailsImpl) super.loadUserDetails(authentication);
            logTentativeConnexion(authentication, userDetails);
            if (userDetails.getAuthorities().isEmpty()) {
                return new ErbUserDetails(userDetails, true);
            }
            if (AuthentificationUtils.hasRole(userDetails, RolesEnum.PILOTAGE_ERE)) {
                userContextHolder.get().setPilotage(true);
                return new ErbUserDetails(userDetails, true);
            }
            Map<String, Object> casMap = userDetails.getAttributesMap();
            PersonnePhysique personnePhysique;
            String idGdi;
            userContextHolder.get().setHasIdGdi(true);
            if (AuthentificationUtils.isUserImpersonated(userDetails)) {
                userContextHolder.get().setImpersonation(true);
                userContextHolder.get().setExternalUid(getExternalUid(userDetails));
            }
            idGdi = (String) casMap.get("uid");
            Objects.requireNonNull(idGdi, "L'idGDI du jeton CAS est null");
            userContextHolder.get().setIdGdi(idGdi); // pour la traceWs
            trackUserCache.clearUserCache(idGdi);
            personnePhysique = clientFacade.rechercherPersonnePhysiqueParIdGdi(idGdi);
            preCache.start(trackUserCacheImpersonation(authentication));
            securityService.initSecurityContext(idGdi, personnePhysique);

            return new ErbUserDetails(userDetails, true);

        } catch (Exception e) {
            log.error("Erreur d'authentication", e);
            SecurityContextHolder.getContext().setAuthentication(null);
            throw new UsernameNotFoundException("Erreur d'authentication", e);
        }
    }


    private void logTentativeConnexion(Authentication authentication, UserDetailsImpl userDetails) {
        Collection<String> roles = new ArrayList<>();
        if (userDetails.getAuthorities() != null) {
            roles = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.toList());
        }
        final Map<String, Object> casMap = userDetails.getAttributesMap();
        log.info("Detail Tentative de connexion pour {} avec {}, roles = {}", authentication, casMap, roles);
    }

    private String getExternalUid(UserDetailsImpl userDetails) {
        return (String) userDetails.getAttributesMap().get("externalUid");
    }

    private Runnable trackUserCacheImpersonation(Authentication authentication) {
        final UserContext userContext = userContextHolder.get();
        final String source = authentication.getName();
        final String cible = userContext.getIdGdi();
        if (userContext.isImpersonation() && !cible.equals(source)) {
            return () -> trackUserCache.migrateTrackUserCache(source, cible);
        }
        return () -> {
        };
    }

}

