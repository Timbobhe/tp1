package fr.ag2rlamondiale.erb.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class DetailArrerage {
    private String idArrerageRente;
    private String idArrerageMajoration;
    private Date dateMiseEnPaiementArrerage;
    //private Date dateMiseEnPaiementArrerageMajoration;

}
