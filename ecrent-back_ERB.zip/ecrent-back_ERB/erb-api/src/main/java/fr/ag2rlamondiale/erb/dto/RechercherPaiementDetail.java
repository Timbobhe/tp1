package fr.ag2rlamondiale.erb.dto;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.*;

@Data
@Builder(toBuilder = true)
@ToString(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
public class RechercherPaiementDetail {
    ContratParcoursDto contratParcours;
    DetailArrerage arrerageId;
}
