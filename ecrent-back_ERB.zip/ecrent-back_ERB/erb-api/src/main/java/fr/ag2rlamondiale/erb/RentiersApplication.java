package fr.ag2rlamondiale.erb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentiersApplication {
	public static void main(String[] args) {
		SpringApplication.run(RentiersApplication.class, args);
	}
}
