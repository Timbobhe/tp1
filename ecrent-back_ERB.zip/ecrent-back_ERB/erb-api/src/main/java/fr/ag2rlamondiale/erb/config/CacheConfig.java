package fr.ag2rlamondiale.erb.config;

import fr.ag2rlamondiale.trm.InterceptorOrders;
import fr.ag2rlamondiale.trm.cache.CacheConstants;
import fr.ag2rlamondiale.trm.cache.WithMethodSimpleKeyGenerator;
import fr.ag2rlamondiale.trm.client.soap.config.XCallerSimpleKeyGenerator;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.cache.jcache.JCacheManagerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;

@Configuration
@EnableCaching(order = InterceptorOrders.DEFAULT_CACHEABLE_ORDER)
public class CacheConfig extends CachingConfigurerSupport {
    @Value("classpath:ehcache.xml")
    Resource ehcacheConfig;


    @SneakyThrows
    @Primary
    @Bean("ehCacheManager")
    @Override
    public JCacheCacheManager cacheManager() {
        org.springframework.cache.jcache.JCacheCacheManager cacheCacheManager = new JCacheCacheManager();
        final JCacheManagerFactoryBean factory = new JCacheManagerFactoryBean();
        factory.setCacheManagerUri(ehcacheConfig.getURI());
        factory.afterPropertiesSet();
        cacheCacheManager.setCacheManager(factory.getObject());
        return cacheCacheManager;
    }


    @Bean(CacheConstants.DEFAULT_KEY_GENERATOR)
    public KeyGenerator defaulKeyGenerator() {
        return new WithMethodSimpleKeyGenerator();
    }

    @Bean(CacheConstants.XCALLER_SIMPLE_KEY_GENERATOR)
    public KeyGenerator xcallerSimpleKeyGenerator() {
        return new XCallerSimpleKeyGenerator();
    }
}
