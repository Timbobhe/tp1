package fr.ag2rlamondiale.erb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IOperationFacade;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.echeancier.DemandeSiloRequestDto;
import fr.ag2rlamondiale.trm.domain.operation.CodeSituationOperationType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.operation.RechercherOperationsDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Objects;


@Service
public class OperationFacadeImpl implements IOperationFacade {

    @Autowired
    private IOperationsClient operationClient;

    @Override
    public List<Operation> findOperationsToReCalculate(String idAssure, CodeSiloType codeSiloType) {
        Objects.requireNonNull(idAssure);
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(codeSiloType);
        demande.setIdAssure(idAssure);
        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);
        setCodeSituationOperation(codeSiloType, rechercherOperationsDto);
        Date now = new Date();
        rechercherOperationsDto.setMinDate(Date.from(now.toInstant().atZone(ZoneId.systemDefault()).minusYears(3).toInstant()));
        rechercherOperationsDto.setMaxDate(now);

        try {
            return operationClient.rechercherOperations(rechercherOperationsDto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException();
        }
    }

    private void setCodeSituationOperation(CodeSiloType codeSiloType, RechercherOperationsDto rechercherOperationsDto) {
        if (CodeSiloType.ERE.equals(codeSiloType)) {
            rechercherOperationsDto.setCodeSituationOperationsERE(Collections.singletonList(CodeSituationOperationType.ARECAL.name()));
        } else if (CodeSiloType.MDP.equals(codeSiloType)) {
            rechercherOperationsDto.setCodeSituationOperationsMDP(Collections.singletonList(CodeSituationOperationType.ARECAL.name()));
        }
    }
}
