package fr.ag2rlamondiale.erb.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.ag2rlamondiale.erb.client.ErbClientConfig;
import fr.ag2rlamondiale.erb.contrat.ErbContratConfig;
import fr.ag2rlamondiale.erb.pfs.ErbPfsConfig;
import fr.ag2rlamondiale.erb.web.filter.ClientRequestTracking;
import fr.ag2rlamondiale.erb.web.filter.ThreadLocalFilter;
import fr.ag2rlamondiale.trm.CoreConfig;
import fr.ag2rlamondiale.trm.PfsConfig;
import fr.ag2rlamondiale.trm.cas.CasMockConfig;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.method.HandlerTypePredicate;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.util.HttpSessionMutexListener;

@Configuration
@Import({CoreConfig.class, PfsConfig.class, ErbPfsConfig.class, CacheConfig.class, CasMockConfig.class, ErbClientConfig.class, ErbContratConfig.class})
public class ApiConfig implements WebMvcConfigurer {

    static {
        SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
    }

    @Bean
    public RequestContextListener requestContextListener() {
        return new RequestContextListener();
    }

    @Bean
    public HttpSessionMutexListener httpSessionMutexListener() {
        return new HttpSessionMutexListener();
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }

    @Bean(name = "theadLocalFilter")
    public ThreadLocalFilter threadLocalFilter() {
        return new ThreadLocalFilter();
    }

    @Bean(name = "clientRequestFilter")
    public ClientRequestTracking clientRequestTracking() {
        return new ClientRequestTracking();
    }

    @Bean(name = "multipartResolver")
    public CommonsMultipartResolver multipartResolver() {
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
        multipartResolver.setMaxUploadSize(-1); // g&eacute;rer applicativement
        return multipartResolver;
    }

    /**
     * https://reflectoring.io/configuring-localdate-serialization-spring-boot/
     * https://docs.spring.io/spring-boot/docs/current-SNAPSHOT/reference/htmlsingle/#howto.spring-mvc.customize-jackson-objectmapper
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return mapper;
    }

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.addPathPrefix("/api", HandlerTypePredicate.forAnnotation(RestController.class));
    }
}
