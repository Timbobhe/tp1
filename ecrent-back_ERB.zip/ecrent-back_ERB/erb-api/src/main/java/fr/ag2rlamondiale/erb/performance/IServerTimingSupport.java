package fr.ag2rlamondiale.erb.performance;

public interface IServerTimingSupport {

    String ATTRIBUTE_NAME_START_REQ_TIME = "X-REQUEST-START-TIME";

    boolean isActive();
}
