package fr.ag2rlamondiale.erb.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.InfoContratsDetailDTO;
import fr.ag2rlamondiale.erb.dto.HistoriquePaiement;
import fr.ag2rlamondiale.erb.dto.PaiementDetailDto;
import fr.ag2rlamondiale.erb.dto.RechercherPaiementDetail;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;

import java.util.List;

public interface IContratDetailsFacade {
    InfoContratsDetailDTO start() throws TechnicalException;

    List<ContratRente> rechercherAllContratsRentes() throws TechnicalException;

    List<HistoriquePaiement> rechercherPaiementsRecus(ContratParcoursDto contratRente) throws TechnicalException;

    PaiementDetailDto getPaiementsDetailsInfo(RechercherPaiementDetail rechercherPaiementDetail) throws TechnicalException;
}
