package fr.ag2rlamondiale.erb.business.impl;

import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;

@Component
@RequestScope
@Data
public class CalculerEncoursParamsHolder {
    private boolean activeGestionErreurOperationRecalculer;
}
