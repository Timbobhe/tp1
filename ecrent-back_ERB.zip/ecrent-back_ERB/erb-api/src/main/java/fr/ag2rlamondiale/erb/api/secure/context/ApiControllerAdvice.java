package fr.ag2rlamondiale.erb.api.secure.context;

import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.SecuredParam;
import fr.ag2rlamondiale.trm.security.SecurityParamType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

@ControllerAdvice({"fr.ag2rlamondiale.erb.api.secure", "fr.ag2rlamondiale.trm.api.secure"})
public class ApiControllerAdvice {
    @Autowired
    private RequestContextHolder requestContext;

    @ModelAttribute
    @Secure
    public void requestContext(
            @RequestParam(required = false)
            @SecuredParam(paramType = SecurityParamType.CONTRAT) String contrat,
            @RequestParam(required = false)
            @SecuredParam(paramType = SecurityParamType.IDASSURE) String compartiment) {
        requestContext.setContrat(contrat);
        requestContext.setCompartiment(compartiment);
    }

}
