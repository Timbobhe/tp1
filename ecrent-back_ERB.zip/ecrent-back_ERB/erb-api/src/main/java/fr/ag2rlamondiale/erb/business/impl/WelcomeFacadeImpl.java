package fr.ag2rlamondiale.erb.business.impl;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.erb.business.IWelcomeFacade;

@Service
public class WelcomeFacadeImpl implements IWelcomeFacade {

	@Override
	public String welcomeToApp(String appName) {
		return String.format("Welcome to %s!", appName);
	}
}
