package fr.ag2rlamondiale.erb.business;

public interface IWelcomeFacade {
	String welcomeToApp(String appName); 
}
