package fr.ag2rlamondiale.erb.trm;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ErbSupplierLibService implements ISupplierLibService {

    @Value("${ecrent.front.url}")
    private String urlFront;

    @Override
    public String getCodeCassiniAppli() {
        return "A1573";
    }

    @Override
    public String getLibelleAppli() {
        return "ESPACE RENTIERS";
    }

    @Override
    public String getUrlFront() {
        return urlFront;
    }
}
