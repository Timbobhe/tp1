package fr.ag2rlamondiale.erb.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource({"classpath:webservices-pfs.properties", "classpath:webservices-rest.properties", "classpath:application-contextual-values.properties"})
public class PropertyConfig {
	
}
