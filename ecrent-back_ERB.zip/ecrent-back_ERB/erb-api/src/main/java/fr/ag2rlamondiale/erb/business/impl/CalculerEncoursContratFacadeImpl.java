package fr.ag2rlamondiale.erb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IOperationFacade;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.dto.OperationToRecalculate;
import fr.ag2rlamondiale.trm.business.IBaseCalculerEncoursContratFacade;
import fr.ag2rlamondiale.trm.business.impl.BaseCalculerEncoursContratFacadeImpl;
import fr.ag2rlamondiale.trm.client.soap.ICalculerEncoursContratClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.*;


@Slf4j
@Service
@Primary
@AppImpl(implemtationOf = IBaseCalculerEncoursContratFacade.class)
public class CalculerEncoursContratFacadeImpl extends BaseCalculerEncoursContratFacadeImpl implements ICalculerEncoursContratFacade {

    public static final String ENCOURS_CONTRAT_EN_ERREUR = "Service calculerEncoursContrat en erreur : {}";
    private static final String ENCOURS_OP_A_RECALCULER = "ERR_90020";

    @Autowired
    private CalculerEncoursParamsHolder calculerEncoursParamsHolder;

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private ICalculerEncoursContratClient calculerEncoursContratClient;


    @Override
    public CompteEncours getCompteEncoursNonPacte(ContratRente contratRente) {
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        dto.setCodeSiloType(contratRente.getCodeSilo());
        if (contratRente.isMdpro()) {
            dto.setIdContrat(contratRente.getId());
        } else {
            dto.setIdAssure(contratRente.getIdentifiantAssure());
        }
        return calculerEncoursContrat(dto);
    }

    public CompteEncours calculerEncoursContrat(CalculerEncoursContratDto dto) {
        try {
            return calculerEncoursContratClient.calculerEncoursContrat(dto);
        } catch (TechnicalException e) {
            CompteEncours compteEncours = new CompteEncours();
            OperationToRecalculate operationToRecalculate = hasOperationToRecalculate(e, dto);
            if (operationToRecalculate.isHasOperation()) {
                Date dayBefore = Date.from(operationToRecalculate.getOperation().getDate()
                        .toInstant().atZone(ZoneId.systemDefault()).minusDays(1).toInstant());
                dto.setDateEncours(dayBefore);
                compteEncours = basicCalculerEncours(dto);
            } else {
                setEncoursInError(e, compteEncours);
            }
            return compteEncours;
        }
    }

    private CompteEncours basicCalculerEncours(CalculerEncoursContratDto dto) {
        try {
            return calculerEncoursContratClient.calculerEncoursContrat(dto);
        } catch (TechnicalException e) {
            log.error(ENCOURS_CONTRAT_EN_ERREUR, e.toString());
            CompteEncours compteEncours = new CompteEncours();
            compteEncours.setEncoursEnErreur(true);
            return compteEncours;
        }
    }

    @Override
    public CompteEncours getCompteEncoursCompartiment(Compartiment compartiment) {
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        final ContratRente contratRente = compartiment.getContratRente();
        dto.setCodeSiloType(contratRente.getCodeSilo());
        if (contratRente.isMdpro()) {
            dto.setIdContrat(contratRente.getId());
        } else {
            dto.setIdAssure(compartiment.getIdentifiantAssure());
        }
        return calculerEncoursContrat(dto);
    }

    @Override
    public Encours getEncoursCompartimentEreNonPacte(Compartiment compartiment) {
        final CompteEncours compteEncours = getCompteEncoursCompartiment(compartiment);
        BasicEncours res = new BasicEncours();
        if (compteEncours.isEnErreur()) {
            res.setEnErreur(true);
            return res;
        }
        if (CompartimentType.C1.equals(compartiment.getType()) || CompartimentType.C4.equals(compartiment.getType())) {
            res.setHasVLVersement(compteEncours.hasVLVersement());
        }
        res.setMontant(BigDecimal.ZERO);
        res.setDate(compteEncours.getDate());

        ContributionType.forCompartimentNonPacte(compartiment.getType()).forEach(contributionType -> {
            final BigDecimal mnt = getMontantByCodeContributionInv(compteEncours, contributionType.getCode());
            res.addMontant(mnt);
        });

        return res;
    }

    private BigDecimal getMontantByCodeContributionInv(CompteEncours compteEncours, String codeContribution) {
        if (compteEncours.getOccurStructInvList() == null) {
            return BigDecimal.ZERO;
        }
        return compteEncours.getOccurStructInvList().stream()
                .filter(occ -> occ.getContributionInv() != null
                        && codeContribution.equals(occ.getContributionInv().getCodeContributionInv()))
                .map(OccurStructInvDto::getMontantOccurSupportInv)
                .findFirst()
                .orElse(BigDecimal.ZERO);
    }


    @Override
    public EncoursDto getEncoursDto(ContratRente contratRente, List<CompartimentType> compartimentTypes) {
        List<EncoursDto> encoursCompartiments = new ArrayList<>();
        for (Compartiment compartiment : contratRente.compartiments(compartimentTypes)) {
            EncoursDto compteEncours = getEncoursDto(compartiment);
            encoursCompartiments.add(compteEncours);
        }
        boolean encoursEnErreur = encoursCompartiments.stream().anyMatch(EncoursDto::isEncoursEnErreur);
        if (!encoursEnErreur) {
            return EncoursDto.builder()
                    .montantEncours(sommeEncoursCompartiments(encoursCompartiments))
                    .dateEncours(encoursCompartiments.get(0).getDateEncours())
                    .encoursEnErreur(false)
                    .build();
        }
        return EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
    }


    @Override
    public EvolutionCompteEncours getEncoursAtDate(IContrat iContrat, Date date) {
        return null;
    }

    @Override
    public EncoursDto getEncoursDto(ContratRente contratRente) {
        if (contratRente.isEre() && !contratRente.isPacte() || contratRente.isMdpro()) {
            CompteEncours compteEncours = this.getCompteEncoursNonPacte(contratRente);
            return new EncoursDto(compteEncours);
        } else {
            return this.getEncoursDtoPacte(contratRente);
        }
    }

    @Override
    public EncoursDto getEncoursDtoPacte(ContratRente contratRente) {
        List<EncoursDto> encoursCompartiments = new ArrayList<>();
        for (Compartiment compartiment : contratRente.getCompartiments()) {
            CompteEncours compteEncours = getCompteEncoursCompartiment(compartiment);
            encoursCompartiments.add(new EncoursDto(compteEncours));
        }
        boolean encoursEnErreur = encoursCompartiments.stream().anyMatch(EncoursDto::isEncoursEnErreur);
        if (!encoursEnErreur) {
            return EncoursDto.builder()
                    .montantEncours(sommeEncoursCompartiments(encoursCompartiments))
                    .dateEncours(encoursCompartiments.get(0).getDateEncours())
                    .encoursEnErreur(false)
                    .build();
        }
        return EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
    }

    @Override
    public EncoursDto getEncoursDto(Compartiment compartiment) {
        if (compartiment.isMdpro() || compartiment.isERE() && compartiment.isPacte()) {
            CompteEncours compteEncours = this.getCompteEncoursCompartiment(compartiment);
            return new EncoursDto(compteEncours);
        } else if (compartiment.isERE() && !compartiment.isPacte()) {
            Encours encoursEreNonPacte = this.getEncoursCompartimentEreNonPacte(compartiment);
            return new EncoursDto(encoursEreNonPacte);
        }
        return EncoursDto.builder()
                .encoursEnErreur(false)
                .montantEncours(0.0)
                .build();
    }

    private Double sommeEncoursCompartiments(List<EncoursDto> encoursDtoList) {
        Double encours = 0.0;
        for (EncoursDto encoursDto : encoursDtoList) {
            if (!encoursDto.isEncoursEnErreur()) {
                encours += encoursDto.getMontantEncours();
            }
        }
        return encours;
    }

    private OperationToRecalculate hasOperationToRecalculate(TechnicalException e, CalculerEncoursContratDto dto) {
        OperationToRecalculate operationToRecalculate = new OperationToRecalculate();
        if (hasErrorEncoursToRecalculate(e) && isAllowsToRecalculateEncours()) {
            List<Operation> operations = operationFacade.findOperationsToReCalculate(dto.getIdAssure(), dto.getCodeSiloType());
            if (!CollectionUtils.isEmpty(operations)) {
                Optional<Operation> oldestOperationOfPastThreeMonths = operations.stream()
                        .filter(this::isOperationOfLastThreeMonths)
                        .min(Comparator.comparing(Operation::getDate));
                operationToRecalculate.setHasOperation(oldestOperationOfPastThreeMonths.isPresent());
                operationToRecalculate.setOperation(oldestOperationOfPastThreeMonths.orElse(null));
            }
        }
        return operationToRecalculate;
    }

    private boolean hasErrorEncoursToRecalculate(TechnicalException e) {
        return e.getCause() != null && e.getCause().getMessage() != null
                && e.getCause().getMessage().contains(ENCOURS_OP_A_RECALCULER);
    }

    private boolean isAllowsToRecalculateEncours() {
        return calculerEncoursParamsHolder != null && calculerEncoursParamsHolder.isActiveGestionErreurOperationRecalculer();
    }

    private boolean isOperationOfLastThreeMonths(Operation operation) {
        return operation.getDate().after(Date.from(DateUtils.getTodayTimelessDate()
                .toInstant().atZone(ZoneId.systemDefault()).minusMonths(3).toInstant()))
                && operation.getDate().before(DateUtils.getTodayTimelessDate());
    }

    private void setEncoursInError(TechnicalException e, CompteEncours compteEncours) {
        log.error(ENCOURS_CONTRAT_EN_ERREUR, e.toString());
        compteEncours.setEncoursEnErreur(true);
    }

}
