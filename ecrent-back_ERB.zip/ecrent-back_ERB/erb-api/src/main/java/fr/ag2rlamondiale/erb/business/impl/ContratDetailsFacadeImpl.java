package fr.ag2rlamondiale.erb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IContratDetailsFacade;
import fr.ag2rlamondiale.erb.contrat.business.IContratFacade;
import fr.ag2rlamondiale.erb.contrat.business.IFilterContrats;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.ContratDetailDTO;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.InfoContratsDetailDTO;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.Periodicite;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratDetailMapper;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratParcoursMapper;
import fr.ag2rlamondiale.erb.dto.*;
import fr.ag2rlamondiale.erb.dto.DetailArrerage;
import fr.ag2rlamondiale.erb.dto.HistoriquePaiement;
import fr.ag2rlamondiale.erb.pfs.client.rest.IConsulterOptionRenteContratClient;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.GarantiesType;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.client.rest.IConsulterContratClient;
import fr.ag2rlamondiale.trm.client.rest.IRechercherPrestationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrattechnique.AnnuiteRente;
import fr.ag2rlamondiale.trm.domain.contrattechnique.InfoRente;
import fr.ag2rlamondiale.trm.domain.contrattechnique.RechercherContratTechniqueIn;
import fr.ag2rlamondiale.trm.domain.contrattechnique.RechercherContratTechniqueOut;
import fr.ag2rlamondiale.trm.domain.encours.EncoursComparator;
import fr.ag2rlamondiale.trm.domain.prestations.*;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.erb.pfs.domain.rente.GarantiesType.getDescriptionFromCodes;

@Service
public class ContratDetailsFacadeImpl implements IContratDetailsFacade {

    private static final String ARRERAGE_A_JOUR = "ARRAJ";
    private static final String TYPE_ANNUITE_RENTE = "RENTE";
    private static final String TYPE_ANNUITE_MAJORATION = "MAJORATION";
    private static final String TYPE_ARRERAGE_RENTES = "RENTES";
    private static final String TYPE_ARRERAGE_MAJORATION = "MAJORATION";
    private static final String TYPE_STATUT_PAIEMENT_PAYE = "P";
    private static final String TYPE_STATUT_PAIEMENT_REGLE = "R";

////           Paiement de la rente sans majoration
//    private static final String CONTRAT_ID = "EV016279510000";
//    private static final String PERSON_ID = "P5149814";

    //    Paiement de la rente avec majoration en montant
//    private static final String CONTRAT_ID = "EV014908609000";
//    private static final String PERSON_ID = "P5149365";
//
//    Paiement de la rente avec majoration cas test
//    private static final String CONTRAT_ID = "EV002365927000";
//    private static final String PERSON_ID = "P3963167";
//

    //    Paiement de la rente avec regularisation
    private static final String CONTRAT_ID = "EV014214768000";
    private static final String PERSON_ID = "P4062908";


//    //Paiement de la rente avec majoration en pourcentage
    // private static final String CONTRAT_ID = "EV012221030000";
    //private static final String PERSON_ID = "P4093124";

////    //Paiement de la rente test demo
//    private static final String CONTRAT_ID = "EV017878846000";
//    private static final String PERSON_ID = "P4164202";

    ////   //Paiement de la rente avec fiscalité article39
//    private static final String CONTRAT_ID = "EV015014824000";
//    private static final String PERSON_ID = "P5143418";

    @Autowired
    private IContratFacade contratFacade;

    @Autowired
    private CalculerEncoursParamsHolder calculerEncoursParamsHolder;

    @Autowired
    private RequestContextHolder requestContext;

    @Autowired
    private ContratDetailMapper contratDetailMapper;

    @Autowired
    private ContratParcoursMapper contratParcoursMapper;

    @Autowired
    private IRechercherPrestationsClient rechercherPrestationsClient;

    @Autowired
    private IConsulterContratClient consulterContratClient;
    private String type = "";

    @Autowired
    private IConsulterOptionRenteContratClient consulterOptionRenteContratClient;

    @Override
    public InfoContratsDetailDTO start() throws TechnicalException {
        List<ContratRente> contratRentes = rechercherAllContratsRentes().stream()
                .filter(contratRente -> contratRente.isEre() || (contratRente.isMdpro() && !contratRente.isClasseAutreContrat())
                ).collect(Collectors.toList());

        calculerEncoursParamsHolder.setActiveGestionErreurOperationRecalculer(true);

        ContratDetailDTO contratDetailPrincipale;
        String contratId = requestContext.getContrat();
        if (contratId != null) {
            contratDetailPrincipale = contratRentes.stream()
                    .filter(contratRente -> contratId.equals(contratRente.getId()))
                    .findFirst()
                    .map(this::mapToContratDetail)
                    .orElseThrow(NoSuchElementException::new);
        } else {
            contratDetailPrincipale = contratRentes.stream()
                    .map(this::mapToContratDetail)
                    .findFirst()
                    .orElseThrow(NoSuchElementException::new);
        }

        ConsulterOptionRenteIn optionRenteIn = ConsulterOptionRenteIn.builder()
                .idContrat(contratDetailPrincipale.getNomContrat())
                .idPersonne(contratDetailPrincipale.getPersonId())
                .build();
        ConsulterOptionRenteContratDto renteContratDto = consulterOptionRenteContratClient.consulterOptionRenteContrat(optionRenteIn);
        if (Objects.nonNull(renteContratDto) && CollectionUtils.isNotEmpty(renteContratDto.getOptionRentes())) {
            List<String> codesGaranties = renteContratDto.getOptionRentes().stream()
                    .map(opt -> opt.getOptRenteType().getCode())
                    .distinct()
                    .collect(Collectors.toList());
            contratDetailPrincipale.setLibelleGaranties(getDescriptionFromCodes(codesGaranties).getDescription());
        } else {
            contratDetailPrincipale.setLibelleGaranties(GarantiesType.DEFAULT.getDescription());
        }

        List<ContratParcoursDto> contratParcoursDtos = contratRentes.stream()
                .filter(x -> !x.getNomContrat().equals(contratDetailPrincipale.getNomContrat()))
                .map(c -> contratParcoursMapper.map(c, true))
                .collect(Collectors.toList());

        InfoContratsDetailDTO infoContratsDetailDTO = new InfoContratsDetailDTO();
        infoContratsDetailDTO.setContrat(contratDetailPrincipale);
        infoContratsDetailDTO.setAutresContrats(contratParcoursDtos);
        return infoContratsDetailDTO;
    }

    @Override
    public List<ContratRente> rechercherAllContratsRentes() throws TechnicalException {
        IFilterContrats noFilter = contratRente -> contratRente;
        return contratFacade.rechercherContrats(noFilter);
    }

    private ContratDetailDTO mapToContratDetail(ContratRente contratRente) {
        ContratDetailDTO contratDetailDTO = contratDetailMapper.map(contratRente, false);

        //the block below should be delete when we are able to get the right rente contract information

        contratRente.setId(CONTRAT_ID);
        contratRente.setPersonId(PERSON_ID);

        RechercherPrestationsCriteresDto rechercherPrestationsCriteresDto = new RechercherPrestationsCriteresDto();
        // FIXME : L'appel du rechercherPrestationsClient c'est avec EVxxx ou RGxxx ? => EVxxx
        rechercherPrestationsCriteresDto.setIdContrat(contratRente.getId());
        rechercherPrestationsCriteresDto.setIdPersonne(contratRente.getPersonId());
        rechercherPrestationsCriteresDto.setCodeSiloType(contratRente.getCodeSilo());
        rechercherPrestationsCriteresDto.setFromEspaceRentier(true);
        PrestationsDto prestationsDto = rechercherPrestationsClient.rechercherPrestationsClient(rechercherPrestationsCriteresDto);

        Paiement dernierPaiementRente = findDernierPaiementByType(TYPE_ARRERAGE_RENTES, prestationsDto);
        Paiement dernierPaiementMajoration = findDernierPaiementByType(TYPE_ARRERAGE_MAJORATION, prestationsDto);

        if (dernierPaiementRente.getMontantPaiement() != null) {
            contratDetailDTO.setDateDernierPaiement(dernierPaiementRente.getDatePaiement());
            contratDetailDTO.setMontantDernierPaiement(dernierPaiementMajoration.getMontantPaiement() != null ?
                    dernierPaiementRente.getMontantPaiement().add(dernierPaiementMajoration.getMontantPaiement())
                    : dernierPaiementRente.getMontantPaiement());
        }


        RechercherContratTechniqueIn in = new RechercherContratTechniqueIn();
        // FIXME : L'appel du ContratTechnique c'est avec EVxxx ou RGxxx ?
        in.setIdContrat(contratRente.getId());
        in.setIdPersonne(contratRente.getPersonId());
        in.setCodeSilo(contratRente.getCodeSilo());
        in.setFromEspaceRentier(true);

        RechercherContratTechniqueOut contratTechnique = consulterContratClient.consulterContratTechnique(in);

        InfoRente infoRente = contratTechnique.getInfoRente();
        contratDetailDTO.setDateProchainPaiement(infoRente.getDateProchainPaiementRente());
        contratDetailDTO.setPeriodiciteRente(Periodicite.fromCode(infoRente.getCodePeriodicitePrestationRente()));

        BigDecimal montantDerniereAnnuite = getMontantAnnuite(contratTechnique, TYPE_ANNUITE_RENTE);

        BigDecimal montantMajoration = getMontantAnnuite(contratTechnique, TYPE_ANNUITE_MAJORATION);

        if (montantDerniereAnnuite != null) {
            contratDetailDTO.setMontantRenteAnnuelleBrute(montantMajoration != null ?
                    montantDerniereAnnuite.add(montantMajoration) : montantDerniereAnnuite);
        }

        contratDetailDTO.setTypePaiement("AUTO");
        return contratDetailDTO;
    }

    private BigDecimal getMontantAnnuite(RechercherContratTechniqueOut contratTechnique, String rente) {

        Optional<AnnuiteRente> annuiteRente = contratTechnique.getDivisionRente().stream()
                .filter(divisionRente -> rente.equals(divisionRente.getCodeDivisionRente()))
                .findFirst().flatMap(divisionRente -> divisionRente.getAnnuiteRenteList()
                        .stream()
                        .max(Comparator.comparing(AnnuiteRente::getDateFinAnnuite)));

        return annuiteRente.map(AnnuiteRente::getMontantAnnuite).orElse(null);
    }


    private Paiement findDernierPaiementByType(String type, PrestationsDto prestationsDto) {
        Paiement paiement = new Paiement();

        prestationsDto.getOccurenceReglementList().stream()
                .filter(occurReglement -> (occurReglement.getDetailArrerageRente() != null)
                        && occurReglement.getDetailArrerageRente().getLibelleTypeArrerage().equals(type)
                        && occurReglement.getDetailArrerageRente().getCodeEtatArrerage().equals(ARRERAGE_A_JOUR))
                .max(Comparator.comparing(o -> o.getDetailArrerageRente().getDateMiseEnPaiementArrerage()))
                .ifPresent(occurenceReglementDetailArrerage -> {
                    paiement.setDatePaiement(occurenceReglementDetailArrerage.getDetailArrerageRente().getDateMiseEnPaiementArrerage());

                    prestationsDto.getOccurenceReglementList().stream()
                            .filter(reglement -> reglement.getReglement() != null
                                    && reglement.getIdentifiantParent().equals(occurenceReglementDetailArrerage.getDetailArrerageRente().getIdentifiantArrerage()))
                            .findAny().flatMap(occurenceReglementPaiement -> prestationsDto.getOccurenceReglementList().stream()
                            .filter(reglement -> reglement.getPaiements() != null
                                    && reglement.getIdentifiantParent().equals(occurenceReglementPaiement.getReglement().getIdentificationReglement()))
                            .findAny()).flatMap(occurencePaiement -> occurencePaiement.getPaiements().stream().findAny())
                            .ifPresent(infoPaiement -> paiement.setMontantPaiement(infoPaiement.getMontantPaiement()));
                });

        return paiement;
    }


    private List<HistoriquePaiement> rechercherPaiements(PrestationsDto prestationsDto, String type) {
        HistoriquePaiement paiement = new HistoriquePaiement();
        return prestationsDto.getOccurenceReglementList().stream().
                filter(occurenceReglement -> occurenceReglement != null
                        && occurenceReglement.getDetailArrerageRente() != null
                        && occurenceReglement.getDetailArrerageRente().getLibelleTypeArrerage().equals(type)
                        && occurenceReglement.getDetailArrerageRente().getCodeEtatArrerage().equals(ARRERAGE_A_JOUR))
                .map(occurence -> {
                    if (type.equals(TYPE_ARRERAGE_RENTES)) {
                        paiement.setDetailArrerage(DetailArrerage.builder().
                                idArrerageRente(occurence.getDetailArrerageRente().getIdentifiantArrerage())
                                .dateMiseEnPaiementArrerage(getDatePaiement(occurence)).build());
                    } else {
                        paiement.setDetailArrerage(DetailArrerage.builder().
                                idArrerageMajoration(occurence.getDetailArrerageRente().getIdentifiantArrerage())
                                .dateMiseEnPaiementArrerage(getDatePaiement(occurence)).build());
                    }
                    return occurence.getDetailArrerageRente().getIdentifiantArrerage();
                })
                .map(idArrerage -> filterOccurenceReglementByIdParent(prestationsDto, idArrerage))
                .filter(Objects::nonNull).map(occurenceReglementOpt -> occurenceReglementOpt.getReglement().getIdentificationReglement())
                .map(idReglement -> filterOccurenceReglementByIdParent(prestationsDto, idReglement))
                .filter(Objects::nonNull).map(occurence ->
                        HistoriquePaiement.builder()
                                .detailArrerage(paiement.getDetailArrerage())
                                .montantPaiement(getMontantPaiement(occurence.getPaiements())).
                                build()).sorted((o1, o2) -> o2.getDetailArrerage().getDateMiseEnPaiementArrerage().compareTo(o1.getDetailArrerage().getDateMiseEnPaiementArrerage())).collect(Collectors.toList());
    }

    private Date getDatePaiement(OccurenceReglement occurence) {
        return occurence.getDetailArrerageRente() != null ? occurence.getDetailArrerageRente().getDateMiseEnPaiementArrerage() : null;
    }


    private BigDecimal getMontantPaiement(List<Paiement> paiementList) {
        if (CollectionUtils.isEmpty(paiementList)) {
            return BigDecimal.ZERO;
        }
        return paiementList.stream().filter(paiement -> paiement.getCodeStatutPaiement().equals(TYPE_STATUT_PAIEMENT_PAYE)
                || paiement.getCodeStatutPaiement().equals(TYPE_STATUT_PAIEMENT_REGLE))
                .map(Paiement::getMontantPaiement)
                .filter(Objects::nonNull).
                        reduce(BigDecimal.ZERO, BigDecimal::add);

    }

    private OccurenceReglement filterOccurenceReglementByIdParent(PrestationsDto prestationsDto, String id) {
        return prestationsDto.getOccurenceReglementList().stream().
                filter(occurenceReglement -> occurenceReglement != null
                        && occurenceReglement.getIdentifiantParent() != null
                        && occurenceReglement.getIdentifiantParent().equals(id)).findAny().orElse(null);
    }


    @Override
    public List<HistoriquePaiement> rechercherPaiementsRecus(ContratParcoursDto contratRente) {
        contratRente.setNomContrat(CONTRAT_ID);
        contratRente.setIdentifiantAssure(PERSON_ID);
        RechercherPrestationsCriteresDto rechercherPrestationsCriteresDto = new RechercherPrestationsCriteresDto();
        rechercherPrestationsCriteresDto.setIdContrat(contratRente.getNomContrat());
        rechercherPrestationsCriteresDto.setIdPersonne(contratRente.getIdentifiantAssure());
        rechercherPrestationsCriteresDto.setCodeSiloType(contratRente.getCodeSilo());
        rechercherPrestationsCriteresDto.setFromEspaceRentier(true);
        PrestationsDto prestationsDto = rechercherPrestationsClient.rechercherPrestationsClient(rechercherPrestationsCriteresDto);

        List<HistoriquePaiement> paiementListRente = rechercherPaiements(prestationsDto, TYPE_ARRERAGE_RENTES);

        List<HistoriquePaiement> paiementListMajoration = rechercherPaiements(prestationsDto, TYPE_ARRERAGE_MAJORATION);

        if (paiementListMajoration.isEmpty()) {
            return calculTotalPaiementGroupedByDate(paiementListRente);
        } else {
            List<HistoriquePaiement> historiquePaiementList = new ArrayList<>();
            for (HistoriquePaiement paiementRente : paiementListRente) {
                HistoriquePaiement historiquePaiement = paiementListMajoration.stream().
                        filter(paiementMajoration -> paiementMajoration.getDetailArrerage().getDateMiseEnPaiementArrerage() != null
                                && paiementMajoration.getDetailArrerage().getDateMiseEnPaiementArrerage()
                                .equals(paiementRente.getDetailArrerage().getDateMiseEnPaiementArrerage())).findAny().orElse(null);
                if (historiquePaiement != null) {
                    BigDecimal montantMajoration = historiquePaiement.getMontantPaiement();
                    if (montantMajoration != null) {
                        HistoriquePaiement hPaiement = HistoriquePaiement.builder()
                                .detailArrerage(paiementRente.getDetailArrerage())
                                .montantPaiement(paiementRente.getMontantPaiement()
                                        .add(montantMajoration)).build();
                        historiquePaiementList.add(hPaiement);
                    }
                }

            }

            return calculTotalPaiementGroupedByDate(historiquePaiementList);

        }
    }


    private List<HistoriquePaiement> calculTotalPaiementGroupedByDate(List<HistoriquePaiement> historiquePaiementList) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate today = LocalDate.now();
        Date dateFin = Date.from(today.atStartOfDay(defaultZoneId).toInstant());

        LocalDate dateMin = today.minus(3, ChronoUnit.YEARS);
        Date dateDebut = Date.from(dateMin.atStartOfDay(defaultZoneId).toInstant());

        List<HistoriquePaiement> resultPaiement = new ArrayList<>();
        historiquePaiementList.stream().filter(p -> !p.getDetailArrerage().getDateMiseEnPaiementArrerage().before(dateDebut) && !p.getDetailArrerage().getDateMiseEnPaiementArrerage().after(dateFin))
                .collect(Collectors.groupingBy(HistoriquePaiement::getDetailArrerage,
                        Collectors.mapping(HistoriquePaiement::getMontantPaiement, Collectors.reducing(BigDecimal.ZERO, BigDecimal::add))))
                .forEach((key, value) -> {
                    if (value.compareTo(BigDecimal.ZERO) != 0) {
                        HistoriquePaiement historiquePaiement = new HistoriquePaiement(key, value);
                        resultPaiement.add(historiquePaiement);
                    }
                });

        resultPaiement.sort((h1, h2) -> h2.getDetailArrerage().getDateMiseEnPaiementArrerage().compareTo(h1.getDetailArrerage().getDateMiseEnPaiementArrerage()));
        return resultPaiement;
    }


    @Override
    public PaiementDetailDto getPaiementsDetailsInfo(RechercherPaiementDetail rechercherPaiementDetail) {
        rechercherPaiementDetail.setContratParcours(ContratParcoursDto.builder().nomContrat(CONTRAT_ID)
                .identifiantAssure(PERSON_ID)
                .codeSilo(CodeSiloType.ERE).build());
        RechercherPrestationsCriteresDto rechercherPrestationsCriteresDto = new RechercherPrestationsCriteresDto();
        rechercherPrestationsCriteresDto.setIdContrat(rechercherPaiementDetail.getContratParcours().getNomContrat());
        rechercherPrestationsCriteresDto.setIdPersonne(rechercherPaiementDetail.getContratParcours().getIdentifiantAssure());
        rechercherPrestationsCriteresDto.setCodeSiloType(rechercherPaiementDetail.getContratParcours().getCodeSilo());
        rechercherPrestationsCriteresDto.setFromEspaceRentier(true);
        PrestationsDto prestationsDto = rechercherPrestationsClient.rechercherPrestationsClient(rechercherPrestationsCriteresDto);

        return getDetailsPaiementsInfos(prestationsDto, rechercherPaiementDetail.getArrerageId());
    }

    private BigDecimal calculTotalPrelevements(BigDecimal x, BigDecimal y, BigDecimal z, BigDecimal w) {
        BigDecimal montantTotalAutresPrelevements = BigDecimal.ZERO;
        montantTotalAutresPrelevements = montantTotalAutresPrelevements.add(x).add(y).add(z).add(w);
        return montantTotalAutresPrelevements;
    }

    private PaiementDetailDto getDetailsPaiementsInfos(PrestationsDto prestationsDto, DetailArrerage arrerageId) {
        PaiementDetailDto paiementDetailDtoRenteBase;
        PaiementDetailDto paiementDetailDtoMjoration;

        if (arrerageId.getIdArrerageMajoration() == null) {
            paiementDetailDtoRenteBase = getDetailsPaiements(prestationsDto, arrerageId.getIdArrerageRente());
        } else {
            paiementDetailDtoRenteBase = getDetailsPaiements(prestationsDto, arrerageId.getIdArrerageRente());
            paiementDetailDtoMjoration = getDetailsPaiements(prestationsDto, arrerageId.getIdArrerageMajoration());
            RenteBrute renteBrute = new RenteBrute();
            renteBrute.setMontantBruteRente(paiementDetailDtoRenteBase.getRenteBrute().getMontantBruteRente());
            renteBrute.setMontantBruteRenteRevalorisation(paiementDetailDtoRenteBase.getRenteBrute().getMontantBruteRenteRevalorisation());
            renteBrute.setMontantBruteMajoration(paiementDetailDtoMjoration.getRenteBrute().getMontantBruteMajoration());
            renteBrute.setMontantBruteMajorationRevalorisation(paiementDetailDtoMjoration.getRenteBrute().getMontantBruteMajorationRevalorisation());
            renteBrute.setMontantTotalRente(calculTotalPrelevements(renteBrute.getMontantBruteRente(), renteBrute.getMontantBruteMajoration(), renteBrute.getMontantBruteMajorationRevalorisation(), renteBrute.getMontantBruteRenteRevalorisation()));
            MontantsRetenus montantsRetenus = new MontantsRetenus();
            montantsRetenus.setMontantPrelevementRenteCrds(paiementDetailDtoRenteBase.getMontantsRetenus().getMontantPrelevementRenteCrds());
            montantsRetenus.setMontantPrelevementRenteCsgCasa(paiementDetailDtoRenteBase.getMontantsRetenus().getMontantPrelevementRenteCsgCasa());
            montantsRetenus.setMontantPrelevementRenteSs(paiementDetailDtoRenteBase.getMontantsRetenus().getMontantPrelevementRenteSs());
            montantsRetenus.setMontantPreleventRentePasrau(paiementDetailDtoRenteBase.getMontantsRetenus().getMontantPreleventRentePasrau());
            montantsRetenus.setMontantPrelevementMajorationCrds(paiementDetailDtoMjoration.getMontantsRetenus().getMontantPrelevementMajorationCrds());
            montantsRetenus.setMontantPrelevementMajorationCsgCasa(paiementDetailDtoMjoration.getMontantsRetenus().getMontantPrelevementMajorationCsgCasa());
            montantsRetenus.setMontantPrelevementMajorationSs(paiementDetailDtoMjoration.getMontantsRetenus().getMontantPrelevementMajorationSs());
            montantsRetenus.setMontantPreleventMajorationPasrau(paiementDetailDtoMjoration.getMontantsRetenus().getMontantPreleventMajorationPasrau());
            montantsRetenus.setTotalPrelevementsRenteBase(paiementDetailDtoRenteBase.getMontantsRetenus().getTotalPrelevementsRenteBase());
            montantsRetenus.setTotalPrelevementsMajoration(paiementDetailDtoMjoration.getMontantsRetenus().getTotalPrelevementsMajoration());
            montantsRetenus.setTotalPrelevementsRenteBase(montantsRetenus.getTotalPrelevementsMajoration().add(montantsRetenus.getTotalPrelevementsRenteBase()));
            paiementDetailDtoRenteBase.setRenteBrute(renteBrute);
            paiementDetailDtoRenteBase.setMontantsRetenus(montantsRetenus);
            return paiementDetailDtoRenteBase;
        }

        return paiementDetailDtoRenteBase;

    }

    private PaiementDetailDto getDetailsPaiements(PrestationsDto prestationsDto, String id) {
        PaiementDetailDto p = new PaiementDetailDto();
        return prestationsDto.getOccurenceReglementList().stream().filter(occurenceReglement ->
                occurenceReglement != null && occurenceReglement.getDetailArrerageRente() != null &&
                        occurenceReglement.getDetailArrerageRente().getIdentifiantArrerage().equals(id))
                .map(occurence -> {
                    if (occurence.getDetailArrerageRente().getRegularisationEcheances() != null) {
                        p.setMontantsTotalsRegularisation(calculTotalRegularisation(occurence.getDetailArrerageRente().getRegularisationEcheances()));
                    }
                    p.setRenteBrute(getMontantArrerage(occurence, occurence.getDetailArrerageRente().getLibelleTypeArrerage()));
                    type = occurence.getDetailArrerageRente().getLibelleTypeArrerage();
                    return occurence.getDetailArrerageRente().getIdentifiantArrerage();
                }).map(idArrerage -> filterOccurenceReglementByIdParent(prestationsDto, idArrerage))
                .filter(Objects::nonNull).map(occurenceReglement -> {
                            p.setMontantsRetenus(getAutresPrelevements(occurenceReglement, type));
                            return p;
                        }
                ).findAny().orElse(null);
    }

    private BigDecimal calculTotalRegularisation(List<RegularisationEcheance> regularisationEcheance) {
        BigDecimal totalMontantRegularisation = regularisationEcheance.stream().map(RegularisationEcheance::getMontantTotalRegularisation)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return totalMontantRegularisation;

    }

    private RenteBrute getMontantArrerage(OccurenceReglement occurenceReglement, String type) {
        if (type.equals(TYPE_ARRERAGE_RENTES)) {
            return RenteBrute.builder().montantBruteRente(occurenceReglement.getDetailArrerageRente().getMontantArrerageHT())
                    .montantBruteRenteRevalorisation(occurenceReglement.getDetailArrerageRente().getMontantRevalorisationArrerageHT())
                    .montantTotalRente(occurenceReglement.getDetailArrerageRente().getMontantRevalorisationArrerageHT()
                            .add(occurenceReglement.getDetailArrerageRente().getMontantArrerageHT()))
                    .build();
        } else {
            return RenteBrute.builder().montantBruteMajoration(occurenceReglement.getDetailArrerageRente().getMontantArrerageHT())
                    .montantBruteMajorationRevalorisation(occurenceReglement.getDetailArrerageRente().getMontantRevalorisationArrerageHT())
                    .build();
        }
    }

    private MontantsRetenus getAutresPrelevements(OccurenceReglement occurenceReglement, String type) {
        MontantsRetenus montantsRetenus = new MontantsRetenus();
        if (occurenceReglement.getReglement() != null && occurenceReglement.getReglement().getAutrePrelevements() != null) {
            occurenceReglement.getReglement().getAutrePrelevements().forEach(prelevement ->
            {
                if (type.equals(TYPE_ARRERAGE_RENTES)) {
                    if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "CsgCasa".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementRenteCsgCasa(prelevement.getMontantPrelevement());
                    } else if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "SS".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementRenteSs(prelevement.getMontantPrelevement());
                    } else if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "CRDS".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementRenteCrds(prelevement.getMontantPrelevement());
                    } else if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "3".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantContributionL137(prelevement.getMontantPrelevement());
                    }
                    montantsRetenus.setMontantPreleventRentePasrau(occurenceReglement.getReglement().getPasrau().getMontantPAS());

                } else {
                    if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "CsgCasa".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementMajorationCsgCasa(prelevement.getMontantPrelevement());
                    } else if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "SS".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementMajorationSs(prelevement.getMontantPrelevement());
                    } else if (prelevement != null && prelevement.getCodeTypePrelevementSilo() != null && "CRDS".equals(prelevement.getCodeTypePrelevementSilo())) {
                        montantsRetenus.setMontantPrelevementMajorationCrds(prelevement.getMontantPrelevement());
                    }
                    montantsRetenus.setMontantPreleventMajorationPasrau(occurenceReglement.getReglement().getPasrau().getMontantPAS());


                }


            });
            if (type.equals(TYPE_ARRERAGE_RENTES)) {
                montantsRetenus.setTotalPrelevementsRenteBase(calculTotalPrelevements(occurenceReglement.getReglement().getPasrau().getMontantPAS(), montantsRetenus.getMontantPrelevementRenteCrds(),
                        montantsRetenus.getMontantPrelevementRenteCsgCasa(), montantsRetenus.getMontantPrelevementRenteSs()));
            } else {
                montantsRetenus.setTotalPrelevementsMajoration(calculTotalPrelevements(montantsRetenus.getMontantPreleventMajorationPasrau(), montantsRetenus.getMontantPrelevementMajorationCrds(),
                        montantsRetenus.getMontantPrelevementMajorationCsgCasa(),
                        montantsRetenus.getMontantPrelevementMajorationSs()));

            }
        }


        return montantsRetenus;
    }
}



