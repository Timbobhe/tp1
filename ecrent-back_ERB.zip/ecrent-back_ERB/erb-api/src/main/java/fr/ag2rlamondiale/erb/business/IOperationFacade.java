package fr.ag2rlamondiale.erb.business;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;

import java.util.List;

public interface IOperationFacade {

    List<Operation> findOperationsToReCalculate(String idAssure, CodeSiloType codeSiloType);
}
