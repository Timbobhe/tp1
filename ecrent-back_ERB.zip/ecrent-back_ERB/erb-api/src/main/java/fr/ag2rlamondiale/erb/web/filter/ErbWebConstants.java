package fr.ag2rlamondiale.erb.web.filter;

import org.springframework.core.Ordered;

public class ErbWebConstants {

    public static final int ORDER_FILTER_THREAD_LOCAL = Ordered.HIGHEST_PRECEDENCE;
    public static final int ORDER_FILTER_REQUEST_ID = ORDER_FILTER_THREAD_LOCAL + 1;
    public static final int ORDER_FILTER_CRSFR = ORDER_FILTER_REQUEST_ID + 1;

    private ErbWebConstants() {
        // ignore
    }
}
