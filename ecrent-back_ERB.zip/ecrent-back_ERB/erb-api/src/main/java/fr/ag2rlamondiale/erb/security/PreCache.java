package fr.ag2rlamondiale.erb.security;

import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class PreCache {

    @Autowired
    private AsyncTaskExecutor asyncTaskExecutor;

    @Autowired
    private UserContextHolder userContextHolder;


    void start(Runnable onTerminate) {
        final UserContext userContext = userContextHolder.get();
        log.info("Start pre-cache pour {}", userContext);

    }

}
