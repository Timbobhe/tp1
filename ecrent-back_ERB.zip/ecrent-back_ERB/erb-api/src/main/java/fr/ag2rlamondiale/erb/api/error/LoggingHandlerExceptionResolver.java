package fr.ag2rlamondiale.erb.api.error;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class LoggingHandlerExceptionResolver implements Ordered, HandlerExceptionResolver {// NOSONAR
    private static final Logger log = LoggerFactory.getLogger(LoggingHandlerExceptionResolver.class);

    public LoggingHandlerExceptionResolver() {
        //vide
    }

    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        log.error("Spring MVC Exception for [{} {}] : {}", request.getMethod(), request.getRequestURI(), this.buildMessage(ex), ex);

        return null;
    }


    public int getOrder() {
        return -2147483648;
    }

    private String buildMessage(Exception exception) {
        Throwable src = ExceptionUtils.getRootCause(exception);
        if (src == null) {
            src = exception;
        }

        return src.getClass() + " : " + src.getMessage();
    }
}
