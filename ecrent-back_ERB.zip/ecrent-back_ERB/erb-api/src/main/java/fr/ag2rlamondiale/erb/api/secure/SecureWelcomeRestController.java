package fr.ag2rlamondiale.erb.api.secure;

import fr.ag2rlamondiale.erb.business.IWelcomeFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// http://localhost:8081/api/secure/welcome-app
@RestController
@RequestMapping("/secure")
public class SecureWelcomeRestController {
	
	@Autowired
	private IWelcomeFacade rentiersFacade;

	@GetMapping("/welcome-app")
	public String welcome(@RequestParam(value = "name", defaultValue = "Rentiers-back") String name) {
		return rentiersFacade.welcomeToApp(name);
	}
}
