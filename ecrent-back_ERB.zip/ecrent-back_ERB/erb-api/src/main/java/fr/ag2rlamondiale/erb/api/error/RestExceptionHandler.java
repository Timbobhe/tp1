/*
 * Cree le 11 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.erb.api.error;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.error.RestError;
import fr.ag2rlamondiale.trm.domain.upload.UploadFileResponseDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.core.convert.ConversionFailedException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.lang.reflect.InvocationTargetException;

import static fr.ag2rlamondiale.trm.domain.upload.UploadFileResponseDto.UploadErrorType.PJ_TAILLE_KO;
import static fr.ag2rlamondiale.trm.utils.ErrorConstantes.*;

/**
 * ResponseEntityExceptionHandler applicative heritant de l'implementation de Metis pour gestion des
 * exceptions applicatives, sur les appels de services REST Spring MVC (qui met par defaut le
 * message d'Exception dans la reponse REST, alors que l'implementation par defaut de Spring ne met
 * qu'un message relatif au status code).
 * <p>
 * Il faut une classe applicative avec l'annotation ControllerAdvice, heritant de
 * MetisSpringRestResponseEntityExceptionHandler, sinon l'implementation Metis n'est pas utilisee
 * dans l'application.
 *
 * <p>
 * On le LOG pas car c'est déjà fait par le Framework : fr.ag2rlamondiale.metis.ria.server.spring.rest.LoggingHandlerExceptionResolver
 * </p>
 */
@Slf4j
@ControllerAdvice(basePackages = "fr.ag2rlamondiale.ecrs.api")
public class RestExceptionHandler extends ResponseEntityExceptionHandler {
    /**
     * Gestion des erreurs métiers
     *
     * @param ex BusinessException
     * @return image json d'une RestError
     */
    @ExceptionHandler(value = {BusinessException.class})
    protected ResponseEntity<RestError> handleBusinessException(BusinessException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_METIER, ex.getMessage()),
                new HttpHeaders(), HttpStatus.SERVICE_UNAVAILABLE);
    }

    /**
     * Gestion des erreurs métiers
     *
     * @param ex BusinessException
     * @return image json d'une RestError
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(value = {MaxUploadSizeExceededException.class})
    protected ResponseEntity<UploadFileResponseDto> handleMaxUploadSizeExceededException(MaxUploadSizeExceededException ex) {
        UploadFileResponseDto err = new UploadFileResponseDto();
        err.setState(UploadFileResponseDto.State.KO);
        err.setErrorTag(PJ_TAILLE_KO);
        return ResponseEntity.badRequest().body(err);
    }

    /**
     * Gestion des erreurs techniques
     *
     * @param ex TechnicalException
     * @return image json d'une RestError
     */
    @ExceptionHandler(value = {TechnicalException.class})
    protected ResponseEntity<RestError> handleTechnicalException(TechnicalException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null), new HttpHeaders(),
                HttpStatus.SERVICE_UNAVAILABLE);
    }

    /**
     * Retourne une 403 Forbidden
     */
    @ExceptionHandler({AccessDeniedException.class})
    @ResponseBody
    public ResponseEntity<RestError> handleAccessDenied(AccessDeniedException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_METIER, UTILISATEUR_NON_TROUVE),
                new HttpHeaders(), HttpStatus.FORBIDDEN);
    }

    /**
     * Traite les Runtimes courantes.
     */
    @ExceptionHandler({InvocationTargetException.class, IllegalArgumentException.class,
            ClassCastException.class, ConversionFailedException.class})
    @ResponseBody
    public ResponseEntity<RestError> handleMiscFailures(Throwable t) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null), new HttpHeaders(),
                HttpStatus.BAD_REQUEST);
    }

    /**
     * Retourne une 401 Unauthorized
     */
    @ExceptionHandler({AuthenticationException.class})
    @ResponseBody
    public ResponseEntity<RestError> handleAuthentication(AuthenticationException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null), new HttpHeaders(), HttpStatus.UNAUTHORIZED);
    }

    /**
     * Traite tous les autres types d'exceptions
     *
     * @param e Exception
     * @return image json d'une RestError
     */
    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<RestError> handleAnyException(Exception e) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null).addMessage(buildErrorMessage(e)), HttpStatus.SERVICE_UNAVAILABLE);
    }

    private String buildErrorMessage(Throwable excep) {
        Throwable src = ExceptionUtils.getRootCause(excep);
        if (src == null) {
            src = excep;
        }

        return src.getClass() + " : " + src.getMessage();
    }
}
