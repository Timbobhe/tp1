package fr.ag2rlamondiale.erb.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class RenteBrute {
    BigDecimal montantBruteRente;
    BigDecimal montantBruteRenteRevalorisation;
    BigDecimal montantBruteMajoration;
    BigDecimal montantBruteMajorationRevalorisation;
    BigDecimal montantTotalRente;
}
