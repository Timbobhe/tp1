package fr.ag2rlamondiale.erb.api.secure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IContratDetailsFacade;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.InfoContratsDetailDTO;
import fr.ag2rlamondiale.erb.dto.HistoriquePaiement;
import fr.ag2rlamondiale.erb.dto.PaiementDetailDto;
import fr.ag2rlamondiale.erb.dto.RechercherPaiementDetail;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/secure/contrat-detail")
public class ContratDetailRestController {
    @Autowired
    private IContratDetailsFacade detailsContratsFacade;


    @LogExecutionTime
    @GetMapping(path = "/start")
    public InfoContratsDetailDTO start() throws TechnicalException {
        return detailsContratsFacade.start();
    }

    @PostMapping(path = "/historique-paiement")
    List<HistoriquePaiement> getHistoriquesPaiements(@RequestBody ContratParcoursDto contratRente) throws TechnicalException {
        return detailsContratsFacade.rechercherPaiementsRecus(contratRente);
    }

    @LogExecutionTime
    @PostMapping(path = "/details-paiements")
    public PaiementDetailDto getDetailsPaiementsInfo(@RequestBody RechercherPaiementDetail rechercherPaiementDetail) throws TechnicalException {
        return detailsContratsFacade.getPaiementsDetailsInfo(rechercherPaiementDetail);
    }
}
