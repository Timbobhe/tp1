package fr.ag2rlamondiale.erb.business.impl;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import static org.junit.jupiter.api.Assertions.*;


@Configuration
@RunWith(MockitoJUnitRunner.Silent.class)
public class WelcomeFacadeImplTest {

    @InjectMocks
    WelcomeFacadeImpl welcomeFacadeImpl;

    @Test
    public void testWelcomeToApp(){
        final String appName = "Rentiers-Back";
        final String expected = "Welcome to " + appName + "!";
        final String result = welcomeFacadeImpl.welcomeToApp(appName);
        assertEquals(expected, result);
    }

}