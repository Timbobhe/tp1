package fr.ag2rlamondiale.erb.utils;

import fr.ag2rlamondiale.trm.security.UserContext;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
public class MockUserContext extends UserContext {

    private String idGdi;
    private String numeroPersonneEre;
    private String numeroPersonneMdpro;
}
