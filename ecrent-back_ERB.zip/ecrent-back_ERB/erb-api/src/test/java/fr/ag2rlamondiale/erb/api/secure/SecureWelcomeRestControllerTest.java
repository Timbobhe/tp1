package fr.ag2rlamondiale.erb.api.secure;

import fr.ag2rlamondiale.erb.business.IWelcomeFacade;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.anyString;

@SpringBootTest
@AutoConfigureMockMvc
class SecureWelcomeRestControllerTest {

    @Mock
    private IWelcomeFacade rentiersFacade;

    @Autowired
    private MockMvc mvc;

    @Test
    void testStart_NotLoggedIN() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                .get("/api/secure/welcome-app")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isFound());
        Mockito.verify(rentiersFacade, Mockito.never()).welcomeToApp(anyString());
    }

    @Test
    @WithMockUser
    void testStart_LoggedIN() throws Exception {
        final String name = "Rentiers";
        mvc.perform(MockMvcRequestBuilders.get("/api/secure/welcome-app")
                    .param("name", name)
                    .contentType(MediaType.APPLICATION_JSON)
                ).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().string(String.format("Welcome to %s!", name)));
    }

}