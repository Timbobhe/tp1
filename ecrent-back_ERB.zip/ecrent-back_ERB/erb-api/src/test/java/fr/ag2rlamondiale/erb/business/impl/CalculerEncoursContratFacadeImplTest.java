package fr.ag2rlamondiale.erb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IOperationFacade;
import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.client.soap.ICalculerEncoursContratClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.encours.CalculerEncoursContratDto;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class CalculerEncoursContratFacadeImplTest {

    @Mock
    ICalculerEncoursContratClient calculerEncoursContratClient;

    @Mock
    IOperationFacade operationFacade;

    @Mock
    CalculerEncoursParamsHolder calculerEncoursParamsHolder;

    @InjectMocks
    CalculerEncoursContratFacadeImpl sut;

    @Test
    public void calculerEncoursContratERETest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratRente contratRente = new ContratRente();
        contratRente.setCodeSilo(CodeSiloType.ERE);

        // When
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratRente);
        // Then
        Assert.assertEquals("1", compteEncours.getIdStructInv());
    }

    @Test
    public void calculerEncoursContratMDPROTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratRente contratRente = new ContratRente();
        contratRente.setCodeSilo(CodeSiloType.MDP);

        // When
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratRente);
        // Then
        Assert.assertEquals("1", compteEncours.getIdStructInv());
    }

    @Test
    public void calculerEncoursContratEnErreur() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenThrow(new TechnicalException("fds"));


        //When
        ContratRente contratRente = new ContratRente();
        contratRente.setCodeSilo(CodeSiloType.ERE);
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratRente);

        Assert.assertTrue(compteEncours.isEncoursEnErreur());
    }

    @Test
    public void getCompteEncoursContratTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When
        ContratRente contratRente = ContratRente.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(false)
                .build();

        EncoursDto encoursDto = sut.getEncoursDto(contratRente);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(100.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursContrat2Test() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratRente contratRente = ContratRente.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratRente(contratRente).build();
        Compartiment compartiment2 = Compartiment.builder().contratRente(contratRente).build();
        contratRente.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(contratRente);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(200.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursContratEnErreurTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setEncoursEnErreur(true);
                    return compteEncours;
                });

        //When

        ContratRente contratRente = ContratRente.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratRente(contratRente).build();
        Compartiment compartiment2 = Compartiment.builder().contratRente(contratRente).build();
        contratRente.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(contratRente);

        Assert.assertTrue(encoursDto.isEncoursEnErreur());
    }

    @Test
    public void getCompteEncoursCompartimentTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratRente contratRente = ContratRente.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratRente(contratRente).build();
        Compartiment compartiment2 = Compartiment.builder().contratRente(contratRente).build();
        contratRente.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(compartiment1);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(100.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursCompartiment2Test() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContrat(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratRente contratRente = ContratRente.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(false)
                .build();
        Compartiment compartiment1 = Compartiment.builder()
                .contratRente(contratRente)
                .type(CompartimentType.C1)
                .build();
        contratRente.setCompartiments(Collections.singletonList(compartiment1));

        EncoursDto encoursDto = sut.getEncoursDto(compartiment1);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(0.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void should_calculate_encours_when_error_operation_a_recalculer() throws TechnicalException {
        when(calculerEncoursParamsHolder.isActiveGestionErreurOperationRecalculer()).thenReturn(true);
        when(calculerEncoursContratClient.calculerEncoursContrat(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if(argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(1,2));
        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());

        Assert.assertEquals(JsonMarshaller.toJSON(createCompteEncours_en_Erreur()), JsonMarshaller.toJSON(actual));
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_exception_is_not_operation_a_recalculer() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContrat(any())).thenThrow(new TechnicalException());
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(1,2));
        when(calculerEncoursParamsHolder.isActiveGestionErreurOperationRecalculer()).thenReturn(true);

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_no_operation_found() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContrat(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if(argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(null);
        when(calculerEncoursParamsHolder.isActiveGestionErreurOperationRecalculer()).thenReturn(true);

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_no_operation_in_last_three_months() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContrat(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if(argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(5, 6));
        when(calculerEncoursParamsHolder.isActiveGestionErreurOperationRecalculer()).thenReturn(true);

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }


    private CompteEncours createCompteEncours() {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setMontantEncours(new BigDecimal("100"));
        return compteEncours;
    }

    private CompteEncours createCompteEncours_en_Erreur() {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setMontantEncours(new BigDecimal("0"));
        compteEncours.setEncoursEnErreur(true);
        return compteEncours;
    }

    private List<Operation> createOperationList(int firstOperation, int secondOperation) {
        List<Operation> operations = new ArrayList<>();
        Operation operation1 = new Operation();
        operation1.setId("operation1");
        operation1.setDate(Date.from(new Date().toInstant().atZone(ZoneId.systemDefault()).minusMonths(firstOperation).toInstant()));
        operations.add(operation1);
        Operation operation2 = new Operation();
        operation2.setId("operation2");
        operation2.setDate(Date.from(new Date().toInstant().atZone(ZoneId.systemDefault()).minusMonths(secondOperation).toInstant()));
        operations.add(operation2);
        return operations;
    }
}
