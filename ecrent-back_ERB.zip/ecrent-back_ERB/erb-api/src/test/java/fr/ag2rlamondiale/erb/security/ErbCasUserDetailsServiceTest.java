package fr.ag2rlamondiale.erb.security;


import fr.ag2rlamondiale.erb.client.business.impl.RechercheClientFacadeImpl;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.utils.MockUserContext;
import fr.ag2rlamondiale.metis.boot.security.dao.IApplicationRolesRetriever;
import fr.ag2rlamondiale.trm.cache.ITrackUserCache;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.jasig.cas.client.authentication.AttributePrincipalImpl;
import org.jasig.cas.client.validation.AssertionImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.*;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.MOCKDATA;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ErbCasUserDetailsServiceTest {

    @InjectMocks
    ErbCasUserDetailsService erbCasUserDetailsService = new ErbCasUserDetailsService(new ApplicationRolesRetrieverImpl());

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    UserSecurityServiceImpl userSecurityService;

    @Mock
    RechercheClientFacadeImpl clientFacade;



    @Mock
    ITrackUserCache trackUserCache;

    @Mock
    PreCache preCache;



    @Before
    public void init() throws Exception {
        final UserContext userContextERE = createUserContextERE(MOCKDATA);
        when(userContextHolder.get()).thenReturn(userContextERE);
        when(clientFacade.rechercherPersonnePhysiqueParIdGdi(anyString())).thenReturn(createPersonnePhysique());

    }

    private List<ContratRente> createContrats() {
        ContratRente contrat = new ContratRente();
        return Arrays.asList(contrat);
    }

    private UserContext createUserContextERE(String numPP) {
        MockUserContext userContext = new MockUserContext();
        userContext.setNumeroPersonneEre(numPP);
        userContext.setPartenaire(new Partenaire());
        return userContext;
    }

    private PersonnePhysique createPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setIdGdi("IDGDI");
        pp.setNom("NOM");
        pp.setPrenom("PRENOM");
        pp.setNumeroPersonneEre("NUMERE");
        pp.setNumeroPersonneMdpro("NUMMDPRO");
        return pp;
    }

    @Test
    public void testStandard() {
        UserDetails userDetails = erbCasUserDetailsService.loadUserDetails(cas4());
        assertTrue(userDetails.isAccountNonLocked());
    }

    @Test
    public void testStandard2() {
        UserDetails userDetails = erbCasUserDetailsService.loadUserDetails(cas4());
        assertTrue(userDetails.isAccountNonLocked());
    }

    @Test
    public void testImpersonnation() {
        UserDetails userDetails = erbCasUserDetailsService.loadUserDetails(cas2());
        assertTrue(userDetails.isAccountNonLocked());
    }


    private CasAssertionAuthenticationToken cas1() {
        Map<String, Object> attributes = new HashMap<>();
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }

    private CasAssertionAuthenticationToken cas2() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("roles", Arrays.asList("NET-Pilotage"));
        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }

    private CasAssertionAuthenticationToken cas4() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20210301151047+0100");
        attributes.put("roles", Arrays.asList("EERE-Salarie"));

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        AttributePrincipalImpl principal = new AttributePrincipalImpl("IDGDI", attributes);
        AssertionImpl assertion = new AssertionImpl(principal, new Date(), null, new Date(), Collections.emptyMap());
        String ticket = "";
        return new CasAssertionAuthenticationToken(assertion, ticket);
    }
}

class ApplicationRolesRetrieverImpl implements IApplicationRolesRetriever {

    @Override
    public List<String> getApplicationRoles() {
        return Arrays.asList("EERE-Salarie", "NET-Utilisateur",
                "IMP-EERE-Salarie", "cla_fonds_pension",
                "EMDPRO-Utilisateur", "NET-Pilotage", "EERE-Federation");
    }
}
