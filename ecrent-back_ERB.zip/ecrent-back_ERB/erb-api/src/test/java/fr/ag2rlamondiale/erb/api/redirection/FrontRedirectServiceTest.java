package fr.ag2rlamondiale.erb.api.redirection;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.*;


@SpringBootTest
@AutoConfigureMockMvc
class FrontRedirectServiceTest {

    @Autowired
    private MockMvc mvc;

    @Test
    @WithMockUser
    void testRedirectToFront_LoggedIN_InvalidUrl() throws Exception {
        final String service = "B3d_ReQ";
        mvc.perform(MockMvcRequestBuilders.get("/api/secure/redirectToFront")
                        .param("service", service)
                        .contentType(MediaType.APPLICATION_JSON)
                ).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.status().isBadRequest());
    }

    @Test
    @WithMockUser
    void testRedirectToFront_LoggedIN_validUrl() throws Exception {
        final String service = "http://itsvalid";
        mvc.perform(MockMvcRequestBuilders.get("/api/secure/redirectToFront")
                        .param("service", service)
                        .contentType(MediaType.APPLICATION_JSON)
                ).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.header().string("Location", service))
                .andExpect(MockMvcResultMatchers.status().isFound());
    }

    @Test
    @WithMockUser
    void testRedirectToSwagger_LoggedIN_validUrl() throws Exception {
        final String service = "http://itsvalid";
        final HttpServletRequest httpServletRequest = Mockito.mock(HttpServletRequest.class);
        mvc.perform(MockMvcRequestBuilders.get("/api/secure/swagger")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(httpServletRequest))
                ).andDo(MockMvcResultHandlers.print())
                .andExpect(MockMvcResultMatchers.header().string("Location", CoreMatchers.containsString("api/swagger-ui.html")))
                .andExpect(MockMvcResultMatchers.status().isFound());
    }


}