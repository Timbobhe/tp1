package fr.ag2rlamondiale.erb.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.operation.RechercherOperationsDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Configuration
@RunWith(MockitoJUnitRunner.Silent.class)
public class OperationFacadeImplTest {

    private static final String ID_OPERATION = "81169648";
    private static final String ID_ASSURE = "84940";

    @Mock
    private IOperationsClient operationClient;

    @InjectMocks
    OperationFacadeImpl operationFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();


    @Test
    public void should_find_operations_to_recalculate_for_mdpro() throws TechnicalException {
        when(operationClient.rechercherOperations(any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId(ID_OPERATION);
                    return Collections.singletonList(operation);
                });
        List<Operation> actual = operationFacade.findOperationsToReCalculate(ID_ASSURE, CodeSiloType.MDP);
        Assert.assertEquals(ID_OPERATION, actual.get(0).getId());
    }


    @Test(expected = TechnicalRuntimeException.class)
    public void should_throw_exception_when_trying_to_find_operations_to_recalculate() throws TechnicalException {
        when(operationClient.rechercherOperations(any(RechercherOperationsDto.class))).thenThrow(new TechnicalException());
        operationFacade.findOperationsToReCalculate(ID_ASSURE, CodeSiloType.ERE);
    }

}