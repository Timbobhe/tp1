package fr.ag2rlamondiale.erb.security;

import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.erb.contrat.business.IContratFacade;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class UserSecurityServiceImplTest {
    @Spy
    private UserSecurityContext securityContext;

    @Spy
    private UserContextHolder userContextHolder;

    @Mock
    IContratFacade contratFacade;

    @InjectMocks
    UserSecurityServiceImpl userSecurityService;

    @Before
    public void init() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");

        when(userContextHolder.get()).thenReturn(userContext);
    }

    private void cas1() {
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(securityContext.isContextActive()).thenReturn(false);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas2() {
        JoinPoint joinPoint = mock(JoinPoint.class);
        when(securityContext.isContextActive()).thenReturn(true);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(true);
        when(userContextHolder.get()).thenReturn(userContext);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas3() throws NoSuchMethodException, SecurityException {
        JoinPoint joinPoint = mock(JoinPoint.class);

        when(securityContext.isContextActive()).thenReturn(true);
        Set<String> set = new HashSet<>();
        set.add("arg");
        when(securityContext.getIdAssures()).thenReturn(set);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(false);
        when(userContextHolder.get()).thenReturn(userContext);
        MethodSignature signature = mock(MethodSignature.class);
        when(joinPoint.getSignature()).thenReturn(signature);
        Class[] cArg = new Class[1];
        cArg[0] = String.class;
        Method testMethod = this.getClass().getMethod("testMethod", cArg);
        when(signature.getMethod()).thenReturn(testMethod);
        ISecurityParamAccess security = mock(ISecurityParamAccess.class);
        Object[] args = Arrays.asList("arg", security).toArray();
        when(joinPoint.getArgs()).thenReturn(args);
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    private void cas4() throws NoSuchMethodException, SecurityException {
        JoinPoint joinPoint = mock(JoinPoint.class);

        when(securityContext.isContextActive()).thenReturn(true);
        Set<String> set = new HashSet<>();
        set.add("IDASSURE");
        when(securityContext.getIdAssures()).thenReturn(set);
        UserContext userContext = new UserContext();
        userContext.setForSupervision(false);
        when(userContextHolder.get()).thenReturn(userContext);
        MethodSignature signature = mock(MethodSignature.class);
        when(joinPoint.getSignature()).thenReturn(signature);
        Class[] cArg = new Class[1];
        cArg[0] = String.class;
        Method testMethod = this.getClass().getMethod("testMethod", cArg);
        when(signature.getMethod()).thenReturn(testMethod);
        ISecurityParamAccess security = mock(ISecurityParamAccess.class);
        Object[] args = Arrays.asList(security).toArray();
        when(joinPoint.getArgs()).thenReturn(args);
        when(security.secureForIdentifiantAssure()).thenReturn("IDASSURE");
        assertTrue(userSecurityService.isAuthorized(joinPoint, null));
    }

    @Test
    public void isAuthorized() throws NoSuchMethodException, SecurityException {
        cas1();
        cas2();
        cas3();
        cas4();
    }

    @Test
    public void testInitSecurityContext() throws Exception{
        final String idGdi = "IdGDITEST";
        final PersonnePhysique personnePhysique = buildPersonnePhysique(idGdi);
        when(contratFacade.rechercherContrats()).thenReturn(Arrays.asList( ContratRente.builder()
                .codeSilo(CodeSiloType.ERE).build() ));
        userSecurityService.initSecurityContext(idGdi, personnePhysique);

        Assert.assertEquals(idGdi, securityContext.getIdGdi());
        Assert.assertEquals(personnePhysique.getNumeroPersonneEre(),userContextHolder.get().getNumeroPersonneEre());
        Assert.assertEquals(personnePhysique.getNumeroPersonneMdpro(),userContextHolder.get().getNumeroPersonneMdpro());
        Assert.assertEquals(idGdi,userContextHolder.get().getIdGdi());
        Assert.assertEquals(personnePhysique.getNom(),userContextHolder.get().getNom());
        Assert.assertEquals(personnePhysique.getPrenom(),userContextHolder.get().getPrenom());
        Assert.assertEquals(personnePhysique.getCivilite(),userContextHolder.get().getCivilite());

        Assert.assertEquals(personnePhysique.getNumeroPersonneMdpro(),securityContext.getNumeroPersonneMdpro());
        Assert.assertEquals(personnePhysique.getNumeroPersonneEre(),securityContext.getNumeroPersonneEre());

    }
    @Test
    public void testInitSecurityContext_UserManager() throws Exception{
        final String idGdi = "IdGDITEST";
        final PersonnePhysique personnePhysique = buildPersonnePhysique(idGdi);
        final UserTestManager userTestManager = builUserTestManager(idGdi, personnePhysique);

        userSecurityService.initSecurityContext(userTestManager);
        Assert.assertEquals(idGdi , MDC.get(FrmkLogKeys.IDENTIFIANT_UTILISATEUR));
        Assert.assertEquals(idGdi , securityContext.getIdGdi());
        Assert.assertNotNull(userContextHolder.get());
        Assert.assertTrue(userContextHolder.get().isForSupervision());
        Assert.assertEquals(idGdi, userContextHolder.get().getIdGdi());

        Assert.assertEquals(personnePhysique.getNumeroPersonneEre(),userContextHolder.get().getNumeroPersonneEre());
        Assert.assertEquals(personnePhysique.getNumeroPersonneMdpro(),userContextHolder.get().getNumeroPersonneMdpro());
        Assert.assertEquals(personnePhysique.getNumeroPersonneEre(),securityContext.getNumeroPersonneEre());
        Assert.assertEquals(personnePhysique.getNumeroPersonneMdpro(),securityContext.getNumeroPersonneMdpro());

        Assert.assertTrue(securityContext.isContextActive());
    }



    private PersonnePhysique buildPersonnePhysique(final String idGdi){
        final PersonnePhysique personnePhysique = new PersonnePhysique();
        personnePhysique.setIdGdi("idGdi");
        personnePhysique.setNom("LastName");
        personnePhysique.setPrenom("FisrtName");
        personnePhysique.setCivilite("Mr");
        personnePhysique.setNumeroPersonneEre("NUMPERSOERE");
        personnePhysique.setNumeroPersonneMdpro("NUMPERSONNEMDPRO");
        return personnePhysique;
    }

    private UserTestManager builUserTestManager(final String idGdi, final PersonnePhysique personnePhysique){
        final UserTestManager userTestManager = new UserTestManager();
        userTestManager.setIdGdi(idGdi);
        userTestManager.setPersonnePhysique(personnePhysique);
        return  userTestManager;
    }

    public void testMethod(@SecuredParam(paramType = SecurityParamType.IDASSURE) String s) {

    }
}