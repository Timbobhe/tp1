package fr.ag2rlamondiale.erb.api.secure;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.business.IContratDetailsFacade;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.InfoContratsDetailDTO;
import fr.ag2rlamondiale.erb.dto.DetailArrerage;
import fr.ag2rlamondiale.erb.dto.RechercherPaiementDetail;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.*;

@SpringBootTest
@AutoConfigureMockMvc
class ContratDetailRestControllerTest {

    @InjectMocks
    @Spy
    ContratDetailRestController contratDetailRestController;

    @Mock
    private IContratDetailsFacade detailContratFacadeMock;

    @Autowired
    private MockMvc mvc;

    @Test
    public void testStart() throws TechnicalException {
        when(detailContratFacadeMock.start()).thenReturn(new InfoContratsDetailDTO());
        InfoContratsDetailDTO infoContratsDetailDTO = contratDetailRestController.start();
        verify(contratDetailRestController, times(1)).start();
        verify(detailContratFacadeMock, times(1)).start();
        assertNotNull(infoContratsDetailDTO);
    }

    @Test
    void testStart_NotLoggedIN() throws Exception {
        mvc.perform(MockMvcRequestBuilders
                .get("/api/secure/contrat-detail/start")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isFound());
        Mockito.verify(detailContratFacadeMock, Mockito.never()).start();
    }

    // @Test
/*    @WithMockUser
    void testStart_LoggedIN() throws Exception {
        when(detailContratFacadeMock.start()).thenReturn(new InfoContratsDetailDTO());
        mvc.perform(MockMvcRequestBuilders
                .get("/api/secure/contrat-detail/start")
                .contentType(MediaType.APPLICATION_JSON)).andExpect(MockMvcResultMatchers.status().isOk());
        Mockito.verify(detailContratFacadeMock, Mockito.times(1)).start();
    }*/

    @Test
    public void getHistoriquesPaiements() throws TechnicalException {
        contratDetailRestController.getHistoriquesPaiements(createContratParcours());
        verify(contratDetailRestController, times(1)).getHistoriquesPaiements(createContratParcours());
    }

    @Test
    public void getDetailsPaiementsInfo() throws TechnicalException {
        contratDetailRestController.getDetailsPaiementsInfo(createRechercherPaiementDetail());
        verify(contratDetailRestController, times(1)).getDetailsPaiementsInfo(createRechercherPaiementDetail());
    }


    private ContratParcoursDto createContratParcours() {
        ContratParcoursDto contrat = new ContratParcoursDto();
        contrat = ContratParcoursDto.builder().nomContrat("nomcontrat").identifiantAssure("idAssure").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .build();
        return contrat;
    }

    private RechercherPaiementDetail createRechercherPaiementDetail(){
        ContratParcoursDto contrat = ContratParcoursDto.builder().nomContrat("nomcontrat").identifiantAssure("idAssure").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .build();

        DetailArrerage detailArrerage=DetailArrerage.builder().idArrerageRente("idArrerageRente").idArrerageMajoration("idArrerageMajoration")
                .build();
        return RechercherPaiementDetail.builder().contratParcours(contrat).arrerageId(detailArrerage)
                .build();
    }

}
