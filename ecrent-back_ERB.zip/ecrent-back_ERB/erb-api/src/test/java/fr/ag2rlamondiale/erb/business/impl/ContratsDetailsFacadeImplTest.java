package fr.ag2rlamondiale.erb.business.impl;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.business.IFilterContrats;
import fr.ag2rlamondiale.erb.contrat.business.impl.ContratFacadeImpl;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.InfoContratsDetailDTO;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.Periodicite;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratDetailMapperImpl;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratParcoursMapperImpl;
import fr.ag2rlamondiale.erb.contrat.utils.ContratVifHelper;
import fr.ag2rlamondiale.erb.dto.*;
import fr.ag2rlamondiale.erb.dto.HistoriquePaiement;
import fr.ag2rlamondiale.erb.pfs.client.rest.IConsulterOptionRenteContratClient;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteType;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.client.rest.IConsulterContratClient;
import fr.ag2rlamondiale.trm.client.rest.IRechercherPrestationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrattechnique.AnnuiteRente;
import fr.ag2rlamondiale.trm.domain.contrattechnique.DivisionRente;
import fr.ag2rlamondiale.trm.domain.contrattechnique.InfoRente;
import fr.ag2rlamondiale.trm.domain.contrattechnique.RechercherContratTechniqueOut;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.prestations.*;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import lombok.NonNull;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class ContratsDetailsFacadeImplTest {

    @InjectMocks
    ContratDetailsFacadeImpl contratDetailsFacadeImpl;

    @Mock
    ContratFacadeImpl contratFacade;

    @Mock
    private CalculerEncoursParamsHolder calculerEncoursParamsHolder;

    @Mock
    private RequestContextHolder requestContext = new RequestContextHolder();

    @Mock
    UserContextHolder userContextHolder;

    @Spy
    ContratDetailMapperImpl contratDetailMapper;

    @Spy
    ContratParcoursMapperImpl contratParcoursMapper;

    @Mock
    private ContratVifHelper contratVifHelper;

    @Mock
    ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mock
    private IRechercherPrestationsClient rechercherPrestationsClientMock;

    @Mock
    private IConsulterContratClient consulterContratClientMock;

    @Mock
    private IConsulterOptionRenteContratClient consulterOptionRenteContratMock;

    @Before
    public void init() throws TechnicalException, ParseException {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(contratDetailMapper, "calculerEncoursContratFacade", calculerEncoursContratFacade);
        ReflectionTestUtils.setField(contratParcoursMapper, "calculerEncoursContratFacade", calculerEncoursContratFacade);
        when(userContextHolder.get()).thenReturn(createUserContext());
        // when(requestContext.getContrat()).thenReturn(createContratId());
        when(contratDetailsFacadeImpl.rechercherAllContratsRentes()).thenReturn(contratRentes());

        when(contratFacade.rechercherContrats(any(IFilterContrats.class))).thenReturn(contratRentes());
        if (contratRentes().get(0).isPacte()) {
            when(contratVifHelper.isVifPossible(any(), any())).thenReturn(true);
        } else {
            when(contratVifHelper.isVifPossible(any())).thenReturn(true);
        }

        when(rechercherPrestationsClientMock.rechercherPrestationsClient(any())).thenReturn(createPrestationDto());
        when(consulterContratClientMock.consulterContratTechnique(any())).thenReturn(createContratTechnique());
        when(consulterOptionRenteContratMock.consulterOptionRenteContrat(any(ConsulterOptionRenteIn.class))).thenReturn(createOptionsRente());
    }

    @Test
    public void shouldStart() throws TechnicalException {
        InfoContratsDetailDTO infoContratsDetailDTO = contratDetailsFacadeImpl.start();
        Assert.assertEquals(2, infoContratsDetailDTO.getAutresContrats().size());
        Assert.assertNotNull(infoContratsDetailDTO.getContrat());
    }

    @Test
    public void shouldStartIfNoContratId() throws TechnicalException {
        when(requestContext.getContrat()).thenReturn(null);
        InfoContratsDetailDTO infoContratsDetailDTO = contratDetailsFacadeImpl.start();
        Assert.assertEquals(2, infoContratsDetailDTO.getAutresContrats().size());
        Assert.assertNotNull(infoContratsDetailDTO.getContrat());
    }

    private List<ContratRente> contratRentes() {
        return Arrays.asList(createContratRente("id2", "NumMDP", CodeSiloType.MDP), createContratRente("id1", "NumERE", CodeSiloType.ERE));
    }

    private ContratRente createContratRente(String id, String idAssure, CodeSiloType silo) {
        ContratRente contratRente = new ContratRente();
        contratRente.setId(id);
        contratRente.setIdentifiantAssure(idAssure);
        contratRente.setCodeSilo(silo);
        contratRente.setEtatContrat(SituationContratEnum.CREATION);
        contratRente.setAffichageType(AffichageType.NORMAL);
        contratRente.setDateSitCtr(relativeDate(-6));
        contratRente.setPacte(false);

        return contratRente;
    }

    @NonNull
    private Date relativeDate(int nbMois) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MONTH, nbMois);
        return calendar.getTime();
    }

    private UserContext createUserContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
        Partenaire partenaire = new Partenaire();
        partenaire.setIdContrats(Collections.singletonList("id1"));
        userContext.setPartenaire(partenaire);
        return userContext;
    }

    private RechercherContratTechniqueOut createContratTechnique() {
        RechercherContratTechniqueOut contratTechnique = new RechercherContratTechniqueOut();
        DivisionRente divisionRente1 = new DivisionRente();
        divisionRente1.setCodeDivisionRente("RENTE");
        AnnuiteRente annuiteRente1 = new AnnuiteRente();
        annuiteRente1.setMontantAnnuite(new BigDecimal("25.12"));
        annuiteRente1.setDateFinAnnuite(DateUtils.createTimelessDate("02/10/2020"));
        divisionRente1.setCodeDivisionRente("RENTE");
        AnnuiteRente annuiteRente2 = new AnnuiteRente();
        annuiteRente2.setMontantAnnuite(new BigDecimal("12.18"));
        annuiteRente2.setDateFinAnnuite(DateUtils.createTimelessDate("02/10/2021"));
        divisionRente1.setAnnuiteRenteList(Arrays.asList(annuiteRente1, annuiteRente2));
        contratTechnique.setDivisionRente(Collections.singletonList(divisionRente1));
        InfoRente infoRente= new InfoRente();
        infoRente.setDateProchainPaiementRente(DateUtils.createTimelessDate("15/12/2030"));
        infoRente.setCodeEcheancePrestationRente(Periodicite.MENSUEL.getCode());
        contratTechnique.setInfoRente(infoRente);
        return contratTechnique;
    }

    private PrestationsDto createPrestationDto() {
        PrestationsDto prestationsDto = new PrestationsDto();
        OccurenceReglement occurenceReglement1 = new OccurenceReglement();
        DetailArrerageRente detailArrerageRente1 = new DetailArrerageRente();
        detailArrerageRente1.setCodeEtatArrerage("ARRAJ");
        detailArrerageRente1.setLibelleTypeArrerage("RENTES");
        detailArrerageRente1.setMontantArrerageHT(BigDecimal.valueOf(46.6));
        RegularisationEcheance echeance= new RegularisationEcheance();
        echeance.setMontantTotalRegularisation(BigDecimal.valueOf(10.66));
        List<RegularisationEcheance> echeanceList= new ArrayList<>();
        echeanceList.add(echeance);
        detailArrerageRente1.setRegularisationEcheances(echeanceList);
        detailArrerageRente1.setMontantRevalorisationArrerageHT(BigDecimal.valueOf(13.5));
        detailArrerageRente1.setDateMiseEnPaiementArrerage(DateUtils.createTimelessDate("01/08/2021"));
        detailArrerageRente1.setIdentifiantArrerage("idArrerageRente");
        occurenceReglement1.setDetailArrerageRente(detailArrerageRente1);
        occurenceReglement1.setIdentifiantParent("idArrerageRente");
        Reglement reglement1 = new Reglement();
        reglement1.setIdentificationReglement("idReglement");
        Pasrau pasrau=new Pasrau();
        pasrau.setMontantPAS(BigDecimal.valueOf(2.5));
        reglement1.setPasrau(pasrau);
        AutrePrelevement autrePrelevementCsgCasa = new AutrePrelevement();
        autrePrelevementCsgCasa.setCodeTypePrelevementSilo("CsgCasa");
        autrePrelevementCsgCasa.setMontantPrelevement(BigDecimal.valueOf(0.8));
        AutrePrelevement autrePrelevementCrds = new AutrePrelevement();
        autrePrelevementCrds.setCodeTypePrelevementSilo("CRDS");
        autrePrelevementCrds.setMontantPrelevement(BigDecimal.valueOf(0.4));
        AutrePrelevement autrePrelevementSs = new AutrePrelevement();
        autrePrelevementSs.setCodeTypePrelevementSilo("SS");
        autrePrelevementSs.setMontantPrelevement(BigDecimal.valueOf(0.4));
        AutrePrelevement autrePrelevementCode3 = new AutrePrelevement();
        autrePrelevementCode3.setCodeTypePrelevementSilo("3");
        autrePrelevementCode3.setMontantPrelevement(BigDecimal.valueOf(0.4));
        List<AutrePrelevement> autrePrelevementList= new ArrayList<>();
        autrePrelevementList.add(autrePrelevementCrds);
        autrePrelevementList.add(autrePrelevementCsgCasa);
        autrePrelevementList.add(autrePrelevementSs);
        autrePrelevementList.add(autrePrelevementCode3);
        reglement1.setAutrePrelevements(autrePrelevementList);
        occurenceReglement1.setReglement(reglement1);
        Paiement paiement1 = new Paiement();
        paiement1.setMontantPaiement(new BigDecimal("5.0"));
        paiement1.setCodeStatutPaiement("Reglé");
        occurenceReglement1.setPaiements(Collections.singletonList(paiement1));

        OccurenceReglement occurenceReglement2 = new OccurenceReglement();
        DetailArrerageRente detailArrerageRente2 = new DetailArrerageRente();
        detailArrerageRente2.setCodeEtatArrerage("ARRAJ");
        detailArrerageRente2.setLibelleTypeArrerage("MAJORATION");
        RegularisationEcheance echeance1= new RegularisationEcheance();
        echeance1.setMontantTotalRegularisation(BigDecimal.valueOf(10.66));
        List<RegularisationEcheance> echeanceList1= new ArrayList<>();
        echeanceList1.add(echeance1);
        detailArrerageRente2.setRegularisationEcheances(echeanceList1);
        detailArrerageRente2.setDateMiseEnPaiementArrerage(DateUtils.createTimelessDate("02/10/2021"));
        detailArrerageRente2.setMontantArrerageHT(BigDecimal.valueOf(46.6));
        detailArrerageRente2.setMontantRevalorisationArrerageHT(BigDecimal.valueOf(13.5));
        detailArrerageRente2.setIdentifiantArrerage("idArrerageMajoration");
        occurenceReglement2.setDetailArrerageRente(detailArrerageRente2);
        occurenceReglement2.setIdentifiantParent("idArrerageMajoration");
        Reglement reglement = new Reglement();
        reglement.setIdentificationReglement("idReglement");
        Pasrau pasrau1 =new Pasrau();
        pasrau1.setMontantPAS(BigDecimal.valueOf(2.5));
        reglement.setPasrau(pasrau1);
        AutrePrelevement autrePrelevementCsgCasa1 = new AutrePrelevement();
        autrePrelevementCsgCasa1.setCodeTypePrelevementSilo("CsgCasa");
        autrePrelevementCsgCasa1.setMontantPrelevement(BigDecimal.valueOf(0.8));
        AutrePrelevement autrePrelevementCrds1 = new AutrePrelevement();
        autrePrelevementCrds1.setCodeTypePrelevementSilo("CRDS");
        autrePrelevementCrds1.setMontantPrelevement(BigDecimal.valueOf(0.4));
        AutrePrelevement autrePrelevementSs1 = new AutrePrelevement();
        autrePrelevementSs1.setCodeTypePrelevementSilo("SS");
        autrePrelevementSs1.setMontantPrelevement(BigDecimal.valueOf(0.4));
        List<AutrePrelevement> autrePrelevementList1 = new ArrayList<>();
        autrePrelevementList1.add(autrePrelevementCrds1);
        autrePrelevementList1.add(autrePrelevementCsgCasa1);
        autrePrelevementList1.add(autrePrelevementSs1);
        reglement.setAutrePrelevements(autrePrelevementList1);
        occurenceReglement2.setReglement(reglement);
        Paiement paiement2 = new Paiement();
        paiement2.setMontantPaiement(new BigDecimal("10.0"));
        paiement2.setCodeStatutPaiement("Payé");
        occurenceReglement2.setPaiements(Collections.singletonList(paiement2));

        OccurenceReglement occurenceReglement3 = new OccurenceReglement();
        DetailArrerageRente detailArrerageRente3 = new DetailArrerageRente();
        detailArrerageRente3.setCodeEtatArrerage("ARRAJ");
        detailArrerageRente3.setLibelleTypeArrerage("RENTES");
        detailArrerageRente3.setDateMiseEnPaiementArrerage(DateUtils.createTimelessDate("02/10/2021"));
        detailArrerageRente3.setIdentifiantArrerage("idArrerage");
        occurenceReglement3.setDetailArrerageRente(detailArrerageRente3);
        occurenceReglement3.setIdentifiantParent("idReglement");
        Reglement reglement3 = new Reglement();
        reglement3.setIdentificationReglement("idReglement");
        Paiement paiement = new Paiement();
        paiement.setMontantPaiement(new BigDecimal("12.5"));
        paiement.setCodeStatutPaiement("Payé");
        occurenceReglement3.setPaiements(Collections.singletonList(paiement));

        prestationsDto.setOccurenceReglementList(Arrays.asList(occurenceReglement1, occurenceReglement2, occurenceReglement3));

        return prestationsDto;
    }

    private ContratParcoursDto createContratParcours() {
        return ContratParcoursDto.builder().nomContrat("nomcontrat").identifiantAssure("idAssure").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .build();
    }

    @Test
    public void rechercherPaiementsTest() {
        ContratParcoursDto contratRente = createContratParcours();
        List<HistoriquePaiement> historiquePaiementList = contratDetailsFacadeImpl.rechercherPaiementsRecus(contratRente);
        Assert.assertNotNull(historiquePaiementList);

    }


    private ConsulterOptionRenteContratDto createOptionsRente() throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Date dateDebut = formatter.parse("07-07-2013");
        Date dateFin = formatter.parse("07-07-2019");
        OptionRenteDto option1 = OptionRenteDto.builder().optRenteType(OptionRenteType.DIFF).dateDebutEffet(dateDebut)
                .dateFinEffet(dateFin).build();
        OptionRenteDto option2 = OptionRenteDto.builder().optRenteType(OptionRenteType.DIFF).dateDebutEffet(dateFin)
                .dateFinEffet(null).build();
        return ConsulterOptionRenteContratDto.builder().optionRentes(Arrays.asList(option1, option2)).build();

    }
    private RechercherPaiementDetail createRechercherPaiementDetail(){
        ContratParcoursDto contrat = ContratParcoursDto.builder().nomContrat("nomcontrat").identifiantAssure("idAssure").affichageType(AffichageType.NORMAL).codeSilo(CodeSiloType.ERE)
                .build();

        DetailArrerage detailArrerage=DetailArrerage.builder().idArrerageRente("idArrerageRente").idArrerageMajoration("idArrerageMajoration")
                .build();
        return RechercherPaiementDetail.builder().contratParcours(contrat).arrerageId(detailArrerage)
                .build();
    }
    private PaiementDetailDto createPaiementDetailDto(){
        RenteBrute renteBrute= new RenteBrute();
        renteBrute.setMontantTotalRente(BigDecimal.valueOf(448));
        renteBrute.setMontantBruteRente(BigDecimal.valueOf(256));
        renteBrute.setMontantBruteMajoration(BigDecimal.valueOf(56));
        renteBrute.setMontantBruteRenteRevalorisation(BigDecimal.valueOf(16));
        renteBrute.setMontantBruteMajorationRevalorisation(BigDecimal.valueOf(26));
        MontantsRetenus montantsRetenus= new MontantsRetenus();
        montantsRetenus.setTotalPrelevementsMajoration(BigDecimal.valueOf(16));
        montantsRetenus.setMontantPreleventMajorationPasrau(BigDecimal.valueOf(1));
        montantsRetenus.setMontantPrelevementMajorationSs(BigDecimal.valueOf(16));
        montantsRetenus.setMontantPrelevementMajorationCsgCasa(BigDecimal.valueOf(16));
        montantsRetenus.setMontantPrelevementMajorationCrds(BigDecimal.valueOf(16));
        montantsRetenus.setMontantPrelevementRenteSs(BigDecimal.valueOf(1));
        montantsRetenus.setMontantPreleventRentePasrau(BigDecimal.valueOf(1.3));
        montantsRetenus.setMontantPrelevementRenteCrds(BigDecimal.valueOf(0.6));
        montantsRetenus.setMontantPrelevementRenteCsgCasa(BigDecimal.valueOf(0));
        montantsRetenus.setTotalPrelevementsRenteBase(BigDecimal.valueOf(16));
        return PaiementDetailDto.builder().montantsRetenus(montantsRetenus).renteBrute(renteBrute)
                .montantsTotalsRegularisation(BigDecimal.valueOf(10.66)).build();
    }
    @Test
    public void getDetailsPaiementsInfoTest(){
        RechercherPaiementDetail paiementDetail= createRechercherPaiementDetail();
        PaiementDetailDto p = contratDetailsFacadeImpl.getPaiementsDetailsInfo(paiementDetail);
        Assert.assertNotNull(p);
        Assert.assertEquals(BigDecimal.valueOf(10.66),p.getMontantsTotalsRegularisation());

    }




}
