package fr.ag2rlamondiale.erb.security;

import org.junit.Test;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collections;

import static org.junit.Assert.*;

public class ErbUserDetailsTest {

    private final String USER1 = "user1";
    private final String USER2 = "user2";

    @Test
    public void test() {
        ErbUserDetails userEcrs1 = user(USER1);
        ErbUserDetails userEcrs2 = user(USER2);
        ErbUserDetails userEcrs3 = user(USER1);

        assertNull(userEcrs1.getEnvironnement());
        assertNull(userEcrs1.getCodeDelegation());
        assertNull(userEcrs1.getUserMail());
        assertNull(userEcrs1.getUserSn());
        assertNull(userEcrs1.getUserGivenName());
        assertTrue(userEcrs1.equals(userEcrs3) && userEcrs3.equals(userEcrs1));
        assertEquals(userEcrs1.hashCode(),userEcrs3.hashCode());
        assertNotEquals(userEcrs1, userEcrs2);
        assertNotNull(userEcrs1);
    }

    private ErbUserDetails user(String username) {
        UserDetails userDetails = new User(username, "password", Collections.emptyList());
        ErbUserDetails userEcrs = new ErbUserDetails(userDetails, true);

        userEcrs.setEnvironnement("");
        userEcrs.setCodeDelegation("");
        userEcrs.setUserFirstLastName("");
        userEcrs.setUserMail("");
        userEcrs.setUserSn("");
        userEcrs.setUserGivenName("");
        return userEcrs;
    }
}
