package fr.ag2rlamondiale.erb.pfs.domain.rente;

import lombok.Data;

@Data
public class CalculerEligibiliteRenteIn {
    private String idContrat;
    private String idPersonne;
}
