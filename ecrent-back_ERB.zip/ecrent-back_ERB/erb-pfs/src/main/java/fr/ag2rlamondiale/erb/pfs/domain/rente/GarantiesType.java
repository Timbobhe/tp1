package fr.ag2rlamondiale.erb.pfs.domain.rente;

import org.apache.commons.collections4.CollectionUtils;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public enum GarantiesType {

    VIA(List.of("VIA"),"Vous disposez d'une rente viagère non réversible"),
    VIAREV(List.of("VIA","REV"),"Vous disposez d'une rente viagère réversible"),
    VIAANG(List.of("VIA","ANG"),"Vous disposez d'une rente viagère avec trimestrialités garanties"),
    VIADEC(List.of("VIA","DEC"),"Vous disposez d'une rente viagère avec option décès"),
    VIADEP(List.of("VIA","DEP"),"Vous disposez d'une rente viagère avec option dépendance"),
    VIAREVDEP(List.of("VIA","REV","DEP"),"Vous disposez d'une rente viagère réversible avec option dépendance"),
    VIAREVDEC(List.of("VIA","REV","DEC"),"Vous disposez d'une rente viagère réversible avec option décès"),
    VIAREVANG(List.of("VIA","REV","ANG"),"Vous disposez d'une rente viagère réversible avec trimestrialités garanties"),
    VIAREVDECDEP(List.of("VIA","REV","DEC","DEP"),"Vous disposez d'une rente viagère réversible avec option décès et dépendance"),
    VIADEPDEC(List.of("VIA","DEP","DEC"),"Vous disposez d'une rente viagère avec option décès et dépendance"),
    LIM(List.of("LIM"),"Vous disposez d'une rente à durée limitée"),
    LIMREV(List.of("LIM","REV"),"Vous disposez d'une rente réversible à durée limitée"),
    CER(List.of("CER"),"Vous disposez d'une rente à annuités certaines"),
    CYP(List.of("CYP"),"Vous disposez d'une rente viagère Cycle de vie"),
    VIAMAJ(List.of("VIA","MAJ"),"Vous disposez d'une rente viagère avec option rente majorée / minorée"),
    VIAREVMAJ(List.of("VIA","REV","MAJ"),"Vous disposez d'une rente viagère réversible avec option rente majorée / minorée"),
    CYD(List.of("CYD"),"Vous disposez d'une rente viagère Cycle de vie dépendance"),
    CYDREV(List.of("CYD","REV"),"Vous disposez d'une rente viagère réversible Cycle de vie dépendance"),
    VIARVD(List.of("VIA","RVD"),"Vous disposez d'une rente viagère non réversible"),
    VIAREVRVD(List.of("VIA","REV","RVD"),"Vous disposez d'une rente viagère réversible"),
    VIAREVRVDRED(List.of("VIA","REV","RVD","RED"),"Vous disposez d'une rente viagère réversible"),
    CYF(List.of("CYF"),"Vous disposez d'une rente viagère Cycle de vie avec différé"),
    DEFAULT(new ArrayList<>(),"Vous disposez d’un contrat de rente. Pour en connaître les détails, veuillez-vous reporter au document « certificat de rente");

    private List<String> codes;
    private String description;

    public String getDescription(){
        return this.description;
    }

    GarantiesType(List<String> codes, String description) {
        this.codes = codes;
        this.description = description;
    }

    public static GarantiesType getDescriptionFromCodes(@Nonnull final List<String> codes){
        for(GarantiesType type : values()){
            if(CollectionUtils.isEqualCollection(type.codes,codes)){
                return type;
            }
        }
        return DEFAULT;
    }
}
