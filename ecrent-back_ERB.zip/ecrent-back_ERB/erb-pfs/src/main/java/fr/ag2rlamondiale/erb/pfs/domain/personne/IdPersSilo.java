package fr.ag2rlamondiale.erb.pfs.domain.personne;

import lombok.Data;

import java.io.Serializable;

@Data
public class IdPersSilo implements Serializable {
    private String idSilo;
    private String codeAppli;
}
