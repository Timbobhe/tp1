package fr.ag2rlamondiale.erb.pfs;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class ErbPfsConfig {
}
