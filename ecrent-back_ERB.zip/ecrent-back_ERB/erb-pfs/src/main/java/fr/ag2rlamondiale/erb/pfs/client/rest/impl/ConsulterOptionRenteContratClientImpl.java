package fr.ag2rlamondiale.erb.pfs.client.rest.impl;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.*;
import fr.ag2rlamondiale.erb.pfs.client.rest.IConsulterOptionRenteContratClient;
import fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente.ConsulterOptRenteCtrRequestMapper;
import fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente.ConsulterOptRenteCtrResponseMapper;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.trm.log.LogError;
import fr.ag2rlamondiale.trm.rest.PfsRestException;
import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestService;
import fr.ag2rlamondiale.trm.rest.jaxb.response.FuncError;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ConsulterOptionRenteContratClientImpl implements IConsulterOptionRenteContratClient, SelfReferencingBean {

    private static final String NOT_FOUND_PATTERN = ".*404.*";

    @Autowired
    private ConsulterOptRenteCtrRequestMapper consulterOptRenteCtrRequestMapper;

    @Autowired
    private ConsulterOptRenteCtrResponseMapper consulterOptRenteCtrResponseMapper;

    private IConsulterOptionRenteContratClient springProxy;

    @Override
    @LogError(category = "REST")
    @PfsRestService(serviceId = "GestRente_1/ConsulterOptRenteCtr_1", alternative = "${pfs.consulter.option.rente.contrat.endPointAddress}")
    public ResponseJSONRootType restConsulterOptionRenteContrat(RequestJSONRootType requestJSONRootType) {
        return null;
    }

    public ConsulterOptionRenteContratDto consulterOptionRenteContrat(ConsulterOptionRenteIn in) {

        ConsulterOptRenteCtrType request = consulterOptRenteCtrRequestMapper.map(in);
        RequestJSONRootType requestJson = new RequestJSONRootType();
        requestJson.setConsulterOptRenteCtr(request);
        try {
            ResponseJSONRootType response = this.springProxy.restConsulterOptionRenteContrat(requestJson);
            return consulterOptRenteCtrResponseMapper.mapOptionRentes(response);

        } catch (PfsRestException e) {
            for (FuncError error : e.getHeader().getFuncError()) {
                if (error.getErrorMessage().matches(NOT_FOUND_PATTERN)) {
                    return null;
                }
            }
            throw e;
        }
    }

    @Override
    public void setProxy(Object o) {
        this.springProxy = (IConsulterOptionRenteContratClient) o;
    }

    public IConsulterOptionRenteContratClient getSpringProxy() {
        return springProxy;
    }
}
