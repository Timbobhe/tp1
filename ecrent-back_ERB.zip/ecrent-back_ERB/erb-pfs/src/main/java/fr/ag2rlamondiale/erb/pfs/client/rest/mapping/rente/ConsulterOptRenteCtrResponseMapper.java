package fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.*;
import fr.ag2rlamondiale.erb.pfs.domain.rente.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.Date;
import java.util.Objects;

@Mapper(componentModel = "spring", builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class ConsulterOptRenteCtrResponseMapper {

    private static final String DATE_FORMAT  = "yyyy-MM-dd";

    @Mapping(target = "optionRentes", source = "consulterOptRenteCtrResponse.consulterOptRenteCtrFunc.optRente")
    public abstract ConsulterOptionRenteContratDto mapOptionRentes(ResponseJSONRootType type);


    @Mapping(expression = "java(fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteType.fromNameAndLibelle(optRenteType.getCodeOptRenteSousc(), optRenteType.getLibOptRenteSousc()))", target = "optRenteType")
    @Mapping(target = "dateDebutEffet", source = "dateDebutEffetOptRenteSousc")
    @Mapping(target = "dateFinEffet", source = "dateFinEffetOptRenteSousc")
    @Mapping(target = "tauxGarOptRente", source = "tauxGarOptRenteSousc")
    @Mapping(target = "dateDifferePrevisionnel", source = "dateDifferePrevisionnel")
    @Mapping(target = "palierRentes", source = "palierRente")
    @Mapping(target = "benef", source = "benef")
    public abstract OptionRenteDto map(OptRenteType optRenteType);


    @Mapping(target = "identSilo", source = "identSilo")
    @Mapping(target = "nomUsage", source = "infoPP.nomUsage")
    @Mapping(target = "dateDeces", source = "type.signq", qualifiedByName = "calculDateDeces")
    @Mapping(target = "dateMariage", source = "type.detailPP", qualifiedByName = "calculDateMariage")
    @Mapping(target = "dateDivorce", source = "type.detailPP", qualifiedByName = "calculDateDivorce")
    @Mapping(target = "indMariagePrec", source = "detailPP.infoFam.indMariagePrec")
    @Mapping(target = "indBenefIrrev", source = "indBenefIrrev")
    @Mapping(target = "tauxPartBenef", source = "tauxPartBenef")
    @Mapping(target = "benefScdRang", source = "benefScdRang")
    @Mapping(source = "infoLienPers", target = "lienPersonnesType", qualifiedByName = "infoLienPersonne")
    public abstract Benef mapBenef(BenefType type);

    @Named("calculDateDeces")
    Date mapDateDeces(SignqResponseType type) {
        if (type == null) {
            return null;
        }

        return type.getDateDeces() != null ? fr.ag2rlamondiale.trm.utils.DateUtils.parseDate(type.getDateDeces(), DATE_FORMAT) : null;
    }

    @Named("calculDateMariage")
    Date mapDateMariage(DetailPPResponseType type) {
        if (type == null || type.getInfoFam() == null) {
            return null;
        }
        return type.getInfoFam().getDateMariage() != null ? fr.ag2rlamondiale.trm.utils.DateUtils.parseDate(type.getInfoFam().getDateMariage(), DATE_FORMAT) : null;
    }

    @Named("calculDateDivorce")
    Date mapDateDivorce(DetailPPResponseType type) {
        if (type == null || type.getInfoFam() == null) {
            return null;
        }
        return type.getInfoFam().getDateDivorce() != null ? fr.ag2rlamondiale.trm.utils.DateUtils.parseDate(type.getInfoFam().getDateDivorce(), DATE_FORMAT) : null;
    }

    @Named("infoLienPersonne")
    LienPersonnesType map(InfoLienPersResponseType responseType) {
        if(Objects.nonNull(responseType)){
            return LienPersonnesType.fromCodeAndLibelle(responseType.getCodeTypeLienPers(),
                    responseType.getLibTypeLienPers());
        }
        return null;
    }

    @Mapping(expression = "java(fr.ag2rlamondiale.erb.pfs.domain.rente.BeneficiaireType.fromCodeAndLibelle(type.getTypeBenefScdRang(), type.getLibBenef()))", target = "benefScdRangType")
    @Mapping(expression = "java(fr.ag2rlamondiale.erb.pfs.domain.rente.ModePaiementType.fromCodeAndLibelle(type.getCodeModePaimtBenefScdRang(), type.getLibModePaimtBenefScdRang()))", target = "modePaimtBenefScdRang")
    @Mapping(target = "identSilo", source = "identSilo")
    @Mapping(target = "codeBIC", source = "codeBICIBAN.codeBIC")
    @Mapping(target = "codeIBAN", source = "codeBICIBAN.codeIBAN")
    @Mapping(target = "devise", source = "devise")
    public abstract BenefScdRang mapBenefSnd(BenefScdRangResponseType type);
}
