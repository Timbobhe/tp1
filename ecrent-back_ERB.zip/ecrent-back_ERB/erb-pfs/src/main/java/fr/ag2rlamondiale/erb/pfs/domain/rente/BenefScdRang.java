package fr.ag2rlamondiale.erb.pfs.domain.rente;

import fr.ag2rlamondiale.erb.pfs.domain.personne.IdPersSilo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class BenefScdRang implements Serializable {
    private IdPersSilo identSilo;
    private String nomUsage;
    private BeneficiaireType benefScdRangType;
    private Date dateDebutBenefScdRang;
    private Date dateFinBenefScdRang;
    private BigDecimal tauxPartBenefScdRang;
    private String devise;
    private String mntPartBenefScdRang;
    private ModePaiementType modePaimtBenefScdRang;
    private String codeBIC;
    private String codeIBAN;
}
