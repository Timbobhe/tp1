package fr.ag2rlamondiale.erb.pfs.client.rest;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.*;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;

public interface IConsulterOptionRenteContratClient {
	ResponseJSONRootType restConsulterOptionRenteContrat(RequestJSONRootType requestJSONRootType);

    ConsulterOptionRenteContratDto consulterOptionRenteContrat(ConsulterOptionRenteIn consulterOptionRenteContrat);
}
