package fr.ag2rlamondiale.erb.pfs.domain.rente;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ConsulterOptionRenteIn {
    private String idContrat;
    private String idPersonne;
}
