package fr.ag2rlamondiale.erb.pfs.domain.rente;

import fr.ag2rlamondiale.erb.pfs.domain.personne.IdPersSilo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class Benef implements Serializable {
    private IdPersSilo identSilo;
    private String nomUsage;
    private Date dateDeces;
    private Date dateMariage;
    private Date dateDivorce;
    private boolean indMariagePrec;
    private LienPersonnesType lienPersonnesType;
    private boolean indBenefIrrev;
    private BigDecimal tauxPartBenef;
    private List<BenefScdRang> benefScdRang;
}
