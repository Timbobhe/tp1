package fr.ag2rlamondiale.erb.pfs.domain.rente;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class PalierRente implements Serializable {

    private String idPalier;
    private Date dateFinPalier;
    private BigDecimal tauxPalier;

}
