package fr.ag2rlamondiale.erb.pfs.domain.rente;

import javax.annotation.Nonnull;

public enum OptionRenteType {

    VIAG("Viagère","VIA"),
    LIMITE("Limitée","LIM"),
    CERT("Certaines","CER"),
    CYCLEDIF("Cycle de vie différé","CYF"),
    CYCLEDEP("Cycle de vie avec dépendance","CYD"),
    CYCLEPAL("Cycle de vie par palier","CYP"),
    REVERS("Réversion","REV"),
    ANNGAR("Annuités garanties","ANG"),
    /* Les contrats qui disposent des garanties suivantes doivent être exclus */
    INVAL("Invalidité","INV"),
    REVIAGDIF("Viagère différée","RVD"),
    REVDIF("Réversion différée","RED"),

    /* Garanties non nécessaire pour l'eligibilité*/
    DECES("Décès","DEC"),
    DEPEND("Dépendances","DEP"),
    DIFF("Différée","DIF"),
    MAJORA("Majoration","MAJ"),
    CAPDECES("Capital décès","CDC");

    private String libelle;
    private String code;

    OptionRenteType(String libelle, String code) {
        this.libelle = libelle;
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public String getCode() {
        return code;
    }

    public static OptionRenteType fromNameAndLibelle(@Nonnull String name, @Nonnull String libelle) {
        for (OptionRenteType item : OptionRenteType.values()) {
            if (item.name().equals(name) && item.getLibelle().equals(libelle)) {
                return item;
            }
        }
        return null;
    }

    public static OptionRenteType fromCode(@Nonnull String code) {
        for (OptionRenteType item : OptionRenteType.values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }
        return null;
    }
}
