package fr.ag2rlamondiale.erb.pfs.domain.contrat;

import lombok.Data;

import java.io.Serializable;

@Data
public class IdContratSilo implements Serializable {
    private String idSilo;
    private String codeAppli;
}
