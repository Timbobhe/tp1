package fr.ag2rlamondiale.erb.pfs.domain.rente;

import javax.annotation.Nonnull;

public enum BeneficiaireType {
    NRM("NORMAL"),
    ONX("ONEREUX");

    private String libelle;

    BeneficiaireType(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelle() {
        return libelle;
    }

    public static BeneficiaireType fromCodeAndLibelle(@Nonnull final String code, @Nonnull final String libelle) {
        for (BeneficiaireType item : BeneficiaireType.values()) {
            if (item.name().equals(code) && item.getLibelle().equals(libelle)) {
                return item;
            }
        }
        return null;
    }
}
