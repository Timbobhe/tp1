package fr.ag2rlamondiale.erb.pfs.utils.contrats;

import lombok.Getter;

import java.util.Arrays;

public class LibelleEtatContrat {
    private static final String EN_COURS = "En cours";
    private static final String EN_COURS_SANS_COTISATION = "En cours sans cotisation";
    private static final String RETRAITE = "Retraité";
    private static final String TRANSFERE = "Transféré";
    private static final String CLOTURE = "Clôturé";
    private static final String SORTI = "Sorti";

    @Getter
    public enum LibelleEtatContratEREEnum {
        C(EN_COURS),
        A(EN_COURS),
        L(EN_COURS_SANS_COTISATION),
        Z(RETRAITE),
        T(TRANSFERE),
        S(CLOTURE),
        X(CLOTURE),
        R(CLOTURE),
        W(EN_COURS),
        V(EN_COURS);

        private final String etat;

        LibelleEtatContratEREEnum(String etat) {
            this.etat = etat;
        }

        public static String getEtatFromCode(String code) {
            return  Arrays.stream(LibelleEtatContratEREEnum.values())
                    .filter(value -> value.name().equals(code))
                    .map(LibelleEtatContratEREEnum::getEtat)
                    .findFirst().orElse(null);
        }
    }

    @Getter
    public enum LibelleEtatContratMDPEnum {
        EN_COURS("2", LibelleEtatContrat.EN_COURS),
        EN_COURS_SS_PRIMES("3", LibelleEtatContrat.EN_COURS),
        RACHETE_D("6", CLOTURE),
        RACHETE_DEMANDE("7", CLOTURE),
        EXPI_AVEC_CONTRAT("8", SORTI),
        EXPI_SANS_CONTRAT("9", SORTI),
        ANNEE_BLANCHE("12", LibelleEtatContrat.EN_COURS),
        SINISTRE("13", CLOTURE),
        LIB_PRIME_OFFICE("16", LibelleEtatContrat.EN_COURS),
        LIB_PRIME_DEMANDE("17", LibelleEtatContrat.EN_COURS),
        REDUIT("20", LibelleEtatContrat.EN_COURS),
        TRANSFORME("21", SORTI);

        private String code;
        private String etat;

        LibelleEtatContratMDPEnum(String code, String etat) {
            this.code = code;
            this.etat = etat;
        }

        public static String getEtatFromCode(String code) {
            return  Arrays.stream(LibelleEtatContratMDPEnum.values())
                    .filter(value -> value.getCode().equals(code))
                    .map(LibelleEtatContratMDPEnum::getEtat)
                    .findFirst().orElse(null);
        }
    }
}
