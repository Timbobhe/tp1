package fr.ag2rlamondiale.erb.pfs.domain.rente;

import javax.annotation.Nonnull;

public enum ModePaiementType {

    CHEQ("Chèque"),
    VRT("Virement");
    private String libelle;

    ModePaiementType(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelle() {
        return libelle;
    }

    public static ModePaiementType fromCodeAndLibelle(@Nonnull final String code, @Nonnull final String libelle) {
        for (ModePaiementType item : ModePaiementType.values()) {
            if (item.name().equals(code) && item.getLibelle().equals(libelle)) {
                return item;
            }
        }
        return null;
    }
}
