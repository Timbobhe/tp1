package fr.ag2rlamondiale.erb.pfs.domain.rente;

import javax.annotation.Nonnull;

public enum  LienPersonnesType {
    AUCUN("Pas de lien de parenté"),
    CONJ("Conjoint");
    private String libelle;

    LienPersonnesType(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelle() {
        return libelle;
    }

    public static LienPersonnesType fromCodeAndLibelle(@Nonnull final String code, @Nonnull final String libelle) {
        for (LienPersonnesType item : LienPersonnesType.values()) {
            if (item.name().equalsIgnoreCase(code) && item.getLibelle().equalsIgnoreCase(libelle)) {
                return item;
            }
        }
        return null;
    }
}
