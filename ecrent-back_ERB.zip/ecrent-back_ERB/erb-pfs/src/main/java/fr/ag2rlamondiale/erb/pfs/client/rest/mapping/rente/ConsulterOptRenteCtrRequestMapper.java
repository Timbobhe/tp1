package fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ConsulterOptRenteCtrType;

import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public abstract class ConsulterOptRenteCtrRequestMapper {

    @Mapping(source = "idContrat", target = "idSiloCtr.idSilo")
    @Mapping(expression = "java(fr.ag2rlamondiale.trm.domain.CodeApplicationType.PTV_RENTE_ERE.getCode())", target = "idSiloCtr.codeAppli")
    @Mapping(source = "idPersonne", target = "criteresFiltr.idSiloPers.idSilo")
    @Mapping(expression = "java(fr.ag2rlamondiale.trm.domain.CodeApplicationType.EGESPER_ERE.getCode())", target = "criteresFiltr.idSiloPers.codeAppli")
    public abstract ConsulterOptRenteCtrType map (ConsulterOptionRenteIn in);
}
