package fr.ag2rlamondiale.erb.pfs.domain.rente;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OptionRenteDto implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private OptionRenteType optRenteType;
    private Date dateDebutEffet;
    private Date dateFinEffet;
    private BigDecimal tauxGarOptRente;
    private Date dateDifferePrevisionnel;
    private List<PalierRente> palierRentes;
    private List<Benef> benef;
}
