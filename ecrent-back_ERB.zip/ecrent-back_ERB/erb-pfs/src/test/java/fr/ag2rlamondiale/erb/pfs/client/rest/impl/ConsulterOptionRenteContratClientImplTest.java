package fr.ag2rlamondiale.erb.pfs.client.rest.impl;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ConsulterOptRenteCtrType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ResponseJSONRootType;
import com.google.common.collect.Lists;
import fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente.ConsulterOptRenteCtrRequestMapperImpl;
import fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente.ConsulterOptRenteCtrResponseMapperImpl;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.trm.rest.PfsRestException;
import fr.ag2rlamondiale.trm.rest.jaxb.response.FuncError;
import fr.ag2rlamondiale.trm.rest.jaxb.response.Header;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ConsulterOptionRenteContratClientImplTest {
    @Spy
    private ConsulterOptRenteCtrRequestMapperImpl requestMapper;

    @Spy
    private ConsulterOptRenteCtrResponseMapperImpl responseMapper;

    @Mock
    ConsulterOptionRenteContratClientImpl mockProxy;

    @InjectMocks
    ConsulterOptionRenteContratClientImpl sut;


    @Before
    public void setUp() {
        sut.setProxy(mockProxy);
    }

    @Test
    public void should_return_option_rente_contrat() {
        when(requestMapper.map(any())).thenReturn(new ConsulterOptRenteCtrType());
        when(sut.getSpringProxy().restConsulterOptionRenteContrat(any())).thenReturn(new ResponseJSONRootType());

        ConsulterOptionRenteContratDto actual = sut.consulterOptionRenteContrat(new ConsulterOptionRenteIn());

        assertNotNull(actual);
    }

    @Test(expected = PfsRestException.class)
    public void should_throw_exception() {
        FuncError error = new FuncError();
        error.setErrorMessage("Aucun critere de recherche");
        Header header = new Header();
        header.setFuncError(Lists.newArrayList(error));

        when(sut.getSpringProxy().restConsulterOptionRenteContrat(any())).thenThrow(new PfsRestException(header));

        sut.consulterOptionRenteContrat(new ConsulterOptionRenteIn());
    }
}
