package fr.ag2rlamondiale.erb.pfs.client.rest.mapping.rente;

import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.BenefScdRangResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.BenefType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.CodeBICIBANResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ConsulterOptRenteCtrFuncType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ConsulterOptRenteCtrResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ConsulterOptRenteCtrType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.DetailPPResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.IdentSiloResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.InfoFamResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.InfoLienPersResponseType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.OptRenteType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.PalierRenteType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.ResponseJSONRootType;
import com.alm.esb.service.gestrente_1.consulteroptrentectr_1.SignqResponseType;
import fr.ag2rlamondiale.erb.pfs.domain.rente.*;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import io.jsonwebtoken.lang.Collections;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class ConsulterOptRenteCtrMapperTest {
    @InjectMocks
    ConsulterOptRenteCtrRequestMapperImpl inMapper;
    @InjectMocks
    ConsulterOptRenteCtrResponseMapperImpl outMapper;

    @Test
    public void consulterOptRenteCtrRequestMapperInTest() {
        ConsulterOptionRenteIn in = new ConsulterOptionRenteIn();
        in.setIdContrat("EV000167034000");
        in.setIdPersonne("P5149814");

        ConsulterOptRenteCtrType actual = inMapper.map(in);

        assertEquals("EV000167034000", actual.getIdSiloCtr().getIdSilo());
        assertEquals(CodeApplicationType.PTV_RENTE_ERE.getCode(), actual.getIdSiloCtr().getCodeAppli());
        assertEquals("P5149814", actual.getCriteresFiltr().getIdSiloPers().getIdSilo());
        assertEquals(CodeApplicationType.EGESPER_ERE.getCode(), actual.getCriteresFiltr().getIdSiloPers().getCodeAppli());
    }

    @Test
    public void consulterOptRenteCtrRequestMapperOutTest() {

        ConsulterOptionRenteContratDto actual = outMapper.mapOptionRentes(createConsulterOptRenteCtrResponseType());


        ResponseJSONRootType consulterOptRenteCtrResponseType = createConsulterOptRenteCtrResponseType();
        OptRenteType expectedOptRenteType = consulterOptRenteCtrResponseType.getConsulterOptRenteCtrResponse().getConsulterOptRenteCtrFunc().getOptRente().get(0);

        final OptionRenteDto currentOptionRenteDto = actual.getOptionRentes().get(0);

        assertEquals(Objects.requireNonNull(DateUtils.getDateOrNull(expectedOptRenteType.getDateDebutEffetOptRenteSousc())),
                currentOptionRenteDto.getDateDebutEffet());
        assertEquals(Objects.requireNonNull(DateUtils.getDateOrNull(expectedOptRenteType.getDateFinEffetOptRenteSousc())),
                currentOptionRenteDto.getDateFinEffet());
        assertEquals(expectedOptRenteType.getTauxGarOptRenteSousc(),
                currentOptionRenteDto.getTauxGarOptRente());
        assertEquals(Objects.requireNonNull(DateUtils.getDateOrNull(expectedOptRenteType.getPalierRente().get(0).getDateFinPalier())),
                currentOptionRenteDto.getPalierRentes().get(0).getDateFinPalier());
        assertEquals(expectedOptRenteType.getPalierRente().get(0).getIdPalier(), currentOptionRenteDto.getPalierRentes().get(0).getIdPalier());
        assertEquals(expectedOptRenteType.getPalierRente().get(0).getTauxPalier(), currentOptionRenteDto.getPalierRentes().get(0).getTauxPalier());
        assertNull(currentOptionRenteDto.getDateDifferePrevisionnel());

        Benef actualBenefDto = currentOptionRenteDto.getBenef().get(0);
        BenefType expectedBenefType = expectedOptRenteType.getBenef().get(0);

        assertNull(actualBenefDto.getNomUsage());
        assertNull(actualBenefDto.getDateDivorce());
        assertEquals(expectedBenefType.getIdentSilo().getIdSilo(), actualBenefDto.getIdentSilo().getIdSilo());
        assertEquals(expectedBenefType.getIdentSilo().getCodeAppli(), actualBenefDto.getIdentSilo().getCodeAppli());

        assertFalse(actualBenefDto.isIndMariagePrec());
        assertEquals(DateUtils.parseDate(expectedBenefType.getSignq().getDateDeces(), "yyyy-MM-dd"), actualBenefDto.getDateDeces());
        assertEquals(expectedBenefType.getInfoLienPers().getCodeTypeLienPers(), actualBenefDto.getLienPersonnesType().name());
        assertEquals(expectedBenefType.getTauxPartBenef(), actualBenefDto.getTauxPartBenef());

        BenefScdRang actualBenefScdRangDto = actualBenefDto.getBenefScdRang().get(0);
        BenefScdRangResponseType expectedBenefScdRangResponseType = expectedBenefType.getBenefScdRang().get(0);

        Assert.assertEquals(expectedBenefScdRangResponseType.getIdentSilo().getIdSilo(), actualBenefScdRangDto.getIdentSilo().getIdSilo());
        Assert.assertEquals(expectedBenefScdRangResponseType.getIdentSilo().getCodeAppli(), actualBenefScdRangDto.getIdentSilo().getCodeAppli());
        assertEquals(expectedBenefScdRangResponseType.getTypeBenefScdRang(), actualBenefScdRangDto.getBenefScdRangType().name());
        assertEquals(expectedBenefScdRangResponseType.getMntPartBenefScdRang().toString(), actualBenefScdRangDto.getMntPartBenefScdRang());
        assertEquals(expectedBenefScdRangResponseType.getDevise(), actualBenefScdRangDto.getDevise());
        assertEquals(expectedBenefScdRangResponseType.getNomUsage(), actualBenefScdRangDto.getNomUsage());
        assertEquals(Objects.requireNonNull(DateUtils.getDateOrNull(expectedBenefScdRangResponseType.getDateDebutBenefScdRang())), actualBenefScdRangDto.getDateDebutBenefScdRang());
        assertNull(actualBenefScdRangDto.getDateFinBenefScdRang());
        assertEquals(expectedBenefScdRangResponseType.getTauxPartBenefScdRang(), actualBenefScdRangDto.getTauxPartBenefScdRang());
        assertEquals(expectedBenefScdRangResponseType.getCodeModePaimtBenefScdRang(), actualBenefScdRangDto.getModePaimtBenefScdRang().name());
        assertEquals(expectedBenefScdRangResponseType.getCodeBICIBAN().getCodeBIC(), actualBenefScdRangDto.getCodeBIC());
        assertEquals(expectedBenefScdRangResponseType.getCodeBICIBAN().getCodeIBAN(), actualBenefScdRangDto.getCodeIBAN());
    }

    private ResponseJSONRootType createConsulterOptRenteCtrResponseType() {
    	ResponseJSONRootType reponseJsonRootType = new ResponseJSONRootType();
    	
        ConsulterOptRenteCtrResponseType responseType = new ConsulterOptRenteCtrResponseType();

        List<OptRenteType> optionRenteTypes = new ArrayList<>();
        OptRenteType optRenteType = new OptRenteType();
        optRenteType.setCodeOptRenteSousc("REVERS");
        optRenteType.setLibOptRenteSousc("Réversion");
        optRenteType.setDateDebutEffetOptRenteSousc(DateMapper.map(Date.valueOf("2009-04-18")));
        optRenteType.setTauxGarOptRenteSousc(BigDecimal.valueOf(0.6));
        optRenteType.setDateFinEffetOptRenteSousc(DateMapper.map(Date.valueOf("2009-04-17")));

        BenefType benefType = new BenefType();
        IdentSiloResponseType identSiloType = new IdentSiloResponseType();
        identSiloType.setIdSilo("P2000471");
        identSiloType.setCodeAppli("A0499");
        benefType.setIdentSilo(identSiloType);
        benefType.setInfoPP(null);
        SignqResponseType signq = new SignqResponseType();
        signq.setDateDeces("1998-12-13");
        benefType.setSignq(signq);
        InfoFamResponseType infoFamResponseType = new InfoFamResponseType();
        infoFamResponseType.setIndMariagePrec(false);
        DetailPPResponseType detailPPResponseType = new DetailPPResponseType();
        detailPPResponseType.setInfoFam(infoFamResponseType);
        benefType.setDetailPP(detailPPResponseType);
        InfoLienPersResponseType infoLienPersResponseType = new InfoLienPersResponseType();
        infoLienPersResponseType.setCodeTypeLienPers("AUCUN");
        infoLienPersResponseType.setLibTypeLienPers("Pas de lien de parenté");
        benefType.setInfoLienPers(infoLienPersResponseType);
        benefType.setIndBenefIrrev(true);
        benefType.setTauxPartBenef(BigDecimal.valueOf(0.878));

        BenefScdRangResponseType benefScdRangResponseType = new BenefScdRangResponseType();
        benefScdRangResponseType.setIdentSilo(identSiloType);
        benefScdRangResponseType.setNomUsage("JEANNINE DURAND");
        benefScdRangResponseType.setTypeBenefScdRang("NRM");
        benefScdRangResponseType.setLibBenef("NORMAL");
        benefScdRangResponseType.setDevise("EUR");
        benefScdRangResponseType.setDateDebutBenefScdRang(DateMapper.map(Date.valueOf("2009-04-18")));
        benefScdRangResponseType.setTauxPartBenefScdRang(BigDecimal.valueOf(1.0));
        benefScdRangResponseType.setCodeModePaimtBenefScdRang("CHEQ");
        benefScdRangResponseType.setLibModePaimtBenefScdRang("Chèque");
        benefScdRangResponseType.setMntPartBenefScdRang(new BigDecimal("1.0"));

        CodeBICIBANResponseType codeBICIBANResponseType = new CodeBICIBANResponseType();
        codeBICIBANResponseType.setCodeBIC("CODE_BIC");
        codeBICIBANResponseType.setCodeIBAN("CODE_IBAN");
        benefScdRangResponseType.setCodeBICIBAN(codeBICIBANResponseType);
        benefType.getBenefScdRang().add(benefScdRangResponseType);
        optRenteType.getBenef().add(benefType);


        PalierRenteType palierRente = new PalierRenteType();
        palierRente.setDateFinPalier(DateMapper.map(Date.valueOf("2009-04-18")));
        palierRente.setIdPalier("idPalier");
        palierRente.setTauxPalier(new BigDecimal("1.0"));
        optRenteType.getPalierRente().add(palierRente);

        optionRenteTypes.add(optRenteType);
        ConsulterOptRenteCtrFuncType funcType = new ConsulterOptRenteCtrFuncType();
        funcType.getOptRente().addAll(optionRenteTypes);
        responseType.setConsulterOptRenteCtrFunc(funcType);
        reponseJsonRootType.setConsulterOptRenteCtrResponse(responseType);
        return reponseJsonRootType;
    }
}
