package fr.ag2rlamondiale.erb.contrat.dto.contratdetail;

import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.Data;

import java.util.List;

@Data
public class InfoContratsDetailDTO {
    private ContratDetailDTO contrat;
    private List<ContratParcoursDto> autresContrats;
}
