package fr.ag2rlamondiale.erb.contrat.business;


import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.business.IBaseCalculerEncoursContratFacade;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;

import java.util.List;

public interface ICalculerEncoursContratFacade extends IBaseCalculerEncoursContratFacade {

    /**
     * Récupère l'encours <b>quelque soit le type</b> de contrat
     *
     * @param contratRente
     * @return
     */
    EncoursDto getEncoursDto(ContratRente contratRente);

    EncoursDto getEncoursDto(Compartiment compartiment);

    CompteEncours getCompteEncoursNonPacte(ContratRente contratRente);

    CompteEncours getCompteEncoursCompartiment(Compartiment compartiment);

    Encours getEncoursCompartimentEreNonPacte(Compartiment compartiment);

    EncoursDto getEncoursDtoPacte(ContratRente contratRente);

    EncoursDto getEncoursDto(ContratRente contratRente, List<CompartimentType> compartimentTypes);


}
