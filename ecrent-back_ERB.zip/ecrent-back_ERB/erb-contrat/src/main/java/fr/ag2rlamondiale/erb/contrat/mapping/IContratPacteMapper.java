package fr.ag2rlamondiale.erb.contrat.mapping;

import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;

import java.util.List;

public interface IContratPacteMapper {

    List<ContratRente> convertToPacte(List<ContratHeaderDto> contratHeaderDto, InfosContratDto infosContratDto);

    ContratRente mapBasic(ContratHeaderDto dto);
}
