package fr.ag2rlamondiale.erb.contrat.domain;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import lombok.*;

import java.util.Date;
import java.util.Objects;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Compartiment  implements ICompartiment<ContratRente> {
    @ToString.Exclude
    private ContratRente contratRente;

    private String identifiantAssure;
    private String college;
    private CompartimentType type;

    /**
     * Ne concerne que les compartiment ERE, utilisé pour l'arbitrage (support unite de compte)
     */
    private ContributionType contributionType;

    private Date dateAffiliation;
    private String libelleEtat;
    private Date dateEffetSituationAffiliation;

    private SituationContratEnum etatContrat;

    private SituationAffiliationEnum etatCompartiment;
    private String libelleEtatAssure;
    private AffichageType affichageType;
    private boolean deductible;
    private DisponibiliteType disponibilite;

    private String idCollege;

    public Compartiment(String identifiantAssure) {
        this.identifiantAssure = identifiantAssure;
    }

    public boolean is(CompartimentType compartimentType) {
        return type != null && type.equals(compartimentType);
    }

    public boolean is(CompartimentId compartimentId) {
        return Objects.equals(this.getCompartimentId(), compartimentId);
    }

    @Override
    public ContratRente getContrat() {
        return this.contratRente;
    }

    public CompartimentId getCompartimentId() {
        if (contratRente.isEre()) {
            return CompartimentId.ere(this.identifiantAssure, this.type);
        } else if (contratRente.isMdpro()) {
            return CompartimentId.mdpro(contratRente.getId(), this.type);
        }
        throw new IllegalStateException("Silo inconnu");
    }

    @Override
    public CodeSiloType getCodeSilo() {
        return ICompartiment.super.getCodeSilo();
    }

    public boolean isPacte() {
        return contratRente.isPacte();
    }

    public boolean isERE() {
        return contratRente.isEre();
    }

    public boolean isMdpro() {
        return contratRente.isMdpro();
    }



}
