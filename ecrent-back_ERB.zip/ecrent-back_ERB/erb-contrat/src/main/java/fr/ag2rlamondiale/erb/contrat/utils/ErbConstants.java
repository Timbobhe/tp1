package fr.ag2rlamondiale.erb.contrat.utils;

public class ErbConstants {
	
	public static final String RENTE_JEU_MAC_DO = "EV001401553000";

	private ErbConstants() {
		throw new IllegalStateException("ErbConstants class");
	}

}
