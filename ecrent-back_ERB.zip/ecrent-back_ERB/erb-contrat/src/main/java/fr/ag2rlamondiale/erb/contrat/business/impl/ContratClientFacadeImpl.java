package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratPacteMapperERE;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratPacteMapperMDP;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.utils.Lambda;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.RUNTIME_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.XCALLER_SIMPLE_KEY_GENERATOR;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;

@Slf4j
@Service
public class ContratClientFacadeImpl {
    private static final String CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP = "CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP";

    @Autowired
    private IContratsClient contratClient;
    @Autowired
    private ContratPacteMapperERE contratPacteMapperERE;

    @Autowired
    private ContratPacteMapperMDP contratPacteMapperMDP;


    @LogExecutionTime
    @Cacheable(cacheNames = CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = XCALLER_SIMPLE_KEY_GENERATOR)
    public List<ContratRente> rechercherContratsPersonne(RechercherContratsDto critere) throws TechnicalException {
        final List<ContratHeaderDto> contratsDto = contratClient.rechercherContratsRetraiteSupp(critere);
        prefetchInfosContrat(contratsDto);
        return convertToPacte(contratsDto);
    }

    private void prefetchInfosContrat(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final var contratId = entry.getKey();
            final List<ContratHeaderDto> contratHeaderDtos = entry.getValue();
            prefetchInfosContrat(contratId, contratHeaderDtos);
        }
    }

    private void prefetchInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        this.contratClient.consulterContratGeneralesAsync(new ConsulterContratGeneralesDto(contratId));
        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() ->
                    this.contratClient
                            .consulterCompteGeneralesEREAsync(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()))
                ));
            }
        }
    }

    private List<ContratRente> convertToPacte(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        final List<ContratRente> liste = new ArrayList<>();

        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final var contratId = entry.getKey();
            final List<ContratHeaderDto> contrats = entry.getValue();

            final var infosContratDto = retrieveInfosContrat(contratId, contrats);
            if (contratId.is(MDP)) {
                liste.addAll(contratPacteMapperMDP.convertToPacte(distinctMDP(contrats), infosContratDto));
            } else if (contratId.is(ERE)) {
                List<ContratRente> collect = contratPacteMapperERE.convertToPacte(contrats, infosContratDto).stream()
                        .filter(contratHeader1 -> !AffichageType.MASQUE.equals(contratHeader1.getAffichageType()))
                        .collect(Collectors.toList());
                liste.addAll(collect);
            }
        }
        return liste;
    }

    private InfosContratDto retrieveInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        var infosContratDto = new InfosContratDto();
        final var contratGeneral = this.contratClient
                .consulterContratGenerales(new ConsulterContratGeneralesDto(contratId));
        infosContratDto.setContratGeneral(contratGeneral);

        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() -> {
                    final var cge = this.contratClient
                            .consulterCompteGeneralesERE(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()));
                    infosContratDto.add(cge);
                }));
            }
        }

        return infosContratDto;
    }

    private List<ContratHeaderDto> distinctMDP(List<ContratHeaderDto> contrats) {
        if (contrats.size() == 1) {
            return contrats;
        }

        final List<ContratHeaderDto> res = contrats.stream().distinct().collect(Collectors.toList());
        if (contrats.size() > res.size()) {
            log.warn("BACK 8X retourne des contrats MDP en doublon {}", contrats);
        }
        return res;
    }

}
