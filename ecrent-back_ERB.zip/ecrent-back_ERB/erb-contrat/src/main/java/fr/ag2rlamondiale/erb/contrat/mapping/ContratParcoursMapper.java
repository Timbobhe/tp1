package fr.ag2rlamondiale.erb.contrat.mapping;

import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;
import java.util.List;

@Mapper(componentModel = "spring")
public abstract class ContratParcoursMapper {

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mapping(source = "id", target = "nomContrat")
    @Mapping(source = "descriptionFront", target = "description")
    @Mapping(source = "raisonSocialeFront", target = "raisonSociale")
    @Mapping(source = ".", target = "estCompartiment", qualifiedByName = "setContrat")
    public abstract ContratParcoursDto map(ContratRente contratRente);

    @Mapping(source = "contratHeader.id", target = "nomContrat")
    @Mapping(source = "contratHeader.descriptionFront", target = "description")
    @Mapping(source = "contratHeader.raisonSocialeFront", target = "raisonSociale")
    @Mapping(source = "contratHeader", target = "estCompartiment", qualifiedByName = "setContrat")
    public abstract ContratParcoursDto map(ContratComplet contratComplet);

    public ContratParcoursDto map(ContratRente contratRente, boolean avecEncours) {
        final ContratParcoursDto contratParcours = map(contratRente);
        if (avecEncours) {
            contratParcours.setAvecEncours(true);
            contratParcours.setEncours(calculerEncoursContrat(contratRente));
        }

        return contratParcours;
    }

    public ContratParcoursDto map(ContratRente contratRente, boolean avecEncours, List<CompartimentType> compartimentTypes) {
        final ContratParcoursDto contratParcours = map(contratRente);
        contratParcours.setDisponibilite(contratRente.compartiments(compartimentTypes).stream()
                .map(Compartiment::getDisponibilite)
                .findFirst()
                .orElse(DisponibiliteType.NON_CLASSES));
        // TODO gere le cas ou pas de disponibile trouve diffement, en theorie pas possible
        if (avecEncours) {
            contratParcours.setAvecEncours(true);
            contratParcours.setEncours(calculerEncoursContrat(contratRente, compartimentTypes));
            contratParcours.setEncoursGlobalContrat(calculerEncoursContrat(contratRente, Arrays.asList(CompartimentType.C1, CompartimentType.C4, CompartimentType.C3, CompartimentType.C2)));
        }

        return contratParcours;
    }

    @Mapping(source = "contratRente.id", target = "nomContrat")
    @Mapping(source = "contratRente.raisonSocialeFront", target = "raisonSociale")
    @Mapping(source = "contratRente.descriptionFront", target = "description")
    @Mapping(source = "contratRente.codeSilo", target = "codeSilo")
    @Mapping(source = "contratRente.idAdherente", target = "idAdherente")
    @Mapping(source = "contratRente.idContractante", target = "idContractante")
    @Mapping(source = ".", target = "estCompartiment", qualifiedByName = "setCompartiment")
    @Mapping(source = "type", target = "compartimentType")
    @Mapping(source = "pacte", target = "pacte")
    @Mapping(source = "deductible", target = "deductible")
    public abstract ContratParcoursDto map(Compartiment compartiment);

    public ContratParcoursDto map(Compartiment compartiment, boolean avecEncours) {
        final ContratParcoursDto contratParcours = map(compartiment);
        if (avecEncours) {
            contratParcours.setAvecEncours(true);
            contratParcours.setEncours(calculerEncoursCompartiment(compartiment));
        }
        return contratParcours;
    }

    @Named("setCompartiment")
    public boolean setCompartiment(Compartiment compartiment) {
        return true;
    }

    @Named("setContrat")
    public boolean setContrat(ContratRente contratRente) {
        return false;
    }

    private EncoursDto calculerEncoursCompartiment(Compartiment compartiment) {
        return calculerEncoursContratFacade.getEncoursDto(compartiment);
    }

    private EncoursDto calculerEncoursContrat(ContratRente contratRente) {
        return calculerEncoursContratFacade.getEncoursDto(contratRente);
    }

    private EncoursDto calculerEncoursContrat(ContratRente contratRente, List<CompartimentType> compartimentTypes) {
        return calculerEncoursContratFacade.getEncoursDto(contratRente, compartimentTypes);
    }
}