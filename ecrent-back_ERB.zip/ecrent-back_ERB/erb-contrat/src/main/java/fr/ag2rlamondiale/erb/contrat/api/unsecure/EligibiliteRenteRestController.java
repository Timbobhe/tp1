package fr.ag2rlamondiale.erb.contrat.api.unsecure;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEligibiliteFacade;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EligibiliteRenteRestController {

    @Autowired
    ICalculerEligibiliteFacade calculEligibiliteFacade;

    @PostMapping("/getEligibiliteRente")
    public InfoEligibiliteRente getEligibiliteRente(@RequestBody EligibiliteRenteRequest request) throws TechnicalException {
        try {
            return calculEligibiliteFacade.calculEligibiliteRente(request);
        } catch (TechnicalException e) {
            throw new TechnicalException(e.getCause().getMessage());
        }
    }
}
