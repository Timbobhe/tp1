package fr.ag2rlamondiale.erb.contrat.business;


import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;

public interface ICalculerEligibiliteFacade {

    InfoEligibiliteRente calculEligibiliteRente(EligibiliteRenteRequest request) throws TechnicalException;

}
