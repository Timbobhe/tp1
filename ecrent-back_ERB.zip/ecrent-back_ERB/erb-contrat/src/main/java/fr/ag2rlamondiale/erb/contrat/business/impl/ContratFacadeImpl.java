package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.business.IContratFacade;
import fr.ag2rlamondiale.erb.contrat.business.IFilterContrats;
import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.EnumTypeIdentifiantSilo;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static org.apache.commons.lang3.StringUtils.isEmpty;

@Service
@Slf4j
public class ContratFacadeImpl implements IContratFacade {

    @Autowired
    private IContratsClient contratClient;

    @Autowired
    private ICalculerEncoursContratFacade encoursFacade;

    @Autowired
    private RequestContextHolder requestContext;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private AsyncTaskExecutor asyncExecutor;

    @Autowired
    private ContratClientFacadeImpl contratClientFacade;


    @Override
    public List<ContratHeaderDto> rechercherContrats(String numPersonne) throws TechnicalException {
        var rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setPersonId(numPersonne);
        rechercherContratsDto.setCodeAppli(CodeApplicationType.PTV_RENTE_ERE);
        return contratClient.rechercherContratsPersonneV3(rechercherContratsDto);
    }

    @Override
    public List<ContratRente> rechercherContrats() throws TechnicalException {
        return rechercherContrats(new FilterByRequestContext(requestContext));
    }

    @Override
    public List<ContratRente> rechercherContratsMdpro(IFilterContrats filter) throws TechnicalException {
        if (isEmpty(userContextHolder.get().getNumeroPersonneMdpro())) {
            return new ArrayList<>();
        }
        var rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(MDP);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneMdpro());
        final List<ContratRente> contratHeaders = contratClientFacade.rechercherContratsPersonne(rechercherContratsDto);
        final List<ContratRente> sub = filterContratsPartenaire(contratHeaders);
        if (filter != null) {
            return filter.filter(sub);
        }
        return sub;
    }

    @Override
    public List<ContratRente> rechercherContratsEre(IFilterContrats filter) throws TechnicalException {
        if (isEmpty(userContextHolder.get().getNumeroPersonneEre())) {
            return new ArrayList<>();
        }
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(ERE);
        rechercherContratsDto.setPersonId(userContextHolder.get().getNumeroPersonneEre());
        final List<ContratRente> contratHeaders = contratClientFacade.rechercherContratsPersonne(rechercherContratsDto);
        final List<ContratRente> sub = filterContratsPartenaire(contratHeaders);
        if (filter != null) {
            return filter.filter(sub);
        }
        return sub;
    }

    @Override
    public ContratComplet recupererContratComplet(ContratRente contratRente) {
        final var complet = new ContratComplet();
        complet.setContratHeader(contratRente);
        final String idContrat = contratRente.getId();
        final CodeSiloType silo = contratRente.getCodeSilo();

        // Contrat General
        final var contratGenerale = getContratGenerale(idContrat, silo);
        complet.setContratGeneral(contratGenerale);

        // Compte ERE
        if (contratRente.isEre()) {
            for (Compartiment compartiment : contratRente.getCompartiments()) {
                if (compartiment.getIdentifiantAssure() != null) {
                    final CompteGeneralesERE compteGenerale = getCompteGenerale(compartiment.getIdentifiantAssure(), silo);
                    complet.setCompteGeneralesEre(compartiment.getCompartimentId(), compteGenerale);
                }
            }
            if (contratRente.getIdentifiantAssure() != null) {
                final CompteGeneralesERE compteGenerale = getCompteGenerale(contratRente.getIdentifiantAssure(), silo);
                complet.setCompteGeneralesERE(compteGenerale);
            }
        }

        // Encours
        complet.setEncours(new Memoizer<>(() -> encoursFacade.getCompteEncoursNonPacte(contratRente)));

        for (Compartiment compartiment : contratRente.getCompartiments()) {
            if (contratRente.isMdpro() || contratRente.isEre() && contratRente.isPacte()) {
                complet.setEncours(compartiment.getCompartimentId(), new Memoizer<>(() -> encoursFacade.getCompteEncoursCompartiment(compartiment)));
            } else if (contratRente.isEre() && !contratRente.isPacte()) {
                complet.setEncours(compartiment.getCompartimentId(), new Memoizer<>(() -> encoursFacade.getEncoursCompartimentEreNonPacte(compartiment)));
            }
        }

        return complet;
    }

    private List<ContratRente> filterContratsPartenaire(List<ContratRente> contratsHeader) {
        var partenaire = userContextHolder.get().getPartenaire();
        if (partenaire != null && partenaire.getRefExterne() != null) {
            String refExterne = partenaire.getRefExterne();
            return contratsHeader.stream()
                    .filter(contrat -> refExterne.equalsIgnoreCase(contrat.getIdContratReference()))
                    .collect(Collectors.toList());
        }
        return contratsHeader;
    }


    @Override
    public List<ContratRente> rechercherContrats(IFilterContrats filter) throws TechnicalException {
        final List<ContratRente> ere = this.rechercherContratsEre(filter);
        final List<ContratRente> mdp =  this.rechercherContratsMdpro(filter);

        List<ContratRente> contrats = new ArrayList<>();
        contrats.addAll(ere);
        contrats.addAll(mdp);

        return contrats;
    }

    @Override
    public ContratGeneral getContratGenerale(String idContrat, CodeSiloType silo) {
        try {
            var ccg= ConsulterContratGeneralesDto.builder()
                    .idContrat(idContrat)
                    .codeSilo(silo)
                    .typeIdentifiant(EnumTypeIdentifiantSilo.CONTRAT_RENTE)
                    .build();

            return contratClient.consulterContratGenerales(ccg);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public CompteGeneralesERE getCompteGenerale(String idAssure, CodeSiloType silo) {
        if (ERE.equals(silo)) {
            try {
                var ccgERE = new ConsulterCompteGeneralesEREDto(idAssure);
                return contratClient.consulterCompteGeneralesERE(ccgERE);
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException(e);
            }
        }
        return null;
    }

    @Override
    public List<ContratRente> rechercherContratsEre() throws TechnicalException {
        return rechercherContratsEre(new FilterByRequestContext(requestContext));
    }

    @Override
    public List<ContratRente> rechercherContratsMdpro() throws TechnicalException {
        return rechercherContratsMdpro(new FilterByRequestContext(requestContext));
    }
}
