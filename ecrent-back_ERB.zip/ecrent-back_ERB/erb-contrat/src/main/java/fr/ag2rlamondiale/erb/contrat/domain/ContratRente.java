package fr.ag2rlamondiale.erb.contrat.domain;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.exception.CodeSiloTypeNonGereException;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.trm.utils.Sets;
import lombok.*;

import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;

@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class ContratRente implements IContrat, Comparable<ContratRente>{

    @EqualsAndHashCode.Include
    private CodeSiloType codeSilo;
    @EqualsAndHashCode.Include
    private String id;
    private String personId;
    private String typeContrat;
    private String numGenContrat;
    private String codeFiliale;
    private String identifiantAssure;
    private boolean classeAutreContrat;
    private String codeEtat;

    @EqualsAndHashCode.Include
    private String idAdherente;

    private String raisonSocialeAdherente;

    @EqualsAndHashCode.Include
    private String idContractante;

    private String raisonSocialeContractante;
    private String raisonSocialeFront;

    /**
     * Construit depuis :
     * <ul>
     *     <li>ERE : {@link ContratGeneral#getProduit()}</li>
     * </ul>
     */
    private String descriptionFront;

    private AffichageType affichageType;
    private boolean deductible;

    private boolean contractanteRepresent;
    private Date dateAffiliation;

    private String codeAssureur;
    private String codeProduit;
    private String libelleProduit;
    private String codeMentionLegale;
    private String etatContratLabel;
    private String etatAffiliationLabel;
    private Date dateEffet;
    private Date dateFinEffet;
    private String codeSitAffil;
    private String libSitAffil;
    private Date dateSitAffil;
    private String descClauseBenef;

    // Fiscalité
    private String codeCadreFiscal;
    private String libCadreFiscal;

    // ContratResume
    private SituationContratEnum etatContrat;
    private Date dateSitCtr;
    private Date dateEffetSituationAffiliation;

    private Set<PartType> partsType;

    private List<Compartiment> compartiments = new ArrayList<>();
    private boolean pacte;

    /**
     * contrats MDPRO 8X ont été migré sur PTV (Sur contrat général : TYPCONNUMGEN = RG02 002)
     */
    private boolean petitCollectifPTV;

    /**
     * Identifiant technique NIE
     */
    @Override
    public boolean is(CodeSiloType codeSilo) {
        return this.codeSilo.equals(codeSilo);
    }
    private String idContratReference;
    public Set<String> getIdentifiantsAssures() {
        if (is(MDP)) {
            return Collections.emptySet();
        }

        if (isPacte()) {

            return this.getCompartiments().stream().map(Compartiment::getIdentifiantAssure)
                    .filter(Objects::nonNull).collect(Collectors.toSet());
        }

        return Sets.set(this.identifiantAssure);
    }

    @Override
    public ContratId getContratId() {
        if (this.isEre()) {
            return ContratId.ere(this.id, this.idAdherente, this.idContractante,null);
        } else if (isMdpro()) {
            return ContratId.mdpro(this.id);
        }
        throw new CodeSiloTypeNonGereException(this.codeSilo);
    }

    @Override
    public MetierContratType getMetierContrat() {
        return MetierContratType.RETRAITE_SUPPLEMENTAIRE;
    }

    @Override
    public boolean isEre() {
        return this.is(ERE);
    }

    @Override
    public boolean isMdpro() {
        return this.is(MDP);
    }

    public Compartiment addCompartiment(Compartiment compartiment) {
        compartiment.setContratRente(this);
        this.getCompartiments().add(compartiment);
        return compartiment;
    }

    @Override
    public int compareTo(ContratRente o) {
        if (o == null) {
            return -1;
        }
        return id.compareTo(o.getId());
    }

    @Override
    public List<Compartiment> compartiments(CompartimentType type) {
        return this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).collect(Collectors.toList());
    }

    public List<Compartiment> compartiments(List<CompartimentType> types) {
        final List<Compartiment> compartimentList = new ArrayList<>();
        for(CompartimentType type : types){
            compartimentList.addAll(this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).collect(Collectors.toList()));
        }
        return compartimentList;
    }

    public Compartiment compartiment(CompartimentId compartimentId) {
        return this.getCompartiments().stream().filter(compartiment -> compartiment.is(compartimentId)).findFirst().orElse(null);
    }

    public Compartiment compartimentEre(String idAssure) {
        return this.getCompartiments().stream().filter(compartiment -> idAssure.equals(compartiment.getIdentifiantAssure())).findFirst().orElse(null);
    }

    public void compartiment(CompartimentType type, Consumer<Compartiment> consumer) {
        this.getCompartiments().stream().filter(compartiment -> compartiment.is(type)).forEach(consumer);
    }

    public List<Compartiment> getCompartiments() {
        if (compartiments == null) {
            compartiments = new ArrayList<>();
        }
        return compartiments;
    }

}
