package fr.ag2rlamondiale.erb.contrat.dto.contratdetail;


import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.Data;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.Date;

@Data
@SuperBuilder
public class ContratDetailDTO extends ContratParcoursDto {
    // nom entreprise ( Contrat Rente )
    private String raisonSocialeAdherente;
    private String raisonSocialeContractante;

    // etat du compte ( Contrat Rente )
    private String statut;

    // date affiliation  ( Contrat Rente )
    private Date dateAffiliation;

    // date d'effet ( Contrat Rente )
    private Date dateEffet;

    // date de terme  ( date de fin d'effet sur Contrat Rente )
    private Date dateTerme;

    private BigDecimal montantRenteAnnuelleBrute;

    private BigDecimal montantDernierPaiement;

    private Date dateDernierPaiement;

    private Date dateProchainPaiement;

    private Periodicite periodiciteRente;

    private String typePaiement;

    // Numero de personne ( Contrat General )
    private String personId;
    private boolean isVersementAccessible;
    private boolean isArbitrageAccessible;

    private String libelleGaranties;
}
