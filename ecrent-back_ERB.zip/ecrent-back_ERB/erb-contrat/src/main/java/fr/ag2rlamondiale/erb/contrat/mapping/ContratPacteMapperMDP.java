package fr.ag2rlamondiale.erb.contrat.mapping;

import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.utils.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratCloture;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_RETRAITE;
import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_SOUS_CONDITIONS;

@Mapper(componentModel = "spring")
public abstract class ContratPacteMapperMDP implements IContratPacteMapper {

    @Autowired
    private ContratMDPROHelper contratMDPROHelper;

    @Override
    public List<ContratRente> convertToPacte(List<ContratHeaderDto> contrats, InfosContratDto infosContratDto) {
        if (contrats.size() != 1) {
            throw new IllegalArgumentException("contrats MDPRO");
        }

        final ContratRente contrat = mapBasic(contrats.get(0));

        contrat.setDateAffiliation(contrat.getDateSitCtr());
        final boolean pacte = contratMDPROHelper.isContratPacte(contrat);
        contrat.setPacte(pacte);
        final AffichageType affichageType = SituationContratCloture.contratAffichageType(CodeSiloType.MDP,
                contrat.getEtatContrat().getCodeSilo(), contrat.getDateSitCtr(), contrat.getDateFinEffet(), contratMDPROHelper.isContainOldNumGenContratMadelin(contrat));
        contrat.setAffichageType(affichageType);
        if (AffichageType.MASQUE.equals(affichageType)) {
            return new ArrayList<>();
        }

        contrat.setCodeAssureur(infosContratDto.getContratGeneral().getCodeAssureur());
        contrat.setDescriptionFront(contrat.getLibelleProduit());
        contrat.setCodeCadreFiscal(infosContratDto.getContratGeneral().getCodeCadreFiscal());
        contrat.setLibCadreFiscal(infosContratDto.getContratGeneral().getLibCadreFiscal());
        contrat.setRaisonSocialeFront(infosContratDto.getContratGeneral().getContractante());
        if (pacte) {
            return Collections.singletonList(contratPacte(contrat));
        }
        return Collections.singletonList(contratNonPacte(contrat));
    }

    /**
     * <h3>Règles pour les contrats MDPRO considérés non PACTE</h3>
     *
     * <h4>Disponibilité</h4>
     * <ul>
     *     <li>Tous les contrats sont disponibles à la Retraite</li>
     * </ul>
     *
     * <h4>Compartiments</h4>
     * La règle de construction des Compartiments s'appuie sur le <u>type de Contrat</u>  et le <u>Numéro génération du Contrat</u>; voir: {@link ContratMDPROHelper}
     *
     * <ul>
     *      <li>Type de contrat = RA09, RA10 et numGen != "pacte" => C1</li>
     *      <li>Tous les autres contrats sont classés dans "Autre Contrat"</li>
     * </ul>
     *
     * @param contratRente
     * @return
     */
    private ContratRente contratNonPacte(ContratRente contratRente) {
        final Compartiment model = modelCompartiment(contratRente);

        if (contratMDPROHelper.isContratAutoriseNonPacte(contratRente)) {
            final Compartiment c1 = model.toBuilder().type(CompartimentType.C1).build();
            c1.setDeductible(contratMDPROHelper.isContratDeductible(contratRente));
            contratRente.addCompartiment(c1);
        } else {
            contratRente.setClasseAutreContrat(true);
        }
        return contratRente;
    }

    private Compartiment modelCompartiment(ContratRente contratRente) {
        final Compartiment model = new Compartiment();
        model.setAffichageType(contratRente.getAffichageType());
        model.setDateAffiliation(contratRente.getDateSitCtr());
        model.setEtatContrat(contratRente.getEtatContrat());
        model.setDeductible(false);
        model.setDisponibilite(DISPO_RETRAITE);
        return model;
    }

    /**
     * <h3>Règles pour les contrats MDPRO considérés PACTE</h3>
     *
     * <h4>Disponibilité</h4>
     * <ul>
     *     <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) sont disponibles sous Conditions (C1)</li>
     *     <li>Contrats numGen=A07, A08 sont disponibles sous conditions (C4)</li>
     *     <li>Contrats numGen=C01, C02 sont disponibles à la Retraite (C3)</li>
     *     <li>Tous les autres contrats sont disponibles à la Retraite</li>
     * </ul>
     *
     * <h4>Déductibilité</h4>
     * <ul>
     *     <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) sont déductibles (C1)</li>
     *     <li>Contrats numGen=A07, A08 ne sont pas déductibles (C4)</li>
     *     <li>Contrats numGen=C01, C02 ne sont pas déductibles (C3)</li>
     *     <li>Tous les autres contrats ne sont pas déductibles</li>
     * </ul>
     *
     * <h4>Compartiments</h4>
     * La règle de construction des Compartiments s'appuie sur le <u>type de Contrat</u>  et le <u>Numéro génération du Contrat</u>; voir: {@link ContratMDPROHelper}
     *
     * <ul>
     *      <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) => C1</li>
     *      <li>Contrats numGen=A07, A08 ne sont pas déductibles => C4</li>
     *      <li>Contrats numGen=C01, C02 ne sont pas déductibles => C3</li>
     *      <li>Tous les autres contrats sont classés dans "Autre Contrat"</li>
     * </ul>
     *
     * @param contratRente
     * @return
     */
    private ContratRente contratPacte(ContratRente contratRente) {
        final Compartiment model = modelCompartiment(contratRente);

        if (contratMDPROHelper.isC3Pacte(contratRente)) {
            final Compartiment c3 = model.toBuilder().type(CompartimentType.C3)
                    .disponibilite(DISPO_RETRAITE)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .build();
            contratRente.addCompartiment(c3);
            contratRente.setAffichageType(AffichageType.LECTURE_SEULE);
        } else if (contratMDPROHelper.isC2Pacte(contratRente)) {
            final Compartiment c2 = model.toBuilder().type(CompartimentType.C2)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .disponibilite(DISPO_SOUS_CONDITIONS)
                    .build();
            contratRente.addCompartiment(c2);
            contratRente.setAffichageType(AffichageType.LECTURE_SEULE);
        } else if (contratMDPROHelper.isContratAutorise(contratRente)) {
            setCompartimentPourDeductibilite(contratRente, model);
        } else {
            contratRente.setDeductible(false);
            contratRente.setClasseAutreContrat(true);
        }
        return contratRente;
    }


    private void setCompartimentPourDeductibilite(ContratRente contratRente, Compartiment model) {
        if (contratMDPROHelper.isContratDeductible(contratRente)) {
            final Compartiment c1 = model.toBuilder().type(CompartimentType.C1).deductible(true).disponibilite(DISPO_SOUS_CONDITIONS).build();
            contratRente.addCompartiment(c1);
        } else {
            final Compartiment c4 = model.toBuilder().type(CompartimentType.C4).deductible(false)
                    .disponibilite(DISPO_SOUS_CONDITIONS)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .build();
            contratRente.addCompartiment(c4);
            contratRente.setAffichageType(AffichageType.LECTURE_SEULE);
        }
    }

}
