package fr.ag2rlamondiale.erb.contrat.business;

import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;

import java.util.List;

public abstract interface IFilterContrats {

    List<ContratRente> filter(List<ContratRente> contratsHeader);

}
