package fr.ag2rlamondiale.erb.contrat.business.impl;

import fr.ag2rlamondiale.erb.contrat.business.IFilterContrats;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;

import java.util.List;
import java.util.stream.Collectors;

public class FilterByRequestContext implements IFilterContrats {

    private final RequestContextHolder requestContext;

    public FilterByRequestContext(RequestContextHolder requestContext) {
        this.requestContext = requestContext;
    }

    @Override
    public List<ContratRente> filter(List<ContratRente> contrats) {
        return filterByRequestContext(contrats);
    }

    private List<ContratRente> filterByRequestContext(List<ContratRente> contratsRentes) {
        if (requestContext.getContrat() != null) {
            List<ContratRente> filtered = filterContrat(contratsRentes, requestContext.getContrat());
            if (!filtered.isEmpty()) {
                return filtered;
            }
        }
        return contratsRentes;
    }

    private static List<ContratRente> filterContrat(List<ContratRente> contratsRentes, String contratId) {
        return contratsRentes.stream()
                .filter(ctr -> contratId.equals(ctr.getId()))
                .collect(Collectors.toList());
    }

}
