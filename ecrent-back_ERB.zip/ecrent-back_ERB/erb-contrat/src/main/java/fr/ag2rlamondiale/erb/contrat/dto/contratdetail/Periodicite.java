package fr.ag2rlamondiale.erb.contrat.dto.contratdetail;

import lombok.Getter;

import java.util.Arrays;

@Getter
public enum Periodicite {
    MENSUEL("M"),
    TRIMESTRIEL("T"),
    SEMESTRIEL("S"),
    ANNUEL("A");

    Periodicite(String code) {
        this.code = code;
    }

    private final String code;

    public static Periodicite fromCode(String code) {
        return Arrays.stream(Periodicite.values()).filter(periodicite -> periodicite.code.equals(code)).findAny().orElse(null);
    }


}
