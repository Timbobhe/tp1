package fr.ag2rlamondiale.erb.contrat.domain;

import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;

public class ContratComplet extends BaseContratComplet<ContratRente> {

    public ContratComplet() {
        super();
    }

    public ContratComplet(ContratRente contratRente) {
        super();
        this.setContratHeader(contratRente);
    }
}
