package fr.ag2rlamondiale.erb.contrat.dto;

import fr.ag2rlamondiale.trm.domain.operation.Operation;
import lombok.Data;

@Data
public class OperationToRecalculate {
    private boolean hasOperation;
    private Operation operation;
}
