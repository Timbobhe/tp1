package fr.ag2rlamondiale.erb.contrat.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@AllArgsConstructor
public class EligibiliteRenteRequest {
	// les champs nom, prenom et dateNaissance ?? 
    private String nom;
    private String prenom;
    private Date dateNaissance;
    
    private String idPersonne;
    private String idContrat;
}
