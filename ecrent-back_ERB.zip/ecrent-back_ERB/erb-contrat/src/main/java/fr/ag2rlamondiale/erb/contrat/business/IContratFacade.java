package fr.ag2rlamondiale.erb.contrat.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;

import java.util.List;

/**
 * FIXME : Il faut récupérer les contrats EVxxxxx en plus des RGxxxx
 * <p>
 * RGxxx => Contrat de Retraite Supplémentaire qui se transformera en EVxxxx
 * EVxxx => Contrat de Rente
 */
public interface IContratFacade {

    List<ContratHeaderDto> rechercherContrats(String numPersonne) throws TechnicalException;

    List<ContratRente> rechercherContrats() throws TechnicalException;

    List<ContratRente> rechercherContrats(IFilterContrats filter) throws TechnicalException;

    List<ContratRente> rechercherContratsMdpro(IFilterContrats filter) throws TechnicalException;

    List<ContratRente> rechercherContratsEre(IFilterContrats filter) throws TechnicalException;

    ContratComplet recupererContratComplet(ContratRente contratRente);

    ContratGeneral getContratGenerale(String idContrat, CodeSiloType silo);

    CompteGeneralesERE getCompteGenerale(String idAssure, CodeSiloType silo);

    List<ContratRente> rechercherContratsEre() throws TechnicalException;

    List<ContratRente> rechercherContratsMdpro() throws TechnicalException;
}
