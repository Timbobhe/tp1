package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEligibiliteFacade;
import fr.ag2rlamondiale.erb.contrat.business.IContratFacade;
import fr.ag2rlamondiale.erb.pfs.client.rest.IConsulterOptionRenteContratClient;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteType;
import fr.ag2rlamondiale.erb.contrat.dto.DetailEligibiliteRenteContrat;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;
import fr.ag2rlamondiale.erb.contrat.utils.ErbConstants;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
public class CalculerEligibiliteFacadeImpl implements ICalculerEligibiliteFacade {
	@Autowired
	private IContratFacade contratFacade;

	@Autowired
	private IConsulterOptionRenteContratClient consulterOptionRenteContratClient;

	@Autowired
	private IConsulterPersPhysFacade consulterPersPhysFacade;

	@Autowired
	private UserContextHolder userContextHolder;

	@Value("ere.consoleadmin.ws.soap.idgdi")
	private String idgdi;

	@Override
	public InfoEligibiliteRente calculEligibiliteRente(EligibiliteRenteRequest in) throws TechnicalException {
		createUserContext(in);
		InfoEligibiliteRente infosRente = null;
		List<ContratHeaderDto> contrats;
		PersonnePhysiqueConsult personnePhysiqueConsult;
        // FIXME : Utiliser fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest.idPersonne au lieu du userContextHolder
		personnePhysiqueConsult = consulterPersPhysFacade.consulterPersPhys(userContextHolder.get().getIdSilo());
		if(!exist(in, personnePhysiqueConsult)){
			return InfoEligibiliteRente.builder()
					.accesAutorise(Boolean.toString(false))
					.idPersonne(in.getIdPersonne())
					.infoComplementaire("Informations de la personne " + in.getIdPersonne() + " incorrectes")
					.build();
		}

		// etape 1 : appel du service rechercherStrPerSilo par idPersonne
		contrats = contratFacade.rechercherContrats(in.getIdPersonne());

		if (!StringUtils.isBlank(in.getIdContrat())) {
			contrats = contrats.stream().filter(c -> in.getIdContrat().equals(c.getId())).collect(Collectors.toList());
		}

		if (contrats.isEmpty()) {
			return InfoEligibiliteRente.builder()
					.accesAutorise("FALSE")
					.idPersonne(in.getIdPersonne())
					.infoComplementaire("Contrat non trouvé")
					.build();
		}

		// etape 2 : traiter les exclusions
		contrats = contrats.stream().filter(isContratRenteJeuMacDo().negate())
				.filter(isTypConNumGentoExclude().negate())
				.filter(isContratFilialeMEP().negate())
				.filter(isLibParticulariteRentetoExclude().negate())
				.filter(isContratEnCours()).collect(Collectors.toList());


		if (contrats.isEmpty()) {
			return InfoEligibiliteRente.builder()
					.accesAutorise("FALSE")
					.idPersonne(in.getIdPersonne())
					.infoComplementaire("Contrat non éligible")
					.build();
		}

		List<DetailEligibiliteRenteContrat> listDetails = new ArrayList<>();
		for (ContratHeaderDto contratHeaderDto : contrats) {
			if (verifierEligibiliteContrat(contratHeaderDto.getId())) {
				listDetails.add(DetailEligibiliteRenteContrat.builder().idContrat(contratHeaderDto.getId()).build());
			}
		}
		if (CollectionUtils.isNotEmpty(listDetails)) {
			infosRente = InfoEligibiliteRente.builder().accesAutorise("TRUE").idPersonne(in.getIdPersonne()).build();
			infosRente.setContrats(listDetails);
		}
		return infosRente;
	}

	private boolean exist(EligibiliteRenteRequest in, PersonnePhysiqueConsult persPhy) {
		boolean objExist = in != null && persPhy != null;
		boolean nomExist = objExist && in.getNom() != null && persPhy.getNom() != null && in.getNom().equalsIgnoreCase(persPhy.getNom());
		boolean prenomExist = objExist && in.getPrenom() != null && persPhy.getPrenom() != null && in.getPrenom().equalsIgnoreCase(persPhy.getPrenom());
		boolean dateNaissExist = objExist && in.getDateNaissance() != null && persPhy.getDateDeNaissance() != null
				&& in.getDateNaissance().toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
				.isEqual(persPhy.getDateDeNaissance().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
		return  nomExist && prenomExist && dateNaissExist;
	}

	private boolean verifierEligibiliteContrat(String idContrat) {
		List<OptionRenteType> garantiesExclues = Arrays.asList(OptionRenteType.INVAL, OptionRenteType.REVDIF,
				OptionRenteType.REVIAGDIF);

        // FIXME : Appeler avec le EVxxx et pas RGxxx
		ConsulterOptionRenteIn optionRenteIn = ConsulterOptionRenteIn.builder().idContrat(idContrat).build();
		ConsulterOptionRenteContratDto optionsRenteContrat = consulterOptionRenteContratClient
				.consulterOptionRenteContrat(optionRenteIn);
		for (OptionRenteDto optionRente : optionsRenteContrat.getOptionRentes()) {

			if (garantiesExclues.contains(optionRente.getOptRenteType()) && validDateGarantie(optionRente)) {
				return false;
			}

			if (Arrays.asList(OptionRenteType.values()).contains(optionRente.getOptRenteType())
					&& validDateGarantie(optionRente)) {
				return true;
			}
		}

		return false;
	}

	private boolean validDateGarantie(OptionRenteDto optionRente) {
		return optionRente.getDateDebutEffet() != null && (optionRente.getDateDebutEffet().before(new Date()) && optionRente.getDateFinEffet() == null
				|| optionRente.getDateDebutEffet().before(new Date())
						&& optionRente.getDateFinEffet().after(new Date()));
	}


	private Predicate<ContratHeaderDto> isTypConNumGentoExclude() {
		return c -> "CD01".equals(c.getTypeContrat())
				|| "RK04".equals(c.getTypeContrat()) && "004".equals(c.getNumGenContrat())
				|| "RK05".equals(c.getTypeContrat()) && "001".equals(c.getNumGenContrat());
	}

	private Predicate<ContratHeaderDto> isLibParticulariteRentetoExclude() {
		return c -> "Gestion déléguée sans prélèvement".equalsIgnoreCase(c.getLibParticulariteRente())
				|| "Gestion déléguée paiements à regrouper".equalsIgnoreCase(c.getLibParticulariteRente());

	}

	private Predicate<ContratHeaderDto> isContratEnCours() {
		return c -> SituationContratEnum.EN_COURS.equals(c.getEtatContrat());
	}

	private Predicate<ContratHeaderDto> isContratRenteJeuMacDo() {
		return c -> ErbConstants.RENTE_JEU_MAC_DO.equals(c.getId());
	}

	private Predicate<ContratHeaderDto> isContratFilialeMEP() {
		return c -> "MEP".equals(c.getCodeFiliale());
	}

	private void createUserContext(EligibiliteRenteRequest in) {
		var userContext = new UserContext();
		userContext.setIdGdi(idgdi);
		userContext.setForSupervision(true);
		userContext.setNumeroPersonneEre(in.getIdPersonne());
		userContext.setSilos(Sets.set(CodeSiloType.ERE));
		userContextHolder.set(userContext);
	}
}
