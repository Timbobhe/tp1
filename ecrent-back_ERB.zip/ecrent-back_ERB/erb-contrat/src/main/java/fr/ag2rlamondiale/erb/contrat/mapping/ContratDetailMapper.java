package fr.ag2rlamondiale.erb.contrat.mapping;


import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.dto.contratdetail.ContratDetailDTO;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.beans.factory.annotation.Autowired;
import fr.ag2rlamondiale.erb.pfs.utils.contrats.LibelleEtatContrat;

@Mapper(componentModel = "spring")
public abstract class ContratDetailMapper {

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Mapping(source = "id", target = "nomContrat")
    @Mapping(source = "descriptionFront", target = "description")
    @Mapping(source = "dateFinEffet", target = "dateTerme")
    @Mapping(source = "raisonSocialeFront", target = "raisonSociale")
    @Mapping(source = ".", target = "statut", qualifiedByName = "getStatutFromCodeEtat")
    public abstract ContratDetailDTO map(ContratRente contratRente);

    public ContratDetailDTO map(ContratRente contratRente, boolean avecEncours) {
        final ContratDetailDTO contratDetail = map(contratRente);
        if (avecEncours) {
            contratDetail.setAvecEncours(true);
            contratDetail.setEncours(calculerEncoursContrat(contratRente));
        }
        return contratDetail;
    }

    private EncoursDto calculerEncoursContrat(ContratRente contratRente) {
        return calculerEncoursContratFacade.getEncoursDto(contratRente);
    }

    @Named("getStatutFromCodeEtat")
    protected String getStatutFromCodeEtat(ContratRente contratRente) {
        String statut = null;
        if (contratRente.isEre()) {
            statut = LibelleEtatContrat.LibelleEtatContratEREEnum.getEtatFromCode(contratRente.getCodeEtat());
        } else if (contratRente.isMdpro()) {
            statut = LibelleEtatContrat.LibelleEtatContratMDPEnum.getEtatFromCode(contratRente.getCodeEtat());
        }
        return statut;
    }
}

