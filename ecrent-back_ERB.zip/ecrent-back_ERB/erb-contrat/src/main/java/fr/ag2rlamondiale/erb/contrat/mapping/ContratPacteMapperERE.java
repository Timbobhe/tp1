package fr.ag2rlamondiale.erb.contrat.mapping;

import fr.ag2rlamondiale.erb.contrat.domain.Compartiment;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.dto.Compart;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.domain.exception.UnknownEnumerationValueException;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.domain.structinv.PartType;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratCloture;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Named;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_RETRAITE;
import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_SOUS_CONDITIONS;
import static fr.ag2rlamondiale.trm.utils.Sets.set;

@Mapper(componentModel = "spring")
public abstract class ContratPacteMapperERE implements IContratPacteMapper {

    @Override
    public List<ContratRente> convertToPacte(List<ContratHeaderDto> contrats, InfosContratDto infosContratDto) {
        return convert(contrats, infosContratDto);
    }


    private List<ContratRente> convert(List<ContratHeaderDto> contratHeaderDto, InfosContratDto infosContratDto) {
        List<ContratRente> contratRentes = new ArrayList<>();
        final ContratGeneral contratGeneral = infosContratDto.getContratGeneral();
        final boolean pacte = contratGeneral.isPacte();

        if (pacte) {
            // Pour les PACTE le college est au niveau du compartiment => 1 ContratId = 1 Contrat ...
            contratRentes.add(contratPacte(contratHeaderDto, infosContratDto));
        } else {
            // ... alors que les non PACTE : le college est au niveau du contrat => 1 ContratId = 1,n Contrats
            contratRentes.addAll(contratNonPacte(contratHeaderDto, contratGeneral, infosContratDto));
        }

        contratRentes.forEach(contratRente -> {
            contratRente.setCodeAssureur(contratGeneral.getCodeAssureur());
            contratRente.setDescClauseBenef(contratGeneral.getDescClauseBenef());
            contratRente.setCodeCadreFiscal(contratGeneral.getCodeCadreFiscal());
            contratRente.setLibCadreFiscal(contratGeneral.getLibCadreFiscal());
            libellesFront(contratRente, contratGeneral);
            testPetitCollectifPTV(contratRente, infosContratDto);
        });

        return contratRentes;
    }

    private void libellesFront(ContratRente contratHeader, ContratGeneral contratGeneral) {
        // RaisonSocialeFront
        if (contratHeader.getRaisonSocialeAdherente() != null) {
            contratHeader.setRaisonSocialeFront(contratHeader.getRaisonSocialeAdherente());
        } else {
            contratHeader.setRaisonSocialeFront(contratGeneral.getContractante());
        }
        // DescriptionFront
        contratHeader.setDescriptionFront(contratGeneral.getProduit());
        // Statut
        contratHeader.setCodeEtat(contratGeneral.getCodeEtat());
    }


    private ContratRente contratPacte(List<ContratHeaderDto> contrats, InfosContratDto infosContratDto) {
        final ContratRente contrat = mapBasic(contrats.get(0)).toBuilder().identifiantAssure(null).pacte(true).build();
        for (ContratHeaderDto c : contrats) {
            for (Compart compart : c.getCompart()) {
                final CompteGeneralesERE cge = infosContratDto.get(compart.getIdAssure());
                final AffichageType affichageType = SituationContratCloture.contratAffichageType(CodeSiloType.ERE, compart.getCodeSitCompart(), compart.getDateSitCompart(), c.getDateFinEffet(), false);

            if (!AffichageType.MASQUE.equals(affichageType)) {
                final Compartiment compartiment = buildCompartiment(c, compart, cge, affichageType);
                contrat.setEtatAffiliationLabel(cge.getEtat());
                contrat.addCompartiment(compartiment);
            }
        }
    }

        if (contrat.getCompartiments().isEmpty()) {
            contrat.setAffichageType(AffichageType.MASQUE);
        } else {
            completePartsType(contrat, infosContratDto);

            final AffichageType affichageType = contrat.getCompartiments().stream()
                    .map(Compartiment::getAffichageType)
                    .min(AffichageType.ForceComparator.instance)
                    .orElse(AffichageType.NORMAL);
            contrat.setAffichageType(affichageType);

            // on positionne un idAssure dans les Contrats Pacte pour le Wokflow, à voir si c'est absolument nécessaire
            contrat.getCompartiments().stream()
                    .filter(compartiment -> AffichageType.NORMAL.equals(compartiment.getAffichageType()))
                    .map(Compartiment::getIdentifiantAssure)
                    .findFirst()
                    .ifPresent(contrat::setIdentifiantAssure);

            contrat.getCompartiments().stream()
                    .filter(compartiment -> AffichageType.NORMAL.equals(compartiment.getAffichageType()))
                    .map(Compartiment::getDateAffiliation)
                    .collect(Collectors.toList())
                    .stream().min((o1, o2) -> {
                int affiliationDateComparisonValue =
                        o1.compareTo(o2);
                return -affiliationDateComparisonValue;
            }).ifPresent(contrat::setDateAffiliation);

        }

        return contrat;
    }

    private void completePartsType(ContratRente contrat, InfosContratDto infosContrat) {
        Set<PartType> partsType = new HashSet<>();
        final ContratGeneral contratGeneral = infosContrat.getContratGeneral();
        final String tenueCompte = contratGeneral.getOptContratEpargne().getCodeTypeTenueCompte();
        switch (tenueCompte) {
            case "1":
            case "6":
                partsType.add(PartType.PP);
                break;

            case "2":
            case "7":
                partsType.add(PartType.PP);
                partsType.add(PartType.PS);
                break;

            case "3":
                partsType.add(PartType.PP);
                partsType.add(PartType.PS);
                partsType.add(PartType.VL);
                break;

            case "4":
                partsType.add(PartType.PP);
                partsType.add(PartType.VL);
                break;

            case "5":
                partsType.add(PartType.VL);
                break;

            default:
                break;
        }

        contrat.setPartsType(partsType);
    }

    private Compartiment buildCompartiment(ContratHeaderDto c, Compart compart,
                                           CompteGeneralesERE cge, AffichageType affichageType) {
        final Compartiment compartiment = this.map(compart);
        compartiment.setLibelleEtat(c.getEtatContratLabel());
        compartiment.setEtatContrat(c.getEtatContrat());
        if (!affichageType.isDisabled()) {
            this.updateCompartimentPacte(cge, compartiment);
        }
        compartiment.setDisponibilite(DISPO_SOUS_CONDITIONS);
        if (compartiment.is(CompartimentType.C3)) {
            compartiment.setDisponibilite(DISPO_RETRAITE);
        }
        compartiment.setAffichageType(affichageType);
        return compartiment;
    }


    private List<ContratRente> contratNonPacte(List<ContratHeaderDto> contratHeaderDto, ContratGeneral contratGeneral, InfosContratDto infosContrat) {
        List<ContratRente> contrats = new ArrayList<>();
        contratHeaderDto.forEach(dto -> {
            final ContratRente contrat = mapBasic(dto);
            contrat.setPacte(false);
            Compart compart = getCompartNullSafe(dto);
            final String college = getCollegeNullSafe(compart);
            final CompteGeneralesERE cge = infosContrat.get(dto.getIdentifiantAssure());
            this.updateContratHeader(cge, contrat);
            final AffichageType affichageType;
            if (compart != null) {
                affichageType = SituationContratCloture.contratAffichageType(CodeSiloType.ERE, compart.getCodeSitCompart(), compart.getDateSitCompart(), contrat.getDateFinEffet(), false);
            } else {
                throw new IllegalStateException("Impossible de recuperer le compartiment de ");
            }
            contrat.setAffichageType(affichageType);
            if (!AffichageType.MASQUE.equals(affichageType)) {

                final Compartiment model = new Compartiment(contrat.getIdentifiantAssure());
                model.setEtatCompartiment(etatCompartimentPacte(compart.getCodeSitCompart()));
                model.setCollege(college);
                model.setDateAffiliation(contrat.getDateEffet());
                model.setDateEffetSituationAffiliation(contrat.getDateEffetSituationAffiliation());
                model.setEtatContrat(contrat.getEtatContrat());
                model.setAffichageType(affichageType);
                model.setDeductible(false);
                if ("82DISPO".equals(contratGeneral.getCodeCadreFiscal())) {
                    model.setDisponibilite(DISPO_SOUS_CONDITIONS);
                } else {
                    model.setDisponibilite(DISPO_RETRAITE);
                }


                // Tout est déductible sauf Article82 non déductible
                final boolean deductible = !set("82DISPO", "82NODISP").contains(contratGeneral.getCodeCadreFiscal());
                final Compartiment c1x = model.toBuilder().type(deductible ? CompartimentType.C1 : CompartimentType.C4)
                        .contributionType(ContributionType.VERSEMENT_LIBRE)
                        .deductible(deductible)
                        .build();

                final Compartiment c3 = model.toBuilder().type(CompartimentType.C3).build();

                final String tenueCompte = contratGeneral.getOptContratEpargne().getCodeTypeTenueCompte();
                switch (tenueCompte) {
                    case "1":
                    case "2":
                        // C3
                        c3.setContributionType(ContributionType.PART_PATRONALE);
                        contrat.addCompartiment(c3);
                        break;

                    case "3":
                    case "4":
                        // C1/C4 C3
                        c3.setContributionType(ContributionType.PART_PATRONALE);
                        contrat.addCompartiment(c1x);
                        contrat.addCompartiment(c3);
                        break;

                    case "5":
                        // C1/C4
                        contrat.addCompartiment(c1x);
                        break;

                    default:
                        break;

                }
                completePartsType(contrat, infosContrat);
                contrats.add(contrat);
            }
        });
        return contrats;
    }

    private String getCollegeNullSafe(Compart compart) {
        return compart != null ? compart.getLibCatPrslCompart() : null;
    }

    private Compart getCompartNullSafe(ContratHeaderDto dto) {
        return dto.getCompart() != null && dto.getCompart().get(0) != null ? dto.getCompart().get(0) : null;
    }

    @Mapping(source = "identifiantAssure", target = "identifiantAssure")
    @Mapping(source = "etatContrat", target = "etatContrat")
    @Mapping(source = "etatContratLabel", target = "libelleEtat")
    @Mapping(source = "etatAffiliationLabel", target = "libelleEtatAssure")
    @Mapping(source = "college", target = "college")
    @Mapping(source = "idCollege", target = "idCollege")
    public abstract Compartiment map(ContratHeaderDto contratHeader);

    @Mapping(source = "idAssure", target = "identifiantAssure")
    @Mapping(source = "libCatPrslCompart", target = "college")
    @Mapping(source = "idCatPrslCompart", target = "idCollege")
    @Mapping(source = "libCompartSilo", target = "type", qualifiedByName = "compartimentTypePacte")
    @Mapping(source = "libCompartSilo", target = "deductible", qualifiedByName = "deductibilitePacte")
    @Mapping(source = "dateSitCompart", target = "dateAffiliation")
    @Mapping(source = "codeSitCompart", target = "etatCompartiment", qualifiedByName = "etatCompartimentPacte")
    public abstract Compartiment map(Compart compart);

    @Mapping(source = "codeEtat", target = "etatContrat", qualifiedByName = "situationContratEnum")
    @Mapping(source = "dateEffetSituationAffiliation", target = "dateEffetSituationAffiliation")
    @Mapping(source = "libelleContributionInvestissementSilo", target = "contributionType", qualifiedByName = "contributionType")
    public abstract void updateCompartimentPacte(CompteGeneralesERE cge, @MappingTarget Compartiment compartiment);

    @Mapping(source = "dateAffiliation", target = "dateAffiliation")
    @Mapping(source = "codeEtat", target = "etatContrat", qualifiedByName = "situationContratEnum")
    @Mapping(source = "dateEffetSituationAffiliation", target = "dateEffetSituationAffiliation")
    public abstract void updateContratHeader(CompteGeneralesERE cge, @MappingTarget ContratRente contratHeader);


    @Named("compartimentTypePacte")
    public CompartimentType compartimentTypePacte(String libelleContribution) {
        if (libelleContribution == null) {
            return null;
        }

        switch (libelleContribution.trim()) {
            case "Versements Volontaires":
                return CompartimentType.C1;
            case "Versements Volontaires non déductibles":
                return CompartimentType.C4;
            case "Part patronale":
            case "Part salariale":
            case "Versements obligatoires":
                return CompartimentType.C3;
            case "Epargne Salariale":
                return CompartimentType.C2;
            default:
                return null;
        }
    }

    @Named("contributionType")
    public ContributionType contributionType(String libelleContribution) {
        return ContributionType.forLibelle(libelleContribution);
    }

    @Named("deductibilitePacte")
    public boolean deductibilitePacte(String libelle) {
        return "Versements Volontaires".equals(libelle);
    }

    @Named("situationContratEnum")
    public SituationContratEnum situationContratEnum(String codeSilo) {
        try {
            return SituationContratEnum.fromCodeSilo(codeSilo);
        } catch (UnknownEnumerationValueException e) {
            return null;
        }
    }

    @Named("etatCompartimentPacte")
    public SituationAffiliationEnum etatCompartimentPacte(String codeSitCompart) {
        return Arrays.stream(SituationAffiliationEnum.values())
                .filter(s -> s.getCodeValue().equals(codeSitCompart))
                .findFirst()
                .orElse(null);
    }

    private void testPetitCollectifPTV(ContratRente contrat, InfosContratDto infosContratDto) {
        final ContratGeneral contratGeneral = infosContratDto.getContratGeneral();
        final String typeContrat = contratGeneral.getTypeContrat();
        final String numGenContrat = contratGeneral.getNumGenContrat();
        if ("RG02".equals(typeContrat) && "002".equals(numGenContrat)) {
            contrat.setPetitCollectifPTV(true);
        }
    }
}
