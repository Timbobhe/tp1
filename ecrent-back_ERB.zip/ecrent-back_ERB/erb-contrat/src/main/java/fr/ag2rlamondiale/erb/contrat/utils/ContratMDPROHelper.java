package fr.ag2rlamondiale.erb.contrat.utils;

import com.google.common.collect.Sets;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

import static fr.ag2rlamondiale.trm.utils.Sets.concat;
import static fr.ag2rlamondiale.trm.utils.Sets.set;

@Service
public class ContratMDPROHelper {
    private static final Set<String> TYPE_AUTORISE_PACTE = set("RA09");
    private static final Set<String> C1_C4_PACTE = set("A01", "A02", "A03", "A04", "A05", "A06", "A07", "A08");
    private static final Set<String> C2_PACTE = set("B01", "B02");
    private static final Set<String> C3_PACTE = set("C01", "C02");
    protected static final Set<String> TYPE_AUTORISE_NON_PACTE = set("RA09", "RA10");

    private static final Set<String> C1_PACTE_NEW_CONTRAT_MADELIN = set("A21", "A22", "A31", "A32");
    private static final Set<String> C2_PACTE_NEW_CONTRAT_MADELIN = set("B21", "B22", "B31", "B32");
    private static final Set<String> C3_PACTE_NEW_CONTRAT_MADELIN = set("C21", "C22", "C31", "C32");

    private static final Set<String> PACTE = concat(C1_C4_PACTE, C1_PACTE_NEW_CONTRAT_MADELIN, C2_PACTE, C2_PACTE_NEW_CONTRAT_MADELIN, C3_PACTE, C3_PACTE_NEW_CONTRAT_MADELIN);

    private static final Set<String> OLD_NUMGEN_CONTRAT_MADELIN = Sets.newHashSet("V01", "V02", "V21", "V22", "V31", "V32", "V41", "V42");

    @Autowired
    private IParamConsoleFacade paramConsoleFacade;

    private boolean isContientInformation(ContratRente contrat) {
        return contrat.getTypeContrat() != null && contrat.getNumGenContrat() != null;
    }

    public boolean isC2Pacte(ContratRente contrat) {
        return isContratAutorisePacte(contrat) && (C2_PACTE.contains(contrat.getNumGenContrat()) || C2_PACTE_NEW_CONTRAT_MADELIN.contains(contrat.getNumGenContrat()));
    }

    public boolean isC3Pacte(ContratRente contrat) {
        return isContratAutorisePacte(contrat) && (C3_PACTE.contains(contrat.getNumGenContrat()) || C3_PACTE_NEW_CONTRAT_MADELIN.contains(contrat.getNumGenContrat()));
    }

    public boolean isC1PacteNewContratMadelin(ContratRente contrat) {
        return C1_PACTE_NEW_CONTRAT_MADELIN.contains(contrat.getNumGenContrat());
    }

    public boolean isContratNonPacte(ContratRente contrat) {
        return isContratAutorise(contrat) && !PACTE.contains(contrat.getNumGenContrat());
    }

    // Arbitrage
    public boolean isContratAutoriseNonPacteArbitrage(ContratRente contrat) {
        return isContratAutorise(contrat, TYPE_AUTORISE_NON_PACTE);
    }

    public boolean isContratAutoriseNonPacte(ContratRente contrat) {
        return isContratAutorise(contrat, TYPE_AUTORISE_NON_PACTE);
    }

    private boolean isContratAutorisePacte(ContratRente contrat) {
        return isContratAutorise(contrat, TYPE_AUTORISE_PACTE);
    }

    private boolean isContratAutorise(ContratRente contrat, Set<String> types) {
        return isContratAutorise(contrat) && types.contains(contrat.getTypeContrat());
    }

    public boolean isContratAutorise(ContratRente contrat) {
        if (isContientInformation(contrat)) {
            ProduitJson produit = paramConsoleFacade.findProduitMdpro(contrat.getTypeContrat() + contrat.getNumGenContrat());
            return produit != null;
        }
        return false;
    }

    public boolean isContratPacte(ContratRente contrat) {
        return isContratAutorisePacte(contrat) && PACTE.contains(contrat.getNumGenContrat());
    }

    public boolean isContratDeductible(ContratRente contrat) {
        if (isContientInformation(contrat)) {
            ProduitJson produit = paramConsoleFacade.findProduitMdpro(contrat.getTypeContrat() + contrat.getNumGenContrat());

            if (produit != null && produit.getDeductible() != null) {
                return produit.getDeductible();
            }
        }
        return false;
    }

    public boolean isVifPossible(ContratRente contrat) {
        throw new NotImplementedException("Method not implemented!");
    }

    public boolean isAutreContrat(ContratRente contratRente) {
        boolean isAutreContrat;
        if (contratRente.isMdpro()) {
            if (contratRente.isPacte()) {
                isAutreContrat = !isContratAutorisePacte(contratRente);
            } else {
                isAutreContrat = !isContratAutoriseNonPacteArbitrage(contratRente);
            }
        } else {
            isAutreContrat = false;
        }
        return isAutreContrat;
    }

    public boolean isContainOldNumGenContratMadelin(ContratRente contrat) {
        return TYPE_AUTORISE_PACTE.contains(contrat.getTypeContrat()) && OLD_NUMGEN_CONTRAT_MADELIN.contains(contrat.getNumGenContrat());
    }
}
