package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.business.IContratFacade;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;
import fr.ag2rlamondiale.erb.pfs.client.rest.IConsulterOptionRenteContratClient;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteContratDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.ConsulterOptionRenteIn;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteDto;
import fr.ag2rlamondiale.erb.pfs.domain.rente.OptionRenteType;
import fr.ag2rlamondiale.trm.business.IConsulterPersPhysFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CalculerEligibiliteFacadeImplTest {

	@Mock
	private IContratFacade contratFacade;

	@Mock
	private IConsulterOptionRenteContratClient consulterOptionRenteContrat;

	@InjectMocks
	private CalculerEligibiliteFacadeImpl facadeImpl;

	@Mock
	private UserContextHolder userContextHolder;

	@Mock
	private IConsulterPersPhysFacade consulterPersPhysFacade;

	@Test
	public void calcul_eligibilite_rente_personne() throws TechnicalException, ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
		Date date = formatter.parse("07-07-2013");
		// WHEN
		List<ContratHeaderDto> contrats = createContrats();
		when(contratFacade.rechercherContrats(ArgumentMatchers.anyString())).thenReturn(contrats);
		ConsulterOptionRenteContratDto optionsRente = createOptionsRente();
		when(consulterOptionRenteContrat
				.consulterOptionRenteContrat(ArgumentMatchers.any(ConsulterOptionRenteIn.class)))
						.thenReturn(optionsRente);
		when(userContextHolder.get()).thenReturn(createUserContext());
		when(consulterPersPhysFacade.consulterPersPhys(ArgumentMatchers.any(IdSiloDto.class)))
				.thenReturn(createPersonePhysiqueConsult());

		// THEN
		EligibiliteRenteRequest in = EligibiliteRenteRequest.builder().nom("nom").prenom("prenom").dateNaissance(date).idPersonne("P234").build();
		InfoEligibiliteRente resultat = facadeImpl.calculEligibiliteRente(in);

		// Assert
		assertNotNull(resultat);
		assertEquals("P234", resultat.getIdPersonne());
		assertEquals(2, resultat.getContrats().size());
		assertEquals("TRUE", resultat.getAccesAutorise());
	}

	private ConsulterOptionRenteContratDto createOptionsRente() throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
		Date dateDebut = formatter.parse("07-07-2013");
		Date dateFin = formatter.parse("07-07-2019");

		OptionRenteDto option1 = OptionRenteDto.builder().optRenteType(OptionRenteType.DIFF).dateDebutEffet(dateDebut)
				.dateFinEffet(dateFin).build();
		OptionRenteDto option2 = OptionRenteDto.builder().optRenteType(OptionRenteType.DIFF).dateDebutEffet(dateFin)
				.dateFinEffet(null).build();
		return ConsulterOptionRenteContratDto.builder().optionRentes(Arrays.asList(option1, option2)).build();
	}

	@Test
	public void calcul_eligibilite_rente_contrat() throws TechnicalException, ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
		Date date = formatter.parse("07-07-2013");
		// WHEN
		List<ContratHeaderDto> contrats = createContrats();
		when(contratFacade.rechercherContrats(ArgumentMatchers.anyString())).thenReturn(contrats);
		ConsulterOptionRenteContratDto optionsRente = createOptionsRente();
		when(consulterOptionRenteContrat
				.consulterOptionRenteContrat(ArgumentMatchers.any(ConsulterOptionRenteIn.class)))
						.thenReturn(optionsRente);
		when(userContextHolder.get()).thenReturn(createUserContext());
		when(consulterPersPhysFacade.consulterPersPhys(ArgumentMatchers.any(IdSiloDto.class)))
				.thenReturn(createPersonePhysiqueConsult());

		// THEN
		EligibiliteRenteRequest in = EligibiliteRenteRequest.builder().nom("nom").prenom("prenom").dateNaissance(date).idPersonne("P234").idContrat("RG001").build();
		InfoEligibiliteRente resultat = facadeImpl.calculEligibiliteRente(in);

		// Assert
		assertNotNull(resultat);
		assertEquals("P234", resultat.getIdPersonne());
		assertEquals(1, resultat.getContrats().size());
		assertEquals("TRUE", resultat.getAccesAutorise());
	}

	private PersonnePhysiqueConsult createPersonePhysiqueConsult() throws ParseException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
		Date date = formatter.parse("07-07-2013");
		PersonnePhysiqueConsult physiqueConsult = new PersonnePhysiqueConsult();
		physiqueConsult.setNom("nom");
		physiqueConsult.setPrenom("prenom");
		physiqueConsult.setDateDeNaissance(date);
		physiqueConsult.setId("P00000");
		physiqueConsult.setDonneesPersonnellesConfirmees(true);
		physiqueConsult.setEmailPro("emailpro@email.domain");
		physiqueConsult.setTelPortable("06XXXXXXXX");
		physiqueConsult.setPays("pays");
		physiqueConsult.setPaysResidenceFiscale("pays");
		return physiqueConsult;
	}

	private List<ContratHeaderDto> createContrats() {
		ContratHeaderDto c1 = ContratHeaderDto.builder().codeSilo(CodeSiloType.ERE).id("EV001401553001")
				.codeFiliale("MEP").etatContrat(SituationContratEnum.EN_COURS).build();
		ContratHeaderDto c2 = ContratHeaderDto.builder().id("RG001").codeFiliale("PEM")
				.etatContrat(SituationContratEnum.EN_COURS).build();
		ContratHeaderDto c3 = ContratHeaderDto.builder().id("EV001401553000").codeFiliale("REP")
				.etatContrat(SituationContratEnum.EN_COURS).build();
		ContratHeaderDto c4 = ContratHeaderDto.builder().typeContrat("CD01").codeFiliale("PEM")
				.etatContrat(SituationContratEnum.EN_COURS).build();
		ContratHeaderDto c5 = ContratHeaderDto.builder().libParticulariteRente("Gestion déléguée sans prélèvement")
				.codeFiliale("PEM").etatContrat(SituationContratEnum.EN_COURS).build();

		ContratHeaderDto contratPassant = ContratHeaderDto.builder().typeContrat("RK04").codeFiliale("PEM")
				.etatContrat(SituationContratEnum.EN_COURS).build();

		return Arrays.asList(c1, c2, c3, c4, c5, contratPassant);
	}

	private UserContext createUserContext(){
		UserContext userContext = new UserContext();
		userContext.setIdGdi("idgdi");
		userContext.setForSupervision(true);
		userContext.setNumeroPersonneEre("IdPersonne");
		userContext.setSilos(Sets.set(CodeSiloType.ERE));
		return userContext;
	}

}
