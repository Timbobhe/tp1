package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class ContratFacadeImplTest {

    @Spy
    @InjectMocks
    ContratFacadeImpl contratFacade;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    ContratClientFacadeImpl contratClientFacade;

    @Mock
    IContratsClient contratClient;

    @Spy
    private RequestContextHolder requestContext = new RequestContextHolder();


    @Before
    public void init() throws TechnicalException {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
        when(userContextHolder.get()).thenReturn(userContext);
        when(contratClientFacade.rechercherContratsPersonne(rechContrat("NumMDP", CodeSiloType.MDP)))
                .thenReturn(createContratList(CodeSiloType.MDP));
        when(contratClientFacade.rechercherContratsPersonne(rechContrat("NumERE", CodeSiloType.ERE)))
                .thenReturn(createContratList(CodeSiloType.ERE));

    }

    @Test
    public void rechercherContrats() throws TechnicalException {
        List<ContratRente> contrats = contratFacade.rechercherContrats();
        when(userContextHolder.get()).thenReturn(userContext());
        contrats = contratFacade.rechercherContrats();
        assertEquals(4, contrats.size());
    }

    @Test
    public void rechercherContratsEre() throws TechnicalException {
        List<ContratRente> contrats = contratFacade.rechercherContratsEre();
        assertEquals(2, contrats.size());
        /// annuler le init
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacade.rechercherContratsEre().isEmpty());
    }

    @Test
    public void rechercherContratsMdpro() throws TechnicalException {
        List<ContratRente> contrats = contratFacade.rechercherContratsMdpro();
        assertEquals(2, contrats.size());
        /// annuler le init
        when(userContextHolder.get()).thenReturn(userContextEmpty());
        assertTrue(contratFacade.rechercherContratsMdpro().isEmpty());
    }

    @Test
    public void getContratGenerale_throwException() throws TechnicalException {
        final var idContrat = "Id1";
        var ccg= ConsulterContratGeneralesDto.builder().idContrat(idContrat)
                .codeSilo(CodeSiloType.ERE)
                .typeIdentifiant(EnumTypeIdentifiantSilo.CONTRAT_RENTE)
                .build();
        when(contratClient.consulterContratGenerales(ccg)).thenThrow(TechnicalException.class);
        Assertions.assertThrows(TechnicalRuntimeException.class, () -> {contratFacade.getContratGenerale(idContrat, CodeSiloType.ERE);});
    }

    @Test
    public void getContratGenerale() throws TechnicalException {
        final var idContrat = "Id1";
        ContratGeneral contratGeneral = ContratGeneral.builder().id(idContrat).build();
       var ccg= ConsulterContratGeneralesDto.builder().idContrat(idContrat)
                .codeSilo(CodeSiloType.ERE)
                .typeIdentifiant(EnumTypeIdentifiantSilo.CONTRAT_RENTE)
                        .build();
        when(contratClient.consulterContratGenerales(ccg)).thenReturn(contratGeneral);
        Assertions.assertEquals(contratGeneral, contratFacade.getContratGenerale(idContrat, CodeSiloType.ERE));
    }



    @Test
    public void getCompteGenerale() throws TechnicalException {
        final var idAssure = "IdAssur";
        var ccgERE = new ConsulterCompteGeneralesEREDto(idAssure);
        final var compteGeneralesERE = CompteGeneralesERE.builder().idAssure(idAssure).build();
        when(contratClient.consulterCompteGeneralesERE(ccgERE)).thenReturn(compteGeneralesERE);
        Assertions.assertEquals(compteGeneralesERE, contratFacade.getCompteGenerale(idAssure, CodeSiloType.ERE));
    }

    @Test
    public void getCompteGenerale_NotERE() throws TechnicalException {
        final var idAssure = "IdAssur";
        var ccgERE = new ConsulterCompteGeneralesEREDto(idAssure);
        Assertions.assertNull(contratFacade.getCompteGenerale(idAssure, CodeSiloType.MDP));
        Mockito.verify(contratClient, Mockito.never()).consulterCompteGeneralesERE(ccgERE);
    }

    @Test
    public void getCompteGenerale_ThrowException() throws TechnicalException {
        final var idAssure = "IdAssur";
        var ccgERE = new ConsulterCompteGeneralesEREDto(idAssure);
        when(contratClient.consulterCompteGeneralesERE(ccgERE)).thenThrow(TechnicalException.class);
        Assertions.assertThrows(TechnicalRuntimeException.class, () -> {contratFacade.getCompteGenerale(idAssure, CodeSiloType.ERE);});
    }


    @Test
    public void recupererContratComplet() throws TechnicalException {
        final ContratRente contratRente = buildContrat("id", "idAssur", CodeSiloType.ERE);
        var ccg= ConsulterContratGeneralesDto.builder().idContrat(contratRente.getId())
                .codeSilo(contratRente.getCodeSilo())
                .typeIdentifiant(EnumTypeIdentifiantSilo.CONTRAT_RENTE)
                .build();
        final ContratGeneral contratGeneral = new ContratGeneral();
        when(contratClient.consulterContratGenerales(ccg))
                .thenReturn(contratGeneral);
        final ContratComplet contratComplet = contratFacade.recupererContratComplet(contratRente);
        Assertions.assertNotNull(contratComplet);
        Mockito.verify(contratClient, Mockito.times(1))
                .consulterContratGenerales(ccg);
    }

    @Test
    public void getRechercherContrats() throws TechnicalException {
        final String numPersonne = "NumPerson";
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setPersonId(numPersonne);
        rechercherContratsDto.setCodeAppli(CodeApplicationType.PTV_RENTE_ERE);
        List<ContratHeaderDto> contratHeaderDtoList = Collections.EMPTY_LIST;
        when(contratClient.rechercherContratsPersonneV3(rechercherContratsDto))
                .thenReturn(contratHeaderDtoList);
        final List<ContratHeaderDto> contratHeaderDtos = contratFacade.rechercherContrats(numPersonne);
        Mockito.verify(contratClient, Mockito.times(1))
                .rechercherContratsPersonneV3(rechercherContratsDto);

    }

    private List<ContratRente> createContratList(CodeSiloType silo) {
        return Arrays.asList(buildContrat("id", "idAssur", silo), buildContrat("id1", "idAssur1", silo));
    }

    private ContratRente buildContrat(String id, String idAssure, CodeSiloType silo) {
        ContratRente contrat = new ContratRente();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setAffichageType(AffichageType.NORMAL);
        return contrat;
    }

    private UserContext userContext() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("NumMDP");
        userContext.setNumeroPersonneEre("NumERE");
        return userContext;
    }

    private RechercherContratsDto rechContrat(String idPersonne, CodeSiloType codeSilo) {
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(codeSilo);
        rechercherContratsDto.setPersonId(idPersonne);
        return rechercherContratsDto;
    }

    private RechercherContratsDto rechContrat(String idPersonne, CodeSiloType codeSilo, CodeApplicationType codeAppli) {
        RechercherContratsDto rechercherContratsDto = rechContrat(idPersonne, codeSilo);
        rechercherContratsDto.setCodeAppli(codeAppli);
        return rechercherContratsDto;
    }

    private UserContext userContextEmpty() {
        UserContext userContext = new UserContext();
        userContext.setNumeroPersonneMdpro("");
        userContext.setNumeroPersonneEre("");
        return userContext;
    }


}