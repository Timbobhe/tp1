package fr.ag2rlamondiale.erb.contrat.mapping.mock;

import com.alm.esb.service.contratconsult_3.consultercontratgenerales_1.ConsulterContratGeneralesResponseType;
import com.alm.esb.service.gestcontratere_1.consultercomptegeneralesere_1.ConsulterCompteGeneralesEREResponseType;
import com.alm.esb.service.gestctrpers_1.rechercherctrperssilo_3.RechercherCtrPersSiloResponseType;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.comptes.ConsulterCompteGeneralesEREResponseMapperImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.contrats.LibelleOffreMdp3Mapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.contrats.RechercherContratsResponse3MapperImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.contratsgenerales.ConsulterContratGeneralesResponseMapperImpl;
import fr.ag2rlamondiale.trm.csv.EtatAssureMapper;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsResponseDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ContratsClientMock extends ContratsClientAdapter {

    @Spy
    DateMapper dateMapper;

    @InjectMocks
    LibelleOffreMdp3Mapper libelleOffreMdp3Mapper;

    @InjectMocks
    private RechercherContratsResponse3MapperImpl mapperRechercherContratsResponse3;

    @InjectMocks
    private ConsulterContratGeneralesResponseMapperImpl consulterContratGeneralesResponseMapper;

    @InjectMocks
    private ConsulterCompteGeneralesEREResponseMapperImpl compteGeneralesEREResponseMapper;

    @Spy
    EtatAssureMapper etatAssureMapper;

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    private final ContratClientConfig config;

    public ContratsClientMock(ContratClientConfig config) {
        this.config = config;
        init();
    }

    public void init() {
        MockitoAnnotations.initMocks(this);
        IParamConsoleFacade produitFacade = mock(IParamConsoleFacade.class);
        when(produitFacade.findProduitMdpro(eq("RA09V41"))).thenReturn(produit("Retraite Professionnels"));
        ProduitJson produitJson = new ProduitJson();
        produitJson.setLibelle("ACA");
        produitJson.setTypeContrat("RG04");
        produitJson.setNumeroGeneration("003");
        produitJson.setLibelle("MOCKDATA");
        when(produitFacade.findProduitEre(any(String.class), any(String.class), any(String.class))).thenReturn(Optional.of(produitJson));
        ReflectionTestUtils.setField(libelleOffreMdp3Mapper, "produitFacade", produitFacade);
        ReflectionTestUtils.setField(mapperRechercherContratsResponse3, "libelleOffreMdpMapper", libelleOffreMdp3Mapper);
        ReflectionTestUtils.setField(consulterContratGeneralesResponseMapper, "libelleOffreMdpMapper", libelleOffreMdp3Mapper);
        ReflectionTestUtils.setField(consulterContratGeneralesResponseMapper, "paramConsoleFacade", produitFacade);
        when(paramConsoleFacade.getSupportsInvestissement(any())).thenReturn(supportInvestissement("9495", "24 trimestres"));
        MockitoAnnotations.initMocks(this);
    }

    private ProduitJson produit(String libelle) {
        ProduitJson p = new ProduitJson();
        p.setLibelle(libelle);
        return p;
    }

    private SupportInvestissementJson supportInvestissement(String code, String libelle) {
        SupportInvestissementJson support = new SupportInvestissementJson();
        support.setCodeSupport(code);
        support.setLibelleFront(libelle);
        return support;
    }

    public ContratClientConfig getConfig() {
        return config;
    }

    @Override
    public List<ContratHeaderDto> rechercherContratsRetraiteSupp(RechercherContratsDto rechercherContratsDto) {
        // Given
        RechercherCtrPersSiloResponseType type = XmlMarshaller.convertSoapBodyToObject(
                "/xml/" + config.getPersonId() + "/RechercherCtrPersSilo_2." + config.getPersonId() + ".xml", RechercherCtrPersSiloResponseType.class);
        // When
        RechercherContratsResponseDto dto = mapperRechercherContratsResponse3.rechercherContratsTypeToDto(type);
        dto.getContrats().forEach(contratHeaderDto -> contratHeaderDto.setPersonId(config.getPersonId()));
        return dto.getContrats();
    }

    @Override
    public ContratGeneral consulterContratGenerales(ConsulterContratGeneralesDto dto) {
        ConsulterContratGeneralesResponseType response = XmlMarshaller.convertSoapBodyToObject(
                "/xml/" + config.getPersonId() + "/ConsulterContratGenerales_5." + dto.getIdContrat() + ".xml", ConsulterContratGeneralesResponseType.class);

        return consulterContratGeneralesResponseMapper.consulterContratGeneralesTypeToDto(response);
    }

    @Override
    public CompteGeneralesERE consulterCompteGeneralesERE(ConsulterCompteGeneralesEREDto dto) {
        final String idAssure = dto.getIdAssure();
        ConsulterCompteGeneralesEREResponseType response = XmlMarshaller.convertSoapBodyToObject(
                "/xml/" + config.getPersonId() + "/ConsulterCompteGeneralesERE_1." + idAssure + ".xml", ConsulterCompteGeneralesEREResponseType.class);

        return compteGeneralesEREResponseMapper.toCompteGeneralesERE(response);
    }
}
