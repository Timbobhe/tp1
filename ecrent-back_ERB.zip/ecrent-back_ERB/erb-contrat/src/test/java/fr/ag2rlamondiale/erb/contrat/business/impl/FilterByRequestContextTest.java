package fr.ag2rlamondiale.erb.contrat.business.impl;

import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.api.secure.context.RequestContextHolder;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class FilterByRequestContextTest {

    @Spy
    private RequestContextHolder requestContext = new RequestContextHolder();

    @InjectMocks
    FilterByRequestContext filterByRequestContext;

    @Before
    public void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void filter_requestHolder_hasContrat() {

        final ContratRente contratRente1 = buildContratRente("id1", "idAssur1", CodeSiloType.ERE);
        final ContratRente contratRente2 = buildContratRente("id2", "idAssur2", CodeSiloType.ERE);
        Mockito.doReturn("id1").when(requestContext).getContrat();
        List<ContratRente> contrats = Arrays.asList(contratRente1, contratRente2);
        final List<ContratRente> filteredContrats = filterByRequestContext.filter(contrats);
        Assertions.assertFalse(filteredContrats.isEmpty());
        Assertions.assertEquals(0, contratRente1.compareTo(filteredContrats.stream().findFirst().orElse(null)));
    }

    @Test
    public void filter_requestHolder_hasNoContrat() {

        final ContratRente contratRente1 = buildContratRente("id1", "idAssur1", CodeSiloType.ERE);
        final ContratRente contratRente2 = buildContratRente("id2", "idAssur2", CodeSiloType.ERE);
        Mockito.doReturn(null).when(requestContext).getContrat();
        List<ContratRente> contrats = Arrays.asList(contratRente1, contratRente2);
        final List<ContratRente> filteredContrats = filterByRequestContext.filter(contrats);
        Assertions.assertFalse(filteredContrats.isEmpty());
        Assertions.assertEquals(2, filteredContrats.size());
    }

    private ContratRente buildContratRente(String id, String idAssure, CodeSiloType silo) {
        ContratRente contrat = new ContratRente();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        return contrat;
    }
}