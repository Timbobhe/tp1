package fr.ag2rlamondiale.erb.contrat.api.unsecure;

import com.ag2r.common.exceptions.TechnicalException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import fr.ag2rlamondiale.erb.contrat.business.ICalculerEligibiliteFacade;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(classes = {WebConfig.class, EligibiliteRenteRestController.class})
public class EligibiliteRenteRestControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    ICalculerEligibiliteFacade calculEligibiliteFacade;

    @Test
    public void getEligibiliteRente() throws Exception {
        final String idPerson = "idPersonTest";
        EligibiliteRenteRequest request = EligibiliteRenteRequest.builder().build();
        InfoEligibiliteRente infoEligibiliteRente = InfoEligibiliteRente.builder()
                .idPersonne(idPerson)
                .build();
        Mockito.when(calculEligibiliteFacade.calculEligibiliteRente(request))
                .thenReturn(infoEligibiliteRente);

        mvc.perform(MockMvcRequestBuilders
                .post("/api/getEligibiliteRente")
                        .content(convertToJson(request))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.idPersonne").value(idPerson));
        Mockito.verify(calculEligibiliteFacade, Mockito.times(1))
                .calculEligibiliteRente(request);
    }

    @Test
    public void getEligibiliteRente_exceptionThrown() throws Exception {
        final String idPerson = "idPersonTest";
        EligibiliteRenteRequest request = EligibiliteRenteRequest.builder().build();
        InfoEligibiliteRente infoEligibiliteRente = InfoEligibiliteRente.builder()
                .idPersonne(idPerson)
                .build();
        final String exceptionMsg = "ExceptionMsg";
        Mockito.when(calculEligibiliteFacade.calculEligibiliteRente(request))
                        .thenThrow(new TechnicalException("", new Exception(exceptionMsg)));


        try {
            mvc.perform(MockMvcRequestBuilders
                    .post("/api/getEligibiliteRente")
                    .content(convertToJson(request))
                    .contentType(MediaType.APPLICATION_JSON));
        } catch(Exception e){
            Assertions.assertTrue(e.getMessage().contains(exceptionMsg));
        }

        Mockito.verify(calculEligibiliteFacade, Mockito.times(1))
                .calculEligibiliteRente(request);
    }

    private String convertToJson(Object obj){
        ObjectMapper mapper = new ObjectMapper();
        mapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
        ObjectWriter ow = mapper.writer().withDefaultPrettyPrinter();
        try {
            return ow.writeValueAsString( obj );
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

}

@Configuration
@EnableWebMvc
class WebConfig {

}