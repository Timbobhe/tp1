package fr.ag2rlamondiale.erb.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.erb.contrat.mapping.ContratPacteMapperERE;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class ContratClientFacadeImplTest {

    @InjectMocks
    ContratClientFacadeImpl sut;

    @Mock
    IContratsClient contratClient;


    @Mock
    ContratPacteMapperERE contratPacteMapperERE;


    @Before
    public void init() throws TechnicalException {
        when(contratClient.rechercherContratsRetraiteSupp(rechContrat("NumERE", CodeSiloType.ERE)))
                .thenReturn(createContratRenteList(CodeSiloType.ERE));
        when(contratClient.rechercherContratsRetraiteSupp(rechContrat("NumMDP", CodeSiloType.MDP)))
                .thenReturn(createContratRenteList(CodeSiloType.ERE));
        when(contratClient.consulterContratGenerales(any(ConsulterContratGeneralesDto.class)))
                .thenReturn(ContratGeneral.builder().build());
        when(contratClient.consulterContratGenerales(any(ConsulterContratGeneralesDto.class)))
                .thenReturn(ContratGeneral.builder().build());
    }


    @Test
    public void calculerEncoursContratERETest() throws TechnicalException {
        RechercherContratsDto rechercherContratsDto = rechContrat("NumERE", CodeSiloType.ERE);
        final List<ContratRente> contratRentes = sut.rechercherContratsPersonne(rechercherContratsDto);
        Assert.assertNotNull(contratRentes);
    }

    @Test
    public void calculerEncoursContratMDPTest() throws TechnicalException {
        RechercherContratsDto rechercherContratsDto = rechContrat("NumMDP", CodeSiloType.MDP);
        final List<ContratRente> contratRentes = sut.rechercherContratsPersonne(rechercherContratsDto);
        Assert.assertNotNull(contratRentes);
    }

    private RechercherContratsDto rechContrat(String idPersonne, CodeSiloType codeSilo) {
        RechercherContratsDto rechercherContratsDto = new RechercherContratsDto();
        rechercherContratsDto.setCodeSilo(codeSilo);
        rechercherContratsDto.setPersonId(idPersonne);
        return rechercherContratsDto;
    }

    private List<ContratHeaderDto> createContratRenteList(CodeSiloType silo) {
        return Arrays.asList(buildContratRente("id", "idAssur", silo), buildContratRente("id1", "idAssur1", silo));
    }

    private ContratHeaderDto buildContratRente(String id, String idAssure, CodeSiloType silo) {
        ContratHeaderDto contrat = new ContratHeaderDto();
        contrat.setId(id);
        contrat.setIdentifiantAssure(idAssure);
        contrat.setCodeSilo(silo);
        contrat.setEtatContrat(SituationContratEnum.CREATION);
        contrat.setCompart(Collections.emptyList());
        return contrat;
    }


}