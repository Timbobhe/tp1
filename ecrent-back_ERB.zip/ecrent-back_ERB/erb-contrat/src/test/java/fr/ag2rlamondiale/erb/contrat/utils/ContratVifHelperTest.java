package fr.ag2rlamondiale.erb.contrat.utils;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.BasicEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class ContratVifHelperTest {

    @Mock
    IConsulterPersonneClient consulterPersonneClient;

    @Mock
    ContratMDPROHelper contratMDPROHelper;

    @InjectMocks
    ContratVifHelper contratVifHelper;

    @Test
    public void isVifPossible_PersonAgeGreaterThanLimitedAge_ERE() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(50);
        personnePhysiqueConsult.setLimiteAgeVIF(47);

        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet);

        Assert.assertFalse(vifPossible);
    }

    @Test
    public void isVifPossible_PersonAgeGreaterThanLimitedAge_MDP() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.MDP);
        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(50);
        personnePhysiqueConsult.setLimiteAgeVIF(47);

        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet);

        Assert.assertFalse(vifPossible);
    }

    @Test
    public void isVifPossible_test1() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        // Given
        optContratEpargne.setIndRefusVIF("1");
        contratComplet.setContratGeneral(
                ContratGeneral.builder()
                        .optContratEpargne(optContratEpargne)
                        .build()
        );

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(30);
        personnePhysiqueConsult.setLimiteAgeVIF(47);
        // When
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet);
        // Then
        Assert.assertFalse(vifPossible);
    }

    @Test
    public void isVifPossible_test2() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        // Given
        optContratEpargne.setIndResiliation(true);
        contratComplet.setContratGeneral(
                ContratGeneral.builder()
                        .optContratEpargne(optContratEpargne)
                        .build()
        );

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(30);
        personnePhysiqueConsult.setLimiteAgeVIF(47);
        // When
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet);
        // Then
        Assert.assertFalse(vifPossible);
    }

    @Test
    public void isVifPossible_Pacte_HasVLVersement() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        // Given
        contratComplet.getContratHeader().setPacte(true);
        final CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setCodeEtat(SituationAffiliationEnum.LIBERE.getCodeSilo());
        final CompartimentId compartimentId = CompartimentId.ere("IdAssure", CompartimentType.C1);
        contratComplet.setCompteGeneralesERE(compteGeneralesERE);
        Map<CompartimentId, CompteGeneralesERE> compteGeneralesEreParCompartiment = new HashMap<>() {{
            put(compartimentId, compteGeneralesERE);
        }};
        final BasicEncours basicEncours = new BasicEncours();
        basicEncours.setHasVLVersement(true);
        Supplier<Encours> supplier = () -> basicEncours;
        Memoizer<Encours> mEncoursParCompartiment= new Memoizer<>(supplier);

        contratComplet.setEncours(compartimentId, mEncoursParCompartiment);
        contratComplet.setCompteGeneralesEreParCompartiment(compteGeneralesEreParCompartiment);
        contratComplet.setContratGeneral(
                ContratGeneral.builder()
                        .optContratEpargne(optContratEpargne)
                        .build()
        );

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(30);
        personnePhysiqueConsult.setLimiteAgeVIF(47);
        // When
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet, compartimentId);
        // Then
        Assert.assertTrue(vifPossible);
        Assert.assertEquals(basicEncours.hasVLVersement(), vifPossible);
    }

    @Test
    public void isVifPossible_NonPacte() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setCodeTypeTenueCompte("6");
        // Given
        contratComplet.getContratHeader().setPacte(false);

        final CompartimentId compartimentId = CompartimentId.ere("IdAssure", CompartimentType.C1);
        contratComplet.setContratGeneral(
                ContratGeneral.builder()
                        .optContratEpargne(optContratEpargne)
                        .build()
        );

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(30);
        personnePhysiqueConsult.setLimiteAgeVIF(47);
        // When
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet, compartimentId);
        // Then
        Assert.assertFalse(vifPossible);
    }


    @Test
    public void isVifPossible_NonPacte_HasVLVersement() throws TechnicalException {
        ContratComplet contratComplet = buildContraComplet(CodeSiloType.ERE);
        final OptContratEpargne optContratEpargne = new OptContratEpargne();
        optContratEpargne.setCodeTypeTenueCompte("4");
        // Given
        contratComplet.getContratHeader().setPacte(false);
        final CompteGeneralesERE compteGeneralesERE = new CompteGeneralesERE();
        compteGeneralesERE.setCodeEtat(SituationAffiliationEnum.LIBERE.getCodeSilo());
        final CompartimentId compartimentId = CompartimentId.ere("IdAssure", CompartimentType.C1);
        contratComplet.setCompteGeneralesERE(compteGeneralesERE);
        Map<CompartimentId, CompteGeneralesERE> compteGeneralesEreParCompartiment = new HashMap<>() {{
            put(compartimentId, compteGeneralesERE);
        }};
        final BasicEncours basicEncours = new BasicEncours();
        basicEncours.setHasVLVersement(true);
        Supplier<Encours> supplier = () -> basicEncours;
        Memoizer<Encours> encours = new Memoizer<>(supplier);

        contratComplet.setEncours(encours);
        contratComplet.setCompteGeneralesEreParCompartiment(compteGeneralesEreParCompartiment);
        contratComplet.setContratGeneral(
                ContratGeneral.builder()
                        .optContratEpargne(optContratEpargne)
                        .build()
        );

        PersonnePhysiqueConsult personnePhysiqueConsult = new PersonnePhysiqueConsult();
        personnePhysiqueConsult.setAge(30);
        personnePhysiqueConsult.setLimiteAgeVIF(47);
        // When
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class))).thenReturn(personnePhysiqueConsult);
        final boolean vifPossible = contratVifHelper.isVifPossible(contratComplet, compartimentId);
        // Then
        Assert.assertTrue(vifPossible);
        Assert.assertEquals(basicEncours.hasVLVersement(), vifPossible);
    }




    private ContratComplet buildContraComplet(CodeSiloType codeSiloType) {
        ContratRente contratRente = ContratRente.builder()
            .affichageType(AffichageType.NORMAL)
            .codeSilo( codeSiloType )
            .build();
        return new ContratComplet(contratRente);
    }



}