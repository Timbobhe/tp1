package fr.ag2rlamondiale.erb.contrat.utils;

import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;


@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class ContratMDPROHelperTest {

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    @InjectMocks
    ContratMDPROHelper contratMDPROHelper;

    @Test
    public void isC2Pacte() {
        final String typeContrat= "RA09";
        final String numGenContrat = "B01";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean c2Pacte = contratMDPROHelper.isC2Pacte(contratRente);
        assertTrue(c2Pacte);
    }

    @Test
    public void isC3Pacte() {
        final String typeContrat= "RA09";
        final String numGenContrat = "C01";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean c3Pacte = contratMDPROHelper.isC3Pacte(contratRente);
        assertTrue(c3Pacte);
    }

    @Test
    public void isC1PacteNewContratMadelin() {
        final List<String> availableNmmGen = Arrays.asList("A21", "A22", "A31", "A32");
        final ContratRente contratRente = ContratRente.builder()
                .numGenContrat(availableNmmGen.get((int) (Math.random() * availableNmmGen.size())))
                .build();
        final boolean c1PacteNewContratMadelin = contratMDPROHelper.isC1PacteNewContratMadelin(contratRente);
        assertTrue(c1PacteNewContratMadelin);
    }

    @Test
    public void isContratNonPacte() {
        final String typeContrat= "RA09";
        final String numGenContrat = "A09";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);

        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();

        final boolean contratNonPacte = contratMDPROHelper.isContratNonPacte(contratRente);
        assertTrue(contratNonPacte);
    }

    @Test
    public void isContratAutoriseNonPacteArbitrage() {
        final String typeContrat= "RA09";
        final String numGenContrat = "A09";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratAutoriseNonPacteArbitrage = contratMDPROHelper.isContratAutoriseNonPacteArbitrage(contratRente);
        assertTrue(contratAutoriseNonPacteArbitrage);
    }

    @Test
    public void isContratAutoriseNonPacte() {
        final String typeContrat= "RA09";
        final String numGenContrat = "A09";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratAutoriseNonPacte = contratMDPROHelper.isContratAutoriseNonPacte(contratRente);
        assertTrue(contratAutoriseNonPacte);
    }

    @Test
    public void isContratAutorise() {
        final String typeContrat= "RA09";
        final String numGenContrat = "V01";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratAutorise = contratMDPROHelper.isContratAutorise(contratRente);
        assertTrue(contratAutorise);
    }

    @Test
    public void isContratAutorise_Contrat_Without_Info() {
        final String typeContrat= "RA09";
        final String numGenContrat = "V01";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(anyString())).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .build();
        final boolean contratAutorise = contratMDPROHelper.isContratAutorise(contratRente);
        assertFalse(contratAutorise);
    }

    @Test
    public void isContratAutorise_Product_Not_Found() {
        final String typeContrat= "RA09";
        final String numGenContrat = "V01";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(null);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratAutorise = contratMDPROHelper.isContratAutorise(contratRente);
        assertFalse(contratAutorise);
    }

    @Test
    public void isContratPacte() {
        final String typeContrat= "RA09";
        final String numGenContrat = "B21";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratPacte = contratMDPROHelper.isContratPacte(contratRente);
        assertTrue(contratPacte);
    }

    @Test
    public void isContratDeductible() {
        final String typeContrat= "RA09";
        final String numGenContrat = "B21";
        final ProduitJson produitJson = new ProduitJson();
        produitJson.setTypeContrat(typeContrat);
        produitJson.setNumeroGeneration(numGenContrat);
        produitJson.setDeductible(true);
        when(paramConsoleFacade.findProduitMdpro(typeContrat + numGenContrat)).thenReturn(produitJson);
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .build();
        final boolean contratDeductible = contratMDPROHelper.isContratDeductible(contratRente);
        assertTrue(contratDeductible);
    }


    @Test
    public void isAutreContrat() {
        final String typeContrat= "RA09";
        final String numGenContrat = "B21";
        final ContratRente contratRente = ContratRente.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .codeSilo(CodeSiloType.MDP)
                .build();
        final boolean autreContrat = contratMDPROHelper.isAutreContrat(contratRente);
        assertTrue(autreContrat);
    }

    @Test
    public void isContainOldNumGenContratMadelin() {
        final ContratRente contratRente1 = ContratRente.builder()
                .typeContrat("RA09")
                .numGenContrat("V01")
                .build();
        final boolean containOldNumGenContratMadelin1 = contratMDPROHelper.isContainOldNumGenContratMadelin(contratRente1);
        Assert.assertTrue(containOldNumGenContratMadelin1);

        final ContratRente contratRente2 = ContratRente.builder()
                .typeContrat("RA09")
                .numGenContrat("V10")
                .build();
        final boolean containOldNumGenContratMadelin2 = contratMDPROHelper.isContainOldNumGenContratMadelin(contratRente2);
        Assert.assertFalse(containOldNumGenContratMadelin2);
    }
}