package fr.ag2rlamondiale.erb.contrat.mapping;

import fr.ag2rlamondiale.erb.contrat.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.erb.contrat.domain.ContratComplet;
import fr.ag2rlamondiale.erb.contrat.domain.ContratRente;
import fr.ag2rlamondiale.trm.dto.contrat.ContratParcoursDto;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
class ContratParcoursMapperTest {

    private ContratParcoursMapperImpl sut = new ContratParcoursMapperImpl();

    @Mock
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Test
    void testMapContratRente() {
        final ContratRente contratRente = ContratRente.builder()
                .id("TestU")
                .descriptionFront("description")
                .raisonSocialeFront("raisonSociale")
                .build();
        final ContratParcoursDto contratParcoursDto = sut.map(contratRente);
        Assertions.assertEquals(contratRente.getId(), contratParcoursDto.getNomContrat());
        Assertions.assertEquals(contratRente.getDescriptionFront(), contratParcoursDto.getDescription());
        Assertions.assertEquals(contratRente.getRaisonSocialeFront(), contratParcoursDto.getRaisonSociale());
    }

    @Test
    void testMapContratComplet() {
        final ContratRente contratRente = ContratRente.builder()
                .id("TestU")
                .descriptionFront("description")
                .raisonSocialeFront("raisonSociale")
                .build();
        final ContratComplet contratComplet = buildContraComplet(contratRente);
        final ContratParcoursDto contratParcoursDto = sut.map(contratComplet);
        Assertions.assertEquals(contratComplet.getContratHeader().getId(), contratParcoursDto.getNomContrat());
        Assertions.assertEquals(contratComplet.getContratHeader().getDescriptionFront(), contratParcoursDto.getDescription());
        Assertions.assertEquals(contratComplet.getContratHeader().getRaisonSocialeFront(), contratParcoursDto.getRaisonSociale());

    }

    /*@Test
    void testMapContratRenteSansEncours() {
        final ContratRente contratRente = ContratRente.builder()
                .id("TestU")
                .descriptionFront("description")
                .raisonSocialeFront("raisonSociale")
                .build();

        Mockito.when(calculerEncoursContratFacade.getEncoursDto(contratRente)).thenCallRealMethod();
        final ContratParcoursDto contratParcoursDto = sut.map(contratRente, false);
        Assertions.assertEquals(contratRente.getId(), contratParcoursDto.getNomContrat());
        Assertions.assertEquals(contratRente.getDescriptionFront(), contratParcoursDto.getDescription());
        Assertions.assertEquals(contratRente.getRaisonSocialeFront(), contratParcoursDto.getRaisonSociale());
        Mockito.verify(calculerEncoursContratFacade, Mockito.never()).getEncoursDto(contratRente);
    }*/

    private ContratComplet buildContraComplet(ContratRente contratRente) {
        return new ContratComplet(contratRente);
    }


}