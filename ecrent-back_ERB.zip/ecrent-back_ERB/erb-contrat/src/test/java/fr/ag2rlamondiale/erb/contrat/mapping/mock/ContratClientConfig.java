package fr.ag2rlamondiale.erb.contrat.mapping.mock;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

import static fr.ag2rlamondiale.trm.utils.Sets.set;

@Builder(toBuilder = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContratClientConfig {
    private String personId;
    private Set<ContratId> contratsId;
    private Set<String> assuresId;

    public static ContratClientConfig P3995582 = ContratClientConfig.builder().personId("P3995582")
            .contratsId(set(
                    new ContratId(CodeSiloType.ERE, "RG151095348", null, null, null),
                    new ContratId(CodeSiloType.ERE, "RG151095348", null, null, null),
                    new ContratId(CodeSiloType.ERE, "RG152180972", null, null, null)
            ))
            .assuresId(set("368434", "1076342", "1363476", "1363477", "1363478", "1363479")).build();

    public static ContratClientConfig P5210012 = ContratClientConfig.builder().personId("P5210012")
            .contratsId(set(
                    new ContratId(CodeSiloType.ERE, "RG152223361", null,  null, null)
            ))
            .assuresId(set("1398838", "1398839", "1398840", "1398841", "1398842")).build();

    /**
     * P5159994 = pas les vraies donn&eacute;es => modifier pour le test petit collectif
     */
    public static ContratClientConfig P4565355 = ContratClientConfig.builder().personId("P4565355")
            .contratsId(set(
                    new ContratId(CodeSiloType.ERE, "RG151504882", null, null, null),
                    new ContratId(CodeSiloType.ERE, "RG152215019", null, null, null),
                    new ContratId(CodeSiloType.ERE, "RG152215407", null, null, null)
            ))
            .assuresId(set("1117088", "1398102", "1398103", "1398104", "1398105", "1398106", "1398107", "1398108", "1398109")).build();


    public static ContratClientConfig P1022071 = ContratClientConfig.builder().personId("P1022071")
            .contratsId(set(
                    new ContratId(CodeSiloType.MDP, "RA130391280000", null, null, null),
                    new ContratId(CodeSiloType.MDP, "RA149736087000", null, null, null)
            ))
            .build();

    public static ContratClientConfig P0770514 = ContratClientConfig.builder().personId("P0770514")
            .contratsId(set(
                    new ContratId(CodeSiloType.MDP, "RF064045026174", null, null, null),
                    new ContratId(CodeSiloType.MDP, "RA228287172000", null, null, null)
            ))
            .build();
}
