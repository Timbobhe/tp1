package fr.ag2rlamondiale.erb.contrat.business.impl;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.erb.contrat.dto.EligibiliteRenteRequest;
import fr.ag2rlamondiale.erb.contrat.dto.InfoEligibiliteRente;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CalculerEligibiliteImplTestIT {

    @Autowired
    CalculerEligibiliteFacadeImpl facadeImpl;

    @Before
    public void setUp() {
    }

    @Test
    public void should_return_option_rente_contrat() throws TechnicalException, ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Date date = formatter.parse("20-10-1920");
        EligibiliteRenteRequest in = EligibiliteRenteRequest.builder().nom("DURAND").prenom("LOUIS").dateNaissance(date).idPersonne("P2000472").build();
        InfoEligibiliteRente res = facadeImpl.calculEligibiliteRente(in);
        assertNotNull(res);
        assertEquals("TRUE", res.getAccesAutorise());
        assertEquals("EV000167034000", res.getContrats().get(0).getIdContrat());
    }

}

