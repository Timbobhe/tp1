package fr.ag2rlamondiale.erb.contrat.mapping.mock;

import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import lombok.extern.slf4j.Slf4j;
import org.junit.Ignore;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@Slf4j
public class ContratsClientMockTest {

    @Test
    public void test_mock() throws Exception {
        ContratsClientMock mock = new ContratsClientMock(ContratClientConfig.P5210012);
        final List<ContratHeaderDto> contratHeaderDtos = mock.rechercherContratsRetraiteSupp(new RechercherContratsDto());

        log.info("Contrats");
        for (ContratHeaderDto contratHeaderDto : contratHeaderDtos) {
            log.info("{}", contratHeaderDto);
        }
        assertEquals(1, contratHeaderDtos.size());

        log.info("ContratGeneral");
        for (ContratId contratId : mock.getConfig().getContratsId()) {
            final ContratGeneral contratGeneral = mock.consulterContratGenerales(new ConsulterContratGeneralesDto(contratId));
            log.info("{} => {}", contratId, contratGeneral);
            assertNotNull(contratGeneral);
        }

        log.info("ContratGeneral");
        for (String assureId : mock.getConfig().getAssuresId()) {
            final CompteGeneralesERE cge = mock.consulterCompteGeneralesERE(new ConsulterCompteGeneralesEREDto(assureId));
            log.info("{} => {}", assureId, cge);
            assertNotNull(cge);
        }
    }
}
