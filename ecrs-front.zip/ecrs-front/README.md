# appli-front Angular 6+

## Installation

1. Installer Git Bash
1. Aller sur l'URL : [http://amidev/wiki/index.php/Support_METIS_ANGULAR#Installation](http://amidev/wiki/index.php/Support_METIS_ANGULAR#Installation)
1. Dans VS Code, ouvrir le dossier C:\Users\<user>\git\ecrs-front
1. En bas à droite, cliquer sur Install all
1. Supprimer la lecture seule sur le dossier C:\Users\<user>\git\ecrs-front
1. Appuyer sur Ctrl+ù
1. Cliquer sur la corbeille
1. Appuyer sur Ctrl+ù
1. Taper npm install

## Développement

### Composants partagés

- [ButtonCTA](src/app/shared/components/button-cta/README.md) : Bouton CTA générique

### node-sass

Récuperer la version compilée directement depuis : https://github.com/sass/node-sass/releases/tag/v4.12.0  
_Pas la peine d'essayer de compiler .Net framework 2/VS 2005, et .... qui ne marche pas._

- Pour node x64 (v10.18.1)
- https://github.com/sass/node-sass/releases/download/v4.12.0/win32-x64-67_binding.node
- copier dans "./node_modules/node-sass/vendor/win32-x64-64/binding.node"

- ou Dezziper l'archive `./node-sass.zip` présente à la racine du projet dans les `./node_modules`

### Snippets disponibles

Dans le fichier `.vscode/redux.code-snippets` les snippets suivantes sont disponibles :

- `red` : Construit un nouveau Reducer
- `act` :  Construit une nouvelle Action
- `ared` : Construit un nouveau Reducer s'appuyant sur les ApiAction [redux-api-ng](https://git-prd.server.lan/A1282/redux-api-ng)
- `aact` : Construit une nouvelle Action s'appuyant sur les ApiAction [redux-api-ng](https://git-prd.server.lan/A1282/redux-api-ng)

Pour créer le *Body* des snippets, à partir d'un fichier *modèle* exécuter :

```cmd
node .vscode\extract_body_snippet.js CHEMIN_VERS_LE_FICHIER
```

Le contenu est copié dans le presse-papier, à coller dans le body de la snippet.

## Librairie Angular

https://www.willtaylor.blog/complete-guide-to-angular-libraries/

## Transverse-metier-ng

En mode DEV :

```cmd
cd ecrs-front
npm run build_lib_trm

cd dist/transverse-metier-ng
npm link

cd ecrs-front
npm link @ag2rlamondiale/transverse-metier-ng
```
### Règles à respecter (pour ne pas perdre du temps)

1. Tout ce qui est injectable (en argument des constructeurs) ne doit pas être importés avec un index.ts mais explicitement.

import { APP_CONFIG, AppConfig } from '../../../../models'; <- KO
import { APP_CONFIG, AppConfig } from '../../../../models/app.model'; <- OK


2. Pareil, tout ce qui "déclarer" dans les NgModule doit être importé explicitement 
