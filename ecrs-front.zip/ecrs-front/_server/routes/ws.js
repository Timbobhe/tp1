var express = require('express');
var router = express.Router();

const ROOT_DIRNAME = 'C:/ITF/workspaces/js/A1573/ecrs-front/_server/routes/data-ws';
const HEADERS = {'Content-Type': 'text/xml'}

router.post('/GestPersPhys_2/RechercherPPReduit_3', function (req, res) {
  res.sendFile('GestPersPhys_2/RechercherPPReduit_3.xml', {root: ROOT_DIRNAME, headers: HEADERS});
});

router.post('/GestPersPhys_3/ConsulterPersPhysClient_3', function (req, res) {
  res.sendFile('GestPersPhys_3/ConsulterPersPhysClient_3.xml', {root: ROOT_DIRNAME, headers: HEADERS});
});

router.get('/GestPersPhys_2/RechercherPPReduit_3', function (req, res) {
  res.sendFile('GestPersPhys_2/RechercherPPReduit_3.xml', {root: ROOT_DIRNAME, headers: HEADERS});
});

router.get('/GestPersPhys_3/ConsulterPersPhysClient_3', function (req, res) {
  res.sendFile('GestPersPhys_3/ConsulterPersPhysClient_3.xml', {root: ROOT_DIRNAME, headers: HEADERS});
});

module.exports = router;
