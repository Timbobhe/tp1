'use strict';

exports.infoClient = {
  "numeroPersonne": "P0000000",
  "infoPersonne": {
    "nom": "mocknom",
    "prenom": "mockprenom",
    "civilite": "M"
  }
}

