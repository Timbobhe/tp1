const routes = require('./routes.json');
const JDD = 'cobnj6';
const responses = require('./data/response.' + JDD + '.json');
const jahiaData = require('./data/jahia-data.json');

const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router(Object.assign({}, responses, {"jahia_data": jahiaData}));
const middlewares = jsonServer.defaults();
const ws = require('./ws');
const cas = require('./cas');

server.use(middlewares);
server.use('/ws/esb/service', ws);
server.use('/cas', cas);
server.use(jsonServer.rewriter(routes)); // Add this before server.use(router)
server.use(router);
server.listen(3085, () => {
  console.log('JSON Server is running on http://localhost:3085 avec le JDD FRONT = ' + JDD)
});
