# ECRS - FRONT - CHANGES

## v7.2.0 - 15/09/2021

- Refonte Données personnelles
- Simplification sur la gestion des Even à la connexion : distinction POPIN, INDISPO, OBJECTIF
