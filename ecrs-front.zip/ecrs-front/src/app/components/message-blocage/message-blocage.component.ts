import { Component, OnDestroy, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Message } from 'primeng/api';

@Component({
  selector: 'app-message-blocage',
  templateUrl: './message-blocage.component.html',
  styleUrls: ['./message-blocage.component.scss']
})
export class MessageBlocageComponent implements OnInit, OnDestroy {

  msgs: Message[] = [];
  subscriptions = [];

  constructor(private readonly store: Store<GlobalState>) { }

  ngOnInit() {
    this.subscriptions.push(this.store.select('messageBlocage').subscribe(messageBlocage => {
      this.msgs = [];
      if (messageBlocage && messageBlocage.message) {
        this.msgs.push({
          severity: 'error',
          detail: messageBlocage.message
        });
      }
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }

  isMessagesBlocagesEmpty(): boolean {
    return this.msgs.length === 0;
  }
}
