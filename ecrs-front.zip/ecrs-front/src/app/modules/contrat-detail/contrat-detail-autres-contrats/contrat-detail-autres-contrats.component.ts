import { DeviceSize, ResponsiveService, tracking } from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { Component, ElementRef, Input, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { DETAILS_CONTRAT } from '@app/consts/fonctionnalites.const';
import { ContratParcours } from '@app/models/client/contrat.model';
import { Menu } from '@app/models/client/menu.model';
import { FonctionnaliteRedirectService } from '@app/modules/ecrs-common/services/fonctionnalite-redirect.service';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-contrat-detail-autres-contrats',
  templateUrl: './contrat-detail-autres-contrats.component.html',
  styleUrls: ['./contrat-detail-autres-contrats.component.scss'],
})
export class ContratDetailAutresContratsComponent implements OnInit {
  @Input() contrats: ContratParcours[];

  onResize$: Observable<DeviceSize>;
  menu$: Observable<Menu>;
  carouselResponsiveOptions: { numScroll: number; numVisible: number; breakpoint: string }[];
  notMobile = window.innerWidth >= 700


  ngOnInit() {
    this.carouselResponsiveOptions = [
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1
      }
    ];
  }

  constructor(private readonly responsive: ResponsiveService, private readonly redirectService: FonctionnaliteRedirectService,
    private readonly store: Store<GlobalState>) {
    this.onResize$ = this.responsive.onResize$;
    this.menu$ = this.redirectService.menu$;
  }


  redirectToDetailsDeLencours(contrat: ContratParcours, menu: Menu) {
    if (contrat.affichageType === 'NORMAL' && !contrat.encours.encoursEnErreur) {
      this.store.dispatch(tracking(Categorie.contratDetail, TypeOriginAction.autresContrats, 'Voir autres Contrats'));
      this.redirectService.navigateToWithContratId(DETAILS_CONTRAT, menu, contrat);
      window.scroll({
        top: 0,
        left: 0,
        behavior: 'smooth'
      });
    }
  }
}
