import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { ContratDetailGestionFinancierePacteModel } from '@app/modules/contrat-detail/contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte.model';
import { DeviceSize } from '@ag2rlamondiale/transverse-metier-ng';

@Component({
  selector: 'app-contrat-detail-compartiments',
  templateUrl: './contrat-detail-compartiments.component.html',
  styleUrls: ['./contrat-detail-compartiments.component.scss']
})
export class ContratDetailCompartimentsComponent implements OnInit {
  @Input() contrat: ContratDetail;
  @Input() model: ContratDetailGestionFinancierePacteModel;
  @Input() device: DeviceSize;
  isSmallTablet = window.innerWidth >= 700 && window.innerWidth <= 992;

  constructor() { }

  ngOnInit(): void {
  }

}
