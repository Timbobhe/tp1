import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { ContratDetailGestionFinancierePacteModel } from '@app/modules/contrat-detail/contrat-detail-main/contrat-detail-gestion-financiere-pacte/contrat-detail-gestion-financiere-pacte.model';
import { DeviceSize, ThemeService } from '@ag2rlamondiale/transverse-metier-ng';
import { Observable, of } from 'rxjs';
import {
  initDonutOptions,
  LegendDonut,
  TitleDonut,
  TooltipDonut
} from '@app/modules/ecrs-common/components/ecrs-donut/ecrs-donut.component';
import { delay } from 'rxjs/operators';

@Component({
  selector: 'app-contrat-detail-gestion-financiere-pacte-donut',
  templateUrl: './contrat-detail-gestion-financiere-pacte-donut.component.html',
  styleUrls: ['./contrat-detail-gestion-financiere-pacte-donut.component.scss']
})
export class ContratDetailGestionFinancierePacteDonutComponent implements OnInit {

  @Input() contrat: ContratDetail;
  @Input() model: ContratDetailGestionFinancierePacteModel;
  @Input() device: DeviceSize;

  montantLength = 0;
  dataDonut$: Observable<any>;

  titleDonut: TitleDonut = {display: false};
  legendDonut: LegendDonut = {display: false};
  toolTipDonut: TooltipDonut = {enabled: false};


  options = initDonutOptions({
    title: this.titleDonut,
    legend: this.legendDonut,
    tooltip: this.toolTipDonut,
    isHalfDonut: false,
    animation: false,
  });


  constructor(
    private readonly themeService: ThemeService) {
  }

  ngOnInit(): void {
    this.montantLength = this.contrat.encours.montantEncours ? this.contrat.encours.montantEncours.toString().length : 0;
    const donutTheme = this.themeService.theme.palette;
    const firstItem = donutTheme.grey['400'];
    const secondItem = donutTheme.secondary.light;
    const thirdItem = donutTheme.info3.active.main;
    const noItem = '#DDDDD4';
    this.dataDonut$ = of({
      datasets: [
        {
          label: 'Dataset',
          data:
            this.contrat.encours.montantEncours > 0
              ? [this.model.versementsVolontaires.pourcentage, this.model.epargneSalarialeC2.pourcentage, this.model.versementsObligatoires.pourcentage]
              : [100],
          backgroundColor: this.contrat.encours.montantEncours ? [firstItem, secondItem, thirdItem] : [noItem],
          borderWidth: 0,
        },
      ],
    }).pipe(
      delay(50)
    );
  }
}
