import { tracking } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { OperationDetailContrat } from '@app/models/client/details-contrats.models';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

class GroupeOperation {
  nomGroupe: string;
  operations: OperationDetailContrat[];

  constructor(nomGroupe: string) {
    this.nomGroupe = nomGroupe;
    this.operations = [];
  }

  add(operation: OperationDetailContrat) {
    this.operations.push(operation);
    return this;
  }
}

@Component({
  selector: 'app-list-details-operations',
  templateUrl: './list-details-operations.component.html',
  styleUrls: ['./list-details-operations.component.scss']
})
export class ListDetailsOperationsComponent implements OnChanges {
  @Input() listOperations: OperationDetailContrat[];
  @Input() hideMoreList: boolean;
  @Output() operationToDetail = new EventEmitter<OperationDetailContrat>();

  indexPartOne: number;
  startFrom: number;
  newPart: OperationDetailContrat[] = [];
  partOne: GroupeOperation[] = [];

  hideOperations = true;
  displayMoreOp = true;

  withoutLink = false;
  otherPart: GroupeOperation[] = [];
  constructor(private readonly store: Store<GlobalState>) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.listOperations) {
      this.newPart = [];
      this.displayMoreOp = this.hideOperations = this.hideMoreList;

      const partToDisplay = this.deviseListBySixElement(this.listOperations);
      this.partOne = this.groupedListByDate(partToDisplay);
    }
    this.withoutLink = this.listOperations && this.listOperations.length <= 6;
  }

  // fonction pour regrouper les opérations par date MM/YYYY
  groupedListByDate(listToGrouped): GroupeOperation[] {
    const grouped = listToGrouped.reduce(function (r, a) {
      r[a.groupByDateOperation] = r[a.groupByDateOperation] || new GroupeOperation(a.groupByDateOperation);
      r[a.groupByDateOperation].add(a);
      return r;
    }, []);
    return Object.values(grouped);
  }

  // fonction pour  récupérer les 6 premières opérations de la liste
  deviseListBySixElement(listop: OperationDetailContrat[]) {
    let i = 0;
    let nb = 0;
    const partToDisplay = [];

    while (i < listop.length && nb < 6) {
      partToDisplay.push(listop[i]);
      i++;
      nb++;
    }

    this.indexPartOne = i;
    this.startFrom = i;
    return partToDisplay;
  }

  // fonction pour afficher plus des opérations lors du clic sur afficher plus
  displayMoreOperation() {
    let i = this.startFrom;
    let nb = 0;
    while (i < this.listOperations.length && nb < 6) {
      this.newPart.push(this.listOperations[i]);
      i++;
      nb++;
    }
    this.otherPart = [];
    this.otherPart = this.groupedListByDate(this.newPart);
    this.startFrom = i;
    if (i === this.listOperations.length) {
      this.displayMoreOp = false;
      this.newPart = [];
    }
    this.hideOperations = false;
  }

  hideMore() {
    this.newPart = [];
    this.otherPart = [];
    this.startFrom = this.indexPartOne;
    this.hideOperations = true;
    this.displayMoreOp = true;
  }

  showDetails(op: OperationDetailContrat) {
    this.operationToDetail.emit(op);
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.detailOperation, 'detail_operation'));
  }
}
