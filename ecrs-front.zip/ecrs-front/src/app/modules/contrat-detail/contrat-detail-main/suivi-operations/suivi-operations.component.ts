import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { GetHistoriqueOperationsNonPacte, GetHistoriqueOperationsPacte } from '@app/actions/details-contrats.action';
import { OperationDetailContrat } from '@app/models/client/details-contrats.models';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { selectContratDetailHistoriqueOperations } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { of, Subscription } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-suivi-operations',
  templateUrl: './suivi-operations.component.html',
  styleUrls: ['./suivi-operations.component.scss'],
})
export class SuiviOperationsComponent implements OnInit, OnDestroy {
  @Input() contratDetail: ContratDetail;
  operations: OperationDetailContrat[] = [];
  operationsToShow: OperationDetailContrat[] = [];

  showDetailsOperation = false;

  operationToDetail: OperationDetailContrat;

  subscriptions: Subscription[] = [];
  hideMoreList = false;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly reduxApi: ReduxApiService,
    private readonly route: ActivatedRoute
  ) {
  }

  ngOnInit() {
    this.subscriptions.push(
      of(this.contratDetail)
        .pipe(
          switchMap((contrat) => {
            if (contrat.pacte && 'ERE' === contrat.codeSilo) {
              return this.reduxApi.execute(new GetHistoriqueOperationsPacte(contrat));
            } else {
              return this.reduxApi.execute(new GetHistoriqueOperationsNonPacte(contrat));
            }
          }),
          switchMap(() => this.store.select(selectContratDetailHistoriqueOperations)),
          filter((res) => !!res.fetched),
        )
        .subscribe((historique) => {
          this.operations = historique.data;
          this.selectedChoice('ALL');
        })
    );
  }

  selectedChoice(event: string) {
    this.operationsToShow = [];
    this.hideMoreList = true;

    if (this.operations) {
      this.operationsToShow = event === 'ALL' ? this.operations : this.operations.filter((op) => event.includes(op.contrat.compartimentType));
    }
  }

  setOperationToDetail(op: OperationDetailContrat) {
    this.operationToDetail = op;
    this.showDetailsOperation = true;
  }

  showPopUp(event: boolean) {
    this.showDetailsOperation = event;
  }

  hideDetailsOperation() {
    this.showDetailsOperation = false;
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
