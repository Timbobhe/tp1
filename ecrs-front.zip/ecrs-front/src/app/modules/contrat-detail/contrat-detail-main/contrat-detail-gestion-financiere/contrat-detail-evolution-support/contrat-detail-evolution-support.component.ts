import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import {
  DownloadDocumentValeursLiquidatives,
  GetDocumentsEvolutionSupport,
  GetEvolutionSupport
} from '@app/actions/details-contrats.action';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { CurrencyPipe } from '@angular/common';
import { ContratId } from '@ag2rlamondiale/transverse-metier-ng';
import { Fiche } from '@app/models/client/documents.model';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { DocumentService } from '@app/modules/ecrs-common/services/document.service';
import {
  DownloadValeursLiquidativesDto,
  EvolutionSupportDto,
  Periodicites,
  ValeurEvolution
} from '@app/models/client/details-contrats.models';
import { EvolutionData } from '@app/modules/ecrs-common/components/evolution/evolution.component';

@Component({
  selector: 'app-contrat-detail-evolution-support',
  templateUrl: './contrat-detail-evolution-support.component.html',
  styleUrls: ['./contrat-detail-evolution-support.component.scss']
})
export class ContratDetailEvolutionSupportComponent implements OnInit {
  @Input()
  codeIsin: string;
  @Input()
  contratId: ContratId;

  selectedVue: { vueOption: { label: string; value: string }; evolution: ValeurEvolution[] };

  @Output()
  closePopIn = new EventEmitter();

  dataBarChart$: Observable<EvolutionData>;

  evolutionSupport: EvolutionSupportDto;

  subscriptions: Subscription[] = [];

  fiches: Fiche[] = [];


  @Output()
  onVueSelected: EventEmitter<any> = new EventEmitter<any>();

  constructor(private readonly store: Store<GlobalState>,
              public currencyPipe: CurrencyPipe,
              public downloadService: DownloadService,
              public documentService: DocumentService,
              private readonly reduxApiService: ReduxApiService) {
  }

  ngOnInit() {
    this.dataBarChart$ = this.reduxApiService.execute(new GetEvolutionSupport(this.codeIsin)).pipe(
      map((data) => {
        this.evolutionSupport = data;

        const res: EvolutionData = {
          devise: data.devise,
          options: []
        };

        this.evolutionSupport.evolutions.forEach(value => {
          res.options.push({
            vueOption: Periodicites[value.periodicite],
            evolution: value.valeursEvolution
          });
        });
        this.selectedVue = res.options[0];
        this.loadDocument(this.evolutionSupport.codeIsin);
        return res;
      })
    );

  }

  loadDocument(codeIsin: string) {
    this.subscriptions.push(
      this.reduxApiService.execute(new GetDocumentsEvolutionSupport(this.contratId, codeIsin)).pipe(
        map(value => this.fiches = value)
      ).subscribe()
    );
  }

  downloadDocument(fiche: Fiche) {
    this.downloadService.downloadDocument({
      codeDocument: fiche.codeTypeDocument,
      contratId: this.contratId,
      lienFiche: fiche.lien
    });
  }

  downloadValeursLiquidatives() {
    const downloadValeursLiquidatives: DownloadValeursLiquidativesDto = {
      codeIsin: this.evolutionSupport.codeIsin,
      periodicite: this.selectedVue.vueOption.value
    };

    const action = new DownloadDocumentValeursLiquidatives(downloadValeursLiquidatives);
    action.payload.onSuccess = (body, headers) => {
      const contentDisposition = headers.get('content-disposition');

      const filename = contentDisposition
        .split(';')[1]
        .split('filename')[1]
        .split('=')[1]
        .replace(/"/g, '')
        .trim();
      this.fileContentDownloadByType(body, filename, true);
    };
    this.store.dispatch(action);
  }

  fileContentDownloadByType(fileContent, fileName = 'fichier.pdf', download = false) {
    const type = 'application/pdf';
    let blob;
    if (typeof fileContent === 'string') {
      const byteCharacters = atob(fileContent);

      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const byteArray = new Uint8Array(byteNumbers);

      blob = new Blob([byteArray], {type});
    } else {
      blob = new Blob([fileContent], {type});
    }

    // IE doesn't allow using a blob object directly as link href
    // instead it is necessary to use msSaveOrOpenBlob
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, fileName);
      return;
    }

    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.target = '_blank';
    link.href = url;
    if (download) {
      link.setAttribute('download', fileName);
    }
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  }

  updateVueSelected(event: { vueOption: { label: string; value: string }; evolution: ValeurEvolution[] }) {
    this.selectedVue = event;
  }
}

