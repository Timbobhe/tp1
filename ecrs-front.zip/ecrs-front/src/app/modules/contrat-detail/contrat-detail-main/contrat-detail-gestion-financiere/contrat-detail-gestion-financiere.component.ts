import { Component, Input, OnInit } from '@angular/core';
import { ContratDetail, GestionFinanciereDetailContratDto } from '@app/models/contrat-detail.model';
import { Arbitrages, Versements } from '@app/consts/fonctionnalites.const';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import {
  ContratId,
  DeviceSize,
  ResponsiveService,
  ThemeService,
  toQueryParamsContratIdRouter,
  tracking
} from '@ag2rlamondiale/transverse-metier-ng';
import { Observable } from 'rxjs';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { SelectItem } from 'primeng/api';
import { GetContratDetailGestionFinanciere } from '@app/actions/details-contrats.action';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-contrat-detail-gestion-financiere',
  templateUrl: './contrat-detail-gestion-financiere.component.html',
  styleUrls: ['./contrat-detail-gestion-financiere.component.scss']
})
export class ContratDetailGestionFinanciereComponent implements OnInit {
  @Input() contrat: ContratDetail;

  selectedVue: 'chart' | 'list' = 'chart';
  vueOptions: SelectItem[];
  onResize$: Observable<DeviceSize>;
  dataDonut$: Observable<any>;
  gestFin = new GestionFinanciereDetailContratDto();
  gestionFinanciereDonut = new GestionFinanciereDetailContratDto();
  montantLength = 0;
  isSmallTablet = window.innerWidth >= 700 && window.innerWidth <= 992;

  fonctionnalites = {Arbitrages, Versements};
  constructor(
    private readonly router: Router,
    private readonly route: ActivatedRoute,
    private readonly store: Store<GlobalState>,
    private readonly reduxApiService: ReduxApiService,
    private readonly themeService: ThemeService,
    private readonly responsive: ResponsiveService
  ) {
    this.onResize$ = this.responsive.onResize$;
    this.vueOptions = [];
    this.vueOptions.push({label: 'Vue graphique', value: 'chart'});
    this.vueOptions.push({label: 'Vue liste', value: 'list'});
  }

  ngOnInit() {
    this.dataDonut$ = this.reduxApiService.execute(new GetContratDetailGestionFinanciere({...this.contrat} as ContratId)).pipe(
      map((data) => {
        this.gestFin = data;
        this.gestionFinanciereDonut.montantEncours = data.montantEncours;
        if (data.supports.length > 4) {
          let repartitionAutresSupports = 0;
          for (let i = 0; i < 3; i++) {
            this.gestionFinanciereDonut.supports.push(data.supports[i]);
          }
          data.supports.forEach((value, index) => {
            if (index > 2) {
              repartitionAutresSupports += value.pourcentageRepartition;
            }
          });
          this.gestionFinanciereDonut.supports.push({
            libelle: 'Autres supports',
            pourcentageRepartition: Math.round(repartitionAutresSupports * 100) / 100,
          });
        } else {
          this.gestionFinanciereDonut.supports = data.supports;
        }

        this.montantLength = this.gestionFinanciereDonut.montantEncours.toString().length;
        const donutTheme = this.themeService.theme.palette;
        const firstItem = donutTheme.grey['500'];
        const secondItem = donutTheme.info1.active.main;
        const thirdItem = donutTheme.info3.active.main;
        const fourthItem = donutTheme.info4.active.main;
        const noItem = '#DDDDD4';

        return {
          datasets: [
            {
              label: 'Dataset',
              data: this.contrat.encours.montantEncours > 0 ?
                this.gestionFinanciereDonut.supports.map((value) => value.pourcentageRepartition)
                : [100],
              backgroundColor: this.contrat.encours.montantEncours > 0 ? [firstItem, secondItem, thirdItem, fourthItem] : [noItem],
              borderWidth: 0,
            },
          ],
        };
      })
    );
  }
  onClick(value: 'chart' | 'list') {
    this.selectedVue = value;
    this.store.dispatch(tracking(Categorie.EREContratRetraite, TypeOriginAction.constitutionContrat, value === 'chart' ? 'Vue graphique' : 'Vue liste'));
  }

  goToVersement(libelleCta: string) {
    this.store.dispatch(tracking(Categorie.contratDetail, TypeOriginAction.clic, libelleCta));
    this.router.navigate(['/versement'], {queryParams: toQueryParamsContratIdRouter(this.contrat)});
  }

  goToArbitrage() {
    this.router.navigate(['../modification-gestion-financiere'], {queryParams: toQueryParamsContratIdRouter(this.contrat)});
  }
}
