import { DeviceSize, ResponsiveService, StepPagination, tracking } from '@ag2rlamondiale/transverse-metier-ng';
import { AfterViewChecked, Component, ElementRef, Input, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { DOCUMENTS, GESTION_COMPTE, GESTION_FINANCIERE, SIMULATEUR_FISCAL_MDP, SIMULATEUR_RENTE_VIF } from '@app/consts/fonctionnalites.const';
import { ContratId } from '@app/models/client/contrat.model';
import { Menu } from '@app/models/client/menu.model';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { FonctionnaliteRedirectService } from '@app/modules/ecrs-common/services/fonctionnalite-redirect.service';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import { DocumentService } from './../../ecrs-common/services/document.service';

class CarousselItem {
nomContrat: string;
fonctionnalities: string[] = [];
type: 'simulateur' | 'documents' | 'savoir-plus';
title: string;
icon: string;
keyText: string;
keyLink: string;
}

@Component({
  selector: 'app-contrat-detail-aside',
  templateUrl: './contrat-detail-aside.component.html',
  styleUrls: ['./contrat-detail-aside.component.scss']
})
export class ContratDetailAsideComponent implements OnInit {
  @Input() contrat: ContratDetail;
  link: string;
  menu$: Observable<Menu>;
  onResize$: Observable<DeviceSize>;
  content: Element;
  index: number;
  width: number;
  currentStepIndex = 0;
  contratId: ContratId;

  carouselItem: CarousselItem [] = [];
  carouselResponsiveOptions: { numScroll: number; numVisible: number; breakpoint: string }[];


  constructor(
    private readonly redirectService: FonctionnaliteRedirectService,
    private readonly download: DownloadService,
    private readonly documentService: DocumentService,
    private readonly responsive: ResponsiveService,
    private readonly store: Store<GlobalState>, ) {
      this.menu$ = this.redirectService.menu$;
      this.onResize$ = this.responsive.onResize$;
    }

  ngOnInit() {
    this.width = 368;
    this.contratId = { ...this.contrat } as ContratId;
    this.carouselItem.push(
      {
        nomContrat: this.contrat.nomContrat,
        fonctionnalities: ['SimulateurRenteVIF'],
        type: 'simulateur',
        title: 'Simulez votre rente future',
        icon: 'ag2r-114-simulators',
        keyText: 'TEXTE_SIMULATEUR',
        keyLink: 'LINK_SIMULATEUR'
      },
      {
        nomContrat: this.contrat.nomContrat,
        fonctionnalities: ['vosDocuments'],
        type: 'documents',
        title: 'Vos documents',
        icon: 'ag2r-022-forms-complete',
        keyText: 'TEXTE_DOCUMENT',
        keyLink: 'LINK_DOCUMENT'
      },
      {
        nomContrat: this.contrat.nomContrat,
        fonctionnalities: ['GestionFinanciere'],
        type: 'savoir-plus',
        title: 'Plus sur votre contrat',
        icon: 'ag2r-003-list',
        keyText: '',
        keyLink: ''
      });
    this.carouselResponsiveOptions = [
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1
      }
    ];
    this.documentService
      .getFichesSupport(this.contrat )
      .pipe(
        take(1),
        map(e => {
          Object.entries(e).forEach(([key, value]) => {
            this.link = value.lien;
          });
        })
      )
      .subscribe();
  }

}
