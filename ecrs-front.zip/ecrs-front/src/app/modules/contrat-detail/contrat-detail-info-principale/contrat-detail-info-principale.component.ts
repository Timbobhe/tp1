import {
  DeviceSize,
  getCssVariable,
  ResponsiveService,
  toQueryParamsContratIdRouter,
  tracking
} from '@ag2rlamondiale/transverse-metier-ng';
import { GlobalState } from '@ag2rlamondiale/transverse-metier-ng/lib/reducers/global.state';
import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Categorie, TypeOriginAction } from '@app/actions/tracking.action';
import { ContratDetail } from '@app/models/contrat-detail.model';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Arbitrages, Versements } from '@app/consts/fonctionnalites.const';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-contrat-detail-info-principale',
  templateUrl: './contrat-detail-info-principale.component.html',
  styleUrls: ['./contrat-detail-info-principale.component.scss'],
})
export class ContratDetailInfoPrincipaleComponent implements OnInit {
  @Input() contrat: ContratDetail;
  backgroundImageDesktop = '--contrat-detail-header-desktop-url';
  backgroundImageMobile = '--contrat-detail-header-mobile-url';
  onResize$: Observable<DeviceSize>;

  carouselItems: { name: string, placeholder: string, value: string } [] = [];

  fonctionnalites = {Arbitrages, Versements};
  carouselResponsiveOptions: { numScroll: number; numVisible: number; breakpoint: string }[];

  constructor(
    private readonly router: Router,
    private readonly store: Store<GlobalState>,
    private readonly responsive: ResponsiveService,
    private readonly datePipe: DatePipe) {
    this.onResize$ = this.responsive.onResize$;
  }


  ngOnInit() {
    this.setCarouselItems(this.contrat);
  }

  getStyle(device: DeviceSize) {
    return {
      'background-image': device.isMobile() ? getCssVariable(this.backgroundImageMobile) : getCssVariable(this.backgroundImageDesktop),
    };
  }

  goToVersement(libelleCta: string) {
    this.store.dispatch(tracking(Categorie.contratDetail, TypeOriginAction.clic, libelleCta));
    this.router.navigate(['/versement'], {queryParams: toQueryParamsContratIdRouter(this.contrat)});
  }

  /**
   * This function will check if
   * - the contract is for ERE or MDP
   * - the contract is Pacte or Not Pacte
   * - if the college attribute length is > 90 or not
   * and set the corresponding items to the carousel.
   * @param contrat the selected contract
   */
  setCarouselItems(contrat: ContratDetail) {
    if (contrat.codeSilo === 'ERE') {
      if (contrat.pacte) {
        this.carouselItems = [];
      } else {
        if (contrat.college.length <= 90) {
          this.carouselItems = [
            {name: 'statut', placeholder: 'Etat du compte', value: contrat.statut},
            {name: 'college', placeholder: 'Catégorie de personnel', value: contrat.college},
            {
              name: 'dateAffiliation',
              placeholder: 'Date d\'affiliation',
              value: this.datePipe.transform(contrat.dateAffiliation, 'dd/MM/yyyy')
            },
          ];
        } else {
          this.carouselItems = [
            {name: 'statut', placeholder: 'Etat du compte', value: contrat.statut},
            {
              name: 'dateAffiliation',
              placeholder: 'Date d\'affiliation',
              value: this.datePipe.transform(contrat.dateAffiliation, 'dd/MM/yyyy')
            },
          ];
        }
      }
    } else if (contrat.codeSilo === 'MDP') {
      this.carouselItems = [
        {name: 'statut', placeholder: 'Etat du compte', value: contrat.statut},
        {
          name: 'dateEffet',
          placeholder: 'Date d\'effet',
          value: this.datePipe.transform(contrat.dateEffet, 'dd/MM/yyyy')
        },
        {
          name: 'dateTerme',
          placeholder: 'Date de terme',
          value: this.datePipe.transform(contrat.dateTerme, 'dd/MM/yyyy')
        },
      ];
    }
    this.carouselResponsiveOptions = [
      {
        breakpoint: '768px',
        numVisible: 2,
        numScroll: 2
      },
      {
        breakpoint: '560px',
        numVisible: 1,
        numScroll: 1
      }
    ];
  }
}
