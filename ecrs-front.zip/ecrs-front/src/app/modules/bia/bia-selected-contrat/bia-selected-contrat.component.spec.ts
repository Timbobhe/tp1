import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { testingModule } from 'test/ecrs-testing';
import { initialStateWithBiaEtape0 } from './../../../../test/store-states.mock';
import { BiaSelectedContratComponent } from './bia-selected-contrat.component';


describe('BiaSelectedContratComponent', () => {
  let component: BiaSelectedContratComponent;
  let fixture: ComponentFixture<BiaSelectedContratComponent>;


  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithBiaEtape0}, {
      declarations: [BiaSelectedContratComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaSelectedContratComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
