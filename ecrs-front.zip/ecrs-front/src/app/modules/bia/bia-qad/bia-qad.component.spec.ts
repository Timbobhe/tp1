/* tslint:disable:no-unused-variable */
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { BiaQadComponent } from './bia-qad.component';



describe('BiaQadComponent', () => {
  let component: BiaQadComponent;
  let fixture: ComponentFixture<BiaQadComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [RouterModule.forRoot([]), StoreModule.forRoot(fromRoot.reducers)],
      declarations: [BiaQadComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaQadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
