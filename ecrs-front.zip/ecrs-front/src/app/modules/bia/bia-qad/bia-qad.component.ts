import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SetSubtitleBia } from '@app/actions/bia.action';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-bia-qad',
  templateUrl: './bia-qad.component.html',
  styleUrls: ['./bia-qad.component.scss']
})
export class BiaQadComponent implements OnInit, OnDestroy {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
    this.store.dispatch(new SetSubtitleBia({id: 'cancelLink', url: '/bulletin-affiliation/mes-choix/choix-gestion-financiere'}));
  }

  terminateQad(codeProposition: string[]) {
    this.router.navigate(['../mes-choix/choix-gestion-financiere'], {relativeTo: this.activeRoute});
  }

  ngOnDestroy(): void {
    this.store.dispatch(new SetSubtitleBia(null));
  }
}
