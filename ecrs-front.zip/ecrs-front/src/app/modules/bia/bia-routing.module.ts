import { pieceIdentiteRoutes } from '@ag2rlamondiale/transverse-metier-ng';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BiaGuard } from '@app/authguards/bia.guard';
import { BiaChoixContratComponent } from '@app/modules/bia/bia-choix-contrat/bia-choix-contrat.component';
import { ChoixGestionFinanciereComponent } from '@app/modules/bia/bia-choix/choix-gestion-financiere/choix-gestion-financiere.component';
import { ConfirmationChoixClientBiaComponent } from '@app/modules/bia/bia-choix/confirmation-choix-client-bia/confirmation-choix-client-bia.component';
import { BiaIdentiteNumComponent } from '@app/modules/bia/bia-identite-num/bia-identite-num.component';
import { BiaQadComponent } from '@app/modules/bia/bia-qad/bia-qad.component';
import { BiaStateGuard } from '@app/modules/bia/guards/bia-state.guard';
import { ContratUniqueGuard } from '@app/modules/bia/guards/contrat-unique.guard';
import { BiaChoixClauseBeneficiaireComponent } from './bia-choix/bia-choix-clause-beneficiaire/bia-choix-clause-beneficiaire.component';
import { BiaChoixComponent } from './bia-choix/bia-choix.component';
import { BiaConfirmationComponent } from './bia-confirmation/bia-confirmation.component';
import { BiaDemandeComponent } from './bia-demande/bia-demande.component';
import { BiaDemsigelecComponent } from './bia-demsigelec/bia-demsigelec.component';
import { BiaMatchAccountComponent } from './bia-match-account/bia-match-account.component';
import { BiaSigelecRedirectComponent } from './bia-sigelec-redirect/bia-sigelec-redirect.component';
import { BiaComponent } from './bia.component';
import { ChoixBiaSelectionContratGuard } from './guards/choix-bia-selection-contrat.guard';
import { ResetGuard } from './guards/reset.guard';


const routes: Routes = [{
  path: '',
  component: BiaComponent,
  canActivateChild: [BiaStateGuard],
  canActivate: [ResetGuard],
  children: [
    {
      path: 'ma-demande',
      component: BiaDemandeComponent,
      canActivate: [BiaGuard],
    },
    {
      path: 'validation-piece-identite',
      component: BiaIdentiteNumComponent,
      children: pieceIdentiteRoutes
    },
    {
      path: 'verification-donnees-personnelles',
      component: BiaMatchAccountComponent
    },
    {
      path: 'choix-contrat',
      component: BiaChoixContratComponent,
      canActivate: [ContratUniqueGuard]
    },
    {
      path: 'mes-choix',
      component: BiaChoixComponent,
      canActivateChild: [ChoixBiaSelectionContratGuard],
      children: [
        {
          path: 'choix-clause-beneficiaire',
          component: BiaChoixClauseBeneficiaireComponent,
        },
        {
          path: 'choix-gestion-financiere',
          component: ChoixGestionFinanciereComponent
        },
        {
          path: 'confirmation-choix-client',
          component: ConfirmationChoixClientBiaComponent
        },
        {
          path: '**',
          redirectTo: 'choix-clause-beneficiaire',
          pathMatch: 'full'
        }
      ]
    },
    {
      path: 'questionnaire-aide-decision',
      component: BiaQadComponent
    },
    {
      path: 'confirmation-manuscrit',
      component: BiaConfirmationComponent,
    },
    {
      path: 'signature/:status',
      component: BiaSigelecRedirectComponent
    },
    {
      path: 'demande-signature-electronique',
      component: BiaDemsigelecComponent
    },
    {
      path: '**',
      redirectTo: 'ma-demande',
      pathMatch: 'full'
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BiaRoutingModule {
}
