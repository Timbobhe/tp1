import { PercentPipe } from '@angular/common';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { DownloadDocument } from '@app/models/client/download-document.model';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { Subscription } from 'rxjs';
import { initialStateWithContractsAssures } from 'test/store-states.mock';
import { PourcentagePipe } from '@ag2rlamondiale/transverse-metier-ng';
import { BiaDetailChoixClientComponent } from '../bia-choix/bia-detail-choix-client/bia-detail-choix-client.component';
import { BiaConfirmationComponent } from './bia-confirmation.component';
import { testingModule } from '../../../../test/ecrs-testing';


describe('BiaConfirmationComponent', () => {
  let component: BiaConfirmationComponent;
  let fixture: ComponentFixture<BiaConfirmationComponent>;
  let fixture2: ComponentFixture<BiaDetailChoixClientComponent>;
  let downloadServiceStub: Partial<DownloadService>;

  downloadServiceStub = {
    downloadDocument({contratId, codeDocument, htmlContent, htmlStyle, compartimentId}: DownloadDocument) {
      return new Subscription();
    }
  };

  beforeEach(waitForAsync(() => {
    testingModule({...initialStateWithContractsAssures}, {
      declarations: [BiaConfirmationComponent, BiaDetailChoixClientComponent, PourcentagePipe],
      providers: [
        {provide: DownloadService, useValue: downloadServiceStub},
        {provide: PercentPipe, useClass: PercentPipe},
        {provide: PourcentagePipe, useClass: PourcentagePipe},
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaConfirmationComponent);
    fixture2 = TestBed.createComponent(BiaDetailChoixClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
