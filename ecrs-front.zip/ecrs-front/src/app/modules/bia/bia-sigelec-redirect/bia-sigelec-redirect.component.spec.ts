import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { testingModule } from 'test/ecrs-testing';
import { BiaSigelecRedirectComponent } from './bia-sigelec-redirect.component';


describe('BiaSigelecRedirectComponent', () => {
  let component: BiaSigelecRedirectComponent;
  let fixture: ComponentFixture<BiaSigelecRedirectComponent>;


  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [BiaSigelecRedirectComponent],
      // imports: [RouterTestingModule.withRoutes([])],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaSigelecRedirectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
