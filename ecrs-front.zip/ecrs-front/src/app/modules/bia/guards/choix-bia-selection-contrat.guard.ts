import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectBia } from '@app/reducers/ecrs.selectors';
import { map, take } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ChoixBiaSelectionContratGuard implements CanActivateChild {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot) {

    return selectBia(this.store).pipe(
      take(1),
      map(x => !x.bia.contratSelected),
      map(failed => failed ? this.router.parseUrl('/bulletin-affiliation/choix-contrat') : true)
    );
  }

}
