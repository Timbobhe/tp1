import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterModule } from '@angular/router';
import * as fromRoot from '@app/reducers/_index';
import { StoreModule } from '@ngrx/store';
import { initialStateWithSigElec } from 'test/store-states.mock';
import { BiaDemsigelecComponent } from './bia-demsigelec.component';



describe('BiaDemsigelecComponent', () => {
  let component: BiaDemsigelecComponent;
  let fixture: ComponentFixture<BiaDemsigelecComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ BiaDemsigelecComponent ],
      imports: [RouterModule.forRoot([]), StoreModule.forRoot(fromRoot.reducers, initialStateWithSigElec)],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaDemsigelecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
