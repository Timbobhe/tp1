import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SetParcoursManuscritBia } from '@app/actions/bia.action';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-bia-match-account',
  templateUrl: './bia-match-account.component.html',
  styleUrls: ['./bia-match-account.component.scss']
})
export class BiaMatchAccountComponent implements OnInit {

  matchAccount: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
  }

  next(manuscrit = false) {
    this.store.dispatch(new SetParcoursManuscritBia(manuscrit));
    this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute});
  }

  handleMatchAcocunt(value: boolean) {
    this.matchAccount = value;
  }
}
