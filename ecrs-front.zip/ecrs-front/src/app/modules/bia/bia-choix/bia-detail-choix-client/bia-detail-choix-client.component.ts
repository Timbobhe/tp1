import { Component, Input, OnInit } from '@angular/core';
import { ClauseBeneficiaireModel } from '@app/models/client/clause-beneficiaire.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';

@Component({
  selector: 'app-bia-detail-choix-client',
  templateUrl: './bia-detail-choix-client.component.html',
  styleUrls: ['./bia-detail-choix-client.component.scss']
})
export class BiaDetailChoixClientComponent implements OnInit {
  @Input()
  clauseBeneficiaire: ClauseBeneficiaireModel;

  @Input()
  supportsSelectionnes: RepartitionSupport[];

  @Input()
  isParcoursSimplifie = false;

  titreAction: string;

  constructor() {
  }

  ngOnInit() {
    this.titreAction = this.isParcoursSimplifie ?
      'Votre gestion financière du contrat' :
      'Votre gestion financière des cotisations périodiques';
  }

}
