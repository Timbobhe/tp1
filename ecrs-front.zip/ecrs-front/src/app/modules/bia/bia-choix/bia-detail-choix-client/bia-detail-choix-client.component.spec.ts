import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { BiaDetailChoixClientComponent } from './bia-detail-choix-client.component';
import { testingModule } from '../../../../../test/ecrs-testing';
import { EcrsCommonModule } from '@app/modules/ecrs-common/ecrs-common.module';


describe('DetailChoixClientComponent', () => {
  let component: BiaDetailChoixClientComponent;
  let fixture: ComponentFixture<BiaDetailChoixClientComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      imports: [EcrsCommonModule],
      declarations: [BiaDetailChoixClientComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiaDetailChoixClientComponent);
    component = fixture.componentInstance;
    component.clauseBeneficiaire = {
      'clauseStandard': true,
      'typeClause': 'Clause standard',
      'contenuClause': '<div>A défaut de désignation ou si cette désignation est caduque, ce capital est attribué dans l’ordre suivant :<br>  - au conjoint non séparé judiciairement ou au partenaire auquel  le défunt était lié par un PACS (PActe Civil de Solidarité), <br>- à défaut, aux enfants de l’Assuré, nés ou à naître, vivants ou représentés, par parts égales,  <br>- à défaut, aux ascendants de l’Assuré par parts égales ou aux survivants d’entre eux,  <br>- à défaut, aux héritiers de l’Assuré.</div>'
    };
    component.supportsSelectionnes = [];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
