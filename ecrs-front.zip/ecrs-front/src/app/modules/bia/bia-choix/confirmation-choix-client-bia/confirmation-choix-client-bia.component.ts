import { Component, OnDestroy, OnInit } from '@angular/core';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
// @ts-ignore
import biaDocumentStyle from 'styles/document/base-document.css';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { InfoBiaContrat } from '@app/models/client/bia.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-confirmation-choix-blient-bia',
  templateUrl: './confirmation-choix-client-bia.component.html',
  styleUrls: ['./confirmation-choix-client-bia.component.scss']
})
export class ConfirmationChoixClientBiaComponent implements OnInit, OnDestroy {
  contratSelected: InfoBiaContrat;
  supportSelectionnes: any;
  clauseBeneficaire;
  subscriptions: Subscription[] = [];

  constructor(private readonly download: DownloadService, private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select('bia').subscribe(value => {
        this.contratSelected = value.contratSelected;
        this.supportSelectionnes = value.supportsSelectionnes;
        this.clauseBeneficaire = value.choixClauseBeneficiaire;
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  downloadDocument() {
    const bodyDocument: HTMLCollectionOf<Element> = document.getElementsByClassName('confirmation-choix-client');
    this.download.downloadDocument({
      codeDocument: 'BIA_EN_LIGNE', contratId: this.contratSelected.contrat,
      htmlContent: bodyDocument.item(0).innerHTML, htmlStyle: biaDocumentStyle
    });
  }
}
