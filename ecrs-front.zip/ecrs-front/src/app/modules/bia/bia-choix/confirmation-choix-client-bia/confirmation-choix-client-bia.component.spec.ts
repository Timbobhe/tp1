import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmationChoixClientBiaComponent } from './confirmation-choix-client-bia.component';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import * as fromRoot from '@app/reducers/_index';
import { DownloadDocument } from '@app/models/client/download-document.model';

describe('ConfirmationChoixBlientBiaComponent', () => {
  let component: ConfirmationChoixClientBiaComponent;
  let fixture: ComponentFixture<ConfirmationChoixClientBiaComponent>;
  let downloadServiceStub: Partial<DownloadService>;

  downloadServiceStub = {
    downloadDocument({contratId, codeDocument}: DownloadDocument) {
      console.log(`Download document ${contratId}-${codeDocument}`);
    }
  };

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [StoreModule.forRoot(fromRoot.reducers)],
      declarations: [ConfirmationChoixClientBiaComponent],
      providers: [
        {provide: DownloadService, useValue: downloadServiceStub}
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmationChoixClientBiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
