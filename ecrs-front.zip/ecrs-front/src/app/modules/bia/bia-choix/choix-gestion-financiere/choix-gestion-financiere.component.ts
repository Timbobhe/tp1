import { DeviceSize, ImpersonationService, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostBiaTerminate, PushEtapeBia, PushGestionFinanciereSelected } from '@app/actions/bia.action';
import { GestionFinanciereCompartimentFetch } from '@app/actions/gestion-financiere.actions';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import { BiaTerminateModel, InfoBiaContrat } from '@app/models/client/bia.model';
import { ClauseBeneficiaireModel } from '@app/models/client/clause-beneficiaire.model';
import { toCompartimentId } from '@app/models/client/contrat.model';
import { GestionFinanciereModel } from '@app/models/client/gestion-financiere.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { InfoQad } from '@app/models/client/qad.model';
import { ResultatRepartition } from '@app/modules/ecrs-common/components/ecrs-tableau-repart-financiere/ecrs-tableau-repart-financiere.component';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { selectBia, selectInfoClient } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
// @ts-ignore
import documentStyle from '../../../../../styles/document/base-document.css';
import { HideMenu, SetContratCompteDemo, SetParcoursUrl } from '@app/actions/ui.actions';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { filter, switchMap, take } from 'rxjs/operators';

@Component({
  selector: 'app-bia-choix-gestion-financiere',
  templateUrl: './choix-gestion-financiere.component.html',
  styleUrls: ['./choix-gestion-financiere.component.scss']
})
export class ChoixGestionFinanciereComponent implements OnInit, OnDestroy {
  @Output() next: EventEmitter<any> = new EventEmitter();
  gestionFinanciere: GestionFinanciereModel;
  supportsSelectionnes: RepartitionSupport[] = null;
  contratSelected: InfoBiaContrat;
  clauseBeneficiaire: ClauseBeneficiaireModel;
  qadCodeProposition: string[] = [];
  qadContentHtml: string;

  nextEnCours = false;

  selected = false;
  parcoursManuscrit = false;
  onResize$: Observable<DeviceSize>;

  subscriptions: Subscription[] = [];
  isCompteDemo: boolean;

  constructor(
    private readonly download: DownloadService,
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly responsive: ResponsiveService,
    private readonly impersonationService: ImpersonationService,
    private readonly reduxApi: ReduxApiService
  ) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit() {
    this.subscriptions.push(
      selectBia(this.store).pipe(
        filter(x => !x.bia.gestionFinanciere),
        take(1),
        switchMap(x => this.reduxApi.execute(new GestionFinanciereCompartimentFetch({
          contratId: x.bia.contratSelected.contrat,
          compartimentId: toCompartimentId(x.bia.contratSelected.contrat),
          fonctionnalite: 'completerBIA'
        })))
      ).subscribe(),

      selectBia(this.store).subscribe(x => {
        if (x.bia.gestionFinanciere) {
          this.gestionFinanciere = x.bia.gestionFinanciere;
        }

        this.contratSelected = x.bia.contratSelected;
        this.clauseBeneficiaire = x.bia.choixClauseBeneficiaire;
        this.parcoursManuscrit = x.bia.parcoursManuscrit;

        if (x.qad.codesSupportsRecommandes) {
          this.qadCodeProposition = x.qad.codesSupportsRecommandes;
          this.qadContentHtml = x.qad.htmlContent;
        }
      }),

      this.store.select(selectInfoClient).subscribe(e => {
        this.isCompteDemo = e.compteDemo;
      })
    );

  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  updateSelected(choix: ResultatRepartition) {
    if (choix && choix.repartitions.length > 0 && choix.state === 'complete') {
      this.supportsSelectionnes = [];
      choix.repartitions.forEach(r => {
        const grille = this.gestionFinanciere.grillesProfilsNiveau1.find(e => e.id === r.id);
        const recommande = this.supportsRecommandes().includes(r.id);
        const support = new RepartitionSupport();
        support.id = grille.id;
        support.nom = grille.nom;
        support.pourcentage = r.pourcentage;
        support.defaut = grille.defaut;
        support.recommande = recommande;
        this.supportsSelectionnes.push(support);
      });
    } else {
      this.supportsSelectionnes = null;
    }
  }

  goToPreviousStep() {
    this.router.navigate(['../choix-clause-beneficiaire'], {relativeTo: this.activeRoute});
    this.store.dispatch(new PushEtapeBia({etape: 0}));
    this.next.emit(0);
  }

  goToNextStep() {
    this.nextEnCours = true;
    this.store.dispatch(new PushGestionFinanciereSelected(this.supportsSelectionnes));
    this.store.dispatch(tracking(Categorie.bia, TypeOriginAction.signature));

    if (this.parcoursManuscrit) {
      this.router.navigate(['../../confirmation-manuscrit'], {relativeTo: this.activeRoute});
    } else if (!this.isCompteDemo) {
      this.impersonationService.protect(
        'Signature électronique du BIA',
        () => {
          const bodyDocument: HTMLCollectionOf<Element> = document.getElementsByClassName('confirmation-choix-client');

          const clauseBeneficiaire: ClauseBeneficiaireModel = {...this.clauseBeneficiaire};
          clauseBeneficiaire.contenuClause = clauseBeneficiaire.contenuClause.replace(/<[^>]+>/g, '');

          const biaTerminate = new BiaTerminateModel();
          biaTerminate.clauseBeneficiaireSelected = clauseBeneficiaire;
          biaTerminate.contratSelected = this.contratSelected.contrat;
          biaTerminate.gestionFinanciereSelected = this.supportsSelectionnes;
          biaTerminate.contenuBIA = {htmlContent: bodyDocument.item(0).innerHTML, htmlStyle: documentStyle};
          biaTerminate.contenuQAD = {htmlContent: this.qadContentHtml, htmlStyle: documentStyle};

          const postBiaTerminate = new PostBiaTerminate(biaTerminate);
          postBiaTerminate.payload.onSuccess = data => {
            window.location.assign(data);
          };
          this.store.dispatch(postBiaTerminate);
        },
        () => (this.nextEnCours = false)
      );
    } else {
      this.store.dispatch(new HideMenu(true));
      this.store.dispatch(new SetParcoursUrl('bulletin-affiliation'));
      this.store.dispatch(new SetContratCompteDemo(this.contratSelected.contrat.nomContrat));
      this.router.navigate(['/compte-demo']);
    }
  }

  supportParDefaut() {
    const sd = this.gestionFinanciere.grillesProfilsNiveau1.find(value => value.defaut);
    return sd ? sd.id : null;
  }

  supportsRecommandes() {
    return this.qadCodeProposition;
  }

  repartitionParDefaut() {
    const id = this.supportParDefaut();
    return id ? {[id]: {pourcentage: 100}} : null;
  }

  getJahiaKeyButton() {
    if (this.parcoursManuscrit) {
      return 'CONFIRMER_BUTTON';
    }
    return 'CONFIRMER_ET_SIGNER_BUTTON';
  }

  infoQadLauncher(): InfoQad {
    if (this.contratSelected && this.gestionFinanciere && this.gestionFinanciere.qadEligible) {
      return {
        contratId: this.contratSelected.contrat,
        compartimentId: toCompartimentId(this.contratSelected.contrat),
        qadLauncherEligible: true,
        codesSupportsContrat: this.gestionFinanciere.grillesProfilsNiveau1.map(e => e.id)
      };
    }

    return null;
  }

  codeDocumentQad() {
    let codeDocument: string;
    if (this.parcoursManuscrit) {
      codeDocument = 'RESULTAT_QUAD';
    } else {
      codeDocument = 'QAD_EN_LIGNE';
    }
    return codeDocument;
  }
}
