import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AqeFrameComponent } from './aqe-frame/aqe-frame.component';

const routes: Routes = [
  {
    path: ':pageId',
    component: AqeFrameComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AqeFrameRoutingModule {
}
