import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AqeFrameComponent } from './aqe-frame/aqe-frame.component';
import { AqeFrameRoutingModule } from '@app/modules/aqe-frame/aqe-frame-routing.module';
import { IframeAutoHeightDirective } from './iframe-auto-height.directive';
import {EcrsCommonModule} from '@app/modules/ecrs-common/ecrs-common.module';



@NgModule({
  declarations: [AqeFrameComponent, IframeAutoHeightDirective],
    imports: [
        CommonModule,
        AqeFrameRoutingModule,
        EcrsCommonModule
    ]
})
export class AqeFrameModule { }
