import { Directive, ElementRef, EventEmitter, NgZone, OnDestroy, OnInit, Output, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appIframeAutoHeight]'
})
export class IframeAutoHeightDirective implements OnInit, OnDestroy {

  @Output() onAccessible = new EventEmitter<boolean>();

  private readonly el: any;
  private renderer: Renderer2;
  private prevHeight: number;
  private sameCount: number;
  private frameLoaded = false;

  private timeoutsID = [];

  constructor(
    _elementRef: ElementRef,
    _renderer: Renderer2,
    private ngZone: NgZone) {
    this.el = _elementRef.nativeElement;
    this.renderer = _renderer;
  }

  ngOnInit() {
    const self = this;
    if (this.el.tagName === 'IFRAME') {
      this.renderer.listen(this.el, 'load', () => {
        self.prevHeight = 0;
        self.sameCount = 0;
        this.frameLoaded = true;

        this.ngZone.runOutsideAngular(() =>
          this.withTimeout(() => {
            self.setHeight();
          }, 50)
        );
      });

      this.renderer.listen(document, 'scroll', () => {
        if (this.frameLoaded) {
          this.ngZone.runOutsideAngular(() =>
            this.withTimeout(() => {
              self.setHeight();
            }, 50)
          );
        }
      });
    }
  }

  // setHeight2() {
  //   const frame = this.el;
  //   // Get the height of the content
  //   const height = frame.contentDocument.body.scrollHeight;
  //
  //   // Set the height of iframe
  //   frame.setAttribute('height', `${height}px`);
  // }

  setHeight() {

    try {
      const self = this;
      const frame = this.el;
      // Get the height of the content
      const height = frame?.contentDocument?.body?.scrollHeight;

      if (height && height !== this.prevHeight) {
        this.sameCount = 0;
        this.prevHeight = height;
        this.renderer.setStyle(
          frame,
          'height',
          height + 'px'
        );

        this.withTimeout(() => {
          self.setHeight();
        }, 50);

      } else {
        this.sameCount++;
        if (this.sameCount < 20) {
          this.withTimeout(() => {
            self.setHeight();
          }, 50);
        }
      }
      this.onAccessible.emit(true);
    } catch (e) {
    }
  }

  withTimeout(cb: () => any, millis) {
    this.timeoutsID.push(setTimeout(cb, millis));
  }

  ngOnDestroy(): void {
    this.timeoutsID.forEach(e => clearTimeout(e));
  }

}
