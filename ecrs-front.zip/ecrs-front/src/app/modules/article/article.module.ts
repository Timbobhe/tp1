import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {EcrsCommonModule} from '@app/modules/ecrs-common/ecrs-common.module';
import { ArticleComponent } from './article.component';
import {ArticleRoutingModule} from '@app/modules/article/article-routing.module';

@NgModule({
  imports: [
    CommonModule,
    EcrsCommonModule,
    ArticleRoutingModule
  ],
  declarations: [ArticleComponent],
  exports: [ArticleComponent]
})
export class ArticleModule { }
