import { Injectable } from '@angular/core';
import { SupplierModifRibService, CoodonneesBancairesUiConfig } from '@ag2rlamondiale/transverse-metier-ng';

@Injectable({
  providedIn: 'root'
})
export class EcrsSupplierModifRibService extends SupplierModifRibService {

  versementProgrammeRoute(): string {
    return '/modification-gestion-financiere';
  }

  versementSyntheseRoute(): string {
    return '/synthese-des-comptes';
  }

  uiConfig(): CoodonneesBancairesUiConfig {
    return {activeVersementSyntheseRoute: true, activeVersementProgrammeRoute: true};
  }

}
