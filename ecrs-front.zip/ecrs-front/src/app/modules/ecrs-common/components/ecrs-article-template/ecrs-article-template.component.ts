import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Location } from '@angular/common';
import {
  Component,
  HostListener,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Pipe,
  PipeTransform,
  SimpleChanges
} from '@angular/core';
import { ArticleContribs, buildPathFromArticleName } from '@app/models/client/article-content.model';
import { Observable, Subscription } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { JahiaContrib } from '@ag2rlamondiale/jahia-ng/lib/models/jahiacontrib.model';

@Component({
  selector: 'app-ecrs-article-template',
  templateUrl: './ecrs-article-template.component.html',
  styleUrls: ['./ecrs-article-template.component.scss']
})
export class EcrsArticleTemplateComponent implements OnInit, OnChanges, OnDestroy {

  @Input() articleName: string;
  @Input() repertoireName: string;
  @Input() useBodyContent: boolean;
  subscriptions: Subscription[] = [];
  modePictureInPicture = false;

  onResize$: Observable<DeviceSize>;
  articlePieces$: Observable<ArticleContribs>;

  constructor(
    private readonly responsive: ResponsiveService,
    private readonly location: Location,
    private readonly jahiaService: JahiaService) {
    this.onResize$ = this.responsive.onResize$;
  }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges): void {
    const articleName = changes['articleName'].currentValue;

    if (articleName) {

      const articlePath = buildPathFromArticleName(articleName, this.repertoireName, this.useBodyContent);
      this.articlePieces$ = this.jahiaService.getMultiContribsWithId({
        contribId: articleName,
        contribPath: articlePath
      })
        .pipe(
          map(a => convertToObject(a)),
          tap(a => console.log('Article', articleName, a))
        );
    }
  }


  setWidth(device: DeviceSize): string {
    return device.isMobile() ? '100%' : '588px';
  }

  setHeight(device: DeviceSize): string {
    return device.isMobile() ? '210px' : '325px';
  }

  goBack() {
    this.location.back();
  }

  @HostListener('window:scroll', ['$event']) onWindowScroll(e) {
    if (e.target['scrollingElement']) {
      this.modePictureInPicture = e.target['scrollingElement'].scrollTop > 199;
    } else {
      // Fix pour IE11
      this.modePictureInPicture = document.documentElement.scrollTop > 199;
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}

function convertToObject(array: JahiaContrib[]): ArticleContribs {
  const res = {};
  array.forEach(e => Object.assign(res, {[e.contribId]: e.contentHtml?.trim()}));
  return res;
}

@Pipe({
  name: 'extractYoutubeUrl'
})
export class ExtractYoutubeUrlPipe implements PipeTransform {

  transform(contentHTML: string): string {
    const parser = new DOMParser();
    const parsedHtml = parser.parseFromString(contentHTML, 'text/html');
    const body = parsedHtml.querySelector('body');
    return body.innerHTML !== 'null' ? body.innerHTML : null;
  }

}
