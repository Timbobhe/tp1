import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-with-picto-contrib',
  templateUrl: './card-with-picto-contrib.component.html',
  styleUrls: ['./card-with-picto-contrib.component.scss']
})
export class CardWithPictoContribComponent implements OnInit {
  @Input() color: string;
  @Input() textColor: string;
  @Input() icon: string;
  @Input() jahiaContribId: string;

  constructor() { }

  ngOnInit() {
  }
}
