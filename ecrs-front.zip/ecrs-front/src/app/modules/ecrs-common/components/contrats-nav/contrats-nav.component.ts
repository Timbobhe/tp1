import { Component, OnDestroy, OnInit } from '@angular/core';
import { ContratsAssureFetch } from '@app/actions/contrats-assure.actions';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Contrat } from '@app/models/client/contrat.model';

@Component({
  selector: 'app-contrats-nav',
  templateUrl: './contrats-nav.component.html',
  styleUrls: ['./contrats-nav.component.scss']
})
export class ContratsNavComponent implements OnInit, OnDestroy {

  contrats: Contrat[];
  subscriptions = [];

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.subscriptions.push(this.store.select('contratsAssure').subscribe(contratsAssure => {
      if (!(contratsAssure && contratsAssure.isFetched)) {
        this.store.dispatch(new ContratsAssureFetch());
      } else {
        this.contrats = contratsAssure.contratsAssure;
      }
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
