/* tslint:disable:no-unused-variable */
import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, StoreModule } from '@ngrx/store';
import * as fromRoot from '@app/reducers/_index';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';
import { ContratsNavComponent } from './contrats-nav.component';


describe('ContratsNavComponent', () => {
  let component: ContratsNavComponent;
  let fixture: ComponentFixture<ContratsNavComponent>;
  let store: Store<fromRoot.GlobalState>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot({}),
        DialogModule,
        ButtonModule,
        RouterTestingModule
      ],
      declarations: [ ContratsNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    store = TestBed.inject(Store);
    fixture = TestBed.createComponent(ContratsNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
