import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { OpenDonneesPersoPopUp } from '@app/actions/donnee-personnelle.action';
import { selectBasicDonneePerso } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-donnee-personnelle-dialog',
  templateUrl: './donnee-personnelle-dialog.component.html',
  styleUrls: ['./donnee-personnelle-dialog.component.scss']
})
export class DonneePersonnelleDialogComponent implements OnInit, OnDestroy {
  @Input() displayPop = true;

  @Output() onClose = new EventEmitter<boolean>();

  subscriptions: Subscription[] = [];
  popUpType: string;
  titreSujet: string;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select(selectBasicDonneePerso).subscribe(donnees => {
        this.popUpType = donnees.typePopUp;
        this.titreSujet = donnees.titreSujet;
      })
    );
  }

  closePopUp(event) {
    this.displayPop = event;
    this.onClose.emit(true);
    this.store.dispatch(new OpenDonneesPersoPopUp({open: false}));
  }

  ngOnDestroy() {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}
