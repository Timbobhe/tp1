import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ConfirmerDonneePerso, GetDonneePerso, OpenDonneesPersoPopUp } from '@app/actions/donnee-personnelle.action';
import { ResetStateAction } from '@app/actions/global.actions';
import { DonneesPersoParcoursType, IdentiteInfo } from '@app/models/client/donnee-personnelle.model';
import { selectBasicDonneePerso } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { EMPTY, of, Subscription } from 'rxjs';
import { filter, switchMap, take, tap } from 'rxjs/operators';

@Component({
  selector: 'app-donnee-personnelle-validation',
  templateUrl: './donnee-personnelle-validation.component.html',
  styleUrls: ['./donnee-personnelle-validation.component.scss']
})
export class DonneePersonnelleValidationComponent implements OnInit, OnDestroy {
  @Input() titreSujet: string;
  @Output() onClose = new EventEmitter<boolean>();

  identiteInfos: IdentiteInfo;

  dateNaissance: Date;
  subscriptions: Subscription[] = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly reduxApi: ReduxApiService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select(selectBasicDonneePerso).pipe(
        switchMap(donneesPerso => {
          if (donneesPerso.donneesPersonnelles.fetched) {
            return of(donneesPerso.donneesPersonnelles.data);
          } else if (!donneesPerso.donneesPersonnelles.fetched && !donneesPerso.donneesPersonnelles.loading) {
            return this.reduxApi.execution(new GetDonneePerso());
          }
          return EMPTY;
        }),
        filter(donneesPerso => !!donneesPerso)
      )
        .subscribe(donneesPerso => {
          this.identiteInfos = donneesPerso.identiteInfoValidee;
        })
    );

  }

  openUpdate() {
    this.store.dispatch(new OpenDonneesPersoPopUp({open: true, type: 'UPDATE', titreSujet: this.titreSujet}));
  }

  validerInfos() {
    const modificationsIdentiteInfo: IdentiteInfo = {
      codeCivilite: this.identiteInfos.codeCivilite,
      civilite: this.identiteInfos.civilite,
      nom: this.identiteInfos.nom,
      prenom: this.identiteInfos.prenom,
      nomNaissance: this.identiteInfos.nomNaissance,
      dateDeNaissance: this.identiteInfos.dateDeNaissance,
      lieuNaissance: this.identiteInfos.lieuNaissance
    };
    const donneesPersoParcoursType: DonneesPersoParcoursType = 'CONFIRMATION';
    const validationDonneePersoPayload = {
      modificationsIdentiteInfo: modificationsIdentiteInfo,
      donneesPersoParcoursType: donneesPersoParcoursType,
      pieceJointes: null,
      titreSujet: this.titreSujet
    };

    this.subscriptions.push(
      this.reduxApi.execute(new ConfirmerDonneePerso(validationDonneePersoPayload))
        .pipe(tap(e => this.store.dispatch(new ResetStateAction({identNumMatchAccount: {}}))))
        .subscribe(e => this.onClose.emit(true))
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}
