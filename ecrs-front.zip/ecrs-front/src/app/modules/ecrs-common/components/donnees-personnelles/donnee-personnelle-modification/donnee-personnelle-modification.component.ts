import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import {
  CreateIdentiteNumAction,
  CreateIdentitePayload,
  DeviceSize,
  IdentiteNum,
  PrevalidatePieceIdentite,
  ResponsiveService
} from '@ag2rlamondiale/transverse-metier-ng';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ModifierDonneePerso, OpenDonneesPersoPopUp } from '@app/actions/donnee-personnelle.action';
import { ResetStateAction } from '@app/actions/global.actions';
import {
  DonneePersonnelJustificatif,
  DonneesPersoParcoursType,
  IdentiteInfo,
  Justicatif
} from '@app/models/client/donnee-personnelle.model';
import { selectBasicDonneePerso } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { CustomValidator } from '@app/utils/customValidator';
import { DateUtils } from '@app/utils/dateUtils';
import { Store } from '@ngrx/store';
import { SelectItem } from 'primeng/api';
import { Observable, of, Subscription } from 'rxjs';
import { filter, switchMap, tap } from 'rxjs/operators';

@Component({
  selector: 'app-donnee-personnelle-modification',
  templateUrl: './donnee-personnelle-modification.component.html',
  styleUrls: ['./donnee-personnelle-modification.component.scss']
})
export class DonneePersonnelleModificationComponent implements OnInit, OnDestroy {

  @Input() titreSujet: string;

  identiteNum: IdentiteNum = new IdentiteNum();

  valueNotChangedValidator: any;

  subscriptions: Subscription[] = [];
  form: FormGroup;
  utils = DateUtils;
  validators = CustomValidator;


  submitted = false;

  CIVILITE_VALUES = [
    {label: 'Mr', value: 'Mr'},
    {label: 'Mme', value: 'Mme'}
  ];

  onResize$: Observable<DeviceSize>;
  civiliteList: SelectItem[] = [];

  isCtaDisabled = true;

  identiteInfos: IdentiteInfo;
  displayUniversignBloc = false;
  reset = false;
  waitingOCR = false;
  justificatifs: Justicatif;
  identitePayload: CreateIdentitePayload = new CreateIdentitePayload();
  selectedChoixUniversign: boolean;
  @Output() onClose = new EventEmitter<boolean>();

  dateNaissanceFormControl: FormControl;

  notIdentique = false;

  constructor(
    private readonly fb: FormBuilder,
    private readonly store: Store<GlobalState>,
    private readonly responsive: ResponsiveService,
    private readonly reduxApi: ReduxApiService) {
    this.onResize$ = this.responsive.onResize$;
    this.civiliteList = this.CIVILITE_VALUES;
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select(selectBasicDonneePerso).subscribe(donneesPerso => {
        if (donneesPerso.donneesPersonnelles.fetched) {
          this.identiteInfos = donneesPerso.donneesPersonnelles.data.identiteInfoValidee;
          this.initForm();
        }
      })
    );
  }

  initForm() {
    this.form = this.fb.group({
      codeCivilite: [this.identiteInfos.codeCivilite, [Validators.required]],
      nom: new FormControl(this.identiteInfos.nom, {
        validators: [Validators.required, CustomValidator.nameValidator],
        updateOn: 'change'
      }),
      prenom: new FormControl(this.identiteInfos.prenom, {
        validators: [Validators.required, CustomValidator.nameValidator],
        updateOn: 'change'
      }),
      nomNaissance: [this.identiteInfos.nomNaissance],
      dateNaissance: new FormControl(this.utils.convertedStringToDate(this.identiteInfos.dateDeNaissance), {validators: [Validators.required]}),
      lieuNaissance: [this.identiteInfos.lieuNaissance, [Validators.required]],
    });
    let valueChangedValidator = () => CustomValidator.valueNotChangedValidator(
      {
        codeCivilite: this.identiteInfos.codeCivilite,
        nom: this.identiteInfos.nom,
        prenom: this.identiteInfos.prenom,
        nomNaissance: this.identiteInfos.nomNaissance,
        dateNaissance: this.utils.convertedStringToDate(this.identiteInfos.dateDeNaissance),
        lieuNaissance: this.identiteInfos.lieuNaissance
      }, this.form.value);
    this.form.setValidators(valueChangedValidator);
    this.form.updateValueAndValidity();
  }

  get nom() {
    return this.form.get('nom');
  }

  get prenom() {
    return this.form.get('prenom');
  }

  get nomNaissance() {
    return this.form.get('nomNaissance');
  }

  get dateNaissance() {
    return this.form.get('dateNaissance');
  }

  get lieuNaissance() {
    return this.form.get('lieuNaissance');
  }

  get notChangedValues() {
    return this.form.errors;
  }

  onSubmit() {
    this.submitted = true;

    const donneesUpdate = this.form.value;
    const donneePersoModifiee = {
      codeCivilite: donneesUpdate.codeCivilite,
      civilite: this.identiteInfos.civilite,
      nom: donneesUpdate.nom,
      prenom: donneesUpdate.prenom,
      nomNaissance: donneesUpdate.nomNaissance,
      dateDeNaissance: donneesUpdate.dateNaissance,
      lieuNaissance: donneesUpdate.lieuNaissance
    };
    const donneesPersoParcoursType: DonneesPersoParcoursType = 'MODIFICATION';
    const validationDonneePersoPayload = {
      modificationsIdentiteInfo: donneePersoModifiee,
      donneesPersoParcoursType: donneesPersoParcoursType,
      pieceJointes: this.justificatifs.pieceDidendite,
      titreSujet: this.titreSujet
    };

    this.isCtaDisabled = true;

    this.identiteNum = {
      nom: this.nom.value,
      prenom: this.prenom.value,
      dateNaissance: this.dateNaissance.value,
      pieceJointes: this.justificatifs.pieceDidendite,
      typeDoc: this.justificatifs.type
    };
    this.subscriptions.push(this.reduxApi.execution(new PrevalidatePieceIdentite(this.identiteNum)).pipe(
      filter(data => !!data),
      switchMap(data => {
        if (data.codeRetour === '0') {
          return this.reduxApi.execute(new ModifierDonneePerso(validationDonneePersoPayload)).pipe(
            tap(() => {
              if (this.selectedChoixUniversign) {
                this.creerIdentiteNum();
              }
              this.store.dispatch(new ResetStateAction({identNumMatchAccount: {}}));
              this.onClose.emit(true);
            })
          );
        } else {
          this.isCtaDisabled = true;
          this.displayUniversignBloc = false;
          this.notIdentique = true;
          return of(null);
        }
      }),
    ).subscribe());
  }

  creerIdentiteNum() {
    this.identitePayload.doc1 = this.justificatifs.pieceDidendite[0];
    this.identitePayload.doc2 = this.justificatifs.pieceDidendite[1];
    this.store.dispatch(new CreateIdentiteNumAction(this.identitePayload));
  }

  disableButtonValidate(value: boolean) {
    this.isCtaDisabled = value;
  }

  diplayOrNotBlocUniversign(value: boolean) {
    this.displayUniversignBloc = value;
  }

  displaySpinner(value: boolean) {
    this.waitingOCR = value;
  }

  recoverPiecesJointes(value: DonneePersonnelJustificatif) {
    this.notIdentique = false;
    if (value.isCompleted) {
      this.justificatifs = {
        pieceDidendite: value.piecesIdendite,
        type: value.typePj
      };
      if (this.form.valid) {
        this.dispatchFileUpload();
      }
    } else {
      this.justificatifs = null;
      this.isCtaDisabled = true;
      this.displayUniversignBloc = false;
    }
  }

  setCleValidation(cle: string) {
    this.identitePayload.cleValidation = cle;
  }

  setChoixUniversign(choix) {
    if (choix) {
      this.selectedChoixUniversign = choix;
    }
  }

  ngOnDestroy(): void {
    // tslint:disable-next-line:no-unused-expression
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  dispatchFileUpload() {
    this.identiteNum = {
      nom: this.nom.value,
      prenom: this.prenom.value,
      dateNaissance: this.dateNaissance.value,
      pieceJointes: this.justificatifs.pieceDidendite,
      typeDoc: this.justificatifs.type
    };
    this.isCtaDisabled = true;
    this.displayUniversignBloc = false;
    this.notIdentique = false;
    this.waitingOCR = true;
    this.reduxApi.execution(new PrevalidatePieceIdentite(this.identiteNum)).pipe(
      filter(data => !!data),
      tap(data => {
        if (data.codeRetour === '0') {
          this.displayUniversignBloc = true;
          this.notIdentique = false;
          this.setCleValidation(data.idUniverSign);
        } else {
          this.isCtaDisabled = true;
          this.displayUniversignBloc = false;
          this.notIdentique = true;
        }
        this.waitingOCR = false;
      })
    ).subscribe();
  }

  notChanged(): boolean {
    return this.form.errors?.['notChanged'];
  }

  closeModifier() {
    this.store.dispatch(new OpenDonneesPersoPopUp({
      open: true,
      type: 'VALIDATE',
      titreSujet: 'VALIDATION_DONNEES_PERSONNELLES'
    }));
  }
}
