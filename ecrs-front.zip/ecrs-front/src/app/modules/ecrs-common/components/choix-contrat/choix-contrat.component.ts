import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { SetTrackingEnvTemplate } from '@app/actions/tracking.action';

@Component({
  selector: 'app-choix-contrat',
  templateUrl: './choix-contrat.component.html',
  styleUrls: ['./choix-contrat.component.scss']
})
export class ChoixContratComponent implements OnInit {
  subscriptions = [];
  @Input()
  contrats: MiniContrat[] = [];

  @Input()
  afficherEncours = false;

  @Output()
  next: EventEmitter<any> = new EventEmitter<any>();

  constructor(private readonly store: Store<GlobalState>) {}

  ngOnInit() {}

  goToNextStep(event: MiniContrat) {
    this.store.dispatch(new SetTrackingEnvTemplate([event.codeSilo]));
    this.next.emit(event);
  }
}
