import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';
import {
  ClearCacheCoordonneesClient,
  GetIdentNumMatchAccount,
  IdentiteNumerique,
  UrlService
} from '@ag2rlamondiale/transverse-metier-ng';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OpenDonneesPersoPopUp } from '@app/actions/donnee-personnelle.action';
import { GetSigElecDemEnCours } from '@app/actions/sig-elec.action';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';
import { MiniContrat } from '@app/models/client/contrat.model';
import { OperationType } from '@app/models/client/operation.model';
import { selectBasicDonneePerso, selectInfoAtterissage } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { AqeaRedirectService } from '@app/services/aqea-redirect.service';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { filter, switchMap } from 'rxjs/operators';
import { TITRE_SOUS_SUJET_CONF } from '@app/models/client/donnee-personnelle.model';


interface FeatureType {
  contribIdManuscrit: string;
  foncSigElect: FonctionnaliteType;
  featureDicoId: string;
  operationType: OperationType;
  repriseSigElec: boolean;
}

export const Features: Partial<{ [k in FonctionnaliteType]: FeatureType }> = {
  completerBIA: {
    contribIdManuscrit: 'BIA_PARCOURS_MANUSCRIT',
    foncSigElect: 'completerBIASigElec',
    featureDicoId: 'dictionnaireBia',
    operationType: 'EBIA',
    repriseSigElec: true
  },
  Arbitrage: {
    contribIdManuscrit: 'ARBITRAGE_PARCOURS_MANUSCRIT',
    foncSigElect: 'ArbitrageSigElec',
    featureDicoId: 'dictionnaireArbitrage',
    operationType: 'ARBI',
    repriseSigElec: true
  },
  ClauseBeneficiaire: {
    contribIdManuscrit: 'CLAUSE_BENEFICIAIRE_PARCOURS_MANUSCRIT',
    foncSigElect: 'ClauseBeneficiaireSigElec',
    featureDicoId: 'dictionnaireClauseBenef',
    operationType: 'CBF',
    repriseSigElec: true
  },
  versement: {
    contribIdManuscrit: 'VERSEMENT_PARCOURS_MANUSCRIT',
    foncSigElect: 'versementSigElec',
    featureDicoId: 'dictionnaireVersement',
    operationType: 'VRLI',
    repriseSigElec: false
  },
  arretVersement: {
    contribIdManuscrit: 'ARRET_VERSEMENT_PARCOURS_MANUSCRIT',
    foncSigElect: 'versementProgrammeSigElec',
    featureDicoId: 'dictionnaireArretVersement',
    operationType: 'VRPG',
    repriseSigElec: false
  } // à changer VRLI en VR après la mise à jour côté commom GWT
};

@Component({
  selector: 'app-atterissage',
  templateUrl: './atterissage.component.html',
  styleUrls: ['./atterissage.component.scss']
})
export class AtterissageComponent implements OnInit, OnDestroy {
  @Input() fonctionnaliteType: FonctionnaliteType;
  @Output() onNext = new EventEmitter<{ isBlockedSigElec: boolean; isManuscrit: boolean }>();

  feature: FeatureType;
  subscriptions: Subscription[] = [];
  identNumMatchAccount: IdentiteNumerique;
  saisieCoordonneesIsDone: boolean;
  hasIdentNum: boolean;
  hasContratEre = true;
  openDialog: boolean;
  contratsBloquesSigElec: MiniContrat[];
  contratsNonBloquesSigElec: MiniContrat[];

  isBlockedSigElec = false;
  sigElecOff = false;

  private timeoutID: any;

  refonteDonneesPersoActivee: false;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly redirectService: AqeaRedirectService,
    private readonly activeRoute: ActivatedRoute,
    private readonly elRef: ElementRef,
    public readonly confService: ConfigService,
    public readonly urlService: UrlService,
    private readonly configService: ConfigService,
    private readonly reduxApi: ReduxApiService
  ) {
  }

  ngOnInit() {
    this.refonteDonneesPersoActivee = this.configService.config['refonte_donnees_perso'];
    this.feature = Features[this.fonctionnaliteType];

    if (this.feature.repriseSigElec) {
      this.store.dispatch(new GetSigElecDemEnCours(this.feature.operationType));
    }

    this.subscriptions.push(
      selectInfoAtterissage(this.store)
        .pipe(
          filter(x => !x.identiteNum || (x.identiteNum.isFetched === false && x.identiteNum.loading === false)),
          switchMap(x => this.reduxApi.execute(new GetIdentNumMatchAccount()))
        )
        .subscribe(),

      selectInfoAtterissage(this.store)
        .pipe(filter(x => !!x.identiteNum.identiteNumerique))
        .subscribe(x => {
          this.identNumMatchAccount = x.identiteNum.identiteNumerique;
          this.hasIdentNum = x.identiteNum.identiteNumerique.identiteNumeriqueExist;
          this.saisieCoordonneesIsDone = x.identiteNum.identiteNumerique.donnneesPersoConfirmees;

          this.hasContratEre = x.infoClient.hasContratEre;
          this.contratsBloquesSigElec = x.infoClient.infosBlocagesClient.contratsBloques(
            x.contrats.contratsAssure,
            this.feature.foncSigElect
          );
          this.contratsNonBloquesSigElec = x.infoClient.infosBlocagesClient.contratsNonBloques(
            x.contrats.contratsAssure,
            this.feature.foncSigElect
          );
          this.isBlockedSigElec = x.infoClient.infosBlocagesClient.isFonctionnaliteBloqueePourContrat(
            null,
            this.feature.foncSigElect
          );
          this.sigElecOff = x.infoClient.sigElecOff;

          if (x.sigElec.isFetched && x.sigElec.demande && this.feature.repriseSigElec) {
            this.router.navigate(['../demande-signature-electronique'], {
              relativeTo: this.activeRoute,
              queryParamsHandling: 'preserve'
            });
          }
        }),

      this.store.select(selectBasicDonneePerso).subscribe(donnees => {
        this.openDialog = donnees.openPopUpDonnesPerso;
      })
    );
  }

  confirmerCoordonnees() {
    if (this.refonteDonneesPersoActivee) {
      this.store.dispatch(new OpenDonneesPersoPopUp({open: true, type: 'VALIDATE', titreSujet: TITRE_SOUS_SUJET_CONF}));
    } else {
      this.store.dispatch(new ClearCacheCoordonneesClient());
      this.redirectService.redirectToPage('ModifDonneesPerso', null);
    }
  }

  creerIdentNum() {
    this.router.navigate(['../validation-piece-identite/donnees-personnelles'], {relativeTo: this.activeRoute});
  }

  next(manuscrit: boolean) {
    this.onNext.emit({isBlockedSigElec: this.isBlockedSigElec, isManuscrit: manuscrit});
    if (manuscrit || this.sigElecOff) {
      this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute, queryParamsHandling: 'preserve'});
    } else {
      this.router.navigate(['../verification-donnees-personnelles'], {
        queryParamsHandling: 'preserve',
        relativeTo: this.activeRoute
      });
    }
  }

  bindClickEvent(event) {
    this.timeoutID = setTimeout(() => {
      const signManuTag = this.elRef.nativeElement.querySelector('span.signManu');
      if (signManuTag) {
        signManuTag.addEventListener('click', this.next.bind(this, true));
      }
    }, 2000);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
    if (this.timeoutID) {
      clearTimeout(this.timeoutID);
    }
  }
}
