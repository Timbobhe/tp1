import { waitForAsync, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChoixClauseBeneficiaireComponent } from './choix-clause-beneficiaire.component';
import { testingModule } from '../../../../../test/ecrs-testing';
import { initialStateWithClauseBeneficiaire } from '../../../../../test/store-states.mock';

describe('ChoixClauseBeneficiaireComponent', () => {
  let component: ChoixClauseBeneficiaireComponent;
  let fixture: ComponentFixture<ChoixClauseBeneficiaireComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({ ...initialStateWithClauseBeneficiaire }, {
      declarations: [ChoixClauseBeneficiaireComponent],
      providers: [ChoixClauseBeneficiaireComponent],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoixClauseBeneficiaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    component.clauseStandard = true;
    component.contenuClause = '<div>A défaut de désignation ou si cette désignation est caduque, ce capital est attribué dans l’ordre suivant :<br>  - au conjoint non séparé judiciairement ou au partenaire auquel  le défunt était lié par un PACS (PActe Civil de Solidarité), <br>- à défaut, aux enfants de l’Assuré, nés ou à naître, vivants ou représentés, par parts égales,  <br>- à défaut, aux ascendants de l’Assuré par parts égales ou aux survivants d’entre eux,  <br>- à défaut, aux héritiers de l’Assuré.</div>';
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should update accordion status to open', () => {
    component.updateAccordionStatus();
    fixture.detectChanges();
    expect(component.isAccordionOpen).toBeTruthy();
  });

  it('should update accordion status to close', () => {
    component.isAccordionOpen = true;
    component.updateAccordionStatus();
    fixture.detectChanges();
    expect(component.isAccordionOpen).toBeFalsy();
  });

  it('should update clause to standard', () => {
    component.clauseStandard = false;
    component.updateClause();
    fixture.detectChanges();
    expect(component.clauseStandard).toBeTruthy();
  });

  it('should update clause to specific', () => {
    component.clauseStandard = true;
    component.updateClause();
    fixture.detectChanges();
    expect(component.clauseStandard).toBeFalsy();
  });

  it('should next step with specific clause', () => {
    component.clauseStandard = false;
    component.containSpecific = 'MOCKDATA';
    component.goToNextStep();
    fixture.detectChanges();
    expect(component.typeClause).toEqual('Clause spécifique');
  });

  it('should next step with standard clause', () => {
    component.clauseStandard = true;
    component.goToNextStep();
    fixture.detectChanges();
    expect(component.typeClause).toEqual('Clause standard');
  });
});
