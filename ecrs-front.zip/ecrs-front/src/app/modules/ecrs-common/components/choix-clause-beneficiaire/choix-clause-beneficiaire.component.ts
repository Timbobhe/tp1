import { JahiaContribPayload, JahiaService, QuestionReponse } from '@ag2rlamondiale/jahia-ng';
import {
  AfterContentInit,
  AfterViewChecked,
  AfterViewInit,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { DeviceSize, ResponsiveService } from '@ag2rlamondiale/transverse-metier-ng';
import { Observable } from 'rxjs';
import {
  CLAUSE_SPECIFIQUE,
  CLAUSE_STANDARD,
  ClauseBeneficiaireModel,
  TypeClause
} from '@app/models/client/clause-beneficiaire.model';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';


@Component({
  selector: 'app-choix-clause-beneficiaire',
  templateUrl: './choix-clause-beneficiaire.component.html',
  styleUrls: ['./choix-clause-beneficiaire.component.scss']
})
export class ChoixClauseBeneficiaireComponent implements OnInit, AfterViewInit, AfterContentInit, AfterViewChecked {
  @Input() nomContrat: string;
  @Input() clauseStandard: boolean = null;
  @Input() buttonText: string;
  @Input() containSpecific: string;
  @Input() descClauseBenef: string;
  @Input() tc_category: Categorie | string;
  @Output() onChangeTypeClause = new EventEmitter<TypeClause>();
  @Output() next = new EventEmitter<ClauseBeneficiaireModel>();
  @Output() afterInit = new EventEmitter<ClauseBeneficiaireModel>();
  onResize$: Observable<DeviceSize>;
  isAccordionOpen = false;
  typeClause: TypeClause;
  contenuClause: string;
  disableNextButton = true;

  constructor(
    private readonly responsive: ResponsiveService,
    private readonly jahia: JahiaService,
    private readonly store: Store<GlobalState>) {
    this.onResize$ = this.responsive.onResize$;
  }


  ngOnInit() {
    if (!this.containSpecific) {
      const jahiaContrib = new JahiaContribPayload();
      jahiaContrib.contribId = 'CONTENU_CLAUSE_BENEFICIAIRE_HERITAGE';
      this.jahia.getContrib(jahiaContrib).subscribe(value => {
        this.containSpecific = value.contentHtml.replace(/<[^>]+>/g, '');
      });
    }
  }

  updateAccordionStatus() {
    this.isAccordionOpen = !this.isAccordionOpen;
  }

  updateClause() {
    this.clauseStandard = !this.clauseStandard;
    this.isAccordionOpen = this.clauseStandard === false ? false : this.isAccordionOpen;
    this.onChangeTypeClause.emit(this.clauseStandard ? CLAUSE_STANDARD : CLAUSE_SPECIFIQUE);
    this.updateClauseBeneficiaireSelected();
  }

  addClauseSelected() {
    if (this.clauseStandard) {
      this.typeClause = CLAUSE_STANDARD;
      const body = document.getElementById('contenuClauseStandard');
      if (body) {
        this.contenuClause = body.innerHTML.replace(/<[^>]+>/g, '');
      }
    } else if (!this.clauseStandard) {
      this.typeClause = CLAUSE_SPECIFIQUE;
      this.contenuClause = this.containSpecific;
    }
  }

  goToNextStep() {
    this.addClauseSelected();
    this.next.emit({
      clauseStandard: this.clauseStandard,
      typeClause: this.typeClause,
      contenuClause: this.contenuClause
    });
  }

  ngAfterViewInit(): void {
    this.updateClauseBeneficiaireSelected();
  }

  updateClauseBeneficiaireSelected() {
    this.addClauseSelected();
    this.afterInit.emit({
      clauseStandard: this.clauseStandard,
      typeClause: this.typeClause,
      contenuClause: this.contenuClause
    });
  }

  ngAfterContentInit(): void {
    this.updateClauseBeneficiaireSelected();
  }

  ngAfterViewChecked(): void {
    this.updateClauseBeneficiaireSelected();
  }

  isDisabled() {
    return !this.clauseStandard && !this.containSpecific;
  }

  updateCertificationCheckedStatus(event: any) {
    this.disableNextButton = !event;
  }

  handleOpenCloseQuestion(event: { status: 'close' | 'open'; qr: QuestionReponse }) {
    if (event.status === 'open') {
      this.store.dispatch(tracking(this.tc_category, TypeOriginAction.consultationQuestion, event.qr.question));
    }
  }
}
