import { Component, Input, OnInit } from '@angular/core';
import { GetHtmlContentFromExternalUrl } from '@app/actions/htmlContentFromExternalUrl.action';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-content-from-external-html',
  templateUrl: './content-from-external-html.component.html',
  styleUrls: ['./content-from-external-html.component.scss']
})
export class ContentFromExternalHtmlComponent implements OnInit {
  @Input() contentUrl: string;
  @Input() removeScripts: boolean;
  htmlContent: any;

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    const getHtmlContentFromExternalUrl = new GetHtmlContentFromExternalUrl(this.contentUrl);
    getHtmlContentFromExternalUrl.payload.onSuccess = (data => {
      if (this.removeScripts) {
        const div = document.createElement('div');
        div.innerHTML = data;
        const elements = div.getElementsByTagName('script');
        for (let i = elements.length - 1; i >= 0; i--) {
          elements.item(i).remove();
        }
        data = div.innerHTML;
      }
      this.htmlContent = data;
    });
    this.store.dispatch(getHtmlContentFromExternalUrl);
  }
}
