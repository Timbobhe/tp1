import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ActivatedRoute, Router } from '@angular/router';
import { SetParcoursManuscritArretVersement } from '@app/actions/arret-versement-programme.actions';

@Component({
  selector: 'app-arret-versement-match-account',
  templateUrl: './arret-versement-match-account.component.html',
  styleUrls: ['./arret-versement-match-account.component.scss']
})
export class ArretVersementMatchAccountComponent implements OnInit {
  matchAccount: boolean;
  constructor(  private readonly store: Store<GlobalState>,
                private readonly router: Router,
                private readonly activeRoute: ActivatedRoute) { }

  ngOnInit() {
  }

  next(manuscrit = false) {
    this.store.dispatch(new SetParcoursManuscritArretVersement(manuscrit));
    this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute, queryParamsHandling: 'preserve'});
  }

  handleMatchAccount(value: boolean) {
    this.matchAccount = value;
  }
}
