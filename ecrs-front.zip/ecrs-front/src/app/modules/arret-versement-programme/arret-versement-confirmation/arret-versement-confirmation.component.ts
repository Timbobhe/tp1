import { Component, OnDestroy, OnInit } from '@angular/core';
// @ts-ignore
import versementDocumentStyle from '@app/../styles/document/versement-document.css';
import { CompartimentId, MiniContrat, toCompartimentId } from '@app/models/client/contrat.model';
import { Subscription } from 'rxjs';
import { DownloadService } from '@app/modules/ecrs-common/services/download.service';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Location } from '@angular/common';
import { PartenaireIframeService, STEP_COMPLETED } from '@ag2rlamondiale/transverse-metier-ng';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { DownloadDocument } from '@app/models/client/download-document.model';
import { ArretVersementClient } from '@app/models/client/arret-versement-programme.model';

export const jahiaMap = new Map([
  ['contenuFinaliserDemande', '_CONTENU_FINALISER_DEMANDE'],
  ['contenuVerifierDemande', '_CONTENU_VERIFIER_DEMANDE'],
  ['contenuImprimerDemande', '_CONTENU_IMPRIMER_DEMANDE'],
  ['contenuEnvoyerDemande', '_CONTENU_ENVOYER_DEMANDE']
]);

@Component({
  selector: 'app-arret-versement-confirmation',
  templateUrl: './arret-versement-confirmation.component.html',
  styleUrls: ['./arret-versement-confirmation.component.scss']
})
export class ArretVersementConfirmationComponent implements OnInit, OnDestroy {
  contratSelected: MiniContrat;
  compartimentId: CompartimentId;
  subscriptions: Subscription[] = [];
  arretVersementClient: ArretVersementClient;
  htmlContentVersement: string;
  isERE = false;
  contribIdPrefix: string;

  contenuFinaliserDemande: string;
  contenuVerifierDemande: string;
  contenuImprimerDemande: string;
  contenuEnvoyerDemande: string;

  constructor(private readonly download: DownloadService,
              private readonly store: Store<GlobalState>,
              private readonly location: Location,
              private readonly partenaireIframe: PartenaireIframeService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      selectArretVersement(this.store).subscribe(x => {
        this.contratSelected = x.arretVersement.contratSelected.contrat;
        this.compartimentId = toCompartimentId(x.arretVersement.compartimentSelected);
        this.arretVersementClient = x.arretVersement.arretVersementClient;
        this.isERE = this.contratSelected.codeSilo === 'ERE';
      })
    );

    this.contribId();
    this.htmlContentVersement = document.getElementsByClassName('confirmation-choix-client').item(0).innerHTML;

    this.partenaireIframe.postStep(STEP_COMPLETED);
  }

  contribId() {
    this.contribIdPrefix = 'VERSEMENT_ERE';
    this.contenuFinaliserDemande = this.contribIdPrefix + jahiaMap.get('contenuFinaliserDemande');
    this.contenuVerifierDemande = this.contribIdPrefix + jahiaMap.get('contenuVerifierDemande');
    this.contenuImprimerDemande = this.contribIdPrefix + jahiaMap.get('contenuImprimerDemande');
    this.contenuEnvoyerDemande = this.contribIdPrefix + jahiaMap.get('contenuEnvoyerDemande');
  }

  downloadDocuments() {
    this.downloadVersement();
  }

  downloadVersement() {
    const downloadDocument = new DownloadDocument();
    downloadDocument.codeDocument = this.isERE ? 'PARCOURS_VERSEMENT' : 'PARCOURS_VERSEMENT_MDPRO';
    downloadDocument.contratId = this.contratSelected;
    downloadDocument.compartimentId = this.compartimentId;
    downloadDocument.htmlContent = this.htmlContentVersement;
    downloadDocument.htmlStyle = versementDocumentStyle;
    this.download.downloadDocument(downloadDocument);
  }

  goToPreviousStep() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

}
