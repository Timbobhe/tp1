import { trace } from '@ag2rlamondiale/redux-api-ng';
import { isRetourSigElec, UrlUtils } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivateChild, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { SetSubtitleArretVersement } from '@app/actions/arret-versement-programme.actions';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArretVersementProgrammeStateGuard implements CanActivateChild {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    trace('ArretVersementProgrammeStateGuard#start');
    return selectArretVersement(this.store).pipe(
      tap(x => {
        if (x.router.state.url.startsWith('/arret-versement/ma-demande')) {
          this.store.dispatch(new SetSubtitleArretVersement({id: null}));
        }
      }),
      map(x => !isRetourSigElec(x.router.state)
        && !x.arretVersement.isFetched && (!x.router.state.url.startsWith('/arret-versement/ma-demande'))),
      map(failed => {
        if (failed) {
          const qs = UrlUtils.paramsToQueryString(state.root.queryParams, true);
          return this.router.parseUrl(`/arret-versement/ma-demande${qs}`);
        } else {
          return true;
        }
      }),
      tap(r => trace('ArretVersementProgrammeStateGuard#end', r))
    );
  }
}
