import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { ImpersonationService } from '@ag2rlamondiale/transverse-metier-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PostArretVersementTerminate, PushReponse } from '@app/actions/arret-versement-programme.actions';
import { ArretVersementClient, ArretVersementTerminateModel, Etape0, getQuestionsOrNextFromEtape, isQuestionEnAttenteDeReponse, QuestionModel } from '@app/models/client/arret-versement-programme.model';
import { MiniContrat } from '@app/models/client/contrat.model';
import { QuestionType, Reponse } from '@app/models/question-responses.model';
import { selectArretVersement } from '@app/reducers/ecrs.selectors';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
// @ts-ignore
import documentStyle from '../../../../../styles/document/versement-document.css';

@Component({
  selector: 'app-arret-versement-choix-versement',
  templateUrl: './arret-versement-choix-versement.component.html',
  styleUrls: ['./arret-versement-choix-versement.component.scss']
})
export class ArretVersementChoixVersementComponent implements OnInit, OnDestroy {

  questionToShow: QuestionType;
  questions: QuestionModel;
  contrat: MiniContrat;
  parcoursManuscrit: boolean;
  loading = false;
  reponseTemporaire: Reponse;
  arretVersementClient: ArretVersementClient;
  placeholder: string;

  etapeCourante = Etape0;

  subscriptions = [];
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly jahia: JahiaService,
    private readonly impersonationService: ImpersonationService) {
  }

  ngOnInit() {
    this.subscriptions.push(selectArretVersement(this.store).subscribe(x => {
      this.questions = x.arretVersement.questions;
      this.questionToShow = x.arretVersement.questionToShow;
      this.contrat = x.arretVersement.contratSelected.contrat;
      this.parcoursManuscrit = x.arretVersement.parcoursManuscrit;
      this.questionToShow = x.arretVersement.questionToShow;
      this.reponseTemporaire = null;
      this.arretVersementClient = x.arretVersement.arretVersementClient;
      getQuestionsOrNextFromEtape(this.store, this.etapeCourante, x.arretVersement);
    }));
  }

  pushReponse(reponse: Reponse, questionType = this.questionToShow) {
    this.store.dispatch(new PushReponse({ questionType, reponse }));
  }

  canNext(): boolean {
    if (this.questionToShow === 'VERSEMENT_CHOIX_COMPARTIMENT') {
      return this.reponseTemporaire !== null;
    }
    return true;
  }

  goToNext(): void {
    switch (this.questionToShow) {
      case 'VERSEMENT_CHOIX_COMPARTIMENT':
        if (this.questionToShow && this.reponseTemporaire) {
          this.pushReponse(this.reponseTemporaire);
        }
        break;

      default:
        this.next();
        break;
    }
  }

  ctaLabel() {
    return this.parcoursManuscrit ? 'Confirmer' : 'Confirmer et signer ma demande';
  }

  currentQuestion() {
    if (isQuestionEnAttenteDeReponse(this.questions,
      this.questionToShow,
      this.etapeCourante.questionsType[this.contrat.codeSilo])) {
      return this.questions.fromType(this.questionToShow);
    }
    return null;
  }

  saveResponse($event: { reponse: Reponse, goToNext: boolean }, questionType: QuestionType) {
    this.reponseTemporaire = $event.reponse;
    if (questionType !== 'VERSEMENT_CHOIX_DETAIL' && $event.goToNext !== false) {
      this.goToNext();
    }
  }

  onUpdateContribCondition(contrib) {
    trace(`OnUpdateContribCondition:`, contrib);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  next() {
    if (this.parcoursManuscrit) {
      this.router.navigate(['../confirmation-manuscrit'], {relativeTo: this.activeRoute});
    } else {
      this.impersonationService.protect('Signature électronique de l\'arrêt versement', () => {
        const bodyDocument: HTMLCollectionOf<Element> = document.getElementsByClassName('confirmation-choix-client');
        const arretVersementTerminate = new ArretVersementTerminateModel();
        arretVersementTerminate.baseUrl = 'arret-versement';
        arretVersementTerminate.contratSelected = this.contrat;
        arretVersementTerminate.arretVersementClient = this.arretVersementClient;
        arretVersementTerminate.contenuVersement = {
          htmlStyle: documentStyle,
          htmlContent: bodyDocument.item(0).innerHTML
        };
        const postArretVersementTerminate = new PostArretVersementTerminate(arretVersementTerminate);
        postArretVersementTerminate.payload.onSuccess = data => {
          window.location.assign(data);
        };
        this.store.dispatch(postArretVersementTerminate);
      });
    }
  }
}
