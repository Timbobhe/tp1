import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

export const SIGELEC_MSG_PATH = '/sites/aqe/ecrs/arretversement/body-content.apiV2.html.ajax?blockId=';

@Component({
  selector: 'app-arret-versement-sigelec-redirect',
  templateUrl: './arret-versement-sigelec-redirect.component.html',
  styleUrls: ['./arret-versement-sigelec-redirect.component.scss']
})
export class ArretVersementSigelecRedirectComponent implements OnInit {

  signatureStatus: string;
  urlPathPrefix: string;

  constructor(private readonly route: ActivatedRoute) {
  }

  ngOnInit() {
    this.signatureStatus = this.route.snapshot.params.status;
    this.urlPathPrefix = SIGELEC_MSG_PATH;
  }
}
