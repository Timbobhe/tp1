import { Component, OnInit } from '@angular/core';
import { SetParcoursManuscritArbitrage } from '@app/actions/arbitrage.action';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-arbitrage-demande',
  templateUrl: './arbitrage-demande.component.html',
  styleUrls: ['./arbitrage-demande.component.scss']
})
export class ArbitrageDemandeComponent implements OnInit {
  constructor(
    private readonly store: Store<GlobalState>
  ) {
  }

  ngOnInit() {
  }

  updateParcoursManuscrit(event: {isBlockedSigElec: boolean; isManuscrit: boolean}) {
    this.store.dispatch(new SetParcoursManuscritArbitrage(event.isManuscrit));
  }
}
