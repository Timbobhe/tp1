import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { ResponseArbitrageEurosPourcentageType } from '@app/models/client/arbitrage.model';

@Component({
  selector: 'app-arbitrage-partiel',
  templateUrl: './arbitrage-partiel.component.html',
  styleUrls: ['./arbitrage-partiel.component.scss']
})
export class ArbitragePartielComponent implements OnInit, OnChanges {
  @Input()
  support: RepartitionSupport[];
  @Input()
  onlyPourcentage = false;
  @Input()
  showTitle = false;

  isOptionEuro: boolean;

  repartitionSupportWithValidities: RepartitionSupportWithValidity[] = [];

  @Output()
  onRepartitionChange = new EventEmitter<{ repartitions: RepartitionSupport[], valid: boolean }>();

  @Output()
  onEuroPourcent = new EventEmitter<ResponseArbitrageEurosPourcentageType>();

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
  }

  selected(b: boolean) {
    this.isOptionEuro = b;
    if (b) {
      this.onEuroPourcent.emit('ARBITRAGE_EUROS');
    } else {
      this.onEuroPourcent.emit('ARBITRAGE_POURCENTAGE');
    }
    return b;
  }

  updateRepartitionSupportList(repartition: RepartitionSupportWithValidity) {
    this.repartitionSupportWithValidities.forEach(value => {
      if (value.repartitionSupport.id === repartition.repartitionSupport.id) {
        const supportInitial = this.support.find(value1 => value1.id === value.repartitionSupport.id);

        value.validity = repartition.validity;
        value.repartitionSupport.montant = undefined;
        value.repartitionSupport.pourcentage = undefined;
        if (this.isOptionEuro) {
          value.repartitionSupport.montant = +repartition.repartitionSupport.montant || 0;
          value.repartitionSupport.pourcentage = Math.round((value.repartitionSupport.montant / supportInitial.montant) * 100) / 100;
        } else {
          value.repartitionSupport.pourcentage = +repartition.repartitionSupport.pourcentage || 0;
          value.repartitionSupport.montant = (value.repartitionSupport.pourcentage * supportInitial.montant) / 100;
          value.repartitionSupport.montant = Math.round(value.repartitionSupport.montant * 100) / 100;
        }
      }
    });

    const valid = this.checkValidity(this.repartitionSupportWithValidities);
    this.onRepartitionChange.emit({
      repartitions: this.repartitionSupportWithValidities.map(e => e.repartitionSupport),
      valid
    });
    this.selected(this.isOptionEuro);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.support) {
      this.repartitionSupportWithValidities = [];
      this.support.forEach(value => {
        const repa: RepartitionSupportWithValidity = new RepartitionSupportWithValidity();
        const repart: RepartitionSupport = new RepartitionSupport();
        repart.id = value.id;
        repart.nom = value.nom;
        repa.repartitionSupport = repart;
        this.repartitionSupportWithValidities.push(repa);
      });
    }
  }

  checkValidity(choixRepartitionPartielle: RepartitionSupportWithValidity[]): boolean {
    let hasAtLeastOneInputFilled = false;
    for (const r of choixRepartitionPartielle) {
      if (r.validity && !r.validity.isValid) {
        return false;
      }
      if (r.repartitionSupport.montant && r.repartitionSupport.montant > 0 || r.repartitionSupport.pourcentage && r.repartitionSupport.pourcentage > 0) {
        hasAtLeastOneInputFilled = true;
      }
    }
    return hasAtLeastOneInputFilled;
  }

}

export interface ValidityRepartitionSupport {
  isValid: boolean;
  errorMessage: string;
}

export class RepartitionSupportWithValidity {
  repartitionSupport: RepartitionSupport;
  validity: ValidityRepartitionSupport;
}
