import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChanges } from '@angular/core';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import {
  RepartitionSupportWithValidity,
  ValidityRepartitionSupport
} from '@app/modules/arbitrage/arbitrage-partiel/arbitrage-partiel.component';
import { Subscription } from 'rxjs';
import { JahiaService } from '@ag2rlamondiale/jahia-ng';


@Component({
  selector: 'app-arbitrage-partiel-support',
  templateUrl: './arbitrage-partiel-support.component.html',
  styleUrls: ['./arbitrage-partiel-support.component.scss']
})
export class ArbitragePartielSupportComponent implements OnInit, OnChanges, OnDestroy {
  @Input()
  support: RepartitionSupport;
  @Input()
  isEnEuros = false;

  @Output()
  onRepartitionChange = new EventEmitter<RepartitionSupportWithValidity>();

  valueFromInput: number;
  placeHolder: string;
  symbol: any;
  montantDesinvestiText: string;
  pourcentageDesinvestiText: string;
  errorMessagePourcentage: string;
  errorMessageMontant: string;
  subscriptions: Subscription[] = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly jahiaService: JahiaService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.jahiaService.getDico('dictionnaireArbitrage').subscribe(dico => {
        this.montantDesinvestiText = dico.get('ARB_REPARTITION_PARTIELLE_MONTANT_DESINVESTI');
        this.pourcentageDesinvestiText = dico.get('ARB_REPARTITION_PARTIELLE_POURCENTAGE_DESINVESTI');
        this.errorMessageMontant = dico.get('ARB_REPARTITION_PARTIELLE_ERROR_MONTANT');
        this.errorMessagePourcentage = dico.get('ARB_REPARTITION_PARTIELLE_ERROR_POURCENTAGE');

        this.placeHolder = this.isEnEuros ? this.montantDesinvestiText : this.pourcentageDesinvestiText;
        this.symbol = this.isEnEuros ? '&euro;' : '%';
      })
    );
  }

  checkMontantValidator() {
    const repartition: RepartitionSupport = new RepartitionSupport();
    repartition.nom = this.support.nom;
    repartition.id = this.support.id;
    repartition.montant = this.valueFromInput;

    let validator: ValidityRepartitionSupport = {
      isValid: true,
      errorMessage: null
    };

    if (this.valueFromInput > this.support.montant) {
      validator = {
        isValid: false,
        errorMessage: this.errorMessageMontant
      };
    }

    this.onRepartitionChange.emit({repartitionSupport: repartition, validity: validator});

    return validator;
  }


  checkPercentageValidator() {
    const repartition: RepartitionSupport = new RepartitionSupport();
    repartition.nom = this.support.nom;
    repartition.id = this.support.id;
    repartition.pourcentage = this.valueFromInput;

    let validity: ValidityRepartitionSupport = {
      isValid: true,
      errorMessage: null
    };

    if (this.valueFromInput > 100) {
      validity = {
        isValid: false,
        errorMessage: this.errorMessagePourcentage
      };
    }
    this.onRepartitionChange.emit({repartitionSupport: repartition, validity});

    return validity;
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.placeHolder = this.isEnEuros ? this.montantDesinvestiText : this.pourcentageDesinvestiText;
    this.symbol = this.isEnEuros ? '&euro;' : '%';
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}

