import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { QuestionState, Reponse } from '@app/models/question-responses.model';
import { ModeGestionMdproType } from '@app/models/client/gestion-financiere.model';
import { ConsentementEvent } from '@app/modules/arbitrage/arbitrage-consentement/arbitrage-consentement.component';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Observable } from 'rxjs';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { map } from 'rxjs/operators';
import { SetConsentementAccept } from '@app/actions/arbitrage.action';

@Component({
  selector: 'app-arbitrage-mdp-choix-mode-gestion',
  templateUrl: './arbitrage-mdp-choix-mode-gestion.component.html',
  styleUrls: ['./arbitrage-mdp-choix-mode-gestion.component.scss']
})
export class ArbitrageMdpChoixModeGestionComponent implements OnInit {

  @Input() questionState: QuestionState<ModeGestionMdproType>;

  @Output() optionSelected = new EventEmitter<{ reponse: Reponse, goToNext: boolean }>();

  reponseTemporaire: Reponse<ModeGestionMdproType>;

  arbitrageState$: Observable<ArbitrageState>;

  constructor(
    private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.arbitrageState$ = selectArbitrage(this.store).pipe(map(x => x.arbitrage));
  }

  handleResponse(reponse: Reponse, arbitrageState: ArbitrageState) {
    this.reponseTemporaire = reponse;
    // Faire dispatch() au début pour faire bouger le store avant d'emettre la réponse, sinon ça bloque canNext()
    this.store.dispatch(new SetConsentementAccept({perteGestionPilotee: undefined}));
    if (this.reponseTemporaire.value === 'LIBRE' && this.showConsentement(arbitrageState)) {
      this.optionSelected.emit({reponse: null, goToNext: false});
    } else {
      this.optionSelected.emit({
        reponse: this.reponseTemporaire,
        goToNext: !this.isConsentementAffichable(arbitrageState)
      });
    }
  }

  handleCheckConsentement(consentementEvent: ConsentementEvent) {
    this.store.dispatch(new SetConsentementAccept({perteGestionPilotee: consentementEvent.accepted}));
    if (this.reponseTemporaire && consentementEvent.accepted) {
      this.optionSelected.emit({reponse: this.reponseTemporaire, goToNext: false});
    } else {
      this.optionSelected.emit(null);
    }
  }

  showConsentement(arbitrage: ArbitrageState) {
    if (!this.reponseTemporaire) {
      return false;
    }
    const modeGestionCible = this.reponseTemporaire.value;
    return modeGestionCible === 'LIBRE' && this.isConsentementAffichable(arbitrage);
  }

  isConsentementAffichable(arbitrage: ArbitrageState) {
    const modeGestionSource = arbitrage.contratSelected.gestionFinanciereActuelleMdp.modeGestionMDPROSource;
    return modeGestionSource === 'PILOTEE' || modeGestionSource === 'HORIZON';
    // return true;
  }

}
