import { Component, OnDestroy, OnInit } from '@angular/core';
import { ArbitrageEtapeComponent } from '@app/modules/arbitrage/arbitrage-etape-component';
import {
  ConsentementId,
  ConsentementsMdp,
  EngagementsEre,
  Etape1,
  Etape2,
  EtapeArbitrage,
  getQuestionsOrNextFromEtape,
  isQuestionEtapesPrecedentesRepondues,
  QuestionModel,
  QuestionsReellesERE,
  ResponseArbitrageEurosPourcentageType
} from '@app/models/client/arbitrage.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { QuestionType, Reponse } from '@app/models/question-responses.model';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ActivatedRoute, Router } from '@angular/router';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import {
  GetArbitrageQuestionOrNext,
  PushChoixDesinvestissement,
  PushChoixRepartitionSupport,
  PushReponse
} from '@app/actions/arbitrage.action';
import { ResultatRepartitionSupport } from '@app/modules/ecrs-common/components/ecrs-repartition-financiere-contrat/ecrs-repartition-financiere-contrat.component';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { filter } from 'rxjs/operators';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { ConsentementEvent } from '@app/modules/arbitrage/arbitrage-consentement/arbitrage-consentement.component';

@Component({
  selector: 'app-arbitrage-ere-choix-repartition',
  templateUrl: './arbitrage-ere-choix-repartition.component.html',
  styleUrls: ['./arbitrage-ere-choix-repartition.component.scss']
})
export class ArbitrageEreChoixRepartitionComponent implements OnInit, OnDestroy, ArbitrageEtapeComponent {

  questionToShow: QuestionType;

  questions: QuestionModel;
  contrat: MiniContrat;
  loading = false;
  reponseTemporaire: Reponse;
  showRepartitionActuelle = false;
  onlyPourcentage = false;
  choixEuroPourcent: ResponseArbitrageEurosPourcentageType;
  etapeCourante = Etape1;
  accordionOpen = false;
  qadCodesProposition: string[] = [];


  arbitragesClient: ArbitrageClient[];
  nouvellesRepartitions: Map<ArbitrageClient, RepartitionSupport[]>;
  desinvestissements: Map<ArbitrageClient, RepartitionSupport[]>;

  consentementsMdpTemporaire: ConsentementsMdp;
  showConsementsMdp: ConsentementsMdp;

  engagementsEreTemporaire: EngagementsEre = new EngagementsEre();
  showEngagementsERE: EngagementsEre;

  private readonly subscriptions = [];

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly routeEtape: ArbitrageRouteEtapeService,
    private readonly arbitrageStateService: ArbitrageStateService) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.arbitrageStateService.createArbitragesClient$().subscribe(),

      selectArbitrage(this.store).pipe(
        filter(x => !!x.arbitrage.arbitragesClient)
      ).subscribe(x => {
        this.questions = x.arbitrage.questions;
        this.contrat = x.arbitrage.contratSelected.contrat;
        this.questionToShow = x.arbitrage.questionToShow;
        this.reponseTemporaire = null;
        this.showConsementsMdp = this.initShowConsentementsMdp(x.arbitrage);
        this.showEngagementsERE = this.initShowEngagementEre(x.arbitrage);
        this.consentementsMdpTemporaire = Object.assign(new ConsentementsMdp(), x.arbitrage.consentementsMdp);

        if (x.qad.codesSupportsRecommandes) {
          this.qadCodesProposition = x.qad.codesSupportsRecommandes;
        }
        if (isQuestionEtapesPrecedentesRepondues(this.questions, this.etapeCourante, this.contrat.codeSilo)) {
          const {loading} = getQuestionsOrNextFromEtape(this.store, this.etapeCourante, x.arbitrage);

          this.arbitragesClient = x.arbitrage.arbitragesClient;
          this.nouvellesRepartitions = new Map<ArbitrageClient, RepartitionSupport[]>();
          this.desinvestissements = new Map<ArbitrageClient, RepartitionSupport[]>();

          this.showRepartitionActuelle = this.isEncoursNonNul();

          if (this.questions.choixEurosPourcent.choix) {
            this.onlyPourcentage = this.questions.choixEurosPourcent.choix.value === 'ARBITRAGE_POURCENTAGE';
          } else {
            this.onlyPourcentage = false;
          }
          this.loading = loading;
        }
      })
    );
  }

  pushReponse(reponse: Reponse, questionType = this.questionToShow) {
    this.store.dispatch(new PushReponse({questionType, reponse}));
  }

  currentQuestion() {
    if (this.questions && this.questionToShow && this.etapeCourante.questionsType[this.contrat.codeSilo].includes(this.questionToShow)) {
      return this.questions.fromType(this.questionToShow);
    }
    return null;
  }

  saveResponse($event: Reponse, questionType: QuestionType) {
    this.reponseTemporaire = $event;
    if (questionType === 'ARBITRAGE_CHOIX_TOTALPARTIEL') {
      this.goToNext(this.etapeCourante);
    }
  }

  canNext(etapeCourante: EtapeArbitrage): boolean {
    if (this.questions && this.questionToShow && this.questionToShow === 'ARBITRAGE_CHOIX_TOTALPARTIEL') {
      return this.reponseTemporaire !== null;
    }
    if (this.questions && this.questionToShow === 'ARBITRAGE_CHOIX_DESINVESTISSEMENT') {
      return this.desinvestissements.size === this.arbitragesClient.filter(e => e.impossible === false).length;
    }
    if (this.questions && this.questionToShow === 'ARBITRAGE_CHOIX_REPARTITION') {
      const consentementsAcceptes = this.consentementsMdpAcceptes() && this.engagementEREAcceptes();
      return this.nouvellesRepartitions.size === this.arbitragesClient.filter(e => e.impossible === false && e.hasNewRepartitionDifferentThanCurrent).length
        && this.nouvellesRepartitions.size !== 0
        && consentementsAcceptes;
    }
    return this.questions.choixTotalPartiel.choix != null && this.questions.choixDesinvestissement.choix !== null && this.questions.choixRepartition.choix !== null;
  }

  consentementsMdpAcceptes(): boolean {
    if (this.consentementsMdpTemporaire === null || this.showConsementsMdp === null) {
      return true;
    }

    if (this.showConsementsMdp.supportsInvestissement && !this.consentementsMdpTemporaire.supportsInvestissement) {
      return false;
    }
    if (this.showConsementsMdp.formulaireDechargePerp && !this.consentementsMdpTemporaire.formulaireDechargePerp) {
      return false;
    }
    if (this.showConsementsMdp.tutelle && !this.consentementsMdpTemporaire.tutelle) {
      return false;
    }

    return true;
  }

  engagementEREAcceptes(): boolean {
    if (this.engagementsEreTemporaire === null || this.showEngagementsERE === null) {
      return true;
    }

    if (this.showEngagementsERE.connaissanceGestionFinanciere && !this.engagementsEreTemporaire.connaissanceGestionFinanciere) {
      return false;
    }
    if (this.showEngagementsERE.connaissanceGestionFinanciereEtSupportsUC && !this.engagementsEreTemporaire.connaissanceGestionFinanciereEtSupportsUC) {
      return false;
    }
    if (this.showEngagementsERE.certificationRenseignement && !this.engagementsEreTemporaire.certificationRenseignement) {
      return false;
    }

    return true;
  }

  goToNext(etapeCourante: EtapeArbitrage): void {
    if (this.questionToShow && this.reponseTemporaire) {
      this.pushReponse(this.reponseTemporaire);
    }
    // a revoir quand on aura complete
    switch (this.questionToShow) {
      case 'ARBITRAGE_CHOIX_TOTALPARTIEL':
        this.store.dispatch(new GetArbitrageQuestionOrNext({
          questionType: 'ARBITRAGE_CHOIX_EUROSPOURCENT',
          questionTypeList: QuestionsReellesERE,
          contexte: this.questions.toContexte(this.contrat)
        }));
        break;

      case 'ARBITRAGE_CHOIX_DESINVESTISSEMENT':
        this.arbitragesClient.filter(e => e.impossible).forEach(a => this.desinvestissements.set(a, []));
        this.store.dispatch(new PushChoixDesinvestissement({
          reponse: this.desinvestissements
        }));

        if (this.choixEuroPourcent) {
          this.store.dispatch(new PushReponse({
            questionType: 'ARBITRAGE_CHOIX_EUROSPOURCENT',
            reponse: {value: this.choixEuroPourcent}
          }));
        }
        break;

      case 'ARBITRAGE_CHOIX_REPARTITION':
        this.arbitragesClient.filter(e => e.impossible).forEach(a => this.nouvellesRepartitions.set(a, []));
        this.store.dispatch(new PushChoixRepartitionSupport({
          reponse: this.nouvellesRepartitions,
          consentementsMdp: this.consentementsMdpTemporaire
        }));
        break;

      default:
        this.routeEtape.navigateToEtape(Etape2);
        break;
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  updateRepartitionPartiel(
    event: { repartitions: RepartitionSupport[], valid: boolean },
    arbitrageClient: ArbitrageClient) {

    if (event.valid) {
      this.desinvestissements.set(arbitrageClient, event.repartitions);
    } else {
      this.desinvestissements.delete(arbitrageClient);
    }
  }

  updateAccordionStatus() {
    this.accordionOpen = !this.accordionOpen;
  }

  updateChoixRepartition(
    arbitrageClient: ArbitrageClient, choix: ResultatRepartitionSupport) {
    if (!arbitrageClient) {
      return;
    }

    const ac = arbitrageClient.clone();
    ac.hasNewRepartitionDifferentThanCurrent = this.checkIfDifferentThanCurrentRepartition(
      arbitrageClient,
      choix);

    this.arbitragesClient = this.arbitragesClient.map(e => e === arbitrageClient ? ac : e);

    this.nouvellesRepartitions.delete(arbitrageClient);
    if (choix && choix.state === 'complete' && choix.repartitions.length > 0) {
      this.nouvellesRepartitions.set(ac, choix.repartitions);
    } else {
      this.nouvellesRepartitions.delete(ac);
    }
  }

  supportsRecommandes() {
    return this.qadCodesProposition;
  }

  checkIfDifferentThanCurrentRepartition(arbitrageClient: ArbitrageClient, choix: ResultatRepartitionSupport): boolean {
    let isNewRepartitionDifferentThanCurrent = true;
    if (arbitrageClient.desinvestissement.desinvestissementsSupport && arbitrageClient.desinvestissement.desinvestissementsSupport.length > 0) {
      if (arbitrageClient.desinvestissement.desinvestissementsSupport.filter(e => e.montant !== 0).length !== choix.repartitions.filter(
        e => e.selectionned).length) {
        return true;
      }
      choix.repartitions.filter(e => e.selectionned).forEach(supportFromNewRepartition => {
        const supportDesinvesti = arbitrageClient.desinvestissement.desinvestissementsSupport.find(value => value.id === supportFromNewRepartition.id);
        if (supportDesinvesti) {
          isNewRepartitionDifferentThanCurrent = supportDesinvesti.montant !== supportFromNewRepartition.montant;
        }
      });
    } else {
      if (arbitrageClient.repartitionActuelle.repartitions.length !== choix.repartitions.filter(e => e.selectionned).length) {
        return true;
      }
      choix.repartitions.filter(e => e.selectionned).forEach(supportFromNewRepartition => {
        const supportFromRepartitionActuelle = arbitrageClient.repartitionActuelle.repartitions.find(value1 => value1.id === supportFromNewRepartition.id);
        if (supportFromRepartitionActuelle) {
          isNewRepartitionDifferentThanCurrent = (supportFromRepartitionActuelle.pourcentage * 100) !== supportFromNewRepartition.pourcentage;
        } else {
          isNewRepartitionDifferentThanCurrent = true;
        }
      });
    }
    return isNewRepartitionDifferentThanCurrent;
  }

  updateEuroPourcent($event: ResponseArbitrageEurosPourcentageType) {
    if (this.onlyPourcentage) {
      this.choixEuroPourcent = 'ARBITRAGE_POURCENTAGE';
    } else {
      this.choixEuroPourcent = $event;
    }
  }

  handleSetConsentementMdp(consentementId: ConsentementId, $event: ConsentementEvent) {
    this.consentementsMdpTemporaire[consentementId] = $event.enabled ? $event.accepted : undefined;
  }

  handleSetEngagementERE(consentementId: ConsentementId, $event: ConsentementEvent) {
    this.engagementsEreTemporaire[consentementId] = $event.enabled ? $event.accepted : undefined;
  }

  arbitrageClient(index: number, arbitrageClient: ArbitrageClient) {
    return arbitrageClient.ordre;
  }

  private isEncoursNonNul() {
    if (this.questions.choixCompartimentERE.choix.value.tousCompartiments) {
      return this.questions.choixCompartimentERE.choix.value.encours.montantEncours !== 0;
    }
    return this.questions.choixCompartimentERE.choix.value.compartiment.encours.montantEncours !== 0;
  }

  private initShowConsentementsMdp(arbitrage: ArbitrageState) {
    if (arbitrage.contratSelected.contrat.codeSilo !== 'MDP') {
      return null;
    }

    const res = new ConsentementsMdp();

    const modeGestionCible = arbitrage.questions.choixModeGestion.value;
    res.formulaireDechargePerp = arbitrage.contratSelected.gestionFinanciereActuelleMdp.fiscalitePERP && (modeGestionCible === 'DYNAMISATION' || modeGestionCible === 'LIBRE');

    res.supportsInvestissement = true;
    res.tutelle = true;

    return res;
  }

  private initShowEngagementEre(arbitrage: ArbitrageState) {
    if (arbitrage.contratSelected.contrat.codeSilo !== 'ERE') {
      return null;
    }

    const res = new EngagementsEre();

    let hasUniteDeCompte = false;
    for (let i = 0; i < arbitrage.arbitragesClient.length; i++) {
      const arbitrageClient = arbitrage.arbitragesClient[i];
      if (arbitrageClient.hasUniteDeCompte) {
        hasUniteDeCompte = true;
        break;
      }
    }

    res.connaissanceGestionFinanciereEtSupportsUC = hasUniteDeCompte;
    res.connaissanceGestionFinanciere = !hasUniteDeCompte;
    res.certificationRenseignement = true;

    return res;
  }
}
