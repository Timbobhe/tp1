import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  Etape0,
  Etape1,
  EtapeArbitrage,
  getQuestionsOrNextFromEtape,
  InfoArbitrageContrat,
  isQuestionEnAttenteDeReponse,
  isToutesQuestionsRepondues,
  QuestionModel
} from '@app/models/client/arbitrage.model';
import { MiniContrat } from '@app/models/client/contrat.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { QuestionType, Reponse } from '@app/models/question-responses.model';
import { PushReponse } from '@app/actions/arbitrage.action';
import { ArbitrageEtapeComponent } from '@app/modules/arbitrage/arbitrage-etape-component';
import { ActivatedRoute, Router } from '@angular/router';
import { ArbitrageRouteEtapeService } from '@app/modules/arbitrage/arbitrage-route-etape.service';
import { ArbitrageStateService } from '@app/modules/arbitrage/arbitrage-state.service';
import { ResetStateAction } from '@app/actions/global.actions';
import { Context } from '@ag2rlamondiale/jahia-ng';

@Component({
  selector: 'app-arbitrage-ere-choix-arbitrage',
  templateUrl: './arbitrage-ere-choix-arbitrage.component.html',
  styleUrls: ['./arbitrage-ere-choix-arbitrage.component.scss']
})
export class ArbitrageEreChoixArbitrageComponent implements OnInit, OnDestroy, ArbitrageEtapeComponent {
  contexte: Context = new Context();

  questionToShow: QuestionType;
  questions: QuestionModel;
  contrat: MiniContrat;
  loading = false;
  reponseTemporaire: Reponse;
  infoArbitrageContrat: InfoArbitrageContrat;
  subscriptions = [];
  preselected: boolean;

  etapeCourante = Etape0;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute,
    private readonly routeEtape: ArbitrageRouteEtapeService,
    private readonly arbitrageStateService: ArbitrageStateService) {
  }

  ngOnInit() {
    this.subscriptions.push(selectArbitrage(this.store).subscribe(x => {
      this.questions = x.arbitrage.questions;
      this.infoArbitrageContrat = x.arbitrage.contratSelected;
      this.contrat = x.arbitrage.contratSelected.contrat;
      this.questionToShow = x.arbitrage.questionToShow;
      this.reponseTemporaire = null;
      if (this.infoArbitrageContrat.parcoursSimplifie) {
        const contextValue = this.infoArbitrageContrat.nbArbitrageAnnee === 1 ? 'qu\'une seule ' : 'que ' + this.infoArbitrageContrat.nbArbitrageAnnee;
        this.contexte.set('nbModifAnnee', contextValue);
      }
      getQuestionsOrNextFromEtape(this.store, this.etapeCourante, x.arbitrage);
      this.arbitrageStateService.dispatchGestionsFinancieres(x.arbitrage);
    }));
  }

  pushReponse(reponse: Reponse, questionType = this.questionToShow) {
    this.store.dispatch(new PushReponse({questionType, reponse}));
  }

  canNext(etapeCourante: EtapeArbitrage): boolean {
    if (isQuestionEnAttenteDeReponse(this.questions,
      this.questionToShow,
      etapeCourante.questionsType[this.contrat.codeSilo])) {
      return this.reponseTemporaire !== null;
    } else if (isToutesQuestionsRepondues(this.questions, etapeCourante.questionsType[this.contrat.codeSilo])) {
      return true;
    }
    return false;
  }

  goToNext(etapeCourante: EtapeArbitrage): void {
    if (this.questionToShow && this.reponseTemporaire) {
      this.pushReponse(this.reponseTemporaire);
    }
    switch (this.questionToShow) {
      case 'ARBITRAGE_CHOIX_COMPARTIMENT':
        this.store.dispatch(new ResetStateAction({qad: {}}));
        break;

      case 'ARBITRAGE_CHOIX_MODEGESTION':
        break;

      case 'ARBITRAGE_CHOIX_FLUXSTOCK':
      default:
        this.routeEtape.navigateToEtape(Etape1);
        break;
    }
  }

  currentQuestion() {
    if (isQuestionEnAttenteDeReponse(this.questions,
      this.questionToShow,
      this.etapeCourante.questionsType[this.contrat.codeSilo])) {
      return this.questions.fromType(this.questionToShow);
    }
    return null;
  }

  saveResponse($event: { reponse: Reponse, goToNext: boolean }, questionType: QuestionType) {
    this.reponseTemporaire = $event.reponse;
    if (questionType !== 'ARBITRAGE_CHOIX_FLUXSTOCK' && $event.goToNext !== false) {
      this.goToNext(this.etapeCourante);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}
