import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';
import {
  PushContratSelected,
  SetParcoursManuscritArbitrage,
  SetSubtitleArbitrage
} from '@app/actions/arbitrage.action';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';

@Injectable({
  providedIn: 'root'
})
export class ContratUniqueGuard implements CanActivate {
  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return selectArbitrage(this.store).pipe(
      take(1),
      map(x => {
        return {arbitrages: x.arbitrage.arbitrageModel.arbitrages};
      }),
      map(x => {
        const list = x.arbitrages;

        if (list && list.length === 1 && !list[0].bloque && list[0].qadStatus !== 'OBLIGATOIRE') {
          if (list[0].sigElecOff) {
            this.store.dispatch(new SetParcoursManuscritArbitrage(true));
          }

          this.store.dispatch(new PushContratSelected({info: list[0], setSubtitle: true}));
          this.router.navigate(['/modification-gestion-financiere/etape/choix-arbitrage'],
            {replaceUrl: false, queryParamsHandling: 'preserve'});
          return false;
        } else {
          this.store.dispatch(new SetSubtitleArbitrage({id: null}));
        }

        return true;
      })
    );
  }
}
