import {Component, OnDestroy, OnInit} from '@angular/core';
import { OperationType } from '@app/models/client/operation.model';
import { DemandeSigElec } from '@app/actions/sig-elec.action';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-arbitrage-demsigelec',
  templateUrl: './arbitrage-demsigelec.component.html',
  styleUrls: ['./arbitrage-demsigelec.component.scss']
})
export class ArbitrageDemsigelecComponent implements OnInit, OnDestroy {

  fonctionnalite: OperationType = 'ARBI';
  demandeEncours: DemandeSigElec;
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>) {
  }

  ngOnInit() {
    this.subscriptions.push(
      this.store.select('sigElec').subscribe(sigDem => {
        if (sigDem.demande != null) {
          this.demandeEncours = sigDem.demande;
        }
      })
    );
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

}
