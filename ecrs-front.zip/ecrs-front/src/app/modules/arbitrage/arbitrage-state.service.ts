import { ImpersonationService } from '@ag2rlamondiale/transverse-metier-ng';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { PostArbitrageTerminate, SetArbitragesClient } from '@app/actions/arbitrage.action';
import {
  GestionFinanciereActuelleCompartimentFetch,
  GestionFinanciereActuelleContratFetch,
  GestionFinanciereActuellePayload,
  GestionFinanciereCompartimentFetch,
  GestionFinanciereContratFetch,
  GestionFinancierePayload
} from '@app/actions/gestion-financiere.actions';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { ArbitrageTerminateModel, hashCompartimentIds } from '@app/models/client/arbitrage.model';
import { CodeSiloERE, CodeSiloMDP, ContratId, toCompartimentId } from '@app/models/client/contrat.model';
import { GestionFinanciereCompartiments } from '@app/models/client/gestion-financiere.model';
import { InfoQad } from '@app/models/client/qad.model';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { selectArbitrage, selectArbitrageGestionFinanciere } from '@app/reducers/ecrs.selectors';
import { QadState } from '@app/reducers/qad.reducer';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { filter, map, tap } from 'rxjs/operators';
// @ts-ignore
import documentStyle from '../../../styles/document/arbitrage-document.css';
// @ts-ignore
import qadDocumentStyle from '../../../styles/document/base-document.css';
import { HideMenu, SetContratCompteDemo, SetParcoursUrl } from '@app/actions/ui.actions';
import { ClientInfoState } from '@app/reducers/client-infos.reducer';

@Injectable({
  providedIn: 'root'
})
export class ArbitrageStateService {

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly impersonationService: ImpersonationService) {
  }

  infoQadLauncher$(): Observable<InfoQad> {
    return selectArbitrage(this.store).pipe(
      filter(x => !!x.arbitrage.contratSelected),
      map(x => this.toInfoQad(x.arbitrage))
    );
  }

  infoQadAutoLaunch$(): Observable<InfoQad> {
    return selectArbitrage(this.store).pipe(
      filter(x => {
        return x.arbitrage.contratSelected && x.arbitrage.contratSelected.qadStatus === 'OBLIGATOIRE';
      }),
      map(x => this.toInfoQad(x.arbitrage))
    );
  }

  private toInfoQad(arbitrage: ArbitrageState) {
    let contratId: ContratId = null;

    // MDP
    if (arbitrage.contratSelected && arbitrage.contratSelected.contrat.codeSilo === 'MDP') {
      contratId = arbitrage.contratSelected.contrat;
      return {qadLauncherEligible: false, contratId};
    }

    // ERE
    let codesSupportsContrat = [];
    let qadEligible = false;
    let compartimentId = null;

    const choixCompartiment = arbitrage.questions.choixCompartimentERE;
    if (arbitrage.contratSelected && arbitrage.contratSelected.contrat.codeSilo === 'ERE' && choixCompartiment.choix) {
      contratId = arbitrage.contratSelected.contrat;
      const tousCompartiments = choixCompartiment.choix.value.tousCompartiments;

      if (
        !tousCompartiments &&
        arbitrage.gestionFinanciereCompartiment &&
        arbitrage.gestionFinanciereCompartiment.data
      ) {
        compartimentId = toCompartimentId(choixCompartiment.choix.value.compartiment);
        qadEligible = arbitrage.gestionFinanciereCompartiment.data.qadEligible;
        codesSupportsContrat = arbitrage.gestionFinanciereCompartiment.data.grillesProfilsNiveau1.map(s => s.id);
      } else if (tousCompartiments && arbitrage.gestionFinanciereContrat && arbitrage.gestionFinanciereContrat.data) {
        arbitrage.gestionFinanciereContrat.data.listePourCompartiments.forEach(e => {
          if (e.gestionFinanciere.qadEligible) {
            qadEligible = true;
            e.gestionFinanciere.grillesProfilsNiveau1.forEach(s => codesSupportsContrat.push(s.id));
          }
        });
      }
    }

    return qadEligible
      ? {
        qadLauncherEligible: qadEligible,
        contratId,
        codesSupportsContrat,
        compartimentId
      }
      : null;
  }

  dispatchGestionsFinancieres(arbitrage: ArbitrageState) {
    const questions = arbitrage.questions;
    const contrat = arbitrage.contratSelected.contrat;

    const gestionFinanciereActuellePayload = new GestionFinanciereActuellePayload();
    gestionFinanciereActuellePayload.contratId = contrat;
    const gestionFinancierePayload = new GestionFinancierePayload();
    gestionFinancierePayload.fonctionnalite = 'Arbitrage';
    gestionFinancierePayload.gerePlacementsFinanciersDifferentsAutorises = true;
    gestionFinancierePayload.contratId = contrat;
    const listeActions = [];
    const choixCompartiment = questions.choixCompartimentERE.choix;
    // Choix compartiment
    if (choixCompartiment) {
      gestionFinanciereActuellePayload.tousCompartimentsSelected = choixCompartiment.value.tousCompartiments;
      gestionFinanciereActuellePayload.placementsFinanciersDifferentsAutorises =
        choixCompartiment.value.placementsFinanciersDifferentsAutorises;
      if (!choixCompartiment.value.tousCompartiments) {
        gestionFinanciereActuellePayload.compartimentId = toCompartimentId(choixCompartiment.value.compartiment);
        gestionFinancierePayload.compartimentId = toCompartimentId(choixCompartiment.value.compartiment);
      }
      // Choix Mode Gestion
      if (questions.choixModeGestion.choix && arbitrage.contratSelected.contrat.codeSilo === CodeSiloMDP) {
        gestionFinancierePayload.modeGestion = questions.choixModeGestion.choix.value;
      }
      // Push des actions
      if (!arbitrage.gestionFinanciereActuelleContrat && !arbitrage.gestionFinanciereActuelleCompartiment) {
        if (choixCompartiment && choixCompartiment.value.tousCompartiments) {
          listeActions.push(new GestionFinanciereActuelleContratFetch(gestionFinanciereActuellePayload));
        } else {
          listeActions.push(new GestionFinanciereActuelleCompartimentFetch(gestionFinanciereActuellePayload));
        }
      }
      const isMDP = questions.choixModeGestion.choix && arbitrage.contratSelected.contrat.codeSilo === CodeSiloMDP;
      const isERE = arbitrage.contratSelected.contrat.codeSilo === CodeSiloERE;
      if (!arbitrage.gestionFinanciereCompartiment && !arbitrage.gestionFinanciereContrat && (isMDP || isERE)) {
        if (choixCompartiment && choixCompartiment.value.tousCompartiments) {
          listeActions.push(new GestionFinanciereContratFetch(gestionFinancierePayload));
        } else {
          listeActions.push(new GestionFinanciereCompartimentFetch(gestionFinancierePayload));
        }
      }
    }
    // Dispatch
    listeActions.forEach(action => this.store.dispatch(action));
  }

  createArbitragesClient$(): Observable<ArbitrageClient[]> {
    return selectArbitrageGestionFinanciere(this.store).pipe(
      tap(arbitrage => {
        if (arbitrage.arbitragesClient) {
          return;
        }

        if (arbitrage.gestionFinanciereCompartiment && arbitrage.gestionFinanciereCompartiment.data) {
          const cli = new ArbitrageClient();
          cli.ordre = 0;
          cli.contrat = arbitrage.contratSelected.contrat;
          if (cli.contrat.codeSilo === 'ERE') {
            cli.hasUniteDeCompte = arbitrage.gestionFinanciereCompartiment.data.hasUniteDeCompte;
          }
          cli.compartimentIds = [toCompartimentId(arbitrage.questions.choixCompartimentERE.choix.value.compartiment)];
          cli.montantEncours = arbitrage.questions.choixCompartimentERE.choix.value.compartiment.encours.montantEncours;
          cli.repartitionActuelle.repartitions = arbitrage.gestionFinanciereActuelleCompartiment.data.gestionFinanciere.map(
            e => {
              return {...e, ...e.repartition};
            }
          );
          cli.nouvelleRepartition.propositionSupports =
            arbitrage.gestionFinanciereCompartiment.data.grillesProfilsNiveau1;
          cli.typeArbitrage = arbitrage.questions.choixFluxStock.choix;
          cli.montantARepartir = cli.calculerMontantARepartir();
          this.store.dispatch(new SetArbitragesClient([cli]));
        } else if (arbitrage.gestionFinanciereActuelleContrat && arbitrage.gestionFinanciereActuelleContrat.data) {
          const arbitragesClient: ArbitrageClient[] = [];
          arbitrage.gestionFinanciereActuelleContrat.data.listePourCompartiments.forEach((gfac, index) => {
            const cli = new ArbitrageClient();
            cli.ordre = index;
            cli.contrat = arbitrage.contratSelected.contrat;

            cli.compartimentIds = gfac.compartimentIds;
            cli.montantEncours = gfac.montantARepartir;
            cli.repartitionActuelle.repartitions = gfac.gestionFinanciere.map(e => {
              return {...e, ...e.repartition};
            });
            let gestFinComp: GestionFinanciereCompartiments;
            if (
              arbitrage.gestionFinanciereContrat.data.listePourCompartiments.length === 1 &&
              arbitrage.gestionFinanciereActuelleContrat.data.listePourCompartiments.length === 1
            ) {
              gestFinComp = arbitrage.gestionFinanciereContrat.data.listePourCompartiments[0];
            } else {
              gestFinComp = arbitrage.gestionFinanciereContrat.data.listePourCompartiments.find(e => {
                return hashCompartimentIds(e.compartimentIds) === hashCompartimentIds(gfac.compartimentIds);
              });
            }
            if (gestFinComp) {
              cli.nouvelleRepartition.propositionSupports = gestFinComp.gestionFinanciere.grillesProfilsNiveau1;
              if (cli.contrat.codeSilo === 'ERE') {
                cli.hasUniteDeCompte = gestFinComp.gestionFinanciere.hasUniteDeCompte;
              }
            }
            cli.typeArbitrage = arbitrage.questions.choixFluxStock.choix;
            cli.montantARepartir = cli.calculerMontantARepartir();
            if (cli.montantARepartir === 0) {
              cli.impossible = true;
            }
            arbitragesClient.push(cli);
          });
          this.store.dispatch(new SetArbitragesClient(arbitragesClient));
        }
      }),
      map(arbitrage => arbitrage.arbitragesClient)
    );
  }

  endArbitrageWithSigElec(arbitrage: ArbitrageState, qad: QadState, infoClient: ClientInfoState) {
    this.impersonationService.protect('Signature électronique de l\'Arbitrage', () => {
      const bodyDocument: HTMLCollectionOf<Element> = document.getElementsByClassName('confirmation-choix-client');
      const arbitrageTerminate = new ArbitrageTerminateModel();
      arbitrageTerminate.contratSelected = arbitrage.contratSelected.contrat;
      arbitrageTerminate.arbitragesClient = arbitrage.arbitragesClient.map(e => e.clone().clean());
      arbitrageTerminate.contenuArbitrage = {
        htmlStyle: documentStyle,
        htmlContent: bodyDocument.item(0).innerHTML
      };
      if (qad && qad.htmlContent) {
        arbitrageTerminate.contenuQad = {
          htmlStyle: qadDocumentStyle,
          htmlContent: qad.htmlContent
        };
      }
      const postArbitrageTerminate = new PostArbitrageTerminate(arbitrageTerminate);
      postArbitrageTerminate.payload.onSuccess = data => {
        window.location.assign(data);
      };
      if (!infoClient.compteDemo) {
        this.store.dispatch(postArbitrageTerminate);
      } else {
        this.store.dispatch(new HideMenu(true));
        this.store.dispatch(new SetParcoursUrl('modification-gestion-financiere'));
        this.store.dispatch(new SetContratCompteDemo(arbitrage.contratSelected.contrat.nomContrat));
        this.router.navigate(['/compte-demo']);
      }
    });
  }
}
