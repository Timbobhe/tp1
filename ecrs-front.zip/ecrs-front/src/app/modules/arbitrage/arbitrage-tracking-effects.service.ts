import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { filter, map, mergeMap, take } from 'rxjs/operators';
import { Categorie, SetTrackingEnvTemplate, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import {
  ARBITRAGE_GOTO_ETAPE,
  ARBITRAGE_MODIFIER_REPONSE,
  ARBITRAGE_TERMINATE,
  GoToEtapeArbitrage,
  ModifierReponse,
  PUSH_CONTRAT_SELECTED,
  PushContratSelected,
  SET_PARCOURS_MANUSCRIT_ARBITRAGE,
  SetParcoursManuscritArbitrage
} from '@app/actions/arbitrage.action';
import { API, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { Etape1, Etape2, EtapeFin } from '@app/models/client/arbitrage.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { selectArbitrage } from '@app/reducers/ecrs.selectors';
import { EcrsBasicMessageService } from '@app/modules/ecrs-common/services/ecrs-basicmessage.service';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';


@Injectable({
  providedIn: 'root'
})
export class ArbitrageTrackingEffects {

  @Effect({dispatch: true})
  contrat$ = this.actions$.pipe(
    ofType(PUSH_CONTRAT_SELECTED),
    map(a => a as PushContratSelected),
    mergeMap(a => [
        new SetTrackingEnvTemplate([a.payload.info.contrat.codeSilo]),
        tracking(Categorie.arbitrage, TypeOriginAction.typeContrat, a.payload.info.contrat.nomContrat.substring(0, 3))
      ]
    )
  );

  @Effect({dispatch: true})
  manuscrit$ = this.actions$.pipe(
    ofType(SET_PARCOURS_MANUSCRIT_ARBITRAGE),
    map(a => a as SetParcoursManuscritArbitrage),
    filter(a => a.payload),
    map(a => tracking(Categorie.arbitrage, TypeOriginAction.basculeArbitrageManuscrit))
  );

  @Effect({dispatch: true})
  modifierReponseFonds$ = this.actions$.pipe(
    ofType(ARBITRAGE_MODIFIER_REPONSE),
    map(a => a as ModifierReponse),
    filter(a => a.payload.questionType === 'ARBITRAGE_CHOIX_COMPARTIMENT'),
    map(a => tracking(Categorie.arbitrage, TypeOriginAction.modifierArbitrage, 'fonds'))
  );

  @Effect({dispatch: true})
  modifierReponseRepartition$ = this.actions$.pipe(
    ofType(ARBITRAGE_MODIFIER_REPONSE),
    map(a => a as ModifierReponse),
    filter(a => a.payload.questionType === 'ARBITRAGE_CHOIX_REPARTITION'),
    map(a => tracking(Categorie.arbitrage, TypeOriginAction.modifierArbitrage, 'repartition'))
  );

  @Effect({dispatch: true})
  confirmerEtSignerElec$ = this.actions$.pipe(
    ofType(API),
    map(a => a as ApiAction),
    filter(a => a.payload.label === ARBITRAGE_TERMINATE),
    map(a => tracking(Categorie.arbitrage, TypeOriginAction.redirectionUniversign))
  );


  @Effect({dispatch: true})
  etapeArbitrage0$ = this.actions$.pipe(
    ofType(ARBITRAGE_GOTO_ETAPE),
    map(a => a as GoToEtapeArbitrage),
    filter(a => a.payload.etape === Etape1),
    mergeMap(a => selectArbitrage(this.store).pipe(
      take(1),
      mergeMap(x => {
        const choixCompartimentERE = x.arbitrage.questions.choixCompartimentERE;
        return this.basicMessageService.fromJahiaDicoEntry('dictionnaireArbitrage', choixCompartimentERE.choix).pipe(
          map(label => tracking(Categorie.arbitrage, TypeOriginAction.choixArbitreContinuerFinEtape0, label))
        );
      })
    ))
  );

  @Effect({dispatch: true})
  etapeArbitrage1$ = this.actions$.pipe(
    ofType(ARBITRAGE_GOTO_ETAPE),
    map(a => a as GoToEtapeArbitrage),
    filter(a => a.payload.etape === Etape2),
    mergeMap(a => selectArbitrage(this.store).pipe(
      take(1),
      map(x => ArbitrageTrackingEffects.trackingRepartition(
        x.arbitrage, TypeOriginAction.choixArbitreValiderFinEtape1)
      )
    ))
  );
  @Effect({dispatch: true})
  etapeArbitrage2$ = this.actions$.pipe(
    ofType(ARBITRAGE_GOTO_ETAPE),
    map(a => a as GoToEtapeArbitrage),
    filter(a => a.payload.etape === EtapeFin),
    mergeMap(a => selectArbitrage(this.store).pipe(
      take(1),
      map(x => ArbitrageTrackingEffects.trackingRepartition(
        x.arbitrage, TypeOriginAction.choixArbitreConfirmerFinEtape2)
      )
    ))
  );


  private static trackingRepartition(arbitrage: ArbitrageState, tcAction: TypeOriginAction) {
    let label: string;
    if (arbitrage.arbitragesClient.length === 1) {
      label = arbitrage.arbitragesClient[0].nouvelleRepartition.getInfosTracking().toHuman();
    } else {
      label = arbitrage.arbitragesClient.map(a => `${(this.compartLabel(a))}: ${a.nouvelleRepartition.getInfosTracking().toHuman()}`)
        .join('; ');
    }
    return tracking(Categorie.arbitrage, tcAction, label);
  }


  private static compartLabel(a: ArbitrageClient) {
    return a.compartimentIds.map(e => e.compartimentType).sort((i,
      j) => i.localeCompare(j));
  }

  constructor(
    private readonly actions$: Actions,
    private readonly store: Store<GlobalState>,
    private readonly basicMessageService: EcrsBasicMessageService) {
  }
}
