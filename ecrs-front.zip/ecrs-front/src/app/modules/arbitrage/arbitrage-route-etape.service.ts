import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Etape, EtapeArbitrage, EtapesArbitrage } from '@app/models/client/arbitrage.model';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { GoToEtapeArbitrage } from '@app/actions/arbitrage.action';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { ROUTER_NAVIGATED, RouterNavigatedAction } from '@ngrx/router-store';
import { filter, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArbitrageRouteEtapeService {

  constructor(
    private readonly actions$: Actions,
    private readonly router: Router,
    private readonly store: Store<GlobalState>) {
  }

  @Effect({dispatch: true})
  navigated$ = this.actions$.pipe(
    ofType(ROUTER_NAVIGATED),
    map(a => a as RouterNavigatedAction),
    map(a => this.findEtapeFromUrl(a.payload.event.url)),
    filter(etape => !!etape),
    map(etape => new GoToEtapeArbitrage({etape}))
  );

  navigateToEtape(etape: EtapeArbitrage) {
    const url = etape.url;

    if (url) {
      this.router.navigate([url], {queryParamsHandling: 'preserve'});
    }
  }

  findEtapeFromUrl(url: string) {
    return EtapesArbitrage.find(e => url && url.includes(e.url));
  }

  public goToEtape(etape: Etape) {
    this.store.dispatch(new GoToEtapeArbitrage({etape}));
  }
}
