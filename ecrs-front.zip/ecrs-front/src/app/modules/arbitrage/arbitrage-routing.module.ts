import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArbitrageEtapesComponent } from './arbitrage-etapes/arbitrage-etapes.component';
import { ArbitrageEreChoixArbitrageComponent } from './arbitrage-parcours-ere/arbitrage-ere-choix-arbitrage/arbitrage-ere-choix-arbitrage.component';
import { ArbitrageEreRecapSignatureComponent } from './arbitrage-parcours-ere/arbitrage-ere-recap-signature/arbitrage-ere-recap-signature.component';
import { ContratUniqueGuard } from './guards/contrat-unique.guard';
import { ResetGuard } from './guards/reset.guard';
import { ArbitrageChoixContratComponent } from './arbitrage-choix-contrat/arbitrage-choix-contrat.component';
import { ArbitrageConfirmationComponent } from './arbitrage-confirmation/arbitrage-confirmation.component';
import { ArbitrageDemandeComponent } from './arbitrage-demande/arbitrage-demande.component';
import { ArbitrageIdentiteNumComponent } from './arbitrage-identite-num/arbitrage-identite-num.component';
import { ArbitrageMatchAccountComponent } from './arbitrage-match-account/arbitrage-match-account.component';
import { ArbitrageComponent } from './arbitrage.component';
import { ArbitrageSigelecRedirectComponent } from './arbitrage-sigelec-redirect/arbitrage-sigelec-redirect.component';
import { ArbitrageDemsigelecComponent } from './arbitrage-demsigelec/arbitrage-demsigelec.component';
import { ArbitrageStateGuard } from './guards/arbitrage-state.guard';
import { ArbitrageEreChoixRepartitionComponent } from './arbitrage-parcours-ere/arbitrage-ere-choix-repartition/arbitrage-ere-choix-repartition.component';
import { ArbitrageMdpConfirmationPropositionQadComponent } from './arbitrage-mdp-confirmation-proposition-qad/arbitrage-mdp-confirmation-proposition-qad.component';
import { pieceIdentiteRoutes } from '@ag2rlamondiale/transverse-metier-ng';

const routes: Routes = [{
  path: '',
  component: ArbitrageComponent,
  canActivate: [ResetGuard],
  canActivateChild: [ArbitrageStateGuard],
  children: [
    {
      path: 'ma-demande',
      component: ArbitrageDemandeComponent
    },
    {
      path: 'validation-piece-identite',
      component: ArbitrageIdentiteNumComponent,
      children: pieceIdentiteRoutes
    },
    {
      path: 'verification-donnees-personnelles',
      component: ArbitrageMatchAccountComponent
    },
    {
      path: 'choix-contrat',
      component: ArbitrageChoixContratComponent,
      canActivate: [ContratUniqueGuard]
    },
    {
      path: 'etape',
      component: ArbitrageEtapesComponent,
      children: [
        {
          path: 'choix-arbitrage',
          component: ArbitrageEreChoixArbitrageComponent
        },
        {
          path: 'choix-repartition',
          component: ArbitrageEreChoixRepartitionComponent,
          // canActivate: [ArbitrageClientGuard],
        },
        {
          path: 'recapitulatif-signature',
          component: ArbitrageEreRecapSignatureComponent
        },
      ]
    },
    {
      path: 'signature/:status',
      component: ArbitrageSigelecRedirectComponent
    },
    {
      path: 'confirmation-proposition',
      component: ArbitrageMdpConfirmationPropositionQadComponent
    },
    {
      path: 'confirmation-manuscrit',
      component: ArbitrageConfirmationComponent
    },
    {
      path: 'demande-signature-electronique',
      component: ArbitrageDemsigelecComponent
    },
    {
      path: '**',
      redirectTo: 'ma-demande',
      pathMatch: 'full'
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ArbitrageRoutingModule {
}
