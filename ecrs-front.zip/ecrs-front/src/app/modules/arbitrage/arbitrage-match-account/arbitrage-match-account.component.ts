import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { SetParcoursManuscritArbitrage } from '@app/actions/arbitrage.action';

@Component({
  selector: 'app-arbitrage-match-account',
  templateUrl: './arbitrage-match-account.component.html',
  styleUrls: ['./arbitrage-match-account.component.scss']
})
export class ArbitrageMatchAccountComponent implements OnInit {
  matchAccount: boolean;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly activeRoute: ActivatedRoute) {
  }

  ngOnInit() {
  }

  next(manuscrit = false) {
    this.store.dispatch(new SetParcoursManuscritArbitrage(manuscrit));
    this.router.navigate(['../choix-contrat'], {relativeTo: this.activeRoute, queryParamsHandling: 'preserve'});
  }

  handleMatchAcocunt(value: boolean) {
    this.matchAccount = value;
  }
}
