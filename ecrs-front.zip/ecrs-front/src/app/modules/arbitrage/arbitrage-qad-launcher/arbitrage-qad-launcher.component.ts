import {
  AfterContentInit,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  TemplateRef
} from '@angular/core';
import { DeviceSize } from '@ag2rlamondiale/transverse-metier-ng';
import { VariantQadLauncher } from '@app/modules/qad/qad-launcher/qad-launcher.component';
import { ChoixQadMdp, InfoQad } from '@app/models/client/qad.model';
import { PrimeTemplate } from 'primeng/api';


@Component({
  selector: 'app-arbitrage-qad-launcher',
  templateUrl: './arbitrage-qad-launcher.component.html',
  styleUrls: ['./arbitrage-qad-launcher.component.scss']
})
export class ArbitrageQadLauncherComponent implements OnInit, AfterContentInit {
  @Input() device: DeviceSize;
  @Input() mode: VariantQadLauncher = 'Link';
  @Input() infoQad: InfoQad;

  @Output() onClose = new EventEmitter<boolean>();
  @Output() onChoixPropositionMdp = new EventEmitter<ChoixQadMdp>();

  linkTemplate: TemplateRef<any>;
  splashTemplate: TemplateRef<any>;
  @ContentChildren(PrimeTemplate) templates: QueryList<PrimeTemplate>;

  ngOnInit() {
  }

  ngAfterContentInit(): void {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case 'link':
          this.linkTemplate = item.template;
          break;
        case 'splash':
          this.splashTemplate = item.template;
          break;
      }
    });
  }

  get codeDocument() {
    const contrat = this.infoQad.contratId;
    if (contrat.codeSilo === 'ERE') {
      return 'QAD_EN_LIGNE';
    } else if (contrat.codeSilo === 'MDP') {
      return 'DEVOIR_CONSEIL_MDPRO_EN_LIGNE';
    }
    return null;
  }

  handleClose($event: boolean) {
    this.onClose.emit($event);
  }

  get closable(): boolean {
    return this.infoQad.contratId.codeSilo === 'ERE';
  }

  handleChoixPropositionMdp(choix: ChoixQadMdp) {
    this.onChoixPropositionMdp.emit(choix);
  }
}
