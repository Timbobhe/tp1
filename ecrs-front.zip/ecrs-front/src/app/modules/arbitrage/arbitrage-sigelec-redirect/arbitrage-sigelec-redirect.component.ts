import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

export const SIGELEC_MSG_PATH = '/sites/aqe/ecrs/arbitrage/body-content.apiV2.html.ajax?blockId=';

@Component({
  selector: 'app-arbitrage-sigelec-redirect',
  templateUrl: './arbitrage-sigelec-redirect.component.html',
  styleUrls: ['./arbitrage-sigelec-redirect.component.scss']
})
export class ArbitrageSigelecRedirectComponent implements OnInit {
  signatureStatus: string;
  urlPathPrefix: string;

  constructor(private readonly route: ActivatedRoute) {}

  ngOnInit() {
    this.signatureStatus = this.route.snapshot.params.status;
    this.urlPathPrefix = SIGELEC_MSG_PATH;
  }
}
