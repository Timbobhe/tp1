import { JahiaService } from '@ag2rlamondiale/jahia-ng';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { CreateContactReclamation } from '@app/actions/contact-reclamation.actions';
import { Categorie, tracking, TypeOriginAction } from '@app/actions/tracking.action';
import {
  ContactReclamationTerminateModel,
  Question,
  ReclamationResponseModel
} from '@app/models/client/contact-reclamation-terminate.model';
import { CodeSiloType, Contrat, siloContrat } from '@app/models/client/contrat.model';
import { ClientInfoState } from '@app/reducers/client-infos.reducer';
import { forEachEntry } from '@ag2rlamondiale/transverse-metier-ng';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { Message } from 'primeng/api';
import { Subscription } from 'rxjs';
import { ImpersonationService } from '@ag2rlamondiale/transverse-metier-ng';
import { Globals } from '@ag2rlamondiale/transverse-metier-ng';
import { selectContactReclamation } from '@app/reducers/ecrs.selectors';
import { FileUploadResponseModel } from '@ag2rlamondiale/transverse-metier-ng';
import { GetCoordonneesClient } from '@ag2rlamondiale/transverse-metier-ng';
import { CoordonneesClientState } from '@ag2rlamondiale/transverse-metier-ng';
import { CustomUploadState } from '@ag2rlamondiale/transverse-metier-ng';


@Component({
  selector: 'app-formulaire-commun',
  templateUrl: './formulaire-commun.component.html',
  styleUrls: ['./formulaire-commun.component.scss']
})
export class FormulaireCommunComponent implements OnInit, OnDestroy {

  loading = false;
  demandeEnvoyee = false;
  msgs: Message[] = [];

  tokenValid = false;
  contratMdpro = false;

  reclamation = false;
  contratSelectionne: Contrat;

  questions: Question[];
  preValidateForm: FormGroup;
  filesUploaded: FileUploadResponseModel[] = [];
  civiliteFormControl: FormControl;
  nomFormControl: FormControl;
  prenomFormControl: FormControl;
  emailFormControl: FormControl;
  telFormControl: FormControl;
  dateFormControl: FormControl;
  ObjetFormControl: FormControl;

  messageFormControl: FormControl;

  subscriptions: Subscription[] = [];
  private uploadState: CustomUploadState = CustomUploadState.EMPTY;

  constructor(
    private readonly router: Router,
    private readonly fb: FormBuilder,
    private readonly store: Store<GlobalState>,
    private readonly jahia: JahiaService,
    private readonly impersonationService: ImpersonationService,
    private readonly globals: Globals) {

    this.civiliteFormControl = new FormControl({value: '', disabled: true});
    this.nomFormControl = new FormControl({value: '', disabled: true});
    this.prenomFormControl = new FormControl({value: '', disabled: true});
    this.emailFormControl = new FormControl('', [this.globals.emailValidator]);
    this.telFormControl = new FormControl({value: '', disabled: true}, [this.globals.telValidator]);
    this.dateFormControl = new FormControl({value: '', disabled: true});
    this.ObjetFormControl = new FormControl('', [Validators.required]);
    this.messageFormControl = new FormControl('', [Validators.required]);
  }

  ngOnInit() {
    this.preValidateForm = new FormGroup({
      emailFormControl: this.emailFormControl,
      telFormControl: this.telFormControl,
      nomFormControl: this.nomFormControl,
      prenomFormControl: this.prenomFormControl,
      dateFormControl: this.dateFormControl,
      ObjetFormControl: this.ObjetFormControl,
      messageFormControl: this.messageFormControl,
      civiliteFormControl: this.civiliteFormControl
    });

    this.store.dispatch(new GetCoordonneesClient({keepMdproData: true}));

    this.subscriptions.push(
      selectContactReclamation(this.store).subscribe(x => {
        if (x.contactReclamation.contrat) {
          this.contratSelectionne = x.contactReclamation.contrat;
          const silo = siloContrat(this.contratSelectionne);
          this.contratMdpro = (silo === 'MDP');
          if (this.contratMdpro) {
            this.preValidateForm.get('telFormControl').enable();
          } else if (this.preValidateForm.get('telFormControl').enabled) {
            this.preValidateForm.get('telFormControl').disable();
          }
          this.initQuestions(silo);
        }
        this.loading = x.contactReclamation.loading;
        this.reclamation = (x.contactReclamation.typeContact === 'Reclamation');

        this.showResponseMessage(x.contactReclamation.reclamation);

        if (x.coordonneesClient.isFetched) {
          this.initFormValue(x.infoClient, x.coordonneesClient);
        }
      })
    );

  }

  private initQuestions(codeSilo: CodeSiloType) {
    if (codeSilo === 'ERE') {
      this.subscriptions.push(this.jahia.getDico('dictionnaire_contact_reclamation').subscribe(dico => {
        this.questions = [{name: dico.get('QUESTION_1'), code: '1'}, // Question sur l\'un de mes contrats
          {name: dico.get('QUESTION_2'), code: '2'}, // Question sur le fonctionnement du site
          {name: dico.get('QUESTION_3'), code: '3'} //  Question sur les Versements Individuels Facultatifs
        ];
      }));
    } else if (codeSilo === 'MDP') {
      this.subscriptions.push(this.jahia.getDico('dictionnaire_contact_reclamation').subscribe(dico => {
        this.questions = [];
        forEachEntry(dico.entries, (key: string, value) => {
          if (key.startsWith('QUESTION_MDP')) {
            this.questions.push({name: value, code: value});
          }
        });
      }));
    }
  }

  private initFormValue(infoClient: ClientInfoState, coordonneesClient: CoordonneesClientState) {
    this.preValidateForm.get('emailFormControl').setValue(coordonneesClient.coordonnees.email);
    this.preValidateForm.get('nomFormControl').setValue(infoClient.nom);
    this.preValidateForm.get('prenomFormControl').setValue(infoClient.prenom);
    this.preValidateForm.get('telFormControl').setValue(coordonneesClient.coordonnees.telPortable);
    if (infoClient.dateDeNaissance != null) {
      const dateNaissance = new Date(infoClient.dateDeNaissance);
      this.preValidateForm.get('dateFormControl').setValue(dateNaissance);
    }
    if (infoClient.civilite != null) {
      this.preValidateForm.get('civiliteFormControl').setValue(infoClient.civilite);
    }
  }

  areObjetDmdAndMessageValid(): boolean {
    return this.isFieldValid('ObjetFormControl') && this.isFieldValid('messageFormControl') && !this.preValidateForm.get(
      'emailFormControl').hasError('pattern') && !this.preValidateForm.get('emailFormControl').hasError('required');
  }

  isFieldValid(controlName: string): boolean {
    return this.preValidateForm.get(controlName).valid && !this.preValidateForm.get(controlName).hasError('required') && !this.preValidateForm.get(
      controlName).pristine;
  }

  save() {
    this.impersonationService.protect('Envoi de la demande', () => {
      console.log(this.preValidateForm.value);

      const reclamationClient: ContactReclamationTerminateModel = {
        idAssure: this.contratSelectionne.identifiantAssure,
        idContrat: this.contratSelectionne.nomContrat,
        idPersonne: this.contratSelectionne.personId,
        codeSilo: this.contratSelectionne.codeSilo,
        codeFiliale: this.contratSelectionne.codeFiliale,
        codeQuestion: this.preValidateForm.get('ObjetFormControl').value.code,
        message: this.preValidateForm.get('messageFormControl').value,
        reclamation: this.reclamation,
        email: this.preValidateForm.get('emailFormControl').value,
        telephone: this.preValidateForm.get('telFormControl').value,
        raisonSociale: this.contratSelectionne.raisonSociale,
        fichiersJoint: this.filesUploaded.map(e => Object.assign({fileName: e.fileName, fileContent: e.fileContent}))
      };
      console.log('reclamation client', reclamationClient);

      this.msgs = [];
      const retour = new CreateContactReclamation(reclamationClient);
      this.store.dispatch(retour);
      const question = this.questions.find(e => e.code === reclamationClient.codeQuestion);
      this.store.dispatch(tracking(Categorie.contact, TypeOriginAction.objetDemande,
        question ? question.name : reclamationClient.codeQuestion));
    });
  }

  showResponseMessage(reclamation: ReclamationResponseModel) {
    if (!reclamation) {
      this.demandeEnvoyee = false;
      return;
    }

    this.demandeEnvoyee = true;
    if (reclamation.state === 'OK') {
      this.msgs.push({
        severity: 'success', summary: '', detail: 'Votre demande a été transmise avec succès.'
      });
    } else if (reclamation.state === 'LIMITED') {
      this.msgs.push({
        severity: 'error',
        summary: '',
        detail: 'Votre demande n\'a pas été transmise, la limite de cinq demandes par jour est atteinte.'
      });
    } else {
      this.msgs.push({
        severity: 'error',
        summary: '',
        detail: 'Votre demande n\'a pas été transmise, veuillez réessayer plus tard.'
      });
    }
  }

  showResponse(e: boolean) {
    this.tokenValid = e;
  }

  updateUploadedFiles(value: FileUploadResponseModel[]) {
    this.filesUploaded = value;
  }

  isPieceJointeValide(): boolean {
    return !this.contratMdpro || (this.contratMdpro && (this.uploadState === CustomUploadState.EMPTY || this.uploadState === CustomUploadState.SUCCESS));
  }

  isDemandeValide(): boolean {
    return this.areObjetDmdAndMessageValid() && this.isPieceJointeValide();
  }

  handleUploadState(event: CustomUploadState) {
    this.uploadState = event;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }
}
