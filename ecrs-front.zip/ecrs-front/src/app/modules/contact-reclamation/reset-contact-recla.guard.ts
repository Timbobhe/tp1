import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { ResetStateAction } from '@app/actions/global.actions';
import { TrackingState } from '@ag2rlamondiale/transverse-metier-ng';

/**
 * Reset l'état du formulaire dans le Store
 */
@Injectable({
  providedIn: 'root'
})
export class ResetContactReclaGuard implements CanActivate {

  constructor(private readonly store: Store<GlobalState>) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.store.dispatch(new ResetStateAction({
      contactReclamation: {},
      tracking: (state: TrackingState) => Object.assign({info: state.info})
    }));
    return true;
  }

}
