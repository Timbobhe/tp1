import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { map, tap } from 'rxjs/operators';

/**
 * * Vérifier qu'il y a bien le type de contact + le contrat dans le store, sinon rediriger
 */
@Injectable({
  providedIn: 'root'
})
export class CheckStateContactGuard implements CanActivate {

  constructor(private readonly store: Store<GlobalState>,
    private readonly router: Router) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.store.select('contactReclamation').pipe(
      map(e => e.typeContact != null),
      tap(goto => {
        if (!goto) {
          this.router.navigate(['/nous-contacter/type-demande'] );
        }
      })
    );
  }
}
