import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { CONTACT_RECLAMATION_CHOIX_CONTRAT, SelectionContrat } from '@app/actions/contact-reclamation.actions';
import { map } from 'rxjs/operators';
import { SetTrackingEnvTemplate } from '@app/actions/tracking.action';

@Injectable({
  providedIn: 'root'
})
export class ContactReclamationTrackingEffects {

  @Effect({dispatch: true})
  envTempate$ = this.actions$.pipe(
    ofType(CONTACT_RECLAMATION_CHOIX_CONTRAT),
    map(a => a as SelectionContrat),
    map(a => new SetTrackingEnvTemplate([a.payload.codeSilo]))
  );


  constructor(private readonly actions$: Actions) {
  }
}
