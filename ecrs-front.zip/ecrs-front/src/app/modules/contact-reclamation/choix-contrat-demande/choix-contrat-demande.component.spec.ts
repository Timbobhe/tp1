import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {ChoixContratDemandeComponent} from './choix-contrat-demande.component';
import {testingModule} from '../../../../test/ecrs-testing';
import {RouterModule} from '@angular/router';

describe('ChoixContratDemandeComponent', () => {
  let component: ChoixContratDemandeComponent;
  let fixture: ComponentFixture<ChoixContratDemandeComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [ChoixContratDemandeComponent],
      imports: [
        RouterModule.forRoot([{
          path: '',
          redirectTo: 'nous-contacter',
          pathMatch: 'full'
        }])
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChoixContratDemandeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

});
