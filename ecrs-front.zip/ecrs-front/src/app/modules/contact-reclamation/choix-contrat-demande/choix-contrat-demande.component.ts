import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output
} from '@angular/core';
import { GetContactReclamationStart, SelectionContrat } from '@app/actions/contact-reclamation.actions';
import { CONTACT, RECLAMATION } from '@app/consts/fonctionnalites.const';
import { selectContactReclamation } from '@app/reducers/ecrs.selectors';
import { Store } from '@ngrx/store';
import { Contrat, MiniContrat } from '@app/models/client/contrat.model';
import { GlobalState } from '@app/reducers/_index';
import { Subscription } from 'rxjs';
import { filter, switchMap, take } from 'rxjs/operators';
import { ReduxApiService } from '@ag2rlamondiale/redux-api-ng';

@Component({
  selector: 'app-choix-contrat-demande',
  templateUrl: './choix-contrat-demande.component.html',
  styleUrls: ['./choix-contrat-demande.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChoixContratDemandeComponent implements OnInit, OnDestroy {

  subscriptions: Subscription[] = [];
  @Output() clickAction: EventEmitter<any> = new EventEmitter();
  contratSelectionne: Contrat;
  typeDemande: string;

  constructor(
    private readonly store: Store<GlobalState>,
    private readonly cd: ChangeDetectorRef,
    private readonly reduxApi: ReduxApiService) {
  }

  contratsNonBloques: Contrat[];

  ngOnInit() {
    this.cd.detach();
    this.subscriptions.push(
      selectContactReclamation(this.store).pipe(
        filter(x => !(x.contactReclamation.contrats && x.contactReclamation.isFetched)),
        take(1),
        switchMap(x => this.reduxApi.execute(new GetContactReclamationStart()))
      ).subscribe(),

      selectContactReclamation(this.store).pipe(
        filter(x => x.contactReclamation.contrats && x.contactReclamation.isFetched),
        take(1)
      ).subscribe(x => {
        this.typeDemande = x.contactReclamation.typeContact === 'Contact' ? CONTACT : RECLAMATION;
        this.contratsNonBloques = x.infoClient.infosBlocagesClient.contratsNonBloques(x.contactReclamation.contrats, this.typeDemande);
        this.contratsNonBloques = this.contratsNonBloques.filter(c => c.affichageType !== 'GRISE');
        this.cd.detectChanges();
      }));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s && s.unsubscribe());
  }

  select(event: MiniContrat) {
    this.cd.detach();
    this.contratSelectionne = event as Contrat;
    this.cd.detectChanges();
    this.store.dispatch(new SelectionContrat(this.contratSelectionne));
  }
}
