import { JahiaNgModule } from '@ag2rlamondiale/jahia-ng';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '@ag2rlamondiale/transverse-metier-ng';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { MessagesModule } from 'primeng/messages';
import { SelectButtonModule } from 'primeng/selectbutton';
import { RadioButtonModule } from 'primeng/radiobutton';
import { EcrsCommonModule } from '@app/modules/ecrs-common/ecrs-common.module';
import { EffectsModule } from '@ngrx/effects';
import { ChoixContratDemandeComponent } from './choix-contrat-demande/choix-contrat-demande.component';
import { ChoixTypeDemandeComponent } from './choix-type-demande/choix-type-demande.component';
import { ContactReclamationRoutingModule } from './contact-reclamation-routing.module';
import { ContactReclamationComponent } from './contact-reclamation.component';
import { FormulaireCommunComponent } from './formulaire-commun/formulaire-commun.component';
import { FormulaireContactComponent } from './formulaire-contact/formulaire-contact.component';
import { FormulaireReclamationComponent } from './formulaire-reclamation/formulaire-reclamation.component';
import { ContactReclamationTrackingEffects } from './contact-reclamation-tracking-effects.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    JahiaNgModule,
    CalendarModule,
    DropdownModule,
    InputTextareaModule,
    RadioButtonModule,
    SharedModule,
    EcrsCommonModule,
    ContactReclamationRoutingModule,
    SelectButtonModule,
    MessagesModule,
    EffectsModule.forFeature([ContactReclamationTrackingEffects])
  ],
  declarations: [
    ContactReclamationComponent,
    ChoixContratDemandeComponent,
    ChoixTypeDemandeComponent,
    FormulaireCommunComponent,
    FormulaireContactComponent,
    FormulaireReclamationComponent],
  exports: [
    ContactReclamationComponent,
    ChoixContratDemandeComponent,
    ChoixTypeDemandeComponent,
    FormulaireCommunComponent,
    FormulaireContactComponent,
    FormulaireReclamationComponent],
})
export class ContactReclamationModule {
}
