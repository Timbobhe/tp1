import {waitForAsync, ComponentFixture, TestBed} from '@angular/core/testing';

import {FormulaireReclamationComponent} from './formulaire-reclamation.component';
import {testingModule} from '../../../../test/ecrs-testing';

describe('FormulaireReclamationComponent', () => {
  let component: FormulaireReclamationComponent;
  let fixture: ComponentFixture<FormulaireReclamationComponent>;

  beforeEach(waitForAsync(() => {
    testingModule({}, {
      declarations: [FormulaireReclamationComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormulaireReclamationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
