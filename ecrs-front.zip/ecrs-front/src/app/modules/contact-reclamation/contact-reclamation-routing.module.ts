import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChoixTypeDemandeComponent } from './choix-type-demande/choix-type-demande.component';
import { ContactReclamationComponent } from './contact-reclamation.component';
import { FormulaireContactComponent } from './formulaire-contact/formulaire-contact.component';
import { FormulaireReclamationComponent } from './formulaire-reclamation/formulaire-reclamation.component';
import { ResetContactReclaGuard } from '@app/modules/contact-reclamation/reset-contact-recla.guard';
import { CheckStateContactGuard } from '@app/modules/contact-reclamation/check-state-contact.guard';
import { QuitFormGuard } from '@app/modules/contact-reclamation/quit-form.guard';

const routes: Routes = [
  {
    path: '',
    component: ContactReclamationComponent,
    canActivate: [],
    children: [
      {
        path: 'type-demande',
        component: ChoixTypeDemandeComponent,
        canActivate: [ResetContactReclaGuard]
      },
      {
        path: 'contact',
        component: FormulaireContactComponent,
        canActivate: [CheckStateContactGuard],
        canDeactivate: [QuitFormGuard],
        data: {id: 'ContactFormulaire'}
      },
      {
        path: 'reclamation',
        component: FormulaireReclamationComponent,
        canActivate: [CheckStateContactGuard],
        canDeactivate: [QuitFormGuard],
        data: {id: 'ReclamationFormulaire'}
      },
      {
        path: '**',
        redirectTo: 'type-demande',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ContactReclamationRoutingModule {
}
