import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/actions/accessibilite.actions';
import { MODIF_CLAUSE_BENEFICIAIRE } from '@app/consts/fonctionnalites.const';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subject, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';
import { trace } from '@ag2rlamondiale/redux-api-ng';

@Injectable()
export class ModificationClauseBeneficiaireGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
              private readonly router: Router,
              private readonly configService: ConfigService) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const canActivate = new Subject<boolean>();
    const getAccessibiliteModificationClauseBeneficiaire = new GetAccessibilite(MODIF_CLAUSE_BENEFICIAIRE);

    getAccessibiliteModificationClauseBeneficiaire.payload.onSuccess = (data => {
      if (data.accessible || this.isRetourSigElec(state)) {
        canActivate.next(true);
        canActivate.complete();
      } else {
        if (data.raison === 'BLOCAGE_BIA_MONO_EQUIPE_MDPRO') {
          window.open(this.configService.config['espace_societaire_endpoint']);
        }
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible',
          {functionality: MODIF_CLAUSE_BENEFICIAIRE}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });

    this.store.dispatch(getAccessibiliteModificationClauseBeneficiaire);
    return canActivate.pipe(tap(r => trace('ModificationClauseBeneficiaireGuard#stop', r)));
  }

  isRetourSigElec(state: RouterStateSnapshot) {
    return state.url.endsWith('/signature/echouee') || state.url.endsWith('/signature/annulee') || state.url.endsWith('/signature/terminee');
  }
}
