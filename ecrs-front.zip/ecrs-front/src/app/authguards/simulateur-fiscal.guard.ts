import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Observable, Subject } from 'rxjs';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/actions/accessibilite.actions';
import { SIMULATEUR_FISCAL } from '@app/consts/fonctionnalites.const';
import { Store } from '@ngrx/store';
import { GlobalState } from '@app/reducers/_index';
import { tap } from 'rxjs/operators';
import { SetSimulateurFiscalStart } from '@app/actions/simulateur-fiscal.action';
import { SimulateurFiscalModel } from '@app/models/client/simulateur-fiscal.model';


@Injectable({
  providedIn: 'root'
})
export class SimulateurFiscalGuard implements CanActivate {

  constructor(private readonly store: Store<GlobalState>,
              private readonly router: Router) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    trace('SimulateurFiscalGuard#start');
    const canActivate = new Subject<boolean>();
    const getAccessibiliteSimulateurFiscal = new GetAccessibilite<SimulateurFiscalModel>(SIMULATEUR_FISCAL);

    getAccessibiliteSimulateurFiscal.payload.onSuccess = (data => {
      if (data.accessible) {
        this.store.dispatch(new SetSimulateurFiscalStart(data.startData));
        canActivate.next(true);
        canActivate.complete();
      } else {
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible', {functionality: SIMULATEUR_FISCAL}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });
    this.store.dispatch(getAccessibiliteSimulateurFiscal);
    return canActivate.pipe(tap(r => trace('SimulateurFiscalGuard#stop', r)));
  }

}
