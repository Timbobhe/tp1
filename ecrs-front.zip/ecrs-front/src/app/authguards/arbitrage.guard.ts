import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { trace } from '@ag2rlamondiale/redux-api-ng';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { GetAccessibilite, PushAccesFonctionnalite } from '@app/actions/accessibilite.actions';
import { ARBITRAGE } from '@app/consts/fonctionnalites.const';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { Observable, Subject, Subscription } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArbitrageGuard implements CanActivate {
  subscriptions: Subscription[] = [];

  constructor(private readonly store: Store<GlobalState>,
    private readonly router: Router,
    private readonly configService: ConfigService) {
  }


  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    trace('ArbitrageGuard#start');
    const canActivate = new Subject<boolean>();
    const getAccessibiliteArbitrage = new GetAccessibilite(ARBITRAGE);

    getAccessibiliteArbitrage.payload.onSuccess = (data => {
      if (data.accessible || this.isRetourSigElec(state)) {
        canActivate.next(true);
        canActivate.complete();
      } else {
        this.store.dispatch(new PushAccesFonctionnalite(data));
        this.router.navigate(['/fonctionnalite-inaccessible',
        {functionality: ARBITRAGE}]);
        canActivate.next(false);
        canActivate.complete();
      }
    });

     this.store.dispatch(getAccessibiliteArbitrage);
    return canActivate.pipe(tap(r => trace('ArbitrageGuard#stop', r)));
  }

  isRetourSigElec(state: RouterStateSnapshot) {
    return state.url.endsWith('/signature/echouee') || state.url.endsWith('/signature/annulee') || state.url.endsWith(
      '/signature/terminee');
  }
}
