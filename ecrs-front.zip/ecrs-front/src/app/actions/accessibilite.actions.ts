import { Actions as ApiActions } from '@ag2rlamondiale/redux-api-ng';
import { AccesFonctionnaliteModel } from '@app/models/client/acces-fonctionnalite.model';
import { Action } from '@ngrx/store';
import { GetContrat } from './common.actions';

export const GET_ACCESSIBILITE = '[GET]_ACCESSIBILITE';
export const PUSH_ACCESSIBILITE = '[ACCESSIBILITE]_PUSH_ACCESSIBILITE';
export const CLEAR_ACCESSIBILITE = '[ACCESSIBILITE]_CLEAR_ACCESSIBILITE';


export class GetAccessibilite<S = any> extends GetContrat<AccesFonctionnaliteModel<S>> {
  constructor(idFct: string) {
    super(GET_ACCESSIBILITE, 'backend/base', '/accessibilite');
    this.addQueryParam('idFct', idFct);
  }
}

export class PushAccesFonctionnalite implements Action {
  type = PUSH_ACCESSIBILITE;

  constructor(public payload: AccesFonctionnaliteModel) {
  }
}

export class ClearAccesFonctionnalite implements Action {
  type = CLEAR_ACCESSIBILITE;

  constructor(public payload: AccesFonctionnaliteModel) {
  }
}

export type Actions = GetAccessibilite | PushAccesFonctionnalite | ApiActions;
