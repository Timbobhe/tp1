import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';

export const CAPTCHA_VALID_TOKEN = '[CAPTCHA]_VALID_TOKEN';

export class CaptchaValidToken extends ApiAction<any> {
  constructor(public token: string) {
    super(CAPTCHA_VALID_TOKEN, 'backend/verifyCaptcha', token);
    this.payload.method = 'POST';
    this.payload.requestData = token;
  }
}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = CaptchaValidToken | ApiActions;
