import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { InfoPersonne } from '@app/models/client/info.client.model';

export const GET_CLIENT_INFOS = '[CLIENT_INFOS]_GET';

export class GetClientInfos extends ApiAction<InfoPersonne> {

  // 'endpoint' ou 'backend/endpoint_interne'
  constructor() {
    super(GET_CLIENT_INFOS, 'backend/clientInfos', null);
  }

}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetClientInfos | ApiActions;
