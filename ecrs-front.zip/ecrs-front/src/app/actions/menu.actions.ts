import { ApiAction, LEVEL_SEVERITY_MAJOR } from '@ag2rlamondiale/redux-api-ng';
import { ContratParcours } from '@app/models/client/contrat.model';
import { MenuItemData } from '@app/models/client/menu.model';


export const LOAD_MENU = '[MENU]_LOAD';
export const GET_CONTRATS_MENU = '[MENU]_GET_CONTRATS';

export interface MenuJson {
  menu: Array<MenuItemData>;
}

export class LoadMenu extends ApiAction<MenuJson> {
  type = LOAD_MENU;

  constructor() {
    super(LOAD_MENU, 'jahia_ressources_menu', null);
    this.payload.severity = LEVEL_SEVERITY_MAJOR;
  }

}
export class GetContratsMenu extends ApiAction<ContratParcours[]> {
  constructor() {
    super(GET_CONTRATS_MENU, 'backend/menuHeader', null);
    this.payload.url = `contrats`;
    this.payload.method = 'GET';
  }
}


// rajouter les classes d'actions exposées pour le reducer
export type Actions = LoadMenu;
