import { ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { CompartimentId, ContratId } from '@app/models/client/contrat.model';
import {
  DownloadValeursLiquidativesDto,
  EvolutionSupportDto,
  OperationDetailContrat, OperationDetailInfoDto,
  Periodicite
} from '@app/models/client/details-contrats.models';
import { ContratsDetailInfo, GestionFinanciereDetailContratDto } from '@app/models/contrat-detail.model';
import { EvolutionEncours } from '@app/models/client/evolution-encours.model';
import { GetContrat } from './common.actions';
import { DateUtils } from '@app/utils/dateUtils';
import { Fiche } from '@app/models/client/documents.model';
import { Action } from '@ngrx/store';
import { toQueryParamsContratId } from '@ag2rlamondiale/transverse-metier-ng';

export const DETAIL_CONTRAT_START = '[DETAILS_CONTRATS]_DETAIL_CONTRAT_START';
export const GET_OPERATIONS_DETAIL_CONTRAT_PACTE = '[DETAILS_CONTRATS]_GET_OPERATIONS_DETAIL_CONTRAT_PACTE';
export const GET_OPERATIONS_DETAIL_CONTRAT_NON_PACTE = '[DETAILS_CONTRATS]_GET_OPERATIONS_DETAIL_CONTRAT_NON_PACTE';
export const GET_OPERATIONS_DETAILS_CONTRAT = '[DETAILS_CONTRATS]_GET_OPERATIONS_DETAIL_CONTRAT';
export const GET_COMPARTIMENT_DETAIL_CONTRAT_PACTE = '[DETAILS_CONTRATS]_GET_COMPARTIMENT_DETAIL_CONTRAT_PACTE';
export const GET_EVOLUTIONS_ENCOURS_DETAIL_CONTRAT = '[DETAILS_CONTRATS]_GET_EVOLUTIONS_ENCOURS_DETAIL_CONTRAT';
export const CLEAR_EVOLUTION_ENCOURS = '[DETAILS_CONTRATS]_CLEAR_EVOLUTION_ENCOURS';

export const GET_EVOLUTION_SUPPORT = '[DETAILS_CONTRATS]_GET_EVOLUTION_SUPPORT';

export class GetDetailContrat extends GetContrat<ContratsDetailInfo> {
  constructor() {
    super(DETAIL_CONTRAT_START, 'backend/detailscontrats', `/start`);
  }
}

export class GetHistoriqueOperationsNonPacte extends ApiAction<OperationDetailContrat[]> {
  constructor(contrat: ContratId) {
    super(GET_OPERATIONS_DETAIL_CONTRAT_NON_PACTE, 'backend/detailscontrats', null);
    this.payload.url = `/suivi-operations-non-pacte`;
    this.payload.requestData = contrat;
    this.payload.method = 'POST';
  }
}

export class GetHistoriqueOperationsPacte extends ApiAction<OperationDetailContrat[]> {
  constructor(contrat: ContratId) {
    super(GET_OPERATIONS_DETAIL_CONTRAT_PACTE, 'backend/detailscontrats', null);
    this.payload.url = `/suivi-operations-pacte`;
    this.payload.requestData = contrat;
    this.payload.method = 'POST';
  }
}

export class GetEvolutionEncours extends ApiAction<EvolutionEncours[], keyof Periodicite> {
  constructor(contrat: ContratId, periodicite: keyof Periodicite) {
    super(GET_EVOLUTIONS_ENCOURS_DETAIL_CONTRAT, 'backend/detailscontrats', periodicite);
    this.payload.url = `/evolution-encours/${periodicite}`;
    this.payload.requestData = contrat;
    this.payload.inputParams = periodicite;
    this.payload.method = 'POST';
  }
}

export class ClearEvolutionsEncours implements Action {
  type = CLEAR_EVOLUTION_ENCOURS;

  constructor(public payload?: any) {
  }
}

export class GetOperationsContrat extends ApiAction<OperationDetailInfoDto[]> {
  constructor(idOperation: string, typeSilo: string) {
    super(GET_OPERATIONS_DETAILS_CONTRAT, 'backend/detailscontrats', idOperation, typeSilo);
    this.payload.url = `/details-operation/${idOperation}/${typeSilo}`;
  }
}

export class GetContratDetailGestionFinanciere extends ApiAction<GestionFinanciereDetailContratDto> {
  constructor(contratId: ContratId) {
    super('GET_CONTRAT_DETAILS_GESTION_FINANCIERE', 'backend/detailscontrats', contratId);
    this.payload.url = '/gestion-financiere';
    this.payload.method = 'POST';
    this.payload.requestData = contratId;
  }
}

export class GetCompartimentDetailGestionFinanciere extends ApiAction<GestionFinanciereDetailContratDto> {
  constructor(compartimentId: CompartimentId) {
    super(GET_COMPARTIMENT_DETAIL_CONTRAT_PACTE, 'backend/detailscontrats', compartimentId);
    this.payload.url = '/gestion-financiere-compartiment';
    this.payload.method = 'POST';
    this.payload.requestData = compartimentId;
  }
}

export class GetEvolutionSupport extends ApiAction<EvolutionSupportDto> {
  constructor(codeIsin: string) {
    super('GET_EVOLUTION_SUPPORT', 'backend/detailscontrats', codeIsin);
    this.payload.url = `/evolution-support?codeIsin=${codeIsin}`;
    this.payload.method = 'GET';
  }
}

export class GetDocumentsEvolutionSupport extends ApiAction<Fiche[]> {
  constructor(contratId: ContratId, codeIsin: string) {
    super('GET_DOCUMENTS_EVOLUTION_SUPPORT', 'backend/detailscontrats', codeIsin);
    this.payload.url = `/evolution-support/documents/fiches?${toQueryParamsContratId(contratId)}&codeIsin=${codeIsin}`;
    this.payload.method = 'GET';
  }
}

export class DownloadDocumentValeursLiquidatives extends ApiAction<any> {
  constructor(dto: DownloadValeursLiquidativesDto) {
    super('DOWNLOAD_DOCUMENT_VALEURS_LIQUIDATIVES', 'backend/detailscontrats', dto);
    this.payload.url = '/evolution-support/documents/valeurs-liquidatives/download';
    this.payload.method = 'POST';
    this.payload.responseType = 'blob';
    this.payload.requestData = dto;
  }
}

export type Actions =
  | GetDetailContrat
  | GetHistoriqueOperationsNonPacte
  | GetHistoriqueOperationsPacte
  | GetEvolutionEncours
  | GetOperationsContrat
  | GetCompartimentDetailGestionFinanciere
  | GetContratDetailGestionFinanciere
  | GetEvolutionSupport
  | GetDocumentsEvolutionSupport
  | DownloadDocumentValeursLiquidatives
  | ClearEvolutionsEncours;
