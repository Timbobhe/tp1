import { Actions as ApiActions, ApiAction } from '@ag2rlamondiale/redux-api-ng';
import { InfoPersonne } from '@app/models/client/info.client.model';

export const GET_PERSONNE_PHYSIQUE_INFOS = '[PERSONNE_PHYSIQUE_INFOS]_GET';

export class GetPersonnePhysiqueInfos extends ApiAction<InfoPersonne> {

  // 'endpoint' ou 'backend/endpoint_interne'
  constructor() {
    super(GET_PERSONNE_PHYSIQUE_INFOS, 'backend/personnePhysiqueInfos', null);
  }

}

// rajouter les classes d'actions exposées pour le reducer
export type Actions = GetPersonnePhysiqueInfos | ApiActions;
