import { DropDownItem } from './drop-down-item.model';

export class HeaderUser {
  dropDown: DropDownItem [] ;
}
