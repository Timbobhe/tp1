import { Image } from '@app/models/header/image.model';

export interface SimulateurImages {
  simulateurImpotImage: Image;
  simulateurRenteImage: Image;
  simulateurRetraiteImage: Image;

  simulateurHeaderImage: Image;
}
