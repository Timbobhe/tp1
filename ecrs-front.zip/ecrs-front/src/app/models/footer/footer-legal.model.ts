import { LinkModel } from './link.model';

export class FooterLegalModel {
  cols: LinkModel [];
  copyRight: string;
}
