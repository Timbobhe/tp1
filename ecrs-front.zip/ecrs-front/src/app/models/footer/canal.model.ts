export class CanalModel {
  type: string;
  link: string;
  iconClass: string;
  imgSrc: string;
  backgroundPositionX: string;
  backgroundPositionY: string;
}
