import {
  CodeSiloType,
  CompartimentId,
  ContratId,
  ContratParcours,
  Encours,
  MiniContrat,
  toCompartimentId
} from '@app/models/client/contrat.model';
import { GestionFinanciereActuelleMdp, ModeGestionMdproType } from '@app/models/client/gestion-financiere.model';
import { RepartitionSupport } from '@app/models/client/grille.investissement.model';
import { Question, QuestionReponses, QuestionState, QuestionType, Reponse } from '@app/models/question-responses.model';
import { Document } from '@app/modules/ecrs-common/services/download.service';
import { GlobalState } from '@app/reducers/_index';
import { Store } from '@ngrx/store';
import { ArbitrageState } from '@app/reducers/arbitrage.reducer';
import { GetArbitrageQuestionOrNext } from '@app/actions/arbitrage.action';
import { ArbitrageClient } from '@app/models/client/arbitrage-refacto.model';
import { BasicMessage } from '@ag2rlamondiale/transverse-metier-ng';
import {BasicInfoParcoursDto} from '@app/models/client/basic-info-contrat-parcours.model';



export class InfoArbitrageContrat extends BasicInfoParcoursDto {
  contrat: MiniContrat; // numero de contrat ou idAssuré si pacte
  choixCompartimentERE: QuestionReponses<ChoixCompartiment>;
  bloque: boolean;
  raisonBlocage: BasicMessage;
  qadStatus: QadStatusType;
  gestionFinanciereActuelleMdp: GestionFinanciereActuelleMdp;
  nbArbitrageAnnee: number;
}

export type ConsentementId = keyof ConsentementsMdp | keyof EngagementsEre;

export class ConsentementsMdp {
  supportsInvestissement: boolean;
  perteGestionPilotee: boolean;
  formulaireDechargePerp: boolean;
  tutelle: boolean;
}

export class EngagementsEre {
  connaissanceGestionFinanciere: boolean;
  connaissanceGestionFinanciereEtSupportsUC: boolean;
  certificationRenseignement: boolean;
}

export const ConsentementsJahia: { [id in keyof ConsentementsMdp | keyof EngagementsEre]: string } = {
  supportsInvestissement: 'ARB_MDPRO_MISE_EN_GARDE_UC',
  perteGestionPilotee: 'ARB_MDPRO_MESSAGE_RM08H',
  formulaireDechargePerp: 'ARB_MDPRO_FORMULAIRE_DECHARGE_PERP',
  tutelle: 'ARB_MDPRO_QUESTION_RM07QUATER_TITRE',
  connaissanceGestionFinanciere: 'ARB_ENGAGEMENT_CONNAISSANCE_GESTION_FINANCIERE',
  connaissanceGestionFinanciereEtSupportsUC: 'ARB_ENGAGEMENT_CONNAISSANCE_GESTION_FINANCIERE_ET_SUPPORT_UC',
  certificationRenseignement: 'ARB_ENGAGEMENT_CERTIFICATION_RENSEIGNEMENTS'
};

export class ArbitrageModel {
  arbitrages: InfoArbitrageContrat[];
  sigElecOff: boolean;
}

export class ChoixCompartiment {
  compartiment: ContratParcours;
  tousCompartiments: boolean;
  encours: Encours;
  placementsFinanciersDifferentsAutorises: boolean;
}

export class ChoixDesinvestissement {
  arbitragesClient: ArbitrageClient[] = [];
  montantTotal: number;
}


export function hashCompartimentIds(compartiments: CompartimentId[]) {
  return compartiments.map(e => JSON.stringify(e)).sort().join('-');
}

export class ChoixRepartitionSupport {
  arbitragesClient: ArbitrageClient[] = [];
}


export class ChoixDesinvestissementPayload {
  reponse: Map<ArbitrageClient, RepartitionSupport[]>;
}

export class ChoixRepartitionSupportPayload {
  reponse: Map<ArbitrageClient, RepartitionSupport[]>;
  consentementsMdp?: ConsentementsMdp;
}

export interface ChoixReponsePayload {
  questionType: QuestionType;
  reponse: Reponse;
}

export interface QuestionStates {
  choixCompartimentERE: QuestionState<ChoixCompartiment>;
  choixFluxStock: QuestionState<ResponseArbitrageFluxStockType>;
  choixModeGestion: QuestionState<ModeGestionMdproType>;
  choixTotalPartiel: QuestionState<ResponseArbitrageTotalPartielType>;
  choixEurosPourcent: QuestionState<ResponseArbitrageEurosPourcentageType>;
  choixDesinvestissement: QuestionState<ChoixDesinvestissement>;
  choixRepartition: QuestionState<ChoixRepartitionSupport>;
}

function questionFictiveDesinvestissement(): QuestionState<ChoixDesinvestissement> {
  const questionFictive = new QuestionState<ChoixDesinvestissement>();
  questionFictive.isFetched = true;
  questionFictive.questionReponse = new QuestionReponses();
  questionFictive.questionReponse.isFictive = true;
  questionFictive.questionReponse.affirmativeMessage = {
    label: 'Pour un total de desinvestissement de : ',
    jahiaDicoEntry: null
  };
  questionFictive.questionReponse.question = new Question();
  questionFictive.questionReponse.question.id = 'ARBITRAGE_CHOIX_DESINVESTISSEMENT';
  questionFictive.questionReponse.show = true;
  return questionFictive;
}

function questionFictiveRepartition(): QuestionState<ChoixRepartitionSupport> {
  const questionFictive = new QuestionState<ChoixRepartitionSupport>();
  questionFictive.isFetched = true;
  questionFictive.questionReponse = new QuestionReponses();
  questionFictive.questionReponse.isFictive = true;
  questionFictive.questionReponse.affirmativeMessage = {label: 'De la façon suivante : ', jahiaDicoEntry: null};
  questionFictive.questionReponse.question = new Question();
  questionFictive.questionReponse.question.id = 'ARBITRAGE_CHOIX_REPARTITION';
  questionFictive.questionReponse.show = true;
  return questionFictive;
}


export class QuestionModel implements QuestionStates {
  choixCompartimentERE: QuestionState<ChoixCompartiment> = new QuestionState<ChoixCompartiment>();
  choixFluxStock: QuestionState<ResponseArbitrageFluxStockType> = new QuestionState<ResponseArbitrageFluxStockType>();
  choixModeGestion: QuestionState<ModeGestionMdproType> = new QuestionState<ModeGestionMdproType>();
  choixTotalPartiel: QuestionState<ResponseArbitrageTotalPartielType> = new QuestionState<ResponseArbitrageTotalPartielType>();
  choixEurosPourcent: QuestionState<ResponseArbitrageEurosPourcentageType> = new QuestionState<ResponseArbitrageEurosPourcentageType>();
  choixDesinvestissement: QuestionState<ChoixDesinvestissement> = questionFictiveDesinvestissement();
  choixRepartition: QuestionState<ChoixRepartitionSupport> = questionFictiveRepartition();

  setQuestionLoading(questionType: QuestionType) {
    const attr = this.toAttr(questionType);
    const questionState = this[attr];
    // @ts-ignore
    this[attr] = Object.assign(new QuestionState(), {...questionState, isLoading: true});
    return this;
  }

  setQuestionError(questionType: QuestionType) {
    const attr = this.toAttr(questionType);
    const questionState = this[attr];
    // @ts-ignore
    this[attr] = Object.assign(new QuestionState(), {
      ...questionState,
      isError: true,
      isLoading: false,
      isFetched: true
    });
    return this;
  }

  setQuestionReponses(questionReponse: QuestionReponses) {
    const questionType = questionReponse.question.id;
    const choix = questionReponse.defaultValue;
    const attr = this.toAttr(questionType);
    // @ts-ignore
    this[attr] = Object.assign(new QuestionState(), {isFetched: true, questionReponse, choix, isLoading: false});
    return this;
  }

  setChoix(choix: ChoixReponsePayload) {
    const reponse = choix.reponse;
    const attr = this.toAttr(choix.questionType);
    // @ts-ignore
    this[attr] = Object.assign(new QuestionState(),
      {...this[attr], choix: reponse});
    if (choix.questionType === 'ARBITRAGE_CHOIX_COMPARTIMENT' || choix.questionType === 'ARBITRAGE_CHOIX_MODEGESTION') {
      this['choixFluxStock'] = new QuestionState();
      this['choixTotalPartiel'] = new QuestionState();
      this['choixEurosPourcent'] = new QuestionState();
      this['choixDesinvestissement'] = questionFictiveDesinvestissement();
      this['choixRepartition'] = questionFictiveRepartition();
    } else if (choix.questionType === 'ARBITRAGE_CHOIX_FLUXSTOCK') {
      this['choixTotalPartiel'] = new QuestionState();
      this['choixEurosPourcent'] = new QuestionState();
      this['choixDesinvestissement'] = questionFictiveDesinvestissement();
      this['choixRepartition'] = questionFictiveRepartition();
    } else if (choix.questionType === 'ARBITRAGE_CHOIX_TOTALPARTIEL') {
      this['choixEurosPourcent'] = new QuestionState();
      this['choixDesinvestissement'] = questionFictiveDesinvestissement();
      this['choixRepartition'] = questionFictiveRepartition();
    } else if (choix.questionType === 'ARBITRAGE_CHOIX_DESINVESTISSEMENT') {
      this['choixDesinvestissement'] = questionFictiveDesinvestissement(); // voir si necessaire de garder
      this['choixRepartition'] = questionFictiveRepartition();
      this['choixEurosPourcent'] = new QuestionState();
    } else if (choix.questionType === 'ARBITRAGE_CHOIX_REPARTITION') {
      this['choixRepartition'] = questionFictiveRepartition();
    }
    return this;
  }

  setListQuestionResponses(liste: ListQuestionResponses) {
    liste.questionResponsesList.forEach(qr => this.setQuestionReponses(qr));
  }

  toContexte(contratSelectionne: ContratId, isParcoursSimplifie?: boolean): ArbitrageContexte {
    const ps = isParcoursSimplifie ? isParcoursSimplifie : false;
    const context = new ArbitrageContexte(contratSelectionne, ps);

    this.choixCompartimentERE.use(v => {
      context.compartimentSelectionne = v.compartiment ? toCompartimentId(v.compartiment) : null;
      context.tousCompartimentsSelectionnes = v.tousCompartiments;
    });

    this.choixFluxStock.use(v => context.responseFluxStockType = v);
    this.choixModeGestion.use(v => context.responseModeGestionType = v);
    this.choixTotalPartiel.use(v => context.responseTotalPartielType = v);
    this.choixEurosPourcent.use(v => context.responseEurosPourcentageType = v);

    return context;
  }

  fromType(questionType: QuestionType): QuestionState {
    const attr = this.toAttr(questionType);
    return this[attr];
  }

  toAttr(questionType: QuestionType): keyof QuestionStates {
    switch (questionType) {
      case 'ARBITRAGE_CHOIX_COMPARTIMENT':
        return 'choixCompartimentERE';
      case 'ARBITRAGE_CHOIX_FLUXSTOCK':
        return 'choixFluxStock';
      case 'ARBITRAGE_CHOIX_MODEGESTION':
        return 'choixModeGestion';
      case 'ARBITRAGE_CHOIX_TOTALPARTIEL':
        return 'choixTotalPartiel';
      case 'ARBITRAGE_CHOIX_EUROSPOURCENT':
        return 'choixEurosPourcent';
      case 'ARBITRAGE_CHOIX_DESINVESTISSEMENT':
        return 'choixDesinvestissement';
      case 'ARBITRAGE_CHOIX_REPARTITION':
        return 'choixRepartition';
    }
    throw new Error(`${questionType} non gérée`);
  }
}

export class ListQuestionResponses {
  questionTypeDisplayed: QuestionType;
  questionResponsesList: QuestionReponses[];
}

export class ArbitrageContexte {
  contratSelectionne: ContratId;
  compartimentSelectionne?: CompartimentId;
  tousCompartimentsSelectionnes?: boolean;
  responseFluxStockType?: ResponseArbitrageFluxStockType;
  responseModeGestionType?: ModeGestionMdproType;
  responseTotalPartielType?: ResponseArbitrageTotalPartielType;
  responseEurosPourcentageType?: ResponseArbitrageEurosPourcentageType;
  paramFluxStock?: ParamFluxStock;
  parcoursSimplifie?: boolean;

  constructor(contratSelectionne: ContratId, isParcoursSimplifie?: boolean) {
    this.contratSelectionne = contratSelectionne;
    this.parcoursSimplifie = isParcoursSimplifie ? isParcoursSimplifie : false;
  }
}

export class RequestQuestionArbitrage {
  questionType: QuestionType;
  contexte: ArbitrageContexte;
  questionTypeList: QuestionType[];
}

export class ArbitrageTerminateModel {
  contratSelected: ContratId;
  arbitragesClient: ArbitrageClient[];
  contenuArbitrage: Document;
  contenuQad: Document;
}

export type ParamFluxStock = 'flux' | 'stock';

export type QadStatusType = 'IMPOSSIBLE' | 'FACULTATIF' | 'OBLIGATOIRE';

export type ResponseArbitrageFluxStockType = 'ARBITRAGE_FLUX' | 'ARBITRAGE_STOCK' | 'ARBITRAGE_FLUXSTOCK';

export type ResponseArbitrageTotalPartielType = 'ARBITRAGE_TOTAL' | 'ARBITRAGE_PARTIEL';

export type ResponseArbitrageEurosPourcentageType = 'ARBITRAGE_EUROS' | 'ARBITRAGE_POURCENTAGE';

/**
 * Liste des questions à envoyer au back (question-or-next)
 */
export const QuestionsReellesERE: QuestionType[] = [
  'ARBITRAGE_CHOIX_COMPARTIMENT',
  'ARBITRAGE_CHOIX_FLUXSTOCK',
  'ARBITRAGE_CHOIX_TOTALPARTIEL',
  'ARBITRAGE_CHOIX_EUROSPOURCENT'
];

export const QuestionsReellesMDP: QuestionType[] = [
  'ARBITRAGE_CHOIX_MODEGESTION',
  'ARBITRAGE_CHOIX_FLUXSTOCK',
  'ARBITRAGE_CHOIX_TOTALPARTIEL',
  'ARBITRAGE_CHOIX_EUROSPOURCENT'
];

export const QuestionsReelles = {
  ERE: QuestionsReellesERE,
  MDP: QuestionsReellesMDP
};

export interface Etape {
  index: number;
  label: string;
  questionsType?: { [silo in CodeSiloType]: QuestionType[] };
  url?: string;
}

export const EtapeInit: Etape = {
  index: -1,
  label: 'Choix du contrat',
  url: '/modification-gestion-financiere/choix-contrat'
};
export const Etape0: Etape = {
  index: 0,
  label: 'Initialisation de l\'arbitrage',
  questionsType: {
    ERE: ['ARBITRAGE_CHOIX_COMPARTIMENT', 'ARBITRAGE_CHOIX_FLUXSTOCK'],
    MDP: ['ARBITRAGE_CHOIX_MODEGESTION', 'ARBITRAGE_CHOIX_FLUXSTOCK'],
  },
  url: '/modification-gestion-financiere/etape/choix-arbitrage'
};
export const Etape1: Etape = {
  index: 1,
  label: 'Choisir un répartition',
  questionsType: {
    ERE: ['ARBITRAGE_CHOIX_TOTALPARTIEL',
      'ARBITRAGE_CHOIX_EUROSPOURCENT',
      'ARBITRAGE_CHOIX_DESINVESTISSEMENT',
      'ARBITRAGE_CHOIX_REPARTITION'],
    MDP: ['ARBITRAGE_CHOIX_TOTALPARTIEL',
      'ARBITRAGE_CHOIX_EUROSPOURCENT',
      'ARBITRAGE_CHOIX_DESINVESTISSEMENT',
      'ARBITRAGE_CHOIX_REPARTITION']
  },
  url: '/modification-gestion-financiere/etape/choix-repartition'
};
export const Etape2: Etape = {
  index: 2,
  label: 'Confirmer mon choix',
  url: '/modification-gestion-financiere/etape/recapitulatif-signature'
};
export const EtapeFin: Etape = {index: 3, label: 'Signature'};
export type EtapeArbitrage =
  typeof EtapeInit
  | typeof Etape0
  | typeof Etape1
  | typeof Etape2
  | typeof EtapeFin;
export const EtapesArbitrage: Array<Etape> = [EtapeInit, Etape0, Etape1, Etape2, EtapeFin];

export function findEtapeForQuestion(questionType: QuestionType, silo: CodeSiloType): Etape {
  return EtapesArbitrage.find(e => e.questionsType ? e.questionsType[silo].includes(questionType) : false);
}

export function findEtapesPrecedentes(etape: Etape): Etape[] {
  return EtapesArbitrage.filter(e => e.index < etape.index);
}

/**
 * Cette methode fait appel au back pour recupérer dans l'ordre les questions
 * en fonction du silo et de l'etape d'arbitrage
 * @param store
 * @param etapeCourante l'etape d'arbitrage courante
 * @param arbitrage l'etat de l'arbitrage dans le store
 */
export function getQuestionsOrNextFromEtape(store: Store<GlobalState>,
                                            etapeCourante: EtapeArbitrage,
                                            arbitrage: ArbitrageState): { loading: boolean } {
  const questions = arbitrage.questions;
  const contrat = arbitrage.contratSelected.contrat;
  const isParcoursSimplifie = arbitrage.contratSelected.parcoursSimplifie;

  const questionsEtape = etapeCourante.questionsType[contrat.codeSilo];
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    const qs = questions.fromType(questionType);
    if (qs.isError) {
      throw new Error(`${questionType} en erreur`);
    }
    if (qs.canFetch() && QuestionsReelles[contrat.codeSilo].includes(questionType)) {
      store.dispatch(new GetArbitrageQuestionOrNext({
        questionType,
        questionTypeList: QuestionsReelles[contrat.codeSilo],
        contexte: questions.toContexte(contrat, isParcoursSimplifie)
      }));
      return {loading: true};
    } else if (qs.isLoading) {
      return {loading: true};
    } else if (qs.isFetched && qs.questionReponse.show && !qs.choix) {
      return {loading: false};
    }
  }
  return {loading: false};
}

/**
 * Si il y a une question a afficher, cette methode indique si la question a afficher
 * appartient a la liste des questions d'une etape
 * @param questions l'etat des questions dans le store
 * @param questionToShow la question a afficher
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isQuestionEnAttenteDeReponse(questions: QuestionModel,
                                             questionToShow: QuestionType,
                                             questionsEtape: QuestionType[]): boolean {
  if (!questions || !questionToShow) {
    return false;
  }
  let result = false;
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    if (questionToShow === questionType) {
      result = true;
    }
  }
  return result;
}

/**
 * Cette methode verifie que toutes les questions d'une etape de l'arbitrage
 * ont une reponse enregistree dans le store
 * @param questions l'etat des questions dans le store
 * @param questionsEtape la liste des questions d'une etape selon le silo
 */
export function isToutesQuestionsRepondues(questions: QuestionModel, questionsEtape: QuestionType[]): boolean {
  if (!questions) {
    return false;
  }
  for (let i = 0; i < questionsEtape.length; i++) {
    const questionType = questionsEtape[i];
    if (!questions.fromType(questionType).choix) {
      return false;
    }
  }
  return true;
}

/**
 * Cette methode verifie que toutes les questions des etapes precedentes
 * ont une reponse enregistree dans le store
 * @param questions
 * @param etapeCourante
 * @param codeSilo
 */
export function isQuestionEtapesPrecedentesRepondues(questions: QuestionModel,
                                                     etapeCourante: EtapeArbitrage,
                                                     codeSilo: CodeSiloType | string): boolean {
  const etapePrecedentes = findEtapesPrecedentes(etapeCourante);
  for (let i = 0; i < etapePrecedentes.length; i++) {
    if (etapePrecedentes[i].questionsType && !isToutesQuestionsRepondues(questions,
      etapePrecedentes[i].questionsType[codeSilo])) {
      return false;
    }
  }
  return true;
}
