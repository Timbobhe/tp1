import { MiniContrat } from '@app/models/client/contrat.model';
import { BasicInfoParcoursDto } from '@app/models/client/basic-info-contrat-parcours.model';

export class ModificationClauseBeneficiaireModel {
  clauseBeneficiaireContrats: InfoClauseBeneficiaireContratDto[];
  sigElecOff: boolean;
}

export class InfoClauseBeneficiaireContratDto extends BasicInfoParcoursDto {
  contrat: MiniContrat;
}
