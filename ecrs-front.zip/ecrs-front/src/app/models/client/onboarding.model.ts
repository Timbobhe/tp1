import { Evenement } from './evenement.model';
import {BasicInfoParcoursDto} from '@app/models/client/basic-info-contrat-parcours.model';

export class OnboardingModel extends BasicInfoParcoursDto {
  /** Etape de l'Onboarding */
  etape: number;
  /** Sous-étape de l'étape "Configurer votre espace" */
  etapeConfigurerVotreEspace: number;
  sujetsSelectionnes: number[];
}

export class OnboardingTerminateModel {
  evenement: Evenement;
  idSujets: number[];
}
