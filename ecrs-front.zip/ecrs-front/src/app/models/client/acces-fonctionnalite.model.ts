import { ContratId } from './contrat.model';
import { FonctionnaliteType } from '@app/consts/fonctionnalites.const';

export class AccesFonctionnaliteModel<S = any> {
  fonctionnaliteType: FonctionnaliteType;
  accessible: boolean;
  raison: string;
  jahiaContext: Map<string, string>;
  details: Array<DetailAccesFonctionnalite>;
  startData?: S;
}

export class DetailAccesFonctionnalite {
  contrat: ContratId;
  accessible: boolean;
  raison: string;
}

