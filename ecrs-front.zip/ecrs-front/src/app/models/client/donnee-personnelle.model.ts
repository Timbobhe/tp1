import { FileUploadModel } from '@ag2rlamondiale/transverse-metier-ng';

export const TITRE_SOUS_SUJET_CONF = 'CONFIRMATION_DONNEES_PERSONNELLES';


export class DonneePersoModel {
  identiteInfoValidee: IdentiteInfo;
  donneesPersoParcoursTYpe: DonneesPersoParcoursType;

  piecesJointes: Justicatif;
}
export type DonneesPersoParcoursType = 'CONFIRMATION' | 'MODIFICATION';

export class IdentiteInfo {
  codeCivilite: string;
  civilite: string;
  nom: string;
  prenom: string;
  nomNaissance: string;
  dateDeNaissance: string;
  lieuNaissance: string;
}

export class Justicatif {
  pieceDidendite: FileUploadModel[];
  type: string;
}

export class DonneePersonnelJustificatif {
  isCompleted: boolean;
  piecesIdendite: FileUploadModel[];
  typePj: string;
}

