import { BasicMessage, MiniContrat } from '@ag2rlamondiale/transverse-metier-ng';
import { CodeSiloType } from '@app/models/client/contrat.model';
import { QuestionType } from '@app/models/question-responses.model';
import { DateUtils } from '@app/utils/dateUtils';

export type FiscaliteSimuType = 'MADELIN' | 'ART83' | 'PERP';

export class Tmi {
  taux: number;
  montantMin: number;
  montantMax?: number;
}

export class SimulateurFiscalModel {
  simulateurs: InfoSimulateurContrat[];
  parametresTMI: Tmi[];
}

export class InfoSimulateurContrat {
  contrat: MiniContrat;
  bloque: boolean;
  raisonBlocage: BasicMessage;
  fiscaliteSimuType: FiscaliteSimuType;
  showAlertMadelin: boolean;

  /**
   * Uniquement pour MADELIN
   */
  montantCotisationVersementAnneePrecedente?: number;
}

export interface Etape {
  index: number;
  label: string;
  questionsType?: { [silo in CodeSiloType]: QuestionType[] };
  url?: string;
  inStepper?: boolean;
}

export const EtapeNULL: Etape = {
  index: -2,
  label: 'Choix Contrat',
  url: '/simulateur/simulateur-fiscal/choix-contrat'
}

export const EtapeOnboarding: Etape = {
  index: -1,
  label: '',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/onboarding'
};


export const Etape0: Etape = {
  index: 0,
  label: 'Votre revenu net imposable',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/revenu-net-imposable',
  inStepper: true
};
export const Etape0Madelin: Etape = {
  index: 0,
  label: 'Votre revenu professionnel imposable',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/revenu-net-imposable',
  inStepper: true
};
export const Etape1: Etape = {
  index: 1,
  label: 'Votre tranche d\'impôt',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/tranche-impot',
  inStepper: true
};
export const Etape2: Etape = {
  index: 2,
  label: 'Les versements réalisés par votre employeur',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/versement-employeur',
  inStepper: true
};

export const Etape2Madelin: Etape = {
  index: 2,
  label: 'Vos cotisations réalisées en ' + DateUtils.previousYear(),
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/versement-cotisation-madelin',
  inStepper: true
};


export const Etape3: Etape = {
  index: 3,
  label: 'Vos versements auprès d’autres organismes',
  questionsType: {
    ERE: [],
    MDP: []
  },
  url: '/simulateur/simulateur-fiscal/etape/versement-autres-organismes',
  inStepper: true
};

export type EtapeSimulateurFiscal =
  typeof EtapeOnboarding |
  typeof Etape0 |
  typeof Etape0Madelin|
  typeof Etape1 |
  typeof Etape2 |
  typeof Etape2Madelin |
  typeof Etape3;


export const EtapesSimulateurFiscal: Array<Etape> = [EtapeNULL, EtapeOnboarding, Etape0, Etape1, Etape2, Etape3];
export const EtapesSimulateurFiscalMADELIN: Array<Etape> = [EtapeNULL, EtapeOnboarding, Etape0Madelin, Etape1, Etape2Madelin];

export interface StatutsType {
  salarie?: StatutType;
  bicBnc?: StatutType;
  gerantMajoritaire?: StatutType;
  commercant?: StatutType;
  gerantMajoritaireSarl?: StatutType;
}


export type StatutName = keyof StatutsType;

export interface RevenuStatut {
  revenu: number;
  statut: StatutName;

}

export interface StatutType {
  value: StatutName;
  label: string;
  questionDicoEntry: string;
  placeHolderDicoEntry: string;
}

export const StatutsPerp: StatutsType = {
  'salarie': {
    value: 'salarie',
    label: 'Salarié',
    questionDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_QUESTION_SALARIE',
    placeHolderDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_LABEL_INPUT_FIELD_SALARIE',
  },
  'bicBnc': {
    value: 'bicBnc',
    label: 'BIC/BNC',
    questionDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_QUESTION_BICBNC',
    placeHolderDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_LABEL_INPUT_FIELD_BICBNC',
  },
  'gerantMajoritaire': {
    value: 'gerantMajoritaire',
    label: 'Gérant majoritaire',
    questionDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_QUESTION_GERANT_MAJORITAIRE',
    placeHolderDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_LABEL_INPUT_FIELD_GERANT_MAJORITAIRE',
  },
};

export const StatutsMadelin: StatutsType = {
  'commercant': {
    value: 'commercant',
    label: 'Commerçant / Artisan /Proession libérale en entreprise individuelle(BIC/BNC)',
    questionDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_QUESTION',
    placeHolderDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_LABEL_INPUT_FIELD_MADELIN',
  },
  'gerantMajoritaireSarl': {
    value: 'gerantMajoritaireSarl',
    label: 'Gérant majoritaire de SARL ou SELARL',
    questionDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_QUESTION',
    placeHolderDicoEntry: 'SIMULATEUR_FISCAL_STEP_REVENU_NET_IMPOSABLE_LABEL_INPUT_FIELD_MADELIN',
  }
};

