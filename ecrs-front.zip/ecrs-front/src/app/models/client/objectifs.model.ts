export class ObjectifModel {
  sujetsSelectionnes: number[];
}
