export interface JahiaBlocContent {
  titleId?: string;
  bodyId?: string;
  link?: string;
}

export interface GlobalContent {
  currentLink: JahiaBlocContent;

  headerLinks?: Link[];

  footerLinks?: Link[];
}

export interface Link {
  textId: string;
  contentId?: string;
  descriptionId?: string;
  footerTextId?: string;
  link: string;
}

export interface ContentHeaderParams {
  id?: string;
  hasHeader?: boolean;
  hasFilter?: boolean;
  hasFooter?: boolean;
}

export class FiscalitesLinks {
  libCadreFiscal: string;
  url: string;
  nomContrat: string[];
}


export class DossierJahiaTitleId {
  urlTitle: string;
  jahiaTitle:  string;
}

export const FISCALITES_LINKS: FiscalitesLinks[] = [
  {
    libCadreFiscal: 'Fiscalité PER Entreprise',
    url: '/en-savoir-plus/fiscalite/fiscalite-per-entreprise',
    nomContrat: []
  },
  { libCadreFiscal: 'Fiscalité Madelin', url: '/en-savoir-plus/fiscalite/fiscalite-madelin', nomContrat: [] },
  {
    libCadreFiscal: 'Fiscalité Madelin Agricole',
    url: '/en-savoir-plus/fiscalite/fiscalite-madelin-agricole',
    nomContrat: []
  },
  {
    libCadreFiscal: 'Fiscalité Assurance vie',
    url: '/en-savoir-plus/fiscalite/fiscalite-assurance-vie',
    nomContrat: []
  },
  { libCadreFiscal: 'Fiscalité PERP', url: '/en-savoir-plus/fiscalite/fiscalite-perp', nomContrat: [] },
  { libCadreFiscal: 'Fiscalité Article 82', url: '/en-savoir-plus/fiscalite/fiscalite-article-82', nomContrat: [] },
  { libCadreFiscal: 'Fiscalité PACTE', url: '/en-savoir-plus/fiscalite/fiscalite-pacte', nomContrat: [] },
  { libCadreFiscal: 'Fiscalité Classique', url: '/en-savoir-plus/fiscalite/fiscalite-classique', nomContrat: [] }
];

export const FOOTER_LEXIQUE: Link[] = [
  {
    textId: 'ARTICLES_DOSSIERS_TITLE',
    link: '../en-savoir-plus',
    footerTextId: 'ARTICLE_LINK',
    descriptionId: 'DESCRIPTION_DOSSIERS_ARTICLES_FOOTER'
  },
  {
    textId: 'QUESTIONS_FREQUENTES_TITLE',
    link: '../en-savoir-plus/questions-frequentes',
    footerTextId: 'LINK_FOOTER_FAQ',
    descriptionId: 'QUESTIONS_FREQUENTES_DESCRIPTION'
  }
];

export const FOOTER_FAQ: Link[] = [
  {
    textId: 'ARTICLES_DOSSIERS_TITLE',
    link: '../en-savoir-plus',
    footerTextId: 'ARTICLE_LINK',
    descriptionId: 'DESCRIPTION_DOSSIERS_ARTICLES_FOOTER'
  },
  {
    textId: 'LEXIQUE_TITLE',
    link: '../en-savoir-plus/lexique',
    footerTextId: 'LEXIQUE_LINK',
    descriptionId: 'LEXIQUE_FOOTER_DESCRIPTION'
  }
];

export const FOOTER_EN_SAVOIR_PLUS = [
  {
    textId: 'QUESTIONS_FREQUENTES_TITLE',
    link: '../en-savoir-plus/questions-frequentes',
    footerTextId: 'LINK_FOOTER_FAQ',
    descriptionId: 'QUESTIONS_FREQUENTES_DESCRIPTION'
  },
  {
    textId: 'LEXIQUE_TITLE',
    link: '../en-savoir-plus/lexique',
    footerTextId: 'LEXIQUE_LINK',
    descriptionId: 'LEXIQUE_FOOTER_DESCRIPTION'
  }
];

export const BTN_EN_SAVOIR_PLUS = {
  textId: 'EN_SAVOIR_PLUS_TITLE',
  contentId: '',
  link: '../en-savoir-plus'
};

export const BTN_VOIR_LEXIQUE = {
  textId: 'LEXIQUE_TITLE_VOIR',
  contentId: '',
  link: '../en-savoir-plus/lexique'
};

export const BTN_VOIR_FAQ = {
  textId: 'TITLE_FAQ',
  contentId: '',
  link: '../en-savoir-plus/questions-frequentes'
};

export const DOSSIER_TITLE: DossierJahiaTitleId[] = [
  {urlTitle: 'la-gestion-de-mon-compte', jahiaTitle: 'GESTION_COMPTE_TITLE'},
  {urlTitle: 'le-fonctionnement-de-la-retraite', jahiaTitle: 'FONCTIONNEMENT_RETRAITE_TITLE'},
  {urlTitle: 'preparer-sa-retraite', jahiaTitle: 'PREPARER_RETRAITE_TITLE'},
];
