import { CompartimentId, ContratId } from '@app/models/client/contrat.model';
import { GestionFinanciereContrat } from '@app/models/client/gestion-financiere.model';
import { GrilleInvestissementModel, RepartitionSupport } from '@app/models/client/grille.investissement.model';

export class QadResultModel {
  idQuestion: string;
  labelCourt: string;
  reponseWeight: number;
  codeProfil: string;
  reponsesLabels: string[];

  index: number;
}

export class ResponseModel {
  reponseLabel: string;
  reponseWeight: number;
}

export class QadQuestionsReponses {
  idQue: string;
  codeProfil: string;
  ordre: number;
  libelleLong: string;
  libelleCourt: string;
  choixMultiple: boolean;
  virtualPageName: boolean;
  reponses: QadReponses[];
}

export class QadReponses {
  idQue: string;
  ordre: number;
  libelleLong: string;
  libelleCourt: string;
  score: number;
}

export class TypeProfil {
  score: number;
  codeSupport: string;
  libelleTypeProfil?: string;
}

export class QadProposition {
  numeroProposition: number;
  typeProfilInvestissement: TypeProfil;
  typeProfilEpargnant: TypeProfil;
  typeProfilERE: TypeProfil;
  typeProposition: TypeProposition;
}

export class TypeProposition {
  libelleTypeProposition: string;
  repartitionSupports: RepartitionSupportQad[];
}

export class RepartitionSupportQad {
  pourcentage: number;
  supportInvestissement: SupportInvestissementQad;
}

export class SupportInvestissementQad {
  codeSupport: string;
  libelleSupport: string;
  libelleFront: string;
  modeGestion: string;
}

export class ChoixQadMdp {
  proposition: QadProposition;
  arbitragePerso: boolean;
}

export interface InfoQad {
  contratId: ContratId;
  compartimentId?: CompartimentId;
  qadLauncherEligible?: boolean;
  codesSupportsContrat?: string[];
}


export function convertPropositionSupports(typeProposition: TypeProposition): GestionFinanciereContrat {
  const grillesProfilsNiveau1: GrilleInvestissementModel[] = typeProposition.repartitionSupports.map(e => {
    return {
      id: e.supportInvestissement.codeSupport,
      nom: e.supportInvestissement.libelleFront || e.supportInvestissement.libelleSupport,
      indicateurTauxDerogeable: false,
      tauxRepartitionDefaut: e.pourcentage,
      defaut: false,
      tauxRepartition: e.pourcentage
    };
  });

  const res: GestionFinanciereContrat = {
    listePourCompartiments: [{
      compartimentIds: null,
      gestionFinanciere: {grillesProfilsNiveau1, qadEligible: false, hasUniteDeCompte: false}
    }]
  };
  return res;
}


export function convertPropositionToRepartitionSupports(typeProposition: TypeProposition): RepartitionSupport[] {
  return typeProposition.repartitionSupports.map(e => {
    return {
      id: e.supportInvestissement.codeSupport,
      nom: e.supportInvestissement.libelleFront || e.supportInvestissement.libelleSupport,
      pourcentage: e.pourcentage,
      selectionned: true
    };
  });
}
