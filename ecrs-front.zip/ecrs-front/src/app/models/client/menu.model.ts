import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { buildUrl } from '@ag2rlamondiale/redux-api-ng';
import { containsAll } from '@ag2rlamondiale/transverse-metier-ng';
import { Params } from '@angular/router';
import { MenuJson } from '@app/actions/menu.actions';
import { AqeaRedirectService } from '@app/services/aqea-redirect.service';
import { addQueryParams } from '@app/utils/url.utils';

export const APPLICATION_ECRS = 'ecrs';
export const APPLICATION_AQEA = 'aqea';
export const APPLICATION_PC = 'pc';

export const APPLICATION_ENDPOINTS = {
  [APPLICATION_ECRS]: {
    endpoint: null,
    buildLink: (menuId: string, queryParams: Params = {}) => addQueryParams(`/${menuId}`, queryParams),
    toRouterLink: (link: string, queryParams: Params = {}) => {
      if (link && link.startsWith('/#/')) {
        // Pour retourner un ComputedLink avec routerLink : lien interne à l'application
        return addQueryParams(link.substring(2), queryParams);
      }
      return addQueryParams(link, queryParams);
    }
  },
  [APPLICATION_AQEA]: {endpoint: 'aqea_endpoint'},
  [APPLICATION_PC]: {endpoint: 'parcours_client_endpoint'}
};

export interface MenuItemData {
  id?: string;
  libelle: string;
  link?: string; // ''
  hasLink?: boolean;
  application?: string;
  enable?: boolean;
  visible?: boolean;
  sousMenus?: Array<MenuItemData>;
  fonctionnalites?: Array<string>;
  overriding?: { [k: string]: MenuItemData };
}

export interface ComputedLink {
  /** lien Externe */
  url?: string;

  /** lien Interne */
  routerLink?: string;
  routerLinkActiveOptions?: {
    exact: boolean;
    queryParams?: Params;
  };
}

export function extractUrl(cl: ComputedLink) {
  let url = cl.url;
  if (cl.routerLink) {
    url = buildUrl('#', cl.routerLink);
    if (cl?.routerLinkActiveOptions?.queryParams) {
      url = addQueryParams(url, cl.routerLinkActiveOptions.queryParams);
    }
  }

  return url;
}

export const NOLINK: ComputedLink = {};

export class MenuItem implements MenuItemData {
  id: string;
  link: string;
  libelle: string;
  enable = true;
  visible = true;
  hasLink = true;
  application: string = APPLICATION_ECRS;
  sousMenus?: Array<MenuItem>;
  fonctionnalites: Array<string>;
  separator?: boolean;
  overriding?: { [k: string]: MenuItemData };

  constructor(menu: Menu, data?: MenuItemData) {
    if (!data) {
      return;
    }

    const fonctionnalites = data.fonctionnalites ? data.fonctionnalites : [data.id];

    Object.assign(this, data, {fonctionnalites});
    if (data.sousMenus) {
      this.sousMenus = [];
      data.sousMenus.forEach(e => this.add(e, menu));
    }
    menu.registerPourFonctionnalites(this);
  }

  add(item: MenuItemData, menu: Menu) {
    if (!this.sousMenus) {
      this.sousMenus = [];
    }
    this.sousMenus.push(new MenuItem(menu, item));
    return this;
  }

  setEnableFonctionnalite(enable: boolean, fonctionnalites: Set<string>) {
    if (containsAll(fonctionnalites, this.fonctionnalites)) {
      this.enable = enable;

      if (this.enable === false && this.sousMenus) {
        this.sousMenus.forEach(e => (e.enable = false));
      }
    }

    if (this.sousMenus) {
      this.sousMenus.forEach(e => e.setEnableFonctionnalite(enable, fonctionnalites));
    }
  }

  tousSousMenuDisabled() {
    if (this.sousMenus && this.sousMenus.length > 0) {
      for (const e of this.sousMenus) {
        if (e.enable) {
          return false;
        }
      }
      return true;
    }
    return false;
  }

  /**
   * Regle pour le calcul du lien
   * 0. avec hasLink à false = NOLINK
   * 1. avec link sans application = link absolu
   * 2. avec link et application = link relatif à l'application
   * 3. sans link et application
   *   - pour AQEA : /#{id}:
   *   - pour ECRS : /#/{id}
   */
  computeLink(configService: ConfigService, aqeaRedirect: AqeaRedirectService, queryParams: Params = {}): ComputedLink {
    if (this.hasLink === false) {
      // 0
      return NOLINK;
    }

    if (!this.application && this.link) {
      // 1
      return {url: addQueryParams(this.link, queryParams)};
    }
    if (this.application) {
      return this.computeLinkWithApplication(configService, aqeaRedirect, queryParams);
    }
    return NOLINK;
  }

  private computeLinkWithApplication(
    configService: ConfigService,
    aqeaRedirect: AqeaRedirectService,
    queryParams: Params = {}
  ): ComputedLink {
    const app = APPLICATION_ENDPOINTS[this.application];
    if (!app) {
      console.warn(
        `Impossible de retrouver la config pour l'application de code ${this.application}, pour le menuItem`,
        this
      );
      return {url: '/'};
    }

    if (this.application === APPLICATION_AQEA) {
      if (this.link) {
        return aqeaRedirect.redirectToLink(this.link, queryParams, {redirect: false});
      }
      return aqeaRedirect.redirectToPage(this.id, queryParams, {redirect: false});
    }

    let clink = this.link;
    if (!this.link && app.buildLink) {
      clink = app.buildLink(this.id, queryParams);
    }

    const endpoint = app.endpoint;
    if (endpoint) {
      // Lien externe
      const cep = configService.config[endpoint];
      if (!cep) {
        console.warn(
          `Impossible de retrouver l'URL du endpoint depuis le configService pour l'application de code ${this.application}, pour le menuItem`,
          this
        );
      }
      return {url: buildUrl(cep, clink)};
    }

    // Lien interne
    if (app.toRouterLink) {
      return {routerLink: app.toRouterLink(clink), routerLinkActiveOptions: {exact: false, queryParams}};
    }

    return {routerLink: clink, routerLinkActiveOptions: {exact: false}};
  }

  override(nameConfig: string) {
    if (this.overriding) {
      const overrideConfig = this.overriding[nameConfig];
      if (overrideConfig) {
        Object.assign(this, overrideConfig);
      }
    }
  }

  findMenuItemById(id: string) {
    if (this.sousMenus) {
      for (const item of this.sousMenus) {
        if (item.id === id) {
          return item;
        }
      }
    }
    return null;
  }
}

export class Menu {
  items: Array<MenuItem> = [];
  itemsByFonctionnalites: { [k: string]: MenuItem } = {};

  static fromMenuJson(menuJson: MenuJson) {
    const res = new Menu();
    res.items = [];
    menuJson.menu.forEach(e => res.add(e));
    return res;
  }

  clone(): Menu {
    const menuJson: MenuJson = {menu: this.items};
    return Menu.fromMenuJson(menuJson);
  }

  add(item: MenuItemData) {
    this.items.push(new MenuItem(this, item));
    return this;
  }

  registerPourFonctionnalites(menuItem: MenuItem) {
    menuItem.fonctionnalites.forEach(fonc => (this.itemsByFonctionnalites[fonc] = menuItem));
  }

  setEnableFonctionnalite(enable: boolean, ids: Set<string>): Menu {
    this.items.forEach(e => e.setEnableFonctionnalite(enable, ids));
    this.items.forEach(e => {
      if (e.tousSousMenuDisabled()) {
        e.enable = false;
      }
    });
    return this;
  }

  findMenuItem(idFonctionnalite: string): MenuItem {
    return this.itemsByFonctionnalites[idFonctionnalite];
  }

  findMenuItemById(id: string): MenuItem {
    for (const item of this.items) {
      if (item.id === id) {
        return item;
      } else if (item.sousMenus) {
        const res = item.findMenuItemById(id);
        if (res) {
          return res;
        }
      }
    }
    throw new Error(`Impossible de trouver le MenuItem pour id=${id}`);
  }

  override(nameConfig: string) {
    this.items.forEach(e => e.override(nameConfig));
    this.items.forEach(e => {
      if (e.sousMenus) {
        e.sousMenus.forEach(s => s.override(nameConfig));
      }
    });
    return this;
  }


}
