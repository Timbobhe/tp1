import {ContextCondition} from '@ag2rlamondiale/jahia-ng/lib/models/jahiacondition.model';

export class BasicInfoParcoursDto {
  parcoursSimplifie: boolean;
  contextJahia?: ContextCondition;
  sigElecOff?: boolean;
}
