import {
  ChoixCompartiment,
  ChoixDesinvestissement,
  ChoixRepartitionSupport,
  Etape1,
  Etape2,
  findEtapeForQuestion,
  isQuestionEtapesPrecedentesRepondues,
  QuestionModel,
  ResponseArbitrageEurosPourcentageType,
  ResponseArbitrageFluxStockType,
  ResponseArbitrageTotalPartielType
} from '@app/models/client/arbitrage.model';
import { Reponse } from '@app/models/question-responses.model';
import { ModeGestionMdproType } from '@app/models/client/gestion-financiere.model';

describe('arbitrage.model', () => {

  const reponseChoixCompartiment: Reponse<ChoixCompartiment> = {
    value: {
      tousCompartiments: true,
      compartiment: null,
      encours: null,
      placementsFinanciersDifferentsAutorises: null
    }
  };
  const reponseModeGestion: Reponse<ModeGestionMdproType> = {value: 'LIBRE'};
  const reponseFluxStock: Reponse<ResponseArbitrageFluxStockType> = {value: 'ARBITRAGE_FLUXSTOCK'};
  const reponseEurosPourcent: Reponse<ResponseArbitrageEurosPourcentageType> = {value: 'ARBITRAGE_EUROS'};
  const reponseTotalPartiel: Reponse<ResponseArbitrageTotalPartielType> = {value: 'ARBITRAGE_TOTAL'};
  const reponseDesinvestissement: Reponse<ChoixDesinvestissement> = {
    value: {
      arbitragesClient: [],
      montantTotal: 100
    }
  };
  const reponseRepartition: Reponse<ChoixRepartitionSupport> = {
    value: {
      arbitragesClient: []
    }
  };

  it('QuestionModel : should retrieve attr from QuestionType', () => {
    const questionModel = new QuestionModel();
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_COMPARTIMENT')).toEqual('choixCompartimentERE');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_FLUXSTOCK')).toEqual('choixFluxStock');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_MODEGESTION')).toEqual('choixModeGestion');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_TOTALPARTIEL')).toEqual('choixTotalPartiel');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_EUROSPOURCENT')).toEqual('choixEurosPourcent');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_DESINVESTISSEMENT')).toEqual('choixDesinvestissement');
    expect(questionModel.toAttr('ARBITRAGE_CHOIX_REPARTITION')).toEqual('choixRepartition');
    expect(() => questionModel.toAttr(null)).toThrowError();
  });

  const prepareQuestionModel = () => {
    const questionModel = new QuestionModel();
    questionModel.choixCompartimentERE.choix = reponseChoixCompartiment;
    questionModel.choixFluxStock.choix = reponseFluxStock;
    questionModel.choixEurosPourcent.choix = reponseEurosPourcent;
    questionModel.choixTotalPartiel.choix = reponseTotalPartiel;
    questionModel.choixDesinvestissement.choix = reponseDesinvestissement;
    questionModel.choixRepartition.choix = reponseRepartition;
    return questionModel;
  };

  it('QuestionModel : should reset the state according to the choice : ChoixCompartiment', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_COMPARTIMENT', reponse: reponseChoixCompartiment});
    expect(questionModel.choixCompartimentERE.value).toBeTruthy();
    expect(questionModel.choixFluxStock.value).toBeNull();
    expect(questionModel.choixTotalPartiel.value).toBeNull();
    expect(questionModel.choixEurosPourcent.value).toBeNull();
    expect(questionModel.choixDesinvestissement.value).toBeNull();
    expect(questionModel.choixRepartition.value).toBeNull();
  });

  it('QuestionModel : should reset the state according to the choice : ModeGestion', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_MODEGESTION', reponse: reponseModeGestion});
    expect(questionModel.choixModeGestion.value).toBeTruthy();
    expect(questionModel.choixFluxStock.value).toBeNull();
    expect(questionModel.choixTotalPartiel.value).toBeNull();
    expect(questionModel.choixEurosPourcent.value).toBeNull();
    expect(questionModel.choixDesinvestissement.value).toBeNull();
    expect(questionModel.choixRepartition.value).toBeNull();
  });

  it('QuestionModel : should reset the state according to the choice : ChoixFluxStock', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_FLUXSTOCK', reponse: reponseFluxStock});
    expect(questionModel.choixFluxStock.value).toBeTruthy();
    expect(questionModel.choixTotalPartiel.value).toBeNull();
    expect(questionModel.choixEurosPourcent.value).toBeNull();
    expect(questionModel.choixDesinvestissement.value).toBeNull();
    expect(questionModel.choixRepartition.value).toBeNull();
  });

  it('QuestionModel : should reset the state according to the choice : ChoixTotalPartiel', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_TOTALPARTIEL', reponse: reponseTotalPartiel});
    expect(questionModel.choixFluxStock.value).toBeTruthy();
    expect(questionModel.choixTotalPartiel.value).toBeTruthy();
    expect(questionModel.choixEurosPourcent.value).toBeNull();
    expect(questionModel.choixDesinvestissement.value).toBeNull();
    expect(questionModel.choixRepartition.value).toBeNull();
  });

  it('QuestionModel : should reset the state according to the choice : ChoixDesinvestissement', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_DESINVESTISSEMENT', reponse: reponseDesinvestissement});
    expect(questionModel.choixFluxStock.value).toBeTruthy();
    expect(questionModel.choixTotalPartiel.value).toBeTruthy();
    expect(questionModel.choixDesinvestissement.value).toBeNull(); // FIXME : c'est bizarre que c'est ce que soit attendu
    expect(questionModel.choixRepartition.value).toBeNull();
    expect(questionModel.choixEurosPourcent.value).toBeNull();
  });

  it('QuestionModel : should reset the state according to the choice : ChoixRepartition', () => {
    const questionModel = prepareQuestionModel();
    questionModel.setChoix({questionType: 'ARBITRAGE_CHOIX_REPARTITION', reponse: reponseDesinvestissement});
    expect(questionModel.choixFluxStock.value).toBeTruthy();
    expect(questionModel.choixTotalPartiel.value).toBeTruthy();
    expect(questionModel.choixRepartition.value).toBeNull(); // FIXME : c'est bizarre que c'est ce que soit attendu
  });


  it('Etape 0 : should retrieve Etape for Question', () => {
    // ERE
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_COMPARTIMENT', 'ERE').index).toEqual(0);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_FLUXSTOCK', 'ERE').index).toEqual(0);

    // MDP
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_MODEGESTION', 'MDP').index).toEqual(0);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_FLUXSTOCK', 'MDP').index).toEqual(0);

    // Question MDP dans ERE
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_MODEGESTION', 'ERE')).toBeFalsy();
  });

  it('Etape 1 : should retrieve Etape for Question', () => {
    // ERE
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_TOTALPARTIEL', 'ERE').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_EUROSPOURCENT', 'ERE').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_DESINVESTISSEMENT', 'ERE').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_REPARTITION', 'ERE').index).toEqual(1);

    // MDP
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_TOTALPARTIEL', 'MDP').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_EUROSPOURCENT', 'MDP').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_DESINVESTISSEMENT', 'MDP').index).toEqual(1);
    expect(findEtapeForQuestion('ARBITRAGE_CHOIX_REPARTITION', 'MDP').index).toEqual(1);
  });

  it('isQuestionEtapesPrecedentesRepondues EtapeCourante = 1', () => {
    const questionModel = prepareQuestionModel();
    expect(isQuestionEtapesPrecedentesRepondues(questionModel, Etape1, 'ERE')).toBeTruthy();
  });

  it('isQuestionEtapesPrecedentesRepondues EtapeCourante = 2', () => {
    const questionModel = prepareQuestionModel();
    expect(isQuestionEtapesPrecedentesRepondues(questionModel, Etape2, 'ERE')).toBeTruthy();
  });

});
