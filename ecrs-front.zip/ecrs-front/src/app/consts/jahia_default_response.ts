import { ConfigService } from '@ag2rlamondiale/metis-ng';
import { HeaderData } from '@ag2rlamondiale/transverse-metier-ng';
import { FooterModel } from '@app/models/footer/footer.model';
import { JahiaModel } from '../models/jahia.model';

const LABEL = 'Votre espace client';

const IMG_SRC = 'https://espace-client.ag2rlamondiale.fr/files/live/sites/aql/files/javascriptEtCSS/styles/css/img/picto/sprite-ag2r.png';
export const footerData: FooterModel = {
  footerSocial: {
    title: 'Suivez-nous',
    canals: [
      {
        type: 'facebook',
        link: 'https://www.facebook.com/AG2RLAMONDIALE/',
        iconClass: 'iconFb',
        imgSrc:
        IMG_SRC,
        backgroundPositionX: '-197px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'tweeter',
        link: 'https://twitter.com/ag2rlamondiale?lang=fr',
        iconClass: 'iconTw',
        imgSrc:
        IMG_SRC,
        backgroundPositionX: '-291px',
        backgroundPositionY: '-120px'
      },
      {
        type: 'linkedin',
        link: 'https://fr.linkedin.com/company/ag2r-la-mondiale',
        iconClass: 'iconLnkd',
        imgSrc:
        IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'scoope',
        link: 'http://www.scoop.it/u/ag2rlamondiale',
        iconClass: 'iconScoope',
        imgSrc:
        IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      },
      {
        type: 'youtube',
        link: 'https://www.youtube.com/user/AG2RLAMONDIALE',
        iconClass: 'iconYoutube',
        imgSrc:
        IMG_SRC,
        backgroundPositionX: '-236px',
        backgroundPositionY: '-46px'
      }
    ]
  },
  footerTitle: 'Les sites AG2R LA MONDIALE',
  footerCols: [
    {
      title: 'SITES SERVICES DU GROUPE',
      links: [
        {
          label: 'Portail Groupe',
          url: 'https://www.ag2rlamondiale.fr/'
        },
        {
          label: 'Ventes en ligne',
          url: 'https://www.vente-en-ligne.ag2rlamondiale.fr/accueil'
        },
        {
          label: 'Clientèle patrimoniale',
          url: 'http://www.patrimoine.ag2rlamondiale.fr/'
        },
        {
          label: 'Partenariat patrimonial',
          url:
            'https://www.partenariat.patrimonial.ag2rlamondiale.fr/accueil.html'
        },
        {
          label: 'Aidons les nôtres',
          url: 'https://www.aidonslesnotres.fr/'
        },
        {
          label: 'Préparons ma retraite',
          url: 'http://www.preparonsmaretraite.fr/cms/retraite.html'
        },
        {
          label: 'Club Expertises et Solutions',
          url:
            'https://www.ag2rlamondiale.fr/club-expertises-et-solutions'
        },
        {
          label: 'Epargne salariale',
          url: 'http://www.epargne.ag2rlamondiale.fr/'
        }
      ]
    },
    {
      title: 'Autres sites du groupe',
      links: [
        {
          label: 'Cyclisme',
          url: 'http://www.cyclisme.ag2rlamondiale.fr/fr/'
        },
        {
          label: 'Voile',
          url: 'http://transat.ag2rlamondiale.fr/fr/s01_home/s01p01_home.php'
        },
        {
          label: 'Magazine Pleine Vie',
          url: 'http://www.pleinevie.fr/'
        }
      ]
    },
    {
      title: 'Mutuelles Partenaires du Groupe',
      links: [
        {
          label: 'La Frontalière',
          url: 'http://www.mutuelle-lafrontaliere.fr/'
        },
        {
          label: 'Leroy Somer',
          url: 'http://www.mutuelle-leroy-somer.com/'
        },
        {
          label: 'Mutuelle Interprofessionnelle des Antilles et de Guyane',
          url: 'http://www.miag.fr/'
        },
        {
          label: 'Mutuelle des Professions Judiciaires',
          url: 'http://www.mutuelle-mpj.fr/home.html'
        },
        {
          label: 'Mutuelle Just\'En Famille',
          url: 'http://www.justenfamille.fr/'
        }
      ]
    },
    {
      title: 'Caisses de retraite partenaires du groupe',
      links: [
        {
          label: 'IRCOM La Verrière',
          url: 'http://www.ircom-laverriere.com/'
        },
        {
          label: 'CGRR',
          url: 'http://www.cgrr.fr/'
        }
      ]
    }
  ],
  footerLegal: {
    cols: [
      {
        label: 'Plan du site',
        url: 'https://www.ag2rlamondiale.fr/plan-du-site'
      },
      {
        label: 'Mentions légales',
        url: 'https://www.ag2rlamondiale.fr/mentions-legales'
      },
      {
        label: 'Protection des données',
        url:
          'https://www.ag2rlamondiale.fr/protection-des-donnees-espace-client'
      },
      {
        label: 'Nous contacter',
        url: 'https://www.ag2rlamondiale.fr/nous-contacter'
      }
    ],
    copyRight: '© 2011-2018 AG2R LA MONDIALE'
  }
};


export function getJahiaResponse(configService: ConfigService): JahiaModel {
  return {
    headerAg2r: {
      title: {
        image: {
          alt: 'AG2R LA MONDIALE',
          url: configService.config['jahia_ressources_logos_root'].concat('AG2R-desktop.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('AG2R-mobile.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerArialCNP: {
      title: {
        image: {
          alt: 'ARIAL CNP ASSURANCES',
          url: configService.config['jahia_ressources_logos_root'].concat('ACA.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('ACA.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerPartenaireNie: {
      title: {
        image: {
          alt: '',
          url: configService.config['jahia_ressources_logos_root'].concat('logo_nie_aca_small.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('logo_nie_aca_small.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    headerPartenaireAdding: {
      title: {
        image: {
          alt: '',
          url: configService.config['jahia_ressources_logos_root'].concat('adding-logo.svg'),
          urlMobile: configService.config['jahia_ressources_logos_root'].concat('adding-logo.svg'),
          urlToRedirect: configService.config['parcours_client_endpoint']
        },
        label: LABEL
      },
      user: null
    },
    onboardingImage: {
      alt: 'Onboarding',
      url: configService.config['jahia_ressources_onboarding_root'].concat('onboarding-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_onboarding_root'].concat('onboarding-mobile.jpg'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    biaImage: {
      alt: 'BIA',
      url: configService.config['jahia_ressources_bia_root'].concat('bia-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_bia_root'].concat('bia-mobile.jpg'),
      urlToRedirect: null
    },
    coordonneesBancairesImage: {
      alt: 'CoordonneesBancaires',
      url: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_coordonnees_bancaires_root'].concat('coordonnees-bancaires-mobile.jpg'),
      urlToRedirect: null
    },
    versementImage: {
      alt: 'Versement',
      url: configService.config['jahia_ressources_versement_root'].concat('versement-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_versement_root'].concat('versement-mobile.jpg'),
      urlToRedirect: null
    },
    contactImage: {
      alt: 'ContactReclamation',
      url: configService.config['jahia_ressources_contact_root'].concat('contact-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_contact_root'].concat('contact-mobile.jpg'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    arbitrageImage: {
      alt: 'Arbitrage',
      url: configService.config['jahia_ressources_arbitrage_root'].concat('arbitrage-desktop.jpg'),
      urlMobile: configService.config['jahia_ressources_arbitrage_root'].concat('arbitrage-mobile.jpg'),
      urlToRedirect: configService.config['mkg_bloc_endpoint']
    },
    syntheseImages: {
      mkgDefaultBloc: {
        alt: 'MKG BLOC',
        url: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_bloc/pub.jpg'),
        urlMobile: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_bloc/pub-mobile.jpg'),
        urlToRedirect: null// configService.config['mkg_bloc_endpoint']
      },

      mkgLyfeBloc: {
        alt: 'LYFE BLOC',
        url: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_lyfe_bloc/lyfe.jpg'),
        urlMobile: configService.config['jahia_ressources_synthese_images_root'].concat('mkg_lyfe_bloc/lyfe.jpg'),
        urlToRedirect: configService.config['mkg_lyfe_bloc_endpoint']
      }
    },
    contratDetailImages: {
      contratDetailCoverImage: {
        alt: 'Contrat-detail',
        url: configService.config['jahia_ressources_contrat_detail_root'].concat('contrat-detail-desktop.jpg'),
        urlMobile: configService.config['jahia_ressources_contrat_detail_root'].concat('contrat-detail-mobile.jpg'),
        urlToRedirect: null
      },
      contratDetailHeaderImage: {
        alt: 'Contrat-detail-header',
        url: configService.config['jahia_ressources_contrat_detail_root'].concat('contrat-detail-header-desktop.jpg'),
        urlMobile: configService.config['jahia_ressources_contrat_detail_root'].concat('contrat-detail-header-mobile.jpg'),
        urlToRedirect: null
      }
    },
    simulateurImages: {
      simulateurImpotImage: {
        alt: 'simulateur-fiscal',
        url: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-impot.jpg'),
        urlMobile: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-impot.jpg'),
        urlToRedirect: null
      },
      simulateurRenteImage: {
        alt: 'simulateur-rente',
        url: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-rente.jpg'),
        urlMobile: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-rente.jpg'),
        urlToRedirect: null
      },
      simulateurRetraiteImage: {
        alt: 'simulateur-retraite',
        url: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-retraite.jpg'),
        urlMobile: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-retraite-mobile.jpg'),
        urlToRedirect: null
      },
      simulateurHeaderImage: {
        alt: 'simulateur',
        url: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-desktop.jpg'),
        urlMobile: configService.config['jahia_ressources_simulateur_root'].concat('simulateur-mobile.jpg'),
        urlToRedirect: null
      }
    }
  };
}

export function getHeaderUserEre(isFilialeAca: boolean, configService: ConfigService): HeaderData {
  const theme = isFilialeAca ? 'aca' : 'alm2';
  return {
    user: {
      dropDown: [
        {
          title: 'Données personnelles',
          selectionColor: '0088bb',
          cssClassName: 'ag2r-134-record-of-situation',
          functionName: 'connexionData',
        },
        {
          title: 'Déconnexion',
          urlToRedirect: configService.config['cas_server_logout_url'],
          selectionColor: '0088bb',
          cssClassName: 'ag2r-004-turn-off',
          functionName: 'logout'
        },


      ]
    },
    title: {
      display: true,
      label: 'RETRAITE SUPPLÉMENTAIRE',
      iconClass: 'ag2r-127-annuities'
    }
  };
}

export function getHeaderUserMdpro(configService: ConfigService): HeaderData {
  return {
    user: {
      dropDown: [

        {
          title: 'Données personnelles',
          selectionColor: '0088bb',
          cssClassName: 'ag2r-134-record-of-situation',
          functionName: 'connexionData',
        },
        {
          title: 'Déconnexion',
          urlToRedirect: configService.config['cas_server_logout_url'],
          selectionColor: '0088bb',
          cssClassName: 'ag2r-004-turn-off',
          functionName: 'logout'
        }
      ]
    },

    title: {
      display: true,
      label: 'RETRAITE SUPPLÉMENTAIRE ',
      iconClass: 'ag2r-127-annuities'
    }

  };
}

export function getHeaderUserPartenaire(configService: ConfigService): HeaderData {
  return {
    user: {
      dropDown: [
        {
          title: 'Données personnelles',
          selectionColor: '0088bb',
          cssClassName: 'ag2r-134-record-of-situation',
          functionName: 'connexionData',
        }
      ]
    }

  };
}
