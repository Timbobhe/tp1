import { NombreTracesConfig } from '@ag2rlamondiale/transverse-metier-ng';

export const MARKS = {
  indexHtml: 'index.html',
  INIT_APP: 'INIT_APP',
  bootstrapAppModule: 'bootstrap-AppModule',
  AppComponentNgOnInit: 'AppComponent-ngOnInit',
  SyntheseVisible: 'SyntheseVisible',
  SyntheseNavigated: 'SyntheseNavigated'
};

export const MEASURES = {
  SyntheseVisibleDepuisNavigated: 'SyntheseVisibleDepuisNavigated',
  SyntheseVisibleDepuisIndexHtml: 'SyntheseVisibleDepuisIndexHtml',

  indexHtmlTobootstrapAppModule: 'index.htmlTobootstrap-AppModule',
  bootstrapToAppComponentNgOnInit: 'bootstrapToAppComponentNgOnInit'
};

/**
 * Pour envoyer les traces Front au Back via API *traceFrontPerformance*: '/api/secure/trace-front/performance'
 * il est nécessaire de déclarer les mesures qui nous interesse + le nombre de fois que l'on va les envoyer.
 *
 * ___
 * Pour prendre des Mesures il faut utiliser la classe **Performance** dispo depuis la Lib **redux-api-ng**.
 */
export const TraceFrontConfig: NombreTracesConfig = {
  [MEASURES.SyntheseVisibleDepuisIndexHtml]: {number: 1, justLog: false},
  [MEASURES.SyntheseVisibleDepuisNavigated]: {number: 1, justLog: true}
};
