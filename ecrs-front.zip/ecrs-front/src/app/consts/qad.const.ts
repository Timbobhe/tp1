export const QAD_PATH = 'sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/qad/area-simple-content.apiV2.html.ajax?blockId=qad_code_';

export const QAD_PATH_SUFFIX = '&typeUrlResource=absolute&removeComments';

export const CODE_PROFIL_PREFIX = 'GESTION_FIN_QAD_PROFIL_CODE_';
export const QAD_MDP_PATH = '/sites/aqe/ecrs/qad/body-content.apiV2.html.ajax?blockId=qad_profil_';
// 'sites/aqe/home/retraite-supplementaire/demandes-en-ligne/arbitrage/mdpro/qad/area-simple-content.apiV2.html.ajax?blockId=qad_profil_';
