export const ONBOARDING = 'accueil';
export const DETAILS_SUPPORT = 'DetailsSupport';
export const VERSEMENT = 'versement';
export const ARRET_VERSEMENT = 'arretVersement';
export const SIMULATEUR_RENTE_VIF = 'SimulateurRenteVIF';
export const SIMULATEUR_FISCAL_MDP = 'https://www.ag2rlamondiale.fr/retraite/s-informer-sur-la-retraite/simuler-votre-retraite';
export const SYNTHESE = 'SyntheseDesComptes';
export const COMPLETER_BIA = 'completerBIA';
export const MODIF_DONNEES_PERSO = 'ModifDonneesPerso';
export const CONTACT = 'ContactFormulaire';
export const RECLAMATION = 'ReclamationFormulaire';
export const COORDONNEES_BANCAIRES = 'VosCoordonneesBancaires';
export const MODIF_RIB = 'ModifierRIB';
export const MODIF_CLAUSE_BENEFICIAIRE = 'ClauseBeneficiaire';
export const COMPLETER_BIA_SIGELEC = 'completerBIASigElec';
export const MODIFIER_CLAUSE_BENEF_SIGELEC = 'ClauseBeneficiaireSigElec';
export const ARBITRAGE_SIGELEC = 'ArbitrageSigElec';
export const ARBITRAGE = 'Arbitrage';
export const VOS_DONNEES_VERSEMENT = 'VosDonneesVersement';
export const QUESTION_FREQUENTE = 'QuestionsFrequentes';
export const LEXIQUE = 'Lexique';
export const FISCALITE_PER_ENTREPRISE = 'Fiscalite1';
export const FISCALITE_MADELIN = 'Fiscalite2';
export const FISCALITE_MADELIN_AGRICOLE = 'Fiscalite3';
export const FISCALITE_ASSURANCE_VIE = 'Fiscalite4';
export const FISCALITE_PERP = 'Fiscalite5';
export const FISCALITE_ARTICLE82 = 'Fiscalite6';
export const FISCALITE_PACTE = 'Fiscalite7';
export const COMPTE_DEMO = 'CompteDemo';
export const GESTION_COMPTE = 'EnSavoirPlus';
export const DOCUMENTS = 'vosDocuments';
export const GESTION_FINANCIERE = 'GestionFinanciere';
export const DETAILS_CONTRAT = 'DetailsContrat';
export const SIMULATEUR_FISCAL = 'SimulateurFiscal';

export type FonctionnaliteType =
  'accueil'
  | 'Arbitrage'
  | 'ArbitrageSigElec'
  | 'Article'
  | 'ChoixOption'
  | 'ClauseBeneficiaire'
  | 'ClauseBeneficiaireSigElec'
  | 'completerBIA'
  | 'completerBIASigElec'
  | 'ContactFormulaire'
  | 'CompteDemo'
  | 'demandeLiquidation'
  | 'demandeLiquidationSigElec'
  | 'DetailsSupport'
  | 'Dossier'
  | 'EnSavoirPlus'
  | 'EvolutionEncours'
  | 'EvolutionSupport'
  | 'Fiscalite1'
  | 'Fiscalite2'
  | 'Fiscalite3'
  | 'Fiscalite4'
  | 'Fiscalite5'
  | 'Fiscalite6'
  | 'Fiscalite7'
  | 'GestionFinanciere'
  | 'Guide'
  | 'homeAction'
  | 'Lexique'
  | 'ListeArticles'
  | 'Login'
  | 'ModifDonneesPerso'
  | 'ModifierRIB'
  | 'QuestionsFrequentes'
  | 'ReclamationFormulaire'
  | 'SimulateurFiscal'
  | 'SimulateurOptionRente'
  | 'SimulateurRenteVIF'
  | 'suivreVosDemandes'
  | 'SyntheseDesComptes'
  | 'versement'
  | 'versementSigElec'
  | 'versementLibre'
  | 'versementLibreSigElec'
  | 'versementProgramme'
  | 'versementProgrammeSigElec'
  | 'vidercache'
  | 'VosCoordonneesBancaires'
  | 'vosDocuments'
  | 'vosDonnees'
  | 'VosDonneesContract'
  | 'VosdonneesPerso'
  | 'vosEcheanciers'
  | 'VosDonneesVersement'
  | 'arretVersement'
  | 'DetailsContrat';


export const FonctionnaliteLabel: Partial<{ [k in FonctionnaliteType]: string }> = {
  'completerBIA': 'Compléter votre bulletin d\'affiliation',
  'ClauseBeneficiaire': 'Modification de clause bénéficiaire',

  'accueil': 'Onboarding',
  'Arbitrage': 'Arbitrage',
  'ArbitrageSigElec': 'Signature électronique de l\'arbitrage',
  'Article': 'Article',
  'ChoixOption': 'Choix d\'option',
  'ClauseBeneficiaireSigElec': 'Signature électronique de la Clause bénéficiaire',
  'completerBIASigElec': 'Signature électronique de compléter BIA',
  'ContactFormulaire': 'Formulaire de contact',
  'CompteDemo': 'Compte demo',
  'demandeLiquidation': 'Demande de liquidation',
  'demandeLiquidationSigElec': 'Signature électronique de la demande de liquidation',
  'DetailsSupport': 'Détails support',
  'Dossier': 'Dossier',
  'EnSavoirPlus': 'En savoir plus',
  'EvolutionEncours': 'Evolution encours',
  'EvolutionSupport': 'Evolution support',
  'Fiscalite1': 'Fiscalité PER ENTREPRISES',
  'Fiscalite2': 'Fiscalité Madelin',
  'Fiscalite3': 'Fiscalité Madelin Agricole',
  'Fiscalite4': 'Fiscalité Assurance vie',
  'Fiscalite5': 'Fiscalité PERP',
  'Fiscalite6': 'Fiscalité Article 82',
  'Fiscalite7': 'Fiscalité PACTE',
  'GestionFinanciere': 'Gestion financière',
  'Guide': 'Guide',
  'homeAction': 'Home action',
  'Lexique': 'Lexique',
  'ListeArticles': 'Liste des articles',
  'Login': 'Login',
  'ModifDonneesPerso': 'Modifier données personnelles',
  'ModifierRIB': 'Modifier RIB',
  'QuestionsFrequentes': 'FAQ',
  'ReclamationFormulaire': 'Réclamation',
  'SimulateurFiscal': 'Simulateur fiscal',
  'SimulateurOptionRente': 'Simulateur rente avec option',
  'SimulateurRenteVIF': 'Simulateur rente VIF',
  'suivreVosDemandes': 'Suivre vos demandes',
  'SyntheseDesComptes': 'Synthèse des comptes',
  'versement': 'Versement',
  'versementSigElec': 'Signature électronique du versement',
  'versementLibre': 'Versement libre',
  'versementLibreSigElec': 'Signature électronique du versement libre',
  'versementProgramme': 'Versement programmé',
  'versementProgrammeSigElec': 'Signature électronique du versement programmé',
  'vidercache': 'Vider le cache',
  'VosCoordonneesBancaires': 'Vos coordonnées bancaires',
  'vosDocuments': 'Vos documents',
  'vosDonnees': 'Vos données',
  'VosDonneesContract': 'Vos données contractuelles',
  'VosdonneesPerso': 'Vos données personnelles',
  'vosEcheanciers': 'Vos échéanciers',
  'VosDonneesVersement': 'Vos versements',
  'arretVersement': 'Arrêter votre versement programmé',
  'DetailsContrat': 'Details du contrat'
};


export const fonctionnalites: { [k in FonctionnaliteType]: FonctionnaliteType } = {
  accueil: 'accueil',
  Arbitrage: 'Arbitrage',
  ArbitrageSigElec: 'ArbitrageSigElec',
  Article: 'Article',
  ChoixOption: 'ChoixOption',
  ClauseBeneficiaire: 'ClauseBeneficiaire',
  ClauseBeneficiaireSigElec: 'ClauseBeneficiaireSigElec',
  completerBIA: 'completerBIA',
  completerBIASigElec: 'completerBIASigElec',
  ContactFormulaire: 'ContactFormulaire',
  CompteDemo: 'CompteDemo',
  demandeLiquidation: 'demandeLiquidation',
  demandeLiquidationSigElec: 'demandeLiquidationSigElec',
  DetailsSupport: 'DetailsSupport',
  Dossier: 'Dossier',
  EnSavoirPlus: 'EnSavoirPlus',
  EvolutionEncours: 'EvolutionEncours',
  EvolutionSupport: 'EvolutionSupport',
  Fiscalite1: 'Fiscalite1',
  Fiscalite2: 'Fiscalite2',
  Fiscalite3: 'Fiscalite3',
  Fiscalite4: 'Fiscalite4',
  Fiscalite5: 'Fiscalite5',
  Fiscalite6: 'Fiscalite6',
  Fiscalite7: 'Fiscalite7',
  GestionFinanciere: 'GestionFinanciere',
  Guide: 'Guide',
  homeAction: 'homeAction',
  Lexique: 'Lexique',
  ListeArticles: 'ListeArticles',
  Login: 'Login',
  ModifDonneesPerso: 'ModifDonneesPerso',
  ModifierRIB: 'ModifierRIB',
  QuestionsFrequentes: 'QuestionsFrequentes',
  ReclamationFormulaire: 'ReclamationFormulaire',
  SimulateurFiscal: 'SimulateurFiscal',
  SimulateurOptionRente: 'SimulateurOptionRente',
  SimulateurRenteVIF: 'SimulateurRenteVIF',
  suivreVosDemandes: 'suivreVosDemandes',
  SyntheseDesComptes: 'SyntheseDesComptes',
  versement: 'versement',
  versementSigElec: 'versementSigElec',
  versementLibre: 'versementLibre',
  versementLibreSigElec: 'versementLibreSigElec',
  versementProgramme: 'versementProgramme',
  versementProgrammeSigElec: 'versementProgrammeSigElec',
  vidercache: 'vidercache',
  VosCoordonneesBancaires: 'VosCoordonneesBancaires',
  vosDocuments: 'vosDocuments',
  vosDonnees: 'vosDonnees',
  VosDonneesContract: 'VosDonneesContract',
  VosdonneesPerso: 'VosdonneesPerso',
  vosEcheanciers: 'vosEcheanciers',
  VosDonneesVersement: 'VosDonneesVersement',
  arretVersement: 'arretVersement',
  DetailsContrat: 'DetailsContrat'
};


export const Arbitrages: FonctionnaliteType[] = [ARBITRAGE, ARBITRAGE_SIGELEC];
export const Versements: FonctionnaliteType[] = ['versementLibre', 'versementLibreSigElec', 'versementProgramme', 'versementProgrammeSigElec'];
