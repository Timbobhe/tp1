package fr.ag2rlamondiale.cab.purge;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.TestPropertySource;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
@TestPropertySource(locations = "classpath:application-test.properties")
public class PurgeDaoTest {

	@Autowired
	private PurgeJdbcDao purgeJdbcDao;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@MockBean
	PurgeApplication purgeApplication;


	@Test
	void purgeTest() throws SQLException {
		final PurgeResult purgeResult = purgeJdbcDao.purge();
		assertEquals(3, purgeResult.getNombreEvenPurges("TP_SM_PER_PP"));
		assertEquals(1, purgeResult.getNombreEvenPurges("TP_SM_STRUCTINV_CONSULTER"));
		assertEquals(0, purgeResult.getNombreEvenPurges("PAS_SUPPRESSION"));

		Integer afterDelete = jdbcTemplate.queryForObject("select count(*) from TBCL0TRC", Integer.class);
		assertEquals(2, afterDelete);

	}

}
