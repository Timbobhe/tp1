package fr.ag2rlamondiale.cab.purge;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Data
@ConfigurationProperties(prefix = "purge.config")
@Component
public class PurgeConfiguration {

	private int maxRowNum = 200000;
	private int commitRows = 1000;
	private Map<String, Integer> events;

}
