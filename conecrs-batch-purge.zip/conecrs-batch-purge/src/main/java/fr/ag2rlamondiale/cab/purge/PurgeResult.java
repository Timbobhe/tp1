package fr.ag2rlamondiale.cab.purge;

import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class PurgeResult {
	private Map<String, Integer> nombreEvenPurges = new HashMap<>();


	public void setNombreEvenPurges(String typeEven, Integer nb) {
		nombreEvenPurges.put(typeEven, nb);
	}

	public Integer getNombreEvenPurges(String typeEven) {
		return nombreEvenPurges.getOrDefault(typeEven, 0);
	}
}
