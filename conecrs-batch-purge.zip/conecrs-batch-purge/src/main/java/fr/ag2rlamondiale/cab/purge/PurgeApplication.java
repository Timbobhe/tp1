package fr.ag2rlamondiale.cab.purge;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@Slf4j
@SpringBootApplication
public class PurgeApplication {

	@Autowired
	private PurgeJdbcDao purgeJdbcDao;

	public static void main(String[] args) {
		SpringApplication.run(PurgeApplication.class, args);
	}


	@EventListener
	public void onApplicationEvent(ApplicationReadyEvent ae) {
		try {
			log.info("Execution de batch de suppression");
			purgeJdbcDao.purge();
			log.info("FIN Execution de batch de suppression avec SUCCESS");
			System.exit(0);
		} catch (Exception e) {
			log.error("Erreur Execution de batch de suppression", e);
			System.exit(1);
		}
	}
}
