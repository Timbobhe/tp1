package fr.ag2rlamondiale.cab.purge;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.Map;

@Slf4j
@Service
public class PurgeJdbcDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private PurgeConfiguration purgeConfiguration;

	public PurgeResult purge() throws SQLException {
		var rowsAffected = 0;
		var rowsCommit = 0;
		var deleteQuery = "DELETE FROM TBCL0TRC " +
				"WHERE TYEVETRC = ? " +
				"AND TSDEBTRC <= ADD_MONTHS(trunc(sysdate) ,?) " +
				"AND ROWNUM < ?";

		PurgeResult res = new PurgeResult();
		for (Map.Entry<String, Integer> m : purgeConfiguration.getEvents().entrySet()) {
			int deleted = jdbcTemplate.update(deleteQuery, m.getKey(), m.getValue(), purgeConfiguration.getMaxRowNum());
			res.setNombreEvenPurges(m.getKey(), deleted);
			if (deleted >= 1) {
				rowsAffected += deleted;
				rowsCommit += deleted;
				if (rowsCommit >= purgeConfiguration.getCommitRows()) {
					jdbcTemplate.execute("commit");
					rowsCommit = 0;
				}
				log.info("nombre de lignes supprimes pour type evenement : {} -> {}", m.getKey(), deleted);
			} else if (log.isDebugEnabled()) {
				log.debug("nombre de lignes supprimes pour type evenement : {} -> {}", m.getKey(), deleted);
			}
		}
		jdbcTemplate.execute("commit");
		log.info("nombre des evenements supprimes: {}", rowsAffected);
		return res;
	}
}
