package fr.ag2rlamondiale.ecrs.expo.contrat.mapping;

import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

class RequestClientMapperTest {

    RequestClientMapper requestClientMapper = new RequestClientMapperImpl();

    @Test
    void test_map_client_internet() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        // When
        final IdentiteNumeriqueHabilitation identiteNumeriqueHabilitation = requestClientMapper.map(clientInternet);

        // Then
        assertEquals("1", identiteNumeriqueHabilitation.getIdentifiantFournisseurIdentiteNumerique());
        assertEquals("1mgu13", identiteNumeriqueHabilitation.getLogin());
    }

    @Test
    void test_map_client_partenaire_from_refExterne() throws Exception {
        // Given
        RequestClientPartenaireDto clientPartenaire = RequestClientPartenaireDto.builder()
                .codeApplicationPartenaire("A1587")
                .referenceExterne("006040962735940901")
                .build();

        // When
        final UserRequestDto userRequest = requestClientMapper.map(clientPartenaire);

        // Then
        assertEquals("49505", userRequest.getAttributes().fdiPerimeterName());
        assertEquals("{refExterne=006040962735940901}", userRequest.getAttributes().businessIdMap());
        assertEquals(Set.of("EERE-Federation"), userRequest.getAttributes().getRoles());
    }

    @Test
    void test_map_client_partenaire_from_idEpargneRetraite() throws Exception {
        // Given
        RequestClientPartenaireDto clientPartenaire = RequestClientPartenaireDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantEpargneRetraite("P4167507")
                .build();

        // When
        final UserRequestDto userRequest = requestClientMapper.map(clientPartenaire);

        // Then
        assertEquals("49505", userRequest.getAttributes().fdiPerimeterName());
        assertEquals("{idEpargneRetraite=P4167507}", userRequest.getAttributes().businessIdMap());
        assertEquals(Set.of("EERE-Federation"), userRequest.getAttributes().getRoles());
    }
}
