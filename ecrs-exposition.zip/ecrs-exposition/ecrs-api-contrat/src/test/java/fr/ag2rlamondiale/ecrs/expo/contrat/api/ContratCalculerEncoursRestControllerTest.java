package fr.ag2rlamondiale.ecrs.expo.contrat.api;

import fr.ag2rlamondiale.ecrs.expo.common.ApiConstants;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.ContratTestConfig;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.IContratCalculerEncoursFacade;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = ContratCalculerEncoursRestController.class, excludeAutoConfiguration = SecurityAutoConfiguration.class)
@Import(ContratCalculerEncoursRestController.class)
@ContextConfiguration(classes = ContratTestConfig.class)
class ContratCalculerEncoursRestControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IContratCalculerEncoursFacade contratCalculerEncoursFacade;

    @Test
    void test_should_validate_error_400() throws Exception {
        mvc.perform(get("/v1/contrats/calculer_encours")).andExpect(status().is4xxClientError());
    }

    @Test
    void test_should_call_from_client_request() throws Exception {
        // Given
        given(contratCalculerEncoursFacade.calculerEncoursTotal(any(RequestClientInternetDto.class))).willReturn(ContratCalculerEncoursRestController.exemple());

        // When
        final ResultActions perform = mvc.perform(get("/v1/contrats/calculer_encours?idFournisseurIdentite=1&loginFournisseurIdentite=1mgu13"));

        // Then
        perform.andExpect(status().is2xxSuccessful());
    }

    @Test
    void test_should_call_from_client_partenaire() throws Exception {
        // Given
        given(contratCalculerEncoursFacade.calculerEncoursTotal(any(RequestClientInternetDto.class))).willReturn(ContratCalculerEncoursRestController.exemple());

        // When
        final ResultActions perform = mvc.perform(get("/v1/contrats/calculer_encours?identifiantEpargneRetraite=P4508543").header(ApiConstants.HEADER_XCALLER, "A1587"));

        // Then
        perform.andExpect(status().is2xxSuccessful());
    }
}
