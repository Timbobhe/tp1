package fr.ag2rlamondiale.ecrs.expo.contrat.business.impl;

import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratClientFacade;
import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.expo.common.business.IUserContextBuilder;
import fr.ag2rlamondiale.ecrs.expo.common.business.impl.UserContextBuilderImpl;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.expo.common.exception.NotFoundException;
import fr.ag2rlamondiale.ecrs.expo.common.exception.ServiceException;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.IContratCalculerEncoursFacade;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.EncoursContratMapper;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.EncoursContratMapperImpl;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.RequestClientMapper;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.RequestClientMapperImpl;
import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.business.ISimpleBlocageFacade;
import fr.ag2rlamondiale.trm.client.rest.IPartenaireRestClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapper;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapperImpl;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;

@RunWith(SpringRunner.class)
@SpringBootTest
class ContratCalculerEncoursFacadeImplTest {

    @Autowired
    IContratCalculerEncoursFacade contratCalculerEncoursFacade;

    @MockBean
    private IRechercherHabiliFacade rechercherHabiliFacade;

    @MockBean
    private IContratClientFacade contratClientFacade;

    @MockBean
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Autowired
    private EncoursContratMapper encoursContratMapper;

    @MockBean
    private IUserIdentityProviderFacade userIdentityProviderFacade;

    @Autowired
    private RequestClientMapper requestClientMapper;

    @MockBean
    ISimpleBlocageFacade simpleBlocageFacade;

    @TestConfiguration
    static class ContratCalculerEncoursFacadeImplTestConfiguration {
        @MockBean
        IPartenaireRestClient partenaireRestClient;

        @Bean
        IContratCalculerEncoursFacade contratCalculerEncoursFacade() {
            return new ContratCalculerEncoursFacadeImpl();
        }

        @Bean
        EncoursContratMapper encoursContratMapper() {
            return new EncoursContratMapperImpl();
        }

        @Bean
        RequestClientMapper requestClientMapper() {
            return new RequestClientMapperImpl();
        }

        @Bean
        IUserContextBuilder userContextBuilder() {
            return new UserContextBuilderImpl();
        }

        @Bean
        PartenaireMapper partenaireMapper() {
            return new PartenaireMapperImpl();
        }

        @Bean
        UserContextHolder userContextHolder() {
            return new UserContextHolder();
        }

        @Bean
        ISupplierLibService supplierLibService() {
            return new ISupplierLibService() {
                @Override
                public String getCodeCassiniAppli() {
                    return "A1573";
                }

                @Override
                public String getLibelleAppli() {
                    return null;
                }

                @Override
                public String getUrlFront() {
                    return null;
                }
            };
        }
    }


    @BeforeEach
    public void setUp() throws Exception {
        when(simpleBlocageFacade.getInfosBlocagesClient(any(), any())).thenReturn(new InfosBlocagesClient());
    }

    @Test
    void test_calculerEncoursTotal_clientInternet() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());

        // When
        final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);

        // Then
        assertNotNull(encoursTotal);
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_contrat_tous_bloque() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());

        given(simpleBlocageFacade.getInfosBlocagesClient(any(), any())).willAnswer(invocation -> {
            InfosBlocagesClient res = new InfosBlocagesClient();
            res.setFonctionnalitesBloqueesContrats(Map.of("id1", Set.of(FonctionnaliteType.SYNTHESE.getLabel())));
            return res;
        });

        // When
        final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);

        // Then
        assertNotNull(encoursTotal);
        assertTrue(encoursTotal.isEncoursNonDisponible());
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_contrat_un_bloque() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        final List<ContratHeader> contrats = contrats(Map.of("id1", CodeSiloType.ERE, "id2", CodeSiloType.MDP));
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id2", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(20000d)
                .dateEncours("01/04/2022")
                .build());

        given(simpleBlocageFacade.getInfosBlocagesClient(any(), any())).willAnswer(invocation -> {
            InfosBlocagesClient res = new InfosBlocagesClient();
            res.setFonctionnalitesBloqueesContrats(Map.of("id1", Set.of(FonctionnaliteType.SYNTHESE.getLabel())));
            return res;
        });

        // When
        final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);

        // Then
        assertNotNull(encoursTotal);
        assertTrue(encoursTotal.isEncoursNonDisponible());
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_autre_contrat() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        final List<ContratHeader> contrats = contratsMDP(true);
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);

        // When
        final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);

        // Then
        assertNotNull(encoursTotal);
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_encours_en_erreur() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .encoursEnErreur(true)
                .build());

        try {
            // When
            final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);
            fail();
        } catch (ServiceException ignore) {
        }
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_non_trouve() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(null);
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());

        try {
            // When
            final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);
            // Then
            fail();
        } catch (NotFoundException ignore) {

        }
    }

    @Test
    void test_calculerEncoursTotal_clientInternet_contrats_non_trouve() throws Exception {
        // Given
        RequestClientInternetDto clientInternet = RequestClientInternetDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        given(rechercherHabiliFacade.rechercherParIdentiteNumerique(any())).willReturn(personnePhysique());
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(null);

        try {
            // When
            final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientInternet);
            // Then
            fail();
        } catch (NotFoundException ignore) {

        }
    }

    @Test
    void test_calculerEncoursTotal_clientPartenaire() throws Exception {
        // Given
        RequestClientPartenaireDto clientPartenaire = RequestClientPartenaireDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantEpargneRetraite("P0568037")
                .build();

        given(userIdentityProviderFacade.identiteInterneDepuisFederation(any(), any())).willReturn(UserResponseInternal.builder()
                .personnePhysique(personnePhysique())
                .build());
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());

        // When
        final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientPartenaire);

        // Then
        assertNotNull(encoursTotal);
    }

    @Test
    void test_calculerEncoursTotal_clientPartenaire_non_trouve() throws Exception {
        // Given
        RequestClientPartenaireDto clientPartenaire = RequestClientPartenaireDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantEpargneRetraite("P0568037")
                .build();

        given(userIdentityProviderFacade.identiteInterneDepuisFederation(any(), any())).willReturn(null);
        final List<ContratHeader> contrats = contrats();
        given(contratClientFacade.rechercherContratsPersonne(any(PersonnePhysique.class))).willReturn(contrats);
        given(calculerEncoursContratFacade.getEncoursDto(eq(contrat("id1", contrats)))).willReturn(EncoursDto.builder()
                .montantEncours(451575.261)
                .dateEncours("01/04/2022")
                .build());

        try {
            // When
            final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientPartenaire);
            // Then
            fail();
        } catch (NotFoundException ignore) {

        }
    }

    @Test
    void test_calculerEncoursTotal_clientPartenaire_non_trouve_suite() throws Exception {
        // Given
        RequestClientPartenaireDto clientPartenaire = RequestClientPartenaireDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantEpargneRetraite("P0568037")
                .build();

        given(userIdentityProviderFacade.identiteInterneDepuisFederation(any(), any())).willReturn(UserResponseInternal.builder()
                .personnePhysique(new PersonnePhysique())
                .build());

        try {
            // When
            final EncoursTotalDto encoursTotal = contratCalculerEncoursFacade.calculerEncoursTotal(clientPartenaire);
            // Then
            fail();
        } catch (NotFoundException ignore) {

        }
    }

    private List<ContratHeader> contrats() {
        return List.of(
                ContratHeader.builder()
                        .codeSilo(CodeSiloType.ERE)
                        .id("id1")
                        .codeFiliale("codeFiliale")
                        .build()
        );
    }

    private List<ContratHeader> contrats(Map<String, CodeSiloType> model) {
        return model.entrySet().stream()
                .map(e ->
                        ContratHeader.builder()
                                .codeSilo(e.getValue())
                                .id(e.getKey())
                                .codeFiliale("codeFiliale")
                                .build()
                )
                .collect(Collectors.toList());
    }

    private List<ContratHeader> contratsMDP(boolean autreContrat) {
        return List.of(
                ContratHeader.builder()
                        .codeSilo(CodeSiloType.MDP)
                        .id("id2")
                        .codeFiliale("codeFiliale")
                        .classeAutreContrat(true)
                        .build()
        );
    }

    private PersonnePhysique personnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setNumeroPersonneEre("P4508543");
        return pp;
    }

    private ContratHeader contrat(String id, List<ContratHeader> liste) {
        return liste.stream()
                .filter(contratHeader -> contratHeader.getId().equals(id))
                .findFirst()
                .orElseThrow();
    }
}
