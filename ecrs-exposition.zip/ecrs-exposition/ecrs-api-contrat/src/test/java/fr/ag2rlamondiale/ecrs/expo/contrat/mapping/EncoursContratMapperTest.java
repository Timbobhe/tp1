package fr.ag2rlamondiale.ecrs.expo.contrat.mapping;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.domain.EncoursContrat;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursContratDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.FilialeType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class EncoursContratMapperTest {
    private final EncoursContratMapper encoursContratMapper = new EncoursContratMapperImpl();

    @Test
    void test_should_encours_null_for_error() throws Exception {
        // Given
        EncoursDto encours = EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
        // When
        final BigDecimal bigDecimal = encoursContratMapper.convertEncours(encours);

        // Then
        assertNull(bigDecimal);
    }

    @Test
    void test_should_dateEncours_null_for_error() throws Exception {
        // Given
        EncoursDto encours = EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
        // When
        final LocalDate localDate = encoursContratMapper.convertDateEncours(encours);

        // Then
        assertNull(localDate);
    }

    @Test
    void test_should_convert_encours_with_2decimals() throws Exception {
        // Given
        EncoursDto encours = EncoursDto.builder()
                .montantEncours(451575.2321)
                .build();
        // When
        final BigDecimal bigDecimal = encoursContratMapper.convertEncours(encours);

        // Then
        assertEquals("451575.23", bigDecimal.toString());
    }

    @Test
    void test_should_convert_encours_with_2decimals_arrondis() throws Exception {
        // Given
        EncoursDto encours = EncoursDto.builder()
                .montantEncours(451575.261)
                .build();
        // When
        final BigDecimal bigDecimal = encoursContratMapper.convertEncours(encours);

        // Then
        assertEquals("451575.26", bigDecimal.toString());
    }

    @Test
    void test_should_convert_date_encours() throws Exception {
        // Given
        EncoursDto encours = EncoursDto.builder()
                .dateEncours("01/04/2022")
                .build();
        // When
        final LocalDate localDate = encoursContratMapper.convertDateEncours(encours);

        // Then
        assertEquals("2022-04-01", localDate.toString());
    }

    @Test
    void test_should_convert_filiale_ACA_with_one_filiale_ACA() throws Exception {
        // Given
        List<EncoursContrat> contrats = List.of(
                EncoursContrat.builder()
                        .contratHeader(ContratHeader.builder()
                                .codeSilo(CodeSiloType.ERE)
                                .codeFiliale("ACN")
                                .build())
                        .build(),
                EncoursContrat.builder()
                        .contratHeader(ContratHeader.builder()
                                .codeSilo(CodeSiloType.MDP)
                                .codeFiliale("autre")
                                .build())
                        .build()
        );


        // When
        final FilialeType filialeType = encoursContratMapper.mapFiliale(contrats);

        // Then
        assertEquals(FilialeType.ACA, filialeType);
    }

    @Test
    void test_should_convert_filiale_ALM_with_no_filiale_ACA() throws Exception {
        // Given
        List<EncoursContrat> contrats = List.of(
                EncoursContrat.builder()
                        .contratHeader(ContratHeader.builder()
                                .codeSilo(CodeSiloType.ERE)
                                .codeFiliale("autre1")
                                .build())
                        .build(),
                EncoursContrat.builder()
                        .contratHeader(ContratHeader.builder()
                                .codeSilo(CodeSiloType.MDP)
                                .codeFiliale("autre2")
                                .build())
                        .build()
        );


        // When
        final FilialeType filialeType = encoursContratMapper.mapFiliale(contrats);

        // Then
        assertEquals(FilialeType.ALM, filialeType);
    }


    @Test
    void test_should_map_encours_contrat() throws Exception {
        // Given
        final EncoursContrat encoursContrat = EncoursContrat.builder()
                .encours(EncoursDto.builder()
                        .montantEncours(451575.261)
                        .dateEncours("01/04/2022")
                        .build())
                .contratHeader(ContratHeader.builder()
                        .id("IDCONTRAT")
                        .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                        .descriptionFront("DESCRIPTION_FRONT")
                        .codeSilo(CodeSiloType.ERE)
                        .codeFiliale("ACN")
                        .build())
                .build();

        // When
        final EncoursContratDto res = encoursContratMapper.map(encoursContrat);

        // Then
        assertEquals("IDCONTRAT", res.getIdContrat());
        assertEquals("RAISON_SOCIALE_FRONT", res.getRaisonSociale());
        assertEquals("DESCRIPTION_FRONT", res.getLibelleProduit());
        assertEquals("451575.26", res.getEncours().toString());
        assertEquals("2022-04-01", res.getDateEncours().toString());
    }

    @Test
    void test_should_map_list_encours_contrat() throws Exception {
        // Given
        final List<EncoursContrat> list = List.of(
                EncoursContrat.builder()
                        .encours(EncoursDto.builder()
                                .montantEncours(451575.261)
                                .dateEncours("01/04/2022")
                                .build())
                        .contratHeader(ContratHeader.builder()
                                .id("IDCONTRAT")
                                .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                                .descriptionFront("DESCRIPTION_FRONT")
                                .codeSilo(CodeSiloType.ERE)
                                .codeFiliale("ACN")
                                .build())
                        .build(),
                EncoursContrat.builder()
                        .encours(EncoursDto.builder()
                                .montantEncours(23232.05)
                                .dateEncours("31/03/2022")
                                .build())
                        .contratHeader(ContratHeader.builder()
                                .id("IDCONTRAT2")
                                .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                                .descriptionFront("DESCRIPTION_FRONT")
                                .codeSilo(CodeSiloType.MDP)
                                .codeFiliale("autre")
                                .build())
                        .build()
        );

        // When
        final EncoursTotalDto res = encoursContratMapper.map(list);

        // Then
        assertEquals(FilialeType.ACA, res.getCodeFiliale());
        assertEquals(FilialeType.ACA.getLibelle(), res.getLibelleFiliale());
        assertEquals("474807.31", res.getEncoursTotal().toString());
        assertEquals("2022-04-01", res.getDateEncours().toString());
        assertEquals(2, res.getDetailEncours().size());
    }

    @Test
    void test_should_map_list_encours_contrat_avec_autres_contrats() throws Exception {
        // Given
        final List<EncoursContrat> list = List.of(
                EncoursContrat.builder()
                        .encours(EncoursDto.builder()
                                .montantEncours(451575.261)
                                .dateEncours("01/04/2022")
                                .build())
                        .contratHeader(ContratHeader.builder()
                                .id("IDCONTRAT")
                                .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                                .descriptionFront("DESCRIPTION_FRONT")
                                .codeSilo(CodeSiloType.ERE)
                                .codeFiliale("ACN")
                                .build())
                        .build(),
                EncoursContrat.builder()
                        .encours(EncoursDto.builder()
                                .montantEncours(23232.05)
                                .dateEncours("31/03/2022")
                                .build())
                        .contratHeader(ContratHeader.builder()
                                .id("IDCONTRAT2")
                                .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                                .descriptionFront("DESCRIPTION_FRONT")
                                .codeSilo(CodeSiloType.MDP)
                                .codeFiliale("autre")
                                .build())
                        .build(),
                EncoursContrat.builder()
                        .encours(EncoursDto.builder()
                                .montantEncours(null)
                                .build())
                        .contratHeader(ContratHeader.builder()
                                .id("IDCONTRAT3")
                                .raisonSocialeFront("RAISON_SOCIALE_FRONT")
                                .descriptionFront("DESCRIPTION_FRONT")
                                .codeSilo(CodeSiloType.MDP)
                                .codeFiliale("autre")
                                .classeAutreContrat(true)
                                .build())
                        .build()
        );

        // When
        final EncoursTotalDto res = encoursContratMapper.map(list);

        // Then
        assertEquals(FilialeType.ACA, res.getCodeFiliale());
        assertEquals(FilialeType.ACA.getLibelle(), res.getLibelleFiliale());
        assertEquals("474807.31", res.getEncoursTotal().toString());
        assertEquals("2022-04-01", res.getDateEncours().toString());
        assertEquals(3, res.getDetailEncours().size());
    }


}
