package fr.ag2rlamondiale.ecrs.expo.contrat;

import fr.ag2rlamondiale.ecrs.expo.common.api.RestExceptionHandler;
import fr.ag2rlamondiale.ecrs.expo.common.mapping.client.PublicRequestClientMapper;
import fr.ag2rlamondiale.ecrs.expo.common.mapping.client.PublicRequestClientMapperImpl;
import fr.ag2rlamondiale.ecrs.expo.contrat.api.ContratCalculerEncoursRestController;
import fr.ag2rlamondiale.trm.CoreConfig;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBeanPostProcessor;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;


@EnableAspectJAutoProxy
@SpringBootConfiguration
public class ContratTestConfig {
    @Bean
    public PublicRequestClientMapper publicRequestClientMapper() {
        return new PublicRequestClientMapperImpl();
    }

    @Bean
    public SelfReferencingBeanPostProcessor selfReferencingBeanPostProcessor() {
        return new SelfReferencingBeanPostProcessor();
    }

    @Bean
    public RestExceptionHandler restExceptionHandler(){
        return new RestExceptionHandler();
    }

//    @Bean
//    public ContratCalculerEncoursRestController contratCalculerEncoursRestController() {
//        return new ContratCalculerEncoursRestController();
//    }
}
