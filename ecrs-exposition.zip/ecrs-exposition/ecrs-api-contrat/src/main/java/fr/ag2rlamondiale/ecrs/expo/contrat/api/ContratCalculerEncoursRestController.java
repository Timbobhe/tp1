package fr.ag2rlamondiale.ecrs.expo.contrat.api;

import fr.ag2rlamondiale.ecrs.expo.common.ApiConstants;
import fr.ag2rlamondiale.ecrs.expo.common.api.dto.RequestClientDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.InternalRequestClientDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.error.ApiAcquittalError;
import fr.ag2rlamondiale.ecrs.expo.common.exception.BadRequestException;
import fr.ag2rlamondiale.ecrs.expo.common.mapping.client.PublicRequestClientMapper;
import fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.ValidationInternalRequestClient;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.IContratCalculerEncoursFacade;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursContratDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.FilialeType;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import io.swagger.annotations.*;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/v1/contrats")
@Api(value = "/v1/contrats", produces = MediaType.APPLICATION_JSON_VALUE, tags = {
        "Exposition du calcul de l'encours pour les contrats de Retraite Suppl\u00E9mentaire du client"})
public class ContratCalculerEncoursRestController {

    @Autowired
    private IContratCalculerEncoursFacade contratCalculerEncoursFacade;

    @Autowired
    private PublicRequestClientMapper requestClientMapper;

    @LogExecutionTime
    @SneakyThrows
    @GetMapping(value = {"/calculer_encours"}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @ApiOperation(value = "Calcul de l'encours pour l'ensemble des contrats de Retraite Supplémentaire du client", produces = MediaType.APPLICATION_JSON_VALUE, response = EncoursTotalDto.class)
    @ApiResponses(value = {
            @ApiResponse(code = 400, message = "Mauvaise requête", response = ApiAcquittalError.class),
            @ApiResponse(code = 204, message = "Non trouvé", response = ApiAcquittalError.class),
            @ApiResponse(code = 500, message = "Erreur interne serveur", response = ApiAcquittalError.class),
            @ApiResponse(code = 502, message = "Erreur reçue depuis un service distant", response = ApiAcquittalError.class)
    })
    public EncoursTotalDto calculerEncoursTotal(
            @ModelAttribute RequestClientDto requestClient,

            @ApiParam(value = "Represente le code application du partenaire", example = "A1587 pour NIE; A1520 pour ADDING")
            @RequestHeader(name = ApiConstants.HEADER_XCALLER, required = false) String codeApplicationPartenaire,

            @ApiParam(value = "_[Bouchon]_ Indique que l'on appelle le service en mode fictif (bouchonné)")
            @RequestParam(name = "exemple", required = false) boolean exemple) {
        log.info("Appel de l'API getEncoursTotal avec {}, {}: {}, exemple: {}",
                requestClient, ApiConstants.HEADER_XCALLER, codeApplicationPartenaire, exemple);
        if (exemple) {
            return exemple();
        }

        final InternalRequestClientDto internalRequestClient = requestClientMapper.map(requestClient, codeApplicationPartenaire);
        ValidationInternalRequestClient.check(internalRequestClient);

        return calculerEncoursTotal(internalRequestClient);
    }


    @SneakyThrows
    protected EncoursTotalDto calculerEncoursTotal(InternalRequestClientDto internalRequestClient) {
        final RequestClientInternetDto requestClientInternet = internalRequestClient.toRequestClientInternetDto();
        if (requestClientInternet != null) {
            return contratCalculerEncoursFacade.calculerEncoursTotal(requestClientInternet);
        }

        final RequestClientPartenaireDto clientPartenaire = internalRequestClient.toRequestClientPartenaireDto();
        if (clientPartenaire != null) {
            return contratCalculerEncoursFacade.calculerEncoursTotal(clientPartenaire);
        }

        throw new BadRequestException("Fournir une requete pour les clients internet/partenaire");
    }

    public static EncoursTotalDto exemple() {
        return EncoursTotalDto.builder()
                .codeFiliale(FilialeType.ACA)
                .libelleFiliale("Arial CNP Assurances")
                .dateEncours(LocalDate.now())
                .encoursTotal(new BigDecimal("26979.85"))
                .detailEncours(List.of(
                        EncoursContratDto.builder()
                                .idContrat("RG151236289")
                                .raisonSociale("COMPAGNIE IBM FRANCE")
                                .libelleProduit("Plan d'\u00C9pargne Retraite Entreprises")
                                .dateEncours(LocalDate.now())
                                .encours(new BigDecimal("26979.85"))
                                .build(),
                        EncoursContratDto.builder()
                                .idContrat("RG152289321")
                                .raisonSociale("COMPAGNIE IBM FRANCE")
                                .libelleProduit("PLAN D'EPARGNE RETRAITE OBLIGATOIRE")
                                .dateEncours(LocalDate.now())
                                .encours(new BigDecimal("0.00"))
                                .build()
                ))
                .build();
    }

}
