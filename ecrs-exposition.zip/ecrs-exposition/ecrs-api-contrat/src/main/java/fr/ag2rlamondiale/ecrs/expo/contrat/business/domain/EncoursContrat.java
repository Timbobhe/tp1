package fr.ag2rlamondiale.ecrs.expo.contrat.business.domain;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class EncoursContrat {
    private ContratHeader contratHeader;
    private EncoursDto encours;
    private boolean contratBloque;
}
