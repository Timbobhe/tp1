package fr.ag2rlamondiale.ecrs.expo.contrat.mapping;

import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.security.RolesEnum;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static fr.ag2rlamondiale.ecrs.rfi.business.impl.UserIdentityProviderFacadeImpl.ID_EPARGNE_RETRAITE;
import static fr.ag2rlamondiale.ecrs.rfi.business.impl.UserIdentityProviderFacadeImpl.REF_EXTERNE;

@Mapper(componentModel = "spring", uses = DateMapper.class, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class RequestClientMapper {

    @Mapping(target = "identifiantFournisseurIdentiteNumerique", source = "idFournisseurIdentite")
    @Mapping(target = "login", source = "loginFournisseurIdentite")
    public abstract IdentiteNumeriqueHabilitation map(RequestClientInternetDto clientInternet);


    @Mapping(target = "attributes.fdiPerimeterName", source = "codeApplicationPartenaire", qualifiedByName = "fdiPerimeterName")
    @Mapping(target = "attributes.businessIdMap", source = ".", qualifiedByName = "convertToBusinessIdMap")
    @Mapping(target = "attributes.roles", expression = "java(rolesFederation())")
    public abstract UserRequestDto map(RequestClientPartenaireDto requestPartenaire);

    @Named("convertToBusinessIdMap")
    public List<String> convertToBusinessIdMap(RequestClientPartenaireDto requestPartenaire) {
        List<String> businessIdMap = new ArrayList<>();
        if (requestPartenaire.getReferenceExterne() != null) {
            businessIdMap.add(REF_EXTERNE + "=" + requestPartenaire.getReferenceExterne());
        }

        if (requestPartenaire.getIdentifiantEpargneRetraite() != null) {
            businessIdMap.add(ID_EPARGNE_RETRAITE + "=" + requestPartenaire.getIdentifiantEpargneRetraite());
        }

        return wrapToList("{" + String.join(",", businessIdMap) + "}");
    }

    @Named("wrapToList")
    protected <T> List<T> wrapToList(T e) {
        return WrapListUtils.wrapToList(e);
    }

    @Named("rolesFederation")
    protected Set<String> rolesFederation() {
        return Set.of(RolesEnum.FEDERATION.getSuffixe());
    }

    @Named("fdiPerimeterName")
    protected List<String> fdiPerimeterName(String codeApplicationPartenaire) {
        String fdiPerimeterName = null;
        switch (codeApplicationPartenaire) {
            case "A1587":
                fdiPerimeterName = Partenaire.CODE_NIE;
                break;
            case "A1520":
                fdiPerimeterName = Partenaire.CODE_ADDING;
                break;
        }

        return wrapToList(fdiPerimeterName);
    }

}
