package fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EncoursContratDto {
    @ApiModelProperty(position = 1, required = true, value = "Nom du contrat", example = "RG151236289")
    private String idContrat;

    @ApiModelProperty(position = 2, required = true, value = "Raison sociale adh\u00E9rente du contrat", example = "COMPAGNIE IBM FRANCE")
    private String raisonSociale;

    @ApiModelProperty(position = 3, required = true, value = "Libell\u00E9 du produit du contrat", example = "Plan d'\u00C9pargne Retraite Entreprises")
    private String libelleProduit;

    @ApiModelProperty(position = 4, required = true, value = "Indique si l'encours est non disponible")
    private boolean encoursNonDisponible;

    @ApiModelProperty(position = 5, value = "Date pour laquelle on retourne la valeur de l'encours du contrat", example = "2022-03-23", dataType = "date")
    private LocalDate dateEncours;

    @ApiModelProperty(position = 6, value = "Valeur de l'encours total en EURO", example = "26979.85", dataType = "d\u00E9cimal (18,2)")
    private BigDecimal encours;
}
