package fr.ag2rlamondiale.ecrs.expo.contrat.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;

public interface IContratCalculerEncoursFacade {

    EncoursTotalDto calculerEncoursTotal(RequestClientInternetDto clientInternet) throws TechnicalException;

    EncoursTotalDto calculerEncoursTotal(RequestClientPartenaireDto clientPartenaire) throws TechnicalException;

}
