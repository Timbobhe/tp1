package fr.ag2rlamondiale.ecrs.expo.contrat.mapping;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.domain.EncoursContrat;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursContratDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.FilialeType;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

@Mapper(componentModel = "spring", uses = DateMapper.class, builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class EncoursContratMapper {

    @Mapping(target = "idContrat", source = "contratHeader.nomContrat")
    @Mapping(target = "libelleProduit", source = "contratHeader.descriptionFront")
    @Mapping(target = "raisonSociale", source = "contratHeader.raisonSocialeFront")
    @Mapping(target = "encours", source = "encours", qualifiedByName = "convertEncours")
    @Mapping(target = "dateEncours", source = "encours", qualifiedByName = "convertDateEncours")
    @Mapping(target = "encoursNonDisponible", source = "contratBloque")
    public abstract EncoursContratDto map(EncoursContrat encoursContrat);

    public abstract List<EncoursContratDto> mapList(List<EncoursContrat> encoursContrats);

    public EncoursTotalDto map(List<EncoursContrat> encoursContrats) {
        EncoursTotalDto encoursTotal = new EncoursTotalDto();
        final FilialeType filialeType = mapFiliale(encoursContrats);
        encoursTotal.setCodeFiliale(filialeType);
        encoursTotal.setLibelleFiliale(filialeType.getLibelle());

        final List<EncoursContratDto> details = mapList(encoursContrats);
        encoursTotal.setDetailEncours(details);

        final boolean nonDisponible = details.stream().anyMatch(EncoursContratDto::isEncoursNonDisponible);
        if (nonDisponible) {
            encoursTotal.setEncoursNonDisponible(true);
            return encoursTotal;
        }

        final BigDecimal total = details.stream()
                .map(EncoursContratDto::getEncours)
                .filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(2, RoundingMode.HALF_DOWN);
        encoursTotal.setEncoursTotal(total);


        details.stream()
                .map(EncoursContratDto::getDateEncours)
                .filter(Objects::nonNull)
                .max(LocalDate::compareTo)
                .ifPresent(encoursTotal::setDateEncours);

        return encoursTotal;
    }


    @Named("convertEncours")
    public BigDecimal convertEncours(EncoursDto encours) {
        if (encours == null || encours.isEncoursEnErreur() || encours.getMontantEncours() == null) {
            return null;
        }
        return BigDecimal.valueOf(encours.getMontantEncours()).setScale(2, RoundingMode.HALF_DOWN);
    }

    @Named("convertDateEncours")
    public LocalDate convertDateEncours(EncoursDto encours) {
        if (encours == null || encours.isEncoursEnErreur() || encours.getDateEncours() == null) {
            return null;
        }
        return LocalDate.parse(encours.getDateEncours(), DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.FRANCE));
    }

    public FilialeType mapFiliale(List<EncoursContrat> encoursContrats) {
        final boolean aca = encoursContrats.stream()
                .map(EncoursContrat::getContratHeader)
                .anyMatch(ContratHeader::isFilialeACA);
        return aca ? FilialeType.ACA : FilialeType.ALM;
    }
}
