package fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours;

import lombok.Getter;

@Getter
public enum FilialeType {
    ACA("ARIAL CNP Assurance"),
    ALM("AG2R LA MONDIALE");

    private final String libelle;

    FilialeType(String libelle) {
        this.libelle = libelle;
    }
}
