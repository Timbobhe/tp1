package fr.ag2rlamondiale.ecrs.expo.contrat.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IContratClientFacade;
import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.expo.common.business.IUserContextBuilder;
import fr.ag2rlamondiale.ecrs.expo.common.domain.WithUserContext;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientInternetDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.ecrs.expo.common.exception.NotFoundException;
import fr.ag2rlamondiale.ecrs.expo.common.exception.ServiceException;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.IContratCalculerEncoursFacade;
import fr.ag2rlamondiale.ecrs.expo.contrat.business.domain.EncoursContrat;
import fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours.EncoursTotalDto;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.EncoursContratMapper;
import fr.ag2rlamondiale.ecrs.expo.contrat.mapping.RequestClientMapper;
import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.trm.domain.FonctionnaliteType;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.security.UserContext;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ContratCalculerEncoursFacadeImpl implements IContratCalculerEncoursFacade {

    @Autowired
    private IRechercherHabiliFacade rechercherHabiliFacade;

    @Autowired
    private IContratClientFacade contratClientFacade;

    @Autowired
    private ICalculerEncoursContratFacade calculerEncoursContratFacade;

    @Autowired
    private EncoursContratMapper encoursContratMapper;

    @Autowired
    private IUserIdentityProviderFacade userIdentityProviderFacade;

    @Autowired
    private RequestClientMapper requestClientMapper;

    @Autowired
    private IUserContextBuilder userContextBuilder;


    @Override
    @NoAuthRequired
    public EncoursTotalDto calculerEncoursTotal(RequestClientInternetDto clientInternet) throws TechnicalException {
        final PersonnePhysique pp = rechercherHabiliFacade.rechercherParIdentiteNumerique(requestClientMapper.map(clientInternet));

        if (pp == null || pp.getNumeroPersonneEre() == null && pp.getNumeroPersonneMdpro() == null) {
            log.warn("Pas de client trouvé depuis {}", clientInternet);
            throw new NotFoundException("Client non trouvé");
        }

        final WithUserContext withUserContext = userContextBuilder.prepareUserContext(pp, clientInternet.getCodeApplicationPartenaire());

        return withUserContext.execute(c -> {
            final List<ContratHeader> contratHeaders = getContratsPersonne(pp);
            c.initBlocagesClient(contratHeaders);
            return calculerEncoursTotal(contratHeaders, c.getUserContext());
        });
    }

    private List<ContratHeader> getContratsPersonne(PersonnePhysique pp) throws ServiceException {
        final List<ContratHeader> contratHeaders;
        try {
            contratHeaders = contratClientFacade.rechercherContratsPersonne(pp);
        } catch (TechnicalException e) {
            throw new ServiceException(e);
        }
        if (contratHeaders == null || contratHeaders.isEmpty()) {
            log.warn("Pas de contrat trouvé pour le client {}", pp);
            throw new NotFoundException("Contrat non trouvé");
        }
        return contratHeaders;
    }

    @Override
    @NoAuthRequired
    public EncoursTotalDto calculerEncoursTotal(RequestClientPartenaireDto clientPartenaire) throws TechnicalException {
        UserRequestDto userRequest = requestClientMapper.map(clientPartenaire);
        final UserResponseInternal userResponseInternal = userIdentityProviderFacade.identiteInterneDepuisFederation(userRequest, UserRequestOptionsDto.builder()
                .createHabili(false)
                .build());

        if (userResponseInternal == null || Boolean.FALSE.equals(userResponseInternal.getIsAuthorized()) || userResponseInternal.getPersonnePhysique() == null) {
            log.warn("Pas de client trouvé depuis {}", clientPartenaire);
            throw new NotFoundException("Client non trouvé");
        }

        final PersonnePhysique pp = userResponseInternal.getPersonnePhysique();
        if (pp == null || pp.getNumeroPersonneEre() == null && pp.getNumeroPersonneMdpro() == null) {
            log.warn("Pas de client trouvé depuis {}", clientPartenaire);
            throw new NotFoundException("Client non trouvé");
        }

        final WithUserContext withUserContext = userContextBuilder.prepareUserContextPartenaire(pp, clientPartenaire);
        return withUserContext.execute(c -> {
            final List<ContratHeader> contratHeaders = getContratsPersonne(pp);
            c.initBlocagesClient(contratHeaders);
            return calculerEncoursTotal(contratHeaders, c.getUserContext());
        });
    }

    @SneakyThrows
    private EncoursTotalDto calculerEncoursTotal(List<ContratHeader> contratHeaders, UserContext userContext) {
        final InfosBlocagesClient infosBlocagesClient = userContext.getInfosBlocagesClient();

        final List<EncoursContrat> encoursContrats = contratHeaders.stream()
                .parallel()
                .map(c -> EncoursContrat.builder()
                        .contratHeader(c)
                        .contratBloque(testContratBloque(infosBlocagesClient, c))
                        .build())
                .map(encoursContrat -> {
                    EncoursDto encours = encoursNull();
                    if (!encoursContrat.isContratBloque()) {
                        encours = getEncours(encoursContrat.getContratHeader());
                    }
                    return encoursContrat.toBuilder()
                            .encours(encours)
                            .build();
                })
                .collect(Collectors.toList());

        // Vérification des erreurs
        encoursContrats.stream()
                .filter(e -> e.getEncours() != null && e.getEncours().isEncoursEnErreur())
                .findFirst()
                .ifPresent(encoursContrat -> {
                    log.warn("Encours en erreur pour le contrat {}", encoursContrat.getContratHeader());
                    throw new ServiceException("Encours en erreur pour le contrat " + encoursContrat.getContratHeader().getId());
                });

        return encoursContratMapper.map(encoursContrats);
    }

    private EncoursDto getEncours(ContratHeader c) {
        if (c.isClasseAutreContrat()) {
            return encoursNull();
        }
        return calculerEncoursContratFacade.getEncoursDto(c);
    }

    private EncoursDto encoursNull() {
        return EncoursDto.builder()
                .montantEncours(null)
                .build();
    }

    private boolean testContratBloque(InfosBlocagesClient infosBlocagesClient, ContratHeader contratHeader) {
        return infosBlocagesClient.isFonctionnaliteBloqueePourContrat(contratHeader.getId(), FonctionnaliteType.SYNTHESE);
    }
}
