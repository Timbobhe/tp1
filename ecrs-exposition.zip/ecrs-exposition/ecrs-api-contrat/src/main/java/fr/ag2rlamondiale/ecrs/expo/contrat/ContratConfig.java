package fr.ag2rlamondiale.ecrs.expo.contrat;

import fr.ag2rlamondiale.ecrs.EcrsLibContratConfig;
import fr.ag2rlamondiale.ecrs.expo.common.CommonConfig;
import fr.ag2rlamondiale.ecrs.rfi.EcrsLibRfiConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@ComponentScan
@Import({CommonConfig.class, EcrsLibContratConfig.class, EcrsLibRfiConfig.class})
public class ContratConfig {
}
