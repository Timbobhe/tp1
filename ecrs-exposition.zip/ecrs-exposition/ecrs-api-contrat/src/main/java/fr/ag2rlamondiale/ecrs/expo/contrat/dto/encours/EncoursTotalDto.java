package fr.ag2rlamondiale.ecrs.expo.contrat.dto.encours;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EncoursTotalDto {
    @ApiModelProperty(position = 1, required = true, value = "Code de la filiale du client; ACA s'il possède au moins un contrat ACA, sinon ALM")
    private FilialeType codeFiliale;

    @ApiModelProperty(position = 2, required = true, value = "Libell\u00E9 de la filiale du client", example = "Arial CNP Assurances")
    private String libelleFiliale;

    @ApiModelProperty(position = 3, required = true, value = "Indique si l'encours est non disponible")
    private boolean encoursNonDisponible;

    @ApiModelProperty(position = 4, required = true, value = "Date pour laquelle on retourne la valeur de l'encours total", example = "2022-03-23", dataType = "date")
    private LocalDate dateEncours;

    @ApiModelProperty(position = 5, required = true, value = "Valeur de l'encours total en EURO", example = "26979.85", dataType = "d\u00E9cimal (18,2)")
    private BigDecimal encoursTotal;

    @ApiModelProperty(position = 6, required = true, value = "D\u00E9tail de l'encours pour chaque contrat du client")
    private List<EncoursContratDto> detailEncours;
}
