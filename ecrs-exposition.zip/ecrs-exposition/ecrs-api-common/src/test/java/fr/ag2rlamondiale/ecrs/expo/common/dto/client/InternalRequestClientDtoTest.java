package fr.ag2rlamondiale.ecrs.expo.common.dto.client;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class InternalRequestClientDtoTest {

    @Test
    void test_toRequestClientPartenaireDto() throws Exception {
        // Given
        InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .codeApplicationPartenaire("49505")
                .identifiantExterneClient("refExterne")
                .identifiantEpargneRetraite("idEpargneRetraite")
                .build();

        // When
        final RequestClientPartenaireDto clientPartenaire = requestClient.toRequestClientPartenaireDto();

        // Then
        assertEquals("49505", clientPartenaire.getCodeApplicationPartenaire());
        assertEquals("refExterne", clientPartenaire.getReferenceExterne());
        assertEquals("idEpargneRetraite", clientPartenaire.getIdentifiantEpargneRetraite());
    }

    @Test
    void test_toRequestClientInternetDto() throws Exception {
        // Given
        InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .idFournisseurIdentite("idFournisseur")
                .loginFournisseurIdentite("login")
                .build();

        // When
        final RequestClientInternetDto clientInternet = requestClient.toRequestClientInternetDto();

        // Then
        assertEquals("idFournisseur", clientInternet.getIdFournisseurIdentite());
        assertEquals("login", clientInternet.getLoginFournisseurIdentite());
    }


    @Test
    void test_to_null() throws Exception {
        // Given
        InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .build();

        // When
        final RequestClientInternetDto clientInternet = requestClient.toRequestClientInternetDto();
        final RequestClientPartenaireDto clientPartenaire = requestClient.toRequestClientPartenaireDto();

        // Then
        assertNull(clientInternet);
        assertNull(clientPartenaire);
    }
}
