package fr.ag2rlamondiale.ecrs.expo.common;

import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;


@EnableAspectJAutoProxy
@SpringBootConfiguration
public class CommonTestConfig {
}
