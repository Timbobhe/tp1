package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.client;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({TYPE})
@Retention(RUNTIME)
@Constraint(validatedBy = RequestClientValidator.class)
@Documented
public @interface RequestClientConstraints {

    String message() default "{RequestClient.invalid}";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
