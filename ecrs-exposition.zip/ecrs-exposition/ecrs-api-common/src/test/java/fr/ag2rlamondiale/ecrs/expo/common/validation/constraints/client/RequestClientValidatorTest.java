package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.client;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
class RequestClientValidatorTest {

    Validator validator;

    @BeforeEach
    public void init() {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    @Test
    void test_should_valid_failed_when_idFournisseurIdentite_and_codePartenaire_empty() {
        // Given
        var req = new RequestClientDto();

        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertFalse(constraintViolations.isEmpty());
        final String expectedMessage = "Au moins un des champs suivants doit être renseigné: [idFournisseurIdentite, codePartenaire]";
        final Optional<String> errorMessage = constraintViolations.stream()
                .map(ConstraintViolation::getMessage)
                .filter(m -> m.equals(expectedMessage))
                .findFirst();
        assertTrue(errorMessage.isPresent());
        log.info("Impossible de valider les donnees du bean : ");
        for (ConstraintViolation<RequestClientDto> contraintes : constraintViolations) {
            log.info(contraintes.getRootBeanClass().getSimpleName() +
                    "." + contraintes.getPropertyPath() + " " + contraintes.getMessage());
        }
    }

    @Test
    void test_should_valid_failed_when_idFournisseurIdentite_filled_but_login_empty() {
        // Given
        var req = RequestClientDto.builder()
                .idFournisseurIdentite("1")
                .build();


        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertFalse(constraintViolations.isEmpty());
        final String expectedMessage = "loginFournisseurIdentite ne doit pas être vide";
        final Optional<String> errorMessage = constraintViolations.stream()
                .map(ConstraintViolation::getMessage)
                .filter(m -> m.equals(expectedMessage))
                .findFirst();
        assertTrue(errorMessage.isPresent());
        log.info("Impossible de valider les donnees du bean : ");
        for (ConstraintViolation<RequestClientDto> contraintes : constraintViolations) {
            log.info(contraintes.getRootBeanClass().getSimpleName() +
                    "." + contraintes.getPropertyPath() + " " + contraintes.getMessage());
        }
    }

    @Test
    void test_should_valid_success_when_idFournisseurIdentite_and_login_not_empty() {
        // Given
        var req = RequestClientDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("1mgu13")
                .build();

        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertTrue(constraintViolations.isEmpty());
    }

    @Test
    void test_should_valid_failed_when_codePartenaire_filled_but_refExterne_or_idEpargneRetraite_empty() {
        // Given
        var req = RequestClientDto.builder()
                .codePartenaire("49505")
                .build();


        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertFalse(constraintViolations.isEmpty());
        final String expectedMessage = "Au moins un des champs suivants doit être renseigné: [identifiantEpargneRetraite, identifiantExterneClient]";
        final Optional<String> errorMessage = constraintViolations.stream()
                .map(ConstraintViolation::getMessage)
                .filter(m -> m.equals(expectedMessage))
                .findFirst();
        assertTrue(errorMessage.isPresent());
        log.info("Impossible de valider les donnees du bean : ");
        for (ConstraintViolation<RequestClientDto> contraintes : constraintViolations) {
            log.info(contraintes.getRootBeanClass().getSimpleName() +
                    "." + contraintes.getPropertyPath() + " " + contraintes.getMessage());
        }
    }

    @Test
    void test_should_valid_success_when_codePartenaire_filled_and_idEpargneRetraite_not_empty() {
        // Given
        var req = RequestClientDto.builder()
                .codePartenaire("49505")
                .identifiantEpargneRetraite("P4167507")
                .build();

        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertTrue(constraintViolations.isEmpty());
    }

    @Test
    void test_should_valid_success_when_codePartenaire_filled_and_refExterne_not_empty() {
        // Given
        var req = RequestClientDto.builder()
                .codePartenaire("49505")
                .identifiantExterneClient("006040962735940901")
                .build();

        // When
        final Set<ConstraintViolation<RequestClientDto>> constraintViolations = validator.validate(req);

        // Then
        assertTrue(constraintViolations.isEmpty());
    }
}
