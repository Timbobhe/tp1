package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.client;

import fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.OneOf;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@RequestClientConstraints
@ApiModel(description = "Représente la requête permettant de cibler un client : Données d'appel en entrée")
@OneOf(groups = RequestClientGroups.Client.class, value = {"idFournisseurIdentite", "codePartenaire"})
@OneOf(groups = RequestClientGroups.Partenaire.class, value = {"identifiantEpargneRetraite", "identifiantExterneClient"})
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
class RequestClientDto {
    @ApiModelProperty(position = 1, value = "**[Internet-1]** Identifiant du fournisseur d'identit\u00E9, issue du Service Habilitation; \"1\" pour GDI", example = "1")
    @NotBlank(groups = RequestClientGroups.Internet.class)
    private String idFournisseurIdentite;

    @ApiModelProperty(position = 2, value = "**[Internet-2]** Login du client selon le fournisseur d'identit\u00E9", example = "1mgu13")
    @NotBlank(groups = RequestClientGroups.Internet.class, message = "loginFournisseurIdentite ne doit pas \u00EAtre vide")
    private String loginFournisseurIdentite;

    @ApiModelProperty(position = 10, value = "`[Partenaire-1]` Code repr\u00E9sentant le partenaire appelant; \"49505\" pour NIE", example = "49505")
    @NotBlank(groups = RequestClientGroups.Partenaire.class)
    private String codePartenaire;

    @ApiModelProperty(position = 11, value = "`[Partenaire-2]` Num\u00E9ro de personne dans ERE, correspondant \u00E0 un identifiant client", example = "P4167507")
    private String identifiantEpargneRetraite;

    @ApiModelProperty(position = 12, value = "`[Partenaire-3]` Identifiant technique du client g\u00E9r\u00E9 par le partenaire (aussi connu sous le nom de refExterne)", example = "006040962735940901")
    private String identifiantExterneClient;

}
