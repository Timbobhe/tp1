package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.client;

public interface RequestClientGroups {
    interface Client {}
    interface Partenaire {}
    interface Internet {}
}
