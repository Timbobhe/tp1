package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints;

import fr.ag2rlamondiale.ecrs.expo.common.dto.client.InternalRequestClientDto;
import fr.ag2rlamondiale.ecrs.expo.common.exception.BadRequestException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ValidationInternalRequestClientTest {

    @Test
    void test_request_inconnue() throws Exception {
        // Given
        InternalRequestClientDto requestClient = new InternalRequestClientDto();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            fail();
        } catch (BadRequestException ignore) {
            // Then

        }

    }

    @Test
    void test_request_interne_ko() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .idFournisseurIdentite("1")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            fail();
        } catch (BadRequestException ignore) {
            // Then
        }
    }

    @Test
    void test_request_interne_ok() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .idFournisseurIdentite("1")
                .loginFournisseurIdentite("login")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            // Then
        } catch (BadRequestException ignore) {
            fail();
        }
    }

    @Test
    void test_request_interne_avec_partenaire_ko() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .identifiantExterneClient("1")
                .loginFournisseurIdentite("login")
                .connexionPartenaire(true)
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            fail();
        } catch (BadRequestException ignore) {
            // Then
        }
    }

    @Test
    void test_request_interne_avec_partenaire_ok() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .identifiantExterneClient("1")
                .loginFournisseurIdentite("login")
                .connexionPartenaire(true)
                .codeApplicationPartenaire("A1587")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            // Then
        } catch (BadRequestException ignore) {
            fail();
        }
    }

    @Test
    void test_request_partenaire_ok() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantExterneClient("idExterne")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            // Then
        } catch (BadRequestException ignore) {
            fail();
        }
    }

    @Test
    void test_request_partenaire_ko() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .codeApplicationPartenaire("A1587")
                .identifiantExterneClient("idExterne")
                .identifiantEpargneRetraite("idEpargneRetraite")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            fail();
        } catch (BadRequestException ignore) {
            // Then
        }
    }

    @Test
    void test_request_partenaire_ko_2() throws Exception {
        // Given
        final InternalRequestClientDto requestClient = InternalRequestClientDto.builder()
                .codeApplicationPartenaire("A1587")
                .build();

        // When
        try {
            ValidationInternalRequestClient.check(requestClient);
            fail();
        } catch (BadRequestException ignore) {
            // Then
        }
    }
}
