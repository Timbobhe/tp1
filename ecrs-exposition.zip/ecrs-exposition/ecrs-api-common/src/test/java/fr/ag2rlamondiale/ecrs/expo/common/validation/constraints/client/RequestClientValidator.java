package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.client;

import javax.validation.*;
import java.util.Set;

public class RequestClientValidator implements ConstraintValidator<RequestClientConstraints, RequestClientDto> {
    @Override
    public boolean isValid(RequestClientDto value, ConstraintValidatorContext context) {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();

        final Set<ConstraintViolation<RequestClientDto>> violationsClient = validator.validate(value, RequestClientGroups.Client.class);

        if (violationsClient.isEmpty()) {
            if (value.getIdFournisseurIdentite() != null) {
                final Set<ConstraintViolation<RequestClientDto>> violationsInternet = validator.validate(value, RequestClientGroups.Internet.class);
                appendConstraintViolations(violationsInternet, context);
                return violationsInternet.isEmpty();
            }

            final Set<ConstraintViolation<RequestClientDto>> violationsPartenaire = validator.validate(value, RequestClientGroups.Partenaire.class);
            appendConstraintViolations(violationsPartenaire, context);
            return violationsPartenaire.isEmpty();
        }

        appendConstraintViolations(violationsClient, context);
        return false;
    }

    private void appendConstraintViolations(Set<ConstraintViolation<RequestClientDto>> violations, ConstraintValidatorContext context) {
        context.disableDefaultConstraintViolation();
        violations.forEach(v -> {
            final ConstraintValidatorContext.ConstraintViolationBuilder builder = context.buildConstraintViolationWithTemplate(v.getMessage());
            builder.addConstraintViolation();
        });
    }

}
