package fr.ag2rlamondiale.ecrs.expo.common.business;

import fr.ag2rlamondiale.ecrs.expo.common.domain.WithUserContext;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;

public interface IUserContextBuilder {

    WithUserContext prepareUserContext(PersonnePhysique personnePhysique, String codeApplicationPartenaire);

    /**
     * Permet de gérer le XCALLER pour les Partenaires
     *
     * @param personnePhysique
     * @param clientPartenaire
     * @return
     */
    WithUserContext prepareUserContextPartenaire(PersonnePhysique personnePhysique, RequestClientPartenaireDto clientPartenaire);

}
