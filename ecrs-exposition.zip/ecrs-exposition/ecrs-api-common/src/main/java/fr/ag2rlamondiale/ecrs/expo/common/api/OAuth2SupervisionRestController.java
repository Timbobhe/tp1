package fr.ag2rlamondiale.ecrs.expo.common.api;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/oauth2-supervision")
public class OAuth2SupervisionRestController {


    @GetMapping("/jwt")
    public Object user(JwtAuthenticationToken jwtToken) {

        // On peut également retrouver le jeton sécurisé via l'API standard Spring
        // Security
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        log.info("spring Security Authentication [{}]", auth);


        var infos = new HashMap<>();
        infos.put("name", jwtToken.getName());
        infos.put("tokenAttributes", jwtToken.getTokenAttributes());
        infos.put("grantedAuthorities", jwtToken.getAuthorities());
        infos.put("accessToken", jwtToken.getToken().getTokenValue());
        return infos;
    }

    @GetMapping("/secure-by-utf0-role")
    @Secured("ROLE_UTF0")
    public String secureByUtf0Role() {
        return "secure by UTF0 role";
    }

    @GetMapping("/secure-by-unknown-role")
    @Secured("ROLE_xxx")
    public String secureByUnknownRole() {
        return "secure by unknown role";
    }


}
