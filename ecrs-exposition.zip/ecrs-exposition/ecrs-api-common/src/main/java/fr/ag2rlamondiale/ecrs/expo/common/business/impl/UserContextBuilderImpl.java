package fr.ag2rlamondiale.ecrs.expo.common.business.impl;

import fr.ag2rlamondiale.ecrs.expo.common.business.IUserContextBuilder;
import fr.ag2rlamondiale.ecrs.expo.common.domain.WithUserContext;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.RequestClientPartenaireDto;
import fr.ag2rlamondiale.trm.business.ISimpleBlocageFacade;
import fr.ag2rlamondiale.trm.client.rest.IPartenaireRestClient;
import fr.ag2rlamondiale.trm.domain.mapping.PartenaireMapper;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.partenaire.PartenaireJson;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class UserContextBuilderImpl implements IUserContextBuilder {

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IPartenaireRestClient partenaireRestClient;

    @Autowired
    private PartenaireMapper partenaireMapper;

    @Autowired
    private ISimpleBlocageFacade simpleBlocageFacade;

    @Override
    public WithUserContext prepareUserContext(PersonnePhysique personnePhysique, String codeApplicationPartenaire) {
        String idGdi = personnePhysique.getIdGdi();
        final UserContext userContext = new UserContext();
        userContext.setIdGdi(idGdi);
        userContext.setNom(personnePhysique.getNom());
        userContext.setPrenom(personnePhysique.getPrenom());
        userContext.setCivilite(personnePhysique.getCivilite());
        userContext.setIdExtranet(personnePhysique.getIdExtranet());
        String numPpEre = personnePhysique.getNumeroPersonneEre();
        String numPpMdpro = personnePhysique.getNumeroPersonneMdpro();
        userContext.setNumeroPersonneEre(numPpEre);
        userContext.setNumeroPersonneMdpro(numPpMdpro);

        if (codeApplicationPartenaire != null) {
            userContext.setXCaller(codeApplicationPartenaire);

            final String fdiPerimeterName = fdiPerimeterName(codeApplicationPartenaire);
            if (fdiPerimeterName != null) {
                final PartenaireJson partenaireJson = partenaireRestClient.findById(fdiPerimeterName);
                final Partenaire partenaire = partenaireMapper.map(partenaireJson);
                userContext.setPartenaire(partenaire);
            }
        }

        return new WithUserContext(userContext, userContextHolder, simpleBlocageFacade);
    }

    @Override
    public WithUserContext prepareUserContextPartenaire(PersonnePhysique personnePhysique, RequestClientPartenaireDto clientPartenaire) {
        return prepareUserContext(personnePhysique, clientPartenaire.getCodeApplicationPartenaire());
    }


    protected String fdiPerimeterName(String codeApplicationPartenaire) {
        switch (codeApplicationPartenaire) {
            case "A1587":
                return Partenaire.CODE_NIE;
            case "A1520":
                return Partenaire.CODE_ADDING;
        }

        return null;
    }

}
