package fr.ag2rlamondiale.ecrs.expo.common;

public class ApiConstants {
    public static final String HEADER_XCALLER = "x-caller";

    private ApiConstants() {
        // constants
    }
}
