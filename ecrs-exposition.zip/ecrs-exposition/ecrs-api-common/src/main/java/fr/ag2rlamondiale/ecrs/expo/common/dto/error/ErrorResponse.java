package fr.ag2rlamondiale.ecrs.expo.common.dto.error;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.ecrs.expo.common.exception.IGenericException;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Objet Response Error pour l'api
 */
@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ErrorResponse {

    /**
     * Code d'erreur HTTP
     */
    @JsonProperty("code")
    @ApiModelProperty(position = 1)
    private Integer httpCode;

    /**
     * Message d'erreur
     */
    @JsonProperty("message")
    @ApiModelProperty(position = 2)
    private String errorMsg;

    /**
     * Informations complémentaires : description longue, Human-readable
     */
    @JsonProperty("info")
    @ApiModelProperty(position = 3)
    private String errorInfo;


    public ErrorResponse(final IGenericException exception) {
        httpCode = exception.getHttpStatus().value();
        errorMsg = exception.getLibelleError();
        errorInfo = exception.getMessage();
    }

}
