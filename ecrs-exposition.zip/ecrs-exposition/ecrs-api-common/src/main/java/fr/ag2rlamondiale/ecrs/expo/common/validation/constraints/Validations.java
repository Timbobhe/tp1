package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints;

import fr.ag2rlamondiale.ecrs.expo.common.exception.BadRequestException;

import java.util.function.Supplier;

public class Validations {
    public static void checkNonNull(Object value, String message) {
        if (value == null) {
            throw new BadRequestException(message);
        }
    }
    public static void checkAssertion(Supplier<Boolean> expression, String message) {
        if (Boolean.TRUE.equals(expression.get())) {
            throw new BadRequestException(message);
        }
    }
}
