package fr.ag2rlamondiale.ecrs.expo.common.exception;

import org.springframework.http.HttpStatus;

/**
 * Interface d'implémentation de méthodes utilitaires pour les exceptions levées
 * par l'application
 */
public interface IGenericException {

    HttpStatus getHttpStatus();

    String getMessage();

    String getLibelleError();

}
