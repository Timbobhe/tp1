package fr.ag2rlamondiale.ecrs.expo.common.dto.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RequestClientPartenaireDto {
    private String codeApplicationPartenaire;
    private String identifiantEpargneRetraite;
    private String referenceExterne;
}
