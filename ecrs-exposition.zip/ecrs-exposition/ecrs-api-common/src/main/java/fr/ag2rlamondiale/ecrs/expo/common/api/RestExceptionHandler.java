/*
 * Cree le 18 janv. 2016.
 * (c) Ag2r - La Mondiale, 2016. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.expo.common.api;

import fr.ag2rlamondiale.ecrs.expo.common.dto.error.ApiAcquittalError;
import fr.ag2rlamondiale.ecrs.expo.common.dto.error.ErrorResponse;
import fr.ag2rlamondiale.ecrs.expo.common.exception.IGenericException;
import fr.ag2rlamondiale.ecrs.expo.common.exception.TechnicalException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.HierarchicalMessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.Locale;
import java.util.stream.Collectors;

/**
 * ResponseEntityExceptionHandler applicative heritant de l'implementation de
 * Metis pour gestion des exceptions applicatives (non deja gerees par Spring ou
 * Metis), sur les appels de services REST Spring MVC (qui met par defaut le
 * message d'Exception dans la reponse REST, alors que l'implementation par
 * defaut de Spring ne met qu'un message relatif au status code).
 * <p>
 * Il faut une classe applicative avec l'annotation ControllerAdvice, heritant
 * de MetisSpringRestResponseEntityExceptionHandler, sinon l'implementation
 * Metis n'est pas utilisee dans l'application.
 *
 * @author JEGE
 */
@ControllerAdvice
@Slf4j
public class RestExceptionHandler {

    @Autowired
    HierarchicalMessageSource hierarchicalMessageSource;


    @ExceptionHandler(BindException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ApiAcquittalError> handleValidationExceptions(BindException ex) {
        final String errorMsg = ex.getBindingResult().getAllErrors().stream()
                .map((error) -> hierarchicalMessageSource.getMessage(error, Locale.FRANCE))
                .collect(Collectors.joining(", "));
        return new ResponseEntity<>(new ApiAcquittalError(ErrorResponse.builder()
                .httpCode(HttpStatus.BAD_REQUEST.value())
                .errorMsg("Arguments incorrects")
                .errorInfo(errorMsg)
                .build()),
                HttpStatus.BAD_REQUEST);
    }

    public ResponseEntity<ApiAcquittalError> handleGenericExceptions(IGenericException ex) {
        return new ResponseEntity<>(new ApiAcquittalError(ex), ex.getHttpStatus());
    }

    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<ApiAcquittalError> handleValidationException(final Exception exception) {
        log.error("Service d'exposition : {}", exception.getMessage());

        if (exception instanceof IGenericException) {
            return handleGenericExceptions((IGenericException) exception);
        } else if (exception instanceof BindException) {
            return handleValidationExceptions((MethodArgumentNotValidException) exception);
        } else if (exception instanceof com.ag2r.common.exceptions.TechnicalException
                || exception instanceof fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException) {
            return new ResponseEntity<>(new ApiAcquittalError(ErrorResponse.builder()
                    .httpCode(HttpStatus.BAD_GATEWAY.value())
                    .errorMsg("Erreur reçue depuis un service distant")
                    .build()),
                    HttpStatus.BAD_GATEWAY);
        } else {
            return new ResponseEntity<>(new ApiAcquittalError(ErrorResponse.builder()
                    .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                    .errorMsg(TechnicalException.LIBELLE_ERROR)
                    .build()),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
