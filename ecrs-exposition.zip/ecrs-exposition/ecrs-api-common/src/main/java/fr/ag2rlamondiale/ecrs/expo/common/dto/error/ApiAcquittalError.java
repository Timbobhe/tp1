package fr.ag2rlamondiale.ecrs.expo.common.dto.error;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.ecrs.expo.common.exception.IGenericException;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Objet Response Error pour l'api
 *
 * @author MSAC
 */
@ApiModel(description = "Format d'échange de l'API : Données en sortie dans le cas d'une erreur")
@Data
@AllArgsConstructor
public class ApiAcquittalError {

    /**
     * Objet d'erreur
     */
    @JsonProperty("errorResponse")
    @ApiModelProperty
    private ErrorResponse errorResponse;

    public ApiAcquittalError(final IGenericException exception) {
        errorResponse = new ErrorResponse(exception);
    }

}
