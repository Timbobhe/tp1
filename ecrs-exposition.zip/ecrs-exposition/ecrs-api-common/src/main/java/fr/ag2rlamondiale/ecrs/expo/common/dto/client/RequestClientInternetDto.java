package fr.ag2rlamondiale.ecrs.expo.common.dto.client;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RequestClientInternetDto {
    private String idFournisseurIdentite;
    private String loginFournisseurIdentite;
    private boolean connexionPartenaire;
    private String codeApplicationPartenaire;
}
