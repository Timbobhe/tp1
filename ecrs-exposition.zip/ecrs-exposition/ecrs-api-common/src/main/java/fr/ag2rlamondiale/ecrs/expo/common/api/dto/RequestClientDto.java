package fr.ag2rlamondiale.ecrs.expo.common.api.dto;

import fr.ag2rlamondiale.ecrs.expo.common.ApiConstants;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(description = "Représente la requête permettant de cibler un client : Données d'appel en entrée")
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class RequestClientDto {
    @ApiModelProperty(position = 1, value = "**[Internet-1]** Identifiant du fournisseur d'identit\u00E9, issue du Service Habilitation; \"1\" pour GDI", example = "1")
    private String idFournisseurIdentite;

    @ApiModelProperty(position = 2, value = "**[Internet-2]** Login du client selon le fournisseur d'identit\u00E9", example = "1mgu13")
    private String loginFournisseurIdentite;

    @ApiModelProperty(position = 3, value = "**[Internet-3]** Indique si le client est une connexion Partenaire, dans ce cas on trouvera le code du partenaire depuis le HEADER HTTP " + ApiConstants.HEADER_XCALLER)
    private boolean connexionPartenaire;

    @ApiModelProperty(position = 11, value = "`[Partenaire-2]` Num\u00E9ro de personne dans ERE, correspondant \u00E0 un identifiant client", example = "P4167507")
    private String identifiantEpargneRetraite;

    @ApiModelProperty(position = 12, value = "`[Partenaire-3]` Identifiant technique du client g\u00E9r\u00E9 par le partenaire (aussi connu sous le nom de refExterne)", example = "006040962735940901")
    private String identifiantExterneClient;

}
