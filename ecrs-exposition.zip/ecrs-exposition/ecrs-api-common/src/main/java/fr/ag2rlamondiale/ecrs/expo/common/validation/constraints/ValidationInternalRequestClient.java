package fr.ag2rlamondiale.ecrs.expo.common.validation.constraints;

import fr.ag2rlamondiale.ecrs.expo.common.ApiConstants;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.InternalRequestClientDto;
import fr.ag2rlamondiale.ecrs.expo.common.exception.BadRequestException;

import static fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.Validations.checkAssertion;
import static fr.ag2rlamondiale.ecrs.expo.common.validation.constraints.Validations.checkNonNull;


public class ValidationInternalRequestClient {

    public static void check(InternalRequestClientDto requestClient) throws BadRequestException {
        checkNonNull(requestClient, "Renseigner une RequestClient");

        checkAssertion(() -> requestClient.getIdFournisseurIdentite() == null && requestClient.getCodeApplicationPartenaire() == null,
                "Renseigner soit idFournisseurIdentite soit codeApplicationPartenaire");


        if (requestClient.getIdFournisseurIdentite() != null) {
            checkNonNull(requestClient.getLoginFournisseurIdentite(), "loginFournisseurIdentite");
            checkAssertion(() -> requestClient.isConnexionPartenaire() && requestClient.getCodeApplicationPartenaire() == null,
                    "Requete avec connexionPartenaire=true => Il faut fournir le codeApplicationPartenaire via HEADER HTTP " + ApiConstants.HEADER_XCALLER);
        }

        else if (requestClient.getCodeApplicationPartenaire() != null) {
            checkAssertion(() -> requestClient.getIdentifiantExterneClient() == null && requestClient.getIdentifiantEpargneRetraite() == null
                            || requestClient.getIdentifiantExterneClient() != null && requestClient.getIdentifiantEpargneRetraite() != null,
                    "Renseigner identifiantExterneClient ou identifiantEpargneRetraite");
        }

    }


}
