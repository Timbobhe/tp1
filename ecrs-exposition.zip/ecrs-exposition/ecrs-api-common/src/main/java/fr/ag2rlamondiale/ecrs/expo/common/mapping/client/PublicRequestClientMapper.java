package fr.ag2rlamondiale.ecrs.expo.common.mapping.client;

import fr.ag2rlamondiale.ecrs.expo.common.api.dto.RequestClientDto;
import fr.ag2rlamondiale.ecrs.expo.common.dto.client.InternalRequestClientDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", builder = @org.mapstruct.Builder(disableBuilder = true))
public interface PublicRequestClientMapper {

    InternalRequestClientDto map(RequestClientDto requestClient, String codeApplicationPartenaire);

}
