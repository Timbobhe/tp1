package fr.ag2rlamondiale.ecrs.expo.common.domain;

import com.ag2r.common.exceptions.TechnicalException;
import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.trm.business.ISimpleBlocageFacade;
import fr.ag2rlamondiale.trm.domain.blocage.InfosBlocagesClient;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.Getter;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

import java.util.List;
import java.util.function.Function;

@Slf4j
public class WithUserContext {
    private final UserContextHolder holder;
    private final ISimpleBlocageFacade simpleBlocageFacade;

    @Getter
    private final UserContext userContext;

    public WithUserContext(UserContext userContext, UserContextHolder holder, ISimpleBlocageFacade simpleBlocageFacade) {
        this.holder = holder;
        this.userContext = userContext;
        this.simpleBlocageFacade = simpleBlocageFacade;
    }

    @SneakyThrows
    public WithUserContext initBlocagesClient(List<? extends IContrat> contratsClient) {
        final InfosBlocagesClient infosBlocagesClient = simpleBlocageFacade.getInfosBlocagesClient(userContext, contratsClient);
        this.userContext.setInfosBlocagesClient(infosBlocagesClient);
        log.info("INFO BLOCAGES CONSOLE pour USERCONTEXT={}", userContext);
        return this;
    }

    public <T> T execute(Function<WithUserContext, T> code) {
        MDC.put(FrmkLogKeys.IDENTIFIANT_UTILISATEUR, userContext.getIdGdi());
        log.info("Execute avec USERCONTEXT={}", userContext);
        holder.set(userContext);
        try {
            return code.apply(this);
        } finally {
            holder.clean();
        }
    }
}
