package fr.ag2rlamondiale.ecrs.expo.common.dto.client;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InternalRequestClientDto {
    private String idFournisseurIdentite;
    private String loginFournisseurIdentite;
    private boolean connexionPartenaire;
    private String codeApplicationPartenaire;
    private String identifiantEpargneRetraite;
    private String identifiantExterneClient;

    @JsonIgnore
    public RequestClientInternetDto toRequestClientInternetDto() {
        if (idFournisseurIdentite != null) {
            return RequestClientInternetDto.builder()
                    .idFournisseurIdentite(idFournisseurIdentite)
                    .loginFournisseurIdentite(loginFournisseurIdentite)
                    .connexionPartenaire(connexionPartenaire)
                    .codeApplicationPartenaire(connexionPartenaire ? codeApplicationPartenaire : null)
                    .build();
        }
        return null;
    }

    @JsonIgnore
    public RequestClientPartenaireDto toRequestClientPartenaireDto() {
        if (codeApplicationPartenaire != null) {
            return RequestClientPartenaireDto.builder()
                    .codeApplicationPartenaire(codeApplicationPartenaire)
                    .identifiantEpargneRetraite(identifiantEpargneRetraite)
                    .referenceExterne(identifiantExterneClient)
                    .build();
        }
        return null;
    }
}
