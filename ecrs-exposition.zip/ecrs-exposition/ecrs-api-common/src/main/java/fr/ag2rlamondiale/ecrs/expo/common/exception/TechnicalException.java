package fr.ag2rlamondiale.ecrs.expo.common.exception;

public class TechnicalException extends RuntimeException {
    public static final String LIBELLE_ERROR = "Erreur technique interne.";

    public TechnicalException() {
    }

    public TechnicalException(String message) {
        super(message);
    }

    public TechnicalException(String message, Throwable cause) {
        super(message, cause);
    }

    public TechnicalException(Throwable cause) {
        super(cause);
    }

    public TechnicalException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
