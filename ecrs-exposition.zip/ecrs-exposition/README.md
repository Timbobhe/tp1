# Bienvenue - ECRS Exposition

Ce projet permet d'exposer des API de la Recette Supplémentaire à des applications internes comme à des partenaires extérieurs.

Les API seront mises à disposition via la plateforme APIGEE.

## Modules

Le projet **ecrs-exposition** est découpé en module Maven :
1. **ecrs-api** est le point d'entrée, c'est ce module qui porte la classe Main `EcrsExpositionApplication`
2. **ecrs-api-contrat** permet d'exposer les API portants sur les contrats avant la Retraite
3. **ecrs-api-common** contient les classes communes à l'ensemble des API
4. **ecrs-lib-contrat** contient l'intelligence de la gestion des contrats de Retraite supplémentaire


### Graphe de dépendances

```mermaid
graph TD
    A[ecrs-exposition] -->|main| B(ecrs-api)
    B --> C[ecrs-api-contrat]
    C --> D[ecrs-api-common]
    C --> |ecrs-back-lib| E[ecrs-lib-contrat]
    E --> F[ecrs-lib-client]
```

## Intégration continue

Jenkins est un outil logiciel d’intégration continu. Il permet de tester et de rapporter les changements effectués en temps réels.
Vous pouvez néanmoins choisir de désactiver l'intégration continue si vous souhaitez ne pas l'utiliser sur le projet.

Il faut tout simplement décocher la case *Active*.

Vous y avez accès via :
> Settings => Integrations => Jenkins CI

Dans le cas où l'intégration continue est utilisée, vous pouvez consulter votre job via : 

> [Votre projet sous Cloudbees](https://master-0.pacific.appli/job/A1573/job/ecrs-exposition/)

### Support
Contacter la [LD DSI Support ICE](mailto:LDDSISupportICE@ag2rlamondiale.fr).

## Qualimétrie

Sonarqube, est un logiciel open source permettant de tester et de mesurer la qualité du code source de façon continue.
Cet outil fournit des rapports sur plusieurs mesures comme la duplication de code, le niveau de documentation, la 
détection de bugs potentiels ou encore l'évaluation des tests unitaires sur le code.

> [Votre projet sous Sonarqube](https://quality.pacific.appli/dashboard?id=A1573:ecrs-exposition)
	

## Pacific

PACIFIC est la mise en oeuvre d'un ensemble d'outils liés à l'intégration continue. Elle vise à simplifier l'usage de 
l'IC en fournissant un ensemble cohérent d'outils préconfigurés, ainsi que des exemples d'usage de ces outils. 
L'objectif étant de faire de l'IC un standard, tout en considérant la migration vers ces outils comme un non-évènement.

> Vous pouvez consulter la documentation Pacific pour toutes informations supplémentaires - [Documentation](https://git-prd.server.lan/A0961/PACIFIC)

Il faut savoir que deux fichiers sont générés par défaut lors de la création de votre projet :

- [Jenkinsfile](https://git-prd.server.lan/A1573/ecrs-exposition/blob/master/Jenkinsfile) : C'est un template que l'on peut compléter selon nos besoins.
Il permet de faire le lien entre Cloudbees et Gitlab, c'est ce fichier qui est déclenché lors du lancement d'un pipeline. 
- [.gitignore](https://git-prd.server.lan/A1573/ecrs-exposition/blob/master/.gitignore) : 
Par défaut, le fichier gitignore est complet. Vous pouvez cependant à tout moment ajouter manuellement des fichiers si nécessaire.

### Support
Contacter la [LD DSI Assemblage](mailto:ld_dsi_assemblage@ag2rlamondiale.fr).

## Gitflow AG2R

> Documentation du Gitflow AG2R - [Gitflow](https://git-prd.server.lan/Formation/TP/blob/master/docs/workflow.md)


