package fr.ag2rlamondiale.ecrs.expo.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Collections;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    @Value("${app.version}")
    private String version;

    @Autowired
    private SwaggerContact contact;

    @Bean
    public Docket productApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .enable(true)
                .select()
                .apis(RequestHandlerSelectors.basePackage("fr.ag2rlamondiale.ecrs.expo.contrat.api"))
//                .paths(PathSelectors.ant("/v1/**"))
                .build()
                .apiInfo(apiInfo())
                .useDefaultResponseMessages(false);
    }

    /**
     * Api Info du projet
     *
     * @return les infos relatives à l'api
     */
    private ApiInfo apiInfo() {
        Contact contact = new Contact(this.contact.getName(), this.contact.getUrl(), this.contact.getEmail());
        return new ApiInfo("API d'usage du projet Retraite Suppl\u00E9mentaire FRONT - Service Catalogue d'Exposition",
                "Ensemble des apis d'usage d\u00E9ploy\u00E9es pour le projet Retraite Suppl\u00E9mentaire FRONT dans le cadre d'appel au service catalogue d'exposition",
                version, "Terms of service", contact, null, null, Collections.emptyList());
    }


    @Data
    @Component
    @ConfigurationProperties(prefix = "swagger.contact")
    public static class SwaggerContact {
        private String name;
        private String email;
        private String url;
    }


}
