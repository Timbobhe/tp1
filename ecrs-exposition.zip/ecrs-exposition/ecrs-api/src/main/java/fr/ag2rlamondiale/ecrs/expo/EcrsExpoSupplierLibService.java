package fr.ag2rlamondiale.ecrs.expo;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Primary
@Service
public class EcrsExpoSupplierLibService implements ISupplierLibService {

    @Override
    public String getCodeCassiniAppli() {
        return CodeApplicationType.ECRS.getCode();
    }

    @Override
    public String getLibelleAppli() {
        return "ESPACE CLIENT RETRAITE SUPPLEMENTAIRE - EXPOSITION API";
    }

    @Override
    public String getUrlFront() {
        throw new AbstractMethodError();
    }
}
