package fr.ag2rlamondiale.ecrs.expo.web;

import org.springframework.core.Ordered;

public class EcrsExpoWebConstants {

    public static final int ORDER_FILTER_THREAD_LOCAL = Ordered.HIGHEST_PRECEDENCE;
    public static final int ORDER_FILTER_REQUEST_ID = ORDER_FILTER_THREAD_LOCAL + 1;
    public static final int ORDER_FILTER_CRSFR = ORDER_FILTER_REQUEST_ID + 1;
    public static final int ORDER_FILTER_PARTENAIRE_EXCEPTION = ORDER_FILTER_CRSFR + 1;
    public static final int ORDER_FILTER_LIMITE_CONNEXION = ORDER_FILTER_PARTENAIRE_EXCEPTION + 1;

    public static final int ORDER_REQUEST_CONTEXT_FILTER = -105;//-2147483500;

    /**
     * Position : après que l'utilisateur soit récupéré par Spring.
     */
    public static final int ORDER_FILTER_RESTORE_USER_CONTEXTE_SESSION = ORDER_REQUEST_CONTEXT_FILTER + 105;//-2147483500;

    private EcrsExpoWebConstants() {
        // ignore
    }
}
