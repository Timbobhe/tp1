package fr.ag2rlamondiale.ecrs.expo.trm;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.Secure;
import fr.ag2rlamondiale.trm.security.UserSecurityService;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import org.aspectj.lang.JoinPoint;
import org.springframework.stereotype.Service;

@Service
public class NullUserSecurityService implements UserSecurityService {
    @Override
    public boolean isAuthorized(JoinPoint joinPoint, Secure secure) {
        return true;
    }

    @Override
    public void initSecurityContext(String s, PersonnePhysique personnePhysique) {

    }

    @Override
    public void initSecurityContext(UserTestManager userTestManager) {

    }
}
