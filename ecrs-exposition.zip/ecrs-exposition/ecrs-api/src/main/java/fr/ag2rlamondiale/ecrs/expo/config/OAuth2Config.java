package fr.ag2rlamondiale.ecrs.expo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;

@Configuration
//@EnableGlobalMethodSecurity(securedEnabled = true)
public class OAuth2Config {

//	private final OAuth2ResourceServerProperties.Jwt properties;
//	
//	OAuth2Config(OAuth2ResourceServerProperties properties) {
//		this.properties = properties.getJwt();
//	}

    /**
     * Config pour extraire les <code>GrantedAuthority</code>
     * à partir de l'attribut <code>roles</code> du JWT
     */
    @Bean
    public JwtAuthenticationConverter jwtAuthenticationConverter() {
        JwtGrantedAuthoritiesConverter grantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        grantedAuthoritiesConverter.setAuthoritiesClaimName("roles");
        grantedAuthoritiesConverter.setAuthorityPrefix("ROLE_");
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(grantedAuthoritiesConverter);
        return jwtAuthenticationConverter;
    }


//	Pour augmenter le timeout d'acces au JWKS qui est bas par defaut
//	https://github.com/spring-projects/spring-security/issues/4474
//	@Bean
//	public JwtDecoder jwtDecoder() throws KeySourceException, MalformedURLException {
//		// Pour augmenter le timeout d'acces au JWKS qui est bas par defaut
//		// https://github.com/spring-projects/spring-security/issues/4474
//		RemoteJWKSet<SecurityContext> jwkSource = new RemoteJWKSet<>(new URL(properties.getJwkSetUri()),
//				new DefaultResourceRetriever(10000, 10000, RemoteJWKSet.DEFAULT_HTTP_SIZE_LIMIT));
//		JWSKeySelector<SecurityContext> jwsKeySelector = JWSAlgorithmFamilyJWSKeySelector
//				.fromJWKSource(jwkSource);
//		
//		DefaultJWTProcessor<SecurityContext> jwtProcessor = new DefaultJWTProcessor<>();
//		jwtProcessor.setJWSKeySelector(jwsKeySelector);
//		return new NimbusJwtDecoder(jwtProcessor);
//	}	

}
