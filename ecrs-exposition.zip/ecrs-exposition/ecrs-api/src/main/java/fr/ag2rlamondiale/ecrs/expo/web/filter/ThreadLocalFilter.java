package fr.ag2rlamondiale.ecrs.expo.web.filter;

import com.google.common.base.Splitter;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.ecrs.expo.performance.IServerTimingSupport;
import fr.ag2rlamondiale.ecrs.expo.web.EcrsExpoWebConstants;
import fr.ag2rlamondiale.trm.cache.RequestScopedCacheManager;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.slf4j.MDC;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Set;

import static fr.ag2rlamondiale.ecrs.expo.performance.IServerTimingSupport.ATTRIBUTE_NAME_START_REQ_TIME;


/**
 * filter pour mettre a jour le wsContext Threadlocal
 */
public class ThreadLocalFilter implements Filter, InitializingBean, Ordered {

    @Autowired
    private RequestScopedCacheManager requestScopedCacheManager;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private IServerTimingSupport serverTiming;

    @Value("${http.headers.to-mdc:user-agent}")
    private String confHeaders;

    private Set<String> headersToMDC;

    @Override
    public void init(FilterConfig filterConfig) {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    @Override
    public void destroy() {
        // Empty
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse response, FilterChain filterChain)
            throws IOException, ServletException {
        try {
            HttpServletRequest request = (HttpServletRequest) servletRequest;


            if (serverTiming.isActive()) {
                request.setAttribute(ATTRIBUTE_NAME_START_REQ_TIME, System.currentTimeMillis());
            }

            MDC.put("clientIp", getClientIp(request));

            if (!this.headersToMDC.contains("none")) {
                for (String header : this.headersToMDC) {
                    final String value = request.getHeader(header);
                    MDC.put("reqheader." + header, value);
                }
            }


            requestScopedCacheManager.clearCaches();

            filterChain.doFilter(request, response);
        } finally {
            requestScopedCacheManager.clearCaches();
            MDC.clear();
            // On Force le CLEAN du UserContext sur ce Filtre qui est toujours présent (à la connexion et pendant les requêtes).
            userContextHolder.clean();
        }
    }


    private static String getClientIp(HttpServletRequest request) {
        String remoteAddr = "";
        if (request != null) {
            remoteAddr = request.getHeader("X-FORWARDED-FOR");
            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = request.getRemoteAddr();
            }
        }

        return remoteAddr;
    }

    @Override
    public void afterPropertiesSet() {
        headersToMDC = Sets.newHashSet(Splitter.on(",").trimResults().omitEmptyStrings().split(this.confHeaders));
    }

    @Override
    public int getOrder() {
        return EcrsExpoWebConstants.ORDER_FILTER_THREAD_LOCAL;
    }
}
