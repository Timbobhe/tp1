package fr.ag2rlamondiale.ecrs.expo.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import fr.ag2rlamondiale.ecrs.expo.contrat.ContratConfig;
import fr.ag2rlamondiale.ecrs.expo.web.filter.ClientRequestTracking;
import fr.ag2rlamondiale.ecrs.expo.web.filter.ThreadLocalFilter;
import org.springframework.context.annotation.*;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.HandlerTypePredicate;
import org.springframework.web.servlet.config.annotation.PathMatchConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@ComponentScan
@Import({ContratConfig.class})
public class ApiConfig implements WebMvcConfigurer {

    static {
        SecurityContextHolder.setStrategyName(SecurityContextHolder.MODE_INHERITABLETHREADLOCAL);
    }

    @Bean(name = "theadLocalFilter")
    public ThreadLocalFilter threadLocalFilter() {
        return new ThreadLocalFilter();
    }

    @Bean(name = "clientRequestFilter")
    public ClientRequestTracking clientRequestTracking() {
        return new ClientRequestTracking();
    }

    /**
     * https://reflectoring.io/configuring-localdate-serialization-spring-boot/
     * https://docs.spring.io/spring-boot/docs/current-SNAPSHOT/reference/htmlsingle/#howto.spring-mvc.customize-jackson-objectmapper
     */
    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        ObjectMapper mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        return mapper;
    }

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.addPathPrefix("/api", HandlerTypePredicate.forAnnotation(RestController.class));
    }
}
