package fr.ag2rlamondiale.ecrs.expo.web.filter;

import com.ag2r.common.keys.log.FrmkLogKeys;
import org.slf4j.MDC;
import org.springframework.core.Ordered;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Random;

import static fr.ag2rlamondiale.ecrs.expo.web.EcrsExpoWebConstants.ORDER_FILTER_REQUEST_ID;


public class ClientRequestTracking implements Filter, Ordered {

    public static final String REQUEST_ID = "fr.ag2rlamondiale.idReq";
    public static final String X_ID_REQ = "X-ID-REQ";

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;

        String requeteId = getRequeteId(request);
        MDC.put(FrmkLogKeys.IDENTIFIANT_REQUETE, requeteId);


        request.setAttribute(REQUEST_ID, requeteId);
        response.addHeader(X_ID_REQ, requeteId);

        filterChain.doFilter(request, response);
    }

    private static String getRequeteId(HttpServletRequest request) {
        String requeteId = request.getHeader(X_ID_REQ);
        if (requeteId == null) {
            requeteId = generateRequestId();
        }
        return requeteId;
    }

    private static String generateRequestId() {
        Random randnumber = new Random();
        int number = randnumber.nextInt(100000) + 1000000;
        return 'R' + Integer.toString(number);
    }


    @Override
    public int getOrder() {
        return ORDER_FILTER_REQUEST_ID;
    }
}

