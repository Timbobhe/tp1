package fr.ag2rlamondiale.ecrs.expo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource({"classpath:application-contextual-values.properties"})
public class PropertyConfig {

}
