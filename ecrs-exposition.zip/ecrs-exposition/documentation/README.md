# Documentation ECRS-EXPOSITION

## JDD

- **Autre contrat MDP :** ` n6q1gu`

  **Requête :** http://localhost:8086/rsa/api/v1/contrats/calculer_encours?idFournisseurIdentite=1&loginFournisseurIdentite=n6q1gu

  **Retour :**
```json
{
    "codeFiliale": "ALM",
    "libelleFiliale": "AG2R LA MONDIALE",
    "dateEncours": "2022-04-01",
    "encoursTotal": 3506.1,
    "detailEncours": [
        {
            "idContrat": "RF056611043003",
            "raisonSociale": "S.A.S LA PUB EN VERT",
            "libelleProduit": "Régime de Retraite et de Prévoyance",
            "dateEncours": null,
            "encours": null
        },
        {
            "idContrat": "RA207914165000",
            "raisonSociale": "Monsieur BONNEAU MARC",
            "libelleProduit": "Retraite individuelle",
            "dateEncours": "2022-04-01",
            "encours": 3506.1
        },
        {
            "idContrat": "RS056611140002",
            "raisonSociale": "S.A.S LA PUB EN VERT",
            "libelleProduit": "Régime de Retraite et de Prévoyance",
            "dateEncours": null,
            "encours": null
        }
    ]
}
```

- **Test ERE :** `1mgu13`

  **Requête :** http://localhost:8086/rsa/api/v1/contrats/calculer_encours?idFournisseurIdentite=1&loginFournisseurIdentite=1mgu13

  **Retour :**

```json
{
  "codeFiliale": "ACA",
  "libelleFiliale": "ARIAL CNP Assurance",
  "dateEncours": "2022-04-05",
  "encoursTotal": 42065.05,
  "detailEncours": [
    {
      "idContrat": "RG151236289",
      "raisonSociale": "COMPAGNIE IBM FRANCE",
      "libelleProduit": "Plan d'Épargne Retraite Entreprises",
      "dateEncours": "2022-04-05",
      "encours": 40852.55
    },
    {
      "idContrat": "RG152289321",
      "raisonSociale": "COMPAGNIE IBM FRANCE",
      "libelleProduit": "PLAN D'EPARGNE RETRAITE OBLIGATOIRE",
      "dateEncours": "2022-04-05",
      "encours": 1212.5
    }
  ]
}
```


- **Test MDP :** `qnun5e`

  **Requête :** http://localhost:8086/rsa/api/v1/contrats/calculer_encours?idFournisseurIdentite=1&loginFournisseurIdentite=qnun5e

  **Retour :**

```json
{
    "codeFiliale": "ALM",
    "libelleFiliale": "AG2R LA MONDIALE",
    "dateEncours": "2022-04-01",
    "encoursTotal": 19801.27,
    "detailEncours": [
        {
            "idContrat": "RA149894488000",
            "raisonSociale": "Madame FRIGIERE BRIGITTE",
            "libelleProduit": "Mondiale Solutions Retraite",
            "dateEncours": "2022-04-01",
            "encours": 19801.27
        }
    ]
}
```

- **Appel depuis Partenaire, avec _idEpargneRetraite_ :**

  **Requête :** http://localhost:8086/rsa/api/v1/contrats/calculer_encours?codePartenaire=49505&identifiantEpargneRetraite=P4508543

  **Retour :**

```json
{
  "codeFiliale": "ACA",
  "libelleFiliale": "ARIAL CNP Assurance",
  "dateEncours": "2022-04-05",
  "encoursTotal": 4748.01,
  "detailEncours": [
    {
      "idContrat": "RG151545137",
      "raisonSociale": "SOMFY ACTIVITES SA",
      "libelleProduit": "Plan d'Épargne Retraite Entreprises",
      "dateEncours": "2022-04-05",
      "encours": 4748.01
    }
  ]
}
```
