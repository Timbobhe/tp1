create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), idpai bigint not null, primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
create sequence sd0inpq start with 1 increment by 1
create sequence sd0paiq start with 1 increment by 1
create sequence sd0plfq start with 1 increment by 1
create sequence sd0prfq start with 1 increment by 1
create sequence sd0prmq start with 1 increment by 1
create table tbsd0bdt (tybusdat varchar(10) not null, vabusdat varchar(35), idpai bigint not null, primary key (tybusdat, idpai))
create table tbsd0cdt (noord integer not null, vacstdat varchar(35), idpai bigint not null, primary key (idpai, noord))
create table tbsd0exb (lbban varchar(45) not null, tscre timestamp, dteff date, primary key (lbban))
create table tbsd0his (idpai bigint not null, tseta timestamp not null, coetapai varchar(255) not null, lbmsgstt varchar(200), mtpai float, costt varchar(30), primary key (idpai, tseta))
create table tbsd0inp (idinp bigint not null, coapp varchar(5) not null, coiso varchar(2), tscre timestamp, dteff date, tymet varchar(30), lbpay varchar(40), typay varchar(255), primary key (idinp))
create table tbsd0pai (idpai bigint not null, lbbancli varchar(45), coapp varchar(5) not null, idctr varchar(30), idctrref varchar(30), tscre timestamp not null, tsmaj timestamp, coetapai varchar(255) not null, tyevemet varchar(255) not null, cofil varchar(3), idtrs varchar(30), idunicli varchar(30) not null, tymthpai varchar(10) not null, tymet varchar(30) not null, mtpai float not null, tynatcli varchar(255), lbnompai varchar(45), idord varchar(32) not null, lbpaymth varchar(40), lbpayres varchar(40), lbpayresfis varchar(40), coprd varchar(30), costrjur varchar(3), intiepai boolean, tycli varchar(255), primary key (idpai))
create table tbsd0pdt (idprm bigint not null, idctrref varchar(30), idctr varchar(30), cofil varchar(3), coprd varchar(30), costrjur varchar(3), primary key (idprm))
create table tbsd0plf (idplf bigint not null, mtmax float, mtmin float, nbmax integer, tyfrq varchar(255) not null, primary key (idplf))
create table tbsd0ppl (idplf bigint not null, idprm bigint not null, tymthpai varchar(255) not null, primary key (idplf, idprm, tymthpai))
create table tbsd0prf (idprf bigint not null, coapp varchar(5) not null, tyevemet varchar(255), tymet varchar(30) not null, tynatcli varchar(255), tycli varchar(255), primary key (idprf))
create table tbsd0prm (idprm bigint not null, tscre timestamp, dteff date, dtfineff date, tsmaj timestamp, idprmpar bigint, intiepai boolean not null, typrm varchar(255) not null, vaprm varchar(30) not null, idprf bigint, primary key (idprm))
alter table tbsd0pai add constraint UK_g8oa22nei4xbpnc9219kjal7b unique (idtrs)
alter table tbsd0pai add constraint UK_jfgmuuku8o12xyqla2yevdot0 unique (idord)
alter table tbsd0bdt add constraint FK7ki64kp0pcvawikb8y61kyes8 foreign key (idpai) references tbsd0pai
alter table tbsd0cdt add constraint FKrsgonjfb16aaxiibo4etelp9e foreign key (idpai) references tbsd0pai
alter table tbsd0his add constraint FKry31m0ngcr78qhecmb3oojn8r foreign key (idpai) references tbsd0pai
alter table tbsd0pdt add constraint FKba6ryhuh769cxdm1avriaucvo foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKh9hgev3hygvagpivd3neq4ky4 foreign key (idprm) references tbsd0prm
alter table tbsd0ppl add constraint FKq0sg44rlt0i13hi1qq5t2vrcl foreign key (idplf) references tbsd0plf
alter table tbsd0prm add constraint FK9jghct8u9oykbsncjsfwbvsiq foreign key (idprf) references tbsd0prf
