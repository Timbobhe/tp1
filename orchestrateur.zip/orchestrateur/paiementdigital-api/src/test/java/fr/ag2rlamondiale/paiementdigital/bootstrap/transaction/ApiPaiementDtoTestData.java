package fr.ag2rlamondiale.paiementdigital.bootstrap.transaction;

import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;
import fr.ag2rlamondiale.paiementdigital.dto.HistoriqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import org.springframework.stereotype.Component;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.dateNowMinusDays;

@Component
public class ApiPaiementDtoTestData {

    public PaiementDto build(String nomPayeur, String idUniqueClient, Float montant, String orderId, String idTransaction,
                             int numberDays, MethodePaiementEnum methodePaiement, EtatEnum etat) {
        Date date = dateNowMinusDays(numberDays);

        return PaiementDto.builder()
                .orderId(orderId)
                .idTransaction(idTransaction)
                .idUniqueClient(idUniqueClient)
                .metier(TransactionConstantes.RET_SUP_COL)
                .codeApplication(TransactionConstantes.A1324)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .dateCreation(date)
                .dateModification(date)
                .montant(montant)
                .methodeDePaiement(methodePaiement.toString())
                .nomPayeur(nomPayeur)
                .paysMethode("FRANCE")
                .banque("LCL")
                .etatCourant(etat)
                .structureJuridique(TransactionConstantes.ARI)
                .filiale(TransactionConstantes.ACA)
                .produit(null)
                .contrat(null)
                .contratDeReference(null)
                .tiersPayeur(false)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .paysResidence("FRANCE")
                .paysResidenceFiscale("FRANCE")
                .build();
    }

    public Set<HistoriqueDto> modifTransaEtats(EtatEnum etat, Float montant, String code, String message, Long paiementId) {
        Set<HistoriqueDto> historiques = null;

        if (Objects.isNull(etat))
            return Collections.emptySet();

        HistoriqueDto h1 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.CREATE).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h2 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZATION).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h3 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZED).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h4 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.CAPTURE).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h5 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.CAPTURED).status(HipayConstantes.STT_CODE_CAPTURED_OK).message(HipayConstantes.CAPTURED).date(new Date())
                .build();
        HistoriqueDto h6 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.FAIL).status(HipayConstantes.STT_CODE_CAPTURE_FAIL).message(HipayConstantes.STT_MSG_CAPTURE_REFUSED).date(new Date())
                .build();
        HistoriqueDto h7 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.ERROR).status(code).message(message).date(new Date())
                .build();

        switch (etat) {
            case CREATE:
                historiques = new HashSet<>(Arrays.asList(h1));
                break;
            case AUTHORIZATION:
                historiques = new HashSet<>(Arrays.asList(h1, h2));
                break;
            case AUTHORIZED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3));
                break;
            case CAPTURE:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4));
                break;
            case CAPTURED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h5));
                break;
            case FAIL:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h6));
                break;
            case ERROR:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h7));
                break;
        }

        return historiques;
    }

    public Set<HistoriqueDto> creerTransaEtats(EtatEnum etat, Float montant, String code, String message, Long paiementId) {
        Set<HistoriqueDto> historiques = null;

        if (Objects.isNull(etat))
            return Collections.emptySet();

        HistoriqueDto h1 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.CREATE).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h2 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZATION).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h3 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZED).status(null).message(null).date(new Date())
                .build();
        HistoriqueDto h4 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.FAIL).status(code).message(message).date(new Date())
                .build();
        HistoriqueDto h5 = HistoriqueDto.builder()
                .montant(montant).etat(EtatEnum.ERROR).status(code).message(message).date(new Date())
                .build();

        switch (etat) {
            case CREATE:
                historiques = new HashSet<>(Arrays.asList(h1));
                break;
            case AUTHORIZATION:
                historiques = new HashSet<>(Arrays.asList(h1, h2));
                break;
            case AUTHORIZED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3));
                break;
            case FAIL:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h4));
                break;
            case ERROR:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h5));
                break;
        }

        return historiques;
    }
}
