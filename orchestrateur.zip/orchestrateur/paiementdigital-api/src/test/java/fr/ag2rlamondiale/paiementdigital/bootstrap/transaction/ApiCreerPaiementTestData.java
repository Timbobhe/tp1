package fr.ag2rlamondiale.paiementdigital.bootstrap.transaction;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.*;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.Arrays;

import static fr.ag2rlamondiale.paiementdigital.utils.TransactionUtils.buildLongDateTime;

@Component
public class ApiCreerPaiementTestData {

    public ResponseEntity<CreerPaimtDigiRootResp> creerPaimtDigiRespSuccess(HttpStatus httpStatus, String idTransaction, float montant, String codeSit) {
        CreerPaimtDigiRootResp response = creerPaimtDigiRespBuilderSuccess(idTransaction, montant, codeSit);
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), httpStatus);
    }

    public ResponseEntity<CreerPaimtDigiRootResp> creerPaimtDigiRespError(HttpStatus httpStatus, String code, String message) {
        CreerPaimtDigiRootResp response = creerPaimtDigiRespBuilderFailure(httpStatus, code, message);
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), httpStatus);
    }

    private CreerPaimtDigiRootResp creerPaimtDigiRespBuilderSuccess(String idTransaction, float montant, String codeSit) {
        DetMntPaimtResp detMntPaimt = DetMntPaimtResp
                .builder()
                .codeDevVersm(DeviseEnum.EUR)
                .mntFraisLivr(1.3f)
                .mntTaxes(1.1f)
                .mntTTC(montant)
                .build();

        DetTransaPaimtNumeriseResp detTransaPaimtNum = DetTransaPaimtNumeriseResp.builder()
                .refTransPaimtDigi(idTransaction)
                .numAutionTransaPaimtNumerise("AUT190999999999")
                .instantAutionTransa(buildLongDateTime(2021, 2, 8, 12, 0, 5))
                .instantCreatTransa(buildLongDateTime(2021, 2, 8, 12, 0, 0))
                .instantModifTransa(buildLongDateTime(2021, 2, 8, 12, 0, 5))
                .mntTransaPaimtDigi(montant)
                .codeDevMntTransaPaimtDigi(DeviseEnum.EUR)
                .codeSitTransaPaimtDigi(codeSit)
                .build();

        PaimtDigiResp paimtDigi = PaimtDigiResp.builder()
                .detTransaPaimtNumerise(detTransaPaimtNum)
                .detMntPaimt(detMntPaimt)
                .build();

        CreerPaimtDigiRespBisResp creerPaimtDigiResponseBis = new CreerPaimtDigiRespBisResp(paimtDigi);

        CreerPaimtDigiFuncResp creerPaimtDigiFunc = new CreerPaimtDigiFuncResp(creerPaimtDigiResponseBis);

        CreerPaimtDigiResp creerPaimtDigiResponse = new CreerPaimtDigiResp(creerPaimtDigiFunc);

        BodyResp body = new BodyResp(creerPaimtDigiResponse);

        ResponseResp response = new ResponseResp(null, body);

        return new CreerPaimtDigiRootResp(response);
    }

    private CreerPaimtDigiRootResp creerPaimtDigiRespBuilderFailure(HttpStatus httpStatus, String code, String message) {
        HeaderResp header = new HeaderResp();
        ErrorResp error = ErrorResp
                .builder()
                .errorCode(code)
                .errorMessage(message)
                .build();
        if (!HttpStatus.INTERNAL_SERVER_ERROR.equals(httpStatus)) {
            header.setFuncError(Arrays.asList(error));
        } else {
            header.setTechError(Arrays.asList(error));
        }

        ResponseResp response = new ResponseResp(header, null);

        return new CreerPaimtDigiRootResp(response);
    }

}
