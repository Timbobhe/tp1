package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.notification.ApiNotificationTestData;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@AutoConfigureTestDatabase
class NotificationControllerTest {

    @Autowired
    private MockMvc mvc;

    @Autowired
    private SecurityTestData security;

    @MockBean
    private NotificationController controller;

    @Autowired
    private ApiNotificationTestData notificationData;

    private String uri = "/api/notification/send";

    private String token;

    @BeforeEach
    void setUp() {
        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        token = null;
    }

    @Test
    void call_notification_return_ok_and_notification_authorized_status() throws Exception {

       ResponseEntity<NotificationRootResp> notificationRootResp = new ResponseEntity<>(notificationData.buildResponseStatus200_authorized(), HttpStatus.OK);

        //WHEN THEN
        when(controller.sendNotification(any(NotificationRootReq.class))).thenReturn(notificationRootResp);

        String authorizedRequest = "json/send-notification-authorize-req-test.json";
        mvc.perform(
                post(uri)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
                        .content(JsonUtils.asJsonString(JsonUtils.notificationRequest(authorizedRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").value("A1573"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").value("00001338125"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").value("116"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").value("Authorized"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").value("9"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").value("visa"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").value("ORDER_Pauline_012"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").value("CPL"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").value("Authorized"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").value("XXX"));
    }


    @Test
    void call_notification_return_ok_and_notification_captured_status() throws Exception {

        ResponseEntity<NotificationRootResp> notificationRootResp = new ResponseEntity<>(notificationData.buildResponseStatus200_captured(), HttpStatus.OK);

        //WHEN THEN
        when(controller.sendNotification(any(NotificationRootReq.class))).thenReturn(notificationRootResp);

        String capturedRequest = "json/send-notification-capure-req-test.json";
        mvc.perform(
                post(uri)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
                        .content(JsonUtils.asJsonString(JsonUtils.notificationRequest(capturedRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").value("A1573"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").value("00001338125"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").value("118"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").value("Captured"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").value("9"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").value("visa"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").value("ORDER_Pauline_012"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").value("CPL"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").value("Captured"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").value("XXX"));
    }

    @Test
    void call_notification_return_ok_and_notification_cpl_fail_status() throws Exception {

        ResponseEntity<NotificationRootResp> notificationRootResp = new ResponseEntity<>(notificationData.buildResponseStatus200_cpl_fail(), HttpStatus.OK);

        //WHEN THEN
        when(controller.sendNotification(any(NotificationRootReq.class))).thenReturn(notificationRootResp);

        String cplFailRequest = "json/send-notification-cpl-fail-req-test.json";
        mvc.perform(
                post(uri)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
                        .content(JsonUtils.asJsonString(JsonUtils.notificationRequest(cplFailRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").value("A1573"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").value("00001338125"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").value("173"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").value("Fail"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").value("9"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").value("visa"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").value("ORDER_Pauline_012"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").value("CPL"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").value("Fail"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").value("XXX"));
    }

    @Test
    void call_notification_return_ok_and_notification_fail_status() throws Exception {

        ResponseEntity<NotificationRootResp> notificationRootResp = new ResponseEntity<>(notificationData.buildResponseStatus200_fail(), HttpStatus.OK);

        //WHEN THEN
        when(controller.sendNotification(any(NotificationRootReq.class))).thenReturn(notificationRootResp);

        String annulationRequest = "json/send-notification-ann-req-test.json";
        mvc.perform(
                post(uri)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
                        .content(JsonUtils.asJsonString(JsonUtils.notificationRequest(annulationRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").value("A1573"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").value("00001338125"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").value("173"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").value("Fail"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").value("9"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").value("visa"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").value("ORDER_Pauline_012"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").value("ANN"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").value("Fail"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").value("XXX"));
    }

    @Test
    void call_notification_return_ok_and_notification_pending_status() throws Exception {

        ResponseEntity<NotificationRootResp> notificationRootResp = new ResponseEntity<>(notificationData.buildResponseStatus200_pending(), HttpStatus.OK);

        //WHEN THEN
        when(controller.sendNotification(any(NotificationRootReq.class))).thenReturn(notificationRootResp);

        String pendingRequest = "json/send-notification-pending-req-test.json";
        mvc.perform(
                post(uri)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
                        .content(JsonUtils.asJsonString(JsonUtils.notificationRequest(pendingRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.destinataire").value("A1573"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.identifiantMarchant").value("00001338125"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.statut").value("200"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.message").value("Pending"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeValeurECI").value("9"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.codeModePaiement").value("visa"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.EntetePaiementNumerise.identifiantDemandePaiement").value("ORDER_Pauline_012"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.codeSituationTransactionPaiementDigital").value("ATT"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DetailTransactionPaiementNumerise.libelleSituationTransactionPaiementDigital").value("Pending"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier").exists())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].typeDonnee").value("test"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").isNotEmpty())
                .andExpect(MockMvcResultMatchers.jsonPath("$.NotifierPaiementDigital.PaiementDigital.DonneesMetier[*].valeurDonnee").value("XXX"));
    }
}