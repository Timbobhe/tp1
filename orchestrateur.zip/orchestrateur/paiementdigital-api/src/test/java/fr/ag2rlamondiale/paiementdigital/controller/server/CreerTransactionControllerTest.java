package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.controller.client.CreerPaiementDigitalController;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransacPaimtDigiResponse;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.AdditionalAnswers;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@ActiveProfiles("test")
class CreerTransactionControllerTest {

    @Autowired
    private MockMvc mvc;

    @Mock
    private ICreerTransaRespBuilderFacade facade;

    @Mock
    private IEtatPaiementFacade etatPaiementFacade;

    @Mock
    private PfsPropertyConfig config;

    @Mock
    private IInterpreteurPfsResponseFacade<CreerPaimtDigiRootResp, Paiement> interpreteurFacade;

    @Mock
    private IGestionTokenFacade gestionTokenFacade;

    @Mock
    private ICreerPaimtDigiReqBuilderFacade creerPaimtDigibuildFacade;

    @Mock
    private CreerPaiementDigitalController controller;

    @Autowired
    private SecurityTestData security;

    private String uri = "/api/transaction";

    private Paiement paiement;

    private String creerTransaRequest = "json/creer-transaction-req-ok-test.json";

    private CreerTransaPaimtDigiRootResp creerTransaResponse;

    private float montant;

    private String orderId;

    private String idTransaction;

    private ResponseEntity<CreerPaimtDigiRootResp> creerPaiementDigitalResponseExpected;

    private String paiementResponseFilename = "json/creer-paimt-digi-rep-test.json";

    private String token;

    @BeforeEach
    void setUp() {
        CreerTransacPaimtDigiResponse creerTransacPaimtDigiResponse = CreerTransacPaimtDigiResponse.builder().build();
        creerTransaResponse = CreerTransaPaimtDigiRootResp.builder().creationTransactionPaiementDigital(creerTransacPaimtDigiResponse).build();
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        paiement = Paiement.builder()
                .id(21l)
                .orderId(orderId)
                .montant(montant)
                .idTransaction(idTransaction)
                .methodeDePaiement(MASTERCARD.name())
                .etatCourant(AUTHORIZED)
                .build();

        creerPaiementDigitalResponseExpected = getCreerTransaction(paiementResponseFilename);

        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        creerTransaResponse = null;
        paiement = null;
        creerPaiementDigitalResponseExpected = null;
        token = null;
    }

    @Disabled
    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    void insertion_paiement_digital_should_return_response_entity() throws Exception {
        //GIVEN
        given(etatPaiementFacade.create(any(CreerTransaPaimtDigiRootReq.class))).willReturn(paiement);

        given(etatPaiementFacade.authorization(any(Paiement.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        given(config.getCreatePaiementUrl()).willReturn("value");

        given(gestionTokenFacade.getUriWithParams(any(String.class), any(String.class), any(String.class))).willReturn("some value");

        given(creerPaimtDigibuildFacade.build(any(CreerTransaPaimtDigiRootReq.class), any(Paiement.class))).willReturn(new CreerPaimtDigiRootReq());

        given(controller.creerPaiementDigital(any(String.class), any(CreerPaimtDigiRootReq.class))).willReturn(creerPaiementDigitalResponseExpected);

        given(interpreteurFacade.interpreteur(any(), any(Paiement.class))).willAnswer(AdditionalAnswers.returnsFirstArg());

        given(facade.build(any(Paiement.class), any())).willReturn(creerTransaResponse);

        //WHEN THEN
        mvc.perform(
                post(uri + "/create")
                        .content(JsonUtils.asJsonString(JsonUtils.transactionRequest(creerTransaRequest)))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk());
    }

    private ResponseEntity<CreerPaimtDigiRootResp> getCreerTransaction(String filename) {
        CreerPaimtDigiRootResp creerPaiementDigitalResponseDto = JsonUtils.paiementResponse(filename);
        return new ResponseEntity<>(creerPaiementDigitalResponseDto, HttpStatus.OK);
    }


}