package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IEtatTransPaimtDigiFacade;
import fr.ag2rlamondiale.paiementdigital.domain.CustomData;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.*;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerTransaRespMapper;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerTransaToPaimtMapper;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.ERROR;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreerTransaRespBuilderFacadeImplTest {

    @InjectMocks
    private CreerTransaRespBuilderFacadeImpl facade;

    @Mock
    private ICreerTransaRespBuilderFacade transactionFacade;

    @Mock
    private IInterpreteurPfsResponseFacade<CreerPaimtDigiRootResp, Paiement> interpreteurFacade;

    @Mock
    private IEtatPaiementFacade etatPaiementFacade;

    @Mock
    private ICreerTransaToPaimtMapper transactionRequestMapper;

    @Mock
    private IPaiementFacade paiementFacade;

    @Mock
    private IEtatTransPaimtDigiFacade etatTransPaimtDigiFacade;

    @Mock
    private ICreerTransaRespMapper mapper;

    @Autowired
    private ApiPaiementTestData paiementData;

    @Autowired
    ApiPaiementTestData apiTransactionTestData;

    private Paiement paiement;

    private ResponseEntity<CreerPaimtDigiRootResp> creerTransaResp;

    private String paiementResponseFilename = "json/creer-paimt-digi-rep-test.json";

    private float montant;

    private String idTransaction;

    private String orderId;

    private Set<CustomData> customDatas;

    private String status = "300003";

    private String message = "message error";

    @BeforeEach
    void setUp() {

        CustomData c1 = CustomData.builder().ordre(1).cdata("ARI").build();
        CustomData c2 = CustomData.builder().ordre(2).cdata("RG01002ARI").build();
        CustomData c3 = CustomData.builder().ordre(3).cdata("1311014").build();
        CustomData c4 = CustomData.builder().ordre(4).cdata("A0499").build();
        CustomData c5 = CustomData.builder().ordre(5).cdata("P5049181").build();
        customDatas = new HashSet<>(Arrays.asList(c1, c2, c3, c4, c5));

        montant = 8.99f;
        idTransaction = ApiPaiementITData.idTransaction();
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());

        creerTransaResp = getCreerTransaction(paiementResponseFilename);

    }

    @AfterEach
    void tearDown() {
        idTransaction = null;
        orderId = null;
        paiement = null;
        creerTransaResp = null;
        customDatas = null;
    }

    @Test
    void invalid_parameters_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> facade.build(null, null));
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_authorized() {
        //GIVEN
        EtatEnum etat = EtatEnum.AUTHORIZED;
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, etat);
        paiement.setHistoriques(paiementData.creerTransaEtats(etat, montant, null, null, paiement.getId()));
        paiement.setCustomDatas(customDatas);
        when(interpreteurFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);
        when(mapper.toEnteteTransactionPaiementDigital(any(Paiement.class), any(EntetePaimtNumeriseResp.class))).thenReturn(new EnteteTransaPaimtDigiResp());
        when(etatTransPaimtDigiFacade.toEtatTransactionPaiementDigital(any(Paiement.class), any(DetTransaPaimtNumeriseResp.class))).thenReturn(EtatTransaPaimtDigiResp.builder().etatCourant(etat).build());
        when(mapper.toDetailTransactionPaiementDigital(any(Paiement.class), any(DetTransaPaimtNumeriseResp.class))).thenReturn(new DetailTransaPaimtDigiResp());
        when(mapper.toDetailActeurs(any(Paiement.class), any(EmailsResp.class))).thenReturn(new DetailActeursResp());
        when(mapper.toDetailCartePaiement(any(Paiement.class), any(DetCartePaimtResp.class))).thenReturn(new DetailCartePaimtResp());
        when(mapper.toDetailMontantPaiement(any(Paiement.class), any(DetMntPaimtResp.class))).thenReturn(new DetailMontantPaimtResp());
        when(mapper.toDetailPerimetreMetier(any(Paiement.class))).thenReturn(new DetailPerimetreMetierResp());
        when(mapper.toInformationsTechniques(any(InfoTechResp.class))).thenReturn(new InformationsTechniquesResp());

        //WHEN
        CreerTransaPaimtDigiRootResp actual = facade.build(paiement, creerTransaResp);

        //THEN
        assertEquals(etat, actual.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_fail() {
        //GIVEN
        EtatEnum etat = EtatEnum.FAIL;
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, etat);
        paiement.setHistoriques(paiementData.creerTransaEtats(etat, montant, status, message, paiement.getId()));
        paiement.setCustomDatas(customDatas);

        when(interpreteurFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);
        when(mapper.toEnteteTransactionPaiementDigital(any(Paiement.class), any(EntetePaimtNumeriseResp.class))).thenReturn(new EnteteTransaPaimtDigiResp());
        when(etatTransPaimtDigiFacade.toEtatTransactionPaiementDigital(any(Paiement.class), any(DetTransaPaimtNumeriseResp.class))).thenReturn(EtatTransaPaimtDigiResp.builder().etatCourant(etat).build());
        when(mapper.toDetailTransactionPaiementDigital(any(Paiement.class), any(DetTransaPaimtNumeriseResp.class))).thenReturn(new DetailTransaPaimtDigiResp());
        when(mapper.toDetailActeurs(any(Paiement.class), any(EmailsResp.class))).thenReturn(new DetailActeursResp());
        when(mapper.toDetailCartePaiement(any(Paiement.class), any(DetCartePaimtResp.class))).thenReturn(new DetailCartePaimtResp());
        when(mapper.toDetailMontantPaiement(any(Paiement.class), any(DetMntPaimtResp.class))).thenReturn(new DetailMontantPaimtResp());
        when(mapper.toDetailPerimetreMetier(any(Paiement.class))).thenReturn(new DetailPerimetreMetierResp());
        when(mapper.toInformationsTechniques(any(InfoTechResp.class))).thenReturn(new InformationsTechniquesResp());

        //WHEN
        CreerTransaPaimtDigiRootResp actual = facade.build(paiement, creerTransaResp);

        //THEN
        assertEquals(etat, actual.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_error() {
        //GIVEN
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        paiement.setHistoriques(paiementData.creerTransaEtats(ERROR, montant, status, message, paiement.getId()));

        when(interpreteurFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);

        //WHEN
        CreerTransaPaimtDigiRootResp actual = facade.build(paiement, creerTransaResp);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(status, actual.getCodeErreur());
        assertEquals(message, actual.getMessageErreur());
        assertNull(actual.getCreationTransactionPaiementDigital());
    }

    private ResponseEntity<CreerPaimtDigiRootResp> getCreerTransaction(String filename) {
        CreerPaimtDigiRootResp creerPaiementDigitalResponseDto = JsonUtils.paiementResponse(filename);
        return new ResponseEntity<>(creerPaiementDigitalResponseDto, HttpStatus.OK);
    }
}