package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class ResponseBuilderFacadeImplTest {

    @InjectMocks
    private ResponseBuilderFacadeImpl builder;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    private RecupParamProfResp parametre;

    private Set<ExclusionBanqueDto> exclusions;

    private Set<InclusionPaysDto> inclusions;

    private Set<RecupParamPlfdFreqResp> plafonds1;

    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        parametre = parametrageLabData.getParametre();

        exclusions = parametrageLabData.getExclusions();

        inclusions = parametrageLabData.getInclusions();

        plafonds1 = parametrageLabData.getPlafonds1();

        methodes = parametrageLabData.getMethodes();
    }

    @AfterEach
    void tearDown() {
        parametre = null;
        exclusions = null;
        inclusions = null;
        plafonds1 = null;
        methodes = null;
    }

    @Test
    void build_recuperer_parametrages_lab_dto_is_ok() {
        //GIVEN
        RecupParamRootResp expected = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();

        //WHEN
        RecupParamRootResp actual = builder.build(parametre, exclusions, inclusions);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void build_parametres_profils_dto_is_ok() {
        //GIVEN
        float max = 300;
        String methodeMax = MethodePaiementEnum.CB.name();
        int nombre = 4;
        String methodeNombre = MethodePaiementEnum.VISA.name();

        RecupParamProfResp expected = RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(max)
                .methodeMaxDesMontantsDispo(methodeMax)
                .maxDesNombresDePaiementDispo(nombre)
                .methodeMaxDesNombresDePaiementDispo(methodeNombre)
                .perimetreMethodePaiement(methodes)
                .build();

        //WHEN
        RecupParamProfResp actual = builder.build(max, methodeMax, nombre, methodeNombre, methodes);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void build_perimetre_methode_paiement_dto_is_ok() {
        //GIVEN
        String methodeName = MethodePaiementEnum.CB.name();
        float minMontant = 300;
        String frequenceMontant = TypeFrequenceEnum.MOIS_GLISSANT.name();
        int minNombre = 3;
        String frequenceNombre = TypeFrequenceEnum.MOIS_GLISSANT.name();

        RecupParamPeriMethPaimtResp expected = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(methodeName)
                .frequenceMinMontantDispoClient(frequenceMontant)
                .minMontantDispoClient(minMontant)
                .frequenceNombrePaiementDisponible(frequenceNombre)
                .minNombrePaiementDisponible(minNombre)
                .plafondsParFrequences(plafonds1)
                .build();

        //WHEN
        RecupParamPeriMethPaimtResp actual = builder.build(methodeName, minMontant, frequenceMontant,
                minNombre, frequenceNombre, plafonds1);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void build_plafonds_par_frequences_dto_is_ok() {
        //GIVEN
        Plafond plafond = Plafond
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT)
                .montantMinimum(0F)
                .montantMaximum(1000F)
                .nombreMaximumPaiement(5)
                .build();

        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(500)
                .nombreMaxDispoClient(3)
                .build();
        //WHEN
        RecupParamPlfdFreqResp actual = builder.build(plafond, 500, 3);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }
}