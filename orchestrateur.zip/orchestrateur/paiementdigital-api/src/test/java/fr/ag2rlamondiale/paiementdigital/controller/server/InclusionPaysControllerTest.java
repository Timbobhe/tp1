package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IInclusionPaysMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.JSON_PATTERN_DATE_FORMAT;
import static fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum.DOMICILIATION_BANCAIRE;
import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.AUCUN_PAYS_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@AutoConfigureTestDatabase
class InclusionPaysControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IInclusionPaysFacade facade;

    @MockBean
    private IInclusionPaysMapper mapper;

    @Autowired
    private SecurityTestData security;

    private InclusionPays paysSaved;

    private InclusionPaysDto paysSavedDto;

    private String uri = "/api/pays";

    private String codeApplication = "A1573";

    private String nomPays = "France";

    private String codeIso = "FRA";

    private Date dateEffet = buildShortDate(2020, 10, 12);

    private Date dateCreation = buildLongDate(2020, 10, 12);

    private String token;

    @BeforeEach
    void setUp() {

        paysSaved = InclusionPays
                .builder()
                .id(1L)
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(codeApplication)
                .typePays(DOMICILIATION_BANCAIRE)
                .pays(nomPays)
                .codeIso(codeIso)
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

        paysSavedDto = InclusionPaysDto
                .builder()
                .id(1L)
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(codeApplication)
                .typePays(DOMICILIATION_BANCAIRE)
                .pays(nomPays)
                .codeIso(codeIso)
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        paysSaved = null;
        paysSavedDto = null;
        token = null;
    }

    @Test
    void finding_pays_by_id_is_ok() throws Exception {
        //GIVEN
        given(facade.findById(anyLong())).willReturn(paysSaved);
        given(mapper.toPaysDto(any(InclusionPays.class))).willReturn(paysSavedDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/1")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.metier").value(ProfilConstantes.RET_SUP_COL))
                .andExpect(jsonPath("$.codeApplication").value(codeApplication))
                .andExpect(jsonPath("$.typePays").value(DOMICILIATION_BANCAIRE.toString()))
                .andExpect(jsonPath("$.pays").value(nomPays))
                .andExpect(jsonPath("$.codeIso").value(codeIso))
                .andExpect(jsonPath("$.dateEffet").value(dateEffet.toString()))
                .andExpect(jsonPath("$.dateCreation").value(format(dateCreation, JSON_PATTERN_DATE_FORMAT)));

    }

    @Test
    void finding_unknown_pays_by_id_is_404_status() throws Exception {
        //GIVEN
        given(facade.findById(anyLong())).willThrow(new InclusionPaysException(AUCUN_PAYS_TROUVE));

        //WHEN THEN
        mvc.perform(
                get(uri + "/1000")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value(AUCUN_PAYS_TROUVE));
    }

    @Test
    void getting_all_pays_is_ok() throws Exception {
        //GIVEN
        Set<InclusionPaysDto> paysDto = new HashSet<>(Arrays.asList(paysSavedDto));
        Set<InclusionPays> pays = new HashSet<>(Arrays.asList(paysSaved));
        given(facade.findAll()).willReturn(pays);
        given(mapper.toDtoSet(anySet())).willReturn(paysDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/all")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }
}