package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.EtatTransaPaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.DetTransaPaimtNumeriseResp;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.FAIL;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest
class EtatTransPaimtDigiFacadeImplTest {

    @InjectMocks
    EtatTransPaimtDigiFacadeImpl facade;

    @Autowired
    private ApiPaiementTestData paiementData;

    private Paiement paiement;

    private DetTransaPaimtNumeriseResp detTransaPaimtNumResp;

    private String status = "300002";

    private String message = "Hipay error";

    float montant;

    private String orderId;

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                "89087655566", 1, MASTERCARD, AUTHORIZED);
        paiement.setHistoriques(paiementData.creerTransaEtats(AUTHORIZED, montant, null, null, paiement.getId()));

        detTransaPaimtNumResp = DetTransaPaimtNumeriseResp
                .builder()
                .numAutionTransaPaimtNumerise("AUT1999999")
                .mntTransaPaimtDigi(montant)
                .codeDevMntTransaPaimtDigi(DeviseEnum.EUR)
                .codeSitTransaPaimtDigi(HipayConstantes.CPL)
                .build();
    }

    @AfterEach
    void tearDown() {
        orderId = null;
        paiement = null;
        detTransaPaimtNumResp = null;
    }

    @Test
    void map_etat_transac_paiement_digital_when_state_authorized() {
        //WHEN
        EtatTransaPaimtDigiResp actual = facade.toEtatTransactionPaiementDigital(paiement, detTransaPaimtNumResp);

        //THEN
        assertEquals(paiement.getEtatCourant(), actual.getEtatCourant());
        assertNull(actual.getStatus());
        assertNull(actual.getMessage());
        assertEquals(detTransaPaimtNumResp.getCodeSitTransaPaimtDigi(), actual.getCodeSitTransPaiemtDigi());
    }

    @Test
    void map_etat_transac_paiement_digital_when_state_fail() {
        //GIVEN
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                "89087655566", 1, MASTERCARD, FAIL);
        paiement.setHistoriques(paiementData.creerTransaEtats(FAIL, montant, status, message, paiement.getId()));

        //WHEN
        EtatTransaPaimtDigiResp actual = facade.toEtatTransactionPaiementDigital(paiement, detTransaPaimtNumResp);

        //THEN
        assertEquals(paiement.getEtatCourant(), actual.getEtatCourant());
        assertEquals(status, actual.getStatus());
        assertEquals(message, actual.getMessage());
        assertEquals(detTransaPaimtNumResp.getCodeSitTransaPaimtDigi(), actual.getCodeSitTransPaiemtDigi());
    }

}