package fr.ag2rlamondiale.paiementdigital.bootstrap.notification;

import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.*;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class ApiNotificationTestData {


    public NotificationRootResp buildResponseStatus200_authorized() {

        PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                .entetePaiementNumerise(buildEntetePaiementNumeriseResp())
                .detailTransPaiemtNumerise(buildDetailTransactionPaiementNumeriseAuthResp())
                .donneesMetier(buildDonnesMetierResponse())
                .identifiantMarchant("00001338125")
                .statut("116")
                .message("Authorized")
                .destinataire("A1573")
                .build();

        NotificationResp notificationResp = NotificationResp.builder()
                .paimentDigiResp(paimentDigiResp)
                .build();

        NotificationRootResp notificationRootResp = NotificationRootResp
                .builder()
                .notificationResp(notificationResp)
                .build();

        return notificationRootResp;
    }

    public NotificationRootResp buildResponseStatus200_captured() {

        PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                .entetePaiementNumerise(buildEntetePaiementNumeriseResp())
                .detailTransPaiemtNumerise(buildDetailTransactionPaiementNumeriseCaptureResp())
                .donneesMetier(buildDonnesMetierResponse())
                .identifiantMarchant("00001338125")
                .statut("118")
                .message("Captured")
                .destinataire("A1573")
                .build();

        NotificationResp notificationResp = NotificationResp.builder()
                .paimentDigiResp(paimentDigiResp)
                .build();

        NotificationRootResp notificationRootResp = NotificationRootResp
                .builder()
                .notificationResp(notificationResp)
                .build();

        return notificationRootResp;
    }

    public NotificationRootResp buildResponseStatus200_cpl_fail() {

        PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                .entetePaiementNumerise(buildEntetePaiementNumeriseResp())
                .detailTransPaiemtNumerise(buildDetailTransactionPaiementNumeriseCplFailResp())
                .donneesMetier(buildDonnesMetierResponse())
                .identifiantMarchant("00001338125")
                .statut("173")
                .message("Fail")
                .destinataire("A1573")
                .build();

        NotificationResp notificationResp = NotificationResp.builder()
                .paimentDigiResp(paimentDigiResp)
                .build();

        NotificationRootResp notificationRootResp = NotificationRootResp
                .builder()
                .notificationResp(notificationResp)
                .build();

        return notificationRootResp;
    }

    public NotificationRootResp buildResponseStatus200_pending() {

        PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                .entetePaiementNumerise(buildEntetePaiementNumeriseResp())
                .detailTransPaiemtNumerise(buildDetailTransactionPaiementNumerisePendingResp())
                .donneesMetier(buildDonnesMetierResponse())
                .identifiantMarchant("00001338125")
                .statut("200")
                .message("Pending")
                .destinataire("A1573")
                .build();

        NotificationResp notificationResp = NotificationResp.builder()
                .paimentDigiResp(paimentDigiResp)
                .build();

        NotificationRootResp notificationRootResp = NotificationRootResp
                .builder()
                .notificationResp(notificationResp)
                .build();

        return notificationRootResp;
    }

    public NotificationRootResp buildResponseStatus200_fail() {

        PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                .entetePaiementNumerise(buildEntetePaiementNumeriseResp())
                .detailTransPaiemtNumerise(buildDetailTransactionPaiementNumeriseFailResp())
                .donneesMetier(buildDonnesMetierResponse())
                .identifiantMarchant("00001338125")
                .statut("173")
                .message("Fail")
                .destinataire("A1573")
                .build();

        NotificationResp notificationResp = NotificationResp.builder()
                .paimentDigiResp(paimentDigiResp)
                .build();

        NotificationRootResp notificationRootResp = NotificationRootResp
                .builder()
                .notificationResp(notificationResp)
                .build();

        return notificationRootResp;
    }

    private MaintenanceOperationResp buildMaintenanceOperationResp() {
        return MaintenanceOperationResp.builder()
                .typeDerniereOperation("")
                .idOperation("")
                .referenceOperation("")
                .montantOperation("")
                .deviseOperation("")
                .dateOperation("")
                .build();
    }



    private Set<DonneeMetierResp> buildDonnesMetierResponse() {
        return new HashSet<>(Collections.singletonList(DonneeMetierResp.builder()
                .typeDonnee("test")
                .valeurDonnee("XXX").build()));
    }

    private Set<CustomDataResp> buildCustumDataResp() {
        return new HashSet<>(Arrays.asList(CustomDataResp.builder()
                .ordre(2)
                .cdata("RG151252488")
                .build(), CustomDataResp.builder()
                .ordre(1)
                .cdata("ARI")
                .build()));
    }

    private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumeriseAuthResp() {

        return DetailTransactionPaiementNumeriseResp.builder()
                .referenceTransactionPaiementDigital("800105012345")
                .codeSituationTransactionPaiementDigital("CPL")
                .libelleSituationTransactionPaiementDigital("Authorized")
                .build();
    }

    private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumeriseCaptureResp() {

        return DetailTransactionPaiementNumeriseResp.builder()
                .referenceTransactionPaiementDigital("800105012345")
                .codeSituationTransactionPaiementDigital("CPL")
                .libelleSituationTransactionPaiementDigital("Captured")
                .build();
    }

    private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumeriseCplFailResp() {

        return DetailTransactionPaiementNumeriseResp.builder()
                .referenceTransactionPaiementDigital("800105012345")
                .codeSituationTransactionPaiementDigital("CPL")
                .libelleSituationTransactionPaiementDigital("Fail")
                .build();
    }

    private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumerisePendingResp() {

        return DetailTransactionPaiementNumeriseResp.builder()
                .referenceTransactionPaiementDigital("800105012345")
                .codeSituationTransactionPaiementDigital("ATT")
                .libelleSituationTransactionPaiementDigital("Pending")
                .build();
    }

    private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumeriseFailResp() {

        return DetailTransactionPaiementNumeriseResp.builder()
                .referenceTransactionPaiementDigital("800105012345")
                .codeSituationTransactionPaiementDigital("ANN")
                .libelleSituationTransactionPaiementDigital("Fail")
                .build();
    }

    private EntetePaiementNumeriseResp buildEntetePaiementNumeriseResp() {
        return EntetePaiementNumeriseResp.builder()
                .identifiantDemandePaiement("ORDER_Pauline_012")
                .datePaiement(new Date())
                .codeValeurECI("9")
                .codeModePaiement("visa")
                .numeroTentativePaiementDigital(1)
                .build();
    }


}
