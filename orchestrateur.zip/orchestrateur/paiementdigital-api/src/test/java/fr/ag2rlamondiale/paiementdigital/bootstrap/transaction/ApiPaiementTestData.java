package fr.ag2rlamondiale.paiementdigital.bootstrap.transaction;

import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;
import org.springframework.stereotype.Component;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.dateNowMinusDays;

@Component
public class ApiPaiementTestData {

    public Paiement build(String nomPayeur, String idUniqueClient, Float montant, String orderId, String idTransaction,
                          int numberDays, MethodePaiementEnum methodePaiement, EtatEnum etat) {
        Date date = dateNowMinusDays(numberDays);

        return Paiement.builder()
                .orderId(orderId)
                .idTransaction(idTransaction)
                .idUniqueClient(idUniqueClient)
                .metier(TransactionConstantes.RET_SUP_COL)
                .codeApplication(TransactionConstantes.A1324)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .dateCreation(date)
                .dateModification(date)
                .montant(montant)
                .methodeDePaiement(methodePaiement.toString())
                .nomPayeur(nomPayeur)
                .paysMethode("FRANCE")
                .banque("LCL")
                .etatCourant(etat)
                .structureJuridique(TransactionConstantes.ARI)
                .filiale(TransactionConstantes.ACA)
                .produit(null)
                .contrat(null)
                .contratDeReference(null)
                .tiersPayeur(false)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .paysResidence("FRANCE")
                .paysResidenceFiscale("FRANCE")
                .build();
    }

    public Set<Historique> modifTransaEtats(EtatEnum etat, Float montant, String code, String message, Long paiementId) {
        Set<Historique> historiques = null;

        if (Objects.isNull(etat))
            return Collections.emptySet();

        Historique h1 = Historique.builder()
                .montant(montant).etat(EtatEnum.CREATE).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h2 = Historique.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZATION).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h3 = Historique.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZED).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h4 = Historique.builder()
                .montant(montant).etat(EtatEnum.CAPTURE).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h5 = Historique.builder()
                .montant(montant).etat(EtatEnum.CAPTURED).status(HipayConstantes.STT_CODE_CAPTURED_OK).message(HipayConstantes.CAPTURED).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h6 = Historique.builder()
                .montant(montant).etat(EtatEnum.FAIL).status(HipayConstantes.STT_CODE_CAPTURE_FAIL).message(HipayConstantes.STT_MSG_CAPTURE_REFUSED).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h7 = Historique.builder()
                .montant(montant).etat(EtatEnum.ERROR).status(code).message(message).id(new HistoriquePK(new Date(), paiementId))
                .build();

        switch (etat) {
            case CREATE:
                historiques = new HashSet<>(Arrays.asList(h1));
                break;
            case AUTHORIZATION:
                historiques = new HashSet<>(Arrays.asList(h1, h2));
                break;
            case AUTHORIZED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3));
                break;
            case CAPTURE:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4));
                break;
            case CAPTURED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h5));
                break;
            case FAIL:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h6));
                break;
            case ERROR:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3, h4, h7));
                break;
        }

        return historiques;
    }

    public Set<Historique> creerTransaEtats(EtatEnum etat, Float montant, String code, String message, Long paiementId) {
        Set<Historique> historiques = null;

        if (Objects.isNull(etat))
            return Collections.emptySet();

        Historique h1 = Historique.builder()
                .montant(montant).etat(EtatEnum.CREATE).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h2 = Historique.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZATION).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h3 = Historique.builder()
                .montant(montant).etat(EtatEnum.AUTHORIZED).status(null).message(null).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h4 = Historique.builder()
                .montant(montant).etat(EtatEnum.FAIL).status(code).message(message).id(new HistoriquePK(new Date(), paiementId))
                .build();
        Historique h5 = Historique.builder()
                .montant(montant).etat(EtatEnum.ERROR).status(code).message(message).id(new HistoriquePK(new Date(), paiementId))
                .build();

        switch (etat) {
            case CREATE:
                historiques = new HashSet<>(Arrays.asList(h1));
                break;
            case AUTHORIZATION:
                historiques = new HashSet<>(Arrays.asList(h1, h2));
                break;
            case AUTHORIZED:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h3));
                break;
            case FAIL:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h4));
                break;
            case ERROR:
                historiques = new HashSet<>(Arrays.asList(h1, h2, h5));
                break;
        }

        return historiques;
    }
}
