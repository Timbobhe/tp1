package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementDtoTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.CREATE;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class PaiementControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IPaiementFacade facade;

    @Autowired
    private ApiPaiementDtoTestData data;

    @Autowired
    private SecurityTestData security;

    private String uri = "/api/paiements";

    private PaiementDto paiement;

    private String orderId;

    private String idTransaction;

    private float montant;

    private String token;

    @BeforeEach
    void setUp() {
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        montant = 200f;

        paiement = data.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        paiement.setHistoriques(data.modifTransaEtats(CREATE, montant, null, null, paiement.getId()));
        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);

    }

    @AfterEach
    void tearDown() {
        paiement = null;
        orderId = null;
        idTransaction = null;
        token = null;
    }

    @Test
    void finding_paiement_by_id_is_ok() throws Exception {
        //GIVEN
        given(facade.findPaiementById(anyLong())).willReturn(paiement);

        //WHEN THEN
        mvc.perform(
                get(uri + "/1")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
        )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.orderId").value(orderId))
                .andExpect(jsonPath("$.idUniqueClient").value("CLIENT_1"))
                .andExpect(jsonPath("$.idTransaction").value(idTransaction))
                .andExpect(jsonPath("$.historiques.size()").value(1));

    }

    @Test
    void getting_all_profil_is_ok() throws Exception {
        //GIVEN
        Set<PaiementDto> paiements = new HashSet<>(Arrays.asList(paiement));
        given(facade.findPaiements()).willReturn(paiements);

        //WHEN THEN
        mvc.perform(
                get(uri + "/all")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token)
        )
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }
}