package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetActrReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.TelReq;
import fr.ag2rlamondiale.paiementdigital.dto.type.CiviliteEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.CodeSexeEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.RolePersonneEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.TelephoneEnum;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerPaimtDigiReqMapper;
import fr.ag2rlamondiale.paiementdigital.utils.TransactionUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;

@SpringBootTest
class DetailActeurFacadeImplTest {

    @InjectMocks
    private DetailActeurFacadeImpl facade;

    @Mock
    private ICreerPaimtDigiReqMapper mapper;

    private CreerTransaPaimtDigiRootReq request;

    private Set<TelReq> telephones;

    private String email;

    @BeforeEach
    void setUp() {
        CustomDataReq customData1 = CustomDataReq.builder().cdata("codeFiliale").ordre(1).build();
        CustomDataReq customData2 = CustomDataReq.builder().cdata("idSiloTBD").ordre(2).build();
        CustomDataReq customData3 = CustomDataReq.builder().cdata("idPersAppliPtv").ordre(3).build();
        CustomDataReq customData4 = CustomDataReq.builder().cdata("codeAppli").ordre(4).build();
        CustomDataReq customData5 = CustomDataReq.builder().cdata("idPers").ordre(5).build();

        Set<CustomDataReq> customDataSet = new HashSet<>(Arrays.asList(customData1, customData2, customData3, customData4, customData5));

        DetailPerimetreMetierReq detailPerimetreMetier = DetailPerimetreMetierReq
                .builder()
                .metier(TransactionConstantes.RET_SUP_COL)
                .codeApplication(TransactionConstantes.A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .structureJuridique(TransactionConstantes.ARI)
                .filiale(TransactionConstantes.ACA)
                .build();

        TelephoneReq telephone = TelephoneReq.builder().numeroTelephone("0101010101").codeTypeNumeroTelephone(TelephoneEnum.TPE).build();

        email = "xxxxxxxxxxxxxxxxxxxxxxxx@ag2r.com";

        DetailActeursReq detailActeursReq = DetailActeursReq.builder()
                .idUniqueClient("12345PAR12456")
                .codeRole(RolePersonneEnum.PAY)
                .typeClient(TypeClientEnum.CLIENT)
                .natureClient(NatureClientEnum.PP)
                .civilite(CiviliteEnum.DR)
                .prenom("James")
                .nom("Bond")
                .codeSexe(CodeSexeEnum.M)
                .dateNaissance(TransactionUtils.buildLongDate(1970, 12, 12))
                .nomPayeur("JAMES BOND")
                .libelleEmail(email)
                .telephone(new HashSet<>(Arrays.asList(telephone)))
                .tiersPayeur(false)
                .adresseLigne1("1 Rue de la pensée libre")
                .libelleCommune("Paris")
                .numeroCodePostal("75000")
                .paysResidence("FRANCE")
                .paysResidenceFiscale("FRANCE")
                .build();

        request = CreerTransaPaimtDigiRootReq
                .builder()
                .detailActeurs(detailActeursReq)
                .detailPerimetreMetier(detailPerimetreMetier)
                .customDatas(customDataSet)
                .build();

        TelReq telReq = TelReq.builder().numTel("0101010101").codeTypeNumTel(TelephoneEnum.TPE).build();
        telephones = new HashSet<>(Arrays.asList(telReq));
    }

    @AfterEach
    void tearDown() {
        request = null;
        telephones = null;
        email = null;
    }

    @Test
    void map_detail_acteurs_for_creer_paiement_digital() {
        //GIVEN
        when(mapper.toTelReq(anySet())).thenReturn(telephones);

        //WHEN
        DetActrReq actual = facade.detailActeurs(request);

        //THEN
        assertEquals(RolePersonneEnum.PAY, actual.getCodeRole());
        assertEquals(email, actual.getInfoPP().getSignq().getDosCom().getDetCnlCom().getEmails().getLibEmail());
    }

    @Test
    void map_detail_acteurs_for_creer_paiement_digital_when_() {
        //GIVEN
        when(mapper.toTelReq(anySet())).thenReturn(telephones);
        request.getDetailPerimetreMetier().setCodeApplication(PfsParametersConstantes.CODE_APPLI_PTV);

        //WHEN
        DetActrReq result = facade.detailActeurs(request);

        //THEN
        assertNull(result.getInfoPM());
    }
}