package fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage;

import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetreInfos;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetrePlafond;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamCliReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamPeriReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamProflReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.*;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.*;

@Component
@Getter
public class ApiParametrageLabTestData {

    private RecupParamRootReq request;
    private Plafond plafond;
    private Perimetre perimetreAca;
    private Perimetre perimetreAcaExclu;
    private Perimetre perimetreLmr;

    private RecupParamRootResp response;
    private RecupParamProfResp parametre;
    private Set<ExclusionBanqueDto> exclusions;
    private Set<InclusionPaysDto> inclusions;

    private RecupParamPlfdFreqResp ppf1d1;
    private RecupParamPlfdFreqResp ppf1d2;
    private RecupParamPlfdFreqResp ppf1d3;
    private RecupParamPlfdFreqResp ppf2d1;
    private RecupParamPlfdFreqResp ppf2d2;
    private RecupParamPlfdFreqResp ppf2d3;
    private RecupParamPlfdFreqResp ppf3d1;
    private RecupParamPlfdFreqResp ppf3d2;
    private RecupParamPlfdFreqResp ppf3d3;

    private Set<RecupParamPlfdFreqResp> plafonds1;
    private Set<RecupParamPlfdFreqResp> plafonds2;
    private Set<RecupParamPlfdFreqResp> plafonds3;

    private RecupParamPeriMethPaimtResp pmp1;
    private RecupParamPeriMethPaimtResp pmp2;
    private RecupParamPeriMethPaimtResp pmp3;
    private Set<RecupParamPeriMethPaimtResp> methodes;

    private PaiementDto paiementDto;

    public void init() {

        setUpPfsDto();

        setUpProfil();

        setupInclusionsPays();

        setupExclusionsBanque();

        setUpParamaLab();

    }

    private void setUpProfil() {
        PerimetrePlafond prp1Cb1 = perimetrePlafond(CB.name());
        PerimetrePlafond prp1Visa1 = perimetrePlafond(VISA.name());
        PerimetrePlafond prp1Mastercard1 = perimetrePlafond(MASTERCARD.name());

        PerimetrePlafond prp1Cb2 = perimetrePlafond(CB.name());
        PerimetrePlafond prp1Visa2 = perimetrePlafond(VISA.name());
        PerimetrePlafond prp1Mastercard2 = perimetrePlafond(MASTERCARD.name());

        PerimetrePlafond prp1Cb3 = perimetrePlafond(CB.name());
        PerimetrePlafond prp1Visa3 = perimetrePlafond(VISA.name());
        PerimetrePlafond prp1Mastercard3 = perimetrePlafond(MASTERCARD.name());

        PerimetrePlafond prp7Mastercard1 = perimetrePlafond(MASTERCARD.name());
        PerimetrePlafond prp7Mastercard2 = perimetrePlafond(MASTERCARD.name());
        PerimetrePlafond prp7Mastercard3 = perimetrePlafond(MASTERCARD.name());

        Plafond plfAnnee8000 = plafond(TypeFrequenceEnum.ANNEE_CIVILE, 0f, 8000f, 999, new HashSet<>(Arrays.asList(prp1Cb1, prp1Visa1, prp1Mastercard1, prp7Mastercard1)));
        Plafond plfMois2500 = plafond(TypeFrequenceEnum.MOIS_GLISSANT, 0f, 2500F, 999, new HashSet<>(Arrays.asList(prp1Cb2, prp1Visa2, prp1Mastercard2, prp7Mastercard2)));
        Plafond plfTransaction2500 = plafond(TypeFrequenceEnum.TRANSACTION, 0f, 2500f, 999, new HashSet<>(Arrays.asList(prp1Cb3, prp1Visa3, prp1Mastercard3, prp7Mastercard3)));

        PerimetreInfos pri1 = perimetreInfos(ARI, ACA, null, null, null);
        PerimetreInfos pri7 = perimetreInfos(ARI, LMR, null, null, null);

        perimetreAca = Perimetre
                .builder()
                .id(1L)
                .idParent(0L)
                .typePerimetre(TypePerimetreEnum.FILIALE)
                .valeurPerimetre(ACA)
                .tiersPayeur(false)
                .dateEffet(buildShortDate(2020, 11, 30))
                .dateFinEffet(buildShortDate(2030, 11, 30))
                .dateCreation(buildLongDate(2020, 11, 30))
                .dateModification(null)
                .perimetreInfos(pri1)
                .perimetrePlafonds(new HashSet<>(Arrays.asList(prp1Cb1, prp1Visa1, prp1Mastercard1, prp1Cb2, prp1Visa2, prp1Mastercard2, prp1Cb3, prp1Visa3, prp1Mastercard3)))
                .build();

        perimetreAcaExclu = Perimetre
                .builder()
                .id(2L)
                .idParent(1L)
                .typePerimetre(TypePerimetreEnum.PRODUIT)
                .valeurPerimetre("RR01-001-ACA")
                .tiersPayeur(false)
                .dateEffet(null)
                .dateFinEffet(null)
                .dateCreation(null)
                .dateModification(null)
                .perimetreInfos(pri1)
                .perimetrePlafonds(null)
                .build();

        perimetreLmr = Perimetre
                .builder()
                .id(3L)
                .idParent(0L)
                .typePerimetre(TypePerimetreEnum.FILIALE)
                .valeurPerimetre(LMR)
                .tiersPayeur(false)
                .dateEffet(buildShortDate(2020, 11, 30))
                .dateFinEffet(buildShortDate(2030, 11, 30))
                .dateCreation(buildLongDate(2020, 11, 30))
                .dateModification(null)
                .perimetreInfos(pri7)
                .perimetrePlafonds(new HashSet<>(Arrays.asList(prp7Mastercard1, prp7Mastercard2, prp7Mastercard3)))
                .build();

        paiementDto = PaiementDto.builder()
                .idUniqueClient(request.getClient().getIdUniqueClient())
                .metier(request.getProfil().getMetier())
                .codeApplication(request.getProfil().getCodeApplication())
                .evenementMetier(request.getProfil().getEvenementMetier())
                .natureClient(request.getClient().getNatureClient())
                .typeClient(request.getClient().getTypeClient())
                .tiersPayeur(request.getPerimetre().isTiersPayeur())
                .structureJuridique(request.getPerimetre().getStructureJuridique())
                .filiale(request.getPerimetre().getFiliale())
                .produit(request.getPerimetre().getProduit())
                .contratDeReference(request.getPerimetre().getContratDeReference())
                .contrat(request.getPerimetre().getContrat())
                .methodeDePaiement(MASTERCARD.name())
                .etatCourant(EtatEnum.CAPTURED)
                .build();
    }

    private void setupExclusionsBanque() {
        Date dateEffet = buildShortDate(2019, 12, 1);
        Date dateCreation = buildLongDate(2019, 12, 1);

        ExclusionBanqueDto banqueLcl = ExclusionBanqueDto.builder().banque("LCL").dateCreation(dateCreation).dateEffet(dateEffet).build();
        ExclusionBanqueDto banqueBnp = ExclusionBanqueDto.builder().banque("BNP").dateCreation(dateCreation).dateEffet(dateEffet).build();
        exclusions = new HashSet<>(Arrays.asList(banqueLcl, banqueBnp));
    }

    private void setupInclusionsPays() {
        InclusionPaysDto france = InclusionPaysDto.builder().pays("France").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("FR").build();
        InclusionPaysDto espagne = InclusionPaysDto.builder().pays("Espagne").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("ES").build();
        inclusions = new HashSet<>(Arrays.asList(france, espagne));
    }

    private void setUpPfsDto() {
        RecupParamProflReq profil = RecupParamProflReq.builder()
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .build();

        RecupParamCliReq client = RecupParamCliReq.builder()
                .idUniqueClient("1234567")
                .natureClient(NatureClientEnum.PM)
                .typeClient(TypeClientEnum.CLIENT)
                .build();

        RecupParamPeriReq perimetre = RecupParamPeriReq.builder()
                .filiale("ACA")
                .build();

        request = RecupParamRootReq.builder()
                .profil(profil)
                .client(client)
                .perimetre(perimetre)
                .dateRecherche(new Date())
                .exclusionBanques(true)
                .inclusionPays(true)
                .build();

    }

    private void setUpParamaLab() {
        plafond = Plafond
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT)
                .montantMinimum(0F)
                .montantMaximum(1000F)
                .nombreMaximumPaiement(5)
                .build();

        ppf1d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(15000)
                .nombreMax(20)
                .montantMaxdispoClient(10000)
                .nombreMaxDispoClient(8)
                .build();

        ppf1d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(1000)
                .nombreMax(5)
                .montantMaxdispoClient(300)
                .nombreMaxDispoClient(2)
                .build();

        ppf1d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(1000)
                .nombreMax(5)
                .montantMaxdispoClient(1000)
                .nombreMaxDispoClient(5)
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1d1, ppf1d2, ppf1d3));

        ppf2d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(25000)
                .nombreMax(30)
                .montantMaxdispoClient(15000)
                .nombreMaxDispoClient(25)
                .build();

        ppf2d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(2000)
                .nombreMax(10)
                .montantMaxdispoClient(1000)
                .nombreMaxDispoClient(5)
                .build();

        ppf2d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(2000)
                .nombreMax(10)
                .montantMaxdispoClient(2000)
                .nombreMaxDispoClient(10)
                .build();

        plafonds2 = new HashSet<>(Arrays.asList(ppf2d1, ppf2d2, ppf2d3));

        ppf3d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(20000)
                .nombreMax(25)
                .montantMaxdispoClient(12000)
                .nombreMaxDispoClient(20)
                .build();

        ppf3d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(1500)
                .nombreMax(8)
                .montantMaxdispoClient(1000)
                .nombreMaxDispoClient(6)
                .build();

        ppf3d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(1500)
                .nombreMax(8)
                .montantMaxdispoClient(1500)
                .nombreMaxDispoClient(8)
                .build();

        plafonds3 = new HashSet<>(Arrays.asList(ppf3d1, ppf3d2, ppf3d3));

        pmp1 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(MethodePaiementEnum.CB.name())
                .minMontantDispoClient(300)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(2)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .plafondsParFrequences(plafonds1)
                .build();

        pmp2 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(MethodePaiementEnum.VISA.name())
                .minMontantDispoClient(1000)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(5)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .plafondsParFrequences(plafonds2)
                .build();

        pmp3 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(MASTERCARD.name())
                .minMontantDispoClient(1000)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(6)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .plafondsParFrequences(plafonds3)
                .build();

        methodes = new HashSet<>(Arrays.asList(pmp1, pmp2, pmp3));

        String cards = Arrays.asList(VISA.name(), MASTERCARD.name()).stream().collect(Collectors.joining(",", "[", "]"));

        parametre = RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(1000F)
                .methodeMaxDesMontantsDispo(cards)
                .maxDesNombresDePaiementDispo(6)
                .methodeMaxDesNombresDePaiementDispo(MethodePaiementEnum.CB.toString())
                .perimetreMethodePaiement(methodes)
                .build();

        response = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();
    }

}
