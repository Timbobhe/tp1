package fr.ag2rlamondiale.paiementdigital.controller.client;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreerPaiementDigitalControllerTest {

    @InjectMocks
    private CreerPaiementDigitalController creerPaiDigController;

    @Mock
    private RestTemplate restTemplate;

    private String paiementRequestFilename = "json/creer-paimt-digi-req-test.json";
    private String paiementResponse200Filename = "json/creer-paimt-digi-rep-200-test.json";
    private String paiementResponse400Filename = "json/creer-paimt-digi-rep-400-test.json";
    private String paiementResponse401Filename = "json/creer-paimt-digi-rep-401-test.json";

    @Test
    void creer_paiement_digital_gives_status_401() {
        //GIVEN
        CreerPaimtDigiRootReq request = JsonUtils.paiementRequest(paiementRequestFilename);
        CreerPaimtDigiRootResp response = JsonUtils.paiementResponse(paiementResponse401Filename);
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        String uri = "http://uri_without_params";

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = creerPaiDigController.creerPaiementDigital(uri, request);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void creer_paiement_digital_gives_status_400() {
        //GIVEN
        CreerPaimtDigiRootReq request = JsonUtils.paiementRequest(paiementRequestFilename);
        CreerPaimtDigiRootResp response = JsonUtils.paiementResponse(paiementResponse400Filename);
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        String uri = "http://uri_with_params";

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = creerPaiDigController.creerPaiementDigital(uri, request);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void creer_paiement_digital_gives_status_200() {
        //GIVEN
        CreerPaimtDigiRootReq request = JsonUtils.paiementRequest(paiementRequestFilename);
        CreerPaimtDigiRootResp response = JsonUtils.paiementResponse(paiementResponse200Filename);
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.OK);

        String uri = "http://uri_with_params";

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = creerPaiDigController.creerPaiementDigital(uri, request);

        //THEN
        assertEquals(expected, actual);
    }

}
