package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiCreerPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IPFSFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.DetTransaPaimtNumeriseResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.AbstractMap;
import java.util.Optional;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_TECH_DEFAULT;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class InterpreteurCreerPaimtRespFacadeImplTest {

    @InjectMocks
    private InterpreteurCreerPaimtRespFacadeImpl interpreteurFacade;

    @Mock
    private IPFSFacade pfsFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Autowired
    private ApiCreerPaiementTestData creerPaiementData;

    @Autowired
    private ApiPaiementTestData paiementData;

    private ResponseEntity<CreerPaimtDigiRootResp> response;

    private Paiement paiement;

    private String idTransaction;

    private String orderId;

    private float montant;

    @BeforeEach
    void setUp() {
        montant = 200f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();

        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZATION);
        paiement.setHistoriques(paiementData.creerTransaEtats(AUTHORIZATION, montant, null, null, paiement.getId()));

        response = creerPaiementData.creerPaimtDigiRespSuccess(HttpStatus.OK, idTransaction, montant, HipayConstantes.CPL);

    }

    @AfterEach
    void tearDown() {
        orderId = null;
        idTransaction = null;
        paiement = null;
        response = null;
    }

    @Test
    void parameters_are_null_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(null, null));
    }

    @Test
    void creer_paiement_status_ok_with_cpl_code_sit_is_ok() {
        //GIVEN
        Paiement expected = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        expected.setHistoriques(paiementData.creerTransaEtats(AUTHORIZED, montant, null, null, expected.getId()));
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(AUTHORIZED, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> AUTHORIZED.equals(h.getEtat())).findAny();
        assertNull(historique.get().getStatus());
        assertNull(historique.get().getMessage());
    }

    @Test
    void creer_paiement_status_ok_with_ann_code_sit_is_ok() {
        //GIVEN
        response = creerPaiementData.creerPaimtDigiRespSuccess(HttpStatus.OK, idTransaction, montant, HipayConstantes.ANN);
        DetTransaPaimtNumeriseResp detTransaPaimtNum = response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise();
        detTransaPaimtNum.setCodeTechSitTransaPaimtDigi("4000002");
        detTransaPaimtNum.setLibSitTransaPaimtDigi("Declined");

        Paiement expected = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, FAIL);
        expected.setHistoriques(paiementData.creerTransaEtats(FAIL, montant, detTransaPaimtNum.getCodeTechSitTransaPaimtDigi(), detTransaPaimtNum.getLibSitTransaPaimtDigi(), expected.getId()));
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(FAIL, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> FAIL.equals(h.getEtat())).findAny();
        assertEquals(detTransaPaimtNum.getCodeTechSitTransaPaimtDigi(), historique.get().getStatus());
        assertEquals(detTransaPaimtNum.getLibSitTransaPaimtDigi(), historique.get().getMessage());
    }

    @Test
    void creer_paiement_status_ok_with_unknown_code_sit_throws_exception() {
        //GIVEN
        response = creerPaiementData.creerPaimtDigiRespSuccess(HttpStatus.OK, idTransaction, montant, "UNKNOWN_CODESIT");

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }

    @Test
    void creer_paiement_status_4xx_pfs_func_error() {
        //GIVEN
        String message = "The Http Server replied with a 4XX status code";
        String funcErrorMsg = "[A1532] Erreur renvoyee par le Service Applicatif:  :The Http Server replied with a 4XX status code";

        Paiement expected = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        expected.setHistoriques(paiementData.creerTransaEtats(ERROR, montant, A1532_FUNC_CALL_SA, message, expected.getId()));
        expected.setIdTransaction(null);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        response = creerPaiementData.creerPaimtDigiRespError(HttpStatus.BAD_REQUEST, A1532_FUNC_CALL_SA, funcErrorMsg);

        AbstractMap.SimpleEntry<String, String> entry = new AbstractMap.SimpleEntry<>(A1532_FUNC_CALL_SA, message);
        when(pfsFacade.creerTransaHeaderResp(any(PfsResponse.class))).thenReturn(entry);

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertNull(actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).findAny();
        assertEquals(A1532_FUNC_CALL_SA, historique.get().getStatus());
        assertEquals(message, historique.get().getMessage());
    }

    @Test
    void creer_paiement_status_4xx_hipay_func_error() {
        //GIVEN
        String funcErrorMsg = "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found";
        response = creerPaiementData.creerPaimtDigiRespError(HttpStatus.BAD_REQUEST, A1532_FUNC_CALL_SA, funcErrorMsg);

        String code = "3000002";
        String message = "Transaction not found";
        AbstractMap.SimpleEntry<String, String> entry = new AbstractMap.SimpleEntry<>(code, message);
        when(pfsFacade.creerTransaHeaderResp(any(PfsResponse.class))).thenReturn(entry);

        Paiement expected = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        expected.setHistoriques(paiementData.creerTransaEtats(ERROR, montant, code, message, expected.getId()));
        expected.setIdTransaction(null);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertNull(actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).findAny();
        assertEquals(code, historique.get().getStatus());
        assertEquals(message, historique.get().getMessage());
    }

    @Test
    void creer_paiement_status_5xx_pfs_func_error() {
        //GIVEN
        String message = "error generated by Generate Error - Job-35531";
        response = creerPaiementData.creerPaimtDigiRespError(HttpStatus.INTERNAL_SERVER_ERROR, A1532_TECH_DEFAULT, message);

        AbstractMap.SimpleEntry<String, String> entry = new AbstractMap.SimpleEntry<>(A1532_TECH_DEFAULT, message);
        when(pfsFacade.modifTransaHeaderResp(any(PfsResponse.class))).thenReturn(entry);

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }

    @Test
    void unknown_id_paiement_throws_exception() {
        //GIVEN
        when(paiementFacade.update(any(Paiement.class))).thenThrow(PaiementException.class);

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }
}