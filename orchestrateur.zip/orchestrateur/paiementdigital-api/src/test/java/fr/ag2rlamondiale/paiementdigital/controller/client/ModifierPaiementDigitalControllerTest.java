package fr.ag2rlamondiale.paiementdigital.controller.client;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_INVALID_AUTH;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
class ModifierPaiementDigitalControllerTest {

    @InjectMocks
    private ModifierPaiementDigitalController controller;

    @Mock
    private RestTemplate restTemplate;

    @Autowired
    private ApiModifierPaiementTestData data;

    private ModifPaimtRootReq request;

    @BeforeEach
    void setUp() {
        request = data.buildRequest();
    }

    @AfterEach
    void tearDown() {
        request = null;
    }

    @Test
    void modifier_paiement_digital_gives_status_401() {
        //GIVEN
        String uri = "http://uri_without_params";
        ModifPaimtRootResp response = data.buildResponseFuncError(A1532_FUNC_INVALID_AUTH, "[A1532] L'application appelante ne dispose pas des droits d'acces. Veuillez contacter le DIS PFS.");
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uri, request);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED, actual.getStatusCode());
        assertEquals(expected, actual);
    }

    @Test
    void modifier_paiement_digital_gives_status_400() {
        //GIVEN
        String uri = "http://uri_with_params";
        ModifPaimtRootResp response = data.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :The Http Server replied with a 4XX status code");
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uri, request);

        //THEN
        assertEquals(HttpStatus.BAD_REQUEST, actual.getStatusCode());
        assertEquals(expected, actual);
    }

    @Test
    void modifier_paiement_digital_gives_status_200() {
        //GIVEN
        String uri = "http://uri_without_params";
        ModifPaimtRootResp response = data.buildResponseStatus200();
        ResponseEntity<Object> expected = new ResponseEntity<>(response, HttpStatus.OK);

        when(restTemplate.postForEntity(anyString(), any(), any())).thenReturn(expected);

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uri, request);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(expected, actual);
    }

    @Test
    void null_request_gives_internal_error() {
        //GIVEN
        String uri = "http://uri_with_params";

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uri, null);

        //THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.name(), actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorCode());
        assertEquals(INVALID_PARAMETER, actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorMessage());
        assertNull(actual.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc());

    }

    @Test
    void null_uri_gives_internal_error() {
        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(null, request);

        //THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.name(), actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorCode());
        assertEquals(INVALID_PARAMETER, actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorMessage());
        assertNull(actual.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc());

    }

}