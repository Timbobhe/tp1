package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ResponseCalculFacadeImplTest {

    @InjectMocks
    private ResponseCalculFacadeImpl calculFacade;

    private RecupParamPlfdFreqResp ppf1;

    private Set<RecupParamPlfdFreqResp> plafonds1;

    private Set<RecupParamPeriMethPaimtResp> methodes;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        ppf1 = parametrageLabData.getPpf1d1();
        plafonds1 = parametrageLabData.getPlafonds1();
        methodes = parametrageLabData.getMethodes();
    }

    @AfterEach
    void tearDown() {
        plafonds1 = null;
        ppf1 = null;
        methodes = null;
    }

    @Test
    void max_des_montants_dispo_gives_1000() {
        //WHEN
        float actual = calculFacade.maxDesMontantsDispo(methodes);

        //THEN
        assertEquals(1000, actual, "Le maximum doit être 1000.");
    }

    @Test
    void methode_max_des_montants_dispo_contains_visa_mastercard() {
        //WHEN
        String actual = calculFacade.methodeMaxDesMontantsDispo(methodes, 1000);

        //THEN
        assertTrue(actual.contains(MethodePaiementEnum.MASTERCARD.name()), "Le resultat doit contenir la carte MASTERCARD.");
        assertTrue(actual.contains(MethodePaiementEnum.VISA.name()), "Le resultat doit contenir la carte VISA.");
        assertFalse(actual.contains(MethodePaiementEnum.CB.name()), "Le resultat ne doit pas contenir la carte CB.");
    }

    @Test
    void max_des_nombres_de_paiement_dispo_gives_6() {
        //WHEN
        int actual = calculFacade.maxDesNombresDePaiementDispo(methodes);

        //THEN
        assertEquals(6, actual, "Le maximum doit être 6.");
    }

    @Test
    void methode_max_des_nombres_de_paiement_dispo_contains_mastercard() {
        //WHEN
        String actual = calculFacade.methodeMaxDesNombresDePaiementDispo(methodes, 6);

        //THEN
        assertTrue(actual.contains(MethodePaiementEnum.MASTERCARD.name()), "Le resultat doit contenir la carte MASTERCARD.");
        assertFalse(actual.contains(MethodePaiementEnum.VISA.name()), "Le resultat ne doit pas contenir la carte VISA.");
        assertFalse(actual.contains(MethodePaiementEnum.CB.name()), "Le resultat ne doit pas contenir la carte CB.");
    }

    @Test
    void min_montant_dispo_client_gives_300() {
        //WHEN
        float actual = calculFacade.minMontantDispoClient(plafonds1);

        //THEN
        assertEquals(300, actual, "Le minimum des montants pour plafonds1 doit être 300.");
    }

    @Test
    void frequence_min_montant_dispo_client_gives_mois_glissant() {
        //WHEN
        String actual = calculFacade.frequenceMinMontantDispoClient(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual, "Le minimum des frequences pour plafonds1 doit être MOIS_GLISSANT.");
    }

    @RepeatedTest(3)
    void frequence_min_montant_dispo_client_doublon_gives_mois_glissant() {
        //GIVEN
        RecupParamPlfdFreqResp ppf2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(ppf1.getMontantMin())
                .montantMax(ppf1.getMontantMax())
                .nombreMax(ppf1.getNombreMax())
                .montantMaxdispoClient(ppf1.getMontantMaxdispoClient())
                .nombreMaxDispoClient(ppf1.getNombreMaxDispoClient())
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1, ppf2));

        //WHEN
        String actual = calculFacade.frequenceMinMontantDispoClient(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual, "Le resultat pour plafonds1 doit être MOIS_GLISSANT.");
    }

    @Test
    void min_nombre_paiement_disponible_gives_2() {
        //WHEN
        int actual = calculFacade.minNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(2, actual, "Le resultat pour plafonds1 doit être 2.");
    }

    @Test
    void frequence_nombre_paiement_disponible_gives_mois_glissant() {
        //WHEN
        String actual = calculFacade.frequenceNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual, "Le resultat pour plafonds1 doit être MOIS_GLISSANT.");
    }

    @RepeatedTest(3)
    void frequence_nombre_paiement_disponible_doublon_gives_mois_glissant() {
        //GIVEN
        RecupParamPlfdFreqResp ppf2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(ppf1.getMontantMin())
                .montantMax(ppf1.getMontantMax())
                .nombreMax(ppf1.getNombreMax())
                .montantMaxdispoClient(ppf1.getMontantMaxdispoClient())
                .nombreMaxDispoClient(ppf1.getNombreMaxDispoClient())
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1, ppf2));

        //WHEN
        String actual = calculFacade.frequenceNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual, "Le resultat pour plafonds1 doit être MOIS_GLISSANT.");
    }

    @Test
    void montant_max_dispo_client_gives_40() {
        //GIVEN
        List<Float> montantsCaptured = Arrays.asList(10F, 20F, 30F);

        //WHEN
        float actual = calculFacade.montantMaxDispoClient(100, montantsCaptured);

        //THEN
        assertEquals(40, actual, "Le resultat doit donner 40.");
    }

    @Test
    void montant_max_dispo_client_gives_100() {
        //WHEN
        float actual = calculFacade.montantMaxDispoClient(100, null);

        //THEN
        assertEquals(100, actual, "Le resultat doit donner 100.");
    }

    @Test
    void nombre_max_dispo_client_gives_7() {
        //GIVEN
        List<Float> montantsCaptured = Arrays.asList(10F, 20F, 30F);

        //WHEN
        int actual = calculFacade.nombreMaxDispoClient(10, montantsCaptured);

        //THEN
        assertEquals(7, actual, "Le resultat doit donner 7.");
    }

    @Test
    void nombre_max_dispo_client_gives_20() {
        //WHEN
        float actual = calculFacade.montantMaxDispoClient(20, null);

        //THEN
        assertEquals(20, actual, "Le resultat doit donner 20.");
    }

}