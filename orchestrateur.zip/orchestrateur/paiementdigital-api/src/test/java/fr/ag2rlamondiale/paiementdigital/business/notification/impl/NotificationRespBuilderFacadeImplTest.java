package fr.ag2rlamondiale.paiementdigital.business.notification.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.domain.CustomData;
import fr.ag2rlamondiale.paiementdigital.domain.DonneeMetier;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.DetailTransactionPaiementNumeriseReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.EntetePaiementNumeriseReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.DetailTransactionPaiementNumeriseResp;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.EntetePaiementNumeriseResp;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.NotificationException;
import fr.ag2rlamondiale.paiementdigital.mapper.notification.INotificationMapper;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class NotificationRespBuilderFacadeImplTest {

       @InjectMocks
       private NotificationRespBuilderFacadeImpl facade;

       @Mock
       private INotificationMapper mapper;

       @Mock
       private IPaiementFacade paiementFacade;

       @Autowired
       private ApiPaiementTestData paiementData;

       @Autowired
       private NotificationRespBuilderFacadeImpl notificationRespBuilderFacadeImpl;

       private Paiement paiement;

       private String idTransaction;

       private float montant;

       private String orderId;

       private Set<CustomData> customDatas;

       private Set<DonneeMetier> donneeMetier;

       private NotificationRootReq notificationAuthorizeRootReq;

       private NotificationRootReq notificationCaptureRootReq;

       private NotificationRootReq notificationCplFailRootReq;

       private NotificationRootReq notificationFailRootReq;

       private NotificationRootReq notificationPendingRootReq;

       private NotificationRootReq notificationSttErrorRootReq;

       private NotificationRootReq notificationCodeSituationErrorRootReq;

       private String notificationAuthorizeRequestFilename = "json/send-notification-authorize-req-test.json";

       private String notificationCaptureRequestFilename = "json/send-notification-capure-req-test.json";

       private String notificationCplFailRequestFilename = "json/send-notification-cpl-fail-req-test.json";

       private String notificationFailRequestFilename = "json/send-notification-ann-req-test.json";

       private String notificationPendingRequestFilename = "json/send-notification-pending-req-test.json";

       private String notificationSttErrorRequestFilename = "json/send-notification-stt-error-req-test.json";

       private String notificationCodeSituationErrorRequestFilename = "json/send-notification-code-situation-error-req-test.json";

       @BeforeEach
       void setUp() {

           DonneeMetier d1 = DonneeMetier.builder().typeDonnee("typeDonnee").valeurDonnee("XXX").build();
           donneeMetier = new HashSet<>(Collections.singletonList(d1));

           CustomData c1 = CustomData.builder().ordre(1).cdata("ARI").build();
           CustomData c2 = CustomData.builder().ordre(2).cdata("RG01002ARI").build();
           CustomData c3 = CustomData.builder().ordre(3).cdata("1311014").build();
           CustomData c4 = CustomData.builder().ordre(4).cdata("A0499").build();
           CustomData c5 = CustomData.builder().ordre(5).cdata("P5049181").build();
           customDatas = new HashSet<>(Arrays.asList(c1, c2, c3, c4, c5));

           montant = 8.99f;
           idTransaction = ApiPaiementITData.idTransaction();
           orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());

           notificationAuthorizeRootReq = JsonUtils.notificationRequest(notificationAuthorizeRequestFilename);
           notificationCaptureRootReq = JsonUtils.notificationRequest(notificationCaptureRequestFilename);
           notificationCplFailRootReq = JsonUtils.notificationRequest(notificationCplFailRequestFilename);
           notificationFailRootReq = JsonUtils.notificationRequest(notificationFailRequestFilename);
           notificationPendingRootReq = JsonUtils.notificationRequest(notificationPendingRequestFilename);
           notificationSttErrorRootReq = JsonUtils.notificationRequest(notificationSttErrorRequestFilename);
           notificationCodeSituationErrorRootReq = JsonUtils.notificationRequest(notificationCodeSituationErrorRequestFilename);
       }

       @AfterEach
       void tearDown() {
           idTransaction = null;
           orderId = null;
           paiement = null;
           customDatas = null;
           notificationAuthorizeRootReq = null;
           notificationAuthorizeRequestFilename = null;
           notificationCaptureRootReq = null;
           notificationCaptureRequestFilename = null;
           notificationCplFailRootReq = null;
           notificationCplFailRequestFilename = null;
           notificationFailRootReq = null;
           notificationFailRequestFilename = null;
           notificationPendingRootReq = null;
           notificationPendingRequestFilename = null;
           notificationSttErrorRootReq = null;
           notificationSttErrorRequestFilename = null;
           notificationCodeSituationErrorRootReq = null;
           notificationCodeSituationErrorRequestFilename = null;
       }

       @Test
       void invalid_parameters_throws_exception() {
           //WHEN THEN
           assertThrows(NotificationException.class, () -> facade.build(null));
       }

        @Test
        void build_response_for_sa_notification_authorize() {
            //GIVEN
            paiement = buildPaiement(EtatEnum.AUTHORIZED,"116","Authorized");

            EntetePaiementNumeriseResp entetePaiementNumeriseResp = EntetePaiementNumeriseResp.builder()
                    .identifiantDemandePaiement("0cb8f51d08cd480586c617e917efaa96")
                    .build();

            DetailTransactionPaiementNumeriseResp detailTransactionPaiementNumeriseResp = buildDetailTransactionPaiementNumeriseResp("800114851277","CPL","Authorized");

            when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
            when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);
            when(mapper.toEntetePaimtNumerise(any(EntetePaiementNumeriseReq.class))).thenReturn(entetePaiementNumeriseResp);
            when(mapper.toDetTransaPaimtNum(any(DetailTransactionPaiementNumeriseReq.class))).thenReturn(detailTransactionPaiementNumeriseResp);

            //WHEN
            NotificationRootResp actual = facade.build(notificationAuthorizeRootReq);

            //THEN
            assertEquals("116", actual.getNotificationResp().getPaimentDigiResp().getStatut());
            assertEquals("Authorized", actual.getNotificationResp().getPaimentDigiResp().getMessage());
            assertEquals("A1324", actual.getNotificationResp().getPaimentDigiResp().getDestinataire());
            assertEquals("00001338125", actual.getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
            assertEquals("0cb8f51d08cd480586c617e917efaa96", actual.getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
            assertEquals("800114851277", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
            assertEquals("CPL", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
            assertEquals("Authorized", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
            assertEquals("typeDonnee", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee());
            assertEquals("XXX", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee());
        }

        @Test
        void build_response_for_sa_notification_captured() {
            //GIVEN
            paiement = buildPaiement(EtatEnum.CAPTURED,"118","Captured");

            EntetePaiementNumeriseResp entetePaiementNumeriseResp = EntetePaiementNumeriseResp.builder()
                    .identifiantDemandePaiement("0cb8f51d08cd480586c617e917efaa96")
                    .build();

            DetailTransactionPaiementNumeriseResp detailTransactionPaiementNumeriseResp = buildDetailTransactionPaiementNumeriseResp("800114851277","CPL","Captured");

            when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
            when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);
            when(mapper.toEntetePaimtNumerise(any(EntetePaiementNumeriseReq.class))).thenReturn(entetePaiementNumeriseResp);
            when(mapper.toDetTransaPaimtNum(any(DetailTransactionPaiementNumeriseReq.class))).thenReturn(detailTransactionPaiementNumeriseResp);

            //WHEN
            NotificationRootResp actual = facade.build(notificationCaptureRootReq);

            //THEN
            assertEquals("118", actual.getNotificationResp().getPaimentDigiResp().getStatut());
            assertEquals("Captured", actual.getNotificationResp().getPaimentDigiResp().getMessage());
            assertEquals("A1324", actual.getNotificationResp().getPaimentDigiResp().getDestinataire());
            assertEquals("00001338125", actual.getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
            assertEquals("0cb8f51d08cd480586c617e917efaa96", actual.getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
            assertEquals("800114851277", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
            assertEquals("CPL", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
            assertEquals("Captured", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
            assertEquals("typeDonnee", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee());
            assertEquals("XXX", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee());
       }

    @Test
    void build_response_for_sa_notification_cpl_Fail() {
        //GIVEN
        paiement = buildPaiement(EtatEnum.CAPTURED,"173","Fail");

        EntetePaiementNumeriseResp entetePaiementNumeriseResp = EntetePaiementNumeriseResp.builder()
                .identifiantDemandePaiement("0cb8f51d08cd480586c617e917efaa96")
                .build();

        DetailTransactionPaiementNumeriseResp detailTransactionPaiementNumeriseResp = buildDetailTransactionPaiementNumeriseResp("800114851277","CPL","Fail");

        when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);
        when(mapper.toEntetePaimtNumerise(any(EntetePaiementNumeriseReq.class))).thenReturn(entetePaiementNumeriseResp);
        when(mapper.toDetTransaPaimtNum(any(DetailTransactionPaiementNumeriseReq.class))).thenReturn(detailTransactionPaiementNumeriseResp);

        //WHEN
        NotificationRootResp actual = facade.build(notificationCplFailRootReq);

        //THEN
        assertEquals("173", actual.getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals("Fail", actual.getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals("A1324", actual.getNotificationResp().getPaimentDigiResp().getDestinataire());
        assertEquals("00001338125", actual.getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals("0cb8f51d08cd480586c617e917efaa96", actual.getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals("800114851277", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals("CPL", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals("Fail", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals("typeDonnee", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee());
        assertEquals("XXX", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee());
    }

    @Test
    void build_response_for_sa_notification_Fail() {
        //GIVEN
        paiement = buildPaiement(EtatEnum.CAPTURED,"173","Fail");

        EntetePaiementNumeriseResp entetePaiementNumeriseResp = EntetePaiementNumeriseResp.builder()
                .identifiantDemandePaiement("0cb8f51d08cd480586c617e917efaa96")
                .build();

        DetailTransactionPaiementNumeriseResp detailTransactionPaiementNumeriseResp = buildDetailTransactionPaiementNumeriseResp("800114851277","ANN","Fail");

        when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);
        when(mapper.toEntetePaimtNumerise(any(EntetePaiementNumeriseReq.class))).thenReturn(entetePaiementNumeriseResp);
        when(mapper.toDetTransaPaimtNum(any(DetailTransactionPaiementNumeriseReq.class))).thenReturn(detailTransactionPaiementNumeriseResp);

        //WHEN
        NotificationRootResp actual = facade.build(notificationFailRootReq);

        //THEN
        assertEquals("173", actual.getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals("Fail", actual.getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals("A1324", actual.getNotificationResp().getPaimentDigiResp().getDestinataire());
        assertEquals("00001338125", actual.getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals("0cb8f51d08cd480586c617e917efaa96", actual.getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals("800114851277", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals("ANN", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals("Fail", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals("typeDonnee", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee());
        assertEquals("XXX", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee());
    }

    @Test
    void build_response_for_sa_notification_Pending() {
        //GIVEN
        paiement = buildPaiement(EtatEnum.CAPTURED,"200","Pending");

        EntetePaiementNumeriseResp entetePaiementNumeriseResp = EntetePaiementNumeriseResp.builder()
                .identifiantDemandePaiement("0cb8f51d08cd480586c617e917efaa96")
                .build();

        DetailTransactionPaiementNumeriseResp detailTransactionPaiementNumeriseResp = buildDetailTransactionPaiementNumeriseResp("800114851277","ATT","Pending");

        when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);
        when(mapper.toEntetePaimtNumerise(any(EntetePaiementNumeriseReq.class))).thenReturn(entetePaiementNumeriseResp);
        when(mapper.toDetTransaPaimtNum(any(DetailTransactionPaiementNumeriseReq.class))).thenReturn(detailTransactionPaiementNumeriseResp);

        //WHEN
        NotificationRootResp actual = facade.build(notificationPendingRootReq);

        //THEN
        assertEquals("200", actual.getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals("Pending", actual.getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals("A1324", actual.getNotificationResp().getPaimentDigiResp().getDestinataire());
        assertEquals("00001338125", actual.getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals("0cb8f51d08cd480586c617e917efaa96", actual.getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals("800114851277", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals("ATT", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals("Pending", actual.getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals("typeDonnee", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee());
        assertEquals("XXX", actual.getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee());
    }

    @Test
    void build_response_for_sa_notification_Authorize_throws_valeur_stt_exception() {
        //GIVEN
        paiement = buildPaiement(EtatEnum.CAPTURED,"112","Authorized and Pending");

        when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);


        //WHEN THEN
        Throwable exception = assertThrows(NotificationException.class, () -> facade.build(notificationSttErrorRootReq));
        assertEquals("Cette valeur STT est non prévue.", exception.getMessage());

       }

    @Test
    void build_response_for_sa_notification_Authorize_throws_code_situation_non_gerer_exception() {
        //GIVEN
        paiement = buildPaiement(EtatEnum.CAPTURED,"116","Authorized");
        when(paiementFacade.findByOrderId(any(String.class))).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);

        //WHEN THEN
        Throwable exception = assertThrows(NotificationException.class, () -> facade.build(notificationCodeSituationErrorRootReq));
        assertEquals("le codeSituationTransactionPaiementDigital: CPP n'est pas géré.", exception.getMessage());

    }

       private DetailTransactionPaiementNumeriseResp buildDetailTransactionPaiementNumeriseResp(String referenceTransaction, String codeSituationTransaction, String libelleSituationTransaction) {
           return DetailTransactionPaiementNumeriseResp.builder()
                    .referenceTransactionPaiementDigital(referenceTransaction)
                    .codeSituationTransactionPaiementDigital(codeSituationTransaction)
                    .libelleSituationTransactionPaiementDigital(libelleSituationTransaction)
                    .build();
        }

        private Paiement buildPaiement(EtatEnum etat, String status, String message ) {
            paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                    idTransaction, 1, MASTERCARD, etat);
            paiement.setHistoriques(paiementData.creerTransaEtats(AUTHORIZED, montant, status, message, paiement.getId()));
            paiement.setCustomDatas(customDatas);
            paiement.setDonneeMetiers(donneeMetier);
            return  paiement;
        }


}