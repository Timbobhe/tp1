package fr.ag2rlamondiale.paiementdigital.bootstrap;

import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.exception.JwtSecurityException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import javax.xml.bind.DatatypeConverter;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;

@Slf4j
@Component
public class SecurityTestData {

    public static final String PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApOwxjC9nQTO8daIpJWKLoULvFDHww/CSajYAAULZPcj/4Co0K68VdTQ4i7U9bVDoitolV3ORLjw/P0+Qs2oPXbCFH8vj7YLw4neyF3S99UpPwlmfGf3wYuvyojfMn0nnRqZ1Hia7aI+k5/hc4feJJqCbonS1EtdetL6eVERwmoXW7NBMoeiggrWEFel4VJKBH1vyVgN5Ghgiy3DoTWvEC9lCGmRrfPSP9cTu7C7imttQ1i19WBBW61LkrK4ZOEaivyioea68X9LonWsLE4P44izBXSYjwj3Zay6XtL9s5QzABm2DvAWwEGpJ5noBoiEOM4DOGPrDm4LtsqsE0lPaCQIDAQAB";

    public static final String PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCk7DGML2dBM7x1oiklYouhQu8UMfDD8JJqNgABQtk9yP/gKjQrrxV1NDiLtT1tUOiK2iVXc5EuPD8/T5Czag9dsIUfy+PtgvDid7IXdL31Sk/CWZ8Z/fBi6/KiN8yfSedGpnUeJrtoj6Tn+Fzh94kmoJuidLUS1160vp5URHCahdbs0Eyh6KCCtYQV6XhUkoEfW/JWA3kaGCLLcOhNa8QL2UIaZGt89I/1xO7sLuKa21DWLX1YEFbrUuSsrhk4RqK/KKh5rrxf0uidawsTg/jiLMFdJiPCPdlrLpe0v2zlDMAGbYO8BbAQaknmegGiIQ4zgM4Y+sObgu2yqwTSU9oJAgMBAAECggEAIcdaspq27EzbacCH6udPL/1UmG9OH+OzKVvcDmYRtqznc5NRUi0vGO1UM5EwfqZWqrHZehrqfmzKi34RZh3v/cF80rFhArGSAuB/Mnyvt4C761ON2bYAOVKYRI9nMqzhWMAZNs66DcV2AikFZSbdCXNVzSVYPP6toBl2tk26PnudCLzNUmShzusSThvarQDO/tqDuHv4zmR/EXV2Go0SJHcXkDkqlIYUOHfxBPbeahKYw1nxxAR3vpcAaFnQsDI75DT5UwuIy6aLkCEFh+GqpvJrg3jkpbF86cSFKQAt5OY1FI4t30pjpgpaQRS5Bp3rnKgfxKtJLJx7eeoN9WzoMQKBgQDOkIfNk1De0n2D8pibDnCGPDJ70twoOjvuL7cIOf3PXXmZdINylF6krnrYCkIGLOGulxqDZKgL3u2UC8nOXaua3hI8lZi5l+FfXSdrNLjaKc/NymcpazezPnCTExlJQB8o5EuSb7aiNdCS+oV3jUQ2gRM7WRpIqNOttaXfUJXdVQKBgQDMZGkvJIaz3rLp5Zi/9qHpzjYie3RXVTPtPiGE/TBDuSnu4hfr9vjjH9iQqErlhyZNjL1mM+dQxNMI5Jeaq0B+3ARelBoOnv1uzgNluO6o2FhTys8mAMdt/nwqLHwbbD6z76nvXOVvm4LXhq9JsFYnT30lkVc+NNnaxF3tiolp5QKBgQC3K9zxBBhrbtZUolSG8xf/QPQ3bzVBCtrIDVHOHraeIrLIzFQfz8fZWsueNgJ0PWpnCqE9MI3/8NBWPtnWgKPCsfgT90g2E6OLkCx7WYYuF3Opdjlitivva4giM4ZxuUWoWkFVenDGiNgK7dJawE9j0bO/JfUzx1nmKTUMwQYT/QKBgBaBN9OpAevsKWb3kMoSLeHAgtVpInY7O2xz2tz5w8axLJzQ6DFjECRx7TaAUT7UkrMXPAN005NhGJtyD/9Hu+I7938yb2wMtXrt1BHvOtf8ej0/p29Xxp2l16YNH90lHgJR8TQZ1mljhhSVD9fdQp8xcWYhiqmeyB3+YRk2l8rBAoGBAKzHPcqcDO3dM1JQazEF0cMezC7I3ryxwAGKisp7jz7WblFwVQUZ6ZiUhUbZm+Yuu+r1iKUhpbOlOIigJj367SK649exXw+ixRxQ4X/pyxGRQBjaXAXzLDmMzwAat66VIMEf6t8wkewhXdkFXzeVXeU5r7w2uLbADErQlKGwB016";

    public static final long VALIDITY_MILLSEC = 3600000;

    public static final String JWT_SUBJECT = "i124PAR3456";

    public static HttpHeaders getHttpAuthHeaders() {
        String token = createToken(PRIVATE_KEY, VALIDITY_MILLSEC);
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.add(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token);
        return httpHeaders;
    }

    public static String createToken(String secretKey, long validityInMilliseconds) {
        log.debug("Création du TOKEN JWT");
        Date now = new Date();
        Date validity = new Date(now.getTime() + validityInMilliseconds);

        PrivateKey privateKey = null;
        try {
            String privateKeyContent = secretKey
                    .replaceAll("\\n", "")
                    .replace(SecurityConstantes.PRIVATE_KEY_PREFIX, "")
                    .replace(SecurityConstantes.PRIVATE_KEY_SUFFIX, "");

            KeyFactory kf = KeyFactory.getInstance(SecurityConstantes.RSA);

            PKCS8EncodedKeySpec keySpecPKCS8 =
                    new PKCS8EncodedKeySpec(DatatypeConverter.parseBase64Binary(privateKeyContent));

            privateKey = kf.generatePrivate(keySpecPKCS8);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new JwtSecurityException("Erreur lors de la création du token " + e.getMessage());
        }

        Claims claims = Jwts
                .claims()
                .setSubject(JWT_SUBJECT)
                .setAudience(PfsParametersConstantes.CODE_APPLI_BO_PMT_DIGI)
                .setIssuer(PfsParametersConstantes.CODE_APPLI_PFS)
                .setExpiration(validity)
                .setIssuedAt(now);

        return Jwts.builder()
                .setClaims(claims)
                .setIssuedAt(now)
                .setExpiration(validity)
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact();
    }
}
