package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierTransactionTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.controller.client.ModifierPaiementDigitalController;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.STT_CODE_CAPTURED_OK;
import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.STT_CODE_CAPTURE_FAIL;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.CAPTURE;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.ERROR;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ModifierTransactionControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IEtatPaiementFacade facade;

    @MockBean
    private IModifPaimtDigiReqBuilderFacade builder;

    @MockBean
    private PfsPropertyConfig config;

    @MockBean
    private IGestionTokenFacade gestionTokenFacade;

    @MockBean
    private ModifierPaiementDigitalController controller;

    @MockBean
    private IModifTransaRespBuilderFacade modifTransaFacade;

    @Autowired
    private ApiPaiementTestData transaData;

    @Autowired
    private ApiModifierPaiementTestData modifPaimtData;

    @Autowired
    private ApiModifierTransactionTestData modiftransaData;

    @Autowired
    private SecurityTestData security;

    private String uri = "/api/transaction/update";

    private Paiement paiement;

    private float montant;

    private String orderId;

    private String idTransaction;

    private String pfsUri;

    private String token;

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CAPTURE);
        paiement.setHistoriques(transaData.modifTransaEtats(CAPTURE, montant, null, null, paiement.getId()));
        pfsUri = "http://pfs";
        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        paiement = null;
        orderId = null;
        idTransaction = null;
        pfsUri = null;
        token = null;
    }

    @Test
    void modifier_transaction_gives_status_captured_when_given_id_transaction() throws Exception {
        //GIVEN
        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200();
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);
        ModifTransaRootResp modifTransaResponse = modiftransaData.buildCapturedResponse(orderId, idTransaction, montant);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenReturn(modifTransaResponse);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.etatCourant").isEmpty())
                .andExpect(jsonPath("$.codeErreur").isEmpty())
                .andExpect(jsonPath("$.messageErreur").isEmpty())
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.idTransaction")
                        .value(idTransaction))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.orderId")
                        .value(orderId))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.etatCourant")
                        .value(EtatEnum.CAPTURED.name()))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.status")
                        .value(STT_CODE_CAPTURED_OK))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.message")
                        .value(HipayConstantes.CAPTURED));
    }

    @Test
    void modifier_transaction_gives_status_captured_when_not_given_id_transaction() throws Exception {
        //GIVEN
        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200();
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant);
        ModifTransaRootResp modifTransaResponse = modiftransaData.buildCapturedResponse(orderId, idTransaction, montant);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenReturn(modifTransaResponse);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.etatCourant").isEmpty())
                .andExpect(jsonPath("$.codeErreur").isEmpty())
                .andExpect(jsonPath("$.messageErreur").isEmpty())
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.idTransaction")
                        .value(idTransaction))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.orderId")
                        .value(orderId))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.etatCourant")
                        .value(EtatEnum.CAPTURED.name()))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.status")
                        .value(STT_CODE_CAPTURED_OK))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.message")
                        .value(HipayConstantes.CAPTURED));
    }

    @Test
    void modifier_transaction_gives_status_fail() throws Exception {
        //GIVEN
        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200Fail();
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);
        ModifTransaRootResp modifTransaResponse = modiftransaData.buildFailResponse(orderId, idTransaction, montant);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenReturn(modifTransaResponse);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.etatCourant").isEmpty())
                .andExpect(jsonPath("$.codeErreur").isEmpty())
                .andExpect(jsonPath("$.messageErreur").isEmpty())
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.idTransaction")
                        .value(idTransaction))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.DetailTransactionPaiementNumerise.orderId")
                        .value(orderId))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.etatCourant")
                        .value(EtatEnum.FAIL.name()))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.status")
                        .value(STT_CODE_CAPTURE_FAIL))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital.message")
                        .value(HipayConstantes.STT_MSG_CAPTURE_REFUSED));
    }

    @Test
    void modifier_transaction_gives_status_pfs_func_error() throws Exception {
        //GIVEN
        String code = "3000002";
        String message = "Transaction not found";

        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");
        ;
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.BAD_REQUEST);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);
        ModifTransaRootResp modifTransaResponse = modiftransaData.buildFuncErrorResponse(code, message);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenReturn(modifTransaResponse);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.etatCourant").value(EtatEnum.ERROR.name()))
                .andExpect(jsonPath("$.codeErreur").value(code))
                .andExpect(jsonPath("$.messageErreur").value(message))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital").isEmpty());
    }

    @Test
    void modifier_transaction_gives_status_pfs_tech_error() throws Exception {
        //GIVEN
        String code = "A1532-TECH-DEFAULT";
        String message = "error generated by Generate Error - Job-35531";

        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(code, message);
        ;
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);
        ModifTransaRootResp modifTransaResponse = modiftransaData.buildFuncErrorResponse(code, message);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenReturn(modifTransaResponse);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.etatCourant").value(EtatEnum.ERROR.name()))
                .andExpect(jsonPath("$.codeErreur").value(code))
                .andExpect(jsonPath("$.messageErreur").value(message))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital").isEmpty());
    }

    @Test
    void modifier_transaction_gives_status_paiement_error() throws Exception {
        //GIVEN
        String code = String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value());
        String message = INVALID_PARAMETER;

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);

        when(facade.capture(any(ModifTransaRootReq.class))).thenThrow(new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, message));

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.etatCourant").value(EtatEnum.ERROR.name()))
                .andExpect(jsonPath("$.codeErreur").value(code))
                .andExpect(jsonPath("$.messageErreur").value(message))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital").isEmpty());
    }

    @Test
    void modifier_transaction_gives_status_bo_error() throws Exception {
        //GIVEN
        String code = String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value());
        String message = INVALID_PARAMETER;

        ModifPaimtRootReq modifPaimtRequest = modifPaimtData.buildRequest();
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(code, message);
        ;
        ResponseEntity<ModifPaimtRootResp> modifPaimtResponse = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);

        ModifTransaRootReq modifTransaRequest = modiftransaData.buildRequest(orderId, montant, idTransaction);

        when(facade.capture(any(ModifTransaRootReq.class))).thenReturn(paiement);
        when(config.getModifierPaiementUrl()).thenReturn(pfsUri);
        when(gestionTokenFacade.getUriWithParams(anyString(), anyString(), anyString())).thenReturn(pfsUri);
        when(builder.build(any(ModifTransaRootReq.class))).thenReturn(modifPaimtRequest);
        when(controller.modifierPaiementDigital(anyString(), any(ModifPaimtRootReq.class))).thenReturn(modifPaimtResponse);
        when(modifTransaFacade.build(any(), any(Paiement.class))).thenThrow(new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, message));

        paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        paiement.setHistoriques(transaData.modifTransaEtats(ERROR, montant, code, message, paiement.getId()));
        when(facade.error(any(Paiement.class), anyString(), anyString())).thenReturn(paiement);

        //WHEN THEN
        mvc.perform(
                put(uri)
                        .content(JsonUtils.asJsonString(modifTransaRequest))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().is5xxServerError())
                .andExpect(jsonPath("$.etatCourant").value(EtatEnum.ERROR.name()))
                .andExpect(jsonPath("$.codeErreur").value(code))
                .andExpect(jsonPath("$.messageErreur").value(message))
                .andExpect(jsonPath("$.ModificationTransactionPaiementDigital").isEmpty());
    }
}