package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CustomDataReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.DetailPerimetreMetierReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetPdtReq;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


@SpringBootTest
class DetailProduitFacadeImplTest {

    @InjectMocks
    private DetailProduitFacadeImpl detailProduitFacade;

    private CreerTransaPaimtDigiRootReq creerTransacPaimtDigiRequestDto;

    private DetailPerimetreMetierReq detailPerimetreMetier;

    @BeforeEach
    void setUp() {
        detailPerimetreMetier = DetailPerimetreMetierReq.builder().codeApplication(PfsParametersConstantes.CODES_APPLI_RETRAITE_SUP).build();
        CustomDataReq customData = CustomDataReq.builder().cdata("idSiloTBD").ordre(2).build();
        creerTransacPaimtDigiRequestDto = CreerTransaPaimtDigiRootReq.builder()
                .detailPerimetreMetier(detailPerimetreMetier)
                .customDatas(new HashSet<>(Arrays.asList(customData))).build();
    }

    @AfterEach
    void tearDown() {
        detailPerimetreMetier = null;
        creerTransacPaimtDigiRequestDto = null;
    }

    @Test
    void detail_produit_is_mapped_from_transa_request() {
        //GIVEN
        //WHEN
        DetPdtReq result = detailProduitFacade.detailProduit(creerTransacPaimtDigiRequestDto);
        //THEN
        assertEquals("idSiloTBD", result.getInfoCtr().getIdSilo());
        assertEquals(PfsParametersConstantes.CODE_APPLI_PTV, result.getInfoCtr().getCodeAppli());
    }

    @Test
    void detail_perimetre_metier_is_null() {
        //GIVEN
        creerTransacPaimtDigiRequestDto.setDetailPerimetreMetier(null);
        DetPdtReq result = detailProduitFacade.detailProduit(creerTransacPaimtDigiRequestDto);
        //THEN
        assertNull(result.getInfoCtr());
    }
}