package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasSize;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@AutoConfigureTestDatabase
class ParametrageControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IResponseRecupParamLABFacade paramLabProcessFacade;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    @Autowired
    private SecurityTestData security;

    private RecupParamRootReq pfsDto;

    private RecupParamRootResp recupParamLab;

    private String uri = "/api/parametrage/get";

    private String token;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();
        pfsDto = parametrageLabData.getRequest();
        recupParamLab = parametrageLabData.getResponse();
        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        recupParamLab = null;
        token = null;
    }

    @Test
    void finding_aca_profil_gives_status_200() throws Exception {
        //GIVEN
        given(paramLabProcessFacade.recupererParametragesLab(any(RecupParamRootReq.class))).willReturn(recupParamLab);

        //WHEN THEN
        mvc.perform(
                post(uri)
                        .content(JsonUtils.asJsonString(pfsDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.message").isNotEmpty())
                .andExpect(jsonPath("$.parametresProfilsDto.maxDesMontantsDispo")
                        .value("1000.0"))
                .andExpect(jsonPath("$.parametresProfilsDto.maxDesNombresDePaiementDispo")
                        .value("6"))
                .andExpect(jsonPath("$.exclusions", hasSize(2)))
                .andExpect(jsonPath("$.inclusions", hasSize(2)));

    }

    @Test
    void without_inclusions_and_exclusion_finding_aca_profil_gives_status_200() throws Exception {
        //GIVEN
        pfsDto.setInclusionPays(false);
        pfsDto.setExclusionBanques(false);
        recupParamLab.setInclusions(null);
        recupParamLab.setExclusions(null);
        given(paramLabProcessFacade.recupererParametragesLab(any(RecupParamRootReq.class))).willReturn(recupParamLab);

        //WHEN THEN
        mvc.perform(
                post(uri)
                        .content(JsonUtils.asJsonString(pfsDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value(200))
                .andExpect(jsonPath("$.message").isNotEmpty())
                .andExpect(jsonPath("$.parametresProfilsDto.maxDesMontantsDispo")
                        .value("1000.0"))
                .andExpect(jsonPath("$.parametresProfilsDto.maxDesNombresDePaiementDispo")
                        .value("6"))
                .andExpect(jsonPath("$.exclusions", equalTo(null)))
                .andExpect(jsonPath("$.inclusions", equalTo(null)));
    }

    @Test
    void unknow_code_application_request_throws_exception() throws Exception {
        //GIVEN
        given(paramLabProcessFacade.recupererParametragesLab(any(RecupParamRootReq.class))).willThrow(NotFoundParameterValueException.class);

        //WHEN THEN
        mvc.perform(
                post(uri)
                        .content(JsonUtils.asJsonString(pfsDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value(404));
    }

    @Test
    void pfs_request_has_incorrect_parameter_throws_exception() throws Exception {
        //GIVEN
        given(paramLabProcessFacade.recupererParametragesLab(any(RecupParamRootReq.class))).willThrow(IncorrectParameterValueException.class);

        //WHEN THEN
        mvc.perform(
                post(uri)
                        .content(JsonUtils.asJsonString(pfsDto))
                        .contentType(MediaType.APPLICATION_JSON)
                        .accept(MediaType.APPLICATION_JSON)
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value(400));
    }

}