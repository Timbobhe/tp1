package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class GestionTokenFacadeImplTest {

    @InjectMocks
    private GestionTokenFacadeImpl gestionTokenFacade;

    @Mock
    private PfsPropertyConfig pfsPropertyConfig;

    @Test
    void token_uri_is_lmo_when_filiale_is_lmo() {
        //GIVEN
        String uri = "http://www.ag2r.com/";
        String structureJuridique = "LM";
        String filiale = "LMO";
        String token = "XXXXX";

        when(pfsPropertyConfig.getCodeApplication()).thenReturn(PfsParametersConstantes.APPLICATION);
        when(pfsPropertyConfig.getUser()).thenReturn(PfsParametersConstantes.USER);
        when(pfsPropertyConfig.getTokenLMO()).thenReturn(token);

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri,structureJuridique, filiale);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void token_uri_is_ari_when_filiale_is_ari() {
        //GIVEN
        String uri = "http://www.ag2r.com/";
        String structureJuridique = "ARI";
        String filiale = "ARI";
        String token = "YYYYY";

        when(pfsPropertyConfig.getCodeApplication()).thenReturn(PfsParametersConstantes.APPLICATION);
        when(pfsPropertyConfig.getUser()).thenReturn(PfsParametersConstantes.USER);
        when(pfsPropertyConfig.getTokenARI()).thenReturn(token);

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri, structureJuridique, filiale);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void token_uri_is_air_when_filiale_is_lmr() {
        //GIVEN
        String uri = "http://www.ag2r.com/";
        String structureJuridique = "ARI";
        String filiale = "LMR";
        String token = "YYYYY";

        when(pfsPropertyConfig.getCodeApplication()).thenReturn(PfsParametersConstantes.APPLICATION);
        when(pfsPropertyConfig.getUser()).thenReturn(PfsParametersConstantes.USER);
        when(pfsPropertyConfig.getTokenARI()).thenReturn(token);

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri, structureJuridique,  filiale);

        //THEN
        assertEquals(expected, actual);
    }

}