package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePlafonfsFrequencesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class ResponsePerimetresMethodesFacadeImplTest {

    @InjectMocks
    private ResponsePerimetresMethodesFacadeImpl parLabPerMethFacade;

    @Mock
    private IResponsePlafonfsFrequencesFacade parLabPlafFreqFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Mock
    private IResponseChildsFacade paramLabParts;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    private RecupParamRootReq pfsDto;

    private Perimetre perimetreAca;

    private Perimetre perimetreLmr;

    private Set<RecupParamPlfdFreqResp> plafonds1;

    private Set<RecupParamPlfdFreqResp> plafonds2;

    private Set<RecupParamPlfdFreqResp> plafonds3;

    private RecupParamPeriMethPaimtResp pmp1;

    private RecupParamPeriMethPaimtResp pmp2;

    private RecupParamPeriMethPaimtResp pmp3;

    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        pfsDto = parametrageLabData.getRequest();

        perimetreAca = parametrageLabData.getPerimetreAca();

        perimetreLmr = parametrageLabData.getPerimetreLmr();

        plafonds1 = parametrageLabData.getPlafonds1();

        plafonds2 = parametrageLabData.getPlafonds2();

        plafonds3 = parametrageLabData.getPlafonds3();

        pmp1 = parametrageLabData.getPmp1();

        pmp2 = parametrageLabData.getPmp2();

        pmp3 = parametrageLabData.getPmp3();

        methodes = parametrageLabData.getMethodes();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        perimetreAca = null;
        perimetreLmr = null;
        plafonds1 = null;
        plafonds2 = null;
        plafonds3 = null;
        pmp1 = null;
        pmp2 = null;
        pmp3 = null;
        methodes = null;
    }

    @Test
    void toutecarte_gives_set_of_methodes_cards() {
        //GIVEN
        when(parLabPlafFreqFacade
                .getPlafondsParFrequencesDtos(any(RecupParamRootReq.class),
                        anyList(),
                        any(PaiementDto.class)))
                .thenReturn(plafonds1)
                .thenReturn(plafonds2)
                .thenReturn(plafonds3);

        when(paramLabParts.perimetreMethodePaiement(anyString(), anySet()))
                .thenReturn(pmp1)
                .thenReturn(pmp2)
                .thenReturn(pmp3);

        doReturn(pmp1,pmp3, pmp2).when(paramLabParts).getFinalResult(anyString(), anySet());


        //WHEN
        Set<RecupParamPeriMethPaimtResp> actual = parLabPerMethFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetreAca);

        //THEN
        assertThat(actual).hasSameElementsAs(methodes);
        verify(parLabPlafFreqFacade, times(3)).getPlafondsParFrequencesDtos(any(RecupParamRootReq.class),
                anyList(), any(PaiementDto.class));
        verify(paramLabParts, times(3)).perimetreMethodePaiement(anyString(), anySet());

        verify(paramLabParts, times(3)).getFinalResult(anyString(), anySet());
    }

    @Test
    void mastercard_gives_set_of_methodes_cards() {
        //GIVEN
        methodes = new HashSet<>(Arrays.asList(pmp3));

        when(parLabPlafFreqFacade
                .getPlafondsParFrequencesDtos(any(RecupParamRootReq.class),
                        anyList(),
                        any(PaiementDto.class)))
                .thenReturn(plafonds3);

        when(paramLabParts.perimetreMethodePaiement(anyString(), anySet()))
                .thenReturn(pmp3);

        doReturn(pmp3).when(paramLabParts).getFinalResult(anyString(), anySet());

        //WHEN
        Set<RecupParamPeriMethPaimtResp> actual = parLabPerMethFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetreLmr);

        //THEN
        assertThat(actual).hasSameElementsAs(methodes);
        verify(parLabPlafFreqFacade, times(1)).getPlafondsParFrequencesDtos(any(RecupParamRootReq.class),
                anyList(), any(PaiementDto.class));
        verify(paramLabParts, times(1)).perimetreMethodePaiement(anyString(), anySet());

        verify(paramLabParts, times(1)).getFinalResult(anyString(), anySet());
    }

    @Test
    void empty_set_perimetre_methode_throws_parama_lab_exception() {
        //GIVEN
        perimetreLmr.setPerimetrePlafonds(Collections.emptySet());

        //WHEN THEN
        assertThrows(ParamLabException.class, () -> parLabPerMethFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetreLmr));
        verify(parLabPlafFreqFacade, times(0)).getPlafondsParFrequencesDtos(any(RecupParamRootReq.class),
                anyList(), any(PaiementDto.class));
        verify(paramLabParts, times(0)).perimetreMethodePaiement(anyString(), anySet());
    }
}