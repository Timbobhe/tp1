package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetrePlafond;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@SpringBootTest
class ResponsePlafonfsFrequencesFacadeImplTest {

    @InjectMocks
    private ResponsePlafonfsFrequencesFacadeImpl parLabPlafFreqFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Mock
    private IResponseChildsFacade paramLabParts;

    private RecupParamRootReq pfsDto;

    private Perimetre perimetreAca;

    private RecupParamPlfdFreqResp ppf3d1;

    private RecupParamPlfdFreqResp ppf3d2;

    private RecupParamPlfdFreqResp ppf3d3;

    private Set<RecupParamPlfdFreqResp> plafonds3;


    private PaiementDto paiementDto;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        pfsDto = parametrageLabData.getRequest();

        perimetreAca = parametrageLabData.getPerimetreAca();

        ppf3d1 = parametrageLabData.getPpf3d1();

        ppf3d2 = parametrageLabData.getPpf3d2();

        ppf3d3 = parametrageLabData.getPpf3d3();

        plafonds3 = parametrageLabData.getPlafonds3();

        paiementDto = parametrageLabData.getPaiementDto();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        perimetreAca = null;
        ppf3d1 = null;
        ppf3d2 = null;
        ppf3d3 = null;
        plafonds3 = null;
        paiementDto = null;
    }

    @Test
    void plafonds_par_frequence_found_for_mastercard() {
        //GIVEN
        List<Float> mnt1 = Arrays.asList(10F, 20F, 30F);
        List<Float> mnt2 = Arrays.asList(40F, 50F);

        List<Plafond> plafonds = Arrays.asList(
                Plafond.builder().typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE).montantMinimum(0F).montantMaximum(8000F).nombreMaximumPaiement(999).build(),
                Plafond.builder().typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT).montantMinimum(0F).montantMaximum(4000F).nombreMaximumPaiement(999).build(),
                Plafond.builder().typeFrequence(TypeFrequenceEnum.TRANSACTION).montantMinimum(0F).montantMaximum(4000F).nombreMaximumPaiement(999).build()
        );

        when(paiementFacade.getPaiementsAmountsByDate(any(PaiementDto.class), any(Date.class), any(Date.class)))
                .thenReturn(mnt1).thenReturn(mnt2);
        when(paramLabParts.plafondsParFrequences(any(Plafond.class), any()))
                .thenReturn(ppf3d1).thenReturn(ppf3d2).thenReturn(ppf3d3);

        //WHEN
        Set<RecupParamPlfdFreqResp> actual = parLabPlafFreqFacade.getPlafondsParFrequencesDtos(pfsDto, plafonds, paiementDto);

        //THEN
        assertThat(actual).hasSameElementsAs(plafonds3);
        verify(paiementFacade, times(2)).getPaiementsAmountsByDate(any(PaiementDto.class), any(Date.class), any(Date.class));
        verify(paramLabParts, times(3)).plafondsParFrequences(any(Plafond.class), any());
    }

    @Test
    void empty_set_plafonds_par_frequences_throws_parama_lab_exception() {
        //GIVEN
        PerimetrePlafond pp = perimetreAca.getPerimetrePlafonds().iterator().next();

        //WHEN THEN
        assertThrows(ParamLabException.class, () -> parLabPlafFreqFacade.getPlafondsParFrequencesDtos(pfsDto, Collections.emptyList(), paiementDto));
        verify(paiementFacade, times(0)).getPaiementsAmountsByDate(any(PaiementDto.class), any(Date.class), any(Date.class));
        verify(paramLabParts, times(0)).plafondsParFrequences(any(Plafond.class), anyList());
    }

}