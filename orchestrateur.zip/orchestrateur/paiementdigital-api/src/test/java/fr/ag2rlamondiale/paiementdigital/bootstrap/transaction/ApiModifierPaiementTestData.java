package fr.ag2rlamondiale.paiementdigital.bootstrap.transaction;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.*;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;

@Component
public class ApiModifierPaiementTestData {

    public ModifPaimtRootReq buildRequest() {
        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = ModifPaimtDetTransaPaimtNumReq.
                builder()
                .refTransaPaimtDigi("ID_TRANSCTION")
                .typeOpeTransaPaimtDigi("TYPE")
                .build();

        ModifPaimtDetMontantPaimtReq detMontantPaimt = ModifPaimtDetMontantPaimtReq.builder()
                .montantTTC(200)
                .codeDevVersm(DeviseEnum.EUR)
                .build();

        ModifPaimtInfoTechReq infoTech = ModifPaimtInfoTechReq.builder()
                .oriTransa("ORIGINE")
                .refOpePaimtDigi("REF")
                .refSsTransaPaimtDigi("REF")
                .build();

        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq
                .builder()
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detailMontantPaimt(detMontantPaimt)
                .infoTech(infoTech)
                .build();

        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);

        return new ModifPaimtRootReq(modifierPaimtDigi);
    }

    public ModifPaimtRootResp buildResponseFuncError(String errorCode, String errorMessage) {
        ModifPaimtDigiResp modifierPaimtDigiResp = new ModifPaimtDigiResp(null);

        ModifPaimtBodyResp bodyResp = new ModifPaimtBodyResp(modifierPaimtDigiResp);

        ModifPaimtErrorResp funcErrorResp = new ModifPaimtErrorResp(errorCode, errorMessage);

        ModifPaimtHeaderResp headerResp = new ModifPaimtHeaderResp(Arrays.asList(funcErrorResp), null);

        ModifPaimtResp resp = new ModifPaimtResp(headerResp, bodyResp);

        return new ModifPaimtRootResp(resp);
    }

    public ModifPaimtRootResp buildResponseTechError(String errorCode, String errorMessage) {
        ModifPaimtDigiResp modifierPaimtDigiResp = new ModifPaimtDigiResp(null);

        ModifPaimtBodyResp bodyResp = new ModifPaimtBodyResp(modifierPaimtDigiResp);

        ModifPaimtErrorResp funcErrorResp = new ModifPaimtErrorResp(errorCode, errorMessage);

        ModifPaimtHeaderResp headerResp = new ModifPaimtHeaderResp(Arrays.asList(funcErrorResp), null);

        ModifPaimtResp resp = new ModifPaimtResp(headerResp, bodyResp);

        return new ModifPaimtRootResp(resp);
    }

    public ModifPaimtRootResp buildResponseStatus200() {
        ModifPaimtDetTransaPaimtNumResp detTransaPaimtNumeriseResp = ModifPaimtDetTransaPaimtNumResp
                .builder()
                .refTransaPaimtDigi("800091071489")
                .typeOpeTransaPaimtDigi(OPE_TRANSA_CAPTURE)
                .numAutionTransaPaimtDigi("1111111")
                .instantCreatTransa(new Date())
                .instantAutionTransa(new Date())
                .mntAutionPaimtDigi(8.99f)
                .mntTrsfPaimtDigi(8.99f)
                .mntRembsmPaimtDigi(0.0f)
                .build();

        ModifPaimtDetMontantPaimtResp detMontantPaimtResp = new ModifPaimtDetMontantPaimtResp(DeviseEnum.EUR);

        ModifPaimtDigiBisResp paimtDigiResp = ModifPaimtDigiBisResp
                .builder()
                .detailMontantPaimt(detMontantPaimtResp)
                .detTransaPaimtNumerise(detTransaPaimtNumeriseResp)
                .stt(STT_CODE_CAPTURED_OK)
                .msg(CAPTURED)
                .idMarchand("00001338125")
                .build();

        ModifPaimtDigiFuncResp modifierPaimtDigiFuncResp = new ModifPaimtDigiFuncResp(paimtDigiResp);

        ModifPaimtDigiResp modifierPaimtDigiResp = new ModifPaimtDigiResp(modifierPaimtDigiFuncResp);

        ModifPaimtBodyResp bodyResp = new ModifPaimtBodyResp(modifierPaimtDigiResp);

        ModifPaimtResp resp = new ModifPaimtResp(null, bodyResp);

        return new ModifPaimtRootResp(resp);
    }

    public ModifPaimtRootResp buildResponseStatus200Fail() {
        ModifPaimtDetTransaPaimtNumResp detTransaPaimtNumeriseResp = ModifPaimtDetTransaPaimtNumResp
                .builder()
                .refTransaPaimtDigi("800091071485")
                .typeOpeTransaPaimtDigi(OPE_TRANSA_CANCEL)
                .numAutionTransaPaimtDigi("2222222")
                .instantCreatTransa(new Date())
                .instantAutionTransa(new Date())
                .mntAutionPaimtDigi(8.99f)
                .mntTrsfPaimtDigi(8.99f)
                .mntRembsmPaimtDigi(0.0f)
                .build();

        ModifPaimtDetMontantPaimtResp detMontantPaimtResp = new ModifPaimtDetMontantPaimtResp(DeviseEnum.EUR);

        ModifPaimtDigiBisResp paimtDigiResp = ModifPaimtDigiBisResp
                .builder()
                .detailMontantPaimt(detMontantPaimtResp)
                .detTransaPaimtNumerise(detTransaPaimtNumeriseResp)
                .stt(STT_CODE_CAPTURE_FAIL)
                .msg(STT_MSG_CAPTURE_REFUSED)
                .idMarchand("00001338126")
                .build();

        ModifPaimtDigiFuncResp modifierPaimtDigiFuncResp = new ModifPaimtDigiFuncResp(paimtDigiResp);

        ModifPaimtDigiResp modifierPaimtDigiResp = new ModifPaimtDigiResp(modifierPaimtDigiFuncResp);

        ModifPaimtBodyResp bodyResp = new ModifPaimtBodyResp(modifierPaimtDigiResp);

        ModifPaimtResp resp = new ModifPaimtResp(null, bodyResp);

        return new ModifPaimtRootResp(resp);
    }
}
