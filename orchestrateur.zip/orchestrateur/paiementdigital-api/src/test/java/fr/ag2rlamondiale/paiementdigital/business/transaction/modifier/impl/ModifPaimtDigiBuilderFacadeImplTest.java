package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier.IModifierPaiementDigitalMapper;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class ModifPaimtDigiBuilderFacadeImplTest {

    @InjectMocks
    private ModifPaimtDigiReqBuilderFacadeImpl facade;

    @Mock
    private IModifierPaiementDigitalMapper mapper;

    @Test
    void mapping_all_fileds_is_ok() {
        //GIVEN
        ModifTransaDetTransaPaimtNumReq detailTransactionPaiementNumerise = getModifTransaDetTransaPaimtNumReq();

        ModifTransaDetMntPaimtReq detailMontantPaiement = ModifTransaDetMntPaimtReq.builder()
                .montantTTC(200)
                .codeDeviseVersement(DeviseEnum.EUR)
                .build();

        ModifTransaInfosTechReq informationsTechniques = ModifTransaInfosTechReq.builder()
                .origineTransaction("ORIGINE")
                .referenceOperationPaiementDigital("REF")
                .referenceSousTransactionPaiementDigital("REF")
                .build();

        ModifTransaPaiementReq modificationTransactionPaiement = ModifTransaPaiementReq.builder()
                .detailMontantPaiement(detailMontantPaiement)
                .detailTransactionPaiementNumerise(detailTransactionPaiementNumerise)
                .informationsTechniques(informationsTechniques)
                .build();

        ModifTransaRootReq requestDto = new ModifTransaRootReq(modificationTransactionPaiement);

        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = getModifPaimtDetTransaPaimtNumReq();

        ModifPaimtDetMontantPaimtReq detMontantPaimt = ModifPaimtDetMontantPaimtReq.builder()
                .montantTTC(200)
                .codeDevVersm(DeviseEnum.EUR)
                .build();

        ModifPaimtInfoTechReq infoTech = ModifPaimtInfoTechReq.builder()
                .oriTransa("ORIGINE")
                .refOpePaimtDigi("REF")
                .refSsTransaPaimtDigi("REF")
                .build();

        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq
                .builder()
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detailMontantPaimt(detMontantPaimt)
                .infoTech(infoTech)
                .build();

        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);

        ModifPaimtRootReq expected = new ModifPaimtRootReq(modifierPaimtDigi);

        when(mapper.toDetTransaPaimtNumerise(any(ModifTransaDetTransaPaimtNumReq.class))).thenReturn(detTransaPaimtNumerise);
        when(mapper.toDetMontantPaimt(any(ModifTransaDetMntPaimtReq.class))).thenReturn(detMontantPaimt);
        when(mapper.toInfoTech(any(ModifTransaInfosTechReq.class))).thenReturn(infoTech);

        //WHEN
        ModifPaimtRootReq actual = facade.build(requestDto);

        //THEN
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt(), actual.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt());
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise(), actual.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise());
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getInfoTech(), actual.getModifierPaimtDigi().getPaimtDigi().getInfoTech());
    }

    @Test
    void mapping_only_mandatories_files_is_ok() {
        //GIVEN
        ModifTransaDetTransaPaimtNumReq detailTransactionPaiementNumerise = getModifTransaDetTransaPaimtNumReq();

        ModifTransaPaiementReq modificationTransactionPaiement = ModifTransaPaiementReq.builder()
                .detailTransactionPaiementNumerise(detailTransactionPaiementNumerise)
                .detailMontantPaiement(null)
                .informationsTechniques(null)
                .build();

        ModifTransaRootReq requestDto = new ModifTransaRootReq(modificationTransactionPaiement);

        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = getModifPaimtDetTransaPaimtNumReq();

        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq
                .builder()
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detailMontantPaimt(null)
                .infoTech(null)
                .build();

        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);

        ModifPaimtRootReq expected = new ModifPaimtRootReq(modifierPaimtDigi);

        when(mapper.toDetTransaPaimtNumerise(any(ModifTransaDetTransaPaimtNumReq.class))).thenReturn(detTransaPaimtNumerise);

        //WHEN
        ModifPaimtRootReq actual = facade.build(requestDto);

        //THEN
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise(), actual.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise());
        assertNull(actual.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt());
        assertNull(actual.getModifierPaimtDigi().getPaimtDigi().getInfoTech());
    }

    @Test
    void mapping_is_thowing_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(null));
    }

    private ModifTransaDetTransaPaimtNumReq getModifTransaDetTransaPaimtNumReq() {
        return ModifTransaDetTransaPaimtNumReq.builder()
                .idTransaction("ID_TRANSCTION")
                .typeOperationTransactionPaiementDigital("TYPE")
                .build();
    }

    private ModifPaimtDetTransaPaimtNumReq getModifPaimtDetTransaPaimtNumReq() {
        return ModifPaimtDetTransaPaimtNumReq.
                builder()
                .refTransaPaimtDigi("ID_TRANSCTION")
                .typeOpeTransaPaimtDigi("TYPE")
                .build();
    }
}