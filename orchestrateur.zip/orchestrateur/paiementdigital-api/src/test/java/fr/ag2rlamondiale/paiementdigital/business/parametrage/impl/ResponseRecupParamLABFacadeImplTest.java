package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePerimetresMethodesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionPerimetreException;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;

@SpringBootTest
class ResponseRecupParamLABFacadeImplTest {

    @InjectMocks
    private ResponseRecupParamLABFacadeImpl processFacade;

    @Mock
    private IParametrageFacade parametrageFacade;

    @Mock
    private IResponsePerimetresMethodesFacade parLabPerMethFacade;

    @Mock
    private IResponseChildsFacade paramLabParts;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    private RecupParamRootReq pfsDto;

    private Perimetre perimetreAca;

    private RecupParamProfResp parametre;

    private Set<ExclusionBanqueDto> exclusions;

    private Set<InclusionPaysDto> inclusions;

    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        pfsDto = parametrageLabData.getRequest();

        perimetreAca = parametrageLabData.getPerimetreAca();

        parametre = parametrageLabData.getParametre();

        exclusions = parametrageLabData.getExclusions();

        inclusions = parametrageLabData.getInclusions();

        methodes = parametrageLabData.getMethodes();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        perimetreAca = null;
        parametre = null;
        exclusions = null;
        inclusions = null;
        methodes = null;
    }

    @Test
    void parametrage_lab_found() {
        //GIVEN
        RecupParamRootResp expected = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();

        when(parametrageFacade.perimetre(any(RecupParamRootReq.class))).thenReturn(perimetreAca);

        when(parLabPerMethFacade.getPerimetreMethodePaiementDtos(any(RecupParamRootReq.class), any(Perimetre.class)))
                .thenReturn(methodes);

        when(paramLabParts.recupererParametragesLab(any(RecupParamProfResp.class), anySet(), anySet())).thenReturn(expected);
        when(parametrageFacade.exclusions(any(RecupParamRootReq.class))).thenReturn(exclusions);
        when(parametrageFacade.inclusions(any(RecupParamRootReq.class))).thenReturn(inclusions);
        when(paramLabParts.parametresProfils(anySet())).thenReturn(parametre);

        //WHEN
        RecupParamRootResp actual = processFacade.recupererParametragesLab(pfsDto);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void parametrage_lab_throws_not_found_parameter_exception() {
        //GIVEN
        when(parametrageFacade.perimetre(any(RecupParamRootReq.class))).thenThrow(NotFoundParameterValueException.class);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> processFacade.recupererParametragesLab(pfsDto));
    }

    @Test
    void parametrage_lab_throws_incorrect_parameter_exception() {
        //GIVEN
        when(parametrageFacade.perimetre(any(RecupParamRootReq.class))).thenThrow(IncorrectParameterValueException.class);

        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> processFacade.recupererParametragesLab(pfsDto));
    }

    @Test
    void parametrage_lab_throws_exclusion_perimetre_exception() {
        //GIVEN
        when(parametrageFacade.perimetre(any(RecupParamRootReq.class))).thenThrow(ExclusionPerimetreException.class);

        //WHEN THEN
        assertThrows(ExclusionPerimetreException.class, () -> processFacade.recupererParametragesLab(pfsDto));
    }

    @Test
    void parametrage_lab_throws_too_many_profils_exception() {
        //GIVEN
        when(parametrageFacade.perimetre(any(RecupParamRootReq.class))).thenThrow(TooManyProfilsException.class);

        //WHEN THEN
        assertThrows(TooManyProfilsException.class, () -> processFacade.recupererParametragesLab(pfsDto));
    }
}