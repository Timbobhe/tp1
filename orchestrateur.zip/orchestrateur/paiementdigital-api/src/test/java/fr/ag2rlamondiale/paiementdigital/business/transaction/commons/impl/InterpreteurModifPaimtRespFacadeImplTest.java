package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IPFSFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.AbstractMap;
import java.util.Date;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@SpringBootTest
class InterpreteurModifPaimtRespFacadeImplTest {

    @InjectMocks
    private InterpreteurModifPaimtRespFacadeImpl interpretFacade;

    @Mock
    private IPFSFacade pfsFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Autowired
    private ApiModifierPaiementTestData modifData;

    @Autowired
    private ApiPaiementTestData paiementTestData;

    private Paiement paiement;

    @BeforeEach
    void setUp() {
        String orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        paiement = paiementTestData.build("JAMES BOND", "CLIENT_1", 8.99F, orderId,
                "89087655566", 1, MASTERCARD, CAPTURE);
        paiement.setHistoriques(paiementTestData.modifTransaEtats(CAPTURE, 8.99F, null, null, paiement.getId()));
    }

    @AfterEach
    void tearDown() {
        paiement = null;
    }

    @Test
    void parameters_are_null_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(null, null));
    }

    @Test
    void paiement_is_captured_status_200_stt_118() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifData.buildResponseStatus200();
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        Paiement expected = paiement.copy(paiement);
        expected.setEtatCourant(CAPTURED);
        expected.setDateModification(new Date());
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.CAPTURED)
                .id(new HistoriquePK(new Date(), expected.getId()))
                .build();
        expected.getHistoriques().add(historique);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(EtatEnum.CAPTURED, actual.getEtatCourant());
        assertEquals(expected.getEtatCourant(), actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> CAPTURED.equals(h.getEtat())).count());
    }

    @Test
    void paiement_is_fail_status_200_stt_173() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifData.buildResponseStatus200();
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setStt("173");
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setMsg("Fail");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        Paiement expected = paiement.copy(paiement);
        expected.setEtatCourant(FAIL);
        expected.setDateModification(new Date());
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.FAIL)
                .id(new HistoriquePK(new Date(), expected.getId()))
                .build();
        expected.getHistoriques().add(historique);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(FAIL, actual.getEtatCourant());
        assertEquals(expected.getEtatCourant(), actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> FAIL.equals(h.getEtat())).count());
    }

    @Test
    void paiement_status_200_stt_unknown_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifData.buildResponseStatus200();
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setStt("999");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(response, paiement));
    }

    @Test
    void paiement_is_4xx_status() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");
        ModifPaimtErrorResp funcErrorResp = modifPaimtRootResp.getResponse().getHeader().getFuncError().get(0);
        AbstractMap.SimpleEntry<String, String> entry = new AbstractMap.SimpleEntry<>(funcErrorResp.getErrorCode(), funcErrorResp.getErrorMessage());
        when(pfsFacade.modifTransaHeaderResp(any(PfsResponse.class))).thenReturn(entry);

        Paiement expected = paiement.copy(paiement);
        expected.setEtatCourant(EtatEnum.ERROR);
        expected.setDateModification(new Date());
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.ERROR)
                .status(entry.getKey())
                .message(entry.getValue())
                .id(new HistoriquePK(new Date(), expected.getId()))
                .build();
        expected.getHistoriques().add(historique);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.BAD_REQUEST);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR, actual.getEtatCourant());
        assertEquals(expected.getEtatCourant(), actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).count());
    }

    @Test
    void status_not_200_nor_4xx_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(response, paiement));
    }
}