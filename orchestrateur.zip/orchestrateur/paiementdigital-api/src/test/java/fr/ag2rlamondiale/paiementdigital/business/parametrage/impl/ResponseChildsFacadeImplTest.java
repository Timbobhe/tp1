package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseCalculFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@SpringBootTest
class ResponseChildsFacadeImplTest {

    @InjectMocks
    private ResponseChildsFacadeImpl recupParamLab;

    @Mock
    private IResponseCalculFacade calcul;

    @Mock
    private IResponseBuilderFacade builder;


    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    private Plafond plafond;

    private RecupParamProfResp parametre;

    private Set<ExclusionBanqueDto> exclusions;

    private Set<InclusionPaysDto> inclusions;

    private Set<RecupParamPlfdFreqResp> plafonds1;

    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        plafond = parametrageLabData.getPlafond();

        parametre = parametrageLabData.getParametre();

        exclusions = parametrageLabData.getExclusions();

        inclusions = parametrageLabData.getInclusions();

        plafonds1 = parametrageLabData.getPlafonds1();

        methodes = parametrageLabData.getMethodes();
    }

    @AfterEach
    void tearDown() {
        plafond = null;
        parametre = null;
        exclusions = null;
        inclusions = null;
        plafonds1 = null;
        methodes = null;
    }

    @Test
    void get_plafonds_par_frequences_dto_with_captured_montants() {
        //GIVEN
        float montantMaxdispoClient = 500F;
        int nombreMaxDispoClient = 3;
        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(montantMaxdispoClient)
                .nombreMaxDispoClient(nombreMaxDispoClient)
                .build();

        List<Float> montantsCaptured = Arrays.asList(300F, 100F, 100F);

        when(calcul.montantMaxDispoClient(anyFloat(), anyList())).thenReturn(montantMaxdispoClient);
        when(calcul.nombreMaxDispoClient(anyInt(), anyList())).thenReturn(nombreMaxDispoClient);
        when(builder.build(any(Plafond.class), anyFloat(), anyInt())).thenReturn(expected);

        //WHEN
        RecupParamPlfdFreqResp actual = recupParamLab.plafondsParFrequences(plafond, montantsCaptured);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void get_plafonds_par_frequences_dto_without_captured_montants() {
        //GIVEN
        float montantMaxdispoClient = 1000F;
        int nombreMaxDispoClient = 5;

        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(montantMaxdispoClient)
                .nombreMaxDispoClient(nombreMaxDispoClient)
                .build();

        when(calcul.montantMaxDispoClient(anyFloat(), any())).thenReturn(montantMaxdispoClient);
        when(calcul.nombreMaxDispoClient(anyInt(), any())).thenReturn(nombreMaxDispoClient);
        when(builder.build(any(Plafond.class), anyFloat(), anyInt())).thenReturn(expected);

        //WHEN
        RecupParamPlfdFreqResp actual = recupParamLab.plafondsParFrequences(plafond, null);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void get_perimetre_methode_paiement_dto() {
        //GIVEN
        String methodeName = MethodePaiementEnum.CB.name();
        float minMontant = 300;
        String frequenceMontant = TypeFrequenceEnum.MOIS_GLISSANT.name();
        int minNombre = 2;
        String frequenceNombre = TypeFrequenceEnum.MOIS_GLISSANT.name();

        RecupParamPeriMethPaimtResp expected = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(methodeName)
                .frequenceMinMontantDispoClient(frequenceMontant)
                .minMontantDispoClient(minMontant)
                .frequenceNombrePaiementDisponible(frequenceNombre)
                .minNombrePaiementDisponible(minNombre)
                .plafondsParFrequences(plafonds1)
                .build();

        when(calcul.minMontantDispoClient(anySet())).thenReturn(minMontant);
        when(calcul.frequenceMinMontantDispoClient(anySet())).thenReturn(TypeFrequenceEnum.MOIS_GLISSANT.name());
        when(calcul.minNombrePaiementDisponible(anySet())).thenReturn(minNombre);
        when(calcul.frequenceNombrePaiementDisponible(anySet())).thenReturn(TypeFrequenceEnum.MOIS_GLISSANT.name());
        when(builder.build(anyString(), anyFloat(), anyString(), anyInt(), anyString(), anySet())).thenReturn(expected);

        //WHEN
        RecupParamPeriMethPaimtResp actual = recupParamLab.perimetreMethodePaiement(methodeName, plafonds1);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void get_parametres_profils_dto() {
        //GIVEN
        float maxDesMontantsDispo = 1000F;
        String methodeMaxDesMontantsDispo = MethodePaiementEnum.CB.name();
        int maxDesNombresDePaiementDispo = 3;
        String methodeMaxDesNombresDePaiementDispo = MethodePaiementEnum.VISA.name();

        RecupParamProfResp expected = RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(maxDesMontantsDispo)
                .methodeMaxDesMontantsDispo(methodeMaxDesMontantsDispo)
                .maxDesNombresDePaiementDispo(maxDesNombresDePaiementDispo)
                .methodeMaxDesNombresDePaiementDispo(methodeMaxDesNombresDePaiementDispo)
                .perimetreMethodePaiement(methodes)
                .build();

        when(calcul.maxDesMontantsDispo(anySet())).thenReturn(maxDesMontantsDispo);
        when(calcul.methodeMaxDesMontantsDispo(anySet(), anyFloat())).thenReturn(methodeMaxDesMontantsDispo);
        when(calcul.maxDesNombresDePaiementDispo(anySet())).thenReturn(maxDesNombresDePaiementDispo);
        when(calcul.methodeMaxDesNombresDePaiementDispo(anySet(), anyInt())).thenReturn(methodeMaxDesNombresDePaiementDispo);
        when(builder.build(anyFloat(), anyString(), anyInt(), anyString(), anySet())).thenReturn(expected);

        //WHEN
        RecupParamProfResp actual = recupParamLab.parametresProfils(methodes);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    void get_recuperer_parametrages_lab_dto() {
        //GIVEN
        RecupParamRootResp expected = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();

        when(builder.build(any(RecupParamProfResp.class), anySet(), anySet())).thenReturn(expected);

        //WHEN
        RecupParamRootResp actual = recupParamLab.recupererParametragesLab(parametre, exclusions, inclusions);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);

    }

}