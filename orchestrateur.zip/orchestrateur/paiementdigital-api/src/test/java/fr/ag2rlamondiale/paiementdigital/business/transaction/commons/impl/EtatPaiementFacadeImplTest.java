package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierTransactionTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerTransaToPaimtMapper;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_TECH_DEFAULT;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@SpringBootTest
class EtatPaiementFacadeImplTest {

    @InjectMocks
    private EtatPaiementFacadeImpl transactionFacade;

    @Mock
    private IPaiementFacade paiementFacade;

    @Mock
    private ICreerTransaToPaimtMapper mapper;

    @Autowired
    private ApiPaiementTestData transaData;

    @Autowired
    private ApiModifierTransactionTestData modifTransaData;

    private ModifTransaRootReq modifRequest;

    private Paiement paiement;

    private String orderId;

    private String idTransaction;

    private float montant;

    @BeforeEach
    void setUp() {
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        montant = 200f;

        modifRequest = modifTransaData.buildRequest(orderId, montant, idTransaction);

        paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        paiement.setHistoriques(transaData.modifTransaEtats(AUTHORIZED, montant, null, null, paiement.getId()));
    }

    @AfterEach
    void tearDown() {
        modifRequest = null;
        paiement = null;
        orderId = null;
        idTransaction = null;
    }

    @Test
    void create_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> transactionFacade.create(null));
    }

    @Test
    void authorization_null_paiement_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> transactionFacade.authorization(null));
    }

    @Test
    void update_paiement_to_authorization_is_success() {
        //GIVEN
        Paiement paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CREATE);

        Paiement expected = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZATION);
        expected.setHistoriques(transaData.modifTransaEtats(AUTHORIZATION, montant, null, null, expected.getId()));
        when(paiementFacade.update(any(Paiement.class))).thenReturn(expected);

        //WHEN
        Paiement actual = transactionFacade.authorization(paiement);

        //THEN
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(EtatEnum.AUTHORIZATION, actual.getEtatCourant());
        assertEquals(2, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> AUTHORIZATION.equals(h.getEtat())).count());
    }

    @Test
    void update_unknown_paiement_throws_exception() {
        //GIVEN
        Paiement paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CREATE);
        paiement.setId(100000L);
        paiement.setHistoriques(transaData.modifTransaEtats(CREATE, montant, null, null, paiement.getId()));
        when(paiementFacade.update(any(Paiement.class))).thenThrow(PaiementException.class);

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> transactionFacade.authorization(paiement));
    }

    @Test
    void capture_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> transactionFacade.capture(null));
    }

    @Test
    void capture_unknown_id_transaction_throws_exception() {
        //GIVEN
        when(paiementFacade.find(anyString())).thenThrow(ModifierTransactionException.class);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> transactionFacade.capture(modifRequest));
    }

    @Test
    void capture_paiment_to_capture_is_ok() {
        //GIVEN
        float montant = modifRequest.getModificationTransactionPaiement().getDetailMontantPaiement().getMontantTTC();
        Paiement expected = modifTransaData.capture(paiement, montant);
        when(paiementFacade.find(anyString())).thenReturn(paiement);
        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);

        //WHEN
        Paiement actual = transactionFacade.capture(modifRequest);

        //THEN
        assertEquals(expected.getMontant(), actual.getMontant());
        assertEquals(expected.getIdTransaction(), actual.getIdTransaction());
        assertEquals(EtatEnum.CAPTURE, actual.getEtatCourant());
        assertEquals(expected.getEtatCourant(), actual.getEtatCourant());
        assertEquals(4, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> CAPTURE.equals(h.getEtat())).count());
    }

    @Test
    void error_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> transactionFacade.error(null, null, null));
    }

    @Test
    void update_paiment_to_error_is_ok() {
        //GIVEN
        Paiement paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        paiement.setHistoriques(transaData.modifTransaEtats(ERROR, montant, A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531", paiement.getId()));
        float montant = modifRequest.getModificationTransactionPaiement().getDetailMontantPaiement().getMontantTTC();
        Paiement expected = modifTransaData.error(paiement, montant);

        when(paiementFacade.update(any(Paiement.class))).thenReturn(paiement);

        //WHEN
        Paiement actual = transactionFacade.error(paiement, A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531");

        //THEN
        assertEquals(expected.getMontant(), actual.getMontant());
        assertEquals(expected.getIdTransaction(), actual.getIdTransaction());
        assertEquals(EtatEnum.ERROR, actual.getEtatCourant());
        assertEquals(expected.getEtatCourant(), actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).count());
    }

    @Test
    void error_paiment_update_throws_exception() {
        //GIVEN
        Paiement paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        paiement.setHistoriques(transaData.modifTransaEtats(ERROR, montant, INTERNAL_SERVER_ERROR.name(), "Anomalie interne", paiement.getId()));

        when(paiementFacade.update(any(Paiement.class))).thenThrow(PaiementException.class);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> transactionFacade.error(paiement, INTERNAL_SERVER_ERROR.name(), "Anomalie interne"));
    }
}