package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierTransactionTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementTestData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDetMontantPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDetTransaPaimtNumResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDigiBisResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier.IModifTransaPaimtDigiMapper;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Date;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
class ModifTransaBuilderFacadeImplTest {

    @InjectMocks
    private ModifTransaRespBuilderFacadeImpl facade;

    @Mock
    private IInterpreteurPfsResponseFacade<ModifPaimtRootResp, Paiement> interpretFacade;

    @Mock
    private IModifTransaPaimtDigiMapper mapper;

    @Autowired
    private ApiModifierTransactionTestData modifTransaData;

    @Autowired
    private ApiPaiementTestData transaData;

    @Autowired
    private ApiModifierPaiementTestData modifPaimtData;

    private Paiement paiement;
    private float montant;
    private String orderId;
    private String idTransaction;

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        paiement.setHistoriques(transaData.modifTransaEtats(AUTHORIZED, montant, null, null, paiement.getId()));
    }

    @BeforeEach
    void tearDown() {
        paiement = null;
        orderId = null;
        idTransaction = null;
    }

    @Test
    void response_modifier_paiement_digital_is_captured() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200();

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);

        ModifTransaRootResp expected = modifTransaData.buildCapturedResponse(orderId, idTransaction, montant);

        when(mapper.toModifTransa(any(ModifPaimtDigiBisResp.class), any(EtatEnum.class))).thenReturn(expected.getModifTransaResp());
        when(mapper.toDetTransaPaimtNum(any(ModifPaimtDetTransaPaimtNumResp.class), anyString())).thenReturn(expected.getModifTransaResp().getDetailTransactionPaiementNumerise());
        when(mapper.toDetMntPaimt(any(ModifPaimtDetMontantPaimtResp.class))).thenReturn(expected.getModifTransaResp().getDetailMontantPaiement());

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
        assertEquals(EtatEnum.CAPTURED.name(), actual.getModifTransaResp().getEtatCourant());
        assertEquals(STT_CODE_CAPTURED_OK, actual.getModifTransaResp().getStatus());
        assertEquals(CAPTURED, actual.getModifTransaResp().getMessage());
    }

    @Test
    void response_modifier_paiement_digital_is_fail() {
        //GIVEN
        String code = STT_CODE_CAPTURE_FAIL;
        String message = STT_MSG_CAPTURE_REFUSED;
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.FAIL)
                .montant(montant)
                .status(code)
                .message(message)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .build();
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.FAIL);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200Fail();

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);

        ModifTransaRootResp expected = modifTransaData.buildFailResponse(orderId, idTransaction, montant);

        when(mapper.toModifTransa(any(ModifPaimtDigiBisResp.class), any(EtatEnum.class))).thenReturn(expected.getModifTransaResp());
        when(mapper.toDetTransaPaimtNum(any(ModifPaimtDetTransaPaimtNumResp.class), anyString())).thenReturn(expected.getModifTransaResp().getDetailTransactionPaiementNumerise());
        when(mapper.toDetMntPaimt(any(ModifPaimtDetMontantPaimtResp.class))).thenReturn(expected.getModifTransaResp().getDetailMontantPaiement());

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
        assertEquals(EtatEnum.FAIL.name(), actual.getModifTransaResp().getEtatCourant());
        assertEquals(code, actual.getModifTransaResp().getStatus());
        assertEquals(message, actual.getModifTransaResp().getMessage());
    }

    @Test
    void response_modifier_paiement_digital_is_hypay_error() {
        //GIVEN
        String code = "3000002";
        String message = "Transaction not found";
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.ERROR)
                .montant(montant)
                .status(code)
                .message(message)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .build();
        paiement.setIdTransaction(null);
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.ERROR);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.NOT_FOUND);

        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);

        ModifTransaRootResp expected = modifTransaData.buildFuncErrorResponse(code, message);

        when(mapper.toModifTransaRoot(any(Historique.class))).thenReturn(expected);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR.name(), actual.getEtatCourant());
        assertEquals(code, actual.getCodeErreur());
        assertEquals(message, actual.getMessageErreur());
        assertNull(actual.getModifTransaResp());
    }

    @Test
    void response_modifier_paiement_digital_is_pfs_error() {
        //GIVEN
        String code = A0487_TECH_PARSING;
        String message = "Input data invalid";
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.ERROR)
                .montant(montant)
                .status(code)
                .message(message)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .build();
        paiement.setIdTransaction(null);
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.ERROR);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(code, message);

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.NOT_FOUND);

        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenReturn(paiement);

        ModifTransaRootResp expected = modifTransaData.buildFuncErrorResponse(code, message);

        when(mapper.toModifTransaRoot(any(Historique.class))).thenReturn(expected);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR.name(), actual.getEtatCourant());
        assertEquals(code, actual.getCodeErreur());
        assertEquals(message, actual.getMessageErreur());
        assertNull(actual.getModifTransaResp());
    }

    @Test
    void invalid_parameter_in_build_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(null, null));
    }

    @Test
    void exception_during_interpreteur_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);
        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenThrow(ModifierTransactionException.class);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(response, paiement));
    }

    @Test
    void response_status_not_200_not_4xx_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);
        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenThrow(ModifierTransactionException.class);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(response, paiement));
    }

    @Test
    void response_status_stt_not_118_not_173_throws_exception() {
        //GIVEN
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.FAIL)
                .montant(montant)
                .status("UNKNOWN_STT")
                .message("Unknown failure reason")
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .build();
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.FAIL);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200Fail();

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        when(interpretFacade.interpreteur(any(), any(Paiement.class))).thenThrow(ModifierTransactionException.class);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(response, paiement));
    }

}