package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailActeurFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailProduitFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerPaimtDigiReqMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;

@SpringBootTest
class CreerPaiementDigitalFacadeImplTest {

    @InjectMocks
    private CreerPaimtDigiReqBuilderFacadeImpl creerPaiementDigitalFacade;

    @Mock
    private ICreerPaimtDigiReqMapper creerPaiementDigitalMapper;

    @Mock
    private IDetailActeurFacade detailActeurFacade;

    @Mock
    private IDetailProduitFacade detailProduitFacade;

    private CreerTransaPaimtDigiRootReq creerTransacPaimtDigiRequestDto;

    @BeforeEach
    void setUp() {
        creerTransacPaimtDigiRequestDto = CreerTransaPaimtDigiRootReq.builder()
                .redirection(new RedirectionReq())
                .detailTransPaiemtNumerise(new DetailTransactionPaiementNumeriseReq())
                .detailMontantPaiement(new DetailMontantPaiementReq())
                .detailMethodePaiement(DetailMethodePaiementReq.builder().detailCarte(new DetailCarteReq()).build())
                .detailEspaceClient(new DetailEspaceClientReq())
                .entetePaiementDigital(new EntetePaiementDigitalReq())
                .build();
    }

    @AfterEach
    void tearDown() {
        creerTransacPaimtDigiRequestDto = null;
    }

    @Test
    void build_creer_paiement_digi_with_correct_param() {
        //GIVEN
        given(creerPaiementDigitalMapper.toRedirect(any(RedirectionReq.class))).willReturn(new RedirectReq());
        given(creerPaiementDigitalMapper.toDetTransaPaimtNumerise(any(DetailTransactionPaiementNumeriseReq.class))).willReturn(new DetTransaPaimtNumeriseReq());
        given(creerPaiementDigitalMapper.toDetMntPaimt(any(DetailMontantPaiementReq.class))).willReturn(new DetMntPaimtReq());
        given(creerPaiementDigitalMapper.toDetCartePaimt(any(DetailMethodePaiementReq.class))).willReturn(new DetCartePaimtReq());
        given(creerPaiementDigitalMapper.toDetEspCli(any(DetailEspaceClientReq.class))).willReturn(new DetEspCliReq());
        given(creerPaiementDigitalMapper.toEntetePaimtNumerise(any(EntetePaiementDigitalReq.class), any(Paiement.class))).willReturn(new EntetePaimtNumeriseReq());
        given(detailActeurFacade.detailActeurs(any(CreerTransaPaimtDigiRootReq.class))).willReturn(new DetActrReq());
        given(detailProduitFacade.detailProduit(any(CreerTransaPaimtDigiRootReq.class))).willReturn(new DetPdtReq());

        //WHEN
        CreerPaimtDigiRootReq result = creerPaiementDigitalFacade.build(creerTransacPaimtDigiRequestDto, new Paiement());

        //THEN
        assertNotNull(result);
    }

}