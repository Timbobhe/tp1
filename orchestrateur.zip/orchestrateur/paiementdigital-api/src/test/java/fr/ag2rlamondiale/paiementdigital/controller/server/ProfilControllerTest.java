package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiProfilTestData;
import fr.ag2rlamondiale.paiementdigital.business.IProfilFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ProfilDto;
import fr.ag2rlamondiale.paiementdigital.exception.ProfilException;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IProfilMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.A1573;
import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.AUCUN_PROFIL_TROUVE;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ProfilControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IProfilFacade facade;

    @MockBean
    private IProfilMapper mapper;

    @Autowired
    private ApiProfilTestData data;

    @Autowired
    private SecurityTestData security;

    private Profil profil;

    private ProfilDto profilDto;

    private String uri = "/api/profils";

    private String codeApplication = A1573;

    private String token;

    @BeforeEach
    void setUp() {
        data.init();

        profil = data.getProfilA1573();

        profilDto = data.getProfilA1573Dto();

        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        profil = null;
        profilDto = null;
        token = null;
    }

    @Test
    void finding_profil_by_id_is_ok() throws Exception {
        //GIVEN
        given(facade.findById(anyLong())).willReturn(profil);
        given(mapper.toProfilDto(any(Profil.class))).willReturn(profilDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/1")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.metier").value(ProfilConstantes.RET_SUP_COL))
                .andExpect(jsonPath("$.codeApplication").value(codeApplication));

    }

    @Test
    void finding_unknown_profil_by_id_is_404_status() throws Exception {
        //GIVEN
        given(facade.findById(anyLong())).willThrow(new ProfilException(AUCUN_PROFIL_TROUVE));

        //WHEN THEN
        mvc.perform(
                get(uri + "/1000")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value(AUCUN_PROFIL_TROUVE));

    }

    @Test
    void getting_all_profil_is_ok() throws Exception {
        //GIVEN
        Set<ProfilDto> profilsDto = new HashSet<>(Arrays.asList(profilDto));
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        given(facade.findAll()).willReturn(profils);
        given(mapper.toDtoSet(anySet())).willReturn(profilsDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/all")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }
}