package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityTestData;
import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IExclusionBanqueMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.JSON_PATTERN_DATE_FORMAT;
import static fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException.AUCUNE_BANQUE_TROUVEE;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class ExclusionBanqueControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private IExclusionBanqueFacade facade;

    @MockBean
    private IExclusionBanqueMapper mapper;

    @Autowired
    private SecurityTestData security;

    private ExclusionBanque banqueSaved;

    private ExclusionBanqueDto banqueSavedDto;

    private String uri = "/api/banques";

    private Date dateEffet = buildShortDate(2020, 10, 12);

    private Date dateCreation = buildLongDate(2020, 10, 12);

    private String bred = "BRED";

    private String token;

    @BeforeEach
    void setUp() {

        banqueSaved = ExclusionBanque
                .builder()
                .banque(bred)
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

        banqueSavedDto = ExclusionBanqueDto
                .builder()
                .banque(bred)
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

        token = security.createToken(SecurityTestData.PRIVATE_KEY, SecurityTestData.VALIDITY_MILLSEC);
    }

    @AfterEach
    void tearDown() {
        banqueSaved = null;
        banqueSavedDto = null;
        token = null;
    }

    @Test
    void finding_banque_by_id_is_ok() throws Exception {
        //GIVEN
        given(facade.findById(anyString())).willReturn(banqueSaved);
        given(mapper.toBanqueDto(any(ExclusionBanque.class))).willReturn(banqueSavedDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/1")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.banque").value(bred))
                .andExpect(jsonPath("$.dateEffet").value(dateEffet.toString()))
                .andExpect(jsonPath("$.dateCreation").value(format(dateCreation, JSON_PATTERN_DATE_FORMAT)));

    }

    @Test
    void finding_unknown_banque_by_id_is_404_status() throws Exception {
        //GIVEN
        given(facade.findById(anyString())).willThrow(new ExclusionBanqueException(AUCUNE_BANQUE_TROUVEE));

        //WHEN THEN
        mvc.perform(
                get(uri + "/1000")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value(AUCUNE_BANQUE_TROUVEE));

    }

    @Test
    void getting_all_banque_is_ok() throws Exception {
        //GIVEN
        Set<ExclusionBanqueDto> banquesDto = new HashSet<>(Arrays.asList(banqueSavedDto));
        Set<ExclusionBanque> banques = new HashSet<>(Arrays.asList(banqueSaved));
        given(facade.findAll()).willReturn(banques);
        given(mapper.toDtoSet(anySet())).willReturn(banquesDto);

        //WHEN THEN
        mvc.perform(
                get(uri + "/all")
                        .header(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1));
    }
}