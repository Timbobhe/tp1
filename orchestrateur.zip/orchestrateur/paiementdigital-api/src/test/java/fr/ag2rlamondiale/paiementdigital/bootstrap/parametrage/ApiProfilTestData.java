package fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage;

import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.*;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.*;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.*;
import static fr.ag2rlamondiale.paiementdigital.utils.ApiParametrageUtils.*;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.*;

@Component
@Getter
public class ApiProfilTestData {

    private Profil profilA1573;

    private ProfilDto profilA1573Dto;

    private Set<Perimetre> exclusionsPerimetres;

    private Set<PerimetreDto> exclusionsPerimetresDto;

    public void init() {
        initProfil();
        initProfilDto();
    }

    private void initProfil() {

        PerimetrePlafond pp1Cb1 = perimetrePlafond(1L, 1L, CB.name());
        PerimetrePlafond pp1Visa1 = perimetrePlafond(1L, 1L, VISA.name());
        PerimetrePlafond pp1Mastercard1 = perimetrePlafond(1L, 1L, MASTERCARD.name());
        PerimetrePlafond pp1Cb2 = perimetrePlafond(1L, 2L, CB.name());
        PerimetrePlafond pp1Visa2 = perimetrePlafond(1L, 2L, VISA.name());
        PerimetrePlafond pp1Mastercard2 = perimetrePlafond(1L, 2L, MASTERCARD.name());
        PerimetrePlafond pp1Cb3 = perimetrePlafond(1L, 3L, CB.name());
        PerimetrePlafond pp1Visa3 = perimetrePlafond(1L, 3L, VISA.name());
        PerimetrePlafond pp1Mastercard3 = perimetrePlafond(1L, 3L, MASTERCARD.name());

        PerimetrePlafond pp2Cb1 = perimetrePlafond(2L, 3L, CB.name());
        PerimetrePlafond pp2Visa1 = perimetrePlafond(2L, 3L, VISA.name());
        PerimetrePlafond pp2Mastercard1 = perimetrePlafond(2L, 3L, MASTERCARD.name());


        Plafond anneeCivile0_8000 = plafond(1L, TypeFrequenceEnum.ANNEE_CIVILE, 0f, 8000f, 999,
                new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1)));

        Plafond moisGlissant0_2500 = plafond(2L, TypeFrequenceEnum.MOIS_GLISSANT, 0f, 2500f, 999,
                new HashSet<>(Arrays.asList(pp1Cb2, pp1Visa2, pp1Mastercard2)));

        Plafond transaction0_2500 = plafond(3L, TypeFrequenceEnum.TRANSACTION, 0f, 2500f, 999,
                new HashSet<>(Arrays.asList(pp1Cb3, pp1Visa3, pp1Mastercard3, pp2Cb1, pp2Visa1, pp2Mastercard1)));

        PerimetreInfos piAca1 = perimetreInfos(1L, ARI, ACA, null, null, null);
        PerimetreInfos piAca2 = perimetreInfos(2L, ARI, ACA, null, null, null);

        Perimetre aca1 = perimetre(1L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 10, 12),
                buildLongDate(2020, 10, 12), null,
                piAca1, new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1, pp1Cb2, pp1Visa2, pp1Mastercard2, pp1Cb3, pp1Visa3, pp1Mastercard3)));

        Perimetre aca2 = perimetre(2L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2021, 10, 12), null,
                buildLongDate(2021, 10, 12), null,
                piAca2, new HashSet<>(Arrays.asList(pp2Cb1, pp2Visa1, pp2Mastercard1)));

        profilA1573 = Profil.builder()
                .id(1L)
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .perimetres(new HashSet<>(Arrays.asList(aca1, aca2)))
                .build();

    }

    private void initProfilDto() {

        PlafondDto anneeCivile0_8000 = plafondDto(1L, TypeFrequenceEnum.ANNEE_CIVILE, 0f, 8000f, 999);

        PlafondDto moisGlissant0_2500 = plafondDto(2L, TypeFrequenceEnum.MOIS_GLISSANT, 0f, 2500f, 999);

        PlafondDto transaction0_2500 = plafondDto(3L, TypeFrequenceEnum.TRANSACTION, 0f, 2500f, 999);

        PerimetrePlafondDto pp1Cb1 = perimetrePlafondDto(CB.name(), anneeCivile0_8000);
        PerimetrePlafondDto pp1Visa1 = perimetrePlafondDto(VISA.name(), anneeCivile0_8000);
        PerimetrePlafondDto pp1Mastercard1 = perimetrePlafondDto(MASTERCARD.name(), anneeCivile0_8000);
        PerimetrePlafondDto pp1Cb2 = perimetrePlafondDto(CB.name(), moisGlissant0_2500);
        PerimetrePlafondDto pp1Visa2 = perimetrePlafondDto(VISA.name(), moisGlissant0_2500);
        PerimetrePlafondDto pp1Mastercard2 = perimetrePlafondDto(MASTERCARD.name(), moisGlissant0_2500);
        PerimetrePlafondDto pp1Cb3 = perimetrePlafondDto(CB.name(), transaction0_2500);
        PerimetrePlafondDto pp1Visa3 = perimetrePlafondDto(VISA.name(), transaction0_2500);
        PerimetrePlafondDto pp1Mastercard3 = perimetrePlafondDto(MASTERCARD.name(), transaction0_2500);

        PerimetrePlafondDto pp2Cb1 = perimetrePlafondDto(CB.name(), transaction0_2500);
        PerimetrePlafondDto pp2Visa1 = perimetrePlafondDto(VISA.name(), transaction0_2500);
        PerimetrePlafondDto pp2Mastercard1 = perimetrePlafondDto(MASTERCARD.name(), transaction0_2500);

        PerimetreInfosDto piAca1 = perimetreInfosDto(ARI, ACA, null, null, null);
        PerimetreInfosDto piAca2 = perimetreInfosDto(ARI, ACA, null, null, null);

        PerimetreDto aca1 = perimetreDto(1L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 10, 12),
                buildLongDate(2020, 10, 12), null,
                piAca1, new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1, pp1Cb2, pp1Visa2, pp1Mastercard2, pp1Cb3, pp1Visa3, pp1Mastercard3)));

        PerimetreDto aca2 = perimetreDto(2L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2021, 10, 12), null,
                buildLongDate(2021, 10, 12), null,
                piAca2, new HashSet<>(Arrays.asList(pp2Cb1, pp2Visa1, pp2Mastercard1)));

        profilA1573Dto = ProfilDto.builder()
                .id(1L)
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .perimetres(new HashSet<>(Arrays.asList(aca1, aca2)))
                .build();

    }

}