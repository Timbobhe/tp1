package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabTestData;
import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.business.IRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IExclusionBanqueMapper;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IInclusionPaysMapper;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IRecupParamLABMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.buildLongDate;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.buildShortDate;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.when;

@SpringBootTest
class ParametrageFacadeImplTest {

    @InjectMocks
    private ParametrageFacadeImpl parametrageFacade;

    @Mock
    private IRecupParamLABMapper mapper;

    @Mock
    private IRecupParamLABFacade recupParamLABFacade;

    @Mock
    private IInclusionPaysFacade inclusionPaysFacade;

    @Mock
    private IExclusionBanqueFacade exclusionBanqueFacade;

    @Mock
    private IExclusionBanqueMapper banqueMapper;

    @Mock
    private IInclusionPaysMapper paysMapper;

    @Autowired
    private ApiParametrageLabTestData parametrageLabData;

    private RecupParamRootReq pfsDto;

    private Perimetre perimetreAca;

    private RecupParamLAB recupParamLAB;

    @BeforeEach
    void setUp() {
        parametrageLabData.init();

        pfsDto = parametrageLabData.getRequest();
        perimetreAca = parametrageLabData.getPerimetreAca();

        recupParamLAB = RecupParamLAB
                .builder()
                .metier(pfsDto.getProfil().getMetier())
                .codeApplication(pfsDto.getProfil().getCodeApplication())
                .evenementMetier(pfsDto.getProfil().getEvenementMetier())
                .natureClient(pfsDto.getClient().getNatureClient())
                .typeClient(pfsDto.getClient().getTypeClient())
                .structureJuridique(pfsDto.getPerimetre().getStructureJuridique())
                .filiale(pfsDto.getPerimetre().getFiliale())
                .produit(pfsDto.getPerimetre().getProduit())
                .contratDeReference(pfsDto.getPerimetre().getContratDeReference())
                .contrat(pfsDto.getPerimetre().getContrat())
                .tiersPayeur(pfsDto.getPerimetre().isTiersPayeur())
                .dateRecherche(pfsDto.getDateRecherche())
                .build();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        perimetreAca = null;
        recupParamLAB = null;
    }

    @Test
    void perimetre_aca_found_with_parameters() {
        //GIVEN
        when(mapper.toRecupParamLAB(any(RecupParamRootReq.class))).thenReturn(recupParamLAB);
        when(recupParamLABFacade.find(any(RecupParamLAB.class))).thenReturn(perimetreAca);

        //WHEN
        Perimetre actual = parametrageFacade.perimetre(pfsDto);

        //THEN
        assertEquals(perimetreAca, actual);
    }

    @Test
    void unknown_filiale_in_request_throws_exception() {
        //GIVEN
        pfsDto.getPerimetre().setFiliale("UNKNOWN");
        when(mapper.toRecupParamLAB(any(RecupParamRootReq.class))).thenReturn(recupParamLAB);
        when(recupParamLABFacade.find(any(RecupParamLAB.class))).thenThrow(NotFoundParameterValueException.class);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void too_many_profils_found_throws_exception() {
        //GIVEN
        pfsDto.getPerimetre().setFiliale("XXX");
        when(mapper.toRecupParamLAB(any(RecupParamRootReq.class))).thenReturn(recupParamLAB);
        when(recupParamLABFacade.find(any(RecupParamLAB.class))).thenThrow(TooManyProfilsException.class);

        //WHEN THEN
        assertThrows(TooManyProfilsException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void no_perimetre_found_throws_exception() {
        //GIVEN
        when(mapper.toRecupParamLAB(any(RecupParamRootReq.class))).thenReturn(recupParamLAB);
        when(recupParamLABFacade.find(any(RecupParamLAB.class))).thenThrow(NotFoundParameterValueException.class);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void no_pays_found_with_parameters() {
        //GIVEN
        when(inclusionPaysFacade.find(any(String.class), any(String.class), any(Date.class))).thenReturn(Collections.emptySet());

        //WHEN
        Set<InclusionPaysDto> actual = parametrageFacade.inclusions(pfsDto);

        //THEN
        assertEquals(Collections.EMPTY_SET, actual);
    }

    @Test
    void list_of_pays_found_with_parameters() {
        //GIVEN
        InclusionPays france = InclusionPays.builder().id(1L).pays("France").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("FR").build();
        InclusionPays espagne = InclusionPays.builder().id(2L).pays("Espagne").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("ES").build();
        Set<InclusionPays> pays = new HashSet<>(Arrays.asList(france, espagne));

        InclusionPaysDto franceDto = InclusionPaysDto.builder().id(1L).pays("France").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("FR").build();
        InclusionPaysDto espagneDto = InclusionPaysDto.builder().id(2L).pays("Espagne").typePays(TypePaysEnum.DOMICILIATION_BANCAIRE).codeIso("ES").build();
        Set<InclusionPaysDto> paysDto = new HashSet<>(Arrays.asList(franceDto, espagneDto));

        when(inclusionPaysFacade.find(any(String.class), any(String.class), any(Date.class))).thenReturn(pays);
        when(paysMapper.toDtoSet(anySet())).thenReturn(paysDto);

        //WHEN
        Set<InclusionPaysDto> actual = parametrageFacade.inclusions(pfsDto);

        //THEN
        assertEquals(2, actual.size());
        assertEquals(1, actual.stream().filter(p -> "France".equals(p.getPays())).count());
        assertEquals(1, actual.stream().filter(p -> "Espagne".equals(p.getPays())).count());
    }

    @Test
    void no_banques_found_with_parameters() {
        //GIVEN
        when(exclusionBanqueFacade.find(any(Date.class))).thenReturn(Collections.emptySet());

        //WHEN
        Set<ExclusionBanqueDto> actual = parametrageFacade.exclusions(pfsDto);

        //THEN
        assertEquals(Collections.EMPTY_SET, actual);
    }

    @Test
    void list_of_banques_found_with_parameters() {
        //GIVEN
        String lcl = "LCL";
        String bnp = "BNP";
        Date dateEffet = buildShortDate(2019, 12, 1);
        Date dateCreation = buildLongDate(2019, 12, 1);

        ExclusionBanque banqueLcl = ExclusionBanque.builder().banque(lcl).dateCreation(dateCreation).dateEffet(dateEffet).build();
        ExclusionBanque banqueBnp = ExclusionBanque.builder().banque(bnp).dateCreation(dateCreation).dateEffet(dateEffet).build();
        Set<ExclusionBanque> banques = new HashSet<>(Arrays.asList(banqueLcl, banqueBnp));

        ExclusionBanqueDto banqueDtoLcl = ExclusionBanqueDto.builder().banque(lcl).dateCreation(dateCreation).dateEffet(dateEffet).build();
        ExclusionBanqueDto banqueDtoBnp = ExclusionBanqueDto.builder().banque(bnp).dateCreation(dateCreation).dateEffet(dateEffet).build();
        Set<ExclusionBanqueDto> banquesDto = new HashSet<>(Arrays.asList(banqueDtoLcl, banqueDtoBnp));

        when(exclusionBanqueFacade.find(any(Date.class))).thenReturn(banques);
        when(banqueMapper.toDtoSet(anySet())).thenReturn(banquesDto);

        //WHEN
        Set<ExclusionBanqueDto> actual = parametrageFacade.exclusions(pfsDto);

        //THEN
        assertEquals(2, actual.size());
        assertEquals(1, actual.stream().filter(p -> lcl.equals(p.getBanque())).count());
        assertEquals(1, actual.stream().filter(p -> bnp.equals(p.getBanque())).count());
    }
}