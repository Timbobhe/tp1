package fr.ag2rlamondiale.paiementdigital.controller.admin;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static fr.ag2rlamondiale.paiementdigital.constantes.AdminConstantes.HEALTH_CHECK_OK;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class HealthCheckControllerTest {

    @Autowired
    private MockMvc mvc;

    private String uri = "/healthcheck";

    @Test
    void health_check_is_ok() throws Exception {
        //WHEN THEN
        mvc.perform(get(uri))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").value(HEALTH_CHECK_OK));
    }

}