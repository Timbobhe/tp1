package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.util.UriComponentsBuilder;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class GestionTokenFacadeImplIT {

    @Autowired
    private GestionTokenFacadeImpl gestionTokenFacade;

    @Autowired
    private PfsPropertyConfig pfsPropertyConfig;

    @Test
    public void token_uri_is_lmo_when_filiale_is_lmo() {
        //GIVEN
        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String structureJuridique = "LM";
        String filiale = "LMO";
        String token = pfsPropertyConfig.getTokenLMO();

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri, structureJuridique,filiale);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void token_uri_is_lm_when_filiale_is_not_lmo() {
        //GIVEN
        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String structureJuridique = "LM";
        String filiale = "ACA";
        String token = pfsPropertyConfig.getTokenLMO();

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, pfsPropertyConfig.getTokenLM())
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri, structureJuridique,filiale);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void token_uri_is_aca_when_filiale_is_ari() {

        //GIVEN
        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String structureJuridique = "ARI";
        String filiale = "ARI";
        String token = pfsPropertyConfig.getTokenARI();

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri,structureJuridique, filiale);

        //THEN
        assertEquals(expected, actual);


    }

    @Test
    public void token_uri_is_ari_when_filiale_is_lmr() {

        //GIVEN
        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String structureJuridique = "ARI";
        String filiale = "LMR";
        String token = pfsPropertyConfig.getTokenARI();

        String expected = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        String actual = gestionTokenFacade.getUriWithParams(uri,structureJuridique, filiale);

        //THEN
        assertEquals(expected, actual);


    }

}