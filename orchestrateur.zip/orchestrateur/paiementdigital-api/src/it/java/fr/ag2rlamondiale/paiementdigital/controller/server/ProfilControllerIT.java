package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ProfilDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.A1573;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.RET_SUP_COL;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
@ActiveProfiles("it")
class ProfilControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private String paramGetUri = "/api/profils";

    private String locahost = "http://localhost:";

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, paramGetUri);
    }

    @AfterEach
    void tearDown() {
        baseUrl = null;
    }

    @Test
    public void finding_profil_by_id_is_ok() throws URISyntaxException {
        //GIVEN
        HttpEntity<ProfilDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/1");

        //WHEN
        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(RET_SUP_COL, actual.getBody().getMetier());
        assertEquals(A1573, actual.getBody().getCodeApplication());
    }

    @Test
    public void finding_unknown_profil_by_id_is_404_status() throws URISyntaxException {
        //GIVEN
        HttpEntity<ProfilDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/1000");

        //WHEN
        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
    }

    @Test
    public void getting_all_profil_is_ok() throws URISyntaxException {
        //GIVEN
        HttpEntity<ProfilDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/all");

        //WHEN
        ResponseEntity<Set<ProfilDto>> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, new ParameterizedTypeReference<Set<ProfilDto>>() {
                });

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertTrue(actual.getBody().size() > 0);
    }
}