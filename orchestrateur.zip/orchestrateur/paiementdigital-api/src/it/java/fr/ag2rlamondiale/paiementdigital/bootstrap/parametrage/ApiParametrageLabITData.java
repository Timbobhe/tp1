package fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage;

import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamCliReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamPeriReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamProflReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import lombok.Getter;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.*;

@Component
@Getter
public class ApiParametrageLabITData {

    private RecupParamRootReq pfsDto;
    private Plafond plafond;
    private Perimetre perimetreAca;
    private Perimetre perimetreLmr;

    private RecupParamProfResp parametre;
    private Set<ExclusionBanqueDto> exclusions;
    private Set<InclusionPaysDto> inclusions;

    private RecupParamPlfdFreqResp ppf1d1;
    private RecupParamPlfdFreqResp ppf1d2;
    private RecupParamPlfdFreqResp ppf1d3;
    private RecupParamPlfdFreqResp ppf2d1;
    private RecupParamPlfdFreqResp ppf2d2;
    private RecupParamPlfdFreqResp ppf2d3;
    private RecupParamPlfdFreqResp ppf3d1;
    private RecupParamPlfdFreqResp ppf3d2;
    private RecupParamPlfdFreqResp ppf3d3;

    private Set<RecupParamPlfdFreqResp> plafonds1;
    private Set<RecupParamPlfdFreqResp> plafonds2;
    private Set<RecupParamPlfdFreqResp> plafonds3;

    private RecupParamPeriMethPaimtResp pmp1;
    private RecupParamPeriMethPaimtResp pmp2;
    private RecupParamPeriMethPaimtResp pmp3;
    private Set<RecupParamPeriMethPaimtResp> methodes;

    private PaiementDto paiementDto;

    public void setUp() throws ParseException {

        setUpPfsDtoRequest();

        setUpParamaLabDtoResponse();
    }

    private void setUpPfsDtoRequest() throws ParseException {
        RecupParamProflReq profil = RecupParamProflReq.builder()
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .build();

        RecupParamCliReq client = RecupParamCliReq.builder()
                .idUniqueClient("CLIENT_A")
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .build();

        RecupParamPeriReq perimetre = RecupParamPeriReq.builder()
                .structureJuridique(ARI)
                .filiale(ACA)
                .build();

        pfsDto = RecupParamRootReq.builder()
                .profil(profil)
                .client(client)
                .perimetre(perimetre)
                .dateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-08-05" ))
                .exclusionBanques(true)
                .inclusionPays(true)
                .build();

        paiementDto = PaiementDto.builder()
                .idUniqueClient(pfsDto.getClient().getIdUniqueClient())
                .metier(pfsDto.getProfil().getMetier())
                .codeApplication(pfsDto.getProfil().getCodeApplication())
                .evenementMetier(pfsDto.getProfil().getEvenementMetier())
                .natureClient(pfsDto.getClient().getNatureClient())
                .typeClient(pfsDto.getClient().getTypeClient())
                .tiersPayeur(pfsDto.getPerimetre().isTiersPayeur())
                .structureJuridique(pfsDto.getPerimetre().getStructureJuridique())
                .filiale(pfsDto.getPerimetre().getFiliale())
                .produit(pfsDto.getPerimetre().getProduit())
                .contratDeReference(pfsDto.getPerimetre().getContratDeReference())
                .contrat(pfsDto.getPerimetre().getContrat())
                .methodeDePaiement(MASTERCARD.name())
                .etatCourant(EtatEnum.CAPTURED)
                .build();
    }

    private void setUpParamaLabDtoResponse() {
        plafond = Plafond
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT)
                .montantMinimum(0F)
                .montantMaximum(1600F)
                .nombreMaximumPaiement(9)
                .build();

        ppf1d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(8000)
                .nombreMax(999)
                .montantMaxdispoClient(6496.04f)
                .nombreMaxDispoClient(995)
                .build();

        ppf1d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(3298.02f)
                .nombreMaxDispoClient(997)
                .build();

        ppf1d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(4000)
                .nombreMaxDispoClient(999)
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1d1, ppf1d2, ppf1d3));

        ppf2d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(8000)
                .nombreMax(999)
                .montantMaxdispoClient(5696.04F)
                .nombreMaxDispoClient(995)
                .build();

        ppf2d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(2898.02f)
                .nombreMaxDispoClient(997)
                .build();

        ppf2d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(4000)
                .nombreMaxDispoClient(999)
                .build();

        plafonds2 = new HashSet<>(Arrays.asList(ppf2d1, ppf2d2, ppf2d3));

        ppf3d1 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0)
                .montantMax(8000)
                .nombreMax(999)
                .montantMaxdispoClient(4896.04f)
                .nombreMaxDispoClient(995)
                .build();

        ppf3d2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(2498.02f)
                .nombreMaxDispoClient(997)
                .build();

        ppf3d3 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0)
                .montantMax(4000)
                .nombreMax(999)
                .montantMaxdispoClient(4000)
                .nombreMaxDispoClient(999)
                .build();

        plafonds3 = new HashSet<>(Arrays.asList(ppf3d1, ppf3d2, ppf3d3));

        pmp1 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(CB.name())
                .minMontantDispoClient(3298.02f)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(995)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .plafondsParFrequences(plafonds1)
                .build();

        pmp2 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(VISA.name())
                .minMontantDispoClient(2898.02f)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(995)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .plafondsParFrequences(plafonds2)
                .build();

        pmp3 = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(MASTERCARD.name())
                .minMontantDispoClient(2498.02f)
                .frequenceMinMontantDispoClient(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .minNombrePaiementDisponible(995)
                .frequenceNombrePaiementDisponible(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .plafondsParFrequences(plafonds3)
                .build();

        methodes = new HashSet<>(Arrays.asList(pmp1, pmp2, pmp3));

        String cards = Arrays.asList(CB.name(), VISA.name(), MASTERCARD.name()).stream().collect(Collectors.joining(",", "[", "]"));

        parametre = RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(3298.02f)
                .methodeMaxDesMontantsDispo("[" + CB.toString() + "]")
                .maxDesNombresDePaiementDispo(995)
                .methodeMaxDesNombresDePaiementDispo(cards)
                .perimetreMethodePaiement(methodes)
                .build();
    }

}
