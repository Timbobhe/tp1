package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierTransactionITData;
import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.net.URISyntaxException;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.exception.PaiementException.PAIEMENT_NOT_EXIST;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("it")
@Transactional
@AutoConfigureTestDatabase
@Disabled
class ModifierTransactionControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ApiSecurityConfig config;

    @Autowired
    private ApiModifierTransactionITData modifTransaData;

    private ResponseEntity<CreerTransaPaimtDigiRootResp> creerTransaResp;

    private String createTransaUri = "/api/transaction/create";

    private String updateTransaUri = "/api/transaction/update";

    private String locahost = "http://localhost:";

    private String createBaseUrl;

    private String updateBaseUrl;

    private String creerTransaOkJsonFile = "json/creer-transa-ok-req-it.json";

    private String orderId;

    private String idTransaction;

    private float montant;

    @BeforeEach
    void setUp() throws URISyntaxException {
        createBaseUrl = String.join(String.valueOf(randomServerPort), locahost, createTransaUri);
        updateBaseUrl = String.join(String.valueOf(randomServerPort), locahost, updateTransaUri);
        creerTransaResp = creerTransaction();
        idTransaction = creerTransaResp
                .getBody()
                .getCreationTransactionPaiementDigital()
                .getDetailTransactionPaiementDigital()
                .getIdTransaction();
        orderId = creerTransaResp
                .getBody()
                .getCreationTransactionPaiementDigital()
                .getEnteteTransactionPaiementDigital()
                .getOrderId();
        montant = creerTransaResp
                .getBody()
                .getCreationTransactionPaiementDigital()
                .getDetailMontantPaiement()
                .getMntTTC();
    }

    @AfterEach
    void tearDown() {
        createBaseUrl = null;
        updateBaseUrl = null;
        creerTransaResp = null;
        orderId = null;
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    public void modifier_transaction_gives_status_captured_when_given_id_transaction() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, montant, idTransaction);
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        ModifTransaResp modifTransaResp = actual.getBody().getModifTransaResp();
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertNull(actual.getBody().getEtatCourant());
        assertNull(actual.getBody().getCodeErreur());
        assertNull(actual.getBody().getMessageErreur());
        assertEquals(idTransaction, modifTransaResp.getDetailTransactionPaiementNumerise().getIdTransaction());
        assertEquals(orderId, modifTransaResp.getDetailTransactionPaiementNumerise().getOrderId());
        assertEquals(EtatEnum.CAPTURED.name(), modifTransaResp.getEtatCourant());
        assertEquals(STT_CODE_CAPTURED_OK, modifTransaResp.getStatus());
        assertEquals(CAPTURED, modifTransaResp.getMessage());
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    public void modifier_transaction_gives_status_captured_when_not_given_id_transaction() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, montant);
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        ModifTransaResp modifTransaResp = actual.getBody().getModifTransaResp();
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertNull(actual.getBody().getEtatCourant());
        assertNull(actual.getBody().getCodeErreur());
        assertNull(actual.getBody().getMessageErreur());
        assertEquals(idTransaction, modifTransaResp.getDetailTransactionPaiementNumerise().getIdTransaction());
        assertEquals(orderId, modifTransaResp.getDetailTransactionPaiementNumerise().getOrderId());
        assertEquals(EtatEnum.CAPTURED.name(), modifTransaResp.getEtatCourant());
        assertEquals(STT_CODE_CAPTURED_OK, modifTransaResp.getStatus());
        assertEquals(CAPTURED, modifTransaResp.getMessage());
    }

    //Cas FAIL Non testable pour le moment (cf. métier)
    public void modifier_transaction_gives_status_fail() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, montant, idTransaction);
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        ModifTransaResp modifTransaResp = actual.getBody().getModifTransaResp();
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertNull(actual.getBody().getEtatCourant());
        assertNull(actual.getBody().getCodeErreur());
        assertNull(actual.getBody().getMessageErreur());
        assertEquals(idTransaction, modifTransaResp.getDetailTransactionPaiementNumerise().getIdTransaction());
        assertEquals(orderId, modifTransaResp.getDetailTransactionPaiementNumerise().getOrderId());
        assertEquals(EtatEnum.FAIL.name(), modifTransaResp.getEtatCourant());
        assertEquals(STT_CODE_CAPTURE_FAIL, modifTransaResp.getStatus());
        assertEquals(STT_MSG_CAPTURE_REFUSED, modifTransaResp.getMessage());
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    public void modifier_transaction_gives_status_pfs_func_error_on_montant() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, 500.00f, idTransaction);
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        assertEquals(HttpStatus.BAD_REQUEST, actual.getStatusCode());
        assertEquals(EtatEnum.ERROR.name(), actual.getBody().getEtatCourant());
        assertEquals(A1532_FUNC_CALL_SA, actual.getBody().getCodeErreur());
        assertNotNull(actual.getBody().getMessageErreur());
        assertNull(actual.getBody().getModifTransaResp());
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    public void modifier_transaction_gives_status_pfs_func_error_on_type_operation() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, montant, idTransaction);
        modifTransa.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().setTypeOperationTransactionPaiementDigital("UNKNOWN");
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(EtatEnum.ERROR.name(), actual.getBody().getEtatCourant());
        assertEquals("A1532-TECH-BWENGINE", actual.getBody().getCodeErreur());
        assertNotNull(actual.getBody().getMessageErreur());
        assertNull(actual.getBody().getModifTransaResp());
    }

    @Test
    public void modifier_transaction_gives_status_bo_error_when_error_on_idTransacion() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(updateBaseUrl);
        ModifTransaRootReq modifTransa = modifTransaData.buildRequest(orderId, montant, "123456789");
        HttpEntity<ModifTransaRootReq> modifTransaReq = new HttpEntity<>(modifTransa, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<ModifTransaRootResp> actual = testRestTemplate.exchange(uri, HttpMethod.PUT, modifTransaReq, ModifTransaRootResp.class);

        // THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(EtatEnum.ERROR.name(), actual.getBody().getEtatCourant());
        assertEquals(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), actual.getBody().getCodeErreur());
        assertEquals(PAIEMENT_NOT_EXIST, actual.getBody().getMessageErreur());
        assertNull(actual.getBody().getModifTransaResp());
    }

    private ResponseEntity<CreerTransaPaimtDigiRootResp> creerTransaction() throws URISyntaxException {
        URI uri = new URI(createBaseUrl);
        CreerTransaPaimtDigiRootReq creerTransa = JsonUtils.transactionRequest(creerTransaOkJsonFile);
        HttpEntity<CreerTransaPaimtDigiRootReq> creerTransaReq = new HttpEntity<>(creerTransa, getHttpAuthHeaders());
        return testRestTemplate.postForEntity(uri, creerTransaReq, CreerTransaPaimtDigiRootResp.class);
    }
}