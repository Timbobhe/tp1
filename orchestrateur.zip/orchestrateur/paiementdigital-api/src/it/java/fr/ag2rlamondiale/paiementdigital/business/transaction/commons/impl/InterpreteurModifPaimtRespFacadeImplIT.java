package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.transaction.Transactional;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.STT_CODE_CAPTURE_FAIL;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A0487_TECH_PARSING;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
class InterpreteurModifPaimtRespFacadeImplIT {

    @Autowired
    private IInterpreteurPfsResponseFacade<ModifPaimtRootResp, Paiement> interpretFacade;

    @Autowired
    private ApiModifierPaiementITData modifPaimtData;

    @Autowired
    private ApiPaiementITData paiementData;

    @Autowired
    private IPaiementRepository repository;

    private Paiement paiement;

    private String orderId;

    private String idTransaction;

    @BeforeEach
    void setUp() {
        float montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CAPTURE);
        paiement.setHistoriques(paiementData.modifTransaEtats(CAPTURE, montant, null, null, paiement));
        paiement = repository.save(paiement);
    }

    @AfterEach
    void tearDown() {
        paiement = null;
        orderId = null;
        idTransaction = null;
    }

    @Test
    public void parameters_are_null_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(null, null));
    }

    @Test
    public void paiement_is_captured_status_200_stt_118() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200(idTransaction);
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(EtatEnum.CAPTURED, actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> CAPTURED.equals(h.getEtat())).count());
    }

    @Test
    public void paiement_is_fail_status_200_stt_173() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200(idTransaction);
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setStt(STT_CODE_CAPTURE_FAIL);
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setMsg("Fail");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(FAIL, actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> FAIL.equals(h.getEtat())).count());
    }

    @Test
    public void paiement_status_200_stt_unknown_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200(idTransaction);
        modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc()
                .getPaimtDigi().setStt("999");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(response, paiement));
    }

    @Test
    public void paiement_is_4xx_status() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.BAD_REQUEST);

        //WHEN
        Paiement actual = interpretFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR, actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).count());
    }

    @Test
    public void status_not_200_nor_4xx_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(A0487_TECH_PARSING, "error generated by Generate Error - Job-35531");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.INTERNAL_SERVER_ERROR);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> interpretFacade.interpreteur(response, paiement));
    }
}