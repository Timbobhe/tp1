package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.CustomData;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.ERROR;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.FAIL;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;

@Transactional
@SpringBootTest
class CreerTransaRespBuilderFacadeImplIT {

    @Autowired
    private ApiPaiementITData paiementData;

    @Autowired
    private ICreerTransaRespBuilderFacade creerTransaFacade;

    @Autowired
    private IPaiementRepository repository;

    private Paiement paiement;

    private String creerPaimtDigiRespOkFilename = "json/creer-paimt-digi-rep-116-it.json";

    private String creerPaimtDigiRespFailFilename = "json/creer-paimt-digi-rep-113-it.json";

    private String creerPaimtDigiRespErrorFilename = "json/creer-paimt-digi-rep-400-it.json";

    private float montant;

    private String orderId;

    private String idTransaction;

    private Set<CustomData> customDatas;

    private String status = "3010004";

    private String message = "This order has already been paid";

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        EtatEnum etat = EtatEnum.AUTHORIZATION;
        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, etat);

        CustomData c1 = CustomData.builder().paiement(paiement).ordre(1).cdata(TransactionConstantes.ARI).build();
        CustomData c2 = CustomData.builder().paiement(paiement).ordre(2).cdata("RG01002ARI").build();
        CustomData c3 = CustomData.builder().paiement(paiement).ordre(3).cdata("1311014").build();
        CustomData c4 = CustomData.builder().paiement(paiement).ordre(4).cdata("A0499").build();
        CustomData c5 = CustomData.builder().paiement(paiement).ordre(5).cdata("P5049181").build();
        customDatas = new HashSet<>(Arrays.asList(c1, c2, c3, c4, c5));

        paiement.setHistoriques(paiementData.creerTransaEtats(etat, montant, status, message, paiement));
        paiement.setCustomDatas(customDatas);
        paiement = repository.save(paiement);
    }

    @AfterEach
    void tearDown() {
        idTransaction = null;
        orderId = null;
        customDatas = null;
        paiement = null;
    }

    @Test
    public void invalid_parameters_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> creerTransaFacade.build(null, null));
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_authorized() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> creerTransaPaimtDigiResp = getCreerTransaction(creerPaimtDigiRespOkFilename, HttpStatus.OK);

        //WHEN
        CreerTransaPaimtDigiRootResp actual = creerTransaFacade.build(paiement, creerTransaPaimtDigiResp);

        //THEN
        assertEquals(EtatEnum.AUTHORIZED, actual.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_fail() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> creerTransaPaimtDigiResp = getCreerTransaction(creerPaimtDigiRespFailFilename, HttpStatus.OK);

        //WHEN
        CreerTransaPaimtDigiRootResp actual = creerTransaFacade.build(paiement, creerTransaPaimtDigiResp);

        //THEN
        assertEquals(FAIL, actual.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
    }

    @Test
    void build_response_for_sa_transaction_if_pfs_hipay_error() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> creerTransaPaimtDigiResp = getCreerTransaction(creerPaimtDigiRespErrorFilename, HttpStatus.BAD_REQUEST);

        //WHEN
        CreerTransaPaimtDigiRootResp actual = creerTransaFacade.build(paiement, creerTransaPaimtDigiResp);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(status, actual.getCodeErreur());
        assertEquals(message, actual.getMessageErreur());
        assertNull(actual.getCreationTransactionPaiementDigital());
    }

    private ResponseEntity<CreerPaimtDigiRootResp> getCreerTransaction(String filename, HttpStatus status) {
        CreerPaimtDigiRootResp creerPaiementDigitalResponseDto = JsonUtils.paiementResponse(filename);
        return new ResponseEntity<>(creerPaiementDigitalResponseDto, status);
    }
}