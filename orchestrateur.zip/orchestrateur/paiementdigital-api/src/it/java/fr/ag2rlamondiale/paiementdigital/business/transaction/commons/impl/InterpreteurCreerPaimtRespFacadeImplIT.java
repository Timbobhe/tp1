package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.*;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.transaction.Transactional;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_CALL_SA;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_TECH_DEFAULT;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
class InterpreteurCreerPaimtRespFacadeImplIT {

    @Autowired
    private IInterpreteurPfsResponseFacade<CreerPaimtDigiRootResp, Paiement> interpreteurFacade;

    @Autowired
    private ApiPaiementITData paiementData;

    @Autowired
    private IPaiementRepository repository;

    private Paiement paiement;

    private String orderId;

    private String idTransaction;

    float montant;

    private String creerPaimtDigiRespOkFilename = "json/creer-paimt-digi-rep-116-it.json";

    private String creerPaimtDigiRespFailFilename = "json/creer-paimt-digi-rep-113-it.json";

    private String creerPaimtDigiRespErrorFilename = "json/creer-paimt-digi-rep-400-it.json";

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();

        paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZATION);
        paiement.setHistoriques(paiementData.creerTransaEtats(AUTHORIZATION, montant, null, null, paiement));
        paiement = repository.save(paiement);

    }

    @AfterEach
    void tearDown() {
        orderId = null;
        idTransaction = null;
        paiement = null;
    }

    @Test
    public void parameters_are_null_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(null, null));
    }

    @Test
    public void creer_paiement_status_ok_with_cpl_code_sit_is_ok() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespOkFilename, HttpStatus.OK);
        response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi()
                .getPaimtDigi().getDetTransaPaimtNumerise().setRefTransPaimtDigi(idTransaction);
        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(AUTHORIZED, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> AUTHORIZED.equals(h.getEtat())).findAny();
        assertNull(historique.get().getStatus());
        assertNull(historique.get().getMessage());
    }

    @Test
    public void creer_paiement_status_ok_with_ann_code_sit_is_ok() {
        //GIVEN
        // Le montant 13.04 simule auprès de Hipay une erreur en 400
        montant = 13.04f;
        paiement.setMontant(montant);
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespFailFilename, HttpStatus.OK);
        response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi()
                .getPaimtDigi().getDetTransaPaimtNumerise().setRefTransPaimtDigi(idTransaction);
        DetTransaPaimtNumeriseResp detTransaPaimtNum = response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise();

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(FAIL, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> FAIL.equals(h.getEtat())).findAny();
        assertEquals(detTransaPaimtNum.getCodeTechSitTransaPaimtDigi(), historique.get().getStatus());
        assertEquals(detTransaPaimtNum.getLibSitTransaPaimtDigi(), historique.get().getMessage());
    }

    @Test
    public void creer_paiement_status_ok_with_unknown_code_sit_throws_exception() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespFailFilename, HttpStatus.OK);
        PaimtDigiResp paimtDigi = response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi()
                .getPaimtDigi();
        paimtDigi.getDetTransaPaimtNumerise().setRefTransPaimtDigi(idTransaction);
        paimtDigi.getDetTransaPaimtNumerise().setCodeSitTransaPaimtDigi("UNKNOWN_CODESIT");

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }

    @Test
    public void creer_paiement_status_4xx_pfs_func_error() {
        //GIVEN
        String code = A1532_FUNC_CALL_SA;
        String message = "The Http Server replied with a 4XX status code";
        String funcErrorMsg = "[A1532] Erreur renvoyee par le Service Applicatif:  :The Http Server replied with a 4XX status code";
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespErrorFilename, HttpStatus.BAD_REQUEST);
        HeaderResp header = response.getBody().getResponse().getHeader();
        header.setFuncError(Arrays.asList(ErrorResp.builder().errorCode(code).errorMessage(funcErrorMsg).build()));

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertNull(actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).findAny();
        assertEquals(code, historique.get().getStatus());
        assertEquals(message, historique.get().getMessage());
    }

    @Test
    public void creer_paiement_status_4xx_hipay_func_error() {
        //GIVEN
        String code = "3010004";
        String message = "This order has already been paid";
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespErrorFilename, HttpStatus.BAD_REQUEST);

        //WHEN
        Paiement actual = interpreteurFacade.interpreteur(response, paiement);

        //THEN
        assertEquals(ERROR, actual.getEtatCourant());
        assertEquals(montant, actual.getMontant());
        assertNull(actual.getIdTransaction());
        assertEquals(3, actual.getHistoriques().size());
        Optional<Historique> historique = actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).findAny();
        assertEquals(code, historique.get().getStatus());
        assertEquals(message, historique.get().getMessage());
    }

    @Test
    public void creer_paiement_status_5xx_pfs_func_error() {
        //GIVEN
        String code = A1532_TECH_DEFAULT;
        String funcErrorMsg = "error generated by Generate Error - Job-35531";
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespErrorFilename, HttpStatus.INTERNAL_SERVER_ERROR);
        HeaderResp header = response.getBody().getResponse().getHeader();
        header.setTechError(Arrays.asList(ErrorResp.builder().errorCode(code).errorMessage(funcErrorMsg).build()));

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }

    @Test
    public void unknown_id_paiement_throws_exception() {
        //GIVEN
        ResponseEntity<CreerPaimtDigiRootResp> response = getCreerTransaction(creerPaimtDigiRespOkFilename, HttpStatus.OK);
        response.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi()
                .getPaimtDigi().getDetTransaPaimtNumerise().setRefTransPaimtDigi(idTransaction);
        paiement.setId(100000000000L);

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> interpreteurFacade.interpreteur(response, paiement));
    }

    private ResponseEntity<CreerPaimtDigiRootResp> getCreerTransaction(String filename, HttpStatus status) {
        CreerPaimtDigiRootResp creerPaiementDigitalResponseDto = JsonUtils.paiementResponse(filename);
        return new ResponseEntity<>(creerPaiementDigitalResponseDto, status);
    }
}