package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.net.URISyntaxException;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.ANN;

@Transactional
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("it")
@AutoConfigureTestDatabase
@Disabled
class CreerTransactionControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ApiSecurityConfig config;

    private String transaURI = "/api/transaction";

    private String locahost = "http://localhost:";

    private String transactionRequest = "json/creer-transaction-req-ok-test.json";

    private String transactionRequestWrong = "json/creer-transa-statut-400-req-it.json";

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, transaURI);

    }

    @AfterEach
    void tearDown() {
        baseUrl = null;
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    void insertion_transaction_authorized_return_bad_request_with_error_status() throws URISyntaxException {
        //GIVEN
        String insertTransaEndpoint = "/create";
        URI uri = new URI(baseUrl + insertTransaEndpoint);
        CreerTransaPaimtDigiRootReq transactionReq = JsonUtils.transactionRequest(transactionRequestWrong);
        HttpEntity<CreerTransaPaimtDigiRootReq> request = new HttpEntity<>(transactionReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<CreerTransaPaimtDigiRootResp> actual = testRestTemplate.postForEntity(uri, request, CreerTransaPaimtDigiRootResp.class);

        //THEN
        assertEquals(HttpStatus.BAD_REQUEST, actual.getStatusCode());
        assertEquals(EtatEnum.ERROR, actual.getBody().getEtatCourant());
        assertNotNull(actual.getBody().getMessageErreur());
        assertNotNull(actual.getBody().getCodeErreur());
    }

    @Test
    @DirtiesContext(methodMode = DirtiesContext.MethodMode.BEFORE_METHOD)
    void insertion_transaction_authorized_return_ok() throws URISyntaxException {
        //GIVEN
        String insertTransaEndpoint = "/create";
        URI uri = new URI(baseUrl + insertTransaEndpoint);
        CreerTransaPaimtDigiRootReq transactionReq = JsonUtils.transactionRequest(transactionRequest);
        HttpEntity<CreerTransaPaimtDigiRootReq> request = new HttpEntity<>(transactionReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<CreerTransaPaimtDigiRootResp> actual = testRestTemplate.postForEntity(uri, request, CreerTransaPaimtDigiRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(EtatEnum.AUTHORIZED, actual.getBody().getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertEquals(transactionReq.getDetailMontantPaiement().getMontantTTC(), actual.getBody().getCreationTransactionPaiementDigital().getDetailMontantPaiement().getMntTTC());
    }


    @Test
    void insertion_transaction_fail_return_ok_with_etat_fail() throws URISyntaxException {
        //GIVEN
        String insertTransaEndpoint = "/create";
        URI uri = new URI(baseUrl + insertTransaEndpoint);
        CreerTransaPaimtDigiRootReq transactionReq = JsonUtils.transactionRequest(transactionRequest);
        transactionReq.getDetailMontantPaiement().setMontantTTC(13.04f);
        HttpEntity<CreerTransaPaimtDigiRootReq> request = new HttpEntity<>(transactionReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<CreerTransaPaimtDigiRootResp> actual = testRestTemplate.postForEntity(uri, request, CreerTransaPaimtDigiRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(EtatEnum.FAIL, actual.getBody().getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().getEtatCourant());
        assertEquals(transactionReq.getDetailMontantPaiement().getMontantTTC(), actual.getBody().getCreationTransactionPaiementDigital().getDetailMontantPaiement().getMntTTC());
    }
}