package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;


@SpringBootTest
@Transactional
@ActiveProfiles("it")
class ResponseBuilderFacadeImplIT {

    @Autowired
    private IParametrageFacade parametrageFacade;

    @Autowired
    private IResponseBuilderFacade builderFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabData;

    private RecupParamRootReq pfsDto;
    private RecupParamProfResp parametre;
    private Set<RecupParamPlfdFreqResp> plafonds1;
    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabData.setUp();

        pfsDto = parametrageLabData.getPfsDto();
        parametre = parametrageLabData.getParametre();
        plafonds1 = parametrageLabData.getPlafonds1();
        methodes = parametrageLabData.getMethodes();

    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        parametre = null;
        plafonds1 = null;
        methodes = null;
    }

    @Test
    public void build_recuperer_parametrages_lab_dto_is_ok() {
        //GIVEN
        Set<ExclusionBanqueDto> exclusions = parametrageFacade.exclusions(pfsDto);
        Set<InclusionPaysDto> inclusions = parametrageFacade.inclusions(pfsDto);

        RecupParamRootResp expected = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();

        //WHEN
        RecupParamRootResp actual = builderFacade.build(parametre, exclusions, inclusions);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void build_parametres_profils_dto_is_ok() {
        //GIVEN
        float max = 300;
        String methodeMax = MethodePaiementEnum.CB.name();
        int nombre = 4;
        String methodeNombre = MethodePaiementEnum.VISA.name();

        RecupParamProfResp expected = RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(max)
                .methodeMaxDesMontantsDispo(methodeMax)
                .maxDesNombresDePaiementDispo(nombre)
                .methodeMaxDesNombresDePaiementDispo(methodeNombre)
                .perimetreMethodePaiement(methodes)
                .build();

        //WHEN
        RecupParamProfResp actual = builderFacade.build(max, methodeMax, nombre, methodeNombre, methodes);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void build_perimetre_methode_paiement_dto_is_ok() {
        //GIVEN
        String methodeName = MethodePaiementEnum.CB.name();
        float minMontant = 300;
        String frequenceMontant = TypeFrequenceEnum.MOIS_GLISSANT.name();
        int minNombre = 3;
        String frequenceNombre = TypeFrequenceEnum.MOIS_GLISSANT.name();

        RecupParamPeriMethPaimtResp expected = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(methodeName)
                .frequenceMinMontantDispoClient(frequenceMontant)
                .minMontantDispoClient(minMontant)
                .frequenceNombrePaiementDisponible(frequenceNombre)
                .minNombrePaiementDisponible(minNombre)
                .plafondsParFrequences(plafonds1)
                .build();

        //WHEN
        RecupParamPeriMethPaimtResp actual = builderFacade.build(methodeName, minMontant, frequenceMontant,
                minNombre, frequenceNombre, plafonds1);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void build_plafonds_par_frequences_dto_is_ok() {
        //GIVEN
        Plafond plafond = Plafond
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT)
                .montantMinimum(0F)
                .montantMaximum(1000F)
                .nombreMaximumPaiement(5)
                .build();

        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(500)
                .nombreMaxDispoClient(3)
                .build();
        //WHEN
        RecupParamPlfdFreqResp actual = builderFacade.build(plafond, 500, 3);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }
}