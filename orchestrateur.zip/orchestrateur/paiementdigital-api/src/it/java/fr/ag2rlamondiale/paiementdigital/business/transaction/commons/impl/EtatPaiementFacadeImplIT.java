package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierTransactionITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;

import javax.transaction.Transactional;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_TECH_DEFAULT;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@SpringBootTest
@AutoConfigureTestDatabase
class EtatPaiementFacadeImplIT {

    @Autowired
    private IEtatPaiementFacade facade;

    @Autowired
    private ApiModifierTransactionITData modifTransaData;

    @Autowired
    private ApiPaiementITData paiementData;

    @Autowired
    private IPaiementRepository repository;

    private String orderId;

    private String idTransaction;

    private float montant;

    @BeforeEach
    void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
    }

    @AfterEach
    void tearDown() {
        orderId = null;
        idTransaction = null;
    }

    @Test
    public void create_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> facade.create(null));
    }

    @Test
    public void authorization_null_paiement_throws_exception() {
        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> facade.authorization(null));
    }

    @Transactional
    @Test
    public void update_paiement_to_authorization_is_success() {
        //GIVEN
        Paiement paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CREATE);
        paiement.setHistoriques(paiementData.modifTransaEtats(CREATE, montant, null, null, paiement));
        repository.save(paiement);

        //WHEN
        Paiement actual = facade.authorization(paiement);

        //THEN
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(EtatEnum.AUTHORIZATION, actual.getEtatCourant());
        assertEquals(2, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> AUTHORIZATION.equals(h.getEtat())).count());
    }

    @Test
    public void update_unknown_paiement_throws_exception() {
        //GIVEN
        Paiement paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CREATE);
        paiement.setHistoriques(paiementData.modifTransaEtats(CREATE, montant, null, null, paiement));
        paiement.setId(100000L);

        //WHEN THEN
        assertThrows(CreerTransactionException.class, () -> facade.authorization(paiement));
    }

    @Test
    public void capture_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.capture(null));
    }

    @Test
    public void unknown_id_transaction_throws_exception() {
        //GIVEN
        ModifTransaRootReq request = modifTransaData.buildRequest(orderId, montant, idTransaction);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.capture(request));
    }

    @Transactional
    @Test
    public void update_paiment_to_capture_is_ok() {
        //GIVEN
        Paiement paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        paiement.setHistoriques(paiementData.modifTransaEtats(AUTHORIZED, montant, null, null, paiement));
        repository.save(paiement);

        ModifTransaRootReq request = modifTransaData.buildRequest(orderId, montant, idTransaction);

        //WHEN
        Paiement actual = facade.capture(request);

        //THEN
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(EtatEnum.CAPTURE, actual.getEtatCourant());
        assertEquals(4, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> CAPTURE.equals(h.getEtat())).count());
    }

    @Test
    public void error_null_request_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.error(null, null, null));
    }

    @Transactional
    @Test
    public void update_paiment_to_error_is_ok() {
        //GIVEN
        Paiement paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, CAPTURE);
        paiement.setHistoriques(paiementData.modifTransaEtats(CAPTURE, montant, null, null, paiement));
        repository.save(paiement);

        //WHEN
        Paiement actual = facade.error(paiement, A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531");

        //THEN
        assertEquals(montant, actual.getMontant());
        assertEquals(idTransaction, actual.getIdTransaction());
        assertEquals(EtatEnum.ERROR, actual.getEtatCourant());
        assertEquals(5, actual.getHistoriques().size());
        assertEquals(1, actual.getHistoriques().stream().filter(h -> ERROR.equals(h.getEtat())).count());
    }

    @Transactional
    @Test
    public void error_paiment_update_throws_exception() {
        //GIVEN
        Paiement paiement = paiementData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, ERROR);
        paiement.setHistoriques(paiementData.modifTransaEtats(ERROR, montant, INTERNAL_SERVER_ERROR.name(), "Anomalie interne", paiement));
        paiement.setId(1003333L);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.error(paiement, INTERNAL_SERVER_ERROR.name(), "Anomalie interne"));
    }

}