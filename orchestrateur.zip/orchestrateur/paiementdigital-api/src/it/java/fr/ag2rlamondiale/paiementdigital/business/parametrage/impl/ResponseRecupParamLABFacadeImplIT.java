package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamProflReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.A1573;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional

@ActiveProfiles("it")
class ResponseRecupParamLABFacadeImplIT {

    @Autowired
    private IParametrageFacade parametrageFacade;

    @Autowired
    private IResponseRecupParamLABFacade recupParamLABFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabData;

    private RecupParamRootReq pfsDto;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabData.setUp();

        pfsDto = parametrageLabData.getPfsDto();

    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
    }

    @Test
    @Disabled
    public void parametrage_lab_found() {
        //GIVEN
        Set<ExclusionBanqueDto> exclusions = parametrageFacade.exclusions(pfsDto);
        Set<InclusionPaysDto> inclusions = parametrageFacade.inclusions(pfsDto);

        //WHEN
        RecupParamRootResp actual = recupParamLABFacade.recupererParametragesLab(pfsDto);

        //THEN
        assertEquals(HttpStatus.OK.value(), actual.getCode());
        assertEquals(exclusions.size(), actual.getExclusions().size());
        assertEquals(inclusions.size(), actual.getInclusions().size());
        assertEquals(1600, actual.getParametresProfilsDto().getMaxDesMontantsDispo());
    }

    @Test
    public void parametrage_lab_throws_not_found_parameter_exception() {
        RecupParamProflReq profil = RecupParamProflReq.builder()
                .metier("UNKNOWN_METIER")
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .build();

        pfsDto.setProfil(profil);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.recupererParametragesLab(pfsDto));
    }

    @Test
    public void parametrage_lab_throws_incorrect_parameter_exception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> recupParamLABFacade.recupererParametragesLab(null));
    }

}