package fr.ag2rlamondiale.paiementdigital.security;

import fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ProfilDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.test.context.ActiveProfiles;

import java.net.URI;
import java.net.URISyntaxException;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes.CODE_APPLI_BO_PMT_DIGI;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes.CODE_APPLI_PFS;
import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("it")
public class JwtTokenIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private String paramGetUri = "/api/profils";

    private String locahost = "http://localhost:";

    private String baseUrl;

    private ProfilDto profilDto;

    @BeforeEach
    void setUp() {
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, paramGetUri);
    }

    @AfterEach
    void tearDown() {
        profilDto = null;
        baseUrl = null;
    }

    @Test
    public void token_jwt_is_ok() throws URISyntaxException {
        //GIVEN
        HttpEntity<ProfilDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/99999");

        //WHEN
        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
    }

    @Test
    public void validity_token_jwt_is_not_enough() throws URISyntaxException {
        //GIVEN
        HttpHeaders httpHeaders = getHttpAuthHeaders();
        String token = SecurityITData.createToken(CODE_APPLI_BO_PMT_DIGI, CODE_APPLI_PFS, 0);
        httpHeaders.set(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token);
        HttpEntity<?> request = new HttpEntity<>(httpHeaders);
        URI uri = new URI(baseUrl + "/1");

        //WHEN
        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED, actual.getStatusCode());
    }

    @Test
    public void audience_token_jwt_is_not_enough() throws URISyntaxException {
        //GIVEN
//        HttpHeaders httpHeaders = getHttpAuthHeaders();
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        String token = SecurityITData.createToken("UNKNOWN", CODE_APPLI_PFS, 360000);
        httpHeaders.add(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token);
        HttpEntity<?> request = new HttpEntity<>(httpHeaders);
        URI uri = new URI(baseUrl + "/1");

        //WHEN

        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED, actual.getStatusCode());
    }

    @Test
    public void issuer_token_jwt_is_not_enough() throws URISyntaxException {
        //GIVEN
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        String token = SecurityITData.createToken(CODE_APPLI_BO_PMT_DIGI, "A1234", 360000);
        httpHeaders.add(SecurityConstantes.AUTHORIZATION, SecurityConstantes.BEARER_PREFIX + token);
        HttpEntity<?> request = new HttpEntity<>(httpHeaders);
        URI uri = new URI(baseUrl + "/1");

        //WHEN
        ResponseEntity<ProfilDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ProfilDto.class);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED, actual.getStatusCode());
    }
}
