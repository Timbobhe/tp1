package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseCalculFacade;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@ActiveProfiles("it")
class ResponseCalculFacadeImplIT {

    @Autowired
    private IResponseCalculFacade calculFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabData;

    private RecupParamPlfdFreqResp ppf1;
    private Set<RecupParamPlfdFreqResp> plafonds1;
    private Set<RecupParamPeriMethPaimtResp> methodes;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabData.setUp();

        ppf1 = parametrageLabData.getPpf1d1();
        plafonds1 = parametrageLabData.getPlafonds1();
        methodes = parametrageLabData.getMethodes();

    }

    @AfterEach
    void tearDown() {
        plafonds1 = null;
        ppf1 = null;
        methodes = null;
    }

    @Test
    public void max_des_montants_dispo_gives_3298_02() {
        //WHEN
        float actual = calculFacade.maxDesMontantsDispo(methodes);

        //THEN
        assertEquals(3298.02f, actual);
    }

    @Test
    public void methode_max_des_montants_dispo_contains_mastercard_visa_cb() {
        //WHEN
        String actual = calculFacade.methodeMaxDesMontantsDispo(methodes, 3298.02f);

        //THEN
        assertTrue(actual.contains(MethodePaiementEnum.CB.name()));
        assertFalse(actual.contains(MethodePaiementEnum.VISA.name()));
        assertFalse(actual.contains(MethodePaiementEnum.MASTERCARD.name()));
    }

    @Test
    public void max_des_nombres_de_paiement_dispo_gives_995() {
        //WHEN
        int actual = calculFacade.maxDesNombresDePaiementDispo(methodes);

        //THEN
        assertEquals(995, actual);
    }

    @Test
    public void methode_max_des_nombres_de_paiement_dispo_contains_mastercard_visa_cb() {
        //WHEN
        String actual = calculFacade.methodeMaxDesNombresDePaiementDispo(methodes, 995);

        //THEN
        assertTrue(actual.contains(MethodePaiementEnum.CB.name()));
        assertTrue(actual.contains(MethodePaiementEnum.VISA.name()));
        assertTrue(actual.contains(MethodePaiementEnum.MASTERCARD.name()));
    }

    @Test
    public void min_montant_dispo_client_gives_3298_02() {
        //WHEN
        float actual = calculFacade.minMontantDispoClient(plafonds1);

        //THEN
        assertEquals(3298.02f, actual);
    }

    @Test
    public void frequence_min_montant_dispo_client_gives_mois_glissant() {
        //WHEN
        String actual = calculFacade.frequenceMinMontantDispoClient(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual);
    }

    @RepeatedTest(3)
    public void frequence_min_montant_dispo_client_doublon_gives_mois_glissant() {
        //GIVEN
        RecupParamPlfdFreqResp ppf2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(ppf1.getMontantMin())
                .montantMax(ppf1.getMontantMax())
                .nombreMax(ppf1.getNombreMax())
                .montantMaxdispoClient(ppf1.getMontantMaxdispoClient())
                .nombreMaxDispoClient(ppf1.getNombreMaxDispoClient())
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1, ppf2));

        //WHEN
        String actual = calculFacade.frequenceMinMontantDispoClient(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual);
    }

    @Test
    public void min_nombre_paiement_disponible_gives_995() {
        //WHEN
        int actual = calculFacade.minNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(995, actual);
    }

    @Test
    public void frequence_nombre_paiement_disponible_gives_annee_civile() {
        //WHEN
        String actual = calculFacade.frequenceNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.ANNEE_CIVILE.name(), actual);
    }

    @RepeatedTest(3)
    public void frequence_nombre_paiement_disponible_doublon_gives_mois_glissant() {
        //GIVEN
        RecupParamPlfdFreqResp ppf2 = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(ppf1.getMontantMin())
                .montantMax(ppf1.getMontantMax())
                .nombreMax(ppf1.getNombreMax())
                .montantMaxdispoClient(ppf1.getMontantMaxdispoClient())
                .nombreMaxDispoClient(ppf1.getNombreMaxDispoClient())
                .build();

        plafonds1 = new HashSet<>(Arrays.asList(ppf1, ppf2));

        //WHEN
        String actual = calculFacade.frequenceNombrePaiementDisponible(plafonds1);

        //THEN
        assertEquals(TypeFrequenceEnum.MOIS_GLISSANT.name(), actual);
    }

    @Test
    public void montant_max_dispo_client_gives_40() {
        //GIVEN
        List<Float> montantsCaptured = Arrays.asList(10F, 20F, 30F);

        //WHEN
        float actual = calculFacade.montantMaxDispoClient(100, montantsCaptured);

        //THEN
        assertEquals(40, actual);
    }

    @Test
    public void montant_max_dispo_client_gives_100() {
        //WHEN
        float actual = calculFacade.montantMaxDispoClient(100, null);

        //THEN
        assertEquals(100, actual);
    }

    @Test
    public void nombre_max_dispo_client_gives_7() {
        //GIVEN
        List<Float> montantsCaptured = Arrays.asList(10F, 20F, 30F);

        //WHEN
        int actual = calculFacade.nombreMaxDispoClient(10, montantsCaptured);

        //THEN
        assertEquals(7, actual);
    }

    @Test
    public void nombre_max_dispo_client_gives_20() {
        //WHEN
        float actual = calculFacade.montantMaxDispoClient(20, null);

        //THEN
        assertEquals(20, actual);
    }

}