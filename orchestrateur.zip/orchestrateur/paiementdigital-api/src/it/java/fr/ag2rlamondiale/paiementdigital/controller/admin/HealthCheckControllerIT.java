package fr.ag2rlamondiale.paiementdigital.controller.admin;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.net.URI;
import java.net.URISyntaxException;

import static fr.ag2rlamondiale.paiementdigital.constantes.AdminConstantes.HEALTH_CHECK_OK;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class HealthCheckControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Test
    public void health_check_is_status_ok() throws URISyntaxException {
        //GIVEN
        String paramGetUri = "/healthcheck";
        String locahost = "http://localhost:";
        String baseUrl = String.join(String.valueOf(randomServerPort), locahost, paramGetUri);

        URI uri = new URI(baseUrl);

        //WHEN
        ResponseEntity<String> result = testRestTemplate.getForEntity(uri, String.class);

        //THEN
        assertEquals(HttpStatus.OK, result.getStatusCode());
        assertEquals(HEALTH_CHECK_OK, result.getBody());
    }

}