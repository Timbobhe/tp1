package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
@ActiveProfiles("it")
class ExclusionBanqueControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    private String paramGetUri = "/api/banques";

    private String locahost = "http://localhost:";

    private String baseUrl;

    @BeforeEach
    void setUp() {
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, paramGetUri);
    }

    @AfterEach
    void tearDown() {
        baseUrl = null;
    }

    @Test
    public void finding_banque_by_id_is_ok() throws URISyntaxException {
        //GIVEN
        //'N26%20Bank%20GmbH' = 'N26 Bank GmbH'
        HttpEntity<ExclusionBanqueDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/N26%20Bank%20GmbH");

        //WHEN
        ResponseEntity<ExclusionBanqueDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ExclusionBanqueDto.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals("N26 Bank GmbH", actual.getBody().getBanque());
    }

    @Test
    public void finding_unknown_banque_by_id_is_404_status() throws URISyntaxException {
        //GIVEN
        HttpEntity<ExclusionBanqueDto> request = new HttpEntity<>(null, getHttpAuthHeaders());
        URI uri = new URI(baseUrl + "/BRED");

        //WHEN
        ResponseEntity<ExclusionBanqueDto> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, request, ExclusionBanqueDto.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
    }

    @Test
    public void getting_all_banque_is_ok() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl + "/all");

        //WHEN
        ResponseEntity<Set<ExclusionBanqueDto>> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<>(null, getHttpAuthHeaders()), new ParameterizedTypeReference<Set<ExclusionBanqueDto>>() {
                });

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertTrue(actual.getBody().size() > 0);
    }

}