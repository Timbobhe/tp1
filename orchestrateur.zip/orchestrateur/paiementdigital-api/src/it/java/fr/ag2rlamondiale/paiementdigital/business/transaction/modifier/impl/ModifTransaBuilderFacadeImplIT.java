package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiModifierPaiementITData;
import fr.ag2rlamondiale.paiementdigital.bootstrap.transaction.ApiPaiementITData;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.AUTHORIZED;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.MASTERCARD;
import static org.junit.jupiter.api.Assertions.*;

@Transactional
@SpringBootTest
class ModifTransaBuilderFacadeImplIT {

    @Autowired
    private IModifTransaRespBuilderFacade facade;

    @Autowired
    private ApiPaiementITData transaData;

    @Autowired
    private ApiModifierPaiementITData modifPaimtData;

    @Autowired
    private IPaiementRepository repository;

    private Paiement paiement;

    private float montant;

    private String orderId;

    private String idTransaction;

    @BeforeEach
    public void setUp() {
        montant = 8.99f;
        orderId = UUIDUtils.uuidToOrderId(UUID.randomUUID());
        idTransaction = ApiPaiementITData.idTransaction();
        paiement = transaData.build("JAMES BOND", "CLIENT_1", montant, orderId,
                idTransaction, 1, MASTERCARD, AUTHORIZED);
        paiement = repository.save(paiement);
    }

    @BeforeEach
    public void tearDown() {
        paiement = null;
        orderId = null;
        idTransaction = null;
    }

    @Test
    public void response_modifier_paiement_digital_is_captured() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200(idTransaction);
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
        assertEquals(EtatEnum.CAPTURED.name(), actual.getModifTransaResp().getEtatCourant());
        assertEquals(STT_CODE_CAPTURED_OK, actual.getModifTransaResp().getStatus());
        assertEquals(CAPTURED, actual.getModifTransaResp().getMessage());
    }

    @Test
    public void response_modifier_paiement_digital_is_fail() {
        //GIVEN
        String code = STT_CODE_CAPTURE_FAIL;
        String message = STT_MSG_CAPTURE_REFUSED;
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.FAIL)
                .montant(montant)
                .status(code)
                .message(message)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .build();
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.FAIL);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200Fail(idTransaction, STT_CODE_CAPTURE_FAIL);

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertNull(actual.getEtatCourant());
        assertNull(actual.getCodeErreur());
        assertNull(actual.getMessageErreur());
        assertEquals(EtatEnum.FAIL.name(), actual.getModifTransaResp().getEtatCourant());
        assertEquals(code, actual.getModifTransaResp().getStatus());
        assertEquals(message, actual.getModifTransaResp().getMessage());
    }

    @Test
    public void response_modifier_paiement_digital_is_hypay_error() {
        //GIVEN
        String code = "3000002";
        String message = "Transaction not found";
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.ERROR)
                .montant(montant)
                .status(code)
                .message(message)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .build();
        paiement.setIdTransaction(null);
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.ERROR);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(A1532_FUNC_CALL_SA, "[A1532] Erreur renvoyee par le Service Applicatif:  :3000002 Transaction not found");

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.NOT_FOUND);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR.name(), actual.getEtatCourant());
        assertEquals(code, actual.getCodeErreur());
        assertEquals(message, actual.getMessageErreur());
        assertNull(actual.getModifTransaResp());
    }

    @Test
    public void response_modifier_paiement_digital_is_pfs_error() {
        //GIVEN
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.ERROR)
                .montant(montant)
                .status(A0487_TECH_PARSING)
                .message("Input data invalid")
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .build();
        paiement.setIdTransaction(null);
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.ERROR);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseFuncError(A0487_TECH_PARSING, "Input data invalid");

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.NOT_FOUND);

        //WHEN
        ModifTransaRootResp actual = facade.build(response, paiement);

        //THEN
        assertEquals(EtatEnum.ERROR.name(), actual.getEtatCourant());
        assertEquals(A0487_TECH_PARSING, actual.getCodeErreur());
        assertEquals("Input data invalid", actual.getMessageErreur());
        assertNull(actual.getModifTransaResp());
    }

    @Test
    public void invalid_parameter_in_build_throws_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(null, null));
    }

    @Test
    public void response_status_not_200_not_4xx_throws_exception() {
        //GIVEN
        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseTechError(A1532_TECH_DEFAULT, "error generated by Generate Error - Job-35531");
        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.SERVICE_UNAVAILABLE);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(response, paiement));
    }

    @Test
    public void response_status_stt_not_118_not_173_throws_exception() {
        //GIVEN
        Historique historique = Historique
                .builder()
                .etat(EtatEnum.FAIL)
                .montant(montant)
                .status("UNKNOWN_STT")
                .message("Unknown failure reason")
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .build();
        paiement.setMontant(montant);
        paiement.setEtatCourant(EtatEnum.FAIL);
        paiement.setDateModification(new Date());
        paiement.getHistoriques().add(historique);

        ModifPaimtRootResp modifPaimtRootResp = modifPaimtData.buildResponseStatus200Fail(idTransaction, "UNKNOWN_STT");

        ResponseEntity<ModifPaimtRootResp> response = new ResponseEntity<>(modifPaimtRootResp, HttpStatus.OK);

        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(response, paiement));
    }
}