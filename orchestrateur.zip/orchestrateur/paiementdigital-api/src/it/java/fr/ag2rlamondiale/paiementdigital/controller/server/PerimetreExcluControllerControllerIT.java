package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetreDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetreInfosDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.annotation.Transactional;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.buildLongDate;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

@Transactional
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("it")
@AutoConfigureTestDatabase
class PerimetreExcluControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ApiSecurityConfig config;

    private String perimetreURI = "/api/perimetres";

    private String locahost = "http://localhost:";

    private String baseUrl;

    private HttpEntity<RecupParamRootReq> request;

    @BeforeEach
    void setUp() {
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, perimetreURI);

    }

    @AfterEach
    void tearDown() {
        baseUrl = null;
    }


    @Test
    void find_perimetre_by_id_returns_perimetre_and_status_ok() throws URISyntaxException {
        //GIVEN
        String getParametreByIdEndpoint = "/10";
        URI uri = new URI(baseUrl + getParametreByIdEndpoint);
        request = new HttpEntity<>(getHttpAuthHeaders());

        //WHEN
        ResponseEntity<PerimetreDto> actual = testRestTemplate.exchange(uri, HttpMethod.GET,request,PerimetreDto.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(10, actual.getBody().getId());
        assertEquals(1, actual.getBody().getIdParent());
        assertEquals("CONTRAT", actual.getBody().getTypePerimetre().name());
        assertEquals("RRE", actual.getBody().getValeurPerimetre());
        assertEquals(false, actual.getBody().isTiersPayeur());
    }

    @Test
    void find_perimetre_by_id_returns_not_found_when_id_does_not_exist() throws URISyntaxException {
        //GIVEN
        String getParametreByIdEndpoint = "/1";
        URI uri = new URI(baseUrl + getParametreByIdEndpoint);
        request = new HttpEntity<>(getHttpAuthHeaders());

        //WHEN
        ResponseEntity<PerimetreDto> actual = testRestTemplate.exchange(uri, HttpMethod.GET,request,PerimetreDto.class);
    }

    @Test
    void find_all_perimetres_returns_set_of_perimetres_and_status_ok() throws URISyntaxException {
        //GIVEN
        String getParimetreByIdEndpoint = "/all";
        URI uri = new URI(baseUrl + getParimetreByIdEndpoint);
        request = new HttpEntity<>(getHttpAuthHeaders());

        //WHEN
        ResponseEntity<Set<PerimetreDto>> actual =
                testRestTemplate.exchange(uri, HttpMethod.GET, new HttpEntity<>(null, getHttpAuthHeaders()), new ParameterizedTypeReference<Set<PerimetreDto>>() {
                });

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(5, actual.getBody().size());

        Date dateCreation = buildLongDate(2021, 4, 21);
        PerimetreInfosDto perimetreInfos = PerimetreInfosDto.builder().structureJuridique("ARI").filiale("ACN").produit(null).contratDeReference(null).contrat(null).build();

        PerimetreDto perimetre = PerimetreDto.builder()
                .id(9L)
                .idParent(3L).
                typePerimetre(TypePerimetreEnum.PRODUIT)
                .valeurPerimetre("RR03-001-ACN")
                .tiersPayeur(false)
                .dateEffet(null)
                .dateFinEffet(null)
                .dateCreation(dateCreation)
                .dateModification(null)
                .perimetreInfos(perimetreInfos)
                .build();

        assertNotNull(actual.getBody().stream().filter(perimetreDto -> perimetreDto.getId().equals(perimetre.getId())));

    }
}