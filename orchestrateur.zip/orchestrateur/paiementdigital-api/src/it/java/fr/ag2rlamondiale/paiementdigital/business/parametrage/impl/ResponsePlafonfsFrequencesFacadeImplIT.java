package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePlafonfsFrequencesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.CB;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@Transactional
@ActiveProfiles("it")
class ResponsePlafonfsFrequencesFacadeImplIT {

    @Autowired
    private IResponsePlafonfsFrequencesFacade plafonfsFrequencesFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabData;

    private RecupParamRootReq pfsDto;

    private PaiementDto paiementDto;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabData.setUp();

        pfsDto = parametrageLabData.getPfsDto();

        paiementDto = parametrageLabData.getPaiementDto();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        paiementDto = null;
    }

    @Test
    @Disabled
    public void plafonds_par_frequence_found_for_cb() {
        //GIVEN
        paiementDto.setMethodeDePaiement(CB.name());
        List<Plafond> plafonds = Arrays.asList(
                Plafond.builder().typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE).montantMinimum(0F).montantMaximum(8000F).nombreMaximumPaiement(999).build(),
                Plafond.builder().typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT).montantMinimum(0F).montantMaximum(4000F).nombreMaximumPaiement(999).build(),
                Plafond.builder().typeFrequence(TypeFrequenceEnum.TRANSACTION).montantMinimum(0F).montantMaximum(4000F).nombreMaximumPaiement(999).build()
        );

        RecupParamPlfdFreqResp ppf3d1 = RecupParamPlfdFreqResp
                .builder().typeFrequence(TypeFrequenceEnum.ANNEE_CIVILE.name())
                .montantMin(0).montantMax(8000).nombreMax(999)
                .montantMaxdispoClient(8000).nombreMaxDispoClient(999).build();

        RecupParamPlfdFreqResp ppf3d2 = RecupParamPlfdFreqResp
                .builder().typeFrequence(TypeFrequenceEnum.MOIS_GLISSANT.name())
                .montantMin(0).montantMax(4000).nombreMax(999)
                .montantMaxdispoClient(4000).nombreMaxDispoClient(999).build();

        RecupParamPlfdFreqResp ppf3d3 = RecupParamPlfdFreqResp
                .builder().typeFrequence(TypeFrequenceEnum.TRANSACTION.name())
                .montantMin(0).montantMax(4000).nombreMax(999)
                .montantMaxdispoClient(4000).nombreMaxDispoClient(999).build();

        Set<RecupParamPlfdFreqResp> plafondsExpected = new HashSet<>(Arrays.asList(ppf3d1, ppf3d2, ppf3d3));

        //WHEN
        Set<RecupParamPlfdFreqResp> actual = plafonfsFrequencesFacade.getPlafondsParFrequencesDtos(pfsDto, plafonds, paiementDto);

        //THEN
        assertEquals(plafondsExpected, actual);
    }

    @Test
    public void empty_set_plafonds_par_frequences_throws_parama_lab_exception() {
        //WHEN THEN
        assertThrows(ParamLabException.class, () -> plafonfsFrequencesFacade.getPlafondsParFrequencesDtos(pfsDto, Collections.emptyList(), paiementDto));
    }

}