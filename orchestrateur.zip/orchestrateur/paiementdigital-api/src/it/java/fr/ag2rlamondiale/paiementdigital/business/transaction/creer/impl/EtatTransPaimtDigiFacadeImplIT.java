package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.EtatTransaPaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.DetTransaPaimtNumeriseResp;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class EtatTransPaimtDigiFacadeImplIT {

    @Autowired
    EtatTransPaimtDigiFacadeImpl etatTransPaimtDigiFacade;

    private Paiement paiementRequest;

    private DetTransaPaimtNumeriseResp detTransaPaimtNumeriseResponse;

    private Set<Historique> historiques = new HashSet<>();

    private String historiqueMessageAuthorized = "message error";

    private String historiqueStatusAuthorized = "random";

    @BeforeEach
    void setUp() {
        historiques.add(
                Historique.builder()
                        .etat(EtatEnum.AUTHORIZATION)
                        .build());
        historiques.add(
                Historique.builder()
                        .etat(EtatEnum.AUTHORIZED)
                        .message(historiqueMessageAuthorized)
                        .status(historiqueStatusAuthorized)
                        .build());
        paiementRequest = Paiement.builder()
                .etatCourant(EtatEnum.AUTHORIZED)
                .idUniqueClient("123PAR1234")
                .metier("RET_SUP_COL")
                .codeApplication("A1573")
                .evenementMetier(TypeEvenementMetier.VRLI)
                .montant(8.99F)
                .methodeDePaiement("VISA")
                .nomPayeur("SOUFIANE")
                .paysMethode("US")
                .banque("JPMORGAN CHASE BANK, N.A.")
                .structureJuridique("ARI")
                .filiale("ARI")
                .produit("RG01-002-ARI")
                .contrat("XXXXXXXXXXXX")
                .tiersPayeur(false)
                .typeClient(TypeClientEnum.CLIENT)
                .natureClient(NatureClientEnum.PP)
                .paysResidence("FRANCE")
                .paysResidenceFiscale("FRANCE")
                .historiques(historiques)
                .build();
        detTransaPaimtNumeriseResponse = DetTransaPaimtNumeriseResp.builder()
                .numAutionTransaPaimtNumerise("test123")
                .mntTransaPaimtDigi(8.99F)
                .codeDevMntTransaPaimtDigi(DeviseEnum.EUR)
                .codeSitTransaPaimtDigi("CPL").build();
    }

    @AfterEach
    void tearDown() {
        paiementRequest = null;
        historiques = null;
        detTransaPaimtNumeriseResponse = null;
    }

    @Test
    void map_etat_transac_paiement_digital_when_state_authorized() {
        //GIVEN
        paiementRequest.setEtatCourant(EtatEnum.AUTHORIZED);

        //WHEN
        EtatTransaPaimtDigiResp result = etatTransPaimtDigiFacade.toEtatTransactionPaiementDigital(paiementRequest, detTransaPaimtNumeriseResponse);

        //THEN
        assertEquals(paiementRequest.getEtatCourant(), result.getEtatCourant());
        assertEquals(detTransaPaimtNumeriseResponse.getCodeSitTransaPaimtDigi(), result.getCodeSitTransPaiemtDigi());
        assertEquals(historiqueMessageAuthorized, result.getMessage());
        assertEquals(historiqueStatusAuthorized, result.getStatus());
    }

    @Test
    void map_etat_transac_paiement_digital_when_state_fail() {
        //GIVEN
        paiementRequest.setEtatCourant(EtatEnum.FAIL);
        paiementRequest.getHistoriques().add(Historique.builder()
                .etat(EtatEnum.FAIL)
                .message(historiqueMessageAuthorized)
                .status(historiqueStatusAuthorized)
                .build());
        //WHEN
        EtatTransaPaimtDigiResp result = etatTransPaimtDigiFacade.toEtatTransactionPaiementDigital(paiementRequest, detTransaPaimtNumeriseResponse);

        //THEN
        assertEquals(paiementRequest.getEtatCourant(), result.getEtatCourant());
        assertEquals(detTransaPaimtNumeriseResponse.getCodeSitTransaPaimtDigi(), result.getCodeSitTransPaiemtDigi());
        assertEquals(historiqueMessageAuthorized, result.getMessage());
        assertEquals(historiqueStatusAuthorized, result.getStatus());
    }

}