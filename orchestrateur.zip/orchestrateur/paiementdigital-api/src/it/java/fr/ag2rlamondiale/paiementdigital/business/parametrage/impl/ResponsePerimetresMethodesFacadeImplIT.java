package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePerimetresMethodesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;


@SpringBootTest
@Transactional
@ActiveProfiles("it")
@AutoConfigureTestDatabase
class ResponsePerimetresMethodesFacadeImplIT {

    @Autowired
    private IResponsePerimetresMethodesFacade perimetresMethodesFacade;

    @Autowired
    private IParametrageFacade parametrageFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabLoader;

    private RecupParamRootReq pfsDto;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabLoader.setUp();

        pfsDto = parametrageLabLoader.getPfsDto();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
    }

    @Test
    @Disabled
    public void toutecarte_gives_set_of_methodes_cards() {
        //GIVEN
        Perimetre perimetre = parametrageFacade.perimetre(pfsDto);

        //WHEN
        Set<RecupParamPeriMethPaimtResp> actual = perimetresMethodesFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetre);

        //THEN
        assertEquals(3, actual.size());
        assertEquals(1600, actual.stream().max(Comparator
                .comparing(RecupParamPeriMethPaimtResp::getMinMontantDispoClient))
                .get().getMinMontantDispoClient());
    }

    @Test
    @Disabled
    public void perimetre_lmo_gives_set_of_methodes_cards() {
        //GIVEN
        pfsDto.getPerimetre().setStructureJuridique("LM");
        pfsDto.getPerimetre().setFiliale("LMO");
        Perimetre perimetre = parametrageFacade.perimetre(pfsDto);

        //WHEN
        Set<RecupParamPeriMethPaimtResp> actual = perimetresMethodesFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetre);

        //THEN
        assertEquals(3, actual.size());
        assertEquals(2500, actual.stream().max(Comparator
                .comparing(RecupParamPeriMethPaimtResp::getMinMontantDispoClient))
                .get().getMinMontantDispoClient());
    }

    @Test
    public void contrat_rre_with_date_recherche_after_date_effect_gives_set_of_methodes_cards() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setContrat("RRE");
        pfsDto.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-13" ));
        Perimetre perimetre = parametrageFacade.perimetre(pfsDto);

        //WHEN
        Set<RecupParamPeriMethPaimtResp> actual = perimetresMethodesFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetre);

        //THEN
        assertEquals(3, actual.size());
        assertEquals(2500, actual.stream().max(Comparator
                .comparing(RecupParamPeriMethPaimtResp::getMinMontantDispoClient))
                .get().getMinMontantDispoClient());
    }

}