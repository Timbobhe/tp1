package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase
@ActiveProfiles("it")
class NotificationControllerIT {


    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ApiSecurityConfig config;


    private String baseUrl;

    @BeforeEach
    void setUp() {
        String locahost = "http://localhost:";
        String notificationURI = "/api/notification/send";
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, notificationURI);
    }

    @AfterEach
    void tearDown() {
        baseUrl = null;
    }

    @Test
    void send_notification_return_ok_and_authorize_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationRootRequest = "json/notification-authorize-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Authorized");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Authorized");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"116");

    }

    @Test
    void send_notification_return_ok_and_captured_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationCapturedRootRequest = "json/notification-captured-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationCapturedRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Captured");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Captured");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"118");
    }

    @Test
    void send_notification_return_ok_and_cpl_fail_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationCplFailRootRequest = "json/notification-cpl_fail-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationCplFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Fail");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Fail");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"173");
    }

    @Test
    void send_notification_return_ok_and_fail_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-fail-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"ANN");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Fail");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Fail");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"173");
    }

    @Test
    void send_notification_return_ok_and_pending_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-pending-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"ATT");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Pending");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Pending");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"200");
    }

    @Test
    void send_notification_return_ok_and_authentification_echouee_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-auth-echoue-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Authentification échouée");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Authentification échouée");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"109");
    }

    @Test
    void send_notification_return_ok_and_remboursement_demandée_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-remboursement-demande-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Remboursement demandé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Remboursement demandé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"124");
    }

    @Test
    void send_notification_return_ok_and_rembourse_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-rembourse-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Remboursé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Remboursé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"125");
    }

    @Test
    void send_notification_return_ok_and_partiellement_rembourse_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-partiellement-rembourse-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Partiellement remboursé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Partiellement remboursé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"126");
    }

    @Test
    void send_notification_return_ok_and_impaye_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-impaye-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Impayé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Impayé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"129");
    }

    @Test
    void send_notification_return_ok_and_dispute_lost_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-dispute-lost-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Dispute Lost");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Dispute Lost");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"134");
    }

    @Test
    void send_notification_return_ok_and_autorisation_demandee_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-autorisation-demandee-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Autorisation demandée");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Autorisation demandée");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"142");
    }

    @Test
    void send_notification_return_ok_and_autorisation_cancelled_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-autorisation-cancelled-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Authorization Cancelled");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Authorization Cancelled");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"143");
    }

    @Test
    void send_notification_return_ok_and_reference_rendred_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-reference-rendred-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Reference Rendered");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Reference Rendered");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"144");
    }

    @Test
    void send_notification_return_ok_and_card_holder_credit_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-autorisation-card-holder-credit-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Cardholder Credit");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Cardholder Credit");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"166");
    }

    @Test
    void send_notification_return_ok_and_reported_fraude_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-reported-fraud-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Reported Fraud");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Reported Fraud");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"167");
    }

    @Test
    void send_notification_return_ok_and_debited_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-debited-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Debited (Cardholder Credit)");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Debited (Cardholder Credit)");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"168");
    }

    @Test
    void send_notification_return_ok_and_credit_requested_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-credit-requested-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Credit Requested");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Credit Requested");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"169");
    }

    @Test
    void send_notification_return_ok_and_in_progress_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-in-progress-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"In progress");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"In progress");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"172");
    }

    @Test
    void send_notification_return_ok_and_capture_refuse_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-capture-refuse-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Capture refusée");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Capture refusée");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"173");
    }

    @Test
    void send_notification_return_ok_and_awaiting_terminal_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-awaiting-terminal-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Awaiting Terminal");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Awaiting Terminal");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"174");
    }

    @Test
    void send_notification_return_ok_and_soft_declined_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-soft-declined-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Soft Declined");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Soft Declined");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"178");
    }

    @Test
    void send_notification_return_ok_and_bloqued_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-bloqued-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Bloqué");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Bloqué");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"110");
    }

    @Test
    void send_notification_return_ok_and_denied_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-denied-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Refusé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Refusé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"111");
    }

    @Test
    void send_notification_return_ok_and_autorised_in_attente_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-autorised-attente-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Autorisé et en attente");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Autorisé et en attente");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"112");
    }

    @Test
    void send_notification_return_ok_and_refused_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-refused-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Refusé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Refusé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"113");
    }

    @Test
    void send_notification_return_ok_and_perime_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-code-perime-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Périmé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Périmé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"114");
    }

    @Test
    void send_notification_return_ok_and_annule_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-annule-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Annulé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Annulé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"115");
    }

    @Test
    void send_notification_return_ok_and_capture_demande_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-capture-demande-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Capture demandée");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Capture demandée");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"117");
    }

    @Test
    void send_notification_return_ok_and_autorisation_cancellation_requested_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-authorization-cancellation-requested-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Authorization cancellation requested");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Authorization cancellation requested");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"175");
    }

    @Test
    void send_notification_with_error_status_throws_notificationException() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-stt-error-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertTrue(actual.getStatusCode().is4xxClientError());
        assertEquals(actual.getBody().getEtatCourant(), EtatEnum.ERROR);
        assertEquals(actual.getBody().getCodeErreur(), "400");
        assertEquals(actual.getBody().getMessageErreur(), "Cette valeur STT est non prévue.");

    }

    @Test
    void send_notification_return_ok_and_rembousement_refuse_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-remboursement-refuse-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Remboursement refusé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Remboursement refusé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"165");
    }

    @Test
    void send_notification_return_ok_and_partiellement_caputré_status() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationFailRootRequest = "json/notification-partiellement-capture-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationFailRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), Objects.requireNonNull(actual.getBody()).getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getEntetePaiementNumerise().getIdentifiantDemandePaiement(),"9dba1849bb0c49ffa802e91d3dfc419d");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital());
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(), actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getReferenceTransactionPaiementDigital(),"800088752457");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital(),"CPL");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDetailTransPaiemtNumerise().getLibelleSituationTransactionPaiementDigital(),"Partiellement capturé");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getTypeDonnee(),"test" );
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDonneesMetier().stream().findFirst().get().getValeurDonnee(),"XXX");
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getDestinataire(),"A1573");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant(), actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getIdentifiantMarchant(),"00001338125");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getMessage(), actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getMessage(),"Partiellement capturé");
        assertEquals(notificationRootReq.getNotificationReq().getPaimentDigiReq().getStatut(), actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut());
        assertEquals(actual.getBody().getNotificationResp().getPaimentDigiResp().getStatut(),"119");
    }

    @Test
    void send_notification_with_invalid_order_id_throws_exception() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationErrorRootRequest = "json/notification-error-500-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationErrorRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertTrue(actual.getStatusCode().is5xxServerError());
        assertEquals(actual.getBody().getEtatCourant(), EtatEnum.ERROR);
        assertEquals(actual.getBody().getCodeErreur(), "500");
        assertEquals(actual.getBody().getMessageErreur(), "aucun paiement n'existe pour cet orderId ou idTransaction");
    }

    @Test
    void send_notification_with_empty_root_throws_exception() throws URISyntaxException {
        //GIVEN
        URI uri = new URI(baseUrl);
        String notificationErrorRootRequest = "json/notification-error-empty-root-req-it.json";
        NotificationRootReq notificationRootReq = JsonUtils.notificationRequest(notificationErrorRootRequest);
        HttpEntity<NotificationRootReq> request = new HttpEntity<>(notificationRootReq, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<NotificationRootResp> actual = testRestTemplate.postForEntity(uri, request, NotificationRootResp.class);

        //THEN
        assertTrue(actual.getStatusCode().is5xxServerError());
        assertEquals(actual.getBody().getEtatCourant(), EtatEnum.ERROR);
        assertEquals(actual.getBody().getCodeErreur(), "500");
        assertEquals(actual.getBody().getMessageErreur(), "Le paramètre ne peut être null!");
        assertNull(actual.getBody().getNotificationResp());
    }

}