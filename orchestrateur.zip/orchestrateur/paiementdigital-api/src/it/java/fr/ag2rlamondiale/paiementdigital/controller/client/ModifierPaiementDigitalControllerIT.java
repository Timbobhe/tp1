package fr.ag2rlamondiale.paiementdigital.controller.client;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.CAPTURED;
import static fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes.A1532_FUNC_INVALID_AUTH;
import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.ACA;
import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.ARI;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureTestDatabase
@Disabled
class ModifierPaiementDigitalControllerIT {

    @Autowired
    private CreerPaiementDigitalController creerPaiementDigitalController;

    @Autowired
    private IGestionTokenFacade gestionTokenFacade;

    @Autowired
    private PfsPropertyConfig pfsPropertyConfig;

    @Autowired
    private ModifierPaiementDigitalController controller;

    private ModifPaimtRootReq request;

    @BeforeEach
    public void setUp() {
        request = buildRequest();
    }

    @AfterEach
    public void tearDown() {
        request = null;
    }

    @Test
    public void modifier_paiement_digital_gives_status_200_and_captured() {
        //GIVEN
        String uri = pfsPropertyConfig.getModifierPaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri, ARI, ACA);

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uriWithParams, request);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(CAPTURED, actual.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc().getPaimtDigi().getMsg());
    }

    @Test
    public void unknown_id_paiement_gives_status_400() {
        //GIVEN
        String uri = pfsPropertyConfig.getModifierPaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri, ARI,ARI);

        request
                .getModifierPaimtDigi()
                .getPaimtDigi()
                .getDetTransaPaimtNumerise()
                .setRefTransaPaimtDigi("REF_INCONNUE");

        //WHEN
        ResponseEntity<ModifPaimtRootResp> result = controller.modifierPaiementDigital(uriWithParams, request);

        //THEN
        assertEquals(HttpStatus.BAD_REQUEST, result.getStatusCode());
        assertEquals(PfsErrorsConstantes.A1532_FUNC_CALL_SA, result.getBody().getResponse().getHeader().getFuncError().get(0).getErrorCode());
    }

    @Test
    public void missing_token_gives_status_401_unauthorized() {
        //GIVEN
        String domain = pfsPropertyConfig.getModifierPaiementUrl();

        String uri = UriComponentsBuilder
                .fromUriString(domain)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .build()
                .encode()
                .toUri()
                .toString();

        //WHEN
        ResponseEntity<ModifPaimtRootResp> result = controller.modifierPaiementDigital(uri, request);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED, result.getStatusCode());
        assertEquals(A1532_FUNC_INVALID_AUTH, result.getBody().getResponse().getHeader().getFuncError().get(0).getErrorCode());
    }

    @Test
    public void null_request_gives_internal_error() {
        //GIVEN
        String uri = pfsPropertyConfig.getModifierPaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri, ARI,ARI);

        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(uriWithParams, null);

        //THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.name(), actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorCode());
        assertEquals(INVALID_PARAMETER, actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorMessage());
        assertNull(actual.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc());
    }

    @Test
    public void null_uri_gives_internal_error() {
        //WHEN
        ResponseEntity<ModifPaimtRootResp> actual = controller.modifierPaiementDigital(null, request);

        //THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, actual.getStatusCode());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.name(), actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorCode());
        assertEquals(INVALID_PARAMETER, actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorMessage());
        assertNull(actual.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc());
    }

    private ModifPaimtRootReq buildRequest() {
        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = ModifPaimtDetTransaPaimtNumReq.builder()
                .refTransaPaimtDigi(initRefTransPaimtDigi())
                .typeOpeTransaPaimtDigi("capture")
                .build();
        ModifPaimtDetMontantPaimtReq detMontantPaimt = ModifPaimtDetMontantPaimtReq.builder()
                .montantTTC(8.99f)
                .codeDevVersm(DeviseEnum.EUR)
                .build();
        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq.builder()
                .detailMontantPaimt(detMontantPaimt)
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .build();
        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);
        return new ModifPaimtRootReq(modifierPaimtDigi);
    }

    private String initRefTransPaimtDigi() {
        CreerPaimtDigiRootReq request = JsonUtils.paiementRequest("json/creer-paimt-digi-req-3-it.json");

        //Génération à la volée de l'orderId et remplacement de la valeur initiale
        //dans l'objet issu du fichier de test
        String orderId = UUIDUtils.randomUuidToOrderId();
        request.getCreerPaimtDigi().getCreerPaimtDigiBis().getPaimtDigi().getEntetePaimtNumerise().setIdPaimtDigi(orderId);

        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri, ARI,ARI);

        ResponseEntity<CreerPaimtDigiRootResp> response = creerPaiementDigitalController.creerPaiementDigital(uriWithParams, request);
        return response
                .getBody()
                .getResponse()
                .getBody()
                .getCreerPaimtDigiResponse()
                .getCreerPaimtDigiFunc()
                .getCreerPaimtDigi()
                .getPaimtDigi()
                .getDetTransaPaimtNumerise()
                .getRefTransPaimtDigi();
    }
}