package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class ModifPaimtDigiBuilderFacadeImplIT {

    @Autowired
    private IModifPaimtDigiReqBuilderFacade facade;

    private ModifTransaRootReq request;

    private ModifPaimtRootReq expected;

    @BeforeEach
    public void setUp() {
        request = buildRequest();

        expected = buildResponse();
    }

    @AfterEach
    public void tearDown() {
        request = null;
        expected = null;
    }

    @Test
    public void mapping_all_fileds_is_ok() {
        //WHEN
        ModifPaimtRootReq actual = facade.build(request);

        //THEN
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt(), actual.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt());
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise(), actual.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise());
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getInfoTech(), actual.getModifierPaimtDigi().getPaimtDigi().getInfoTech());
    }

    @Test
    public void mapping_only_mandatories_files_is_ok() {
        //GIVEN
        request.getModificationTransactionPaiement().setDetailMontantPaiement(null);
        request.getModificationTransactionPaiement().setInformationsTechniques(null);

        expected.getModifierPaimtDigi().getPaimtDigi().setDetailMontantPaimt(null);
        expected.getModifierPaimtDigi().getPaimtDigi().setInfoTech(null);

        //WHEN
        ModifPaimtRootReq actual = facade.build(request);

        //THEN
        assertEquals(expected.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise(), actual.getModifierPaimtDigi().getPaimtDigi().getDetTransaPaimtNumerise());
        assertNull(actual.getModifierPaimtDigi().getPaimtDigi().getDetailMontantPaimt());
        assertNull(actual.getModifierPaimtDigi().getPaimtDigi().getInfoTech());
    }

    @Test
    public void mapping_is_thowing_exception() {
        //WHEN THEN
        assertThrows(ModifierTransactionException.class, () -> facade.build(null));
    }

    private ModifPaimtRootReq buildResponse() {
        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = ModifPaimtDetTransaPaimtNumReq.
                builder()
                .refTransaPaimtDigi("ID_TRANSCTION")
                .typeOpeTransaPaimtDigi("TYPE")
                .build();
        ModifPaimtDetMontantPaimtReq detMontantPaimt = ModifPaimtDetMontantPaimtReq.builder()
                .montantTTC(200)
                .codeDevVersm(DeviseEnum.EUR)
                .build();
        ModifPaimtInfoTechReq infoTech = ModifPaimtInfoTechReq.builder()
                .oriTransa("ORIGINE")
                .refOpePaimtDigi("REF")
                .refSsTransaPaimtDigi("REF")
                .build();

        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq
                .builder()
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detailMontantPaimt(detMontantPaimt)
                .infoTech(infoTech)
                .build();

        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);

        return new ModifPaimtRootReq(modifierPaimtDigi);
    }

    private ModifTransaRootReq buildRequest() {
        ModifTransaDetTransaPaimtNumReq detailTransactionPaiementNumerise = ModifTransaDetTransaPaimtNumReq.builder()
                .idTransaction("ID_TRANSCTION")
                .typeOperationTransactionPaiementDigital("TYPE")
                .build();

        ModifTransaDetMntPaimtReq detailMontantPaiement = ModifTransaDetMntPaimtReq.builder()
                .montantTTC(200)
                .codeDeviseVersement(DeviseEnum.EUR)
                .build();

        ModifTransaInfosTechReq informationsTechniques = ModifTransaInfosTechReq.builder()
                .origineTransaction("ORIGINE")
                .referenceOperationPaiementDigital("REF")
                .referenceSousTransactionPaiementDigital("REF")
                .build();

        ModifTransaPaiementReq modificationTransactionPaiement = ModifTransaPaiementReq.builder()
                .detailMontantPaiement(detailMontantPaiement)
                .detailTransactionPaiementNumerise(detailTransactionPaiementNumerise)
                .informationsTechniques(informationsTechniques)
                .build();

        return new ModifTransaRootReq(modificationTransactionPaiement);
    }
}