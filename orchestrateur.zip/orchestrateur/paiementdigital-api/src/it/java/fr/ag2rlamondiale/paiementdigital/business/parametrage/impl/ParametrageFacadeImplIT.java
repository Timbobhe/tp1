package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamCliReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamPeriReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamProflReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.util.Date;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.buildShortDate;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@Transactional
@ActiveProfiles("it")
class ParametrageFacadeImplIT {

    @Autowired
    private IParametrageFacade parametrageFacade;

    private RecupParamRootReq pfsDto;

    @BeforeEach
    void setUp() {
        RecupParamProflReq profil = RecupParamProflReq.builder()
                .codeApplication(A1573)
                .metier(ProfilConstantes.RET_SUP_COL)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .build();

        RecupParamCliReq client = RecupParamCliReq.builder()
                .idUniqueClient("CLIENT_A")
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .build();

        RecupParamPeriReq perimetre = RecupParamPeriReq.builder()
                .structureJuridique(ARI)
                .filiale(ACA)
                .build();

        pfsDto = RecupParamRootReq.builder()
                .profil(profil)
                .client(client)
                .perimetre(perimetre)
                .dateRecherche(new Date())
                .exclusionBanques(true)
                .inclusionPays(true)
                .build();
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
    }

    @Test
    public void no_perimetre_found_with_unknow_parameter_throws_not_found_exception() {
        //GIVEN
        RecupParamProflReq profil = RecupParamProflReq.builder()
                .codeApplication("UNKNOWN")
                .metier(ProfilConstantes.RET_SUP_COL)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .build();

        pfsDto.setProfil(profil);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> parametrageFacade.perimetre(pfsDto));
    }

    @Test
    public void perimetre_found_with_the_given_parameters() {
        //WHEN
        Perimetre actual = parametrageFacade.perimetre(pfsDto);

        //THEN
        assertNotNull(actual.getTypePerimetre());
        assertNotNull(actual.getValeurPerimetre());
    }

    @Test
    public void unknown_value_in_database_throws_notfound_parameter_exception() {
        //GIVEN
        pfsDto.getProfil().setMetier("UNKNOWN_METIER");

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> parametrageFacade.inclusions(pfsDto));
    }

    @Test
    public void daterecherche_throws_notfound_parameter_exception() {
        //GIVEN
        pfsDto.setDateRecherche(buildShortDate(1789, 7, 14));

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> parametrageFacade.inclusions(pfsDto));
    }

    @Test
    public void list_of_pays_found_with_parameters() {
        //WHEN
        Set<InclusionPaysDto> result = parametrageFacade.inclusions(pfsDto);

        //THEN
        assertEquals(29, result.size());
        assertEquals(3, result.stream().filter(p -> "FRANCE".equals(p.getPays())).count());
        assertEquals(1, result.stream().filter(p -> "BELGIQUE".equals(p.getPays())).count());
    }

    @Test
    public void list_of_banques_found_with_parameters() {
        //GIVEN
        pfsDto.setDateRecherche(buildShortDate(2020, 10, 12));

        //WHEN
        Set<ExclusionBanqueDto> result = parametrageFacade.exclusions(pfsDto);

        //THEN
        assertEquals(1, result.size());
        assertEquals(1, result.stream().filter(p -> "N26 Bank GmbH".equals(p.getBanque())).count());
        assertEquals(0, result.stream().filter(p -> "BNP".equals(p.getBanque())).count());
    }
}