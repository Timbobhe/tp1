package fr.ag2rlamondiale.paiementdigital.controller.client;


import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsErrorsConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.PaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.net.URISyntaxException;

import static fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException.INVALID_PARAMETER;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CreerPaiementDigitalControllerIT {

    @Autowired
    private PfsPropertyConfig pfsPropertyConfig;

    @Autowired
    private IGestionTokenFacade gestionTokenFacade;

    @Autowired
    private CreerPaiementDigitalController controller;

    private String paiementRequest = "json/creer-paimt-digi-req-3-it.json";
    private String transactionRequest = "json/creer-transa-aca-req-it.json";

    @Test
    @Disabled
    public void orderid_already_used_gives_status_400_func_error() throws IOException {
        //GIVEN
        CreerTransaPaimtDigiRootReq transactionReq = JsonUtils.transactionRequest(transactionRequest);

        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri,transactionReq.getDetailPerimetreMetier().getStructureJuridique() ,transactionReq.getDetailPerimetreMetier().getFiliale());

        CreerPaimtDigiRootReq request = getCreerPaimtDigiRequestDto(paiementRequest);

        //Il faut valider le paiement une première fois et réutiliser le même orderId
        //pour générer une erreur d'orderId déjà utilisé
        controller.creerPaiementDigital(uriWithParams, request);

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = controller.creerPaiementDigital(uriWithParams, request);

        //THEN
        assertEquals(HttpStatus.BAD_REQUEST.value(), actual.getStatusCodeValue());
        assertEquals(PfsErrorsConstantes.A1532_FUNC_CALL_SA,
                actual.getBody().getResponse().getHeader().getFuncError().get(0).getErrorCode().trim());
    }

    @Test
    public void no_params_in_pfs_uri_gives_status_401_func_error() throws IOException, URISyntaxException {
        //GIVEN
        CreerPaimtDigiRootReq request = getCreerPaimtDigiRequestDto(paiementRequest);
        String uriWithoutParams = pfsPropertyConfig.getCreatePaiementUrl();

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = controller.creerPaiementDigital(uriWithoutParams, request);

        //THEN
        assertEquals(HttpStatus.UNAUTHORIZED.value(), actual.getStatusCodeValue());
        Assertions.assertEquals(PfsErrorsConstantes.A0487_FUNC_INVALID_AUTH,
                actual.getBody().getResponse().getHeader().getFuncError().get(0).getErrorCode().trim());
    }

    @Test
    @Disabled
    public void case_ok_status_200() throws IOException {
        //GIVEN
        CreerTransaPaimtDigiRootReq transactionReq = JsonUtils.transactionRequest(transactionRequest);

        String uri = pfsPropertyConfig.getCreatePaiementUrl();
        String uriWithParams = gestionTokenFacade.getUriWithParams(uri, transactionReq.getDetailPerimetreMetier().getStructureJuridique(),transactionReq.getDetailPerimetreMetier().getFiliale());

        CreerPaimtDigiRootReq request = getCreerPaimtDigiRequestDto(paiementRequest);

        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = controller.creerPaiementDigital(uriWithParams, request);

        //THEN
        assertEquals(HttpStatus.OK.value(), actual.getStatusCodeValue());

        PaimtDigiResp paimtDigiResponse = actual.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi().getPaimtDigi();
        assertEquals(HipayConstantes.AUTHORIZED, paimtDigiResponse.getMsg());
        assertEquals(request.getCreerPaimtDigi().getCreerPaimtDigiBis().getPaimtDigi().getDetMntPaimt().getMntTTC(), paimtDigiResponse.getDetTransaPaimtNumerise().getMntTransaPaimtDigi());
    }

    @Test
    public void uri_or_request_null_throws_invalid_parameter() {
        //WHEN
        ResponseEntity<CreerPaimtDigiRootResp> actual = controller.creerPaiementDigital(null, null);

        //THEN
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), actual.getStatusCodeValue());
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.name(), actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorCode().trim());
        assertEquals(INVALID_PARAMETER, actual.getBody().getResponse().getHeader().getTechError().get(0).getErrorMessage().trim());
        assertNull(actual.getBody().getResponse().getBody());
    }

    private CreerPaimtDigiRootReq getCreerPaimtDigiRequestDto(String filename) throws IOException {
        CreerPaimtDigiRootReq request = JsonUtils.paiementRequest(filename);

        //Génération à la volée de l'orderId et remplacement de la valeur initiale
        //dans l'objet issu du fichier de test
        String orderId = UUIDUtils.randomUuidToOrderId();
        request.getCreerPaimtDigi().getCreerPaimtDigiBis().getPaimtDigi().getEntetePaimtNumerise().setIdPaimtDigi(orderId);
        return request;
    }



}
