package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;

import static fr.ag2rlamondiale.paiementdigital.bootstrap.SecurityITData.getHttpAuthHeaders;
import static fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum.TRANSACTION;
import static fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Transactional
@AutoConfigureTestDatabase
@ActiveProfiles("it")
class ParametrageControllerIT {

    @LocalServerPort
    private int randomServerPort;

    @Autowired
    private TestRestTemplate testRestTemplate;

    @Autowired
    private ApiSecurityConfig config;

    @Autowired
    private ApiParametrageLabITData data;

    private RecupParamRootReq pfsDto;

    private String paramGetUri = "/api/parametrage/get";

    private String locahost = "http://localhost:";


    private String filename = "json/parametrage-ok-it.json";

    private String baseUrl;

    private URI uri;

    private HttpEntity<RecupParamRootReq> request;

    @BeforeEach
    void setUp() throws URISyntaxException, ParseException {
        data.setUp();
        pfsDto = data.getPfsDto();
        baseUrl = String.join(String.valueOf(randomServerPort), locahost, paramGetUri);
        uri = new URI(baseUrl);
        request = new HttpEntity<>(pfsDto, getHttpAuthHeaders());
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        baseUrl = null;
        uri = null;
        request = null;
    }

    @Test
    @Disabled
    public void finding_aca_profil_gives_status_200() throws URISyntaxException {
        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());

        assertEquals(1600,
                actual.getBody().getParametresProfilsDto().getMaxDesMontantsDispo());

        assertEquals(1, Arrays.asList("CB").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesMontantsDispo()
                .contains(t)).count());

        assertEquals(995,
                actual.getBody().getParametresProfilsDto().getMaxDesNombresDePaiementDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesNombresDePaiementDispo()
                .contains(t)).count());

        assertEquals(3, actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement().size());

        assertTrue(actual.getBody().getInclusions().size() > 0);

        assertTrue(actual.getBody().getExclusions().size() > 0);

    }

    @Test
    public void unknow_code_application_request_throws_exception() {
        //GIVEN
        pfsDto.getProfil().setMetier("UNKNOWN_METIER");

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
        assertEquals(PROFIL_NOT_FOUND, actual.getBody().getMessage());
        assertNull(actual.getBody().getParametresProfilsDto());
        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }

    @Test
    @Disabled
    public void unknown_contrat_gives_status_200_ok() {
        //GIVEN
        RecupParamRootReq pfsDto = JsonUtils.parametrageRequest(filename);
        request = new HttpEntity<>(pfsDto, getHttpAuthHeaders());

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(2500,
                actual.getBody().getParametresProfilsDto().getMaxDesMontantsDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesMontantsDispo()
                .contains(t)).count());

        assertEquals(999,
                actual.getBody().getParametresProfilsDto().getMaxDesNombresDePaiementDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesNombresDePaiementDispo()
                .contains(t)).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceMinMontantDispoClient())).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceNombrePaiementDisponible())).count());

        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }

    @Test
    public void exclusion_produit_throws_not_found() {
        //GIVEN
        pfsDto.getPerimetre().setProduit("RR01-001-ACA");

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
        assertEquals(PERIMETRE_NOT_FOUND_PRODUIT, actual.getBody().getMessage());
        assertNull(actual.getBody().getParametresProfilsDto());
        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }

    @Test
    public void date_recherche_after_produit_date_fin_effect_gives_status_200_ok() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setProduit("RR01-001-ACA");
        pfsDto.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-13" ));

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(2500,
                actual.getBody().getParametresProfilsDto().getMaxDesMontantsDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesMontantsDispo()
                .contains(t)).count());

        assertEquals(999,
                actual.getBody().getParametresProfilsDto().getMaxDesNombresDePaiementDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesNombresDePaiementDispo()
                .contains(t)).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceMinMontantDispoClient())).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceNombrePaiementDisponible())).count());

        assertEquals(29, actual.getBody().getInclusions().size());
        assertEquals(1, actual.getBody().getExclusions().size());
    }

    @Test
    public void date_recherche_after_contrat_date_fin_effect_gives_status_200_ok() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setContrat("RRE");
        pfsDto.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-13" ));

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(2500,
                actual.getBody().getParametresProfilsDto().getMaxDesMontantsDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesMontantsDispo()
                .contains(t)).count());

        assertEquals(999,
                actual.getBody().getParametresProfilsDto().getMaxDesNombresDePaiementDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesNombresDePaiementDispo()
                .contains(t)).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceMinMontantDispoClient())).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceNombrePaiementDisponible())).count());

        assertEquals(29, actual.getBody().getInclusions().size());
        assertEquals(1, actual.getBody().getExclusions().size());
    }

    @Test
    public void date_recherche_between_contrat_date_effect_and_date_fin_effect_throws_exception() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setContrat("RRE");
        pfsDto.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-10" ));

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
        assertEquals(PERIMETRE_NOT_FOUND_CONTRAT, actual.getBody().getMessage());
        assertNull(actual.getBody().getParametresProfilsDto());
        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }

    @Test
    public void unknown_structure_juridique_throws_exception() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setStructureJuridique("AAA");

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
        assertEquals(PERIMETRE_NOT_FOUND_STRUCTURE_JURIDIQUE, actual.getBody().getMessage());
        assertNull(actual.getBody().getParametresProfilsDto());
        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }

    @Test
    public void unknown_filiale_throws_exception() throws ParseException {
        //GIVEN
        pfsDto.getPerimetre().setFiliale("AAA");

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.NOT_FOUND, actual.getStatusCode());
        assertEquals(PERIMETRE_NOT_FOUND_FILIALE, actual.getBody().getMessage());
        assertNull(actual.getBody().getParametresProfilsDto());
        assertEquals(Collections.emptySet(), actual.getBody().getInclusions());
        assertEquals(Collections.emptySet(), actual.getBody().getExclusions());
    }


    @Test
    @Disabled
    public void date_recherche_before_all_paiements_dates_gives_default_plafonds() throws ParseException {
        //GIVEN
        pfsDto.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-07-22" ));

        //WHEN
        ResponseEntity<RecupParamRootResp> actual =
                testRestTemplate.postForEntity(uri, request, RecupParamRootResp.class);

        //THEN
        assertEquals(HttpStatus.OK, actual.getStatusCode());
        assertEquals(2500,
                actual.getBody().getParametresProfilsDto().getMaxDesMontantsDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesMontantsDispo()
                .contains(t)).count());

        assertEquals(999,
                actual.getBody().getParametresProfilsDto().getMaxDesNombresDePaiementDispo());

        assertEquals(3, Arrays.asList("CB", "VISA", "MASTERCARD").stream().filter(t -> actual
                .getBody().getParametresProfilsDto().getMethodeMaxDesNombresDePaiementDispo()
                .contains(t)).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceMinMontantDispoClient())).count());

        assertEquals(3,
                actual.getBody().getParametresProfilsDto().getPerimetreMethodePaiement()
                        .stream().filter(p -> TRANSACTION.name().equals(p.getFrequenceNombrePaiementDisponible())).count());
        assertNotNull(pfsDto.getDateRecherche());
        assertEquals(29, actual.getBody().getInclusions().size());
        assertEquals(1, actual.getBody().getExclusions().size());
    }


}