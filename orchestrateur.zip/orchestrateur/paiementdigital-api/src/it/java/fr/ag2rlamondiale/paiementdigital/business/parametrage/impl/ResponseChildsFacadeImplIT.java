package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.parametrage.ApiParametrageLabITData;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ActiveProfiles;

import javax.transaction.Transactional;
import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Transactional
@ActiveProfiles("it")
class ResponseChildsFacadeImplIT {

    @Autowired
    private IParametrageFacade parametrageFacade;

    @Autowired
    private IResponseChildsFacade childsFacade;

    @Autowired
    private ApiParametrageLabITData parametrageLabData;

    private RecupParamRootReq pfsDto;
    private Plafond plafond;
    private RecupParamProfResp parametre;
    private Set<RecupParamPlfdFreqResp> plafonds1;
    private Set<RecupParamPeriMethPaimtResp> methodes;
    private Set<ExclusionBanqueDto> exclusions;
    private Set<InclusionPaysDto> inclusions;

    @BeforeEach
    void setUp() throws ParseException {
        parametrageLabData.setUp();

        pfsDto = parametrageLabData.getPfsDto();
        plafond = parametrageLabData.getPlafond();
        parametre = parametrageLabData.getParametre();
        plafonds1 = parametrageLabData.getPlafonds1();
        methodes = parametrageLabData.getMethodes();

        exclusions = parametrageFacade.exclusions(pfsDto);
        inclusions = parametrageFacade.inclusions(pfsDto);
    }

    @AfterEach
    void tearDown() {
        pfsDto = null;
        plafond = null;
        parametre = null;
        exclusions = null;
        inclusions = null;

        plafonds1 = null;

        methodes = null;
    }

    @Test
    public void get_plafonds_par_frequences_dto_with_captured_montants() {
        //GIVEN
        float montantMaxdispoClient = 1100F;
        int nombreMaxDispoClient = 6;
        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(montantMaxdispoClient)
                .nombreMaxDispoClient(nombreMaxDispoClient)
                .build();

        List<Float> montantsCaptured = Arrays.asList(300F, 100F, 100F);


        //WHEN
        RecupParamPlfdFreqResp actual = childsFacade.plafondsParFrequences(plafond, montantsCaptured);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void get_plafonds_par_frequences_dto_without_captured_montants() {
        //GIVEN
        float montantMaxdispoClient = 1600F;
        int nombreMaxDispoClient = 9;
        RecupParamPlfdFreqResp expected = RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(montantMaxdispoClient)
                .nombreMaxDispoClient(nombreMaxDispoClient)
                .build();

        //WHEN
        RecupParamPlfdFreqResp actual = childsFacade.plafondsParFrequences(plafond, null);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void get_perimetre_methode_paiement_dto() {
        //GIVEN
        String methodeName = MethodePaiementEnum.CB.name();
        float minMontant = 3298.02f;
        String frequenceMontant = TypeFrequenceEnum.MOIS_GLISSANT.name();
        int minNombre = 995;
        String frequenceNombre = TypeFrequenceEnum.ANNEE_CIVILE.name();

        RecupParamPeriMethPaimtResp expected = RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(methodeName)
                .frequenceMinMontantDispoClient(frequenceMontant)
                .minMontantDispoClient(minMontant)
                .frequenceNombrePaiementDisponible(frequenceNombre)
                .minNombrePaiementDisponible(minNombre)
                .plafondsParFrequences(plafonds1)
                .build();

        //WHEN
        RecupParamPeriMethPaimtResp actual = childsFacade.perimetreMethodePaiement(methodeName, plafonds1);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }

    @Test
    public void get_parametres_profils_dto() {
        //WHEN
        RecupParamProfResp actual = childsFacade.parametresProfils(methodes);

        //THEN
        assertEquals(3298.02f, actual.getMaxDesMontantsDispo(), "Le montant doit être 3298.02.");
        assertEquals(995, actual.getMaxDesNombresDePaiementDispo(), "Le nombre de paiement restant doit être 995.");

        assertTrue(actual.getMethodeMaxDesNombresDePaiementDispo().contains("CB"), "Le resultat doit contenir la carte CB.");
        assertTrue(actual.getMethodeMaxDesNombresDePaiementDispo().contains("VISA"), "Le resultat doit contenir la carte VISA.");
        assertTrue(actual.getMethodeMaxDesNombresDePaiementDispo().contains("MASTERCARD"), "Le resultat doit contenir la carte MASTERCARD.");

    }

    @Test
    public void get_recuperer_parametrages_lab_dto() {
        //GIVEN
        RecupParamRootResp expected = RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametre)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();

        //WHEN
        RecupParamRootResp actual = childsFacade.recupererParametragesLab(parametre, exclusions, inclusions);

        //THEN
        assertThat(actual).isEqualToComparingFieldByField(expected);
    }
}