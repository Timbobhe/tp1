package fr.ag2rlamondiale.paiementdigital.bootstrap.transaction;

import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetMntPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetTransaPaimtNumResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.utils.TransactionUtils.buildLongDateTime;

@Component
public class ApiModifierTransactionITData {

    public ModifTransaRootReq buildRequest(String orderId, float montant, String... idTransaction) {
        ModifTransaDetTransaPaimtNumReq detTransaPaimtNum = ModifTransaDetTransaPaimtNumReq
                .builder()
                .orderId(orderId)
                .idTransaction(idTransaction.length > 0 ? idTransaction[0] : null)
                .typeOperationTransactionPaiementDigital(OPE_TRANSA_CAPTURE)
                .build();

        ModifTransaDetMntPaimtReq detMntPaimt = ModifTransaDetMntPaimtReq
                .builder()
                .montantTTC(montant)
                .codeDeviseVersement(DeviseEnum.EUR)
                .build();

        ModifTransaInfosTechReq infosTech = ModifTransaInfosTechReq
                .builder()
                .origineTransaction("AUTO")
                .referenceOperationPaiementDigital("REF")
                .referenceSousTransactionPaiementDigital("REF")
                .build();

        ModifTransaPaiementReq transaPaiement = ModifTransaPaiementReq
                .builder()
                .detailMontantPaiement(detMntPaimt)
                .detailTransactionPaiementNumerise(detTransaPaimtNum)
                .informationsTechniques(infosTech)
                .build();

        return new ModifTransaRootReq(transaPaiement);
    }

    public Paiement capture(Paiement paiement, float montant, EtatEnum etat) {
        Paiement result = paiement.copy(paiement);

        Date date = new Date();

        Historique historique = Historique.builder()
                .montant(montant)
                .etat(etat)
                .status(String.valueOf(HttpStatus.OK.value()))
                .message(HttpStatus.OK.name())
                .id(new HistoriquePK(date, paiement.getId()))
                .build();

        result.setMontant(montant);
        result.setEtatCourant(etat);
        result.setDateModification(date);
        result.getHistoriques().add(historique);

        return result;
    }

    public ModifTransaRootResp buildCapturedResponse(String orderId, String idTransaction, float montant) {
        ModifTransaDetTransaPaimtNumResp detTransaPaimtNum = ModifTransaDetTransaPaimtNumResp
                .builder()
                .orderId(orderId)
                .idTransaction(idTransaction)
                .typeOperationTransactionPaiementDigital(OPE_TRANSA_CAPTURE)
                .numeroAutorisationTransactionPaiementDigital("1234567")
                .instantAutorisationTransaction(buildLongDateTime(2021, 3, 12, 13, 0, 0))
                .instantCreationTransaction(buildLongDateTime(2021, 3, 12, 13, 0, 30))
                .instantMajTransaction(buildLongDateTime(2021, 3, 12, 13, 1, 00))
                .montantAutorisationPaiementDigital(montant)
                .montantTransfertPaiementDigital(montant)
                .montantCreditPaiementDigital(0f)
                .montantRemboursementPaiementDigital(0f)
                .build();

        ModifTransaDetMntPaimtResp detMntPaimt = new ModifTransaDetMntPaimtResp(DeviseEnum.EUR.name());

        ModifTransaResp modifTransaResp = ModifTransaResp
                .builder()
                .detailTransactionPaiementNumerise(detTransaPaimtNum)
                .detailMontantPaiement(detMntPaimt)
                .etatCourant(EtatEnum.CAPTURED.name())
                .status(STT_CODE_CAPTURED_OK)
                .message(CAPTURED)
                .identifiantMarchand("00001338125")
                .build();

        return ModifTransaRootResp.builder()
                .etatCourant(null)
                .codeErreur(null)
                .messageErreur(null)
                .modifTransaResp(modifTransaResp)
                .build();
    }

    public ModifTransaRootResp buildFailResponse(String orderId, String idTransaction, float montant) {
        ModifTransaDetTransaPaimtNumResp detTransaPaimtNum = ModifTransaDetTransaPaimtNumResp
                .builder()
                .orderId(orderId)
                .idTransaction(idTransaction)
                .typeOperationTransactionPaiementDigital(OPE_TRANSA_CANCEL)
                .numeroAutorisationTransactionPaiementDigital("1234567")
                .instantAutorisationTransaction(buildLongDateTime(2021, 3, 12, 13, 0, 0))
                .instantCreationTransaction(buildLongDateTime(2021, 3, 12, 13, 0, 30))
                .instantMajTransaction(buildLongDateTime(2021, 3, 12, 13, 1, 00))
                .montantAutorisationPaiementDigital(montant)
                .montantTransfertPaiementDigital(montant)
                .montantCreditPaiementDigital(0f)
                .montantRemboursementPaiementDigital(0f)
                .build();

        ModifTransaDetMntPaimtResp detMntPaimt = new ModifTransaDetMntPaimtResp(DeviseEnum.EUR.name());

        ModifTransaResp modifTransaResp = ModifTransaResp
                .builder()
                .detailTransactionPaiementNumerise(detTransaPaimtNum)
                .detailMontantPaiement(detMntPaimt)
                .etatCourant(EtatEnum.FAIL.name())
                .status(STT_CODE_CAPTURE_FAIL)
                .message("Fail")
                .identifiantMarchand("00001338125")
                .build();

        return ModifTransaRootResp.builder()
                .etatCourant(null)
                .codeErreur(null)
                .messageErreur(null)
                .modifTransaResp(modifTransaResp)
                .build();
    }

    public ModifTransaRootResp buildFuncErrorResponse() {
        return ModifTransaRootResp.builder()
                .etatCourant(EtatEnum.ERROR.name())
                .codeErreur("3000002")
                .messageErreur("Transaction not found")
                .modifTransaResp(null)
                .build();
    }
}
