package fr.ag2rlamondiale.paiementdigital.mapper.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetreDto;
import org.mapstruct.Mapper;

import java.util.Set;

@Mapper
public interface IPerimetreExcluMapper {

    Perimetre toPerimetre(PerimetreDto perimetre);

    PerimetreDto toPerimetreDto(Perimetre perimetre);

    Set<PerimetreDto> toDtoSet(Set<Perimetre> perimetres);

}
