package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
@Builder
public class ModifTransaDetTransaPaimtNumReq {

    @NotBlank
    private String orderId;

    private String idTransaction;

    @NotBlank
    private String typeOperationTransactionPaiementDigital;
}
