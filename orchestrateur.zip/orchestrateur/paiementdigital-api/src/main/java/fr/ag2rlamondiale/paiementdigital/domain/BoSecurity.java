package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BoSecurity {

    private String publicKey;

    private String secretKey;

    private long validityInMilliseconds;
}
