package fr.ag2rlamondiale.paiementdigital.dto;

import java.io.Serializable;

public abstract class BoResponse implements Serializable {

    private static final long serialVersionUID = -7306420140433094779L;

}
