package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ModifPaimtRootResp extends PfsResponse implements Serializable {

    private static final long serialVersionUID = 2711702039785904626L;

    @NotNull
    @JsonProperty("Response")
    private ModifPaimtResp response;
}
