package fr.ag2rlamondiale.paiementdigital.constantes;

public final class ControllerConstantes {

    private ControllerConstantes() {
    }

    public static final String CREER_TRANSACTION_URI = "/api/transaction/create";

    public static final String MODIFIER_TRANSACTION_URI = "/api/transaction/update";

    public static final String PARAMETRAGE_URI = "/api/parametrage/get";
}
