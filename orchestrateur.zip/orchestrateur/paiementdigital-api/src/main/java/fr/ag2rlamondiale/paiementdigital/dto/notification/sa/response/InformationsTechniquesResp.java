package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InformationsTechniquesResp implements Serializable {

    @JsonProperty("TroisDSecure")
    private TroisDSecureResp troisDSecure;

    @JsonProperty("adresseIP")
    private String adresseIp;

    private String deviceId;

    @JsonProperty("ip_country")
    private String ipCountry;




}
