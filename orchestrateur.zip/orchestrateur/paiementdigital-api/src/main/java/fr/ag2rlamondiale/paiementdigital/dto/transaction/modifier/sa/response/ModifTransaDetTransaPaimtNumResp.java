package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ModifTransaDetTransaPaimtNumResp implements Serializable {

    private static final long serialVersionUID = 8299903267183910221L;

    private String orderId;

    private String idTransaction;

    private String typeOperationTransactionPaiementDigital;

    private String numeroAutorisationTransactionPaiementDigital;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date instantCreationTransaction;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date instantMajTransaction;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private Date instantAutorisationTransaction;

    private float montantAutorisationPaiementDigital;

    private float montantTransfertPaiementDigital;

    private float montantRemboursementPaiementDigital;

    private float montantCreditPaiementDigital;

}
