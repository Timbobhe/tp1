package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class DetCnlComResp implements Serializable {

    private static final long serialVersionUID = -2183707014333673858L;

    @JsonProperty("Emails")
    private EmailsResp emails;
}
