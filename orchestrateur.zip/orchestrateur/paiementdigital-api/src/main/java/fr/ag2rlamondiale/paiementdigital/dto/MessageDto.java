/*
 * Cree le 17 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MessageDto<T extends Serializable> extends BoResponse implements Serializable {

    private static final long serialVersionUID = 2845804861760346222L;

    private int httpStatus;

    private String message;

    private T data;

    public static <T extends Serializable> MessageDto<T> sendSuccess(final T data, final String message, final HttpStatus httpStatus) {
        return MessageDto.<T>builder().data(data).message(message).httpStatus(httpStatus.value()).build();
    }

    public static <T extends Serializable> MessageDto<T> sendFailure(final String message, final HttpStatus httpStatus) {
        return MessageDto.<T>builder().message(message).httpStatus(httpStatus.value()).build();
    }
}
