package fr.ag2rlamondiale.paiementdigital.dto.type;

public enum CodeSexeEnum {
    M,
    F,
    U
}
