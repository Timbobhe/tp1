package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class NotificationBodyResp implements Serializable {

    private NotificationRootResp notificationRootResp;

}
