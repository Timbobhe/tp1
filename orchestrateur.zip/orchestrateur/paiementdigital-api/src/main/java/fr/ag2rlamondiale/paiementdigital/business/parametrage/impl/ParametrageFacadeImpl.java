package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.business.IRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IExclusionBanqueMapper;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IInclusionPaysMapper;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IRecupParamLABMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException.INCORRECT_REQUEST_PARAMETER_VALUE;

@Service
@Slf4j
public class ParametrageFacadeImpl implements IParametrageFacade {

    @Autowired
    private IRecupParamLABFacade recupParamLABFacade;

    @Autowired
    private IInclusionPaysFacade inclusionPaysFacade;

    @Autowired
    private IExclusionBanqueFacade exclusionBanqueFacade;

    @Autowired
    private IExclusionBanqueMapper banqueMapper;

    @Autowired
    private IInclusionPaysMapper paysMapper;

    @Autowired
    private IRecupParamLABMapper paramMapper;

    @Override
    public Perimetre perimetre(RecupParamRootReq pfsDto) {
        log.info("Recherche du périmètre associé aux données issues de la requête PFS.");

        if (Objects.isNull(pfsDto))
            throw new IncorrectParameterValueException(INCORRECT_REQUEST_PARAMETER_VALUE);

        return recupParamLABFacade.find(paramMapper.toRecupParamLAB(pfsDto));
    }

    @Override
    public Set<InclusionPaysDto> inclusions(RecupParamRootReq pfsDto) {
        log.info("Recherche de la liste des pays inclus.");
        if (Objects.isNull(pfsDto))
            throw new IncorrectParameterValueException(INCORRECT_REQUEST_PARAMETER_VALUE);

        log.debug("Recherche des pays inclus = {}", pfsDto.isInclusionPays());
        if (pfsDto.isInclusionPays())
            return paysMapper.toDtoSet(inclusionPaysFacade.find(pfsDto.getProfil().getMetier(),
                    pfsDto.getProfil().getCodeApplication(),
                    pfsDto.getDateRecherche()));

        return Collections.emptySet();
    }

    @Override
    public Set<ExclusionBanqueDto> exclusions(RecupParamRootReq pfsDto) {
        log.info("Recherche de la liste des banques exclues.");

        if (Objects.isNull(pfsDto))
            throw new IncorrectParameterValueException(INCORRECT_REQUEST_PARAMETER_VALUE);

        log.debug("Recherche des banques exclues = {}", pfsDto.isExclusionBanques());
        if (pfsDto.isExclusionBanques())
            return banqueMapper.toDtoSet(exclusionBanqueFacade.find(pfsDto.getDateRecherche()));

        return Collections.emptySet();
    }

}
