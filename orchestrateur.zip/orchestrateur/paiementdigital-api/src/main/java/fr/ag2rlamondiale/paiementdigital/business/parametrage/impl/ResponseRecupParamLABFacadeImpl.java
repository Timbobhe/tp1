package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IParametrageFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePerimetresMethodesFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class ResponseRecupParamLABFacadeImpl implements IResponseRecupParamLABFacade {

    @Autowired
    private IParametrageFacade parametrageFacade;

    @Autowired
    private IResponsePerimetresMethodesFacade perimetresMethodesFacade;

    @Autowired
    private IResponseChildsFacade childsFacade;

    @Override
    public RecupParamRootResp recupererParametragesLab(RecupParamRootReq pfsDto) {
        log.info("Demande de récupération du paramétrage LAB.");
        log.debug("pfsDto = {}", pfsDto);
        Perimetre perimetre = parametrageFacade.perimetre(pfsDto);

        log.info("Un périmètre trouvé en base de données Perimetre(id = {}, idParent = {}, " +
                "typePerimetre = {}, valeurPerimetre = {}, tiersPayeur = {}, dateEffet = {}, " +
                "dateFinEffet = {}, dateCreation = {}, dateModification = {}).",
                perimetre.getId(), perimetre.getIdParent(), perimetre.getTypePerimetre(), perimetre.getValeurPerimetre(),
                perimetre.isTiersPayeur(), perimetre.getDateEffet(), perimetre.getDateFinEffet(),
                        perimetre.getDateCreation(), perimetre.getDateModification());

        try {
            pfsDto.setDateRecherche(checkDateRecherche(pfsDto.getDateRecherche()));
        } catch (ParseException e) {
            log.error("Erreur lors du parsing de la date de recherche {}", e.getMessage());
        }

        Set<RecupParamPeriMethPaimtResp> methodes = perimetresMethodesFacade.getPerimetreMethodePaiementDtos(pfsDto, perimetre);

        return childsFacade.recupererParametragesLab(
                childsFacade.parametresProfils(methodes),
                parametrageFacade.exclusions(pfsDto),
                parametrageFacade.inclusions(pfsDto));
    }


    private Date checkDateRecherche(Date dateRecherche) throws ParseException {
        log.debug("Date de recherche reçue de PFS {}", dateRecherche);

        Calendar c = Calendar.getInstance();
        Calendar c1 = Calendar.getInstance();
        c.setTime(dateRecherche);
        c1.setTime(new Date());

        long diffInMillies = Math.abs(new Date().getTime() - c.getTime().getTime());
        long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);

        if(diff > 0){
            c.set(Calendar.HOUR_OF_DAY, 23);
            c.set(Calendar.MINUTE, 59);
            c.set(Calendar.SECOND, 59);
        }else
        {
            c.set(Calendar.HOUR_OF_DAY, c1.get(Calendar.HOUR_OF_DAY));
            c.set(Calendar.MINUTE, c1.get(Calendar.MINUTE));
            c.set(Calendar.SECOND, c1.get(Calendar.SECOND));
        }
        return c.getTime();
    }

}
