package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request;

import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModifPaimtDetMontantPaimtReq {

    private float montantTTC;

    private DeviseEnum codeDevVersm;

}
