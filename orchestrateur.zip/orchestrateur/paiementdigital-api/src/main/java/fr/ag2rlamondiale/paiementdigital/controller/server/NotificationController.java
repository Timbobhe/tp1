package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.notification.INotificationRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.NotificationException;
import fr.ag2rlamondiale.paiementdigital.mapper.notification.INotificationMapper;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;

@Validated
@RestController
@RequestMapping(value = "/api/notification", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class NotificationController {

    @Autowired
    private INotificationRespBuilderFacade notificationFacade;

    @Autowired
    private INotificationMapper mapper;


    @PostMapping("/send")
    public ResponseEntity<NotificationRootResp> sendNotification(@RequestBody NotificationRootReq request) {
        long startTime = Instant.now().toEpochMilli();
        log.info("Réception d'une notification");
        log.debug("NotificationRootReq {}", request);

        try {
            return new ResponseEntity<>(notificationFacade.build(request), ControllerUtils.getHttpHeaders(), HttpStatus.OK);
        } catch (NotificationException e) {
            ResponseEntity<NotificationRootResp> response = new ResponseEntity<>(e.getResponse(), e.getHttpStatus());
            log.error("Réponse pour la notification: {}", response);
            return response;
        } finally {
            long endTime = Instant.now().toEpochMilli();
            long timeElapsed = endTime - startTime;
            log.info("Temps d'execution pour le traitement de la notification : {} ms", timeElapsed);
        }

    }
}
