package fr.ag2rlamondiale.paiementdigital.business.transaction.commons;

import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;

@Service
public interface IPFSFacade {

    AbstractMap.SimpleEntry<String, String> modifTransaHeaderResp(PfsResponse pfsResponse);

    AbstractMap.SimpleEntry<String, String> creerTransaHeaderResp(PfsResponse pfsResponse);
}
