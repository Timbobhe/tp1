package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier.IModifierPaiementDigitalMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;

@Service
@Slf4j
public class ModifPaimtDigiReqBuilderFacadeImpl implements IModifPaimtDigiReqBuilderFacade {

    @Autowired
    private IModifierPaiementDigitalMapper mapper;

    @Override
    public ModifPaimtRootReq build(ModifTransaRootReq request) {
        log.info("Création de la request du SM ModifierPaiementDigital");
        log.debug("ModifTransaRootReq {}", request);

        if (Objects.isNull(request))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise = mapper.toDetTransaPaimtNumerise(request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise());

        ModifPaimtDetMontantPaimtReq detMontantPaimt = null;
        if (!Objects.isNull(request.getModificationTransactionPaiement().getDetailMontantPaiement()))
            detMontantPaimt = mapper.toDetMontantPaimt(request.getModificationTransactionPaiement().getDetailMontantPaiement());

        ModifPaimtInfoTechReq infoTech = null;
        if (!Objects.isNull(request.getModificationTransactionPaiement().getInformationsTechniques()))
            infoTech = mapper.toInfoTech(request.getModificationTransactionPaiement().getInformationsTechniques());

        ModifPaimtDigiBisReq paimtDigi = ModifPaimtDigiBisReq
                .builder()
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detailMontantPaimt(detMontantPaimt)
                .infoTech(infoTech)
                .build();

        ModifPaimtDigiReq modifierPaimtDigi = new ModifPaimtDigiReq(paimtDigi);

        ModifPaimtRootReq modifPaimtRootReq = new ModifPaimtRootReq(modifierPaimtDigi);

        log.debug("ModifPaimtRootReq : {}", modifPaimtRootReq);
        return modifPaimtRootReq;
    }
}
