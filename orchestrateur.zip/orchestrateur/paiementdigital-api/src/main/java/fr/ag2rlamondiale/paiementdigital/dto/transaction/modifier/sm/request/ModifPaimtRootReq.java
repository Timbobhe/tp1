package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifPaimtRootReq {

    @JsonProperty("ModifierPaimtDigi")
    private ModifPaimtDigiReq modifierPaimtDigi;

}
