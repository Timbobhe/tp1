package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailPerimetreMetierResp implements Serializable {

    private static final long serialVersionUID = 4464992223939803958L;

    private String metier;

    private String codeApplication;

    private String evenementMetier;

    private String structureJuridique;

    private String filiale;

    private String produit;

    private String contratDeReference;

    private String contrat;

    private String codeSilo;

}
