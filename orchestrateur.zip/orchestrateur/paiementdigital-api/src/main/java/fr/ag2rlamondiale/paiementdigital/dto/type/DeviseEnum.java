package fr.ag2rlamondiale.paiementdigital.dto.type;

public enum DeviseEnum {
    Euro,
    Dollar,
    EUR
}
