package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailActeurFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailProduitFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerPaimtDigiReqMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CreerPaimtDigiReqBuilderFacadeImpl implements ICreerPaimtDigiReqBuilderFacade {

    @Autowired
    private ICreerPaimtDigiReqMapper mapper;

    @Autowired
    private IDetailActeurFacade detailActeurFacade;

    @Autowired
    private IDetailProduitFacade detailProduitFacade;

    @Override
    public CreerPaimtDigiRootReq build(CreerTransaPaimtDigiRootReq request, Paiement paiement) {
        log.info("Création de la request de création de la transation pour la PFS");
        log.debug("CreerTransaPaimtDigiRootReq {}", request);
        log.debug("Paiement {}", paiement);

        RedirectReq redirect = mapper.toRedirect(request.getRedirection());

        DetTransaPaimtNumeriseReq detTransaPaimtNumerise = mapper.toDetTransaPaimtNumerise(request.getDetailTransPaiemtNumerise());

        DetMntPaimtReq detMntPaimt = mapper.toDetMntPaimt(request.getDetailMontantPaiement());

        DetCartePaimtReq detCartePaimt = mapper.toDetCartePaimt(request.getDetailMethodePaiement());

        DetEspCliReq detEspCli = mapper.toDetEspCli(request.getDetailEspaceClient());

        DetActrReq detActr = detailActeurFacade.detailActeurs(request);

        DetPdtReq detPdt = detailProduitFacade.detailProduit(request);

        DetSepaReq detSepaReq = mapper.toDetSepa(request.getDetailMethodePaiement().getDetailSepa());

        LivrReq livrReq = mapper.toLivr(request.getLivraison());

        InfoTechReq infoTechReq = mapper.toInfoTech(request.getInformationsTechniques());

        DetPorteMonnaieElecReq detPorteMonnaieElecReq = mapper.toDetPorteMonnaieElec(request.getDetailMethodePaiement().getDetailPrtMonElec());

        EntetePaimtNumeriseReq entetePaimtNumerise = mapper.toEntetePaimtNumerise(request.getEntetePaiementDigital(), paiement);

        PaimtDigiReq paimtDigi = PaimtDigiReq
                .builder()
                .entetePaimtNumerise(entetePaimtNumerise)
                .detActr(detActr)
                .detEspCli(detEspCli)
                .detCartePaimt(detCartePaimt)
                .detMntPaimt(detMntPaimt)
                .detTransaPaimtNumerise(detTransaPaimtNumerise)
                .detPdt(detPdt)
                .detSepa(detSepaReq)
                .livr(livrReq)
                .infoTech(infoTechReq)
                .detPorteMonnaieElec(detPorteMonnaieElecReq)
                .redirect(redirect)
                .build();

        CreerPaimtDigiBis creerPaimtDigiBis = new CreerPaimtDigiBis(paimtDigi);

        CreerPaimtDigiReq creerPaimtDigi = new CreerPaimtDigiReq(creerPaimtDigiBis);

        CreerPaimtDigiRootReq result = new CreerPaimtDigiRootReq(creerPaimtDigi);

        log.debug("CreerPaimtDigiRootReq {}", result);

        return result;
    }

}
