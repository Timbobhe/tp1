package fr.ag2rlamondiale.paiementdigital.business.transaction.commons;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface IInterpreteurPfsResponseFacade<R, U> {

    U interpreteur(ResponseEntity<R> response, Paiement paiement);

}
