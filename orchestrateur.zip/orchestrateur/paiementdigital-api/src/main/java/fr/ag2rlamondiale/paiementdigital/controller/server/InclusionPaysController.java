package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IInclusionPaysMapper;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@Validated
@RestController
@RequestMapping(value = "/api/pays", produces = MediaType.APPLICATION_JSON_VALUE)
public class InclusionPaysController {

    @Autowired
    private IInclusionPaysFacade facade;

    @Autowired
    private IInclusionPaysMapper mapper;

    @GetMapping("/{id}")
    public ResponseEntity<InclusionPaysDto> find(@PathVariable Long id) {
        InclusionPaysDto response = mapper.toPaysDto(facade.findById(id));
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<Set<InclusionPaysDto>> findAll() {
        Set<InclusionPaysDto> response = mapper.toDtoSet(facade.findAll());
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }
}
