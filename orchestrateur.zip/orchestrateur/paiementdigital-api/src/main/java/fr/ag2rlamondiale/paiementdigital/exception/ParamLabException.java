package fr.ag2rlamondiale.paiementdigital.exception;

public class ParamLabException extends RuntimeException {

    private static final long serialVersionUID = 1751129304022630521L;

    public static final String PLAFONDS_PAR_FREQUENCES = "Anomalie dans la constitution de la liste des plafonds par frequences.";

    public static final String PERIMETRE_METHODE_PAIEMENT = "Anomalie dans la constitution de la liste des perimetres par methode de paiement.";

    public static final String ANOMALIE_CALCUL_MAX = "Anomalie dans le calcul du maximum.";

    public static final String ANOMALIE_CALCUL_MIN = "Anomalie dans le calcul du minimum.";

    public ParamLabException(String message) {
        super(message);
    }

}
