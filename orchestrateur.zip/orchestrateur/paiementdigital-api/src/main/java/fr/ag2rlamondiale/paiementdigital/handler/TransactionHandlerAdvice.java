package fr.ag2rlamondiale.paiementdigital.handler;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerPaiementDigitalException;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierPaiementDigitalException;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class TransactionHandlerAdvice {

    @ExceptionHandler(CreerTransactionException.class)
    public ResponseEntity<CreerTransaPaimtDigiRootResp> handler(CreerTransactionException exception) {
        ControllerUtils.log(exception.getHttpStatus(), exception.getMessage());
        return new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
    }

    @ExceptionHandler(CreerPaiementDigitalException.class)
    public ResponseEntity<CreerPaimtDigiRootResp> handler(CreerPaiementDigitalException exception) {
        ControllerUtils.log(exception.getHttpStatus(), exception.getMessage());
        return new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
    }

    @ExceptionHandler(ModifierTransactionException.class)
    public ResponseEntity<ModifTransaRootResp> handler(ModifierTransactionException exception) {
        ControllerUtils.log(exception.getHttpStatus(), exception.getMessage());
        return new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
    }

    @ExceptionHandler(ModifierPaiementDigitalException.class)
    public ResponseEntity<ModifPaimtRootResp> handler(ModifierPaiementDigitalException exception) {
        ControllerUtils.log(exception.getHttpStatus(), exception.getMessage());
        return new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
    }

}
