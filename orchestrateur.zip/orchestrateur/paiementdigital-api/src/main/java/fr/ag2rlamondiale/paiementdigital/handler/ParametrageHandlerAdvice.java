package fr.ag2rlamondiale.paiementdigital.handler;

import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.*;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import static fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException.DUPLICATE_BANQUE;
import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.DUPLICATE_PAYS;
import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.DUPLICATE_PROFIL;

@RestControllerAdvice
public class ParametrageHandlerAdvice {

    @ExceptionHandler(ExclusionPerimetreException.class)
    public ResponseEntity<RecupParamRootResp> handler(ExclusionPerimetreException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return new ResponseEntity<>(RecupParamRootResp.sendFailure(httpStatus.value(), exception.getMessage()), httpStatus);
    }

    @ExceptionHandler(TooManyProfilsException.class)
    public ResponseEntity<RecupParamRootResp> handler(TooManyProfilsException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return new ResponseEntity<>(RecupParamRootResp.sendFailure(httpStatus.value(), exception.getMessage()), httpStatus);
    }

    @ExceptionHandler(ProfilException.class)
    public ResponseEntity<RecupParamRootResp> handler(ProfilException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        if (DUPLICATE_PROFIL.equals(exception.getMessage())) {
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        ControllerUtils.log(httpStatus, exception.getMessage());
        return new ResponseEntity<>(RecupParamRootResp.sendFailure(httpStatus.value(), exception.getMessage()), httpStatus);
    }

    @ExceptionHandler(ExclusionBanqueException.class)
    public ResponseEntity<RecupParamRootResp> handler(ExclusionBanqueException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        if (DUPLICATE_BANQUE.equals(exception.getMessage())) {
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        ControllerUtils.log(httpStatus, exception.getMessage());
        return new ResponseEntity<>(RecupParamRootResp.sendFailure(httpStatus.value(), exception.getMessage()), httpStatus);
    }

    @ExceptionHandler(InclusionPaysException.class)
    public ResponseEntity<RecupParamRootResp> handler(InclusionPaysException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        if (DUPLICATE_PAYS.equals(exception.getMessage())) {
            httpStatus = HttpStatus.BAD_REQUEST;
        }
        ControllerUtils.log(httpStatus, exception.getMessage());
        return new ResponseEntity<>(RecupParamRootResp.sendFailure(httpStatus.value(), exception.getMessage()), httpStatus);
    }

}
