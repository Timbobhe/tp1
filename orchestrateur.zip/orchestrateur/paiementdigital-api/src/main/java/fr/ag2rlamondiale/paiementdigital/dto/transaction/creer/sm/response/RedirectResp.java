package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class RedirectResp implements Serializable {

    private static final long serialVersionUID = -7773378238632296866L;

    @JsonProperty("forward_url")
    private String forwardUrl;

}
