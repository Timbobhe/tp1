package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.dto.type.CiviliteEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.CodeSexeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Signq2Req {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateNais;

    private CodeSexeEnum codeSexe;

    private String prenom;

    private String nom;

    private CiviliteEnum civ;

}
