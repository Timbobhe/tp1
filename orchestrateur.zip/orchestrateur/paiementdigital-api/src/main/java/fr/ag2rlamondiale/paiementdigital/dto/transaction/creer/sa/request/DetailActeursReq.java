package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.CiviliteEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.CodeSexeEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.RolePersonneEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetailActeursReq {

    private RolePersonneEnum codeRole;

    private String idUniqueClient;

    private NatureClientEnum natureClient;

    private TypeClientEnum typeClient;

    private boolean tiersPayeur;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateNaissance;

    private CodeSexeEnum codeSexe;

    private String prenom;

    private String nom;

    private String nomPayeur;

    private CiviliteEnum civilite;

    private String libelleEmail;

    private Set<TelephoneReq> telephone;

    private String adresseLigne1;

    private String adresseLigne2;

    private String libelleCommune;

    private String numeroCodePostal;

    private String paysResidence;

    private String paysResidenceFiscale;

}
