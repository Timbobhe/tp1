package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InformationsTechniquesReq {

    private String adresseIP;

    @JsonProperty("http_accept")
    private String httpAccept;

    @JsonProperty("http_user_agent")
    private String httpUserAgent;

    @JsonProperty("device_fingerprint")
    private String deviceFingerPrint;

    @JsonProperty("java_enabled")
    private String javaEnabled;

    @JsonProperty("javascript_enabled")
    private String javascriptEnabled;

    @JsonProperty("color_depth")
    private String colorDepth;

    @JsonProperty("screen_height")
    private String screenHeight;

    @JsonProperty("screen_width")
    private String screenWidth;

    private String language;

    private String timezone;

    @JsonProperty("device_channel")
    private String deviceChannel;

    @JsonProperty("sdk_info_interface")
    private String sdkInfoInterface;

    @JsonProperty("sdk_info_ui_type")
    private String sdkInfoUiType;

    @JsonProperty("sdk_info_app_id")
    private String sdkInfoAppId;

}
