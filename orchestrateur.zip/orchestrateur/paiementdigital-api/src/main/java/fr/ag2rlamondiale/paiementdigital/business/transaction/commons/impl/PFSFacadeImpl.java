package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IPFSFacade;
import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.ErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.HeaderResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtHeaderResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import io.jsonwebtoken.lang.Collections;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;
import java.util.Arrays;
import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;

@Service
@Slf4j
public class PFSFacadeImpl implements IPFSFacade {

    @Override
    public AbstractMap.SimpleEntry<String, String> modifTransaHeaderResp(PfsResponse pfsResponse) {
        log.info("Récupération du code et du message de la réponse du SM ModifierPaiementDigital");
        log.debug("PfsResponse {}", pfsResponse);
        AbstractMap.SimpleEntry<String, String> result = null;

        if (Objects.isNull(pfsResponse))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        ModifPaimtRootResp response = (ModifPaimtRootResp) pfsResponse;
        ModifPaimtHeaderResp header = response.getResponse().getHeader();
        ModifPaimtErrorResp error = !Collections.isEmpty(header.getFuncError()) ? header.getFuncError().get(0) : header.getTechError().get(0);

        log.debug("Erreur : {}", error);

        String[] chunks = error.getErrorMessage().trim().replaceAll("\\s+", " ").split(":");

        result = getEntry(chunks, error.getErrorCode().trim(), error.getErrorMessage().trim());

        log.debug("Erreur et message déduit de la réponse PFS {}", result);
        return result;
    }

    @Override
    public AbstractMap.SimpleEntry<String, String> creerTransaHeaderResp(PfsResponse pfsResponse) {
        log.info("Récupération du code et du message de la réponse du SM CreerPaiementDigital");
        log.debug("Récupération du code et du message d'erreur fonctionnel ou technique dans la réponse fournie par la PFS : {}", pfsResponse);
        AbstractMap.SimpleEntry<String, String> result = null;

        if (Objects.isNull(pfsResponse))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        CreerPaimtDigiRootResp response = (CreerPaimtDigiRootResp) pfsResponse;
        HeaderResp header = response.getResponse().getHeader();
        ErrorResp error = !Collections.isEmpty(header.getFuncError()) ? header.getFuncError().get(0) : header.getTechError().get(0);

        log.debug("Erreur : {}", error);

        String[] chunks = error.getErrorMessage().trim().replaceAll("\\s+", " ").split(":");

        result = getEntry(chunks, error.getErrorCode().trim(), error.getErrorMessage().trim());

        log.debug("Erreur et message déduit de la réponse PFS {}", result);
        return result;
    }

    private AbstractMap.SimpleEntry<String, String> getEntry(String[] chunks, String errorCode, String errorMessage) {
        AbstractMap.SimpleEntry<String, String> result;
        if (chunks.length != 3) {

            result = new AbstractMap.SimpleEntry<>(errorCode, String.join(" ", errorMessage));

        } else {

            String[] chunk3 = chunks[2].split(" ");

            if (chunk3[0].length() == 7) {
                String[] message = Arrays.copyOfRange(chunk3, 1, chunk3.length);
                result = new AbstractMap.SimpleEntry<>(chunk3[0].trim(), String.join(" ", message));
            } else {
                result = new AbstractMap.SimpleEntry<>(errorCode, String.join(" ", chunks[2].trim()));
            }
        }
        return result;
    }

}
