package fr.ag2rlamondiale.paiementdigital.business.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface ICreerTransaRespBuilderFacade {

    CreerTransaPaimtDigiRootResp build(Paiement paiement, ResponseEntity<CreerPaimtDigiRootResp> response);

}
