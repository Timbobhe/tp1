package fr.ag2rlamondiale.paiementdigital.utils;

import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetreDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetreInfosDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PerimetrePlafondDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.PlafondDto;

import java.util.Date;
import java.util.Set;

public final class ApiParametrageUtils {

    private ApiParametrageUtils() {
    }

    public static PerimetreDto perimetreDto(Long id, Long idParent, TypePerimetreEnum typePerimetre, String valeurPerimetre, boolean tiersPayeur, Date dateEffet,
                                            Date dateFinEffet, Date dateCreation, Date dateModification, PerimetreInfosDto perimetreInfos,
                                            Set<PerimetrePlafondDto> perimetrePlafonds) {
        PerimetreDto perimetreDto = PerimetreDto
                .builder()
                .id(id)
                .idParent(idParent)
                .typePerimetre(typePerimetre)
                .valeurPerimetre(valeurPerimetre)
                .tiersPayeur(tiersPayeur)
                .dateEffet(dateEffet)
                .dateFinEffet(dateFinEffet)
                .dateCreation(dateCreation)
                .dateModification(dateModification)
                .perimetreInfos(perimetreInfos)
                .perimetrePlafonds(perimetrePlafonds)
                .build();

        if (id != 0 || id == null)
            perimetreDto.setId(id);

        return perimetreDto;
    }

    public static PerimetreInfosDto perimetreInfosDto(String structureJuridique, String filiale, String produit,
                                                      String contratDeReference, String contrat) {
        return PerimetreInfosDto
                .builder()
                .structureJuridique(structureJuridique)
                .filiale(filiale)
                .produit(produit)
                .contratDeReference(contratDeReference)
                .contrat(contrat)
                .build();
    }

    public static PerimetrePlafondDto perimetrePlafondDto(String methodePaiement, PlafondDto plafond) {
        return PerimetrePlafondDto
                .builder()
                .methodePaiement(methodePaiement)
                .plafond(plafond)
                .build();
    }

    public static PlafondDto plafondDto(Long id, TypeFrequenceEnum typeFrequence, float montantMinimum, float montantMaximum, int nombreMaximumPaiement) {
        return PlafondDto
                .builder()
                .id(id)
                .typeFrequence(typeFrequence)
                .montantMinimum(montantMinimum)
                .montantMaximum(montantMaximum)
                .nombreMaximumPaiement(nombreMaximumPaiement)
                .build();
    }

}
