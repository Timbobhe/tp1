package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InformationsTechniquesReq {


    @JsonProperty("TroisDSecure")
    private TroisDSecureReq troisDSecure;

    @JsonProperty("adresseIP")
    private String adresseIp;

    @JsonProperty("deviceId")
    private String deviceId;

    @JsonProperty("ip_country")
    private String ipCountry;
}
