package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaimentDigiResp implements Serializable {

    @JsonProperty("CustomData")
    @Builder.Default
    private Set<CustomDataResp> customDatas = new HashSet<>();

    @JsonProperty("DepistageFraude")
    DepistageFraudeResp depistageFraude;

    @JsonProperty("DetailActeur")
    DetailActeurResp detailActeur;

    @JsonProperty("DetailCartePaiement")
    private DetailCartePaiementResp detailCartePaiement;

    @JsonProperty("DetailMontantPaiement")
    DetailMontantPaiementResp detailMontantPaiement;

    @JsonProperty("DetailTransactionPaiementNumerise")
    private DetailTransactionPaiementNumeriseResp detailTransPaiemtNumerise;

    @JsonProperty("EntetePaiementNumerise")
    private EntetePaiementNumeriseResp entetePaiementNumerise;

    @JsonProperty("InformationsTechniques")
    InformationsTechniquesResp informationsTechniques;

    @JsonProperty("MaintenanceOperation")
    MaintenanceOperationResp maintenanceOperation;

    @JsonProperty("DonneesMetier")
    private Set<DonneeMetierResp> donneesMetier;

    @JsonProperty("destinataire")
    private String destinataire;

    @JsonProperty("identifiantMarchant")
    private String identifiantMarchant;

    @JsonProperty("identifiantTentative")
    private String identifiantTentative;

    @JsonProperty("indicateurModeTest")
    private Boolean indicateurModeTest;

    @JsonProperty("message")
    private String message;

    @JsonProperty("statut")
    private String statut;

}
