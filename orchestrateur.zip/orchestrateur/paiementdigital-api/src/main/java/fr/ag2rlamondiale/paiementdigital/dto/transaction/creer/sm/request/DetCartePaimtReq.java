package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import fr.ag2rlamondiale.paiementdigital.dto.type.CarteCreditEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetCartePaimtReq {

    private String idChiffreMoyenPaimt;

    private String numCarte;

    private CarteCreditEnum codeTypeCarte;

}
