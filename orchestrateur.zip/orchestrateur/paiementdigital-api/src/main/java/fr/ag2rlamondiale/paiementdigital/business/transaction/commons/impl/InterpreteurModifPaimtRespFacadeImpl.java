package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IPFSFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDigiBisResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.AbstractMap;
import java.util.Date;
import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.STT_CODE_CAPTURED_OK;
import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.STT_CODE_CAPTURE_FAIL;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.VALEUR_STT_EXCEPTION;

@Service
@Slf4j
public class InterpreteurModifPaimtRespFacadeImpl implements IInterpreteurPfsResponseFacade<ModifPaimtRootResp, Paiement> {

    @Autowired
    private IPaiementFacade paiementFacade;

    @Autowired
    private IPFSFacade pfsFacade;

    @Override
    public Paiement interpreteur(ResponseEntity<ModifPaimtRootResp> response, Paiement paiement) {
        log.info("Interprétation de la reponse PFS ModifierPaiementDigital");
        log.debug("ResponseEntity<ModifPaimtRootResp> {}", response);
        log.debug("Paiement {} {}", paiement);

        if (Objects.isNull(response) || Objects.isNull(paiement) || Objects.isNull(response.getBody()))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        ModifPaimtRootResp modifPaimtRootResp = response.getBody();
        HttpStatus status = response.getStatusCode();
        log.debug("Le statut http de la réponse ModifierPaiementDigital est {}", status.value());

        if (HttpStatus.OK.equals(status) || HttpStatus.valueOf(status.value()).is4xxClientError()) {
            Paiement paiementCopy = null;
            float montant = getMontant(paiement, modifPaimtRootResp, status);
            log.debug("Montant {}", montant);

            if (HttpStatus.valueOf(status.value()).is4xxClientError()) {

                AbstractMap.SimpleEntry<String, String> entry = pfsFacade.modifTransaHeaderResp(modifPaimtRootResp);

                Historique historique = Historique
                        .builder()
                        .etat(EtatEnum.ERROR)
                        .montant(montant)
                        .status(entry.getKey())
                        .message(entry.getValue())
                        .id(new HistoriquePK(new Date(), paiement.getId()))
                        .paiement(paiement)
                        .build();
                paiementCopy = paiement.copy(paiement);
                paiementCopy.setIdTransaction(null);
                paiementCopy.setMontant(montant);
                paiementCopy.setEtatCourant(EtatEnum.ERROR);
                paiementCopy.setDateModification(new Date());
                paiementCopy.getHistoriques().add(historique);
            } else {
                ModifPaimtDigiBisResp paimtDigi = modifPaimtRootResp.getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc().getPaimtDigi();
                paiementCopy = processStt(paiement, montant, paimtDigi);
            }

            try {
                Paiement paiementUpdated = paiementFacade.update(paiementCopy);

                log.debug("Résultat du paiement après mise à jour en base de données : {}", paiementUpdated);

                return paiementUpdated;
            } catch (PaiementException e) {
                throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
            }
        }

        throw new ModifierTransactionException(response);
    }

    private Paiement processStt(Paiement paiement, float montant, ModifPaimtDigiBisResp paimtDigi) {
        EtatEnum etat = EtatEnum.CAPTURED;
        Historique historique = Historique
                .builder()
                .etat(etat)
                .status(STT_CODE_CAPTURED_OK)
                .message(null)
                .montant(montant)
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .build();

        if (STT_CODE_CAPTURED_OK.equals(paimtDigi.getStt()) || STT_CODE_CAPTURE_FAIL.equals(paimtDigi.getStt())) {

            if (STT_CODE_CAPTURE_FAIL.equals(paimtDigi.getStt())) {
                etat = EtatEnum.FAIL;
                historique = Historique
                        .builder()
                        .etat(etat)
                        .montant(montant)
                        .status(STT_CODE_CAPTURE_FAIL)
                        .message(paimtDigi.getMsg())
                        .id(new HistoriquePK(new Date(), paiement.getId()))
                        .paiement(paiement)
                        .build();
            }

        } else {
            throw new ModifierTransactionException(HttpStatus.BAD_REQUEST, VALEUR_STT_EXCEPTION);
        }

        Paiement paiementCopy = paiement.copy(paiement);
        paiementCopy.setEtatCourant(etat);
        paiementCopy.setMontant(montant);
        paiementCopy.setDateModification(new Date());
        paiementCopy.getHistoriques().add(historique);

        return paiementCopy;
    }

    private float getMontant(Paiement paiement, ModifPaimtRootResp response, HttpStatus status) {
        return (!HttpStatus.OK.equals(status)) ? paiement.getMontant() : response.getResponse().getBody()
                .getModifierPaimtDigiResponse().getModifierPaimtDigiFunc().getPaimtDigi()
                .getDetTransaPaimtNumerise().getMntTrsfPaimtDigi();
    }

}
