package fr.ag2rlamondiale.paiementdigital.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class ApiSecurityConfig {

    @Value("${jwt.public.key}")
    private String publicKey;

}
