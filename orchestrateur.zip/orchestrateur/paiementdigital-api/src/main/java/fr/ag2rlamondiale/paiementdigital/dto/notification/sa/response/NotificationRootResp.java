package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.BoResponse;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class NotificationRootResp extends BoResponse implements Serializable {

    private static final long serialVersionUID = -4614788292229925336L;

    private EtatEnum etatCourant;

    private String codeErreur;

    private String messageErreur;

    @JsonProperty("NotifierPaiementDigital")
    NotificationResp notificationResp;

    public static CreerTransaPaimtDigiRootResp sendFailure(int code, String message) {
        return CreerTransaPaimtDigiRootResp.builder()
                .etatCourant(EtatEnum.ERROR)
                .codeErreur(String.valueOf(code))
                .messageErreur(message)
                .creationTransactionPaiementDigital(null)
                .build();
    }
}
