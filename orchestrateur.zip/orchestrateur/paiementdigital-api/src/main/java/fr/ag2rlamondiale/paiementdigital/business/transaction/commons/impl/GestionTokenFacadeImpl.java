package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.LM;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.LMO;

@Service
@Slf4j
public class GestionTokenFacadeImpl implements IGestionTokenFacade {

    @Autowired
    private PfsPropertyConfig pfsPropertyConfig;

    @Override
    public String getUriWithParams(String uri, String structureJuridique, String filiale) {
        return build(uri,structureJuridique, filiale);
    }

    private String build(String uri, String structureJuridique, String filiale) {
        log.info("Création de l'URI avec les paramètres avant appel à la PFS");
        log.debug("URI {}", uri);
        log.debug("Filiale {}", filiale);

        String token = getToken(structureJuridique, filiale);
        log.debug("Token déduit de la filiale {}", token);

        String result = UriComponentsBuilder
                .fromUriString(uri)
                .queryParam(PfsParametersConstantes.APPLICATION, pfsPropertyConfig.getCodeApplication())
                .queryParam(PfsParametersConstantes.TOKEN, token)
                .queryParam(PfsParametersConstantes.USER, pfsPropertyConfig.getUser())
                .build()
                .encode()
                .toUri()
                .toString();

        log.debug("Uri d'appel à la PFS {}", result);
        return result;
    }

    private String getToken(String structureJuridique, String filiale) {

        if(LM.equalsIgnoreCase(structureJuridique.trim()) && !LMO.equalsIgnoreCase(filiale))
            return pfsPropertyConfig.getTokenLM();

        return LMO.equalsIgnoreCase(filiale) ?
                pfsPropertyConfig.getTokenLMO() : pfsPropertyConfig.getTokenARI();
    }

}
