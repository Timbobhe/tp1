package fr.ag2rlamondiale.paiementdigital.mapper.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface IRecupParamLABMapper {

    @Mapping(target = "metier", source = "pfsDto.profil.metier")
    @Mapping(target = "codeApplication", source = "pfsDto.profil.codeApplication")
    @Mapping(target = "evenementMetier", source = "pfsDto.profil.evenementMetier")
    @Mapping(target = "natureClient", source = "pfsDto.client.natureClient")
    @Mapping(target = "typeClient", source = "pfsDto.client.typeClient")
    @Mapping(target = "structureJuridique", source = "pfsDto.perimetre.structureJuridique")
    @Mapping(target = "filiale", source = "pfsDto.perimetre.filiale")
    @Mapping(target = "produit", source = "pfsDto.perimetre.produit")
    @Mapping(target = "contratDeReference", source = "pfsDto.perimetre.contratDeReference")
    @Mapping(target = "contrat", source = "pfsDto.perimetre.contrat")
    @Mapping(target = "tiersPayeur", source = "pfsDto.perimetre.tiersPayeur")
    @Mapping(target = "dateRecherche", source = "pfsDto.dateRecherche")
    RecupParamLAB toRecupParamLAB(RecupParamRootReq pfsDto);

}
