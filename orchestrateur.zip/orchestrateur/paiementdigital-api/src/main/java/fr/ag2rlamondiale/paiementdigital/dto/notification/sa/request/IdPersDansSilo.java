package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IdPersDansSilo {

    private String identifiantPersonne;

    private String codeApplication;

}
