package fr.ag2rlamondiale.paiementdigital.exception;

import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class NotificationException extends RuntimeException {

    private static final long serialVersionUID = 17511293040221245L;

    public static final String INVALID_PARAMETER = "Le paramètre ne peut être null!";

    private HttpStatus httpStatus;

    private NotificationRootResp response;

    public NotificationException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
        response = NotificationRootResp.builder()
                .etatCourant(EtatEnum.ERROR)
                .codeErreur(String.valueOf(httpStatus.value()))
                .messageErreur(message)
                .notificationResp(null)
                .build();
        log.error("Exception : {}", response);
    }

}
