package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class SignaletiqueResp implements Serializable {

    private static final long serialVersionUID = 7055555404689063586L;

    @JsonProperty("DosCom")
    private DosComResp dosCom;

}
