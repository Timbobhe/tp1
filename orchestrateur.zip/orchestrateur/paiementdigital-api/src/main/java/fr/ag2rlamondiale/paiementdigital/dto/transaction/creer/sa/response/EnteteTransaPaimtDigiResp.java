package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnteteTransaPaimtDigiResp implements Serializable {

    private static final long serialVersionUID = -7735494613842840366L;

    private String orderId;

    private String codeValeurECI;

    @JsonProperty("numeroTentativePaiementDigital")
    private String numTentativePaiemtDigi;

    private String methodeDePaiement;
}
