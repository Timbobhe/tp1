package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.PfsResponse;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CreerPaimtDigiRootResp extends PfsResponse implements Serializable {

    private static final long serialVersionUID = -6167721990659788335L;

    @JsonProperty("Response")
    private ResponseResp response;

}
