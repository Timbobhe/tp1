package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifTransaDetMntPaimtResp implements Serializable {

    private static final long serialVersionUID = -4567649331773394895L;

    private String codeDeviseVersement;

}
