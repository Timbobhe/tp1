package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EtatTransaPaimtDigiResp implements Serializable {

    private static final long serialVersionUID = 3099710066067669895L;

    private EtatEnum etatCourant;

    private String status;

    private String message;

    @JsonProperty("codeSituationTransactionPaiementDigital")
    private String codeSitTransPaiemtDigi;
}
