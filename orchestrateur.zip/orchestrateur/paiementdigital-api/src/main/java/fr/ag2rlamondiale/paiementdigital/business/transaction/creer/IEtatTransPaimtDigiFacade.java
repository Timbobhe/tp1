package fr.ag2rlamondiale.paiementdigital.business.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.EtatTransaPaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.DetTransaPaimtNumeriseResp;
import org.springframework.stereotype.Service;

@Service
public interface IEtatTransPaimtDigiFacade {

    EtatTransaPaimtDigiResp toEtatTransactionPaiementDigital(Paiement paiement, DetTransaPaimtNumeriseResp detTransaPaimtNumerise);
}
