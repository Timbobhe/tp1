package fr.ag2rlamondiale.paiementdigital.exception;

public class BoPaiementException extends RuntimeException {

    private static final long serialVersionUID = -8117176807389048574L;

    public BoPaiementException(String message) {
        super(message);
    }

}
