package fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface ICreerTransaToPaimtMapper {

    @Mapping(source = "detailActeurs.idUniqueClient", target = "idUniqueClient")
    @Mapping(source = "detailActeurs.nomPayeur", target = "nomPayeur")
    @Mapping(source = "detailPerimetreMetier.metier", target = "metier")
    @Mapping(source = "detailPerimetreMetier.codeApplication", target = "codeApplication")
    @Mapping(source = "detailPerimetreMetier.evenementMetier", target = "evenementMetier")
    @Mapping(source = "detailMontantPaiement.montantTTC", target = "montant")
    @Mapping(source = "detailMethodePaiement.methodeDePaiement", target = "methodeDePaiement")
    @Mapping(source = "detailMethodePaiement.paysMethode", target = "paysMethode")
    @Mapping(source = "detailMethodePaiement.banque", target = "banque")
    @Mapping(source = "detailPerimetreMetier.structureJuridique", target = "structureJuridique")
    @Mapping(source = "detailPerimetreMetier.filiale", target = "filiale")
    @Mapping(source = "detailPerimetreMetier.produit", target = "produit")
    @Mapping(source = "detailPerimetreMetier.contrat", target = "contrat")
    @Mapping(source = "detailPerimetreMetier.contratDeReference", target = "contratDeReference")
    @Mapping(source = "detailActeurs.tiersPayeur", target = "tiersPayeur")
    @Mapping(source = "detailActeurs.typeClient", target = "typeClient")
    @Mapping(source = "detailActeurs.natureClient", target = "natureClient")
    @Mapping(source = "detailActeurs.paysResidence", target = "paysResidence")
    @Mapping(source = "detailActeurs.paysResidenceFiscale", target = "paysResidenceFiscale")
    @Mapping(source = "customDatas", target = "customDatas")
    @Mapping(source = "donneesMetiers", target = "donneeMetiers")
    Paiement toPaiement(CreerTransaPaimtDigiRootReq request);
}
