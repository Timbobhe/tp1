package fr.ag2rlamondiale.paiementdigital.handler;

import fr.ag2rlamondiale.paiementdigital.dto.BoResponse;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

import static fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException.AUCUN_PERIMETRE_EXCLU_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException.DUPLICATE_PERIMETRE_EXCLU;

@RestControllerAdvice
public class BoHandlerAdvice {

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, HttpMessageNotReadableException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, MethodArgumentNotValidException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, IllegalArgumentException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

    @ExceptionHandler(IncorrectParameterValueException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, IncorrectParameterValueException exception) {
        HttpStatus httpStatus = HttpStatus.BAD_REQUEST;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

    @ExceptionHandler(NotFoundParameterValueException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, NotFoundParameterValueException exception) {
        HttpStatus httpStatus = HttpStatus.NOT_FOUND;
        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

    @ExceptionHandler(PerimetreExcluException.class)
    public ResponseEntity<BoResponse> handler(HttpServletRequest req, PerimetreExcluException exception) {
        HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;

        if (AUCUN_PERIMETRE_EXCLU_TROUVE.equalsIgnoreCase(exception.getMessage()))
            httpStatus = HttpStatus.NOT_FOUND;
        else if (DUPLICATE_PERIMETRE_EXCLU.equalsIgnoreCase(exception.getMessage()))
            httpStatus = HttpStatus.BAD_REQUEST;

        ControllerUtils.log(httpStatus, exception.getMessage());
        return ControllerUtils.buildResponse(req, exception, httpStatus);
    }

}
