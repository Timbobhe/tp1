package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TroisDSecureResp implements Serializable {

    private String codeValeurECI;

    private String identifiantTransaction;

    private String messageAuthentification;

    private String messageInscription;

    private String statutAuthentification;

    private String statutInscription;

    private String tokenAuthentification;

}
