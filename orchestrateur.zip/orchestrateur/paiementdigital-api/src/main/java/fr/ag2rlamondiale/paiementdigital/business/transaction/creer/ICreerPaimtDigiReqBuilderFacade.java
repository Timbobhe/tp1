package fr.ag2rlamondiale.paiementdigital.business.transaction.creer;


import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import org.springframework.stereotype.Service;

@Service
public interface ICreerPaimtDigiReqBuilderFacade {

    CreerPaimtDigiRootReq build(CreerTransaPaimtDigiRootReq creationTransaction, Paiement paiement);

}
