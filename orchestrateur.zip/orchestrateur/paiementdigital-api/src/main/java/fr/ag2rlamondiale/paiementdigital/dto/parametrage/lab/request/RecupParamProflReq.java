package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request;

import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecupParamProflReq {

    @NotBlank
    @Size(min = 1, max = 10, message = "Le champs 'metier' doit faire entre 1 et 10 caractères.")
    private String metier;

    @NotBlank
    @Size(min = 5, max = 5, message = "Le champs 'codeApplication' doit faire exactement 5 caractères.")
    private String codeApplication;

    @Size(max = 10, message = "Le champs 'evenementMetier' doit faire 10 caractères maximum.")
    private TypeEvenementMetier evenementMetier;

}
