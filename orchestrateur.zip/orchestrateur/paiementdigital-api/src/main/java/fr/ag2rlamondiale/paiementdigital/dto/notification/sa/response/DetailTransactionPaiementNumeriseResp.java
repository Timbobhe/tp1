package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties("montantTransactionPaiementDigital")
public class DetailTransactionPaiementNumeriseResp  implements Serializable {

    private String codeDeviseMontantTransactionPaiementDigital;

    private String codeRepControleAVS;

    private String codeRepControleCVC;

    private String codeSituationTransactionPaiementDigital;

    private String codeTechniqueSituationTransactionPaiementDigital;

    private String decimals;

    private Date instantAutorisationTransaction;

    private Date instantCreationTransaction;

    private Date instantModificationTransaction;

    private String libelleSituationTransactionPaiementDigital;

    private float montantTransactionPaiementDigital;

    private String numeroAutorisationPaiementDigital;

    @JsonProperty("referenceTransactionPaiementDigital")
    private String referenceTransactionPaiementDigital;

}
