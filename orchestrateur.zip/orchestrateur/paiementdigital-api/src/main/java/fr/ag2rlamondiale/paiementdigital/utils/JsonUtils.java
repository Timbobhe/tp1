package fr.ag2rlamondiale.paiementdigital.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.BoPaiementException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;

import java.io.File;
import java.io.IOException;

@Slf4j
public final class JsonUtils {

    private JsonUtils() {
    }

    public static String asJsonString(final Object object) {
        String result = "";
        ObjectMapper mapper = new ObjectMapper();
        try {
            result = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            log.error("Anomalie lors du mapping au format JSON : {}", e.getMessage());
        }
        return result;
    }

    public static Object filenameContentToObject(String filename, Class<?> object) {
        ObjectMapper objMapper = new ObjectMapper();
        try {
            File resource = new ClassPathResource(filename).getFile();
            return objMapper.readValue(resource, object);
        } catch (IOException e) {
            throw new BoPaiementException(e.getMessage());
        }
    }

    public static Object stringToObject(String objectAsString, Class<?> object) {
        ObjectMapper objMapper = new ObjectMapper();
        try {
            return objMapper.readValue(objectAsString, object);
        } catch (JsonProcessingException e) {
            throw new BoPaiementException(e.getMessage());
        }
    }

    public static CreerPaimtDigiRootReq paiementRequest(String filename) {
        return (CreerPaimtDigiRootReq) filenameContentToObject(filename, CreerPaimtDigiRootReq.class);
    }

    public static CreerPaimtDigiRootResp paiementResponse(String filename) {
        return (CreerPaimtDigiRootResp) filenameContentToObject(filename, CreerPaimtDigiRootResp.class);
    }

    public static CreerTransaPaimtDigiRootReq transactionRequest(String filename) {
        return (CreerTransaPaimtDigiRootReq) filenameContentToObject(filename, CreerTransaPaimtDigiRootReq.class);
    }

    public static ModifPaimtRootReq modifierPaiementRequest(String filename) {
        return (ModifPaimtRootReq) filenameContentToObject(filename, ModifPaimtRootReq.class);
    }

    public static ModifPaimtRootResp modifierPaiementResponse(String filename) {
        return (ModifPaimtRootResp) filenameContentToObject(filename, ModifPaimtRootResp.class);
    }

    public static RecupParamRootReq parametrageRequest(String filename) {
        return (RecupParamRootReq) filenameContentToObject(filename, RecupParamRootReq.class);
    }

    public static NotificationRootReq notificationRequest(String filename) {
        return (NotificationRootReq) filenameContentToObject(filename, NotificationRootReq.class);
    }

    public static NotificationRootResp notificationResponse(String filename) {
        return (NotificationRootResp) filenameContentToObject(filename, NotificationRootResp.class);
    }

}
