package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetSepaReq {

    private String codeIBAN;

    private String codeBIC;

    private String idRUM;

    private String libEtabBanc;

    private String indAccordMandatSEPA;

}
