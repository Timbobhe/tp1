package fr.ag2rlamondiale.paiementdigital.mapper.notification;

import fr.ag2rlamondiale.paiementdigital.domain.DonneeMetier;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Set;

@Mapper()
public interface INotificationMapper {

    Set<CustomDataResp> toCustomData(Set<CustomDataReq> customData);

    DepistageFraudeResp toDepistageFraude(DepistageFraudeReq depistageFraude);

    DetailActeurResp toDetailActeur(DetailActeurReq detailActeur);

    DetailCartePaiementResp toDetailCartePaiement(DetailCartePaiementReq detailCartePaiement);

    DetailMontantPaiementResp toDetailMontantPaiement(DetailMontantPaiementReq detailMontantPaiement);

    @Mapping(source = "detTransaPaimtNum.codeDeviseMontantTransactionPaiementDigital", target = "codeDeviseMontantTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.codeRepControleAVS", target = "codeRepControleAVS")
    @Mapping(source = "detTransaPaimtNum.codeRepControleCVC", target = "codeRepControleCVC")
    @Mapping(source = "detTransaPaimtNum.codeSituationTransactionPaiementDigital", target = "codeSituationTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.codeTechniqueSituationTransactionPaiementDigital", target = "codeTechniqueSituationTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.decimals", target = "decimals")
    @Mapping(source = "detTransaPaimtNum.instantAutorisationTransaction", target = "instantAutorisationTransaction")
    @Mapping(source = "detTransaPaimtNum.instantCreationTransaction", target = "instantCreationTransaction")
    @Mapping(source = "detTransaPaimtNum.instantModificationTransaction", target = "instantModificationTransaction")
    @Mapping(source = "detTransaPaimtNum.libelleSituationTransactionPaiementDigital", target = "libelleSituationTransactionPaiementDigital")
    @Mapping( target = "detTransaPaimtNum.montantTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.numeroAutorisationPaiementDigital", target = "numeroAutorisationPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.referenceTransactionPaiementDigital", target = "referenceTransactionPaiementDigital")
    DetailTransactionPaiementNumeriseResp toDetTransaPaimtNum(DetailTransactionPaiementNumeriseReq detTransaPaimtNum);

    @Mapping(source = "entetePaiementDigital.codeModePaiement", target = "codeModePaiement")
    @Mapping(source = "entetePaiementDigital.codeValeurECI", target = "codeValeurECI")
    @Mapping(source = "entetePaiementDigital.datePaiement", target = "datePaiement")
    @Mapping(source = "entetePaiementDigital.identifiantDemandePaiement", target = "identifiantDemandePaiement")
    @Mapping( source = "entetePaiementDigital.numeroTentativePaiementDigital", target = "numeroTentativePaiementDigital")
    EntetePaiementNumeriseResp toEntetePaimtNumerise(EntetePaiementNumeriseReq entetePaiementDigital);

    @Mapping(source = "adresseIp", target = "adresseIp")
    @Mapping(source = "deviceId", target = "deviceId")
    @Mapping(source = "ipCountry", target = "ipCountry")
    InformationsTechniquesResp toInformationsTechniques(InformationsTechniquesReq infoTech);

    MaintenanceOperationResp toMaintenanceOperation(MaintenanceOperationReq maintenanceOperation);


    Set<DonneeMetierResp> toDonneeMetierResp(Set<DonneeMetier> donneeMetier);

}
