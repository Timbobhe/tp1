package fr.ag2rlamondiale.paiementdigital.business.transaction.commons;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import org.springframework.stereotype.Service;


@Service
public interface IEtatPaiementFacade {

    Paiement create(CreerTransaPaimtDigiRootReq request);

    Paiement authorization(Paiement paiement);

    Paiement capture(ModifTransaRootReq request);

    Paiement error(Paiement paiement, String status, String message);
}
