package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetailActeurReq {

    @JsonProperty("idPersDansSilo")
    private IdPersDansSilo idPersDansSilo;

    @JsonProperty("InformationPP")
    private InformationPP informationPP;
}
