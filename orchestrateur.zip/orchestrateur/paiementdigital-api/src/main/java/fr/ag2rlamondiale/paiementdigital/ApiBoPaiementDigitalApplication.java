package fr.ag2rlamondiale.paiementdigital;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiBoPaiementDigitalApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiBoPaiementDigitalApplication.class);
    }

}
