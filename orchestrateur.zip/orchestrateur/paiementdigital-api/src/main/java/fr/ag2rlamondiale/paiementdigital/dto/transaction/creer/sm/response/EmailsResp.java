package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import lombok.Data;

import java.io.Serializable;

@Data
public class EmailsResp implements Serializable {

    private static final long serialVersionUID = -6463381385704600731L;

    private String libEmail;

}
