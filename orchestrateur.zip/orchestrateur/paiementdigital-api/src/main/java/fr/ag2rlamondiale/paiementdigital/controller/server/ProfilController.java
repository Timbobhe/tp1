package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.IProfilFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ProfilDto;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IProfilMapper;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@Validated
@RestController
@RequestMapping(value = "/api/profils", produces = MediaType.APPLICATION_JSON_VALUE)
public class ProfilController {

    @Autowired
    private IProfilFacade facade;

    @Autowired
    private IProfilMapper mapper;

    @GetMapping("/{id}")
    public ResponseEntity<ProfilDto> find(@PathVariable Long id) {
        Profil profil = facade.findById(id);
        ProfilDto response = mapper.toProfilDto(profil);
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<Set<ProfilDto>> findAll() {
        Set<ProfilDto> response = mapper.toDtoSet(facade.findAll());
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

}