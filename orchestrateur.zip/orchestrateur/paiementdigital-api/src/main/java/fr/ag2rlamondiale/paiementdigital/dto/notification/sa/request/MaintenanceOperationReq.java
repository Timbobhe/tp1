package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MaintenanceOperationReq {

    private String dateOperation;

    private String deviseOperation;

    private String idOperation;

    private String montantOperation;

    private String referenceOperation;

    private String typeDerniereOperation;

}
