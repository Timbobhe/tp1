package fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.JSON_PATTERN_DATE_FORMAT;
import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ExclusionBanqueDto implements Serializable {

    private static final long serialVersionUID = 7236599888094991289L;

    private String banque;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateEffet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateCreation;

    public ExclusionBanqueDto copy(ExclusionBanqueDto banqueDto) {
        return ExclusionBanqueDto
                .builder()
                .banque(banqueDto.getBanque())
                .dateEffet(banqueDto.getDateEffet())
                .dateCreation(banqueDto.getDateCreation())
                .build();
    }
}
