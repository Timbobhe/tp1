package fr.ag2rlamondiale.paiementdigital.controller.client;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierPaiementDigitalException;
import fr.ag2rlamondiale.paiementdigital.exception.RestTemplateException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;

@RestController
@Slf4j
public class ModifierPaiementDigitalController {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<ModifPaimtRootResp> modifierPaiementDigital(String uri, ModifPaimtRootReq request) {
        log.info("Appel à la PFS pour le SM CreerPaiementDigital");
        log.debug("ModifPaimtRootReq {}", request);
        log.debug("URI {}", uri);
        try {

            if (StringUtils.isEmpty(uri) || Objects.isNull(request))
                throw new ModifierPaiementDigitalException(INVALID_PARAMETER);

            HttpEntity<ModifPaimtRootReq> requestHttp = new HttpEntity<>(request, ControllerUtils.getHttpHeaders());
            return  modifierPaiement(uri, requestHttp);

        } catch (ModifierPaiementDigitalException e) {
            ResponseEntity<ModifPaimtRootResp> result = new ResponseEntity<>(e.getResponse(), e.getHttpStatus());
            log.error("Exception retournée par la PFS ou BO : {}", result);
            return result;
        }
    }

    private ResponseEntity<ModifPaimtRootResp> modifierPaiement(String uri, HttpEntity<ModifPaimtRootReq> requestHttp) {

        try {
            ResponseEntity<ModifPaimtRootResp> result = restTemplate.postForEntity(uri, requestHttp, ModifPaimtRootResp.class);
            log.debug("Réponse retournée par la PFS : {}", result);
            return result;
        } catch (RestTemplateException e) {
            ModifPaimtRootResp res = (ModifPaimtRootResp) JsonUtils.stringToObject(e.getMessage(), ModifPaimtRootResp.class);
            ModifierPaiementDigitalException exception = new ModifierPaiementDigitalException(e.getHttpStatus(), res);
            ResponseEntity<ModifPaimtRootResp> result = new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
            log.debug("Exception retournée par la PFS : {}", result);
            return result;
        }
    }
}
