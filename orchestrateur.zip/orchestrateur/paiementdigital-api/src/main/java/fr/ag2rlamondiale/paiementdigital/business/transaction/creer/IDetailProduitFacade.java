package fr.ag2rlamondiale.paiementdigital.business.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetPdtReq;
import org.springframework.stereotype.Service;

@Service
public interface IDetailProduitFacade {

    DetPdtReq detailProduit(CreerTransaPaimtDigiRootReq creerTransaction);
}
