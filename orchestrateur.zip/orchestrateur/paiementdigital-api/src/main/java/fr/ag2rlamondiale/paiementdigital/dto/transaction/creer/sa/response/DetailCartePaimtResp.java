package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailCartePaimtResp implements Serializable {

    private static final long serialVersionUID = 7517563636888549386L;

    private String identifiantChiffreMoyenPaiement;

    private String numeroCarte;

    private String anneeExpiration;

    private String moisExpiration;

    private String nomPayeur;

    private String banque;

    private String paysMethode;
}
