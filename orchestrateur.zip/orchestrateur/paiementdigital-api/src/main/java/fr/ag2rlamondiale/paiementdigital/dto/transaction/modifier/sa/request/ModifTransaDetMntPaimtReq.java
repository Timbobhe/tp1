package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request;

import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ModifTransaDetMntPaimtReq {

    private float montantTTC;

    private DeviseEnum codeDeviseVersement;

}
