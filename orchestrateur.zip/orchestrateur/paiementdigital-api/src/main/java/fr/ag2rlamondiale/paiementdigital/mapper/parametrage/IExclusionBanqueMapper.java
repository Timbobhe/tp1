package fr.ag2rlamondiale.paiementdigital.mapper.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import org.mapstruct.Mapper;

import java.util.Set;

@Mapper
public interface IExclusionBanqueMapper {

    ExclusionBanque toBanque(ExclusionBanqueDto banque);

    ExclusionBanqueDto toBanqueDto(ExclusionBanque banque);

    Set<ExclusionBanqueDto> toDtoSet(Set<ExclusionBanque> exclusionBanque);

}
