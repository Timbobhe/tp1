package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetEspCliReq;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaimtDigiResp implements Serializable {

    private static final long serialVersionUID = 1287293292694753433L;

    @JsonProperty("EntetePaimtNumerise")
    private EntetePaimtNumeriseResp entetePaimtNumerise;

    @JsonProperty("DetActr")
    private DetActrResp detActr;

    @JsonProperty("DetEspCli")
    private DetEspCliReq detEspCli;

    @JsonProperty("DetCartePaimt")
    private DetCartePaimtResp detCartePaimt;

    @JsonProperty("DetMntPaimt")
    private DetMntPaimtResp detMntPaimt;

    @JsonProperty("DetTransaPaimtNumerise")
    private DetTransaPaimtNumeriseResp detTransaPaimtNumerise;

    @JsonProperty("InfoTech")
    private InfoTechResp infoTech;

    @JsonProperty("Redirect")
    private RedirectResp redirect;

    private boolean indModeTest;

    private String idMarchand;

    @JsonProperty("msg")
    private String msg;

    @JsonProperty("stt")
    private String stt;

}
