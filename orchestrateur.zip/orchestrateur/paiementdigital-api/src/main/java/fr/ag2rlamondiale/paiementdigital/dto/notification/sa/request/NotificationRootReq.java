package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class NotificationRootReq {

    @JsonProperty("NotifierPaiementDigital")
    private NotificationReq notificationReq;
}
