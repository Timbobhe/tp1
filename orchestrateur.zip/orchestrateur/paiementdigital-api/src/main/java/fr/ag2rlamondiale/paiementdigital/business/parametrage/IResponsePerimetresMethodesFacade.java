package fr.ag2rlamondiale.paiementdigital.business.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public interface IResponsePerimetresMethodesFacade {

    Set<RecupParamPeriMethPaimtResp> getPerimetreMethodePaiementDtos(RecupParamRootReq pfsDto, Perimetre perimetre);

}
