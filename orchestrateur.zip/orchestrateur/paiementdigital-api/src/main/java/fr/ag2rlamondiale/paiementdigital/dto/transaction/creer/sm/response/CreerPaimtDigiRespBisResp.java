package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreerPaimtDigiRespBisResp implements Serializable {

    private static final long serialVersionUID = 2640068135716757338L;

    @JsonProperty("PaimtDigi")
    private PaimtDigiResp paimtDigi;
}
