package fr.ag2rlamondiale.paiementdigital.constantes;

public final class AdminConstantes {

    private AdminConstantes() {
    }

    public static final String HEALTH_CHECK_OK = "ORCHESTRATEUR OK!";
}
