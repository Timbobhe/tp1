package fr.ag2rlamondiale.paiementdigital.business.transaction.commons;

import org.springframework.stereotype.Service;

@Service
public interface IGestionTokenFacade {

    String getUriWithParams(String uri, String structureJuridique, String filiale);

}