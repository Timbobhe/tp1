package fr.ag2rlamondiale.paiementdigital.controller.admin;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import static fr.ag2rlamondiale.paiementdigital.constantes.AdminConstantes.HEALTH_CHECK_OK;

@ApiIgnore
@RestController
public class HealthCheckController {

    @GetMapping(value = "/healthcheck")
    public ResponseEntity<String> healthcheck() {
        return ResponseEntity.ok(HEALTH_CHECK_OK);
    }

}
