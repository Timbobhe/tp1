package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response;


import fr.ag2rlamondiale.paiementdigital.dto.BoResponse;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import lombok.*;

import java.util.Collections;
import java.util.Set;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecupParamRootResp extends BoResponse {

    private static final long serialVersionUID = -4525281346293934456L;

    private Integer code;

    private String message;

    private RecupParamProfResp parametresProfilsDto;

    private Set<ExclusionBanqueDto> exclusions;

    private Set<InclusionPaysDto> inclusions;

    public static RecupParamRootResp sendSuccess(RecupParamProfResp parametresProfilsDto,
                                                 Set<ExclusionBanqueDto> exclusions,
                                                 Set<InclusionPaysDto> inclusions) {
        return RecupParamRootResp
                .builder()
                .code(200)
                .message("OK")
                .parametresProfilsDto(parametresProfilsDto)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();
    }

    public static RecupParamRootResp sendFailure(Integer code, String message) {
        return RecupParamRootResp
                .builder()
                .code(code)
                .message(message)
                .parametresProfilsDto(null)
                .exclusions(Collections.emptySet())
                .inclusions(Collections.emptySet())
                .build();
    }
}
