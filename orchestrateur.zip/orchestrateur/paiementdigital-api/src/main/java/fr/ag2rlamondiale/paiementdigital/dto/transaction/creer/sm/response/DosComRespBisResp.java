package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class DosComRespBisResp implements Serializable {

    private static final long serialVersionUID = 1443980853743621845L;

    @JsonProperty("DetCnlCom")
    protected DetCnlComResp detCnlCom;
}
