package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InfoPMReq {

    private String codeFiliale;

    private String libFiliale;

}
