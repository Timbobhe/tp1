package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailProduitFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.DetailPerimetreMetierReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetPdtReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.InfoCtrReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class DetailProduitFacadeImpl implements IDetailProduitFacade {

    @Override
    public DetPdtReq detailProduit(CreerTransaPaimtDigiRootReq request) {
        log.debug("Création de la partie DetailProduit pour le SM creerpaiementDigital");
        log.debug("CreerTransaPaimtDigiRootReq {}", request);

        DetailPerimetreMetierReq detailsPerMetier = request.getDetailPerimetreMetier();

        //RDG07
        if (detailsPerMetier == null || !PfsParametersConstantes.CODES_APPLI_RETRAITE_SUP.contains(detailsPerMetier.getCodeApplication()))
            return new DetPdtReq(null);

        DetPdtReq result = new DetPdtReq(InfoCtrReq.builder()
                .idSilo(request.getCustomData(2).getCdata())
                .codeAppli(PfsParametersConstantes.CODE_APPLI_PTV)
                .build());

        log.debug("DetPdtReq {}", result);
        return result;
    }
}
