package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModifPaimtDetTransaPaimtNumReq {

    private String refTransaPaimtDigi;

    private String typeOpeTransaPaimtDigi;

}
