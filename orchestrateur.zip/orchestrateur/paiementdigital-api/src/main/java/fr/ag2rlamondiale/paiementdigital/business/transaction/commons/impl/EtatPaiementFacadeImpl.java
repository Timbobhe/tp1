package fr.ag2rlamondiale.paiementdigital.business.transaction.commons.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerTransaToPaimtMapper;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashSet;
import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;

@Service
@Slf4j
public class EtatPaiementFacadeImpl implements IEtatPaiementFacade {

    @Autowired
    private IPaiementFacade facade;

    @Autowired
    private ICreerTransaToPaimtMapper mapper;

    @Override
    public Paiement create(CreerTransaPaimtDigiRootReq request) {
        log.info("Changement du statut du paiement en CREATE");
        log.debug("Demande de création d'une transaction, request reçue {}", request);
        if (Objects.isNull(request))
            throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);
        if (Objects.isNull(request.getDonneesMetiers()))
            request.setDonneesMetiers(new HashSet<>());
        Paiement paiement = mapper.toPaiement(request);

        Date date = new Date();
        paiement.setOrderId(UUIDUtils.randomUuidToOrderId());
        paiement.setEtatCourant(EtatEnum.CREATE);
        paiement.setDateCreation(date);
        paiement.setDateModification(date);
        paiement.getHistoriques().add(Historique.builder()
                .id(new HistoriquePK(date, paiement.getId()))
                .paiement(paiement)
                .etat(EtatEnum.CREATE)
                .status(null)
                .message(null)
                .montant(paiement.getMontant())
                .build());

        if (!Objects.isNull(paiement.getDonneeMetiers()))
            paiement.getDonneeMetiers().stream().forEach(d -> d.setPaiement(paiement));

        paiement.getCustomDatas().stream().forEach(c -> c.setPaiement(paiement));

        try {
            Paiement update = facade.save(paiement);
            log.debug("Paiement créée : {}", update);
            return update;
        } catch (PaiementException e) {
            throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @Override
    public Paiement authorization(Paiement paiement) {
        log.info("Changement du statut du paiement en AUTHORZATION");
        log.debug("Demande d'autorisation d'une transaction, paiement {}", paiement);
        if (Objects.isNull(paiement))
            throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        Date date = new Date();
        Paiement paiementRequest = paiement.copy(paiement);
        paiementRequest.setEtatCourant(EtatEnum.AUTHORIZATION);
        paiementRequest.setDateModification(date);
        paiementRequest.getHistoriques()
                .add(Historique.builder()
                        .id(new HistoriquePK(date, paiement.getId()))
                        .paiement(paiement)
                        .etat(EtatEnum.AUTHORIZATION)
                        .montant(paiementRequest.getMontant())
                        .status(null)
                        .message(null)
                        .build());
        try {
            Paiement update = facade.update(paiementRequest);
            log.debug("Paiement en cours d'autorisation : {}", update);
            return update;
        } catch (PaiementException e) {
            throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @Override
    public Paiement capture(ModifTransaRootReq request) {
        log.info("Changement du statut du paiement en CAPTURE");
        log.debug("Demande de CAPTURE, request reçue {}", request);
        if (Objects.isNull(request))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        Paiement paiement;

        try {
            String idTransaction = request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().getIdTransaction();

            if (idTransaction != null) {
                paiement = facade.find(idTransaction);
            } else {
                paiement = facade.findByOrderId(request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().getOrderId());
            }

            log.info("Paiement à mettre à jour lié à l'order {} et transaction {} trouvé : Paiement(id = {}, orderId = {}, idTransaction = {}, metier = {}, " +
                    "codeApplication = {}, evenementMetier = {}, etatCourant = {}) ", request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().getOrderId(), idTransaction,
                    paiement.getId(), paiement.getOrderId(), paiement.getIdTransaction(), paiement.getMetier(), paiement.getCodeApplication(),
                    paiement.getEvenementMetier(), paiement.getEtatCourant());

            float montant = request.getModificationTransactionPaiement().getDetailMontantPaiement().getMontantTTC();

            EtatEnum etat = EtatEnum.CAPTURE;

            Date date = new Date();

            Historique historique = Historique.builder()
                    .id(new HistoriquePK(date, paiement.getId()))
                    .paiement(paiement)
                    .montant(montant)
                    .etat(etat)
                    .status(null)
                    .message(null)
                    .build();

            paiement.setMontant(montant);
            paiement.setEtatCourant(etat);
            paiement.setDateModification(date);
            paiement.getHistoriques().add(historique);

            Paiement update = facade.update(paiement);
            log.info("Paiement capturé");
            log.debug("Paiement capturé : {}", update);
            return update;

        } catch (PaiementException e) {
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    @Override
    public Paiement error(Paiement paiement, String status, String message) {
        log.info("Changement du statut du paiement en ERROR");
        log.debug("Demande de changement d'état du paiement en ERROR : {}", paiement);
        log.debug("Statut et message de l'erreur : {} {}", status, message);
        if (Objects.isNull(paiement))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        Paiement paiementUpdated = paiement.copy(paiement);

        float montant = paiementUpdated.getMontant();

        EtatEnum etat = EtatEnum.ERROR;

        Date date = new Date();

        Historique historique = Historique.builder()
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .montant(montant)
                .etat(etat)
                .status(status)
                .message(message)
                .build();

        paiementUpdated.setMontant(montant);
        paiementUpdated.setEtatCourant(etat);
        paiementUpdated.setDateModification(date);
        paiementUpdated.getHistoriques().add(historique);

        try {
            Paiement update = facade.update(paiementUpdated);
            log.debug("Paiement en erreur mis à jour : {}", update);
            return update;
        } catch (PaiementException e) {
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

}
