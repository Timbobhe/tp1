package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ModifPaimtResp implements Serializable {

    private static final long serialVersionUID = -5546056968528953309L;

    @JsonProperty("Header")
    private ModifPaimtHeaderResp header;

    @JsonProperty("Body")
    private ModifPaimtBodyResp body;
}
