package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetMntPaimtResp implements Serializable {

    private static final long serialVersionUID = 9019356825971072314L;

    private float mntTTC;

    private float mntFraisLivr;

    private float mntTaxes;

    private float tauxTaxes;

    private DeviseEnum codeDevVersm;

}
