package fr.ag2rlamondiale.paiementdigital.dto.type;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CiviliteEnum {
    M("M"),
    MME("Mme"),
    MLLE("Mlle"),
    DR("Dr.");

    private String code;
}
