package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response;

import lombok.*;

import java.io.Serializable;
import java.util.Set;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class RecupParamPeriMethPaimtResp implements Serializable {

    private static final long serialVersionUID = 2344506072262305710L;

    private String methodeDePaiement;

    private float minMontantDispoClient;

    private String frequenceMinMontantDispoClient;

    private int minNombrePaiementDisponible;

    private String frequenceNombrePaiementDisponible;

    private Set<RecupParamPlfdFreqResp> plafondsParFrequences;

}
