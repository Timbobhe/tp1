package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreerTransacPaimtDigiResponse implements Serializable {

    private static final long serialVersionUID = -6277969537274331052L;

    @JsonProperty("EtatTransactionPaiementDigital")
    private EtatTransaPaimtDigiResp etatTransactionPaiementDigital;

    @JsonProperty("EnteteTransactionPaiementDigital")
    private EnteteTransaPaimtDigiResp enteteTransactionPaiementDigital;

    @JsonProperty("DetailTransactionPaiementDigital")
    private DetailTransaPaimtDigiResp detailTransactionPaiementDigital;

    @JsonProperty("DetailActeurs")
    private DetailActeursResp detailsActeurs;

    @JsonProperty("DetailCartePaiement")
    private DetailCartePaimtResp detailCartePaiement;

    @JsonProperty("DetailMontantPaiement")
    private DetailMontantPaimtResp detailMontantPaiement;

    @JsonProperty("DetailPerimetreMetier")
    private DetailPerimetreMetierResp detailPerimetreMetier;

    @JsonProperty("DonneesMetier")
    @Builder.Default
    private Set<DonneeMetierResp> donneesMetiers = new HashSet<>();

    @JsonProperty("CustomData")
    @Builder.Default
    private Set<CustomDataResp> customDatas = new HashSet<>();

    @JsonProperty("InformationsTechniques")
    private InformationsTechniquesResp informationsTechniques;

    @JsonProperty("Redirection")
    private RedirectionResp redirection;

    private boolean indicateurModeTest;

    private String identifiantMarchand;

    private String stt;

    private String msg;
}
