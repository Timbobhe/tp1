package fr.ag2rlamondiale.paiementdigital.constantes;

public final class PfsParametersConstantes {

    private PfsParametersConstantes() {
    }

    public static final String APPLICATION = "Application";

    public static final String TOKEN = "Token";

    public static final String USER = "Utilisateur";

    public static final String CODES_APPLI_RETRAITE_SUP = "A1573|A1324|A1335|A0653";

    public static final String CODE_APPLI_ESPACE_CLIENT_HABILITATIONS = "A1531";

    public static final String CODE_APPLI_PTV = "A0252";

    public static final String CODE_APPLI_PFS = "A0487";

    public static final String CODE_APPLI_BO_PMT_DIGI = "A1532";
}
