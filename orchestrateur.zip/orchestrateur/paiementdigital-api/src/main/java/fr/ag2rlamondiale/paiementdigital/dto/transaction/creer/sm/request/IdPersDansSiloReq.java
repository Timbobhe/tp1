package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IdPersDansSiloReq implements Serializable {

    private static final long serialVersionUID = -579229667201360754L;

    private String idPers;

    private String codeAppli;

}
