package fr.ag2rlamondiale.paiementdigital.exception;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.Arrays;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ModifierPaiementDigitalException extends RuntimeException {

    private static final long serialVersionUID = 2583595726161572366L;

    public static final String INVALID_PARAMETER = "Le paramètre ne peut être null!";

    private HttpStatus httpStatus;

    private ModifPaimtRootResp response;

    public ModifierPaiementDigitalException(String message) {
        super(message);
        httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        response = buildResponseTechError(httpStatus.name(), message);
        log.error("Exception : {}", response);
    }

    private ModifPaimtRootResp buildResponseTechError(String errorCode, String errorMessage) {
        ModifPaimtDigiResp modifierPaimtDigiResp = new ModifPaimtDigiResp(null);
        ModifPaimtBodyResp bodyResp = new ModifPaimtBodyResp(modifierPaimtDigiResp);
        ModifPaimtErrorResp errorResp = new ModifPaimtErrorResp(errorCode, errorMessage);
        ModifPaimtHeaderResp headerResp = new ModifPaimtHeaderResp(null, Arrays.asList(errorResp));
        ModifPaimtResp resp = new ModifPaimtResp(headerResp, bodyResp);

        return new ModifPaimtRootResp(resp);
    }
}
