package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response;

import lombok.*;

import java.io.Serializable;
import java.util.Set;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class RecupParamProfResp implements Serializable {

    private static final long serialVersionUID = 430408311590531525L;

    private Float maxDesMontantsDispo;

    private String methodeMaxDesMontantsDispo;

    private Integer maxDesNombresDePaiementDispo;

    private String methodeMaxDesNombresDePaiementDispo;

    private Set<RecupParamPeriMethPaimtResp> perimetreMethodePaiement;

}
