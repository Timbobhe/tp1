package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IEtatTransPaimtDigiFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.EmailsResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.PaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerTransaRespMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.ANN;
import static fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum.*;
import static fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException.ERROR_STATE;
import static fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException.INVALID_PARAMETER;

@Service
@Slf4j
public class CreerTransaRespBuilderFacadeImpl implements ICreerTransaRespBuilderFacade {

    @Autowired
    private ICreerTransaRespMapper mapperResp;

    @Autowired
    private IInterpreteurPfsResponseFacade<CreerPaimtDigiRootResp, Paiement> interpreteur;

    @Autowired
    private IEtatTransPaimtDigiFacade etatTransPaimtDigiFacade;

    @Override
    public CreerTransaPaimtDigiRootResp build(Paiement paiement, ResponseEntity<CreerPaimtDigiRootResp> response) {
        log.info("Création de la réponse du SA de la création de la transaction");
        log.debug("ResponseEntity<CreerPaimtDigiRootResp> {}", response);
        log.debug("Paiement {}", paiement);

        if (Objects.isNull(response) || Objects.isNull(paiement))
            throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        Paiement paiementUpdated = interpreteur.interpreteur(response, paiement);
        log.info("Interprétation de la reponse PFS CréerPaiementDigital");

        if (ERROR.equals(paiementUpdated.getEtatCourant())) {
            CreerTransaPaimtDigiRootResp result = CreerTransaPaimtDigiRootResp.builder()
                    .etatCourant(ERROR)
                    .messageErreur(null)
                    .codeErreur(null)
                    .creationTransactionPaiementDigital(null)
                    .build();

            Optional<Historique> historiqueError = paiementUpdated.getHistoriques().stream().filter(historique -> ERROR.equals(historique.getEtat())).findFirst();
            if (historiqueError.isPresent()) {
                result.setCodeErreur(historiqueError.get().getStatus());
                result.setMessageErreur(historiqueError.get().getMessage());
            }

            log.error("L'état de la réponse du SM est ERROR {}", result);
            return result;

        } else if (AUTHORIZED.equals(paiementUpdated.getEtatCourant()) || FORWARDING.equals(paiementUpdated.getEtatCourant()) || FAIL.equals(paiementUpdated.getEtatCourant())) {
            log.info("L'état de la réponse du SM est {}", paiementUpdated.getEtatCourant());

            CreerPaimtDigiRootResp creerPaiementResponseBody = response.getBody();

            PaimtDigiResp paimtDigiResponse = creerPaiementResponseBody.getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi().getPaimtDigi();

            EmailsResp emails = paimtDigiResponse.getDetActr().getInfoPP().getSignq().getDosCom().getDosCom().getDetCnlCom().getEmails();

            EnteteTransaPaimtDigiResp enteteTransactionPaiementDigital = mapperResp.toEnteteTransactionPaiementDigital(paiementUpdated, paimtDigiResponse.getEntetePaimtNumerise());

            EtatTransaPaimtDigiResp etatTransactionPaiementDigital = etatTransPaimtDigiFacade.toEtatTransactionPaiementDigital(paiementUpdated, paimtDigiResponse.getDetTransaPaimtNumerise());

            DetailTransaPaimtDigiResp detailTransactionPaiementDigital = mapperResp.toDetailTransactionPaiementDigital(paiementUpdated, paimtDigiResponse.getDetTransaPaimtNumerise());

            DetailActeursResp detailActeurs = mapperResp.toDetailActeurs(paiementUpdated, emails);

            DetailCartePaimtResp detailCartePaiement = mapperResp.toDetailCartePaiement(paiementUpdated, paimtDigiResponse.getDetCartePaimt());

            DetailMontantPaimtResp detailMontantPaiement = mapperResp.toDetailMontantPaiement(paiementUpdated, paimtDigiResponse.getDetMntPaimt());

            DetailPerimetreMetierResp detailPerimetreMetier = mapperResp.toDetailPerimetreMetier(paiementUpdated);

            InformationsTechniquesResp informationsTechniques = mapperResp.toInformationsTechniques(paimtDigiResponse.getInfoTech());

            RedirectionResp redirection = new RedirectionResp(paimtDigiResponse.getRedirect() != null ? paimtDigiResponse.getRedirect().getForwardUrl() : null);

            Set<DonneeMetierResp> donneesMetiers = mapperResp.toDonneeMetierResp(paiementUpdated.getDonneeMetiers());

            Set<CustomDataResp> customDatas = mapperResp.toCustomDataResp(paiementUpdated.getCustomDatas());

            CreerTransacPaimtDigiResponse creerTransacPaimtDigiResponse = CreerTransacPaimtDigiResponse.builder()
                    .enteteTransactionPaiementDigital(enteteTransactionPaiementDigital)
                    .etatTransactionPaiementDigital(etatTransactionPaiementDigital)
                    .detailTransactionPaiementDigital(detailTransactionPaiementDigital)
                    .detailsActeurs(detailActeurs)
                    .detailCartePaiement(detailCartePaiement)
                    .detailMontantPaiement(detailMontantPaiement)
                    .detailPerimetreMetier(detailPerimetreMetier)
                    .donneesMetiers(donneesMetiers)
                    .customDatas(customDatas)
                    .informationsTechniques(informationsTechniques)
                    .redirection(redirection)
                    .stt(paimtDigiResponse.getStt())
                    .msg(paimtDigiResponse.getMsg())
                    .indicateurModeTest(paimtDigiResponse.isIndModeTest())
                    .identifiantMarchand(paimtDigiResponse.getIdMarchand())
                    .build();

            CreerTransaPaimtDigiRootResp result = CreerTransaPaimtDigiRootResp.builder()
                    .etatCourant(null)
                    .codeErreur(null)
                    .messageErreur(null)
                    .creationTransactionPaiementDigital(creerTransacPaimtDigiResponse)
                    .build();


            log.info("Renvoie de la réponse");
            log.debug("CreerTransaPaimtDigiRootResp {}", result);

            //TODO Il faut le supprimer le bouchon après les tests sur recette et renvoyer result
            return checkPaiement(result);

            //return result;
        }

        throw new CreerTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, ERROR_STATE);
    }
    private CreerTransaPaimtDigiRootResp checkPaiement(CreerTransaPaimtDigiRootResp result) {

        switch ((int) result.getCreationTransactionPaiementDigital().getDetailMontantPaiement().getMntTTC()){
            case 301 :
                return updateResult(result,"4010307","Unauthorized IP address country");
            case 302 :
                return updateResult(result,"4000006","Acquirer Unavailable");
            case 303 :
                return updateResult(result,"4000001","Declined");
            case 304 :
                return updateResult(result,"4000002","Declined");
            case 305 :
                return updateResult(result,"4010101","Refusal (No Explicit Reason)");
            case 306 :
                return updateResult(result,"4010302","Retain Card");
            case 307 :
                return updateResult(result,"4000003","Insufficient Funds");
            case 308 :
                return updateResult(result,"4010103","Insufficient Funds");
            case 309 :
                return updateResult(result,"4010305","Card Limit Exceeded");
            case 310 :
                return updateResult(result,"4010304","Restricted Card");
            case 311 :
                return updateResult(result,"4010306","Card Blacklisted");
            case 312 :
                return updateResult(result,"4010303","Lost or Stolen Card");
            case 313 :
                return updateResult(result,"4010204","Card Expired");

            default:
                return result;
        }

    }

    private CreerTransaPaimtDigiRootResp updateResult(CreerTransaPaimtDigiRootResp result, String status, String message) {

        result.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().setStatus(status);
        result.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().setMessage(message);
        result.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().setCodeSitTransPaiemtDigi(ANN);
        result.getCreationTransactionPaiementDigital().getEtatTransactionPaiementDigital().setEtatCourant(REFUSED);
        result.getCreationTransactionPaiementDigital().setMsg("REFUSED");
        result.getCreationTransactionPaiementDigital().setStt("113");

        return  result;
    }


}
