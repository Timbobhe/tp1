package fr.ag2rlamondiale.paiementdigital.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class PfsPropertyConfig {

    @Value("${pfs.ws.creerPaimtDigi.url}")
    private String createPaiementUrl;

    @Value("${pfs.ws.modifierPaimtDigi.url}")
    private String modifierPaiementUrl;

    @Value("${pfs.ws.application}")
    private String codeApplication;

    @Value("${pfs.ws.user}")
    private String user;

    @Value("${pfs.ws.token.ari}")
    private String tokenARI;

    @Value("${pfs.ws.token.lmo}")
    private String tokenLMO;

    @Value("${pfs.ws.token.lm}")
    private String tokenLM;

}
