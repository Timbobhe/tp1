package fr.ag2rlamondiale.paiementdigital.business.parametrage;


import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface IResponseCalculFacade {

    float maxDesMontantsDispo(Set<RecupParamPeriMethPaimtResp> methodes);

    String methodeMaxDesMontantsDispo(Set<RecupParamPeriMethPaimtResp> methodes, float maxDesMontantsDispo);

    int maxDesNombresDePaiementDispo(Set<RecupParamPeriMethPaimtResp> methodes);

    String methodeMaxDesNombresDePaiementDispo(Set<RecupParamPeriMethPaimtResp> methodes, int maxDesNombresDePaiementDispo);

    float minMontantDispoClient(Set<RecupParamPlfdFreqResp> plafonds);

    String frequenceMinMontantDispoClient(Set<RecupParamPlfdFreqResp> plafonds);

    int minNombrePaiementDisponible(Set<RecupParamPlfdFreqResp> plafonds);

    String frequenceNombrePaiementDisponible(Set<RecupParamPlfdFreqResp> plafonds);

    float montantMaxDispoClient(float montant, List<Float> montantsCaptured);

    int nombreMaxDispoClient(int nombre, List<Float> montantsCaptured);
}
