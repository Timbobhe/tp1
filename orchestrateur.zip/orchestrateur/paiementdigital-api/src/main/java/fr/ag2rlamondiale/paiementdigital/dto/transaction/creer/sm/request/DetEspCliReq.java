package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class DetEspCliReq implements Serializable {

    private static final long serialVersionUID = 7357537128100263537L;

    private String idExtranet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateCreatEspCli;

    private int dureeCreat;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateModifEspCli;

    private int dureeModif;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateModifMDPEspCli;

    private int dureeModifMDP;

    private int nbeEssaiAjoutCarte24H;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateEnrCartePaimt;

    private int dureeEnrCartePaimt;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date datePremUtilAdrLivr;

    private int dureePremUtilAdrLivr;

    private int nbeCmdAnnee;

    private int nbeCmd6M;

    private int nbeCmd24H;

    private boolean indActivSuspt;

    private boolean indNomsIdentiques;

}
