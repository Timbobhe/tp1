package fr.ag2rlamondiale.paiementdigital.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RestTemplateException extends RuntimeException {

    private static final long serialVersionUID = -2865732503615919768L;

    private HttpStatus httpStatus;

    public RestTemplateException(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
    }
}
