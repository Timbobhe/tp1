/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.JSON_PATTERN_DATE_FORMAT;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PerimetreDto {

    private Long id;

    private Long idParent;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private TypePerimetreEnum typePerimetre;

    private String valeurPerimetre;

    private boolean tiersPayeur;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateEffet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateFinEffet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateCreation;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateModification;

    private PerimetreInfosDto perimetreInfos;

    private Set<PerimetrePlafondDto> perimetrePlafonds;

}
