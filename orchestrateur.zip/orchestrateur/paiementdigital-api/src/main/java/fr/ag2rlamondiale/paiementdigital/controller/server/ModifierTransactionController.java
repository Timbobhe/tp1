package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.controller.client.ModifierPaiementDigitalController;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDigiBisResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.Instant;
import java.util.Objects;

@Validated
@RestController
@RequestMapping(value = "/api/transaction", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class ModifierTransactionController {

    @Autowired
    private IEtatPaiementFacade facade;

    @Autowired
    private IModifPaimtDigiReqBuilderFacade builder;

    @Autowired
    private PfsPropertyConfig config;

    @Autowired
    private IGestionTokenFacade gestionTokenFacade;

    @Autowired
    private ModifierPaiementDigitalController controller;

    @Autowired
    private IModifTransaRespBuilderFacade modifTransaFacade;

    @PutMapping("/update")
    public ResponseEntity<ModifTransaRootResp> update(@Valid @RequestBody ModifTransaRootReq request) {
        long startTime = Instant.now().toEpochMilli();
        log.info("Demande de mise à jour d'une transaction");
        log.debug("ModifTransaRootReq {}", request);

        Paiement paiement = null;
        try {

            paiement = facade.capture(request);

            if (request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().getIdTransaction() == null) {
                request.getModificationTransactionPaiement().getDetailTransactionPaiementNumerise().setIdTransaction(paiement.getIdTransaction());
            }

            String uri = gestionTokenFacade.getUriWithParams(config.getModifierPaiementUrl(), paiement.getStructureJuridique(),paiement.getFiliale());

            ModifPaimtRootReq modifPaimtRootReq = builder.build(request);

            ResponseEntity<ModifPaimtRootResp> responseEntity = controller.modifierPaiementDigital(uri, modifPaimtRootReq);

            logSmResponse(responseEntity);

            ResponseEntity<ModifTransaRootResp> result = new ResponseEntity<>(modifTransaFacade.build(responseEntity, paiement), ControllerUtils.getHttpHeaders(), responseEntity.getStatusCode());

            log.info("Renvoie de la réponse");
            log.debug("ResponseEntity<ModifTransaRootResp> {}", result);
            return result;

        } catch (ModifierTransactionException e) {
            if (!Objects.isNull(paiement)) {
                Paiement paiementUpdated = facade.error(paiement, e.getHttpStatus().name(), e.getMessage());
                log.error("Mise à jour du paiement en erreur : {}", paiementUpdated);
            }

            ResponseEntity<ModifTransaRootResp> result = new ResponseEntity<>(e.getResponse(), e.getHttpStatus());
            log.error("Réponse pour la mise à jour: {}", result);
            return result;
        } finally {
            long endTime = Instant.now().toEpochMilli();
            long timeElapsed = endTime - startTime;
            log.info("Temps d'execution pour la modification de la transaction : {} ms", timeElapsed);
        }
    }

    private void logSmResponse(ResponseEntity<ModifPaimtRootResp> responseEntity) {
        if(responseEntity != null && responseEntity.getBody().getResponse().getBody() != null && responseEntity.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc() != null){
            ModifPaimtDigiBisResp paiementDigiResponse = responseEntity.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc().getPaimtDigi();
            log.info("Réponse retournée par la PFS : code du retour API = {}, idMarchand = {}," +
                            " refTransPaimtDigi = {}, msg = {}, stt = {}",
                    responseEntity.getStatusCodeValue(), paiementDigiResponse.getIdMarchand(),
                    paiementDigiResponse.getDetTransaPaimtNumerise().getRefTransaPaimtDigi(), paiementDigiResponse.getMsg(), paiementDigiResponse.getStt());
        }
    }
}
