package fr.ag2rlamondiale.paiementdigital.business.parametrage;


import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.springframework.stereotype.Service;

@Service
public interface IResponseRecupParamLABFacade {

    RecupParamRootResp recupererParametragesLab(RecupParamRootReq pfsDto);

}
