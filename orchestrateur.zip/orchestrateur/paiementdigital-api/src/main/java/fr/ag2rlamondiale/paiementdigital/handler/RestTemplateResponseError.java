package fr.ag2rlamondiale.paiementdigital.handler;


import fr.ag2rlamondiale.paiementdigital.exception.RestTemplateException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

@Component
@Slf4j
public class RestTemplateResponseError implements ResponseErrorHandler {

    private String bodyObjectAsString;

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {

        if (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
                || response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR) {

            bodyObjectAsString = new BufferedReader(new InputStreamReader(response.getBody()))
                    .lines()
                    .collect(Collectors.joining("\n"));
            log.error("Anomalie survenue lors de l'appel à la PFS : {}", bodyObjectAsString);
            return true;
        }

        return false;
    }

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {

        if (response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR
                || response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR) {

            throw new RestTemplateException(bodyObjectAsString, response.getStatusCode());

        }
    }
}
