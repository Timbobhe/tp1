package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifPaimtHeaderResp implements Serializable {

    private static final long serialVersionUID = 4562513116174801337L;

    @JsonProperty("FuncError")
    private List<ModifPaimtErrorResp> funcError;

    @JsonProperty("TechError")
    private List<ModifPaimtErrorResp> techError;

}
