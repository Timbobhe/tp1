package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RedirectReq {

    @JsonProperty("accept_url")
    private String acceptUrl;

    @JsonProperty("decline_url")
    private String declineUrl;

    @JsonProperty("cancel_url")
    private String cancelUrl;

    @JsonProperty("notify_url")
    private String notifyUrl;

}
