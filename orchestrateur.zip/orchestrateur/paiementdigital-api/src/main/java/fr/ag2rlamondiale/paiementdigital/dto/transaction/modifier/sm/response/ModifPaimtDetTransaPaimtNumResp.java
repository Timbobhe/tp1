package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModifPaimtDetTransaPaimtNumResp implements Serializable {

    private static final long serialVersionUID = -7970723496845470879L;

    private String refTransaPaimtDigi;

    private String typeOpeTransaPaimtDigi;

    private String numAutionTransaPaimtDigi;

    private Date instantCreatTransa;

    private Date instantMajTransa;

    private Date instantAutionTransa;

    private float mntAutionPaimtDigi;

    private float mntTrsfPaimtDigi;

    private float mntRembsmPaimtDigi;

    private float mntCreditPaimtDigi;
}
