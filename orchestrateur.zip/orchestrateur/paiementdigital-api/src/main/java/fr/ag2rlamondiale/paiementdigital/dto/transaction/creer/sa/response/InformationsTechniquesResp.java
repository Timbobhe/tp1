package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InformationsTechniquesResp implements Serializable {

    private static final long serialVersionUID = -3319126365701204196L;

    @JsonProperty("adresseIP")
    private String adresseIP;

    @JsonProperty("ip_country")
    private String ipCountry;

    private String deviceId;
}
