package fr.ag2rlamondiale.paiementdigital.business.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface IResponsePlafonfsFrequencesFacade {

    Set<RecupParamPlfdFreqResp> getPlafondsParFrequencesDtos(RecupParamRootReq pfsDto, List<Plafond> plafonds, PaiementDto paiement);

}
