package fr.ag2rlamondiale.paiementdigital.exception;

import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtHeaderResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

import java.util.Objects;
import java.util.Optional;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class ModifierTransactionException extends RuntimeException {

    private static final long serialVersionUID = 4451599205449099503L;

    public static final String INVALID_PARAMETER = "Le paramètre ne peut être null!";

    public static final String INCORRECT_PATTERN_PFS_ERROR = "Le message d'erreur dans la reponse PFS ne respecte pas le format attendu.";

    public static final String VALEUR_STT_EXCEPTION = "Cette valeur STT est non prévue.";

    private HttpStatus httpStatus;

    private ModifTransaRootResp response;

    public ModifierTransactionException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
        response = ModifTransaRootResp
                .builder()
                .etatCourant(EtatEnum.ERROR.name())
                .codeErreur(String.valueOf(httpStatus.value()))
                .messageErreur(message)
                .modifTransaResp(null)
                .build();
        log.error("Exception : {}", response);
    }

    public ModifierTransactionException(ResponseEntity<ModifPaimtRootResp> modifPaimtRootResp) {
        httpStatus = modifPaimtRootResp.getStatusCode();
        String code = httpStatus.name();
        String message = HttpStatus.INTERNAL_SERVER_ERROR.name();

        ModifPaimtHeaderResp header = modifPaimtRootResp.getBody().getResponse().getHeader();
        if (!Objects.isNull(header)) {
            Optional<ModifPaimtErrorResp> error = error(header);

            if (error.isPresent()) {
                code = error.get().getErrorCode();
                message = error.get().getErrorMessage();
            }
        }

        response = ModifTransaRootResp
                .builder()
                .etatCourant(EtatEnum.ERROR.name())
                .codeErreur(code)
                .messageErreur(message)
                .modifTransaResp(null)
                .build();

        log.error("Exception : {}", response);
    }

    private Optional<ModifPaimtErrorResp> error(ModifPaimtHeaderResp header) {
        return CollectionUtils.isEmpty(header.getFuncError())
                ? header.getTechError().stream().findFirst()
                : header.getFuncError().stream().findFirst();
    }
}
