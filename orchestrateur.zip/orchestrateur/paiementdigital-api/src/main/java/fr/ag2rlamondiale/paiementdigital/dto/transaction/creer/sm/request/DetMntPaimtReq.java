package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetMntPaimtReq {

    private float mntTTC;

    private float mntFraisLivr;

    private float mntTaxes;

    private float tauxTaxes;

    private DeviseEnum codeDevVersm;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date datePrevueVersm;

}
