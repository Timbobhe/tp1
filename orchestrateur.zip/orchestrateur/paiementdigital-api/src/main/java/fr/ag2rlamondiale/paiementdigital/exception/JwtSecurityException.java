package fr.ag2rlamondiale.paiementdigital.exception;

public class JwtSecurityException extends RuntimeException {

    public JwtSecurityException(String message) {
        super(message);
    }
}
