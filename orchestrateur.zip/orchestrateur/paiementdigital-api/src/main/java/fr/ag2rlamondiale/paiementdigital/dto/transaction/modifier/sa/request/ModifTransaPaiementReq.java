package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Builder
public class ModifTransaPaiementReq {

    @NotNull
    @JsonProperty("DetailTransactionPaiementNumerise")
    private ModifTransaDetTransaPaimtNumReq detailTransactionPaiementNumerise;

    @JsonProperty("DetailMontantPaiement")
    private ModifTransaDetMntPaimtReq detailMontantPaiement;

    @JsonProperty("InformationsTechniques")
    private ModifTransaInfosTechReq informationsTechniques;
}
