package fr.ag2rlamondiale.paiementdigital.business.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public interface IParametrageFacade {

    Perimetre perimetre(RecupParamRootReq pfsDto);

    Set<InclusionPaysDto> inclusions(RecupParamRootReq pfsDto);

    Set<ExclusionBanqueDto> exclusions(RecupParamRootReq pfsDto);

}
