package fr.ag2rlamondiale.paiementdigital.mapper.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ProfilDto;
import org.mapstruct.Mapper;

import java.util.Set;

@Mapper
public interface IProfilMapper {

    Profil toProfil(ProfilDto profil);

    ProfilDto toProfilDto(Profil profil);

    Set<ProfilDto> toDtoSet(Set<Profil> profils);

}
