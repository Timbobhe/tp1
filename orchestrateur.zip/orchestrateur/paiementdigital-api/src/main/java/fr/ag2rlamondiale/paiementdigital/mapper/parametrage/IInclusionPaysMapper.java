/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.mapper.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import org.mapstruct.Mapper;

import java.util.Set;

@Mapper
public interface IInclusionPaysMapper {

    InclusionPays toPays(InclusionPaysDto pays);

    InclusionPaysDto toPaysDto(InclusionPays pays);

    Set<InclusionPaysDto> toDtoSet(Set<InclusionPays> inclusionPays);

}
