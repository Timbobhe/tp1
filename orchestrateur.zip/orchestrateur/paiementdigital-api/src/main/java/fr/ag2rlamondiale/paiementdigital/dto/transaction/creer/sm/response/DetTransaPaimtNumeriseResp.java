package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DetTransaPaimtNumeriseResp implements Serializable {

    private static final long serialVersionUID = -2416957060345295775L;

    private String refTransPaimtDigi;

    private String numAutionTransaPaimtNumerise;

    private Date instantAutionTransa;

    private Date instantCreatTransa;

    private Date instantModifTransa;

    private float mntTransaPaimtDigi;

    private DeviseEnum codeDevMntTransaPaimtDigi;

    private String codeSitTransaPaimtDigi;

    private String libSitTransaPaimtDigi;

    private String codeTechSitTransaPaimtDigi;
}
