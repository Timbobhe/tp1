/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PlafondDto {

    private Long id;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private TypeFrequenceEnum typeFrequence;

    private Float montantMinimum;

    private Float montantMaximum;

    private Integer nombreMaximumPaiement;

}
