package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseCalculFacade;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.ParamLabException.ANOMALIE_CALCUL_MAX;
import static fr.ag2rlamondiale.paiementdigital.exception.ParamLabException.ANOMALIE_CALCUL_MIN;

@Service
public class ResponseCalculFacadeImpl implements IResponseCalculFacade {

    @Override
    public float maxDesMontantsDispo(Set<RecupParamPeriMethPaimtResp> methodes) {
        RecupParamPeriMethPaimtResp result = methodes
                .stream()
                .max(Comparator.comparing(RecupParamPeriMethPaimtResp::getMinMontantDispoClient))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MAX));

        return result.getMinMontantDispoClient();
    }

    @Override
    public String methodeMaxDesMontantsDispo(Set<RecupParamPeriMethPaimtResp> methodes, float maxDesMontantsDispo) {
        return methodes
                .stream()
                .filter(p -> maxDesMontantsDispo == p.getMinMontantDispoClient())
                .map(RecupParamPeriMethPaimtResp::getMethodeDePaiement)
                .collect(Collectors.joining(",", "[", "]"));
    }

    @Override
    public int maxDesNombresDePaiementDispo(Set<RecupParamPeriMethPaimtResp> methodes) {
        RecupParamPeriMethPaimtResp result = methodes
                .stream()
                .max(Comparator.comparing(RecupParamPeriMethPaimtResp::getMinNombrePaiementDisponible))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MAX));

        return result.getMinNombrePaiementDisponible();
    }

    @Override
    public String methodeMaxDesNombresDePaiementDispo(Set<RecupParamPeriMethPaimtResp> methodes, int maxDesNombresDePaiementDispo) {
        return methodes
                .stream()
                .filter(p -> maxDesNombresDePaiementDispo == p.getMinNombrePaiementDisponible())
                .map(RecupParamPeriMethPaimtResp::getMethodeDePaiement)
                .collect(Collectors.joining(",", "[", "]"));
    }

    @Override
    public float minMontantDispoClient(Set<RecupParamPlfdFreqResp> plafonds) {
        RecupParamPlfdFreqResp result = plafonds
                .stream()
                .min(Comparator.comparing(RecupParamPlfdFreqResp::getMontantMaxdispoClient))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MIN));

        return result.getMontantMaxdispoClient();
    }

    @Override
    public String frequenceMinMontantDispoClient(Set<RecupParamPlfdFreqResp> plafonds) {
        RecupParamPlfdFreqResp result = plafonds
                .stream()
                .sorted(Comparator.comparing(RecupParamPlfdFreqResp::getMontantMaxdispoClient)
                        .thenComparing(Comparator.comparing(RecupParamPlfdFreqResp::getTypeFrequence))
                        .reversed())
                .min(Comparator.comparing(RecupParamPlfdFreqResp::getMontantMaxdispoClient))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MIN));

        return result.getTypeFrequence();
    }

    @Override
    public int minNombrePaiementDisponible(Set<RecupParamPlfdFreqResp> plafonds) {
        RecupParamPlfdFreqResp result = plafonds
                .stream()
                .min(Comparator.comparing(RecupParamPlfdFreqResp::getNombreMaxDispoClient))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MIN));

        return result.getNombreMaxDispoClient();
    }

    @Override
    public String frequenceNombrePaiementDisponible(Set<RecupParamPlfdFreqResp> plafonds) {
        RecupParamPlfdFreqResp result = plafonds
                .stream()
                .sorted(Comparator.comparing(RecupParamPlfdFreqResp::getNombreMaxDispoClient)
                        .thenComparing(Comparator.comparing(RecupParamPlfdFreqResp::getTypeFrequence))
                        .reversed())
                .min(Comparator.comparing(RecupParamPlfdFreqResp::getNombreMaxDispoClient))
                .orElseThrow(() -> new ParamLabException(ANOMALIE_CALCUL_MIN));

        return result.getTypeFrequence();
    }

    @Override
    public float montantMaxDispoClient(float montant, List<Float> montantsCaptured) {
        float sumMontants = 0;

        if (!CollectionUtils.isEmpty(montantsCaptured))
            sumMontants = montantsCaptured.stream().reduce(0F, (a, b) -> a + b);

        return montant - sumMontants;
    }

    @Override
    public int nombreMaxDispoClient(int nombre, List<Float> montantsCaptured) {
        int monstantsSize = 0;

        if (!CollectionUtils.isEmpty(montantsCaptured))
            monstantsSize = montantsCaptured.size();

        return nombre - monstantsSize;
    }
}
