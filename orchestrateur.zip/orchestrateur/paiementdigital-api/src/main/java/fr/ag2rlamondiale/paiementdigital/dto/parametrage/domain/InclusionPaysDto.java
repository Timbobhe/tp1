/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.JSON_PATTERN_DATE_FORMAT;
import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InclusionPaysDto implements Serializable {

    private static final long serialVersionUID = 7843194928349790384L;

    private Long id;

    private String metier;

    private String codeApplication;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private TypePaysEnum typePays;

    private String pays;

    private String codeIso;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateEffet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = JSON_PATTERN_DATE_FORMAT)
    private Date dateCreation;

    public InclusionPaysDto copy(InclusionPaysDto paysDto) {
        return InclusionPaysDto
                .builder()
                .metier(paysDto.getMetier())
                .codeApplication(paysDto.getCodeApplication())
                .typePays(paysDto.getTypePays())
                .pays(paysDto.getPays())
                .codeIso(paysDto.getCodeIso())
                .dateEffet(paysDto.getDateEffet())
                .dateCreation(paysDto.getDateCreation())
                .build();
    }
}
