package fr.ag2rlamondiale.paiementdigital.dto;

import java.io.Serializable;

public abstract class PfsResponse implements Serializable {

    private static final long serialVersionUID = 3354201975532675154L;
}
