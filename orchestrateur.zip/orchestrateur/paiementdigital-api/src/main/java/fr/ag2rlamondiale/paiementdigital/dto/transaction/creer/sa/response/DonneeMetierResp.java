package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DonneeMetierResp implements Serializable {

    private static final long serialVersionUID = -668965253519694762L;

    private String typeDonnee;

    private String valeurDonnee;
}
