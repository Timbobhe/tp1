package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public class ResponseBuilderFacadeImpl implements IResponseBuilderFacade {

    @Override
    public RecupParamRootResp build(RecupParamProfResp parametresProfilsDto,
                                    Set<ExclusionBanqueDto> exclusions,
                                    Set<InclusionPaysDto> inclusions) {
        return RecupParamRootResp
                .builder()
                .code(HttpStatus.OK.value())
                .message(HttpStatus.OK.name())
                .parametresProfilsDto(parametresProfilsDto)
                .exclusions(exclusions)
                .inclusions(inclusions)
                .build();
    }

    @Override
    public RecupParamProfResp build(float maxDesMontantsDispo,
                                    String methodeMaxDesMontantsDispo,
                                    int maxDesNombresDePaiementDispo,
                                    String methodeMaxDesNombresDePaiementDispo,
                                    Set<RecupParamPeriMethPaimtResp> perimetreMethodePaiement) {
        return RecupParamProfResp
                .builder()
                .maxDesMontantsDispo(maxDesMontantsDispo)
                .methodeMaxDesMontantsDispo(methodeMaxDesMontantsDispo)
                .maxDesNombresDePaiementDispo(maxDesNombresDePaiementDispo)
                .methodeMaxDesNombresDePaiementDispo(methodeMaxDesNombresDePaiementDispo)
                .perimetreMethodePaiement(perimetreMethodePaiement)
                .build();
    }

    @Override
    public RecupParamPeriMethPaimtResp build(String methodeDePaiement,
                                             float minMontantDispoClient,
                                             String frequenceMinMontantDispoClient,
                                             int minNombrePaiementDisponible,
                                             String frequenceNombrePaiementDisponible,
                                             Set<RecupParamPlfdFreqResp> plafondsParFrequences) {
        return RecupParamPeriMethPaimtResp
                .builder()
                .methodeDePaiement(methodeDePaiement)
                .frequenceMinMontantDispoClient(frequenceMinMontantDispoClient)
                .minMontantDispoClient(minMontantDispoClient)
                .frequenceNombrePaiementDisponible(frequenceNombrePaiementDisponible)
                .minNombrePaiementDisponible(minNombrePaiementDisponible)
                .plafondsParFrequences(plafondsParFrequences)
                .build();
    }

    @Override
    public RecupParamPlfdFreqResp build(Plafond plafond,
                                        float montantMaxdispoClient,
                                        int nombreMaxDispoClient) {
        return RecupParamPlfdFreqResp
                .builder()
                .typeFrequence(plafond.getTypeFrequence().name())
                .montantMin(plafond.getMontantMinimum())
                .montantMax(plafond.getMontantMaximum())
                .nombreMax(plafond.getNombreMaximumPaiement())
                .montantMaxdispoClient(montantMaxdispoClient)
                .nombreMaxDispoClient(nombreMaxDispoClient)
                .build();
    }
}
