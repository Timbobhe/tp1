package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailTransaPaimtDigiResp implements Serializable {

    private static final long serialVersionUID = -4010705760616786971L;

    private String idTransaction;

    @JsonProperty("numeroAutorisationTransactionPaiementNumerise")
    private String numAutoTransPaiemtNum;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonProperty("instantAutorisationTransaction")
    private Date instantAutoTrans;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonProperty("instantCreationTransaction")
    private Date instantCreationTrans;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @JsonProperty("instantModificationTransaction")
    private Date instantModifTrans;

    @JsonProperty("montantTransactionPaiementDigital")
    private String mntTransPaiemtDigi;

    @JsonProperty("codeDeviseMontantTransactionPaiementDigital")
    private String codeDevMntTransPaiemtDigi;
}
