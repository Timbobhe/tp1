package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class HeaderResp implements Serializable {

    private static final long serialVersionUID = -7373468530375891527L;

    @JsonProperty("FuncError")
    private List<ErrorResp> funcError;

    @JsonProperty("TechError")
    private List<ErrorResp> techError;

}
