package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ModifPaimtDigiBisReq {

    @JsonProperty("DetTransaPaimtNumerise")
    private ModifPaimtDetTransaPaimtNumReq detTransaPaimtNumerise;

    @JsonProperty("DetMontantPaimt")
    private ModifPaimtDetMontantPaimtReq detailMontantPaimt;

    @JsonProperty("InfoTech")
    private ModifPaimtInfoTechReq infoTech;
}
