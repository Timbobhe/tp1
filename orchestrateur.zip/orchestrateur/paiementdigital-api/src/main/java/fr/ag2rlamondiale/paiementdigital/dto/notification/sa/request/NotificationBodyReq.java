package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class NotificationBodyReq {

    @JsonProperty("NotifierPaiementDigital")
    private NotificationRootReq notificationRootReq;

}
