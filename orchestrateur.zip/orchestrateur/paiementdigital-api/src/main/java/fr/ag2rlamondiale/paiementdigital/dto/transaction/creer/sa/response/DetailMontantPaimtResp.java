package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailMontantPaimtResp implements Serializable {

    private static final long serialVersionUID = -3137550967918570384L;

    @JsonProperty("montantTTC")
    private float mntTTC;

    @JsonProperty("montantFraisLivraison")
    private float mntFraisLivr;

    @JsonProperty("montantTaxes")
    private float mntTaxes;

    @JsonProperty("codeDeviseVersement")
    private DeviseEnum codeDevVers;
}
