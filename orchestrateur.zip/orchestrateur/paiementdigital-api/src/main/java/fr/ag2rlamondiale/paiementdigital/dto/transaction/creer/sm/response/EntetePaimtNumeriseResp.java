package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EntetePaimtNumeriseResp implements Serializable {

    private static final long serialVersionUID = 1904266925692822319L;

    private String idDemPaimt;

    private String codeValECI;

    private String codeNivSecuPaimtDigi;

    private int numTentvPaimtDigi;

    private String codeModePaimt;
}
