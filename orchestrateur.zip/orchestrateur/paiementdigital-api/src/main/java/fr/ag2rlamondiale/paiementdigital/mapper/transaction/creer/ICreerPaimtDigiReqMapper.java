package fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Set;

@Mapper
public interface ICreerPaimtDigiReqMapper {

    @Mapping(source = "paiement.orderId", target = "idPaimtDigi")
    @Mapping(source = "entetePaiementDigital.descriptionPaiementDigital", target = "descPaimtDigi")
    @Mapping(source = "entetePaiementDigital.codeValeurECI", target = "codeValECI")
    @Mapping(source = "entetePaiementDigital.codeNiveauSecuritePaiementDigital", target = "codeNivSecuPaimtDigi")
    EntetePaimtNumeriseReq toEntetePaimtNumerise(EntetePaiementDigitalReq entetePaiementDigital, Paiement paiement);

    @Mapping(source = "identifiantExtranet", target = "idExtranet")
    @Mapping(source = "dateCreationEspaceClient", target = "dateCreatEspCli")
    @Mapping(source = "dureeDepuisCreation", target = "dureeCreat")
    @Mapping(source = "dateModificationEspaceClient", target = "dateModifEspCli")
    @Mapping(source = "dureeDepuisModification", target = "dureeModif")
    @Mapping(source = "dateModificationMotDePasseEspaceClient", target = "dateModifMDPEspCli")
    @Mapping(source = "dureeDepuisModificationMotDePasse", target = "dureeModifMDP")
    @Mapping(source = "nombreEssaiAjoutCarte24H", target = "nbeEssaiAjoutCarte24H")
    @Mapping(source = "dateEnregistrementCartePaiement", target = "dateEnrCartePaimt")
    @Mapping(source = "dureeDepuisEnregistrementCartePaiement", target = "dureeEnrCartePaimt")
    @Mapping(source = "datePremiereUtilisationAdresseLivraison", target = "datePremUtilAdrLivr")
    @Mapping(source = "dureeDepuisPremiereUtilisationAdresseLivraison", target = "dureePremUtilAdrLivr")
    @Mapping(source = "nombreCommandeAnnee", target = "nbeCmdAnnee")
    @Mapping(source = "nombreCommandeDernierSixMois", target = "nbeCmd6M")
    @Mapping(source = "nombreCommande24H", target = "nbeCmd24H")
    @Mapping(source = "indicateurActiviteSuspicieuse", target = "indActivSuspt")
    @Mapping(source = "indicateurNomsIdentiques", target = "indNomsIdentiques")
    DetEspCliReq toDetEspCli(DetailEspaceClientReq detailEspaceClient);

    @Mapping(source = "detailMethodePaiementReq.detailCarte.identifiantChiffreMoyenPaiement", target = "idChiffreMoyenPaimt")
    @Mapping(source = "detailMethodePaiementReq.detailCarte.numeroCarte", target = "numCarte")
    @Mapping(source = "detailMethodePaiementReq.methodeDePaiement", target = "codeTypeCarte")
    DetCartePaimtReq toDetCartePaimt(DetailMethodePaiementReq detailMethodePaiementReq);

    @Mapping(source = "codeIBAN", target = "codeIBAN")
    @Mapping(source = "codeBIC", target = "codeBIC")
    @Mapping(source = "identifiantRUM", target = "idRUM")
    //@Mapping(source = "indicateurAccordMandatSEPA", target = "indAccordMandatSEPA")
    @Mapping(target = "indAccordMandatSEPA",
            expression = "java(getStringFromBoolean(detailSepa.isIndicateurAccordMandatSEPA()))")
    DetSepaReq toDetSepa(DetailSEPAReq detailSepa);

    @Mapping(source = "identifiantPorteMonnaieElectronique", target = "idPorteMonnaieElec")
    DetPorteMonnaieElecReq toDetPorteMonnaieElec(DetailPorteMonnaieElectroniqueReq detailPrtMonElec);

    @Mapping(source = "montantTTC", target = "mntTTC")
    @Mapping(source = "montantFraisLivraison", target = "mntFraisLivr")
    @Mapping(source = "montantTaxes", target = "mntTaxes")
    @Mapping(source = "tauxTaxes", target = "tauxTaxes")
    @Mapping(source = "codeDeviseVersement", target = "codeDevVersm")
    @Mapping(source = "datePrevueVersement", target = "datePrevueVersm")
    DetMntPaimtReq toDetMntPaimt(DetailMontantPaiementReq detailMontantPaiement);

    @Mapping(source = "codeTypeTransactionPaiementDigital", target = "codeTypeTransaPaimtDigi")
    @Mapping(source = "codeDeviseMontantTransactionPaiementDigital", target = "codeDevMntTransaPaimtDigi")
    @Mapping(source = "codeCategorieCommande", target = "codeCatCmd")
    DetTransaPaimtNumeriseReq toDetTransaPaimtNumerise(DetailTransactionPaiementNumeriseReq detailTransPaitNumerise);

    @Mapping(source = "methodeLivraison", target = "mtdLivr")
    @Mapping(source = "descriptionLivreur", target = "descLivreur")
    LivrReq toLivr(LivraisonReq livraison);

    @Mapping(source = "acceptUrl", target = "acceptUrl")
    @Mapping(source = "declineUrl", target = "declineUrl")
    @Mapping(source = "cancelUrl", target = "cancelUrl")
    @Mapping(source = "notifyUrl", target = "notifyUrl")
    RedirectReq toRedirect(RedirectionReq redirection);

    @Mapping(source = "adresseIP", target = "adrIP")
    @Mapping(source = "httpAccept", target = "httpAccept")
    @Mapping(source = "httpUserAgent", target = "httpUserAgent")
    @Mapping(source = "deviceFingerPrint", target = "deviceFingerPrint")
    @Mapping(source = "javaEnabled", target = "javaEnabled")
    @Mapping(source = "javascriptEnabled", target = "javascriptEnabled")
    @Mapping(source = "colorDepth", target = "colorDepth")
    @Mapping(source = "screenHeight", target = "screenHeight")
    @Mapping(source = "screenWidth", target = "screenWidth")
    @Mapping(source = "language", target = "language")
    @Mapping(source = "timezone", target = "timezone")
    @Mapping(source = "deviceChannel", target = "deviceChannel")
    @Mapping(source = "sdkInfoInterface", target = "sdkInfoInterface")
    @Mapping(source = "sdkInfoUiType", target = "sdkInfoUiType")
    @Mapping(source = "sdkInfoAppId", target = "sdkInfoAppId")
    InfoTechReq toInfoTech(InformationsTechniquesReq informationsTechniques);

    Set<TelReq> toTelReq(Set<TelephoneReq> telephone);

    default String getStringFromBoolean(Boolean isIndicateurAccordMandatSEPA) {
        return isIndicateurAccordMandatSEPA ? "1" : "0";
    }
}
