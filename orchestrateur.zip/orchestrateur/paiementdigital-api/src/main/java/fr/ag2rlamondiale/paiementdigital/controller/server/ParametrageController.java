package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@Validated
@RestController
@RequestMapping(value = "/api/parametrage", produces = MediaType.APPLICATION_JSON_VALUE)
public class ParametrageController {

    @Autowired
    private IResponseRecupParamLABFacade facade;

    @ApiOperation(value = "Récupération du paramétrage LAB",
            notes = "Il s'agit de récupérer un périmètre du paramétrage LAB en fonction des critères de recherche.")
    @PostMapping("/get")
    public ResponseEntity<RecupParamRootResp> recupererParametragesLab(@ApiParam(required = true, value = "Critères de recherche") @Valid @RequestBody RecupParamRootReq pfsDto) {
        return new ResponseEntity<>(facade.recupererParametragesLab(pfsDto), ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

}
