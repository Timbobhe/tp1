package fr.ag2rlamondiale.paiementdigital.business.notification.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.notification.INotificationRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.domain.DonneeMetier;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.*;
import fr.ag2rlamondiale.paiementdigital.exception.NotificationException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.mapper.notification.INotificationMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.HipayConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.VALEUR_STT_EXCEPTION;
import static fr.ag2rlamondiale.paiementdigital.exception.NotificationException.INVALID_PARAMETER;

@Service
@Slf4j
public class NotificationRespBuilderFacadeImpl implements INotificationRespBuilderFacade {

    @Autowired
    private IPaiementFacade paiementFacade;

    @Autowired
    private INotificationMapper mapper;

    @Override
    public NotificationRootResp build(NotificationRootReq request) {
        log.debug("NotificationRootReq {}", request);

        if (Objects.isNull(request) || Objects.isNull(request.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement()))
            throw new NotificationException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        log.info("Mise à jour du paiement lié à l'order Id {} avec le status {} et le message {}", request.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement(), request.getNotificationReq().getPaimentDigiReq().getStatut(),request.getNotificationReq().getPaimentDigiReq().getMessage());

        try {
            Paiement paiement = paiementFacade.findByOrderId(request.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise().getIdentifiantDemandePaiement());

            Historique historique = buildHistoriquePaiementFromRequest(paiement, request);

            if(historique != null){

                Paiement paiementUpdated = updateHistoriquePaiement(paiement, historique);

                Set<CustomDataResp> customData = mapper.toCustomData(request.getNotificationReq().getPaimentDigiReq().getCustomDatas());

                DepistageFraudeResp depistageFraude = mapper.toDepistageFraude(request.getNotificationReq().getPaimentDigiReq().getDepistageFraude());

                DetailActeurResp detailActeur = mapper.toDetailActeur(request.getNotificationReq().getPaimentDigiReq().getDetailActeur());

                DetailCartePaiementResp detailCartePaiement = mapper.toDetailCartePaiement(request.getNotificationReq().getPaimentDigiReq().getDetailCartePaiement());

                DetailMontantPaiementResp detailMontantPaiement = mapper.toDetailMontantPaiement(request.getNotificationReq().getPaimentDigiReq().getDetailMontantPaiement());

                DetailTransactionPaiementNumeriseResp detTransaPaimtNum= mapper.toDetTransaPaimtNum(request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise());

                EntetePaiementNumeriseResp entetePaiementNumerise = mapper.toEntetePaimtNumerise(request.getNotificationReq().getPaimentDigiReq().getEntetePaiementNumerise());

                InformationsTechniquesResp informationsTechniques = mapper.toInformationsTechniques(request.getNotificationReq().getPaimentDigiReq().getInformationsTechniques());

                MaintenanceOperationResp maintenanceOperation = mapper.toMaintenanceOperation(request.getNotificationReq().getPaimentDigiReq().getMaintenanceOperation());

                Set<DonneeMetierResp> donneeMetierResp = mapper.toDonneeMetierResp(paiementUpdated.getDonneeMetiers());

                PaimentDigiResp paimentDigiResp = PaimentDigiResp.builder()
                     .customDatas(customData)
                        .depistageFraude(depistageFraude)
                        .detailActeur(detailActeur)
                        .detailCartePaiement(detailCartePaiement)
                        .detailMontantPaiement(detailMontantPaiement)
                        .detailTransPaiemtNumerise(detTransaPaimtNum)
                        .entetePaiementNumerise(entetePaiementNumerise)
                        .informationsTechniques(informationsTechniques)
                        .maintenanceOperation(maintenanceOperation)
                        .donneesMetier(donneeMetierResp)
                        .destinataire(paiementUpdated.getCodeApplication())
                        .identifiantMarchant(request.getNotificationReq().getPaimentDigiReq().getIdentifiantMarchant())
                        .identifiantTentative(request.getNotificationReq().getPaimentDigiReq().getIdentifiantTentative())
                        .indicateurModeTest(request.getNotificationReq().getPaimentDigiReq().getIndicateurModeTest())
                        .message(historique.getMessage())
                        .statut(historique.getStatus())
                    .build();

                NotificationResp notificationResp = NotificationResp.builder()
                    .paimentDigiResp(paimentDigiResp)
                    .build();

                NotificationRootResp notificationRootResp = NotificationRootResp.builder()
                    .notificationResp(notificationResp)
                    .build();

                return populateNotificationResponse(notificationRootResp, paiementUpdated);

            }else {
                throw new NotificationException(HttpStatus.BAD_REQUEST, "Erreur lors de la mise à jour de l'historique de paiement.");
            }
        }catch (PaiementException e){
            throw new NotificationException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    private Historique buildHistoriquePaiementFromRequest(Paiement paiement, NotificationRootReq request) {

        log.info("Création de l'historique du paiement trouvé Paiement(id = {}, orderId = {}, idTransaction = {}, metier = {}," +
                " codeApplication = {}, evenementMetier = {}, etatCourant = {}, paysResidence = {}, paysResidenceFiscale = {})",
                paiement.getId(), paiement.getOrderId(), paiement.getIdTransaction(), paiement.getMetier(), paiement.getCodeApplication(),
                paiement.getEvenementMetier(), paiement.getEtatCourant(), paiement.getPaysResidence(), paiement.getPaysResidenceFiscale());

        Historique historique = null;
        String message = request.getNotificationReq().getPaimentDigiReq().getMessage();
        String status = request.getNotificationReq().getPaimentDigiReq().getStatut();
        String codeSituation = request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital();

        if (CPL.equalsIgnoreCase(codeSituation)
                || ANN.equalsIgnoreCase(codeSituation)|| ATT.equalsIgnoreCase(codeSituation)) {
            if (CPL.equalsIgnoreCase(request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital())) {
                historique = buildCplHistorique(request, paiement, status, message);
            }else if (ANN.equalsIgnoreCase(request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital())){
                historique = buildHistorique(paiement, EtatEnum.FAIL, status, message);
            }else if (ATT.equalsIgnoreCase(request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital())){
                historique = buildHistorique(paiement, EtatEnum.PENDING, status, message);
            }

        }else {
            throw new NotificationException(HttpStatus.BAD_REQUEST, "le codeSituationTransactionPaiementDigital: " + request.getNotificationReq().getPaimentDigiReq().getDetailTransPaiemtNumerise().getCodeSituationTransactionPaiementDigital() + " n'est pas géré.");
        }

        return historique;
    }

    private Historique buildCplHistorique(NotificationRootReq request, Paiement paiement, String status, String message) {

        switch (request.getNotificationReq().getPaimentDigiReq().getStatut()){
            case STT_CODE_AUTHENTIFICATION_ECHOUEE :
                return buildHistorique(paiement, EtatEnum.AUT_ECHOUEE, status, message);

            case STT_CODE_BLOQUED :
                return buildHistorique(paiement, EtatEnum.BLOQUED, status, message);

            case STT_CODE_DENIED :
                return buildHistorique(paiement, EtatEnum.DENIED, status, message);

            case STT_CODE_AUTORISED_ATTENTE :
                return buildHistorique(paiement, EtatEnum.AUTORISED_ATT, status, message);

            case STT_CODE_REFUSED :
                return buildHistorique(paiement, EtatEnum.REFUSED, status, message);

            case STT_CODE_PERIME :
                return buildHistorique(paiement, EtatEnum.PERIME, status, message);

            case STT_CODE_ANNULE :
                return buildHistorique(paiement, EtatEnum.ANNULE, status, message);

            case STT_CODE_AUTHORIZED_OK :
                return buildHistorique(paiement, EtatEnum.AUTHORIZED, status, message);

            case STT_CODE_CAPTURE_DEMANDEE :
                return buildHistorique(paiement, EtatEnum.CAPTURE_DEMANDE, status, message);

            case STT_CODE_CAPTURED_OK :
                return buildHistorique(paiement, EtatEnum.CAPTURED, status, message);

            case STT_CODE_PARTIELLEMENT_CAPTURE :
                return buildHistorique(paiement, EtatEnum.PART_CAPTURE, status, message);

            case STT_CODE_REMBOURSEMENT_DEMANDE :
                return buildHistorique(paiement, EtatEnum.REM_DEMANDE, status, message);

            case STT_CODE_REMBOURSE :
                return buildHistorique(paiement, EtatEnum.REMBOURSE, status, message);

            case STT_CODE_PARTIELLEMENT_REMBOURSE :
                return buildHistorique(paiement, EtatEnum.PART_REMBOURSE, status, message);

            case STT_CODE_IMPAYE :
                return buildHistorique(paiement, EtatEnum.IMPAYE, status, message);

            case STT_CODE_DISPUTE_LOST :
                return buildHistorique(paiement, EtatEnum.DISPUTE_LOST, status, message);

            case STT_CODE_AUTORISATION_DEMANDEE :
                return buildHistorique(paiement, EtatEnum.AUT_DEMANDEE, status, message);

            case STT_CODE_AUTHORIZATION_CANCELLED :
                return buildHistorique(paiement, EtatEnum.AUT_CANCELLED, status, message);

            case STT_CODE_REFERENCE_RENDERED :
                return buildHistorique(paiement, EtatEnum.REF_RENDERED, status, message);

            case STT_CODE_REMBOURSEMENT_REFUSE :
                return buildHistorique(paiement, EtatEnum.REM_REFUSE, status, message);

            case STT_CODE_CARDHOLDER_CREDIT :
                return buildHistorique(paiement, EtatEnum.CARD_CREDIT, status, message);

            case STT_CODE_REPORTED_FRAUD :
                return buildHistorique(paiement, EtatEnum.REPORTED_FRAUD, status, message);

            case STT_CODE_DEBITED :
                return buildHistorique(paiement, EtatEnum.DEBITED, status, message);

            case STT_CODE_CREDIT_REQUESTED :
                return buildHistorique(paiement, EtatEnum.CRE_REQUESTED, status, message);

            case STT_CODE_IN_PROGRESS :
                return buildHistorique(paiement, EtatEnum.IN_PROGRESS, status, message);

            case STT_CODE_AWAITING_TERMINAL : return buildHistorique(paiement, EtatEnum.AWT_TERMINAL, status, message);

            case STT_CODE_AUTHORIZATION_CANCELLATION_REQUESTED :
                return buildHistorique(paiement, EtatEnum.AUT_CANCEL_REQ, status, message);

            case STT_CODE_SOFT_DECLINED :
                return buildHistorique(paiement, EtatEnum.SOFT_DECLINED, status, message);

            case STT_CODE_CAPTURE_FAIL :
                return buildHistorique(paiement, EtatEnum.CAPTURE_FAIL, status, message);

            default: throw new NotificationException(HttpStatus.BAD_REQUEST, VALEUR_STT_EXCEPTION);

        }
    }

    private Historique buildHistorique(Paiement paiement, EtatEnum etat, String status, String message) {
        return Historique.builder()
                .etat(etat)
                .status(status)
                .message(message)
                .montant(paiement.getMontant())
                .id(new HistoriquePK(new Date(), paiement.getId()))
                .paiement(paiement)
                .build();
    }

    private NotificationRootResp populateNotificationResponse(NotificationRootResp response, Paiement paiementUpdated) {
        if (response.getNotificationResp().getPaimentDigiResp().getDonneesMetier() == null) {
            response.getNotificationResp().getPaimentDigiResp().setDonneesMetier(new HashSet<>());
        }
        Set<DonneeMetierResp> donneeMetier = buildDonneesMetier(paiementUpdated.getDonneeMetiers());
        response.getNotificationResp().getPaimentDigiResp().setDonneesMetier(donneeMetier);
        response.getNotificationResp().getPaimentDigiResp().setDestinataire(paiementUpdated.getCodeApplication());

        log.info("Renvoie de la notification");

        return response;
    }

    private Paiement updateHistoriquePaiement(Paiement paiement, Historique historique) {

        log.info("Mise à jour de l'historique du paiement ");

        Paiement paiementCopy = paiement.copy(paiement);
        paiementCopy.setEtatCourant(historique.getEtat());
        paiementCopy.setDateModification(new Date());
        paiementCopy.getHistoriques().add(historique);

        try {
            Paiement paiementUpdated = paiementFacade.update(paiementCopy);
            log.debug("Résultat du paiement après mise à jour de la notification reçue en base de données : {}", paiementUpdated);
            return paiementUpdated;

        } catch (NotificationException e) {
            throw new NotificationException(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }

    private Set<DonneeMetierResp> buildDonneesMetier(Set<DonneeMetier> donneeMetiers) {
        Set<DonneeMetierResp> donneeMetierResp = new HashSet<>();
        donneeMetiers.stream().forEach(donneeMetier -> donneeMetierResp.add(DonneeMetierResp.builder()
                .typeDonnee(donneeMetier.getTypeDonnee())
                .valeurDonnee(donneeMetier.getValeurDonnee())
                .build()));
        return donneeMetierResp;
    }
}
