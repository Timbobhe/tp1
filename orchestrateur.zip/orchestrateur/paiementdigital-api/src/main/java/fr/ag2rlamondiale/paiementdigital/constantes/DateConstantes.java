package fr.ag2rlamondiale.paiementdigital.constantes;

public final class DateConstantes {

    private DateConstantes() {
    }

    public static final String JSON_PATTERN_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String YYYY_DD_MM_FORMAT = "yyyy-MM-dd";
}
