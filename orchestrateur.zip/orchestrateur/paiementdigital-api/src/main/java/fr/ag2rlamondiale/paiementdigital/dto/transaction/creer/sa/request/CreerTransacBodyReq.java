package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class CreerTransacBodyReq {
    @JsonProperty("CreationTransactionPaiementDigital")
    private CreerTransaPaimtDigiRootReq creerTransacPaimtDigiRequestDto;
}

