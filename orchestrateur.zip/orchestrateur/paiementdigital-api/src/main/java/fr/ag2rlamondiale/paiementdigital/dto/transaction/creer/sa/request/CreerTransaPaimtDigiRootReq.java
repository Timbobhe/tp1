package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Optional;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class CreerTransaPaimtDigiRootReq {

    @JsonProperty("EntetePaiementDigital")
    private EntetePaiementDigitalReq entetePaiementDigital;

    @JsonProperty("DetailActeurs")
    private DetailActeursReq detailActeurs;

    @JsonProperty("DetailPerimetreMetier")
    private DetailPerimetreMetierReq detailPerimetreMetier;

    @JsonProperty("DetailEspaceClient")
    private DetailEspaceClientReq detailEspaceClient;

    @JsonProperty("DetailMethodePaiement")
    private DetailMethodePaiementReq detailMethodePaiement;

    @JsonProperty("DetailMontantPaiement")
    private DetailMontantPaiementReq detailMontantPaiement;

    @JsonProperty("DetailTransactionPaiementNumerise")
    private DetailTransactionPaiementNumeriseReq detailTransPaiemtNumerise;

    @JsonProperty("Livraison")
    private LivraisonReq livraison;

    @JsonProperty("CustomData")
    private Set<CustomDataReq> customDatas;

    @JsonProperty("DonneesMetier")
    private Set<DonneeMetierReq> donneesMetiers;

    @JsonProperty("InformationsTechniques")
    private InformationsTechniquesReq informationsTechniques;

    @JsonProperty("Redirection")
    private RedirectionReq redirection;

    public CustomDataReq getCustomData(int value) {
        Optional<CustomDataReq> result = customDatas.stream().filter(c -> c.getOrdre() == value).findFirst();
        return result.isPresent() ? result.get() : null;
    }

}
