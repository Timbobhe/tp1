package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IDetailActeurFacade;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.DetailActeursReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.DetailPerimetreMetierReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.*;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer.ICreerPaimtDigiReqMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

@Service
@Slf4j
public class DetailActeurFacadeImpl implements IDetailActeurFacade {

    @Autowired
    private ICreerPaimtDigiReqMapper mapper;

    @Override
    public DetActrReq detailActeurs(CreerTransaPaimtDigiRootReq request) {
        log.debug("Création de la partie DetailActeurs pour le SM creerpaiementDigital");
        log.debug("CreerTransaPaimtDigiRootReq {}", request);

        List<IdPersDansSiloReq> listIdentifiantSilo = getIdentifiantsSilo(request);

        // RDG06
        InfoPMReq infoPM = null;
        if (request.getDetailPerimetreMetier() != null
                && PfsParametersConstantes.CODES_APPLI_RETRAITE_SUP.contains(request.getDetailPerimetreMetier().getCodeApplication())) {
            infoPM = InfoPMReq.builder().codeFiliale(request.getCustomData(1).getCdata()).build();
        }

        InfoPPReq infoPP = getInfoPP(request.getDetailActeurs());

        DetActrReq result = DetActrReq
                .builder()
                .codeRole(request.getDetailActeurs().getCodeRole())
                .idPersDansSilo(listIdentifiantSilo)
                .infoPM(infoPM)
                .infoPP(infoPP)
                .build();

        log.debug("DetActrReq {}", result);
        return result;
    }

    private DosComReq getDosCom(DetailActeursReq detailActeurs) {
        AdrReq adresse = AdrReq
                .builder()
                .adrLig1(detailActeurs.getAdresseLigne1()).adrLig2(detailActeurs.getAdresseLigne2())
                .libVil(detailActeurs.getLibelleCommune()).numCodePostal(detailActeurs.getNumeroCodePostal())
                .libPays(detailActeurs.getPaysResidence())
                .build();

        Set<TelReq> telephones = Objects.isNull(detailActeurs.getTelephone()) ? null : mapper.toTelReq(detailActeurs.getTelephone());

        DetCnlComReq detailsAdrTel = DetCnlComReq
                .builder()
                .adr(adresse)
                .emails(new EmailsReq(detailActeurs.getLibelleEmail()))
                .tel(telephones)
                .build();

        return new DosComReq(detailsAdrTel);
    }

    private List<IdPersDansSiloReq> getIdentifiantsSilo(CreerTransaPaimtDigiRootReq request) {
        DetailActeursReq detailActeurs = request.getDetailActeurs();

        List<IdPersDansSiloReq> listIdentifiantSilo = new ArrayList<>();

        // RDG03
        IdPersDansSiloReq idDansSilo1 = IdPersDansSiloReq
                .builder()
                .idPers(detailActeurs.getIdUniqueClient())
                .codeAppli(PfsParametersConstantes.CODE_APPLI_ESPACE_CLIENT_HABILITATIONS)
                .build();

        listIdentifiantSilo.add(idDansSilo1);

        DetailPerimetreMetierReq detailsPerMetier = request.getDetailPerimetreMetier();
        if (detailsPerMetier != null
                && PfsParametersConstantes.CODES_APPLI_RETRAITE_SUP.contains(detailsPerMetier.getCodeApplication())) {

            // RDG04
            listIdentifiantSilo.add(
                    IdPersDansSiloReq
                            .builder()
                            .idPers(request.getCustomData(3).getCdata())
                            .codeAppli(PfsParametersConstantes.CODE_APPLI_PTV)
                            .build()
            );

            // RDG05
            listIdentifiantSilo.add(
                    IdPersDansSiloReq
                            .builder()
                            .idPers(request.getCustomData(5).getCdata())
                            .codeAppli(request.getCustomData(4).getCdata()).build()
            );

        }

        return listIdentifiantSilo;
    }

    private InfoPPReq getInfoPP(DetailActeursReq detailActeurs) {

        Signq2Req signq2 = Signq2Req
                .builder()
                .dateNais(detailActeurs.getDateNaissance())
                .codeSexe(detailActeurs.getCodeSexe())
                .prenom(detailActeurs.getPrenom())
                .nom(detailActeurs.getNom())
                .civ(detailActeurs.getCivilite())
                .build();

        DosComReq dosCom = getDosCom(detailActeurs);

        SignqReq signq = SignqReq.builder().signq2(signq2).dosCom(dosCom).build();

        return new InfoPPReq(signq);
    }

}
