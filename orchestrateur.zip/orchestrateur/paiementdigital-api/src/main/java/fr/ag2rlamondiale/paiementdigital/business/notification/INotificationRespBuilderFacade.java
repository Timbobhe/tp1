package fr.ag2rlamondiale.paiementdigital.business.notification;

import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request.NotificationRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response.NotificationRootResp;
import org.springframework.stereotype.Service;

@Service
public interface INotificationRespBuilderFacade {

    NotificationRootResp build(NotificationRootReq request);

}
