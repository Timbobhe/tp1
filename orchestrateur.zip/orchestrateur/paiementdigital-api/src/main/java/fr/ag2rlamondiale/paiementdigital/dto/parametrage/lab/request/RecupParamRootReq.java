package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecupParamRootReq {

    @NotNull
    private RecupParamProflReq profil;

    private RecupParamCliReq client;

    private RecupParamPeriReq perimetre;

    @NotNull
    private Date dateRecherche;

    @NotNull
    private boolean exclusionBanques;

    @NotNull
    private boolean inclusionPays;
}
