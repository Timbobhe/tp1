package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaimentDigiReq {

    @JsonProperty("CustomData")
    @Builder.Default
    private Set<CustomDataReq> customDatas = new HashSet<>();

    @JsonProperty("DepistageFraude")
    DepistageFraudeReq depistageFraude;

    @JsonProperty("DetailActeur")
    DetailActeurReq detailActeur;

    @JsonProperty("DetailCartePaiement")
    private DetailCartePaiementReq detailCartePaiement;

    @JsonProperty("DetailMontantPaiement")
    DetailMontantPaiementReq detailMontantPaiement;

    @JsonProperty("DetailTransactionPaiementNumerise")
    private DetailTransactionPaiementNumeriseReq detailTransPaiemtNumerise;

    @JsonProperty("EntetePaiementNumerise")
    private EntetePaiementNumeriseReq entetePaiementNumerise;

    @JsonProperty("InformationsTechniques")
    InformationsTechniquesReq informationsTechniques;

    @JsonProperty("MaintenanceOperation")
    MaintenanceOperationReq maintenanceOperation;

    @JsonProperty("identifiantMarchant")
    private String identifiantMarchant;

    @JsonProperty("identifiantTentative")
    private String identifiantTentative;

    @JsonProperty("indicateurModeTest")
    private Boolean indicateurModeTest;

    @JsonProperty("message")
    private String message;

    @JsonProperty("statut")
    private String statut;

}
