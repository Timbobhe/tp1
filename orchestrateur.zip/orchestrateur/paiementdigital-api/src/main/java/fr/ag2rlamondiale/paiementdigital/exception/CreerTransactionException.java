package fr.ag2rlamondiale.paiementdigital.exception;

import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.ErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.HeaderResp;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CreerTransactionException extends RuntimeException {

    private static final long serialVersionUID = 17511293040221245L;

    public static final String INVALID_PARAMETER = "Le paramètre ne peut être null!";

    public static final String BODY_RESPONSE_NULL = "CreerPaiementDigitalResponseDto body est null";

    public static final String ERROR_STATE = "retour erreur de la PFS";

    private HttpStatus httpStatus;

    private CreerTransaPaimtDigiRootResp response;

    public CreerTransactionException(HttpStatus httpStatus, String message) {
        super(message);
        this.httpStatus = httpStatus;
        response = CreerTransaPaimtDigiRootResp.builder()
                .etatCourant(EtatEnum.ERROR)
                .codeErreur(String.valueOf(httpStatus.value()))
                .messageErreur(message)
                .creationTransactionPaiementDigital(null)
                .build();
        log.error("Exception : {}", response);
    }

    public CreerTransactionException(ResponseEntity<CreerPaimtDigiRootResp> creerPaimtRootResp) {
        httpStatus = creerPaimtRootResp.getStatusCode();
        HeaderResp header = creerPaimtRootResp.getBody().getResponse().getHeader();
        ErrorResp error = funcError(header);

        response = CreerTransaPaimtDigiRootResp
                .builder()
                .etatCourant(EtatEnum.ERROR)
                .codeErreur(error.getErrorCode())
                .messageErreur(error.getErrorMessage())
                .creationTransactionPaiementDigital(null)
                .build();

        log.error("Exception : {}", response);
    }

    private ErrorResp funcError(HeaderResp header) {
        return CollectionUtils.isEmpty(header.getFuncError()) ? header.getTechError().get(0) : header.getFuncError().get(0);
    }

}
