package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseCalculFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class ResponseChildsFacadeImpl implements IResponseChildsFacade {

    @Autowired
    private IResponseCalculFacade calculFacade;

    @Autowired
    private IResponseBuilderFacade builderFacade;

    @Override
    public RecupParamPlfdFreqResp plafondsParFrequences(Plafond plafond, List<Float> montantsCaptured) {

        float montantMaxdispoClient = calculFacade.montantMaxDispoClient(plafond.getMontantMaximum(), montantsCaptured);
        int nombreMaxDispoClient = calculFacade.nombreMaxDispoClient(plafond.getNombreMaximumPaiement(), montantsCaptured);

        return builderFacade.build(plafond, montantMaxdispoClient, nombreMaxDispoClient);
    }

    @Override
    public RecupParamPeriMethPaimtResp perimetreMethodePaiement(String methode, Set<RecupParamPlfdFreqResp> plafonds) {

        float minMontantDispoClient = calculFacade.minMontantDispoClient(plafonds);
        String frequenceMinMontantDispoClient = calculFacade.frequenceMinMontantDispoClient(plafonds);
        int minNombrePaiementDisponible = calculFacade.minNombrePaiementDisponible(plafonds);
        String frequenceNombrePaiementDisponible = calculFacade.frequenceNombrePaiementDisponible(plafonds);

        return builderFacade.build(methode, minMontantDispoClient,
                frequenceMinMontantDispoClient, minNombrePaiementDisponible,
                frequenceNombrePaiementDisponible, plafonds);
    }

    @Override
    public RecupParamPeriMethPaimtResp getFinalResult(String methode, Set<RecupParamPlfdFreqResp> plafonds) {
        return perimetreMethodePaiement(methode,plafonds);
    }

    @Override
    public RecupParamProfResp parametresProfils(Set<RecupParamPeriMethPaimtResp> methodes) {

        float maxDesMontantsDispo = calculFacade.maxDesMontantsDispo(methodes);
        String methodeMaxDesMontantsDispo = calculFacade.methodeMaxDesMontantsDispo(methodes, maxDesMontantsDispo);
        int maxDesNombresDePaiementDispo = calculFacade.maxDesNombresDePaiementDispo(methodes);
        String methodeMaxDesNombresDePaiementDispo = calculFacade.methodeMaxDesNombresDePaiementDispo(methodes, maxDesNombresDePaiementDispo);

        return builderFacade.build(maxDesMontantsDispo, methodeMaxDesMontantsDispo,
                maxDesNombresDePaiementDispo, methodeMaxDesNombresDePaiementDispo,
                methodes);
    }

    @Override
    public RecupParamRootResp recupererParametragesLab(RecupParamProfResp parametre, Set<ExclusionBanqueDto> exclusions, Set<InclusionPaysDto> inclusions) {
        log.info("Renvoie de la réponse");
        return builderFacade.build(parametre, exclusions, inclusions);
    }
}
