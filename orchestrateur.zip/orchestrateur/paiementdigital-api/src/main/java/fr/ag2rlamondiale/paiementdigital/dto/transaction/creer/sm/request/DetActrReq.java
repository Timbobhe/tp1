package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.type.RolePersonneEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetActrReq {

    private RolePersonneEnum codeRole;

    private List<IdPersDansSiloReq> idPersDansSilo;

    @JsonProperty("InfoPP")
    private InfoPPReq infoPP;

    @JsonProperty("InfoPM")
    private InfoPMReq infoPM;

}