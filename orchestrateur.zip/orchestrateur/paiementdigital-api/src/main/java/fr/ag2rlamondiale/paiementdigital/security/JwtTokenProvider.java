package fr.ag2rlamondiale.paiementdigital.security;

import fr.ag2rlamondiale.paiementdigital.config.ApiSecurityConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.PfsParametersConstantes;
import fr.ag2rlamondiale.paiementdigital.constantes.SecurityConstantes;
import fr.ag2rlamondiale.paiementdigital.exception.JwtSecurityException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Date;
import java.util.Objects;

@Slf4j
@Component
public class JwtTokenProvider {

    @Autowired
    private ApiSecurityConfig config;

    private Claims claims;

    public Authentication getAuthentication() {
        log.debug("Sauvegarde des informations concernant le Claim JWT dans le contexte de sécurité Spring");
        return new UsernamePasswordAuthenticationToken(this.claims, null, null);
    }

    public String resolveToken(HttpServletRequest req) {
        log.info("Résolution du TOKEN JWT");
        String bearerToken = req.getHeader(SecurityConstantes.AUTHORIZATION);
        log.debug("bearerToken {}", bearerToken);

        if (bearerToken != null && bearerToken.startsWith(SecurityConstantes.BEARER_PREFIX)) {
            String token = bearerToken.substring(7);
            log.debug("token {}", token);
            return token;
        }
        throw new JwtSecurityException("Anomalie dans le Bearer");
    }

    public boolean validateToken(String token) {
        log.info("Vérification du TOKEN JWT");
        try {
            this.claims = getClaims(token);
            Date now = new Date();

            if (!Objects.isNull(claims.getSubject())
                    && !Objects.isNull(claims.getAudience())
                    && !Objects.isNull(claims.getIssuer())
                    && !Objects.isNull(claims.getIssuedAt())
                    && !Objects.isNull(claims.getExpiration())
                    && PfsParametersConstantes.CODE_APPLI_BO_PMT_DIGI.equalsIgnoreCase(claims.getAudience())
                    && PfsParametersConstantes.CODE_APPLI_PFS.equalsIgnoreCase(claims.getIssuer())
                    && now.before(claims.getExpiration())
            ) {
                return true;
            }

            throw new JwtSecurityException("Une ou plusieures entrée du token sont invalides");
        } catch (JwtException | IllegalArgumentException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new JwtSecurityException(e.getMessage());
        }
    }

    private Claims getClaims(String token) throws NoSuchAlgorithmException, InvalidKeySpecException {
        X509EncodedKeySpec keySpecPKCS8 = new X509EncodedKeySpec(Base64.getDecoder().decode(config.getPublicKey()));
        KeyFactory kf = KeyFactory.getInstance(SecurityConstantes.RSA);
        PublicKey key = kf.generatePublic(keySpecPKCS8);
        return Jwts.parser().setSigningKey(key).parseClaimsJws(token).getBody();
    }
}
