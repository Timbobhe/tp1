package fr.ag2rlamondiale.paiementdigital.dto.type;

/**
 * Les valeurs de l'enum acceptés par la PFS ne respectent pas le standard de nommage
 * Les seuls valeurs autorisées sont:
 * <p>
 * PAIEMENT
 * VERIFICATION
 * Authorization
 */
public enum EtatPaiementEnum {
    PAIEMENT,
    VERIFICATION,
    Authorization
}
