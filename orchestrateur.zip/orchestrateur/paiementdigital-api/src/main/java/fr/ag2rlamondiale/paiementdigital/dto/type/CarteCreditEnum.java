package fr.ag2rlamondiale.paiementdigital.dto.type;

public enum CarteCreditEnum {
    CB,
    VISA,
    MASTERCARD
}
