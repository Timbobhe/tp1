package fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier;

import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetMntPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetTransaPaimtNumResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDetMontantPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDetTransaPaimtNumResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDigiBisResp;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface IModifTransaPaimtDigiMapper {

    @Mapping(source = "orderId", target = "orderId")
    @Mapping(source = "detTransaPaimtNum.refTransaPaimtDigi", target = "idTransaction")
    @Mapping(source = "detTransaPaimtNum.typeOpeTransaPaimtDigi", target = "typeOperationTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.numAutionTransaPaimtDigi", target = "numeroAutorisationTransactionPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.instantCreatTransa", target = "instantCreationTransaction")
    @Mapping(source = "detTransaPaimtNum.instantMajTransa", target = "instantMajTransaction")
    @Mapping(source = "detTransaPaimtNum.instantAutionTransa", target = "instantAutorisationTransaction")
    @Mapping(source = "detTransaPaimtNum.mntAutionPaimtDigi", target = "montantAutorisationPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.mntTrsfPaimtDigi", target = "montantTransfertPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.mntRembsmPaimtDigi", target = "montantRemboursementPaiementDigital")
    @Mapping(source = "detTransaPaimtNum.mntCreditPaimtDigi", target = "montantCreditPaiementDigital")
    ModifTransaDetTransaPaimtNumResp toDetTransaPaimtNum(ModifPaimtDetTransaPaimtNumResp detTransaPaimtNum, String orderId);

    @Mapping(source = "codeDeviseVersement", target = "codeDeviseVersement")
    ModifTransaDetMntPaimtResp toDetMntPaimt(ModifPaimtDetMontantPaimtResp detMontantPaimtResp);

    @Mapping(source = "etat", target = "etatCourant")
    @Mapping(source = "modifPaimtDigiBisResp.stt", target = "status")
    @Mapping(source = "modifPaimtDigiBisResp.msg", target = "message")
    @Mapping(source = "modifPaimtDigiBisResp.idMarchand", target = "identifiantMarchand")
    ModifTransaResp toModifTransa(ModifPaimtDigiBisResp modifPaimtDigiBisResp, EtatEnum etat);

    @Mapping(source = "etat", target = "etatCourant")
    @Mapping(source = "status", target = "codeErreur")
    @Mapping(source = "message", target = "messageErreur")
    ModifTransaRootResp toModifTransaRoot(Historique historique);

}
