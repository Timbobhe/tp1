package fr.ag2rlamondiale.paiementdigital.business.transaction.creer.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.IEtatTransPaimtDigiFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.EtatTransaPaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.DetTransaPaimtNumeriseResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class EtatTransPaimtDigiFacadeImpl implements IEtatTransPaimtDigiFacade {

    @Override
    public EtatTransaPaimtDigiResp toEtatTransactionPaiementDigital(Paiement paiement, DetTransaPaimtNumeriseResp detTransaPaimtNumerise) {
        log.info("Création de la partie EtatTransaPaimtDigiResp de la réponse du SM");
        log.debug("Paiement {}", paiement);
        log.debug("DetTransaPaimtNumeriseResp {}", detTransaPaimtNumerise);

        Optional<Historique> historiqueAuthOrFail = paiement.getHistoriques().stream().filter(historique ->
                paiement.getEtatCourant().equals(historique.getEtat())
        ).findFirst();
        EtatTransaPaimtDigiResp result = EtatTransaPaimtDigiResp.builder()
                .etatCourant(paiement.getEtatCourant())
                .status(historiqueAuthOrFail.isPresent() ? historiqueAuthOrFail.get().getStatus() : null)
                .message(historiqueAuthOrFail.isPresent() ? historiqueAuthOrFail.get().getMessage() : null)
                .codeSitTransPaiemtDigi(detTransaPaimtNumerise.getCodeSitTransaPaimtDigi())
                .build();

        log.debug("EtatTransaPaimtDigiResp {}", result);
        return result;
    }
}
