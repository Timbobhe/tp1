package fr.ag2rlamondiale.paiementdigital.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.paiementdigital.dto.BoResponse;
import fr.ag2rlamondiale.paiementdigital.exception.JwtSecurityException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;

public class JwtTokenFilter extends OncePerRequestFilter {

    private JwtTokenProvider jwtTokenProvider;

    public JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            String token = jwtTokenProvider.resolveToken(request);
            if (!Objects.isNull(token) && jwtTokenProvider.validateToken(token)) {
                Authentication auth = jwtTokenProvider.getAuthentication();
                SecurityContextHolder.getContext().setAuthentication(auth);
            }
        } catch (JwtSecurityException e) {
            SecurityContextHolder.clearContext();
            HttpStatus httpStatus = HttpStatus.UNAUTHORIZED;
            ResponseEntity<BoResponse> errorResponse = ControllerUtils.buildResponse(request, e, httpStatus);
            String responseToSend = restResponseBytes(errorResponse);
            response.setHeader("Content-Type", "application/json;charset=UTF-8");
            response.setStatus(httpStatus.value());
            response.getWriter().write(responseToSend);
            response.flushBuffer();
            return;
        }

        filterChain.doFilter(request, response);
    }

    protected String restResponseBytes(ResponseEntity<BoResponse> error) throws IOException {
        String serialized = (new ObjectMapper()).writeValueAsString(error);
        return serialized;
    }

}
