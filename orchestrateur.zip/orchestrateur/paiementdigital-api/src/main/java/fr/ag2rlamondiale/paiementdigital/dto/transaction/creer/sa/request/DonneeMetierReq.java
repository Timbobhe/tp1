package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DonneeMetierReq implements Serializable {

    private static final long serialVersionUID = -6946430809006092496L;

    private String typeDonnee;

    private String valeurDonnee;
}
