package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecupParamPeriReq {

    @Size(max = 3, message = "Le champs 'structureJuridique' doit faire 3 caractères maximum.")
    private String structureJuridique;

    @Size(max = 3, message = "Le champs 'filiale' doit faire entre 3 caractères maximum.")
    private String filiale;

    @Size(max = 30, message = "Le champs 'produit' doit faire 30 caractères maximum.")
    private String produit;

    @Size(max = 30, message = "Le champs 'contratDeReference' doit faire 30 caractères maximum.")
    private String contratDeReference;

    @Size(max = 30, message = "Le champs 'contrat' doit faire 30 caractères maximum.")
    private String contrat;

    private boolean tiersPayeur;
}
