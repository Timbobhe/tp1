package fr.ag2rlamondiale.paiementdigital.mapper.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.domain.CustomData;
import fr.ag2rlamondiale.paiementdigital.domain.DonneeMetier;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.*;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.Set;

@Mapper
public interface ICreerTransaRespMapper {

    @Mapping(source = "entetePaimtNumerise.codeModePaimt", target = "methodeDePaiement")
    @Mapping(source = "paiement.orderId", target = "orderId")
    @Mapping(source = "entetePaimtNumerise.codeValECI", target = "codeValeurECI")
    @Mapping(source = "entetePaimtNumerise.numTentvPaimtDigi", target = "numTentativePaiemtDigi")
    EnteteTransaPaimtDigiResp toEnteteTransactionPaiementDigital(Paiement paiement, EntetePaimtNumeriseResp entetePaimtNumerise);

    @Mapping(source = "paiement.idTransaction", target = "idTransaction")
    @Mapping(source = "detTransaPaimtNumerise.numAutionTransaPaimtNumerise", target = "numAutoTransPaiemtNum")
    @Mapping(source = "detTransaPaimtNumerise.instantAutionTransa", target = "instantAutoTrans")
    @Mapping(source = "detTransaPaimtNumerise.instantCreatTransa", target = "instantCreationTrans")
    @Mapping(source = "detTransaPaimtNumerise.instantModifTransa", target = "instantModifTrans")
    @Mapping(source = "detTransaPaimtNumerise.mntTransaPaimtDigi", target = "mntTransPaiemtDigi")
    @Mapping(source = "detTransaPaimtNumerise.codeDevMntTransaPaimtDigi", target = "codeDevMntTransPaiemtDigi")
    DetailTransaPaimtDigiResp toDetailTransactionPaiementDigital(Paiement paiement, DetTransaPaimtNumeriseResp detTransaPaimtNumerise);

    @Mapping(source = "paiement.idUniqueClient", target = "idUniqueClient")
    @Mapping(source = "paiement.tiersPayeur", target = "tiersPayeur")
    @Mapping(source = "paiement.typeClient", target = "typeClient")
    @Mapping(source = "paiement.natureClient", target = "natureClient")
    @Mapping(source = "paiement.paysResidence", target = "paysResidence")
    @Mapping(source = "paiement.paysResidenceFiscale", target = "paysResidenceFiscale")
    @Mapping(source = "emails.libEmail", target = "libelleEmail")
    DetailActeursResp toDetailActeurs(Paiement paiement, EmailsResp emails);

    @Mapping(source = "paiement.paysMethode", target = "paysMethode")
    @Mapping(source = "paiement.banque", target = "banque")
    @Mapping(source = "paiement.nomPayeur", target = "nomPayeur")
    @Mapping(source = "detCartePaimt.idChiffreMoyenPaimt", target = "identifiantChiffreMoyenPaiement")
    @Mapping(source = "detCartePaimt.numCarte", target = "numeroCarte")
    @Mapping(source = "detCartePaimt.anneeExpiration", target = "anneeExpiration")
    @Mapping(source = "detCartePaimt.moisExpiration", target = "moisExpiration")
    DetailCartePaimtResp toDetailCartePaiement(Paiement paiement, DetCartePaimtResp detCartePaimt);

    @Mapping(source = "paiement.montant", target = "mntTTC")
    @Mapping(source = "detMntPaimt.mntFraisLivr", target = "mntFraisLivr")
    @Mapping(source = "detMntPaimt.mntTaxes", target = "mntTaxes")
    @Mapping(source = "detMntPaimt.codeDevVersm", target = "codeDevVers")
    DetailMontantPaimtResp toDetailMontantPaiement(Paiement paiement, DetMntPaimtResp detMntPaimt);

    @Mapping(source = "metier", target = "metier")
    @Mapping(source = "codeApplication", target = "codeApplication")
    @Mapping(source = "evenementMetier", target = "evenementMetier")
    @Mapping(source = "structureJuridique", target = "structureJuridique")
    @Mapping(source = "filiale", target = "filiale")
    @Mapping(source = "produit", target = "produit")
    @Mapping(source = "contrat", target = "contrat")
    @Mapping(source = "contratDeReference", target = "contratDeReference")
    DetailPerimetreMetierResp toDetailPerimetreMetier(Paiement paiement);

    @Mapping(source = "adrIP", target = "adresseIP")
    @Mapping(source = "ipCountry", target = "ipCountry")
    @Mapping(source = "deviceId", target = "deviceId")
    InformationsTechniquesResp toInformationsTechniques(InfoTechResp infoTech);

    Set<CustomDataResp> toCustomDataResp(Set<CustomData> customData);

    Set<DonneeMetierResp> toDonneeMetierResp(Set<DonneeMetier> donneeMetier);

}
