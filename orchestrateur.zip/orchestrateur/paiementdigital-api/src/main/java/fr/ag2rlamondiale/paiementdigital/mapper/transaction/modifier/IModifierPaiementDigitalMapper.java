package fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaDetMntPaimtReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaDetTransaPaimtNumReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request.ModifTransaInfosTechReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtDetMontantPaimtReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtDetTransaPaimtNumReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request.ModifPaimtInfoTechReq;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper
public interface IModifierPaiementDigitalMapper {

    @Mapping(source = "idTransaction", target = "refTransaPaimtDigi")
    @Mapping(source = "typeOperationTransactionPaiementDigital", target = "typeOpeTransaPaimtDigi")
    ModifPaimtDetTransaPaimtNumReq toDetTransaPaimtNumerise(ModifTransaDetTransaPaimtNumReq detailTransactionPaiementNumerise);

    @Mapping(source = "montantTTC", target = "montantTTC")
    @Mapping(source = "codeDeviseVersement", target = "codeDevVersm")
    ModifPaimtDetMontantPaimtReq toDetMontantPaimt(ModifTransaDetMntPaimtReq detailMontantPaiement);

    @Mapping(source = "referenceOperationPaiementDigital", target = "refOpePaimtDigi")
    @Mapping(source = "referenceSousTransactionPaiementDigital", target = "refSsTransaPaimtDigi")
    @Mapping(source = "origineTransaction", target = "oriTransa")
    ModifPaimtInfoTechReq toInfoTech(ModifTransaInfosTechReq informationsTechniques);
}
