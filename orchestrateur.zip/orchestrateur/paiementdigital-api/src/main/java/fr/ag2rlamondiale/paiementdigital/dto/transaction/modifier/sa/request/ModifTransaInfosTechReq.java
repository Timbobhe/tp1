package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ModifTransaInfosTechReq {

    private String referenceOperationPaiementDigital;

    private String referenceSousTransactionPaiementDigital;

    private String origineTransaction;
}
