package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ModifPaimtInfoTechReq {

    private String refOpePaimtDigi;

    private String refSsTransaPaimtDigi;

    private String oriTransa;
}
