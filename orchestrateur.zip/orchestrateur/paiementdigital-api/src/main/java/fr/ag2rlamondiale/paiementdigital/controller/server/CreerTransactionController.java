package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IEtatPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IGestionTokenFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerPaimtDigiReqBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.creer.ICreerTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.config.PfsPropertyConfig;
import fr.ag2rlamondiale.paiementdigital.controller.client.CreerPaiementDigitalController;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.PaimtDigiResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.time.Instant;
import java.util.Objects;

@Validated
@RestController
@RequestMapping(value = "/api/transaction", produces = MediaType.APPLICATION_JSON_VALUE)
@Slf4j
public class CreerTransactionController {

    @Autowired
    private PfsPropertyConfig config;

    @Autowired
    private ICreerTransaRespBuilderFacade transactionFacade;

    @Autowired
    private IEtatPaiementFacade etatPaiementFacade;

    @Autowired
    private ICreerPaimtDigiReqBuilderFacade creerPaimtDigiBuildFacade;

    @Autowired
    private IGestionTokenFacade gestionTokenFacade;

    @Autowired
    private CreerPaiementDigitalController controller;

    @PostMapping("/create")
    public ResponseEntity<CreerTransaPaimtDigiRootResp> insertionPaiementDigital(@Valid @RequestBody CreerTransaPaimtDigiRootReq request) {
        long startTime = Instant.now().toEpochMilli();
        log.info("Demande d'insertion d'une transaction");
        log.debug("CreerTransaPaimtDigiRootReq {}", request);

        try {
            Paiement paiement = etatPaiementFacade.create(request);

            paiement = etatPaiementFacade.authorization(paiement);

            String uriWithParams = gestionTokenFacade.getUriWithParams(config.getCreatePaiementUrl(), paiement.getStructureJuridique() ,paiement.getFiliale());

            CreerPaimtDigiRootReq creerPaimtDigiReq = creerPaimtDigiBuildFacade.build(request, paiement);

            ResponseEntity<CreerPaimtDigiRootResp> smResponse = controller.creerPaiementDigital(uriWithParams, creerPaimtDigiReq);

            logSmResponse(smResponse);

            CreerTransaPaimtDigiRootResp saResponse = buildCreerTransaPaimtDigiRootResp(request, paiement, smResponse);

            ResponseEntity<CreerTransaPaimtDigiRootResp> response = new ResponseEntity<>(saResponse, ControllerUtils.getHttpHeaders(), smResponse.getStatusCode());
            log.debug("ResponseEntity<CreerTransaPaimtDigiRootResp> {}", response);
            return response;

        } catch (CreerTransactionException e) {
            ResponseEntity<CreerTransaPaimtDigiRootResp> response = new ResponseEntity<>(e.getResponse(), e.getHttpStatus());
            log.error("ResponseEntity<CreerTransaPaimtDigiRootResp> {}", response);
            return response;
        } finally {
            long endTime = Instant.now().toEpochMilli();
            long timeElapsed = endTime - startTime;
            log.info("Temps d'execution pour la création de la transaction : {} ms", timeElapsed);
        }
    }

    private void logSmResponse(ResponseEntity<CreerPaimtDigiRootResp> smResponse) {
        if(smResponse != null && smResponse.getBody().getResponse().getBody() != null && smResponse.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi() != null){
            PaimtDigiResp paiementDigiResponse = smResponse.getBody().getResponse().getBody().getCreerPaimtDigiResponse().getCreerPaimtDigiFunc().getCreerPaimtDigi().getPaimtDigi();
            log.info("Réponse retournée par la PFS : code du retour API = {}, idMarchand = {}," +
                            " idDemPaimt = {}, refTransPaimtDigi = {}, libSitTransaPaimtDigi = {}," +
                            "codeTechSitTransaPaimtDigi = {}, codeSitTransaPaimtDigi = {}, msg = {}, stt = {}",
                    smResponse.getStatusCodeValue(), paiementDigiResponse.getIdMarchand(),
                    paiementDigiResponse.getEntetePaimtNumerise().getIdDemPaimt(), paiementDigiResponse.getDetTransaPaimtNumerise().getRefTransPaimtDigi(),
                    paiementDigiResponse.getDetTransaPaimtNumerise().getLibSitTransaPaimtDigi(), paiementDigiResponse.getDetTransaPaimtNumerise().getCodeTechSitTransaPaimtDigi(),
                    paiementDigiResponse.getDetTransaPaimtNumerise().getCodeSitTransaPaimtDigi(), paiementDigiResponse.getMsg(), paiementDigiResponse.getStt());


        }
    }

    private CreerTransaPaimtDigiRootResp buildCreerTransaPaimtDigiRootResp(CreerTransaPaimtDigiRootReq request, Paiement paiement, ResponseEntity<CreerPaimtDigiRootResp> smResponse) {
        CreerTransaPaimtDigiRootResp saResponse = transactionFacade.build(paiement, smResponse);

        //codeSilo est en entrée de la request en paramètre et doit être renvoyée dans la response (cf. metier)
        if (!Objects.isNull(saResponse.getCreationTransactionPaiementDigital())) {
            String codeSilo = request.getDetailPerimetreMetier().getCodeSilo();
            saResponse.getCreationTransactionPaiementDigital().getDetailPerimetreMetier().setCodeSilo(codeSilo);
        }

        return saResponse;
    }
}
