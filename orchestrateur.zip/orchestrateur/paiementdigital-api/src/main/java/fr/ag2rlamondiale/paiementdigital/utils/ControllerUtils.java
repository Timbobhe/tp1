package fr.ag2rlamondiale.paiementdigital.utils;

import fr.ag2rlamondiale.paiementdigital.constantes.ControllerConstantes;
import fr.ag2rlamondiale.paiementdigital.dto.BoResponse;
import fr.ag2rlamondiale.paiementdigital.dto.MessageDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response.CreerTransaPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;

@Slf4j
public final class ControllerUtils {

    private ControllerUtils() {
    }

    public static HttpHeaders getHttpHeaders() {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return httpHeaders;
    }

    public static void log(HttpStatus status, String message) {
        log.error("Status : {} - Message : {}", status.toString(), message);
    }

    public static ResponseEntity<BoResponse> buildResponse(HttpServletRequest req, Exception exception, HttpStatus httpStatus) {
        BoResponse response = null;
        String uri = req.getRequestURI();
        int code = httpStatus.value();
        String message = exception.getMessage();

        if (ControllerConstantes.CREER_TRANSACTION_URI.equalsIgnoreCase(uri)) {
            response = CreerTransaPaimtDigiRootResp.sendFailure(code, message);
        } else if (ControllerConstantes.MODIFIER_TRANSACTION_URI.equalsIgnoreCase(uri)) {
            response = ModifTransaRootResp.sendFailure(code, message);
        } else if (ControllerConstantes.PARAMETRAGE_URI.equalsIgnoreCase(uri)) {
            response = RecupParamRootResp.sendFailure(code, message);
        } else {

            response = MessageDto.sendFailure(message, httpStatus);
        }

        return new ResponseEntity<>(response, httpStatus);

    }

}
