package fr.ag2rlamondiale.paiementdigital.business.parametrage;

import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.InclusionPaysDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamProfResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamRootResp;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
public interface IResponseChildsFacade {

    RecupParamPlfdFreqResp plafondsParFrequences(Plafond plafond, List<Float> montantsCaptured);

    RecupParamPeriMethPaimtResp perimetreMethodePaiement(String methode, Set<RecupParamPlfdFreqResp> plafonds);

    RecupParamPeriMethPaimtResp getFinalResult(String methode, Set<RecupParamPlfdFreqResp> plafonds);

    RecupParamProfResp parametresProfils(Set<RecupParamPeriMethPaimtResp> methodes);

    RecupParamRootResp recupererParametragesLab(RecupParamProfResp parametre,
                                                Set<ExclusionBanqueDto> exclusions,
                                                Set<InclusionPaysDto> inclusions);
}
