package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class RecupParamPlfdFreqResp implements Serializable {

    private static final long serialVersionUID = -8801707057879327880L;

    private String typeFrequence;

    private float montantMin;

    private float montantMax;

    private int nombreMax;

    private float montantMaxdispoClient;

    private int nombreMaxDispoClient;

}
