package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetailSEPAReq {

    private String codeIBAN;

    private String codeBIC;

    private String identifiantRUM;

    private boolean indicateurAccordMandatSEPA;

}
