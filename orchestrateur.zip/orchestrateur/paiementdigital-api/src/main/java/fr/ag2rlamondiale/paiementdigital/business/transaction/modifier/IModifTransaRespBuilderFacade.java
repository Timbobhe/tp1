package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface IModifTransaRespBuilderFacade {

    ModifTransaRootResp build(ResponseEntity<ModifPaimtRootResp> responseEntity, Paiement paiement);

}
