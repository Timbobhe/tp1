package fr.ag2rlamondiale.paiementdigital.constantes;

public final class HipayConstantes {

    private HipayConstantes() {
    }

    public static final String CPL = "CPL";

    public static final String ANN = "ANN";

    public static final String ATT = "ATT";

    public static final String TFR = "TFR";

    public static final String AUTHORIZED = "Authorized";

    public static final String STT_CODE_AUTHORIZED_OK = "116";

    public static final String CAPTURED = "Captured";

    public static final String OPE_TRANSA_CAPTURE = "capture";

    public static final String OPE_TRANSA_REFUND = "refund";

    public static final String OPE_TRANSA_CANCEL = "cancel";

    public static final String OPE_TRANSA_ACCEPT_CHALLENGE = "acceptChallenge";

    public static final String OPE_TRANSA_DENY_CHALLENGE = "denyChallenge";

    public static final String OPE_TRANSA_FINALIZE = "finalize";

    public static final String STT_CODE_AUTHENTIFICATION_ECHOUEE = "109";

    public static final String STT_CODE_BLOQUED = "110";

    public static final String STT_CODE_DENIED = "111";

    public static final String STT_CODE_AUTORISED_ATTENTE = "112";

    public static final String STT_CODE_REFUSED = "113";

    public static final String STT_CODE_PERIME = "114";

    public static final String STT_CODE_ANNULE = "115";


    public static final String  STT_CODE_CAPTURE_DEMANDEE = "117";

    public static final String STT_CODE_CAPTURED_OK = "118";

    public static final String  STT_CODE_PARTIELLEMENT_CAPTURE = "119";

    public static final String  STT_CODE_REMBOURSEMENT_DEMANDE = "124";

    public static final String  STT_CODE_REMBOURSE = "125";

    public static final String  STT_CODE_PARTIELLEMENT_REMBOURSE = "126";

    public static final String  STT_CODE_IMPAYE = "129";

    public static final String  STT_CODE_DISPUTE_LOST = "134";

    public static final String  STT_CODE_AUTORISATION_DEMANDEE = "142";

    public static final String  STT_CODE_AUTHORIZATION_CANCELLED = "143";

    public static final String  STT_CODE_REFERENCE_RENDERED = "144";

    public static final String  STT_CODE_REMBOURSEMENT_REFUSE = "165";

    public static final String  STT_CODE_CARDHOLDER_CREDIT = "166";

    public static final String  STT_CODE_REPORTED_FRAUD = "167";

    public static final String  STT_CODE_DEBITED = "168";

    public static final String  STT_CODE_CREDIT_REQUESTED = "169";

    public static final String  STT_CODE_IN_PROGRESS = "172";

    public static final String STT_CODE_CAPTURE_FAIL = "173";

    public static final String  STT_CODE_AWAITING_TERMINAL = "174";

    public static final String  STT_CODE_AUTHORIZATION_CANCELLATION_REQUESTED = "175";

    public static final String  STT_CODE_SOFT_DECLINED = "178";

    public static final String STT_CODE_PENDING = "200";

    public static final String STT_MSG_CAPTURE_REFUSED = "Capture refused";
}
