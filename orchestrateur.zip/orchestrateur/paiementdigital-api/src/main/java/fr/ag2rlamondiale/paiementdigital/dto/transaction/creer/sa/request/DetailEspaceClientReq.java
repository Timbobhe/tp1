package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

import static fr.ag2rlamondiale.paiementdigital.constantes.DateConstantes.YYYY_DD_MM_FORMAT;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetailEspaceClientReq {

    private String identifiantExtranet;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateCreationEspaceClient;

    private int dureeDepuisCreation;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateModificationEspaceClient;

    private int dureeDepuisModification;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateModificationMotDePasseEspaceClient;

    private int dureeDepuisModificationMotDePasse;

    private int nombreEssaiAjoutCarte24H;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date dateEnregistrementCartePaiement;

    private int dureeDepuisEnregistrementCartePaiement;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = YYYY_DD_MM_FORMAT)
    private Date datePremiereUtilisationAdresseLivraison;

    private int dureeDepuisPremiereUtilisationAdresseLivraison;

    private int nombreCommandeAnnee;

    private int nombreCommandeDernierSixMois;

    private int nombreCommande24H;

    private boolean indicateurActiviteSuspicieuse;

    private boolean indicateurNomsIdentiques;
}
