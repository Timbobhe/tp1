package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;

import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import fr.ag2rlamondiale.paiementdigital.dto.type.EtatPaiementEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetTransaPaimtNumeriseReq {

    private EtatPaiementEnum codeTypeTransaPaimtDigi;

    private DeviseEnum codeDevMntTransaPaimtDigi;

    private String codeCatCmd;

}
