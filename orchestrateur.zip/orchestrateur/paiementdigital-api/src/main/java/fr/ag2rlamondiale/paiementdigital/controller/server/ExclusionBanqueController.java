/*
 * Cree le 19 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain.ExclusionBanqueDto;
import fr.ag2rlamondiale.paiementdigital.mapper.parametrage.IExclusionBanqueMapper;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;

@Validated
@RestController
@RequestMapping(value = "/api/banques", produces = MediaType.APPLICATION_JSON_VALUE)
public class ExclusionBanqueController {

    @Autowired
    private IExclusionBanqueFacade facade;

    @Autowired
    private IExclusionBanqueMapper mapper;

    @GetMapping("/{banque}")
    public ResponseEntity<ExclusionBanqueDto> find(@PathVariable String banque) {
        ExclusionBanqueDto response = mapper.toBanqueDto(facade.findById(banque));
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<Set<ExclusionBanqueDto>> findAll() {
        Set<ExclusionBanqueDto> response = mapper.toDtoSet(facade.findAll());
        return new ResponseEntity<>(response, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

}
