package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaimtDigiReq {

    @JsonProperty("EntetePaimtNumerise")
    private EntetePaimtNumeriseReq entetePaimtNumerise;

    @JsonProperty("DetActr")
    private DetActrReq detActr;

    @JsonProperty("DetEspCli")
    private DetEspCliReq detEspCli;

    @JsonProperty("DetCartePaimt")
    private DetCartePaimtReq detCartePaimt;

    @JsonProperty("DetSepa")
    private DetSepaReq detSepa;

    @JsonProperty("DetPorteMonnaieElec")
    private DetPorteMonnaieElecReq detPorteMonnaieElec;

    @JsonProperty("DetMntPaimt")
    private DetMntPaimtReq detMntPaimt;

    @JsonProperty("DetTransaPaimtNumerise")
    private DetTransaPaimtNumeriseReq detTransaPaimtNumerise;

    @JsonProperty("DetPdt")
    private DetPdtReq detPdt;

    @JsonProperty("Livr")
    private LivrReq livr;

    @JsonProperty("InfoTech")
    private InfoTechReq infoTech;

    @JsonProperty("Redirect")
    private RedirectReq redirect;

    @JsonProperty("msg")
    private String msg;

    @JsonProperty("stt")
    private String stt;
}