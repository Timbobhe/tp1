package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class
CustomDataResp implements Serializable {

    private static final long serialVersionUID = 5992298538586719396L;

    private int ordre;

    private String cdata;
}
