package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.response;

import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DetailActeursResp implements Serializable {

    private static final long serialVersionUID = 1836474532556010503L;

    private String idUniqueClient;

    private String tiersPayeur;

    private NatureClientEnum natureClient;

    private TypeClientEnum typeClient;

    private String libelleEmail;

    private String paysResidence;

    private String paysResidenceFiscale;
}
