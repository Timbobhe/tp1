package fr.ag2rlamondiale.paiementdigital.business.transaction.creer;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request.CreerTransaPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.DetActrReq;
import org.springframework.stereotype.Service;

@Service
public interface IDetailActeurFacade {

    DetActrReq detailActeurs(CreerTransaPaimtDigiRootReq request);


}
