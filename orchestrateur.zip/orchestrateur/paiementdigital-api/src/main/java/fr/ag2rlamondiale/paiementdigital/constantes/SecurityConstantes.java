package fr.ag2rlamondiale.paiementdigital.constantes;

public final class SecurityConstantes {

    private SecurityConstantes() {
    }

    public static final String AUTHORIZATION = "Authorization";

    public static final String BEARER_PREFIX = "Bearer ";

    public static final String PRIVATE_KEY_PREFIX = "-----BEGIN PRIVATE KEY-----";

    public static final String PRIVATE_KEY_SUFFIX = "-----END PRIVATE KEY-----";

    public static final String RSA = "RSA";

}
