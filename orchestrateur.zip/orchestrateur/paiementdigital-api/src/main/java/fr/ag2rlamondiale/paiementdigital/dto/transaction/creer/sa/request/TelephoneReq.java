package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import fr.ag2rlamondiale.paiementdigital.dto.type.TelephoneEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TelephoneReq {

    private TelephoneEnum codeTypeNumeroTelephone;

    private String numeroTelephone;
}
