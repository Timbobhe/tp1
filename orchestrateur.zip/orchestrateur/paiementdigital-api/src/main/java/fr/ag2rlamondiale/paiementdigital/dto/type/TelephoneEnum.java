package fr.ag2rlamondiale.paiementdigital.dto.type;

public enum TelephoneEnum {
    TPO,//Mobile
    TPE,//Domicile
    TPR//Professionnel
}
