package fr.ag2rlamondiale.paiementdigital.exception;

public class CalculEligibiliteException extends RuntimeException {

    private static final long serialVersionUID = -3183090495709355702L;
    public static final String INCORRECT_PARAMETERS = "Les paramètres fournis sont incorrectes (null, montants négatifs, etc...).";

    public CalculEligibiliteException(String message) {
        super(message);
    }

}
