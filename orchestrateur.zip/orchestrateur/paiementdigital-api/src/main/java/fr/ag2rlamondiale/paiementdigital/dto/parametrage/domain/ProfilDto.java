package fr.ag2rlamondiale.paiementdigital.dto.parametrage.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProfilDto {

    private Long id;

    private String metier;

    private String codeApplication;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private TypeEvenementMetier evenementMetier;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private NatureClientEnum natureClient;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private TypeClientEnum typeClient;

    private Set<PerimetreDto> perimetres;

    public ProfilDto copy(ProfilDto profil) {
        return ProfilDto.builder()
                .metier(profil.getMetier())
                .codeApplication(profil.getCodeApplication())
                .evenementMetier(profil.getEvenementMetier())
                .natureClient(profil.getNatureClient())
                .typeClient(profil.getTypeClient())
                .perimetres(profil.getPerimetres())
                .build();
    }
}
