package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.type.CarteCreditEnum;
import lombok.Data;

import java.io.Serializable;

@Data
public class DetCartePaimtResp implements Serializable {

    private static final long serialVersionUID = 1695668169021691288L;

    private String idChiffreMoyenPaimt;

    private String numCarte;

    private CarteCreditEnum codeTypeCarte;

    private String anneeExpiration;

    private String moisExpiration;

    @JsonProperty("TitlCartePaimt")
    private String titlCartePaimt;

    private String libEtabBanc;

    private String codePaysEtabBanc;
}
