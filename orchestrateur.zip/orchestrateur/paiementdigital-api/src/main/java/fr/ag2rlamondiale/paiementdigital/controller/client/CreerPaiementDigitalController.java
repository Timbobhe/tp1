package fr.ag2rlamondiale.paiementdigital.controller.client;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.CreerPaimtDigiRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.CreerPaiementDigitalException;
import fr.ag2rlamondiale.paiementdigital.exception.RestTemplateException;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import fr.ag2rlamondiale.paiementdigital.utils.JsonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.exception.CreerTransactionException.INVALID_PARAMETER;

@RestController
@Slf4j
public class CreerPaiementDigitalController {

    @Autowired
    private RestTemplate restTemplate;

    public ResponseEntity<CreerPaimtDigiRootResp> creerPaiementDigital(String uri, CreerPaimtDigiRootReq request) {
        log.info("Appel à la PFS pour le SM CreerPaiementDigital");
        log.debug("CreerPaimtDigiRootReq {}", request);
        log.debug("URI {}", uri);

        try {

            if (StringUtils.isEmpty(uri) || Objects.isNull(request))
                throw new CreerPaiementDigitalException(INVALID_PARAMETER);

            HttpEntity<CreerPaimtDigiRootReq> httpEntity = new HttpEntity<>(request, ControllerUtils.getHttpHeaders());

            return creerPaiement(uri, httpEntity);

        } catch (CreerPaiementDigitalException e) {
            ResponseEntity<CreerPaimtDigiRootResp> result = new ResponseEntity<>(e.getResponse(), e.getHttpStatus());
            log.error("Exception retournée par la PFS ou BO : {}", result);
            return result;
        }
    }

    private ResponseEntity<CreerPaimtDigiRootResp> creerPaiement(String uri, HttpEntity<CreerPaimtDigiRootReq> httpEntity) {
        try {
            ResponseEntity<CreerPaimtDigiRootResp> result = restTemplate.postForEntity(uri, httpEntity, CreerPaimtDigiRootResp.class);
            log.debug("Réponse retournée par la PFS : {}", result);
           return result;
        } catch (RestTemplateException e) {
            CreerPaimtDigiRootResp res= (CreerPaimtDigiRootResp) JsonUtils.stringToObject(e.getMessage(), CreerPaimtDigiRootResp.class);
            CreerPaiementDigitalException exception = new CreerPaiementDigitalException(e.getHttpStatus(), res);
            ResponseEntity<CreerPaimtDigiRootResp> result = new ResponseEntity<>(exception.getResponse(), exception.getHttpStatus());
            log.debug("Exception retournée par la PFS : {}", result);
            return result;
        }
    }

}
