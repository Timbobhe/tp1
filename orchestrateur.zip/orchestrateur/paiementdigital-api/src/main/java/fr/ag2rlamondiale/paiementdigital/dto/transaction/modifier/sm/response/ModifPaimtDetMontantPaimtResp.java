package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.type.DeviseEnum;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifPaimtDetMontantPaimtResp implements Serializable {

    private static final long serialVersionUID = -8268934719539546336L;

    @JsonProperty("codeDevVersm")
    private DeviseEnum codeDeviseVersement;
}
