package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePerimetresMethodesFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePlafonfsFrequencesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetrePlafond;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPeriMethPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.ParamLabException.PERIMETRE_METHODE_PAIEMENT;

@Service
@Slf4j
public class ResponsePerimetresMethodesFacadeImpl implements IResponsePerimetresMethodesFacade {

    @Autowired
    private IResponsePlafonfsFrequencesFacade plafonfsFrequencesFacade;

    @Autowired
    private IResponseChildsFacade childsFacade;

    @Override
    public Set<RecupParamPeriMethPaimtResp> getPerimetreMethodePaiementDtos(RecupParamRootReq pfsDto, Perimetre perimetre) {
        log.info("Géneration de la partie PerimetreMethodePaiementDto de la réponse.");
        log.debug("pfsDto = {}", pfsDto);
        log.debug("perimetre = {}", perimetre);
        Multimap<String, RecupParamPeriMethPaimtResp> result = ArrayListMultimap.create();
        Multimap<String, RecupParamPeriMethPaimtResp> duplicatedResults = ArrayListMultimap.create();

        Map<String, List<Plafond>> cartes = agregatePlafondsByCards(perimetre);

        Multimap<String, List<Plafond>> cardsWithSamePlafondProfile = checkCartesHavingSamePlafond(cartes);

        log.info("Géneration de la liste de Plafonds Par Frequence.");

        for (Map.Entry<String, List<Plafond>> entry : cartes.entrySet()) {

            PaiementDto pmt = buildPaiementDto(pfsDto, entry.getKey());

            boolean cardHasPlafondDuplication = cardsWithSamePlafondProfile.entries().stream().anyMatch(e -> e.getKey() == entry.getKey());

            if (!cardHasPlafondDuplication) {
                Set<RecupParamPlfdFreqResp> ppfs = plafonfsFrequencesFacade.getPlafondsParFrequencesDtos(pfsDto, entry.getValue(), pmt);
                result.put(entry.getKey(), childsFacade.perimetreMethodePaiement(entry.getKey(), ppfs));
            } else {
                Multimap<String, List<Plafond>> duplicatedCardProfile = getDuplicatedCardProfile(cardsWithSamePlafondProfile, entry.getKey());
                for (Map.Entry<String, List<Plafond>> duplicatedCardEntry : duplicatedCardProfile.entries()) {
                    if (!duplicatedCardEntry.getKey().equals(entry.getKey())) {
                        Set<RecupParamPlfdFreqResp> ppfs = plafonfsFrequencesFacade.getPlafondsParFrequencesDtos(pfsDto, entry.getValue(), pmt);
                        RecupParamPeriMethPaimtResp calculatedPlafonds = childsFacade.perimetreMethodePaiement(duplicatedCardEntry.getKey(), ppfs);
                        duplicatedResults.put(duplicatedCardEntry.getKey(), calculatedPlafonds);
                    }
                }
                Set<RecupParamPlfdFreqResp> ppfs = plafonfsFrequencesFacade.getPlafondsParFrequencesDtos(pfsDto, entry.getValue(), pmt);
                RecupParamPeriMethPaimtResp calculatedPlafonds = childsFacade.perimetreMethodePaiement(entry.getKey(), ppfs);
                result.put(entry.getKey(), calculatedPlafonds);
            }
        }

        if (CollectionUtils.isEmpty(result.entries()))
            throw new ParamLabException(PERIMETRE_METHODE_PAIEMENT);

        if (duplicatedResults.size() > 1) {
            Multimap<String, Multimap<String,Multimap<Float, Integer>>> montantsDupliques = ArrayListMultimap.create();
            duplicatedResults.entries().stream().forEach(duplicatedResult ->
                    montantsDupliques.put(duplicatedResult.getValue().getMethodeDePaiement(), getMontant(duplicatedResult.getValue())));

            Multimap<String, Multimap<String, Multimap<Float, Integer>>> montantResult = getSumMontantByCard(montantsDupliques);
            updateResult(result.entries(), montantResult);
        }

        Set<RecupParamPeriMethPaimtResp> finalResult = new HashSet<>();
        result.entries().forEach(
                r -> {
                    RecupParamPeriMethPaimtResp recupParamPeriMethPaimtResp = childsFacade.getFinalResult(r.getValue().getMethodeDePaiement(), r.getValue().getPlafondsParFrequences());
                    finalResult.add(recupParamPeriMethPaimtResp);
                }
        );

        log.debug("getPerimetreMethodePaiementDtos result = {}", finalResult);
        return finalResult;
    }

    private Multimap<String, Multimap<String, Multimap<Float, Integer>>> getSumMontantByCard(Multimap<String, Multimap<String, Multimap<Float, Integer>>> montantsDupliques) {

        Multimap<String, Multimap<String, Multimap<Float, Integer>>> result = ArrayListMultimap.create();
        Multimap<String, Multimap<String, Multimap<Float, Integer>>> finalResult = ArrayListMultimap.create();

        montantsDupliques.entries().stream().forEach(montants -> {
          if(result.containsKey(montants.getKey())){
              result.get(montants.getKey()).stream().forEach( resultToUpdate ->
                  resultToUpdate.entries().forEach(resToUpdate ->
                      resToUpdate.getValue().entries().forEach(resToUpdateValue ->
                          montants.getValue().entries().stream().forEach(montant -> {
                              if(montant.getKey().equals(resToUpdate.getKey())){
                                  Multimap<Float, Integer> calcul = ArrayListMultimap.create();
                                  montant.getValue().entries().forEach( montantValue -> {
                                          calcul.put(montantValue.getKey()+resToUpdateValue.getKey(),montantValue.getValue()+ resToUpdateValue.getValue());
                                      Multimap<String, Multimap<Float, Integer>> test1 = ArrayListMultimap.create();
                                      test1.put(resToUpdate.getKey(),calcul);
                                      finalResult.put(montants.getKey(),test1);
                                      });
                              }
                          })
                      )
                  )
              );
            }else{
              Multimap<String,Multimap<Float, Integer>> res = ArrayListMultimap.create();
                montants.getValue().entries().stream().forEach(montant -> {
                    Multimap<Float, Integer> calcul = ArrayListMultimap.create();
                    montant.getValue().entries().forEach( m ->
                        calcul.put(m.getKey(), m.getValue())
                    );
                    res.put(montant.getKey(),calcul);
                });
              result.put(montants.getKey(), res);
            }
        });

        return getFinalResult(result, finalResult);
    }

    private Multimap<String, Multimap<String, Multimap<Float, Integer>>> getFinalResult(Multimap<String, Multimap<String, Multimap<Float, Integer>>> result, Multimap<String, Multimap<String, Multimap<Float, Integer>>> finalResult) {

        if(!finalResult.isEmpty()){
            result.entries().forEach( r -> {
                if(!finalResult.containsKey(r.getKey()))
                    finalResult.put(r.getKey(),r.getValue());
            });

            return  finalResult;
        }
        else return result;
    }

    private Collection<Map.Entry<String, RecupParamPeriMethPaimtResp>> updateResult(Collection<Map.Entry<String, RecupParamPeriMethPaimtResp>> result, Multimap<String,Multimap<String,Multimap<Float, Integer>>> montantsDupliques) {

        for (Map.Entry<String, RecupParamPeriMethPaimtResp> recupParamPeriMethPaimtResp : result) {
            for (Map.Entry<String, Multimap<String,Multimap<Float, Integer>>> mDupliques : montantsDupliques.entries())
                if (recupParamPeriMethPaimtResp.getValue().getMethodeDePaiement().equals(mDupliques.getKey())) {
                    recupParamPeriMethPaimtResp.getValue().getPlafondsParFrequences().forEach(
                            ppf -> {
                                if (ppf.getTypeFrequence().equals(TypeFrequenceEnum.MOIS_GLISSANT.name())) {
                                    updateMontantsMois(ppf, mDupliques);
                                } else if (ppf.getTypeFrequence().equals(TypeFrequenceEnum.ANNEE_CIVILE.name())) {
                                    updateMontantsAnnee(ppf, mDupliques);
                                }
                            });
                }
        }
        return result;
    }

    private void updateMontantsAnnee(RecupParamPlfdFreqResp ppf, Map.Entry<String, Multimap<String, Multimap<Float, Integer>>> mDupliques) {
        mDupliques.getValue().entries().forEach(mDuplique -> {
            if(mDuplique.getKey().equals(TypeFrequenceEnum.ANNEE_CIVILE.name())){
                mDuplique.getValue().entries().forEach( duplicated -> {
                    ppf.setMontantMaxdispoClient(ppf.getMontantMaxdispoClient() - duplicated.getKey());
                    ppf.setNombreMaxDispoClient(ppf.getNombreMaxDispoClient() - duplicated.getValue());
                });
            }
        });
    }

    private void updateMontantsMois(RecupParamPlfdFreqResp ppf, Map.Entry<String, Multimap<String, Multimap<Float, Integer>>> mDupliques) {
        mDupliques.getValue().entries().forEach(mDuplique -> {
            if(mDuplique.getKey().equals(TypeFrequenceEnum.MOIS_GLISSANT.name())){
                mDuplique.getValue().entries().forEach( duplicated -> {
                    ppf.setMontantMaxdispoClient(ppf.getMontantMaxdispoClient() - duplicated.getKey());
                    ppf.setNombreMaxDispoClient(ppf.getNombreMaxDispoClient() - duplicated.getValue());
                });
            }
        });
    }

    private Multimap<String,Multimap<Float, Integer>> getMontant(RecupParamPeriMethPaimtResp dp) {

        float montantMensuel;
        float montantAnnuel;
        int nbMensuel = 0;
        int nbAnnuel = 0;
        Multimap<String,Multimap<Float, Integer>> result = ArrayListMultimap.create();

        for (RecupParamPlfdFreqResp recupParamPlfdFreqResp : dp.getPlafondsParFrequences()) {
            Multimap<Float, Integer> calcul = ArrayListMultimap.create();
            if (recupParamPlfdFreqResp.getTypeFrequence().equals(TypeFrequenceEnum.ANNEE_CIVILE.name())) {
                montantAnnuel = recupParamPlfdFreqResp.getMontantMax() - recupParamPlfdFreqResp.getMontantMaxdispoClient();
                nbAnnuel = recupParamPlfdFreqResp.getNombreMax() - recupParamPlfdFreqResp.getNombreMaxDispoClient();
                calcul.put(montantAnnuel, nbAnnuel);
                result.put(TypeFrequenceEnum.ANNEE_CIVILE.name(),calcul);
            }
            else if (recupParamPlfdFreqResp.getTypeFrequence().equals(TypeFrequenceEnum.MOIS_GLISSANT.name())) {
                montantMensuel = recupParamPlfdFreqResp.getMontantMax() - recupParamPlfdFreqResp.getMontantMaxdispoClient();
                nbMensuel = recupParamPlfdFreqResp.getNombreMax() - recupParamPlfdFreqResp.getNombreMaxDispoClient();
                calcul.put(montantMensuel, nbMensuel);
                result.put(TypeFrequenceEnum.MOIS_GLISSANT.name(),calcul);
            }
        }

        return result;
    }

    private Multimap<String, List<Plafond>> getDuplicatedCardProfile(Multimap<String, List<Plafond>> cardsWithSamePlafondProfile, String key) {
        Multimap<String, List<Plafond>> cardWithSamePlafondProfile = ArrayListMultimap.create();
        for (Map.Entry<String, List<Plafond>> entry : cardsWithSamePlafondProfile.entries()) {
            if (!entry.getKey().equals(key)) {
                cardWithSamePlafondProfile.put(entry.getKey(), entry.getValue());
            }
        }
        return cardWithSamePlafondProfile;
    }

    private Multimap<String, List<Plafond>> checkCartesHavingSamePlafond(Map<String, List<Plafond>> cartes) {
        Multimap<String, List<Plafond>> cardsWithSamePlafondProfile = ArrayListMultimap.create();
        if (cartes.values().stream().filter(Objects::isNull).collect(Collectors.toList()).size() == 0) {
            cartes
                    .entrySet().stream()
                    .filter(carte -> getDuplicated(carte.getValue(), carte.getKey(), cartes))
                    .forEach(carte -> cardsWithSamePlafondProfile.put(carte.getKey(), carte.getValue()));
        }
        return cardsWithSamePlafondProfile;
    }

    private boolean getDuplicated(List<Plafond> plafonds, String typeCard, Map<String, List<Plafond>> cartes) {
        for (Map.Entry<String, List<Plafond>> entry : cartes.entrySet()) {
            for (Plafond val : entry.getValue()) {
                for (Plafond p : plafonds) {
                    if (val != null && p.getId() == val.getId() && typeCard != entry.getKey()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }


    private Map<String, List<Plafond>> agregatePlafondsByCards(Perimetre perimetre) {
        Map<String, List<Plafond>> cartes = new HashMap<>();
        for (PerimetrePlafond perimetrePlafond : perimetre.getPerimetrePlafonds()) {
            String carte = perimetrePlafond.getMethodePaiement();
            if (cartes.containsKey(carte)) {
                cartes.get(carte).add(perimetrePlafond.getPlafond());
            } else {
                cartes.put(carte, new ArrayList<>(Arrays.asList(perimetrePlafond.getPlafond())));
            }
        }
        return cartes;
    }

    private PaiementDto buildPaiementDto(RecupParamRootReq pfsDto, String methodePaiement) {
        log.info("Préparation de la requête de recherche des paiements à l'état CAPTURED.");
        log.debug("pfsDto = {}", pfsDto);
        log.debug("methodePaiement = {}", methodePaiement);
        return PaiementDto.builder()
                .idUniqueClient(pfsDto.getClient().getIdUniqueClient())
                .metier(pfsDto.getProfil().getMetier())
                .codeApplication(pfsDto.getProfil().getCodeApplication())
                .evenementMetier(pfsDto.getProfil().getEvenementMetier())
                .natureClient(pfsDto.getClient().getNatureClient())
                .typeClient(pfsDto.getClient().getTypeClient())
                .tiersPayeur(pfsDto.getPerimetre().isTiersPayeur())
                .structureJuridique(pfsDto.getPerimetre().getStructureJuridique())
                .filiale(pfsDto.getPerimetre().getFiliale())
                .produit(pfsDto.getPerimetre().getProduit())
                .contratDeReference(!Objects.isNull(pfsDto.getPerimetre().getContratDeReference()) && !pfsDto.getPerimetre().getContratDeReference().equals("") ? pfsDto.getPerimetre().getContratDeReference() : null)
                .contrat(pfsDto.getPerimetre().getContrat())
                .methodeDePaiement(methodePaiement)
                .etatCourant(EtatEnum.CAPTURED)
                .build();
    }
}
