package fr.ag2rlamondiale.paiementdigital.dto.type;

public enum RolePersonneEnum {
    CPY,
    ADM,
    USER,
    PAY,
    CNS
}
