package fr.ag2rlamondiale.paiementdigital.business.parametrage.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponseChildsFacade;
import fr.ag2rlamondiale.paiementdigital.business.parametrage.IResponsePlafonfsFrequencesFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request.RecupParamRootReq;
import fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.response.RecupParamPlfdFreqResp;
import fr.ag2rlamondiale.paiementdigital.exception.ParamLabException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.time.Year;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.exception.ParamLabException.PLAFONDS_PAR_FREQUENCES;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.buildDate;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.dateNowMinus1Month;

@Service
@Slf4j
public class ResponsePlafonfsFrequencesFacadeImpl implements IResponsePlafonfsFrequencesFacade {

    @Autowired
    private IPaiementFacade paiementFacade;

    @Autowired
    private IResponseChildsFacade childsFacade;

    @Override
    public Set<RecupParamPlfdFreqResp> getPlafondsParFrequencesDtos(RecupParamRootReq pfsDto, List<Plafond> plafonds, PaiementDto paiement) {
        log.debug("pfsDto = {}", pfsDto);
        log.debug("Plafonds = {}", plafonds);
        log.debug("paiement = {}", paiement);

        Set<RecupParamPlfdFreqResp> result = new HashSet<>();

        Date dateRecherche  = pfsDto.getDateRecherche();

        for (Plafond plafond : plafonds) {
            Date dateDebut = buildDate(Year.now().getValue(), 1, 1);

            if (TypeFrequenceEnum.MOIS_GLISSANT.equals(plafond.getTypeFrequence()))
                dateDebut = dateNowMinus1Month(pfsDto.getDateRecherche());

            List<Float> montants = null;
            if (!TypeFrequenceEnum.TRANSACTION.equals(plafond.getTypeFrequence()))
                montants = paiementFacade.getPaiementsAmountsByDate(paiement, dateDebut, dateRecherche);
            log.debug("Liste des montants captured trouvés = {} pour la fréquence {} et la méthode de paiement {}", montants, plafond.getTypeFrequence(), paiement.getMethodeDePaiement());
            result.add(childsFacade.plafondsParFrequences(plafond, montants));
        }

        if (CollectionUtils.isEmpty(result))
            throw new ParamLabException(PLAFONDS_PAR_FREQUENCES);

        log.debug("result = {}", result);
        return result;
    }

}
