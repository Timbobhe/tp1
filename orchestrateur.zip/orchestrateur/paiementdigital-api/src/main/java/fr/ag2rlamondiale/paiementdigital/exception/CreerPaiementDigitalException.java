package fr.ag2rlamondiale.paiementdigital.exception;

import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.CreerPaimtDigiRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.ErrorResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.HeaderResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response.ResponseResp;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.Arrays;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class CreerPaiementDigitalException extends RuntimeException {

    private static final long serialVersionUID = -3708989047380286704L;

    public static final String INVALID_PARAMETER = "Le paramètre ne peut être null!";

    private HttpStatus httpStatus;

    private CreerPaimtDigiRootResp response;

    public CreerPaiementDigitalException(String message) {
        super(message);
        httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        response = buildResponseTechError(httpStatus.name(), message);
        log.error("Exception : {}", response);
    }

    private CreerPaimtDigiRootResp buildResponseTechError(String errorCode, String errorMessage) {
        HeaderResp header = new HeaderResp();
        ErrorResp error = ErrorResp
                .builder()
                .errorCode(errorCode)
                .errorMessage(errorMessage)
                .build();
        header.setTechError(Arrays.asList(error));
        ResponseResp resp= new ResponseResp(header, null);
        return new CreerPaimtDigiRootResp(resp);
    }
}
