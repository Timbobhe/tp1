package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sa.request;

import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetailPerimetreMetierReq {

    private String metier;

    private String codeApplication;

    private TypeEvenementMetier evenementMetier;

    private String structureJuridique;

    private String filiale;

    private String produit;

    private String contratDeReference;

    private String contrat;

    private String codeSilo;

}
