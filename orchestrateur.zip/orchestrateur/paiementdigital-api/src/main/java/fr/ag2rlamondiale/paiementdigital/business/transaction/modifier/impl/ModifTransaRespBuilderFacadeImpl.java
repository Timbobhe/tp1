package fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.impl;

import fr.ag2rlamondiale.paiementdigital.business.transaction.commons.IInterpreteurPfsResponseFacade;
import fr.ag2rlamondiale.paiementdigital.business.transaction.modifier.IModifTransaRespBuilderFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetMntPaimtResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaDetTransaPaimtNumResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sa.response.ModifTransaRootResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtDigiBisResp;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response.ModifPaimtRootResp;
import fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException;
import fr.ag2rlamondiale.paiementdigital.mapper.transaction.modifier.IModifTransaPaimtDigiMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

import static fr.ag2rlamondiale.paiementdigital.exception.ModifierTransactionException.INVALID_PARAMETER;

@Service
@Slf4j
public class ModifTransaRespBuilderFacadeImpl implements IModifTransaRespBuilderFacade {

    @Autowired
    private IInterpreteurPfsResponseFacade<ModifPaimtRootResp, Paiement> interpretFacade;

    @Autowired
    private IModifTransaPaimtDigiMapper mapper;

    @Override
    public ModifTransaRootResp build(ResponseEntity<ModifPaimtRootResp> responseEntity, Paiement paiement) {
        log.info("Création de la reponse du SA ModifierTrasaction");
        log.debug("ResponseEntity<ModifPaimtRootResp> {}", responseEntity);
        log.debug("Informations du paiement {}", paiement);

        if (Objects.isNull(responseEntity) || Objects.isNull(paiement))
            throw new ModifierTransactionException(HttpStatus.INTERNAL_SERVER_ERROR, INVALID_PARAMETER);

        Paiement paiementUpdated = interpretFacade.interpreteur(responseEntity, paiement);

        Optional<Historique> historique = paiement.getHistoriques().stream().filter(h -> EtatEnum.ERROR.equals(h.getEtat())).findAny();
        if (historique.isPresent()) {
            ModifTransaRootResp modifTransaRootResp = mapper.toModifTransaRoot(historique.get());
            log.debug("ModifTransaRootResp {}", modifTransaRootResp);
            return modifTransaRootResp;
        }

        ModifPaimtDigiBisResp paimtDigi = responseEntity.getBody().getResponse().getBody().getModifierPaimtDigiResponse().getModifierPaimtDigiFunc().getPaimtDigi();

        ModifTransaResp modifTransa = mapper.toModifTransa(paimtDigi, paiementUpdated.getEtatCourant());

        ModifTransaDetTransaPaimtNumResp detTransaPaimtNum = mapper.toDetTransaPaimtNum(paimtDigi.getDetTransaPaimtNumerise(), paiement.getOrderId());

        ModifTransaDetMntPaimtResp detMntPaimt = mapper.toDetMntPaimt(paimtDigi.getDetailMontantPaimt());

        modifTransa.setDetailTransactionPaiementNumerise(detTransaPaimtNum);
        modifTransa.setDetailMontantPaiement(detMntPaimt);

        ModifTransaRootResp modifTransaRootResp = ModifTransaRootResp
                .builder()
                .modifTransaResp(modifTransa)
                .build();
        log.debug("ModifTransaRootResp {}", modifTransaRootResp);
        return modifTransaRootResp;
    }

}
