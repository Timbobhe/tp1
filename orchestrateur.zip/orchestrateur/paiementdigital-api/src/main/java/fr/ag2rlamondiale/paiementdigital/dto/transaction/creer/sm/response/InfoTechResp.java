package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class InfoTechResp implements Serializable {

    private static final long serialVersionUID = -6218482334357971834L;

    private String adrIP;

    @JsonProperty("ip_country")
    private String ipCountry;

    private String deviceId;

}
