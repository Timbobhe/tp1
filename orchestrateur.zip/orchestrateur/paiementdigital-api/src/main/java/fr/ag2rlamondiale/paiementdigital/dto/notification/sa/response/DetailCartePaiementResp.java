package fr.ag2rlamondiale.paiementdigital.dto.notification.sa.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DetailCartePaiementResp implements Serializable {

    private String anneeExpiration;

    private String codePaysEtablissementBancaire;

    private String codeTypeCarte;

    private String identifiantChiffreMoyenPaiement;

    private String libelleEtablissementBancaire;

    private String moisExpiration;

    private String numeroCarte;

    private String titulaireCartePaiement;

}
