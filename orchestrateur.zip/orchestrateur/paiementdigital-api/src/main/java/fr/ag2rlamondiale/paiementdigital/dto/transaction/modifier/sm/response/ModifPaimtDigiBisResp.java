package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ModifPaimtDigiBisResp implements Serializable {

    private static final long serialVersionUID = 6764180960960638288L;

    @JsonProperty("DetTransaPaimtNumerise")
    private ModifPaimtDetTransaPaimtNumResp detTransaPaimtNumerise;

    @JsonProperty("DetMntPaimt")
    private ModifPaimtDetMontantPaimtResp detailMontantPaimt;

    private String stt;

    private String msg;

    private String idMarchand;

}
