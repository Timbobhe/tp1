package fr.ag2rlamondiale.paiementdigital.controller.server;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.utils.ControllerUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Set;


@RestController
@RequestMapping(value = "/api/paiements", produces = MediaType.APPLICATION_JSON_VALUE)
public class PaiementController {

    @Autowired
    private IPaiementFacade facade;

    @GetMapping("/{id}")
    public ResponseEntity<PaiementDto> getPaiementById(@PathVariable Long id) {
        PaiementDto paiementDto = facade.findPaiementById(id);
        return new ResponseEntity<>(paiementDto, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<Set<PaiementDto>> getAllPaiements() {
        Set<PaiementDto> paiementsDto = facade.findPaiements();
        return new ResponseEntity<>(paiementsDto, ControllerUtils.getHttpHeaders(), HttpStatus.OK);
    }

}
