package fr.ag2rlamondiale.paiementdigital.dto.transaction.modifier.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifPaimtBodyResp implements Serializable {

    private static final long serialVersionUID = 518646268254162209L;

    @JsonProperty("ModifierPaimtDigiResponse")
    private ModifPaimtDigiResp modifierPaimtDigiResponse;
}
