package fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ag2rlamondiale.paiementdigital.dto.transaction.creer.sm.request.IdPersDansSiloReq;
import fr.ag2rlamondiale.paiementdigital.dto.type.RolePersonneEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DetActrResp implements Serializable {

    private static final long serialVersionUID = -695159816246491199L;

    @JsonProperty("codeRole")
    private RolePersonneEnum codeRole;

    private List<IdPersDansSiloReq> idPersDansSilo;

    @JsonProperty("InfoPP")
    private InfoPPResp infoPP;
}
