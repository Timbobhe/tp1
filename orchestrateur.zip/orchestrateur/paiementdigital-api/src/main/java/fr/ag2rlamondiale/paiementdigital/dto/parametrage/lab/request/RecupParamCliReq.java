package fr.ag2rlamondiale.paiementdigital.dto.parametrage.lab.request;

import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Size;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecupParamCliReq {

    @Size(max = 30, message = "Le champs 'idUniqueClient' doit faire 30 caractères maximum.")
    private String idUniqueClient;

    @Size(max = 20, message = "Le champs 'natureClient' doit faire 20 caractères maximum.")
    private NatureClientEnum natureClient;

    @Size(max = 10, message = "Le champs 'typeClient' doit faire 10 caractères. maximum")
    private TypeClientEnum typeClient;
}
