package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"paiement"})
@ToString(exclude = {"paiement"})
@Builder
@Table(name = "tbsd0bdt")
@Entity
public class DonneeMetier implements Serializable {

    private static final long serialVersionUID = -789822488086582699L;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idpai")
    private Paiement paiement;

    @Id
    @NotNull
    @Size(max = 10)
    @Column(name = "tybusdat", nullable = false)
    private String typeDonnee;

    @Size(max = 35)
    @Column(name = "vabusdat")
    private String valeurDonnee;

}
