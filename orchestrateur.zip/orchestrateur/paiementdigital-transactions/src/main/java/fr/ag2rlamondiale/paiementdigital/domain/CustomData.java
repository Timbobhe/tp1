package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"paiement"})
@ToString(exclude = {"paiement"})
@Builder
@Table(name = "tbsd0cdt")
@Entity
public class CustomData implements Serializable {

    private static final long serialVersionUID = -1623245493321164171L;

    @Id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "idpai")
    private Paiement paiement;

    @Id
    @NotNull
    @Column(name = "noord", nullable = false)
    private int ordre;

    @Size(max = 35)
    @Column(name = "vacstdat")
    private String cdata;

}
