package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Date;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class HistoriquePK implements Serializable {

    private static final long serialVersionUID = 1153713112198526329L;

    @Column(name = "tseta")
    private Date tseta;

    @Column(name = "idpai")
    private Long idpai;
}
