package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementInsertDtoRequest;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementUpdateDtoRequest;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.mapper.PaiementMapper;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterException.MANDATORY_PARAMS_MISSING;
import static fr.ag2rlamondiale.paiementdigital.exception.PaiementException.PAIEMENT_DUPLICATE;
import static fr.ag2rlamondiale.paiementdigital.exception.PaiementException.PAIEMENT_NOT_EXIST;

@Slf4j
@Service
@NoArgsConstructor
public class PaiementFacadeImpl implements IPaiementFacade {

    @Autowired
    private IPaiementRepository repository;

    @Autowired
    private PaiementMapper mapper;

    @Override
    public PaiementDto findPaiementById(Long id) {
        log.info("findPaiementById** : {}", id);
        Paiement paiement = repository.findPaiementById(id);
        return mapper.paiementToPaiementDto(paiement);
    }

    @Override
    public PaiementDto findPaiementByOrderId(String orderId) {
        log.info("findPaiementByOrderId** : {}", orderId);
        if (Objects.isNull(orderId))
            throw new PaiementException(PaiementException.INCORRECT_REQUEST_PARAMETER_VALUE);

        Paiement paiement = repository.findPaiementByOrderId(orderId);
        return mapper.paiementToPaiementDto(paiement);
    }

    @Override
    public Set<PaiementDto> findPaiements() {
        log.info("findPaiements**");
        return mapper.paiementListToPaiementListDto(new HashSet<>(repository.findAll()));
    }

    @Override
    public PaiementDto insertPaiement(PaiementInsertDtoRequest paiementRequest) {
        log.info("insertPaiement** : {}", paiementRequest);
        PaiementDto paiementByOrderId = findPaiementByOrderId(paiementRequest.getOrderId());

        if (paiementByOrderId != null) {
            throw new PaiementException(PAIEMENT_DUPLICATE);
        }

        Date now = new Date();
        Paiement paiement = mapper.paiementDtoRequestToPaiement(paiementRequest);
        paiement.setEtatCourant(EtatEnum.CREATE);
        paiement.setDateCreation(now);

        Historique h = Historique.builder()
                .id(new HistoriquePK(now, paiement.getId()))
                .paiement(paiement)
                .etat(EtatEnum.CREATE)
                .montant(paiementRequest.getMontant())
                .build();

        paiement.getHistoriques().add(h);

        if (!CollectionUtils.isEmpty(paiementRequest.getCustomDatas())) {
            paiement.getCustomDatas().forEach(c -> c.setPaiement(paiement));
        }

        if (!CollectionUtils.isEmpty(paiementRequest.getDonneeMetiers())) {
            paiement.getDonneeMetiers().forEach(d -> d.setPaiement(paiement));
        }

        return mapper.paiementToPaiementDto(repository.save(paiement));

    }

    @Override
    public PaiementDto updatePaiement(PaiementUpdateDtoRequest paiementRequest) {
        log.info("Mise à jour paiement avec les données suivantes : {}", paiementRequest);
        if (Objects.isNull(paiementRequest)
                || Objects.isNull(paiementRequest.getOrderId())
                || Objects.isNull(paiementRequest.getEtatCourant()))
            throw new PaiementException(PaiementException.INCORRECT_REQUEST_PARAMETER_VALUE);

        Paiement paiement = repository.findPaiementByOrderId(paiementRequest.getOrderId());

        if (Objects.isNull(paiement))
            throw new PaiementException(PAIEMENT_NOT_EXIST);

        Date now = new Date();

        paiement.setIdTransaction(paiementRequest.getIdTransaction());
        paiement.setMontant(paiementRequest.getMontant());
        paiement.setEtatCourant(paiementRequest.getEtatCourant());
        paiement.setDateModification(now);

        Historique h = Historique.builder()
                .paiement(paiement)
                .id(new HistoriquePK(now, paiement.getId()))
                .paiement(paiement)
                .etat(paiementRequest.getEtatCourant())
                .montant(paiementRequest.getMontant())
                .status(paiementRequest.getStatus())
                .message(paiementRequest.getMessage())
                .build();

        paiement.getHistoriques().add(h);

        return mapper.paiementToPaiementDto(repository.save(paiement));
    }

    @Override
    public List<Float> getPaiementsAmountsByDate(PaiementDto paiementDto, Date dateDebut, Date dateFin) {
        log.debug("Recherche de l'historique des montants versés à l'état CAPTURED");
        Date copyDateFin = Objects.isNull(dateFin) ? new Date() : (Date) dateFin.clone();

        if (!isValidFields(paiementDto, dateDebut, copyDateFin))
            throw new IncorrectParameterException(MANDATORY_PARAMS_MISSING);

        Paiement paiement = mapper.paiementDtoToPaiement(paiementDto);

        log.debug("Date de recherche des montants compris entre {} et {}", dateDebut, copyDateFin);
        return repository.getAmountsTransactions(paiement, dateDebut, copyDateFin);
    }

    @Override
    public Paiement save(Paiement paiement) {
        if (repository.findPaiementByOrderId(paiement.getOrderId()) != null)
            throw new PaiementException(PAIEMENT_DUPLICATE);
        return repository.save(paiement);
    }

    @Override
    public Paiement find(String idTransaction) {
        Paiement paiement = repository.find(idTransaction);

        if (Objects.isNull(paiement))
            throw new PaiementException(PAIEMENT_NOT_EXIST);

        return paiement;
    }

    @Override
    public Paiement update(Paiement paiement) {
        if (!repository.findById(paiement.getId()).isPresent())
            throw new PaiementException(PAIEMENT_NOT_EXIST);

        return repository.save(paiement);
    }

    @Override
    public Paiement findByOrderId(String orderId) {
        log.info("Recherche du paiement");
        Paiement paiement = repository.findPaiementByOrderId(orderId);
        if (Objects.isNull(paiement))
            throw new PaiementException(PAIEMENT_NOT_EXIST);

        log.debug("Paiement trouvé : {}", paiement);
        return paiement;
    }

    private boolean isValidFields(PaiementDto paiementDto, Date dateDebut, Date dateFin) {
        log.debug("Vérification de la validité des champs paiementDto: {}", paiementDto);
        return !StringUtils.isEmpty(paiementDto.getMetier())
                && !StringUtils.isEmpty(paiementDto.getCodeApplication())
                && !StringUtils.isEmpty(paiementDto.getEvenementMetier())
                && !StringUtils.isEmpty(paiementDto.getMethodeDePaiement())
                && !StringUtils.isEmpty(paiementDto.getIdUniqueClient())
                && !StringUtils.isEmpty(paiementDto.getEtatCourant())
                && !Objects.isNull(dateDebut)
                && dateDebut.before(dateFin);
    }
}
