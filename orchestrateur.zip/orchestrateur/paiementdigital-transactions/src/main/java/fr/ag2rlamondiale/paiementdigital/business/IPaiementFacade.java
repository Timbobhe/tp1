package fr.ag2rlamondiale.paiementdigital.business;

import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementInsertDtoRequest;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementUpdateDtoRequest;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Set;

@Service
public interface IPaiementFacade {
    PaiementDto findPaiementById(Long id);

    PaiementDto findPaiementByOrderId(String orderId);

    Set<PaiementDto> findPaiements();

    PaiementDto insertPaiement(PaiementInsertDtoRequest paiementRequest);

    PaiementDto updatePaiement(PaiementUpdateDtoRequest paiementRequest);

    List<Float> getPaiementsAmountsByDate(PaiementDto paiementDto, Date dateDebut, Date dateFin);

    Paiement find(String idTransaction);

    Paiement save(Paiement paiement);

    Paiement update(Paiement paiement);

    Paiement findByOrderId(String orderId);
}
