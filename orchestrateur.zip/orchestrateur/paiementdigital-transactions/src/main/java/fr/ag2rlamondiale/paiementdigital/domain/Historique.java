package fr.ag2rlamondiale.paiementdigital.domain;

import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

import static javax.persistence.EnumType.STRING;

@Getter
@Setter
@Entity
@EqualsAndHashCode(exclude = {"paiement"})
@NoArgsConstructor
@AllArgsConstructor
@ToString(exclude = {"paiement"})
@Builder
@Table(name = "tbsd0his")
public class Historique implements Serializable {

    private static final long serialVersionUID = 4301831239170522051L;

    @EmbeddedId
    private HistoriquePK id;

    @MapsId("idpai")
    @ManyToOne(optional = false)
    @JoinColumn(name = "idpai")
    private Paiement paiement;

    @Column(name = "mtpai")
    private Float montant;

    @NotNull
    @Enumerated(STRING)
    @Column(name = "coetapai")
    private EtatEnum etat;

    @Size(max = 30)
    @Column(name = "costt")
    private String status;

    @Size(max = 200)
    @Column(name = "lbmsgstt")
    private String message;

}
