package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.config.TransactionConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.utils.TransactionUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.A1573;
import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.RET_SUP_COL;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;


@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TransactionConfig.class)
@Sql(scripts = "/sql/paiement.sql")
@Transactional
public class PaiementRepositoryIT {

    @Autowired
    private IPaiementRepository repository;

    private Paiement searchHistoriqueClientA;

    private Paiement searchHistoriqueClientB;

    @BeforeEach
    void setUp() {

        searchHistoriqueClientA = Paiement.builder()
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .idUniqueClient("CLIENT_A")
                .methodeDePaiement("CB")
                .etatCourant(EtatEnum.CAPTURED)
                .build();

        searchHistoriqueClientB = Paiement.builder()
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .idUniqueClient("CLIENT_B")
                .methodeDePaiement("MASTERCARD")
                .etatCourant(EtatEnum.CAPTURED)
                .build();
    }

    @AfterEach
    void tearDown() {
        searchHistoriqueClientA = null;
        searchHistoriqueClientB = null;
    }

    @Test
    void find_existing_paiement_by_order_id() {
        //GIVEN
        String orderId = "c81d4e2ebcf211e6869b7df92533d2db";
        //WHEN
        Paiement paiement = repository.findPaiementByOrderId(orderId);
        //THEN
        assertEquals(orderId, paiement.getOrderId());
    }

    @Test
    void find_paiement_by_unknown_order_id() {
        //WHEN
        Paiement paiement = repository.findPaiementByOrderId(UUID.randomUUID().toString().replace("-", ""));
        //THEN
        assertEquals(null, paiement);
    }

    @Test
    void finding_historique_clientA_captured_state_gives_1_result() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 1, 1);
        //WHEN
        List<Float> montants = repository.getAmountsTransactions(searchHistoriqueClientA, dateDebut, new Date());
        //THEN
        assertEquals(1, montants.size());
    }

    @Test
    void finding_historique_clientB_captured_state_gives_3_results() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 1);
        //WHEN
        List<Float> montants = repository.getAmountsTransactions(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(3, montants.size());
    }

    @Test
    void finding_historique_clientB_captured_state_gives_1_result() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2021, 4, 7);
        //WHEN
        List<Float> montants = repository.getAmountsTransactions(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(1, montants.size());
    }

    @Test
    void finding_historique_clientB_captured_state_gives_2_results() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 1);
        searchHistoriqueClientB.setMethodeDePaiement("CB");
        //WHEN
        List<Float> montants = repository.getAmountsTransactions(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(2, montants.size());
    }

    @Test
    public void find_paiement_by_id_transaction_is_ok() {
        //GIVEN
        String idTransaction = "800088752450";

        //WHEN
        Paiement actual = repository.find(idTransaction);

        //THEN
        assertEquals(idTransaction, actual.getIdTransaction());
    }

    @Test
    public void find_unknown_id_transaction_return_empty() {
        //WHEN
        Paiement actual = repository.find("UNKNOWN_ID");

        //THEN
        assertNull(actual);
    }
}