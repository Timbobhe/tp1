package fr.ag2rlamondiale.paiementdigital.business.impl;


import fr.ag2rlamondiale.paiementdigital.business.IPaiementFacade;
import fr.ag2rlamondiale.paiementdigital.config.TransactionConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Historique;
import fr.ag2rlamondiale.paiementdigital.domain.HistoriquePK;
import fr.ag2rlamondiale.paiementdigital.domain.Paiement;
import fr.ag2rlamondiale.paiementdigital.domain.type.EtatEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.dto.PaiementDto;
import fr.ag2rlamondiale.paiementdigital.dto.request.CustomDataDtoRequest;
import fr.ag2rlamondiale.paiementdigital.dto.request.DonneeMetierDtoRequest;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementInsertDtoRequest;
import fr.ag2rlamondiale.paiementdigital.dto.request.PaiementUpdateDtoRequest;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterException;
import fr.ag2rlamondiale.paiementdigital.exception.PaiementException;
import fr.ag2rlamondiale.paiementdigital.repository.IPaiementRepository;
import fr.ag2rlamondiale.paiementdigital.utils.TransactionUtils;
import fr.ag2rlamondiale.paiementdigital.utils.UUIDUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.A1573;
import static fr.ag2rlamondiale.paiementdigital.constantes.TransactionConstantes.RET_SUP_COL;
import static org.junit.jupiter.api.Assertions.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = TransactionConfig.class)
@Sql(scripts = "/sql/paiement.sql")
@Transactional
public class PaiementFacadeImplIT {

    @Autowired
    private IPaiementRepository repository;

    @Autowired
    private IPaiementFacade facade;

    private PaiementInsertDtoRequest paiementInsertDtoRequest;

    private PaiementDto searchHistoriqueClientA;

    private PaiementDto searchHistoriqueClientB;

    @BeforeEach
    public void setUp() {
        String orderId = UUIDUtils.randomUuidToOrderId();
        paiementInsertDtoRequest = PaiementInsertDtoRequest.builder()
                .orderId(orderId)
                .idTransaction("123456789")
                .metier(RET_SUP_COL)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .idUniqueClient("CLIENT_C")
                .codeApplication(A1573)
                .montant(123F)
                .methodeDePaiement("CB")
                .build();

        searchHistoriqueClientA = PaiementDto.builder()
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .idUniqueClient("CLIENT_A")
                .methodeDePaiement("CB")
                .etatCourant(EtatEnum.CAPTURED)
                .build();

        searchHistoriqueClientB = PaiementDto.builder()
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .idUniqueClient("CLIENT_B")
                .methodeDePaiement("MASTERCARD")
                .etatCourant(EtatEnum.CAPTURED)
                .build();
    }

    @AfterEach
    public void tearDown() {
        paiementInsertDtoRequest = null;
        searchHistoriqueClientA = null;
        searchHistoriqueClientB = null;
    }

    @Test
    void insert_paiement_with_correct_args() {
        //WHEN
        PaiementDto paiementDto = facade.insertPaiement(paiementInsertDtoRequest);
        //THEN
        assertEquals(paiementInsertDtoRequest.getOrderId(), paiementDto.getOrderId());
        assertNotNull(repository.findAll().stream().filter(p -> p.getOrderId().equals(paiementDto.getOrderId()))
                .findAny().get());
    }

    @Test
    void insert_paiement_with_same_orderid_throws_paiementexception() {
        //GIVEN
        paiementInsertDtoRequest.setOrderId("d9c790ed67774470b86681f324ea81b7");
        //WHEN THEN
        assertThrows(PaiementException.class, () -> facade.insertPaiement(paiementInsertDtoRequest));
    }

    @Test
    void insert_paiement_with_correct_args_and_donneesmetiers() {
        //GIVEN
        DonneeMetierDtoRequest donneeMetierDtoRequest = new DonneeMetierDtoRequest("type", "valeur");
        DonneeMetierDtoRequest donneeMetierDtoRequest2 = new DonneeMetierDtoRequest("type2", "valeur2");
        Set<DonneeMetierDtoRequest> donneeMetierDtoRequestSet = new HashSet<>(Arrays.asList(donneeMetierDtoRequest, donneeMetierDtoRequest2));
        paiementInsertDtoRequest.setDonneeMetiers(donneeMetierDtoRequestSet);

        //WHEN
        PaiementDto paiementDto = facade.insertPaiement(paiementInsertDtoRequest);

        //THEN
        assertEquals(paiementInsertDtoRequest.getOrderId(), paiementDto.getOrderId());
        assertNotNull(paiementDto.getDonneeMetiers());
        assertEquals(2, paiementDto.getDonneeMetiers().size());
        assertNull(paiementDto.getCustomDatas());
    }

    @Test
    void insert_paiement_with_correct_args_and_customdatas() {
        //GIVEN
        CustomDataDtoRequest customDataDtoRequest = new CustomDataDtoRequest(1, "cdata1");
        CustomDataDtoRequest customDataDtoRequest2 = new CustomDataDtoRequest(2, "cdata2");
        Set<CustomDataDtoRequest> customDataDtoRequestSet = new HashSet<>(Arrays.asList(customDataDtoRequest, customDataDtoRequest2));
        paiementInsertDtoRequest.setCustomDatas(customDataDtoRequestSet);
        //WHEN
        PaiementDto paiementDto = facade.insertPaiement(paiementInsertDtoRequest);
        //THEN
        assertEquals(paiementInsertDtoRequest.getOrderId(), paiementDto.getOrderId());
        assertNotNull(paiementDto.getCustomDatas());
        assertEquals(2, paiementDto.getCustomDatas().size());
        assertNull(paiementDto.getDonneeMetiers());
    }

    @Test
    void update_paiement_with_correct_args() {
        //GIVEN
        facade.insertPaiement(paiementInsertDtoRequest);

        PaiementUpdateDtoRequest paiementUpdateRequest = PaiementUpdateDtoRequest.builder()
                .orderId(paiementInsertDtoRequest.getOrderId())
                .etatCourant(EtatEnum.AUTHORIZATION)
                .montant(246F)
                .build();

        //WHEN
        PaiementDto paiementDto = facade.updatePaiement(paiementUpdateRequest);

        //THEN
        assertEquals(paiementUpdateRequest.getOrderId(), paiementDto.getOrderId());
        assertEquals(paiementUpdateRequest.getMontant(), paiementDto.getMontant());
        assertEquals(paiementUpdateRequest.getEtatCourant(), paiementDto.getEtatCourant());
    }

    @Test
    void finding_historique_clientA_captured_state_gives_1_result() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 1, 1);
        //WHEN
        List<Float> montants = facade.getPaiementsAmountsByDate(searchHistoriqueClientA, dateDebut, new Date());
        //THEN
        assertEquals(1, montants.size());
    }

    @Test
    void finding_historique_clientB_captured_state_gives_1_result() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2021, 4, 7);
        //WHEN
        List<Float> montants = facade.getPaiementsAmountsByDate(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(1, montants.size());
    }

    @Test
    void finding_historique_clientB_captured_state_gives_3_results() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 31);
        //WHEN
        List<Float> montants = facade.getPaiementsAmountsByDate(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(3, montants.size());
    }

    @Test
    void finding_paiement_clientB_captured_state_gives_2_results() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 1);
        searchHistoriqueClientB.setMethodeDePaiement("CB");
        //WHEN
        List<Float> montants = facade.getPaiementsAmountsByDate(searchHistoriqueClientB, dateDebut, new Date());
        //THEN
        assertEquals(2, montants.size());
    }

    @Test
    void finding_historique_clientB_with_inverted_dates_throws_incorrect_parameter_exception() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 1);
        Date dateFin = TransactionUtils.buildLongDate(2018, 12, 1);

        //WHEN THEN
        assertThrows(IncorrectParameterException.class, () -> facade.getPaiementsAmountsByDate(searchHistoriqueClientB, dateDebut, dateFin));
    }

    @Test
    void finding_historique_with_missing_mandatory_field_throws_incorrect_argument_exception() {
        //GIVEN
        Date dateDebut = TransactionUtils.buildLongDate(2020, 12, 1);
        searchHistoriqueClientB.setMetier(null);

        //WHEN THEN
        assertThrows(IncorrectParameterException.class, () -> facade.getPaiementsAmountsByDate(searchHistoriqueClientB, dateDebut, new Date()));
    }

    @Test
    void updating_paiement_is_ok() {
        //GIVEN
        PaiementDto dto = facade.insertPaiement(paiementInsertDtoRequest);
        Paiement expected = repository.findPaiementByOrderId(dto.getOrderId());

        Date now = new Date();
        Historique historique = Historique.builder()
                .montant(expected.getMontant())
                .etat(EtatEnum.AUTHORIZATION)
                .id(new HistoriquePK(now, expected.getId()))
                .paiement(expected)
                .build();

        expected.setDateModification(now);
        expected.setEtatCourant(EtatEnum.AUTHORIZATION);
        expected.getHistoriques().add(historique);

        //WHEN
        Paiement actual = facade.update(expected);

        //THEN
        assertEquals(expected.getOrderId(), actual.getOrderId());
        assertEquals(expected.getIdTransaction(), actual.getIdTransaction());
        assertEquals(expected.getDateCreation(), actual.getDateCreation());
        assertEquals(expected.getHistoriques().size(), actual.getHistoriques().size());
    }

    @Test
    void updating_paiement_throws_exception() {
        //GIVEN
        Paiement paiement = repository.findPaiementByOrderId("b348c2a8dbef47deaaf2c8e5b2690ae9");
        Paiement copy = paiement.copy(paiement);
        copy.setId(1000000L);

        //WHEN THEN
        assertThrows(PaiementException.class, () -> facade.update(copy));
    }

    @Test
    public void find_paiement_by_id_transaction_is_ok() {
        //GIVEN
        Paiement expected = repository.findPaiementByOrderId("3666abd61461463c834e8959f57fc13f");

        //WHEN
        Paiement actual = facade.find(expected.getIdTransaction());

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void find_unknown_id_transaction_throws_exception() {
        //WHEN THEN
        assertThrows(PaiementException.class, () -> facade.find("UNKNOWN_ID"));
    }


    @Test
    public void find_paiement_by_orderId_is_ok() {
        //GIVEN
        Paiement expected = repository.findPaiementByOrderId("3666abd61461463c834e8959f57fc13f");

        //WHEN
        Paiement actual = facade.findByOrderId(expected.getOrderId());

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void find_unknown_orderId_throws_exception() {
        //WHEN THEN
        assertThrows(PaiementException.class, () -> facade.findByOrderId("UNKNOWN_ID"));
    }

}