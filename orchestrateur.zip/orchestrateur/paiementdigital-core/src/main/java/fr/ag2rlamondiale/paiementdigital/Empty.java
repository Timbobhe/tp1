package fr.ag2rlamondiale.paiementdigital;

public class Empty {
}
