package fr.ag2rlamondiale.paiementdigital.bootstrap;

import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class ParametrageInclusionPaysData {

    public static Set<InclusionPays> init() {
        Set<InclusionPays> result = new HashSet<>();

        String metierEre = ProfilConstantes.RET_SUP_COL;
        String codeApplicationA1573 = "A1573";

        Date dateEffet = ParametrageUtils.buildShortDate(2021, 1, 1);
        Date dateCreation = ParametrageUtils.buildLongDate(2021, 1, 1);

        result.add(build(1L, metierEre, codeApplicationA1573, TypePaysEnum.RESIDENCE_FISCALE, "France", "FRA", dateEffet, dateCreation));
        result.add(build(2L, metierEre, codeApplicationA1573, TypePaysEnum.DOMICILIATION_BANCAIRE, "France", "FRA", dateEffet, dateCreation));
        result.add(build(3L, metierEre, codeApplicationA1573, TypePaysEnum.RESIDENCE, "Autriche", "AUT", dateEffet, dateCreation));
        result.add(build(4L, metierEre, codeApplicationA1573, TypePaysEnum.RESIDENCE, "Belgique", "BEL", dateEffet, dateCreation));
        result.add(build(5L, metierEre, codeApplicationA1573, TypePaysEnum.RESIDENCE, "Bulgarie", "BGR", dateEffet, dateCreation));
        result.add(build(6L, metierEre, codeApplicationA1573, TypePaysEnum.RESIDENCE, "Croatie", "HRV", dateEffet, dateCreation));

        return result;
    }

    private static InclusionPays build(Long id, String metier, String codeApplication, TypePaysEnum typePays, String pays, String codeIso, Date dateEffet, Date dateCreation) {
        return InclusionPays
                .builder()
                .id(id)
                .metier(metier.toUpperCase())
                .codeApplication(codeApplication.toUpperCase())
                .typePays(typePays)
                .pays(pays)
                .codeIso(codeIso.toUpperCase())
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

    }
}
