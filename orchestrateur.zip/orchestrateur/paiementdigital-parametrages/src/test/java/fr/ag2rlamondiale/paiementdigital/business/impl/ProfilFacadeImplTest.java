package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.ParametrageProfilData;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.exception.ProfilException;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.AUCUN_PROFIL_TROUVE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class ProfilFacadeImplTest {

    @InjectMocks
    private ProfilFacadeImpl facade;

    @Mock
    private IProfilRepository repository;

    private Profil profil;

    @BeforeEach
    void setUp() {
        profil = ParametrageProfilData.profils().stream().findFirst().get();
    }

    @AfterEach
    void tearDown() {
        profil = null;
    }

    @Test
    void saving_profil_is_ok() {
        //GIVEN
        when(repository.find(any(Profil.class))).thenReturn(Collections.emptySet());
        when(repository.save(any(Profil.class))).thenReturn(profil);

        //WHEN
        Profil actual = facade.save(profil);

        //THEN
        assertEquals(profil, actual);
    }

    @Test
    void saving_profil_throws_exception() {
        //GIVEN
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(repository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.save(profil));
    }

    @Test
    void finding_profil_by_id_is_ok() {
        //GIVEN
        Optional<Profil> optProfil = Optional.of(profil);
        when(repository.findById(anyLong())).thenReturn(optProfil);

        //WHEN
        Profil actual = facade.findById(1L);

        //THEN
        assertEquals(profil, actual);
    }

    @Test
    void finding_profil_by_id_is_throwing_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.findById(7L));
    }

    @Test
    void finding_profil_is_ok() {
        //GIVEN
        Set<Profil> expected = new HashSet<>(Arrays.asList(profil));
        when(repository.find(any(Profil.class))).thenReturn(expected);

        //WHEN
        Set<Profil> actual = facade.find(profil);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    void finding_profil_throws_exception() {
        //GIVEN
        when(repository.find(any(Profil.class))).thenReturn(Collections.emptySet());

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.find(profil));
    }

    @Test
    void updating_profil_is_ok() {
        //GIVEN
        String oldCodeApplication = profil.getCodeApplication();
        profil.setCodeApplication("A1111");

        when(repository.findById(anyLong())).thenReturn(Optional.of(profil));
        when(repository.save(any(Profil.class))).thenReturn(profil);

        //WHEN
        Profil actual = facade.update(profil);

        //THEN
        assertNotEquals(oldCodeApplication, actual.getCodeApplication());
        assertEquals(profil.getCodeApplication(), actual.getCodeApplication());
    }

    @Test
    void updating_profil_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.update(profil));
    }

    @Test
    void deleted_profil_by_id_is_ok() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.of(profil));
        doNothing().when(repository).deleteById(anyLong());

        //WHEN
        facade.delete(1L);

        //THEN
        verify(repository, times(1)).deleteById(anyLong());
    }

    @Test
    void deleted_profil_by_id_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenThrow(new ProfilException(AUCUN_PROFIL_TROUVE));

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.delete(1L));
    }

    @Test
    void get_all_profil_gives_1_profil() {
        //GIVEN
        List<Profil> expected = Arrays.asList(profil);
        when(repository.findAll()).thenReturn(expected);

        //WHEN
        Set<Profil> actual = facade.findAll();

        //THEN
        assertEquals(1, actual.size());
        assertEquals(expected, actual.stream().collect(Collectors.toList()));
    }
}