/*
 * Cree le 19 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.ParametrageInclusionPaysData;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum;
import fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.repository.IInclusionPaysRepository;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.DUPLICATE_PAYS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class InclusionPaysFacadeImplTest {

    @InjectMocks
    private InclusionPaysFacadeImpl facade;

    @Mock
    private IInclusionPaysRepository repository;

    private String codeApplication;

    private Date dateRecherche;

    private Set<InclusionPays> pays;

    private InclusionPays inclusionPays;

    @BeforeEach
    void setUp() {
        pays = ParametrageInclusionPaysData.init();

        codeApplication = "A1573";
        dateRecherche = new Date();

        inclusionPays = InclusionPays
                .builder()
                .id(7L)
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication(codeApplication.toUpperCase())
                .typePays(TypePaysEnum.RESIDENCE)
                .pays("Mars")
                .codeIso("MAR")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();
    }

    @AfterEach
    void tearDown() {
        pays = null;
        codeApplication = null;
        dateRecherche = null;
        inclusionPays = null;
    }

    @Test
    void finding_inclusion_pays_with_null_metier_parameter_throws_incorrect_parameter_value_exception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> facade.find(null, codeApplication, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_null_codeApplication_parameter_throws_incorrect_parameter_value_exception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> facade.find(ProfilConstantes.RET_SUP_COL, null, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_null_dateRecherche_parameter_throws_incorrect_parameter_value_exception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> facade.find(ProfilConstantes.RET_SUP_COL, codeApplication, null));
    }

    @Test
    void unknown_parameters_throws_not_found_parameter_value_exception() {
        //GIVEN
        when(repository.find(any(String.class), any(String.class), any(Date.class))).thenReturn(null);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> facade.find(ProfilConstantes.RET_SUP_COL, codeApplication, dateRecherche));
    }

    @Test
    void known_parameters_give_inclusion_pays_list() {
        //GIVEN
        when(repository.find(any(String.class), any(String.class), any(Date.class))).thenReturn(pays);

        //WHEN
        Set<InclusionPays> actual = facade.find(ProfilConstantes.RET_SUP_COL, codeApplication, dateRecherche);

        //THEN
        assertEquals(pays.size(), actual.size());
    }

    @Test
    void saving_pays_is_ok() {
        //GIVEN
        when(repository.save(any(InclusionPays.class))).thenReturn(inclusionPays);

        //WHEN
        InclusionPays actual = facade.save(inclusionPays);

        //THEN
        assertEquals(inclusionPays, actual);
    }

    @Test
    void saving_pays_throws_exception() {
        //GIVEN
        when(repository.find(any(InclusionPays.class))).thenThrow(new InclusionPaysException(DUPLICATE_PAYS));

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.save(inclusionPays));
    }

    @Test
    void finding_pays_by_parameters_is_ok() {
        //GIVEN
        Set<InclusionPays> expected = new HashSet<>(Arrays.asList(inclusionPays));
        when(repository.find(anyString(), any(), any(Date.class))).thenReturn(expected);

        //WHEN
        Set<InclusionPays> actual = facade.find(ProfilConstantes.RET_SUP_COL, codeApplication, dateRecherche);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    void finding_pays_is_ok() {
        //GIVEN
        Set<InclusionPays> expected = new HashSet<>(Arrays.asList(inclusionPays));
        when(repository.find(any(InclusionPays.class))).thenReturn(expected);

        //WHEN
        Set<InclusionPays> actual = facade.find(inclusionPays);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    void finding_pays_throws_exception() {
        //GIVEN
        when(repository.find(any(InclusionPays.class))).thenReturn(Collections.emptySet());

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.find(inclusionPays));
    }

    @Test
    void finding_pays_by_id_is_ok() {
        //GIVEN
        Optional<InclusionPays> optPays = Optional.of(inclusionPays);
        when(repository.findById(anyLong())).thenReturn(optPays);

        //WHEN
        InclusionPays actual = facade.findById(7L);

        //THEN
        assertEquals(inclusionPays, actual);
    }

    @Test
    void finding_pays_by_id_is_throwing_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.findById(7L));
    }

    @Test
    void updating_pays_is_ok() {
        //GIVEN
        InclusionPays inclusionPays = InclusionPays
                .builder()
                .id(7L)
                .metier(ProfilConstantes.RET_SUP_COL)
                .codeApplication("A1111")
                .typePays(TypePaysEnum.RESIDENCE)
                .pays("Mars")
                .codeIso("MAR")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        when(repository.findById(anyLong())).thenReturn(Optional.of(inclusionPays));
        when(repository.save(any(InclusionPays.class))).thenReturn(inclusionPays);

        //WHEN
        InclusionPays actual = facade.update(inclusionPays);

        //THEN
        assertEquals(inclusionPays, actual);
    }

    @Test
    void updating_pays_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.update(inclusionPays));
    }

    @Test
    void deleted_pays_by_id_is_ok() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.of(inclusionPays));
        doNothing().when(repository).deleteById(anyLong());

        //WHEN
        facade.delete(1L);

        //THEN
        verify(repository, times(1)).deleteById(anyLong());
    }


    @Test
    void deleted_pays_by_id_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.delete(1L));
    }

    @Test
    void get_all_pays_gives_6_pays() {
        //GIVEN
        List<InclusionPays> expected = pays.stream().collect(Collectors.toList());
        when(repository.findAll()).thenReturn(expected);

        //WHEN
        Set<InclusionPays> actual = facade.findAll();

        //THEN
        assertEquals(6, actual.size());
        assertEquals(expected, actual.stream().collect(Collectors.toList()));
    }

}
