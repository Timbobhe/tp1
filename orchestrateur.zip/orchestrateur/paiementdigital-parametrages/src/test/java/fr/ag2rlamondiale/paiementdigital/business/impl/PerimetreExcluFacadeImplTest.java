package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.ParametrageProfilData;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException;
import fr.ag2rlamondiale.paiementdigital.repository.IPerimetreRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.perimetre;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class PerimetreExcluFacadeImplTest {

    @InjectMocks
    private PerimetreExcluFacadeImpl facade;

    @Mock
    private IPerimetreRepository repository;

    private Perimetre perimetre;

    private Perimetre expected;

    @BeforeEach
    void setUp() {
        perimetre = perimetre(0L, 13L, TypePerimetreEnum.PRODUIT, "RR01-001-LME", false,
                null, null, null, null, null, null);

        expected = perimetre(1L, 13L, TypePerimetreEnum.PRODUIT, "RR01-001-LME", false,
                null, null, null, null, null, null);

    }

    @AfterEach
    void tearDown() {
        perimetre = null;
        expected = null;
    }

    @Test
    void saving_perimetre_is_ok() {
        //GIVEN
        when(repository.find(any(Perimetre.class))).thenReturn(null);


        when(repository.save(any(Perimetre.class))).thenReturn(expected);

        //WHEN
        Perimetre actual = facade.save(perimetre);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void saving_perimetre_throws_exception() {
        //GIVEN
        when(repository.find(any(Perimetre.class))).thenReturn(expected);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.save(perimetre));
    }

    @Test
    void finding_perimetre_by_id_is_ok() {
        //GIVEN
        Optional<Perimetre> optPerimetre = Optional.of(expected);
        when(repository.findById(anyLong())).thenReturn(optPerimetre);

        //WHEN
        Perimetre actual = facade.findById(1L);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void finding_perimetre_by_id_is_throwing_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.findById(7L));
    }

    @Test
    void finding_perimetre_is_ok() {
        //GIVEN
        when(repository.find(any(Perimetre.class))).thenReturn(expected);

        //WHEN
        Perimetre actual = facade.find(perimetre);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void finding_perimetre_throws_exception() {
        //GIVEN
        when(repository.find(any(Perimetre.class))).thenReturn(null);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.find(perimetre));
    }

    @Test
    void updating_perimetre_is_ok() {
        //GIVEN
        Perimetre perimetre = perimetre(1L, 13L, TypePerimetreEnum.PRODUIT, "RR01-001-LME", false,
                null, null, null, null, null, null);

        Perimetre expected = perimetre(1L, 13L, TypePerimetreEnum.PRODUIT, "UPDATE", false,
                null, null, null, null, null, null);

        when(repository.findById(anyLong())).thenReturn(Optional.of(perimetre));
        when(repository.save(any(Perimetre.class))).thenReturn(expected);

        //WHEN
        Perimetre actual = facade.update(expected);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void updating_perimetre_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.update(expected));
    }

    @Test
    void deleted_perimetre_by_id_is_ok() {
        //GIVEN
        when(repository.findById(anyLong())).thenReturn(Optional.of(expected));
        doNothing().when(repository).deleteById(anyLong());

        //WHEN
        facade.delete(1L);

        //THEN
        verify(repository, times(1)).deleteById(anyLong());
    }

    @Test
    void deleted_perimetre_by_id_throws_exception() {
        //GIVEN
        when(repository.findById(anyLong())).thenThrow(PerimetreExcluException.class);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.delete(1L));
    }

    @Test
    void get_all_gives_all_perimetre_ecluded() {
        //GIVEN
        Set<Perimetre> expected = ParametrageProfilData
                .profils()
                .stream()
                .findFirst()
                .get()
                .getPerimetres()
                .stream()
                .filter(ps -> !Objects.isNull(ps.getIdParent()))
                .collect(Collectors.toSet());
        when(repository.findAll()).thenReturn(expected.stream().collect(Collectors.toList()));

        //WHEN
        Set<Perimetre> actual = facade.findAll();

        //THEN
        assertEquals(expected.size(), actual.size());
        assertThat(actual)
                .containsExactlyInAnyOrderElementsOf(expected);
    }

}