package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.ParametrageProfilData;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException;
import fr.ag2rlamondiale.paiementdigital.repository.IPerimetreRepository;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class RecupParamLABFacadeImplTest {

    @InjectMocks
    private RecupParamLABFacadeImpl recupParamLABFacade;

    @Mock
    private IProfilRepository profilRepository;

    @Mock
    private IPerimetreRepository perimetreRepository;

    private Profil profil, profil3;

    private RecupParamLAB recupParamLAB;

    private Set<Perimetre> exlusionsPerimetre, exlusionsPerimetre3;

    @BeforeEach
    void setUp() throws ParseException {
        profil = ParametrageProfilData.profils().stream().findFirst().get();
        profil3 = ParametrageProfilData.profils().stream().filter(p -> p.getId().equals(3L)).collect(Collectors.toList()).stream().findFirst().get();

        exlusionsPerimetre = profil
                .getPerimetres()
                .stream()
                .filter(ps -> !Objects.isNull(ps.getIdParent()))
                .collect(Collectors.toSet());

        exlusionsPerimetre3 = profil3
                .getPerimetres()
                .stream()
                .filter(ps -> !Objects.isNull(ps.getIdParent()))
                .collect(Collectors.toSet());

        recupParamLAB = RecupParamLAB
                .builder()
                .metier(profil.getMetier())
                .codeApplication(profil.getCodeApplication())
                .evenementMetier(profil.getEvenementMetier())
                .natureClient(profil.getNatureClient())
                .typeClient(profil.getTypeClient())
                .structureJuridique(ProfilConstantes.ARI)
                .filiale(ProfilConstantes.ACA)
                .produit(null)
                .contratDeReference(null)
                .contrat(null)
                .tiersPayeur(false)
                .dateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-08-05" ))
                .build();
    }

    @AfterEach
    void tearDown() {
        profil = null;
        recupParamLAB = null;
        exlusionsPerimetre = null;
    }

    @Test
    void no_profil_found_throws_exception() {
        //GIVEN
        when(profilRepository.find(any(Profil.class))).thenReturn(null);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void too_many_profils_found_throws_exception() {
        //GIVEN
        Profil profil2 = profil.copy(profil);
        profil2.setMetier("XXX");

        Set<Profil> profils = new HashSet<>(Arrays.asList(profil, profil2));

        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(TooManyProfilsException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void no_perimetre_found_throws_exception() {
        //GIVEN
        recupParamLAB.setFiliale("XXX");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void perimetre_is_found() {
        //GIVEN
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        Set<Perimetre> exlusions = exlusionsPerimetre
                .stream()
                .filter(e -> e.getIdParent() == 1L)
                .collect(Collectors.toSet());
        when(perimetreRepository.exclusions(anyLong())).thenReturn(exlusions);

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && date.before(perimetre.getDateFinEffet());
        assertTrue(result);
    }

    @Test
    void perimetre_excluded_throws_exception() {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-ACA");

        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        Set<Perimetre> exlusions = exlusionsPerimetre
                .stream()
                .filter(e -> e.getIdParent() == 1L)
                .collect(Collectors.toSet());
        when(perimetreRepository.exclusions(anyLong())).thenReturn(exlusions);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void perimetre_is_found_with_unknown_produit() {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-XXX");

        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        Set<Perimetre> exlusions = exlusionsPerimetre
                .stream()
                .filter(e -> e.getIdParent() == 1L)
                .collect(Collectors.toSet());
        when(perimetreRepository.exclusions(anyLong())).thenReturn(exlusions);

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && date.before(perimetre.getDateFinEffet());
        assertTrue(result);
    }

    @Test
    void perimetre_is_found_with_unknown_contrat() {
        //GIVEN
        recupParamLAB.setContrat("AAA");

        Set<Profil> profils = new HashSet<>(Arrays.asList(profil));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        Set<Perimetre> exlusions = exlusionsPerimetre
                .stream()
                .filter(e -> e.getIdParent() == 1L)
                .collect(Collectors.toSet());
        when(perimetreRepository.exclusions(anyLong())).thenReturn(exlusions);

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && date.before(perimetre.getDateFinEffet());
        assertTrue(result);
    }

    @Test
    void structure_juridique_excluded_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setStructureJuridique("AAA");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void filiale_excluded_by_date_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-12-12" ));
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void produit_excluded_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setProduit("RR01-003-ACN");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void perimetre_found_with_produit_correct_by_date() throws ParseException {
        //GIVEN
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-12-13" ));
        recupParamLAB.setProduit("RR01-003-ACN");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void contrat_excluded_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setContrat("RRE");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    void perimetre_found_with_contrat_correct_by_date() throws ParseException {
        //GIVEN
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-12-13" ));
        recupParamLAB.setContrat("RRE");
        Set<Profil> profils = new HashSet<>(Arrays.asList(profil3));
        when(profilRepository.find(any(Profil.class))).thenReturn(profils);

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

}