package fr.ag2rlamondiale.paiementdigital.bootstrap;

import fr.ag2rlamondiale.paiementdigital.domain.*;
import fr.ag2rlamondiale.paiementdigital.domain.type.*;

import java.util.*;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.*;
import static fr.ag2rlamondiale.paiementdigital.domain.type.MethodePaiementEnum.*;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.*;

public final class ParametrageProfilData {

    public static Set<Profil> profils() {

        PerimetrePlafond pp1Cb1 = perimetrePlafond(1L, 1L, CB.name());
        PerimetrePlafond pp1Visa1 = perimetrePlafond(1L, 1L, VISA.name());
        PerimetrePlafond pp1Mastercard1 = perimetrePlafond(1L, 1L, MASTERCARD.name());
        PerimetrePlafond pp1Cb2 = perimetrePlafond(1L, 2L, CB.name());
        PerimetrePlafond pp1Visa2 = perimetrePlafond(1L, 2L, VISA.name());
        PerimetrePlafond pp1Mastercard2 = perimetrePlafond(1L, 2L, MASTERCARD.name());
        PerimetrePlafond pp1Cb3 = perimetrePlafond(1L, 3L, CB.name());
        PerimetrePlafond pp1Visa3 = perimetrePlafond(1L, 3L, VISA.name());
        PerimetrePlafond pp1Mastercard3 = perimetrePlafond(1L, 3L, MASTERCARD.name());

        PerimetrePlafond pp2Cb1 = perimetrePlafond(2L, 3L, CB.name());
        PerimetrePlafond pp2Visa1 = perimetrePlafond(2L, 3L, VISA.name());
        PerimetrePlafond pp2Mastercard1 = perimetrePlafond(2L, 3L, MASTERCARD.name());

        PerimetrePlafond pp3Cb1 = perimetrePlafond(3L, 1L, CB.name());
        PerimetrePlafond pp3Visa1 = perimetrePlafond(3L, 1L, VISA.name());
        PerimetrePlafond pp3Mastercard1 = perimetrePlafond(3L, 1L, MASTERCARD.name());
        PerimetrePlafond pp3Cb2 = perimetrePlafond(3L, 2L, CB.name());
        PerimetrePlafond pp3Visa2 = perimetrePlafond(3L, 2L, VISA.name());
        PerimetrePlafond pp3Mastercard2 = perimetrePlafond(3L, 2L, MASTERCARD.name());
        PerimetrePlafond pp3Cb3 = perimetrePlafond(3L, 3L, CB.name());
        PerimetrePlafond pp3Visa3 = perimetrePlafond(3L, 3L, VISA.name());
        PerimetrePlafond pp3Mastercard3 = perimetrePlafond(3L, 3L, MASTERCARD.name());

        PerimetrePlafond pp4Cb1 = perimetrePlafond(4L, 3L, CB.name());
        PerimetrePlafond pp4Visa1 = perimetrePlafond(4L, 3L, VISA.name());
        PerimetrePlafond pp4Mastercard1 = perimetrePlafond(4L, 3L, MASTERCARD.name());

        PerimetrePlafond pp5Mastercard1 = perimetrePlafond(5L, 4L, MASTERCARD.name());
        PerimetrePlafond pp5Mastercard2 = perimetrePlafond(5L, 5L, MASTERCARD.name());
        PerimetrePlafond pp5Mastercard3 = perimetrePlafond(5L, 6L, MASTERCARD.name());

        PerimetrePlafond pp6Cb1 = perimetrePlafond(5L, 1L, CB.name());
        PerimetrePlafond pp6Visa1 = perimetrePlafond(5L, 1L, VISA.name());
        PerimetrePlafond pp6Cb2 = perimetrePlafond(5L, 2L, CB.name());
        PerimetrePlafond pp6Visa2 = perimetrePlafond(5L, 2L, VISA.name());
        PerimetrePlafond pp6Cb3 = perimetrePlafond(5L, 3L, CB.name());
        PerimetrePlafond pp6Visa3 = perimetrePlafond(5L, 3L, VISA.name());

        Plafond anneeCivile0_8000 = plafond(1L, TypeFrequenceEnum.ANNEE_CIVILE, 0f, 8000f, 999,
                new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1, pp3Cb1, pp3Visa1, pp3Mastercard1, pp6Cb1, pp6Visa1)));

        Plafond moisGlissant0_2500 = plafond(2L, TypeFrequenceEnum.MOIS_GLISSANT, 0f, 2500f, 999,
                new HashSet<>(Arrays.asList(pp1Cb2, pp1Visa2, pp1Mastercard2, pp3Cb2, pp3Visa2, pp3Mastercard2, pp6Cb2, pp6Visa2)));

        Plafond transaction0_2500 = plafond(3L, TypeFrequenceEnum.TRANSACTION, 0f, 2500f, 999,
                new HashSet<>(Arrays.asList(pp1Cb3, pp1Visa3, pp1Mastercard3, pp2Cb1, pp2Visa1, pp2Mastercard1, pp3Cb3, pp3Visa3, pp3Mastercard3, pp4Cb1, pp4Visa1, pp4Mastercard1, pp6Cb3, pp6Visa3)));

        Plafond transaction300_2500 = plafond(4L, TypeFrequenceEnum.TRANSACTION, 300f, 2500f, 999,
                new HashSet<>(Arrays.asList(pp5Mastercard1)));

        Plafond anneeCivile0_6000 = plafond(5L, TypeFrequenceEnum.ANNEE_CIVILE, 0f, 6000f, 12,
                new HashSet<>(Arrays.asList(pp5Mastercard2)));

        Plafond moisGlissant0_2000 = plafond(6L, TypeFrequenceEnum.MOIS_GLISSANT, 0f, 2000f, 2,
                new HashSet<>(Arrays.asList(pp5Mastercard3)));

        PerimetreInfos piAca1 = perimetreInfos(1L, ARI, ACA, null, null, null);
        PerimetreInfos piAca2 = perimetreInfos(2L, ARI, ACA, null, null, null);
        PerimetreInfos piAcn = perimetreInfos(3L, ARI, ACN, null, null, null);
        PerimetreInfos piLmr = perimetreInfos(4L, ARI, LMR, null, null, null);
        PerimetreInfos piLmo = perimetreInfos(5L, ARI, LMO, null, null, null);

        Perimetre aca1 = perimetre(1L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 10, 12),
                buildLongDate(2020, 10, 12), null,
                piAca1, new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1, pp1Cb2, pp1Visa2, pp1Mastercard2, pp1Cb3, pp1Visa3, pp1Mastercard3)));

        Perimetre aca2 = perimetre(2L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2021, 10, 12), null,
                buildLongDate(2021, 10, 12), null,
                piAca2, new HashSet<>(Arrays.asList(pp2Cb1, pp2Visa1, pp2Mastercard1)));

        Perimetre acn = perimetre(3L, null, TypePerimetreEnum.FILIALE, ACN, false,
                buildShortDate(2020, 10, 12), null,
                buildLongDate(2020, 10, 12), null,
                piAcn, new HashSet<>(Arrays.asList(pp3Cb1, pp3Visa1, pp3Mastercard1, pp3Cb2, pp3Visa2, pp3Mastercard2, pp3Cb3, pp3Visa3, pp3Mastercard3)));

        Perimetre lmr = perimetre(4L, null, TypePerimetreEnum.FILIALE, LMR, false,
                buildShortDate(2021, 12, 12), null,
                buildLongDate(2021, 12, 12), null,
                piLmr, new HashSet<>(Arrays.asList(pp4Cb1, pp4Visa1, pp4Mastercard1)));

        Perimetre lmo = perimetre(5L, null, TypePerimetreEnum.FILIALE, LMO, false,
                buildShortDate(2020, 10, 12), null,
                buildLongDate(2020, 10, 12), null,
                piLmo, new HashSet<>(Arrays.asList(pp5Mastercard1, pp5Mastercard2, pp5Mastercard3, pp6Cb1, pp6Visa1, pp6Cb2, pp6Visa2, pp6Cb3, pp6Visa3)));

        Perimetre aca1Exclu = perimetre(6L, 1L, TypePerimetreEnum.PRODUIT, "RR01-001-ACA", false,
                null, null, null, null, null, null);

        Perimetre aca2Exclu = perimetre(7L, 2L, TypePerimetreEnum.PRODUIT, "RR01-001-ACA", false,
                null, null, null, null, null, null);

        Perimetre acanExclu1 = perimetre(8L, 3L, TypePerimetreEnum.PRODUIT, "RR01-001-ACN", false,
                null, null, null, null, null, null);

        Perimetre acanExclu2 = perimetre(9L, 3L, TypePerimetreEnum.PRODUIT, "RR01-003-ACN", false,
                null, null, null, null, null, null);

        Profil profil1 = Profil.builder()
                .metier(RET_SUP_COL)
                .id(1L)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .perimetres(new HashSet<>(Arrays.asList(aca1, aca2, acn, lmr, lmo, aca1Exclu, aca2Exclu, acanExclu1, acanExclu2)))
                .build();

        Profil profil2 = Profil.builder()
                .id(2L)
                .metier(RET_SUP_IND)
                .codeApplication("A1335")
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .perimetres(new HashSet<>(Collections.emptyList()))
                .build();


        Perimetre aca1p3 = perimetre(99L, null, TypePerimetreEnum.FILIALE, ACA, false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 10, 12),
                buildLongDate(2021, 10, 12), null,
                piAca1, new HashSet<>(Arrays.asList(pp1Cb1, pp1Visa1, pp1Mastercard1, pp1Cb2, pp1Visa2, pp1Mastercard2, pp1Cb3, pp1Visa3, pp1Mastercard3)));

        Perimetre acanExclup31 = perimetre(9L, 99L, TypePerimetreEnum.PRODUIT, "RR01-003-ACN", false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 12, 12), null, null, null, null);

        Perimetre acanExclup32 = perimetre(10L, 99L, TypePerimetreEnum.CONTRAT, "RRE", false,
                buildShortDate(2020, 10, 12), buildShortDate(2021, 12, 12), null, null, null, null);

        Profil profil3 = Profil.builder()
                .metier(RET_SUP_COL)
                .id(3L)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .perimetres(new HashSet<>(Arrays.asList(aca1p3, acanExclup31, acanExclup32)))
                .build();

        return new LinkedHashSet<>(Arrays.asList(profil1, profil2, profil3));
    }

}
