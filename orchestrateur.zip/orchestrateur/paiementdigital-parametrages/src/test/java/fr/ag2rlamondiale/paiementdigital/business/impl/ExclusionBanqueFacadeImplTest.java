package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.bootstrap.ParametrageExclusionBanqueData;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.repository.IExclusionBanqueRepository;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.DUPLICATE_PAYS;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;


@ExtendWith(SpringExtension.class)
class ExclusionBanqueFacadeImplTest {

    @InjectMocks
    private ExclusionBanqueFacadeImpl facade;

    @Mock
    private IExclusionBanqueRepository repository;

    private static Set<ExclusionBanque> banques;

    private ExclusionBanque banque;

    @BeforeEach
    void setUp() {
        banques = ParametrageExclusionBanqueData.init();

        banque = ExclusionBanque
                .builder()
                .banque("BRED")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();
    }

    @AfterEach
    void tearDown() {
        banques = null;
        banque = null;
    }

    @Test
    void saving_banque_is_ok() {
        //GIVEN
        when(repository.save(any(ExclusionBanque.class))).thenReturn(banque);

        //WHEN
        ExclusionBanque actual = facade.save(banque);

        //THEN
        assertEquals(banque.getBanque(), actual.getBanque());
        assertEquals(banque.getDateCreation(), actual.getDateCreation());
        assertEquals(banque.getDateEffet(), actual.getDateEffet());
    }

    @Test
    void saving_banque_throws_exception() {
        //GIVEN
        when(repository.find(any(ExclusionBanque.class))).thenThrow(new ExclusionBanqueException(DUPLICATE_PAYS));

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.save(banque));
    }

    @Test
    void finding_banque_by_id_is_ok() {
        //GIVEN
        Optional<ExclusionBanque> optBanque = Optional.of(banque);
        when(repository.findById(anyString())).thenReturn(optBanque);

        //WHEN
        ExclusionBanque actual = facade.findById("LCL");

        //THEN
        assertEquals(banque.getBanque(), actual.getBanque());
        assertEquals(banque.getDateCreation(), actual.getDateCreation());
        assertEquals(banque.getDateEffet(), actual.getDateEffet());
    }

    @Test
    void finding_banque_by_id_is_throwing_exception() {
        //GIVEN
        when(repository.findById(anyString())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.findById("LCL"));
    }

    @Test
    void finding_banque_is_ok() {
        //GIVEN
        Set<ExclusionBanque> expected = new HashSet<>(Arrays.asList(banque));
        when(repository.find(any(ExclusionBanque.class))).thenReturn(expected);

        //WHEN
        Set<ExclusionBanque> actual = facade.find(banque);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    void finding_unknown_banque_throws_exception() {
        //GIVEN
        ExclusionBanque banque = ExclusionBanque
                .builder()
                .banque("UNNOWN")
                .build();
        when(repository.find(any(ExclusionBanque.class))).thenReturn(Collections.emptySet());

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.find(banque));
    }

    @Test
    void finding_banque_by_date_is_ok() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(2021, 2, 1);
        when(repository.find(any(Date.class))).thenReturn(banques);

        //WHEN
        Set<ExclusionBanque> actual = facade.find(dateRecherche);

        //THEN
        assertEquals(banques, actual);
    }

    @Test
    void finding_banque_by_older_date_gives_no_result() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(1789, 7, 14);
        when(repository.find(any(Date.class))).thenReturn(Collections.emptySet());

        //WHEN
        Set<ExclusionBanque> actual = facade.find(dateRecherche);

        //THEN
        assertEquals(Collections.EMPTY_SET, actual);
    }

    @Test
    void updating_banque_is_ok() {
        //GIVEN
        ExclusionBanque banque = ExclusionBanque
                .builder()
                .banque("NEW BRED")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        when(repository.findById(anyString())).thenReturn(Optional.of(banque));
        when(repository.save(any(ExclusionBanque.class))).thenReturn(banque);

        //WHEN
        ExclusionBanque actual = facade.update(banque);

        //THEN
        assertEquals(banque.getBanque(), actual.getBanque());
        assertEquals(banque.getDateCreation(), actual.getDateCreation());
        assertEquals(banque.getDateEffet(), actual.getDateEffet());
    }

    @Test
    void updating_banque_throws_exception() {
        //GIVEN
        banque.setBanque("NEW BRED");
        when(repository.findById(anyString())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.update(banque));
    }

    @Test
    void deleted_banque_by_id_is_ok() {
        //GIVEN
        when(repository.findById(anyString())).thenReturn(Optional.of(banque));
        doNothing().when(repository).deleteById(anyString());

        //WHEN
        facade.delete("LCL");

        //THEN
        verify(repository, times(1)).deleteById(anyString());
    }

    @Test
    void deleted_banque_by_id_throws_exception() {
        //GIVEN
        when(repository.findById(anyString())).thenReturn(Optional.empty());

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.delete("LCL"));
    }

    @Test
    void get_all_banques_gives_6_banques() {
        //GIVEN
        List<ExclusionBanque> expected = banques.stream().collect(Collectors.toList());
        when(repository.findAll()).thenReturn(expected);

        //WHEN
        Set<ExclusionBanque> actual = facade.findAll();

        //THEN
        assertEquals(6, actual.size());
        assertEquals(expected, actual.stream().collect(Collectors.toList()));
    }

}