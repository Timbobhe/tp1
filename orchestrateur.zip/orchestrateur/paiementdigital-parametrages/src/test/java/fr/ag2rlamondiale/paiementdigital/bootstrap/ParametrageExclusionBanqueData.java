package fr.ag2rlamondiale.paiementdigital.bootstrap;

import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class ParametrageExclusionBanqueData {

    public static Set<ExclusionBanque> init() {
        Set<ExclusionBanque> result = new HashSet<>();

        Date dateEffet = ParametrageUtils.buildShortDate(2021, 1, 1);
        Date dateCreation = ParametrageUtils.buildLongDate(2021, 1, 1);

        result.add(build("SGIB", dateEffet, dateCreation));
        result.add(build("CAIXA", dateEffet, dateCreation));
        result.add(build("CIC", dateEffet, dateCreation));
        result.add(build("HSBC", dateEffet, dateCreation));
        result.add(build("CA", dateEffet, dateCreation));
        result.add(build("POSTE", dateEffet, dateCreation));

        return result;
    }

    private static ExclusionBanque build(String banque, Date dateEffet, Date dateCreation) {
        return ExclusionBanque
                .builder()
                .banque(banque)
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();
    }
}
