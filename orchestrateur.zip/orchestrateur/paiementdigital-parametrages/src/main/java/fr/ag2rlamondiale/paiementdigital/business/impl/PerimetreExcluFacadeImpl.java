package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPerimetreExcluFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException;
import fr.ag2rlamondiale.paiementdigital.repository.IPerimetreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException.AUCUN_PERIMETRE_EXCLU_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException.DUPLICATE_PERIMETRE_EXCLU;

@Service
public class PerimetreExcluFacadeImpl implements IPerimetreExcluFacade {

    @Autowired
    private IPerimetreRepository repository;

    @Override
    public Perimetre save(Perimetre perimetre) {
        if (!Objects.isNull(repository.find(perimetre)))
            throw new PerimetreExcluException(DUPLICATE_PERIMETRE_EXCLU);

        return repository.save(perimetre);
    }

    @Override
    public Perimetre findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new PerimetreExcluException(AUCUN_PERIMETRE_EXCLU_TROUVE));
    }

    @Override
    public Perimetre find(Perimetre perimetre) {
        Perimetre result = repository.find(perimetre);

        if (Objects.isNull(result))
            throw new PerimetreExcluException(AUCUN_PERIMETRE_EXCLU_TROUVE);

        return result;
    }

    @Override
    public Perimetre update(Perimetre perimetre) {
        if (!repository.findById(perimetre.getId()).isPresent())
            throw new PerimetreExcluException(AUCUN_PERIMETRE_EXCLU_TROUVE);

        return repository.save(perimetre);
    }

    @Override
    public void delete(Long id) {
        if (!repository.findById(id).isPresent())
            throw new PerimetreExcluException(AUCUN_PERIMETRE_EXCLU_TROUVE);

        repository.deleteById(id);
    }

    @Override
    public Set<Perimetre> findAll() {
        return repository.findAll().stream().collect(Collectors.toSet());
    }
}
