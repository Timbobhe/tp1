package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Repository
public interface IPerimetreRepository extends JpaRepository<Perimetre, Long> {

    @Query("SELECT p FROM Perimetre p WHERE " +
            "p.typePerimetre = ?1 " +
            "and p.valeurPerimetre = ?2 " +
            "and (p.idParent = 0 or p.idParent is null)" +
            "and p.dateEffet <= CURRENT_DATE " +
            "and (p.dateFinEffet is null or p.dateFinEffet >= CURRENT_DATE) ")
    Perimetre find(TypePerimetreEnum typePerimetre, String valeurPerimetre);

    @Query("SELECT p FROM Perimetre p WHERE " +
            "p.typePerimetre = :#{#exclu.typePerimetre} " +
            "and p.valeurPerimetre = :#{#exclu.valeurPerimetre} " +
            "and p.idParent = :#{#exclu.idParent} " +
            "and p.idParent > 0")
    Perimetre find(Perimetre exclu);

    @Query("SELECT p FROM Perimetre p WHERE p.idParent = ?1")
    Set<Perimetre> exclusions(long idParent);

    @Query("SELECT p FROM Perimetre p WHERE p.idParent is not null")
    List<Perimetre> findAll();

    @Query("SELECT p FROM Perimetre p WHERE p.id = ?1 and p.idParent is not null")
    Optional<Perimetre> findById(Long id);
}
