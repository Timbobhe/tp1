/*
 * Cree le 16 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.business;

import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public interface IProfilFacade {

    Profil save(Profil profil);

    Profil findById(Long id);

    Set<Profil> find(Profil profil);

    Profil update(Profil profil);

    void delete(Long id);

    Set<Profil> findAll();

}

