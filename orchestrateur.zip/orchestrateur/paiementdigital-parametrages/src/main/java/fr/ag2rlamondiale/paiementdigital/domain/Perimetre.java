/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(exclude = {"profil"})
@ToString(exclude = {"profil"})
@Entity
@Table(name = "tbsd0prm")
public class Perimetre implements Serializable {

    private static final long serialVersionUID = 1273647090953799637L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqIdprm")
    @SequenceGenerator(name = "seqIdprm", sequenceName = "sd0prmq", allocationSize = 1)
    @Column(name = "idprm")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "idprf")
    private Profil profil;

    @Column(name = "idprmpar")
    private Long idParent;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Enumerated(EnumType.STRING)
    @Column(name = "typrm")
    private TypePerimetreEnum typePerimetre;

    @NotNull
    @Size(max = 30)
    @Column(name = "vaprm")
    private String valeurPerimetre;

    @NotNull
    @Column(name = "intiepai")
    private boolean tiersPayeur;

    @Temporal(TemporalType.DATE)
    @Column(name = "dteff")
    private Date dateEffet;

    @Temporal(TemporalType.DATE)
    @Column(name = "dtfineff")
    private Date dateFinEffet;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "tscre")
    private Date dateCreation;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "tsmaj")
    private Date dateModification;

    @OneToOne
    @PrimaryKeyJoinColumn
    private PerimetreInfos perimetreInfos;

    @OneToMany(mappedBy = "perimetre", fetch = FetchType.EAGER)
    @Builder.Default
    private Set<PerimetrePlafond> perimetrePlafonds = new HashSet<>();

}
