package fr.ag2rlamondiale.paiementdigital.utils;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetreInfos;
import fr.ag2rlamondiale.paiementdigital.domain.PerimetrePlafond;
import fr.ag2rlamondiale.paiementdigital.domain.Plafond;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Set;

public final class ParametrageUtils {

    private ParametrageUtils() {
    }

    public static Perimetre perimetre(Long id, Long idParent, TypePerimetreEnum typePerimetre, String valeurPerimetre, boolean tiersPayeur, Date dateEffet,
                                      Date dateFinEffet, Date dateCreation, Date dateModification, PerimetreInfos perimetreInfos,
                                      Set<PerimetrePlafond> perimetrePlafonds) {
        Perimetre perimetre = Perimetre
                .builder()
                .idParent(idParent)
                .typePerimetre(typePerimetre)
                .valeurPerimetre(valeurPerimetre)
                .tiersPayeur(tiersPayeur)
                .dateEffet(dateEffet)
                .dateFinEffet(dateFinEffet)
                .dateCreation(dateCreation)
                .dateModification(dateModification)
                .perimetreInfos(perimetreInfos)
                .perimetrePlafonds(perimetrePlafonds)
                .build();

        if (id != 0 || id == null)
            perimetre.setId(id);

        return perimetre;
    }

    public static PerimetreInfos perimetreInfos(String structureJuridique, String filiale, String produit,
                                                String contratDeReference, String contrat) {
        return PerimetreInfos
                .builder()
                .structureJuridique(structureJuridique)
                .filiale(filiale)
                .produit(produit)
                .contratDeReference(contratDeReference)
                .contrat(contrat)
                .build();
    }

    public static PerimetreInfos perimetreInfos(Long idPerimetre, String structureJuridique, String filiale, String produit,
                                                String contratDeReference, String contrat) {
        return PerimetreInfos
                .builder()
                .idprm(idPerimetre)
                .structureJuridique(structureJuridique)
                .filiale(filiale)
                .produit(produit)
                .contratDeReference(contratDeReference)
                .contrat(contrat)
                .build();
    }

    public static PerimetrePlafond perimetrePlafond(String methodePaiement) {
        return PerimetrePlafond
                .builder()
                .methodePaiement(methodePaiement)
                .build();
    }

    public static PerimetrePlafond perimetrePlafond(Long idPerimetre, Long idPlafond, String methodePaiement) {
        return PerimetrePlafond
                .builder()
                .idprm(idPerimetre)
                .idplf(idPlafond)
                .methodePaiement(methodePaiement)
                .build();
    }

    public static Plafond plafond(TypeFrequenceEnum typeFrequence, float montantMinimum, float montantMaximum, int nombreMaximumPaiement, Set<PerimetrePlafond> perimetrePlafonds) {
        return Plafond
                .builder()
                .typeFrequence(typeFrequence)
                .montantMinimum(montantMinimum)
                .montantMaximum(montantMaximum)
                .nombreMaximumPaiement(nombreMaximumPaiement)
                .perimetrePlafonds(perimetrePlafonds)
                .build();
    }

    public static Plafond plafond(Long idPlafond, TypeFrequenceEnum typeFrequence, float montantMinimum, float montantMaximum, int nombreMaximumPaiement, Set<PerimetrePlafond> perimetrePlafonds) {
        return Plafond
                .builder()
                .id(idPlafond)
                .typeFrequence(typeFrequence)
                .montantMinimum(montantMinimum)
                .montantMaximum(montantMaximum)
                .nombreMaximumPaiement(nombreMaximumPaiement)
                .perimetrePlafonds(perimetrePlafonds)
                .build();
    }

    public static java.sql.Date buildShortDate(int year, int month, int day) {
        return java.sql.Date.valueOf(LocalDate.of(year, month, day));
    }

    public static java.sql.Timestamp buildLongDate(int year, int month, int day) {
        return java.sql.Timestamp.valueOf(LocalDateTime.of(year, month, day, 0, 0, 0));
    }

    public static Date dateNowMinus1Month() {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate localDate = LocalDate.now().minusMonths(1);
        return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
    }

    public static Date dateNowMinus1Month(Date date) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate localDate = Instant
                .ofEpochMilli(date.getTime())
                .atZone(defaultZoneId)
                .toLocalDate().minusMonths(1);
        return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
    }

    public static Date dateNowMinusDays(long numberOfDays) {
        ZoneId defaultZoneId = ZoneId.systemDefault();
        LocalDate localDate = LocalDate.now().minusDays(numberOfDays);
        return Date.from(localDate.atStartOfDay(defaultZoneId).toInstant());
    }

    public static Date buildDate(int year, int month, int day) {
        Instant instant = LocalDateTime.of(year, month, day, 0, 0, 0)
                .atZone(ZoneId.systemDefault()).toInstant();
        return Date.from(instant);
    }

    public static String format(Date date, String format) {
        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern(format).withZone(ZoneId.systemDefault());
        return formatter.format(date.toInstant());
    }
}
