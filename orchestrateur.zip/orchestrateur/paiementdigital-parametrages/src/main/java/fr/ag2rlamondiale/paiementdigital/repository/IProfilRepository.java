/*
 * Cree le 16 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Set;

@Repository
public interface IProfilRepository extends JpaRepository<Profil, Long> {

    @Query("SELECT p FROM Profil p WHERE p.metier = :#{#profil.metier} " +
            "and p.codeApplication = :#{#profil.codeApplication} " +
            "and (:#{#profil.evenementMetier} is null or p.evenementMetier = :#{#profil.evenementMetier}) " +
            "and (:#{#profil.natureClient} is null or p.natureClient = :#{#profil.natureClient}) " +
            "and (:#{#profil.typeClient} is null or p.typeClient = :#{#profil.typeClient})")
    Set<Profil> find(@Param("profil") Profil profil);
}
