/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"perimetre"})
@ToString(exclude = {"perimetre"})
@IdClass(PerimetrePlafondID.class)
@Builder
@Entity
@Table(name = "tbsd0ppl")
public class PerimetrePlafond implements Serializable {

    private static final long serialVersionUID = -3795556259438117315L;

    @Id
    @NotNull
    @Size(max = 10)
    @Column(name = "tymthpai")
    private String methodePaiement;

    @Id
    private Long idprm;

    @Id
    private Long idplf;

    @ManyToOne
    @JoinColumn(name = "idprm", nullable = false, updatable = false)
    private Perimetre perimetre;

    @ManyToOne
    @JoinColumn(name = "idplf", nullable = false, updatable = false)
    private Plafond plafond;

}
