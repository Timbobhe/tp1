package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.repository.IExclusionBanqueRepository;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.Date;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException.AUCUNE_BANQUE_TROUVEE;
import static fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException.DUPLICATE_BANQUE;

@Service
@NoArgsConstructor
public class ExclusionBanqueFacadeImpl implements IExclusionBanqueFacade {

    @Autowired
    private IExclusionBanqueRepository repository;

    @Override
    public ExclusionBanque save(ExclusionBanque banque) {
        if (!CollectionUtils.isEmpty(repository.find(banque)))
            throw new ExclusionBanqueException(DUPLICATE_BANQUE);

        return repository.save(banque);
    }

    @Override
    public ExclusionBanque findById(String banque) {
        return repository.findById(banque)
                .orElseThrow(() -> new ExclusionBanqueException(AUCUNE_BANQUE_TROUVEE));
    }

    @Override
    public Set<ExclusionBanque> find(ExclusionBanque banque) {
        Set<ExclusionBanque> result = repository.find(banque);

        if (CollectionUtils.isEmpty(result))
            throw new ExclusionBanqueException(AUCUNE_BANQUE_TROUVEE);

        return result;
    }

    @Override
    public Set<ExclusionBanque> find(Date dateRecherche) {
        Set<ExclusionBanque> result = repository.find(dateRecherche);
        return CollectionUtils.isEmpty(result) ? Collections.emptySet() : result;
    }

    @Override
    public ExclusionBanque update(ExclusionBanque banque) {
        if (!repository.findById(banque.getBanque()).isPresent())
            throw new ExclusionBanqueException(AUCUNE_BANQUE_TROUVEE);

        return repository.save(banque);
    }

    @Override
    public void delete(String banque) {
        if (!repository.findById(banque).isPresent())
            throw new ExclusionBanqueException(AUCUNE_BANQUE_TROUVEE);

        repository.deleteById(banque);
    }

    @Override
    public Set<ExclusionBanque> findAll() {
        return repository.findAll().stream().collect(Collectors.toSet());
    }
}
