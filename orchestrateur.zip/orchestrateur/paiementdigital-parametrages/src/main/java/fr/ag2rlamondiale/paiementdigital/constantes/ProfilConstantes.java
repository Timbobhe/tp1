package fr.ag2rlamondiale.paiementdigital.constantes;

public final class ProfilConstantes {

    private ProfilConstantes() {
    }

    public static final String ACA = "ACA";

    public static final String ACN = "ACN";

    public static final String ARI = "ARI";

    public static final String LMR = "LMR";

    public static final String LMO = "LMO";

    public static final String ARP = "ARP";

    public static final String FDP = "FDP";

    public static final String LME = "LME";

    public static final String LM = "LM";

    public static final String RET_SUP_COL = "RET_SUP_COL";

    public static final String RET_SUP_IND = "RET_SUP_IND";

    public static final String A1573 = "A1573";
}
