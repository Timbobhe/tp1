package fr.ag2rlamondiale.paiementdigital.business;

import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import org.springframework.stereotype.Service;

@Service
public interface IRecupParamLABFacade {

    Perimetre find(RecupParamLAB recupParamLAB);

}
