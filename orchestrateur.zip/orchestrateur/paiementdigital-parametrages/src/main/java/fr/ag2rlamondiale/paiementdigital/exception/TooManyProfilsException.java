package fr.ag2rlamondiale.paiementdigital.exception;

public class TooManyProfilsException extends RuntimeException {

    private static final long serialVersionUID = -729026681848756270L;
    public static final String TOO_MANY_PROFILS = "Il y a plus d'un profil trouvé!";

    public TooManyProfilsException(String message) {
        super(message);
    }
}
