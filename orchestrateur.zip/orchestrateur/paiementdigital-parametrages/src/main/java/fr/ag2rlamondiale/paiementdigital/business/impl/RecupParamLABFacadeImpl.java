package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.ProfilException;
import fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException;
import fr.ag2rlamondiale.paiementdigital.repository.IPerimetreRepository;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum.*;
import static fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException.*;
import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.AUCUN_PROFIL_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException.TOO_MANY_PROFILS;

@Service
@Slf4j
public class RecupParamLABFacadeImpl implements IRecupParamLABFacade {

    @Autowired
    private IProfilRepository profilRepository;

    @Autowired
    private IPerimetreRepository perimetreRepository;

    @Override
    public Perimetre find(RecupParamLAB recupParamLAB) {
        log.info("Recherche d'un périmètre avec les données suivants RecupParamLAB(metrier = {}," +
                "codeApplication = {}, evenementMetier = {}, natureClient = {}, typeClient = {}, dateRecherche = {})",
                recupParamLAB.getMetier(),recupParamLAB.getCodeApplication(), recupParamLAB.getEvenementMetier(),
                recupParamLAB.getNatureClient(), recupParamLAB.getTypeClient(), recupParamLAB.getDateRecherche());


        log.debug("recupParamLAB {}.", recupParamLAB);

        Profil profil = buildProfil(recupParamLAB);

        Set<Profil> profils = profilRepository.find(profil);
        log.debug("Un ou plusieurs profils trouvés en base de données {}.", profils);

        if (CollectionUtils.isEmpty(profils))
            throw new NotFoundParameterValueException(PROFIL_NOT_FOUND);

        if (profils.size() > 1)
            throw new TooManyProfilsException(TOO_MANY_PROFILS);

        Profil profilFound = profils.stream().findFirst().orElseThrow(() -> new ProfilException(AUCUN_PROFIL_TROUVE));

        log.info("Un profil trouvé en base de données {}.", profilFound);

        log.debug("Liste des périmètres à tester {}.", profilFound.getPerimetres());

        List<Perimetre> perimetresFound = getSearchedPerimetre(profilFound, recupParamLAB);

        if (perimetresFound.size() == 1) {
            Optional<Perimetre> perimetre = perimetresFound.stream().findFirst();
            if (perimetre.isPresent())
                return perimetre.get();
        }

        throw new NotFoundParameterValueException(PROFIL_NOT_FOUND);
    }

    private List<Perimetre> getSearchedPerimetre(Profil profil, RecupParamLAB recupParamLAB) {

        Date date = recupParamLAB.getDateRecherche();

        List<Perimetre> perimetresStJuridiqueFound = checkStJuridique(profil, recupParamLAB);
        
        if(CollectionUtils.isEmpty(perimetresStJuridiqueFound))
            throw new NotFoundParameterValueException(PERIMETRE_NOT_FOUND_STRUCTURE_JURIDIQUE);

        log.debug("Un ou plusieurs perimetres trouvés en base de données pour la structure juridique recherchée {}, checking filiale.", recupParamLAB.getStructureJuridique());

        List<Perimetre> perimetresFound = checkFiliale(perimetresStJuridiqueFound, recupParamLAB, date);

        if(CollectionUtils.isEmpty(perimetresFound))
            throw new NotFoundParameterValueException(PERIMETRE_NOT_FOUND_FILIALE);

        log.debug("Un ou plusieurs perimetres trouvés en base de données pour la filiale recherchée {}, checking Produit.", recupParamLAB.getFiliale());

        List<Perimetre> perimetresFilialeExcluFound = checkPerimetresExcluParFiliale(profil.getPerimetres(), perimetresFound);

        boolean isProduitRechercheExclu = checkProduitExclu(perimetresFilialeExcluFound, recupParamLAB, date);

        if(isProduitRechercheExclu)
            throw new NotFoundParameterValueException(PERIMETRE_NOT_FOUND_PRODUIT);

        log.debug("Le produit recherché n'est pas exclu {}, checking Contrat.", recupParamLAB.getProduit());

        if(!Objects.isNull(recupParamLAB.getContrat()) && !recupParamLAB.getContrat().equalsIgnoreCase("")){

            boolean isContratRechercheExclu = checkContratExclu(perimetresFilialeExcluFound, recupParamLAB, date);

            if(isContratRechercheExclu)
                throw new NotFoundParameterValueException(PERIMETRE_NOT_FOUND_CONTRAT);
        }

        return  perimetresFound;
    }

    private boolean checkContratExclu(List<Perimetre> perimetresFilialeExcluFound, RecupParamLAB recupParamLAB, Date date) {
        return !perimetresFilialeExcluFound.stream()
                .filter(p ->
                        (p.getTypePerimetre().equals(CONTRAT) && p.getValeurPerimetre().equalsIgnoreCase(recupParamLAB.getContrat()))
                                && !Objects.isNull(p.getIdParent())
                                && (Objects.isNull(p.getDateEffet()) || date.after(p.getDateEffet()))
                                && (Objects.isNull(p.getDateFinEffet()) || date.before(p.getDateFinEffet()))).collect(Collectors.toList()).isEmpty();
    }

    private boolean checkProduitExclu(List<Perimetre> perimetresFilialeExcluFound, RecupParamLAB recupParamLAB, Date date) {
        return !perimetresFilialeExcluFound.stream()
                .filter(p ->
                        (p.getTypePerimetre().equals(PRODUIT) && p.getValeurPerimetre().equalsIgnoreCase(recupParamLAB.getProduit()))
                                && !Objects.isNull(p.getIdParent())
                                && (Objects.isNull(p.getDateEffet()) || date.after(p.getDateEffet()))
                                && (Objects.isNull(p.getDateFinEffet()) || date.before(p.getDateFinEffet()))).collect(Collectors.toList()).isEmpty();
    }

    private List<Perimetre> checkPerimetresExcluParFiliale(Set<Perimetre> perimetres, List<Perimetre> perimetresFilialeFound) {
        return perimetres.stream().filter( p ->
                perimetresFilialeFound.stream().anyMatch(pf ->
                            !Objects.isNull(p.getIdParent()) && pf.getId().equals(p.getIdParent()))
        ).collect(Collectors.toList());
    }

    private List<Perimetre> checkFiliale(List<Perimetre> perimetresStJuridiqueFound, RecupParamLAB recupParamLAB, Date date) {
      return  perimetresStJuridiqueFound.stream()
                .filter(p -> (
                        (p.getTypePerimetre().equals(FILIALE) && recupParamLAB.getFiliale().equals(p.getValeurPerimetre()))
                                && Objects.isNull(p.getIdParent())
                                && (
                                        Objects.isNull(p.getDateEffet()) && Objects.isNull(p.getDateFinEffet())
                                                ||  ((Objects.isNull(p.getDateEffet()) || date.after(p.getDateEffet()))
                                                && (Objects.isNull(p.getDateFinEffet()) || date.before(p.getDateFinEffet())))

                        ))).collect(Collectors.toList());
    }

    private List<Perimetre> checkStJuridique(Profil profil, RecupParamLAB recupParamLAB) {
        return profil.getPerimetres().stream()
                .filter(p -> (!Objects.isNull(p.getPerimetreInfos()) &&
                        p.getPerimetreInfos().getStructureJuridique().trim().equalsIgnoreCase(recupParamLAB.getStructureJuridique()))).collect(Collectors.toList());

    }

    private Profil buildProfil(RecupParamLAB recupParamLAB) {
        return Profil
                .builder()
                .metier(recupParamLAB.getMetier())
                .codeApplication(recupParamLAB.getCodeApplication())
                .evenementMetier(recupParamLAB.getEvenementMetier())
                .natureClient(recupParamLAB.getNatureClient())
                .typeClient(recupParamLAB.getTypeClient())
                .build();
    }

}
