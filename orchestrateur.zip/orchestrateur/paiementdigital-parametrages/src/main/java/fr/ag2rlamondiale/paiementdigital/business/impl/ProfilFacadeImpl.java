package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IProfilFacade;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.exception.ProfilException;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.AUCUN_PROFIL_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.exception.ProfilException.DUPLICATE_PROFIL;

@Service
@NoArgsConstructor
public class ProfilFacadeImpl implements IProfilFacade {

    @Autowired
    private IProfilRepository repository;

    @Override
    public Profil save(Profil profil) {
        if (!CollectionUtils.isEmpty(repository.find(profil)))
            throw new ProfilException(DUPLICATE_PROFIL);

        return repository.save(profil);
    }

    @Override
    public Profil findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ProfilException(AUCUN_PROFIL_TROUVE));
    }

    @Override
    public Set<Profil> find(Profil profil) {
        Set<Profil> result = repository.find(profil);

        if (CollectionUtils.isEmpty(result))
            throw new ProfilException(AUCUN_PROFIL_TROUVE);

        return result;
    }

    @Override
    public Profil update(Profil profil) {
        if (!repository.findById(profil.getId()).isPresent())
            throw new ProfilException(AUCUN_PROFIL_TROUVE);

        return repository.save(profil);
    }

    @Override
    public void delete(Long id) {
        if (!repository.findById(id).isPresent())
            throw new ProfilException(AUCUN_PROFIL_TROUVE);

        repository.deleteById(id);
    }

    @Override
    public Set<Profil> findAll() {
        return repository.findAll().stream().collect(Collectors.toSet());
    }

}
