package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.domain.PerimetreInfos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IPerimetreInfosRepository extends JpaRepository<PerimetreInfos, Long> {

}
