/*
 * Cree le 17 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.exception;

public class NotFoundParameterValueException extends RuntimeException {

    private static final long serialVersionUID = 3763148565258369034L;
    public static final String PROFIL_NOT_FOUND = "Profil introuvable avec les critères de recherche fournis!";
    public static final String PERIMETRE_NOT_FOUND = "Périmètre introuvable avec les critères de recherche fournis!";
    public static final String PERIMETRE_NOT_FOUND_STRUCTURE_JURIDIQUE = "Périmètre introuvable avec la structure juridique fournie!";
    public static final String PERIMETRE_NOT_FOUND_FILIALE = "Périmètre introuvable avec la filiale fournie!";
    public static final String PERIMETRE_NOT_FOUND_PRODUIT= "Périmètre exclu avec le produit fourni!";
    public static final String PERIMETRE_NOT_FOUND_CONTRAT = "Périmètre exclu avec le contrat fourni!";
    public static final String PERIMETRE_PLAFONDS_NOT_FOUND = "Aucuns modes de paiement ne correspond aux critères de recherche fournis!";
    public static final String INCLUSIONPAYS_NOT_FOUND = "Aucun pays trouvés avec les critères de recherche fournis!";
    public static final String EXCLUSIONBANQUES_NOT_FOUND = "Aucune banque exclue trouvée avec la date de recherche fournie!";


    public NotFoundParameterValueException(String message) {
        super(message);
    }
}
