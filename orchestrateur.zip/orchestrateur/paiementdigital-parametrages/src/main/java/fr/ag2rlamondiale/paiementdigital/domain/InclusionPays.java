/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Builder
@ToString
@Entity
@Table(name = "tbsd0inp")
public class InclusionPays implements Serializable {

    private static final long serialVersionUID = 4778097354609682110L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqIdinp")
    @SequenceGenerator(name = "seqIdinp", sequenceName = "sd0inpq", allocationSize = 1, initialValue = 1)
    @Column(name = "idinp")
    private Long id;

    @Size(max = 30)
    @Column(name = "tymet")
    private String metier;

    @NotNull
    @Size(min = 5, max = 5)
    @Column(name = "coapp")
    private String codeApplication;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Enumerated(EnumType.STRING)
    @Column(name = "typay")
    private TypePaysEnum typePays;

    @Size(max = 40)
    @Column(name = "lbpay")
    private String pays;

    @Size(max = 2)
    @Column(name = "coiso")
    private String codeIso;

    @Temporal(TemporalType.DATE)
    @Column(name = "dteff")
    private Date dateEffet;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "tscre")
    private Date dateCreation;

}
