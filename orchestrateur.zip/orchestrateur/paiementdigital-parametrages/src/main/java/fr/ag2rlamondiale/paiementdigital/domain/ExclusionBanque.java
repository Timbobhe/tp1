package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
@Builder
@ToString
@Entity
@Table(name = "tbsd0exb")
public class ExclusionBanque implements Serializable {

    private static final long serialVersionUID = 4882046579920799L;

    @Id
    @NotNull
    @Size(max = 45)
    @Column(name = "lbban")
    private String banque;

    @Temporal(TemporalType.DATE)
    @Column(name = "dteff")
    private Date dateEffet;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "tscre")
    private Date dateCreation;

}
