/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Set;

@Repository
public interface IInclusionPaysRepository extends JpaRepository<InclusionPays, Long> {

    @Query("SELECT ip FROM InclusionPays ip WHERE ip.metier = ?1 " +
            "and ip.codeApplication = ?2 " +
            "and ip.dateEffet <= ?3")
    Set<InclusionPays> find(String metier, String codeApplication, Date dateRecherche);

    @Query("SELECT ip FROM InclusionPays ip WHERE ip.metier = :#{#inclPays.metier} " +
            "and ip.codeApplication = :#{#inclPays.codeApplication} " +
            "and (:#{#inclPays.typePays} is null or ip.typePays = :#{#inclPays.typePays}) " +
            "and (:#{#inclPays.pays} is null or ip.pays = :#{#inclPays.pays}) " +
            "and (:#{#inclPays.codeIso} is null or ip.codeIso = :#{#inclPays.codeIso}) " +
            "and (:#{#inclPays.dateEffet} is null or ip.dateEffet = :#{#inclPays.dateEffet}) " +
            "and (:#{#inclPays.dateCreation} is null or ip.dateCreation = :#{#inclPays.dateCreation})")
    Set<InclusionPays> find(InclusionPays inclPays);
}
