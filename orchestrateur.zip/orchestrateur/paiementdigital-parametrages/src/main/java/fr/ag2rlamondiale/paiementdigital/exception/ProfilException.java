package fr.ag2rlamondiale.paiementdigital.exception;

public class ProfilException extends RuntimeException {

    private static final long serialVersionUID = -3153405609100576150L;

    public static final String AUCUN_PROFIL_TROUVE = "Aucun profil n'a été trouvé!";

    public static final String DUPLICATE_PROFIL = "Ce profil exise déjà!";

    public ProfilException(String message) {
        super(message);
    }
}
