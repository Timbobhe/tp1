/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@EqualsAndHashCode(exclude = {"perimetres"})
@ToString(exclude = {"perimetres"})
@Table(name = "tbsd0prf")
public class Profil implements Serializable {

    private static final long serialVersionUID = -4960427971472207346L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqIdprf")
    @SequenceGenerator(name = "seqIdprf", sequenceName = "sd0prfq", allocationSize = 1)
    @Column(name = "idprf")
    private Long id;

    @NotNull
    @Size(max = 30)
    @Column(name = "tymet")
    private String metier;

    @NotNull
    @Size(min = 5, max = 5)
    @Column(name = "coapp")
    private String codeApplication;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Enumerated(EnumType.STRING)
    @Column(name = "tyevemet")
    private TypeEvenementMetier evenementMetier;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Enumerated(EnumType.STRING)
    @Column(name = "tynatcli")
    private NatureClientEnum natureClient;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Enumerated(EnumType.STRING)
    @Column(name = "tycli")
    private TypeClientEnum typeClient;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "profil", cascade = CascadeType.ALL)
    @Builder.Default
    private Set<Perimetre> perimetres = new HashSet<>();

    public Profil copy(Profil profil) {
        return Profil.builder()
                .metier(profil.getMetier())
                .codeApplication(profil.getCodeApplication())
                .evenementMetier(profil.getEvenementMetier())
                .natureClient(profil.getNatureClient())
                .typeClient(profil.getTypeClient())
                .perimetres(profil.getPerimetres())
                .build();
    }
}
