package fr.ag2rlamondiale.paiementdigital.exception;

public class InclusionPaysException extends RuntimeException {

    private static final long serialVersionUID = 329419112821496965L;

    public static final String AUCUN_PAYS_TROUVE = "Aucun pays n'a été trouvé!";

    public static final String DUPLICATE_PAYS = "Ce pays exise déjà!";

    public InclusionPaysException(String message) {
        super(message);
    }
}
