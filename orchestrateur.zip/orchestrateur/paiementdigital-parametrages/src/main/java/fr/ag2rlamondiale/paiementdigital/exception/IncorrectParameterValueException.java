/*
 * Cree le 16 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.exception;

public class IncorrectParameterValueException extends RuntimeException {

    private static final long serialVersionUID = -5502857615366662095L;
    public static final String INCORRECT_REQUEST_PARAMETER_VALUE = "Un ou plusieurs paramètres d'entrée de la requête sont incorrectes ou manquants!";
    public static final String INPUT_NULL = "Un ou plusieurs paramètres d'entrée est null";

    public IncorrectParameterValueException(String message) {
        super(message);
    }
}
