package fr.ag2rlamondiale.paiementdigital.exception;

public class ExclusionBanqueException extends RuntimeException {

    private static final long serialVersionUID = -7538895188798679948L;

    public static final String AUCUNE_BANQUE_TROUVEE = "Aucune banque n'a été trouvée!";

    public static final String DUPLICATE_BANQUE = "Cette banque exise déjà!";

    public ExclusionBanqueException(String message) {
        super(message);
    }

}
