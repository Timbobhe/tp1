/*
 * Cree le 3 déc. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain.type;

public enum TypeClientEnum {
    CLIENT,
    TIERS,
    PROSPECT;
}
