/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.Column;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class PerimetrePlafondID implements Serializable {

    private static final long serialVersionUID = 4300768903250399427L;

    @Column(name = "tymthpai")
    private String methodePaiement;

    @Column(name = "idprm", insertable = false, nullable = false, updatable = false)
    private Long idprm;

    @Column(name = "idplf", insertable = false, nullable = false, updatable = false)
    private Long idplf;

}
