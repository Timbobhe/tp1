/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeFrequenceEnum;
import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"perimetrePlafonds"})
@ToString(exclude = {"perimetrePlafonds"})
@Builder
@Entity
@Table(name = "tbsd0plf")
public class Plafond implements Serializable {

    private static final long serialVersionUID = -5578742772700699095L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqIdplf")
    @SequenceGenerator(name = "seqIdplf", sequenceName = "sd0plfq", allocationSize = 1)
    @Column(name = "idplf")
    private Long id;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @NotNull
    @Enumerated(EnumType.STRING)
    @Column(name = "tyfrq")
    private TypeFrequenceEnum typeFrequence;

    @Column(name = "mtmin")
    private Float montantMinimum;

    @Column(name = "mtmax")
    private Float montantMaximum;

    @Column(name = "nbmax")
    private Integer nombreMaximumPaiement;

    @OneToMany(mappedBy = "plafond")
    @Builder.Default
    private Set<PerimetrePlafond> perimetrePlafonds = new HashSet<>();

}
