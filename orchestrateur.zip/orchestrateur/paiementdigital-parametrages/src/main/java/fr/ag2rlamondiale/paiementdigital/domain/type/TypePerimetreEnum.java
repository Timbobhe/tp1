/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain.type;

public enum TypePerimetreEnum {
    STRUCTURE_JURIDIQUE,
    FILIALE,
    PRODUIT,
    CONTRAT_DE_REFERENCE,
    CONTRAT;
}
