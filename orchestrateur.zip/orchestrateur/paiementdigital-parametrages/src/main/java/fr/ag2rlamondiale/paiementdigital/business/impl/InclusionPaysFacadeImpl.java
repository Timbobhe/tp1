package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.repository.IInclusionPaysRepository;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.Set;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.AUCUN_PAYS_TROUVE;
import static fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException.DUPLICATE_PAYS;
import static fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException.INCORRECT_REQUEST_PARAMETER_VALUE;
import static fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException.INCLUSIONPAYS_NOT_FOUND;

@Service
@Slf4j
@NoArgsConstructor
public class InclusionPaysFacadeImpl implements IInclusionPaysFacade {

    @Autowired
    private IInclusionPaysRepository repository;

    @Override
    public InclusionPays save(InclusionPays pays) {
        if (!CollectionUtils.isEmpty(repository.find(pays)))
            throw new ExclusionBanqueException(DUPLICATE_PAYS);

        return repository.save(pays);
    }

    @Override
    public Set<InclusionPays> find(String metier, String codeApplication, Date dateRecherche) {
        log.info("Recherche de la liste des pays autorisés avec les données suivants: {}, {}, {} .",
                metier, codeApplication, dateRecherche);
        if (StringUtils.isEmpty(metier) || StringUtils.isEmpty(codeApplication) || StringUtils.isEmpty(dateRecherche))
            throw new IncorrectParameterValueException(INCORRECT_REQUEST_PARAMETER_VALUE);

        Set<InclusionPays> result = repository.find(metier, codeApplication, dateRecherche);

        if (CollectionUtils.isEmpty(result))
            throw new NotFoundParameterValueException(INCLUSIONPAYS_NOT_FOUND);

        log.debug("Il y a {} pays paramétré(s).", result.size());
        return result;
    }

    @Override
    public Set<InclusionPays> find(InclusionPays pays) {
        Set<InclusionPays> result = repository.find(pays);

        if (CollectionUtils.isEmpty(result))
            throw new InclusionPaysException(AUCUN_PAYS_TROUVE);

        return result;
    }

    @Override
    public InclusionPays findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new InclusionPaysException(AUCUN_PAYS_TROUVE));
    }

    @Override
    public InclusionPays update(InclusionPays pays) {
        if (!repository.findById(pays.getId()).isPresent())
            throw new InclusionPaysException(AUCUN_PAYS_TROUVE);

        return repository.save(pays);
    }

    @Override
    public void delete(Long id) {
        if (!repository.findById(id).isPresent())
            throw new InclusionPaysException(AUCUN_PAYS_TROUVE);

        repository.deleteById(id);
    }

    @Override
    public Set<InclusionPays> findAll() {
        return repository.findAll().stream().collect(Collectors.toSet());
    }
}
