package fr.ag2rlamondiale.paiementdigital.exception;

public class ExclusionPerimetreException extends RuntimeException {

    private static final long serialVersionUID = 1332341345427563547L;
    public static final String PERIMETRE_EXCLUDED = "La valeur d'un des périmètres fournis est exclu!";

    public ExclusionPerimetreException(String message) {
        super(message);
    }
}
