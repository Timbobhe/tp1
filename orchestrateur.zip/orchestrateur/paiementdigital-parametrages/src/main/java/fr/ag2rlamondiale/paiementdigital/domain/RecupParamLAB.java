package fr.ag2rlamondiale.paiementdigital.domain;

import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecupParamLAB {

    private String metier;

    private String codeApplication;

    private TypeEvenementMetier evenementMetier;

    private NatureClientEnum natureClient;

    private TypeClientEnum typeClient;

    private String structureJuridique;

    private String filiale;

    private String produit;

    private String contratDeReference;

    private String contrat;

    private boolean tiersPayeur;

    private Date dateRecherche;
}
