/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain.type;

public enum TypePaysEnum {
    RESIDENCE,
    RESIDENCE_FISCALE,
    DOMICILIATION_BANCAIRE;
}
