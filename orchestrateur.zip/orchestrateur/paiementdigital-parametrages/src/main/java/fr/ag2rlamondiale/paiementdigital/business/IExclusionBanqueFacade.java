/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.business;

import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Set;

@Service
public interface IExclusionBanqueFacade {

    ExclusionBanque save(ExclusionBanque banque);

    ExclusionBanque findById(String banque);

    Set<ExclusionBanque> find(ExclusionBanque banque);

    Set<ExclusionBanque> find(Date dateRecherche);

    ExclusionBanque update(ExclusionBanque banque);

    void delete(String banque);

    Set<ExclusionBanque> findAll();

}
