/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.business;

import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Set;

@Service
public interface IInclusionPaysFacade {

    InclusionPays save(InclusionPays pays);

    Set<InclusionPays> find(String metier, String codeApplication, Date dateRecherche);

    Set<InclusionPays> find(InclusionPays pays);

    InclusionPays findById(Long id);

    InclusionPays update(InclusionPays pays);

    void delete(Long id);

    Set<InclusionPays> findAll();

}
