/*
 * Cree le 13 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.domain;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"perimetre"})
@ToString(exclude = {"perimetre"})
@Builder
@Entity
@Table(name = "tbsd0pdt")
public class PerimetreInfos implements Serializable {

    private static final long serialVersionUID = -6899730849864195050L;

    @Id
    @Column(name = "idprm")
    private Long idprm;

    @MapsId
    @OneToOne
    @JoinColumn(name = "idprm")
    private Perimetre perimetre;

    @Size(max = 3)
    @Column(name = "costrjur")
    private String structureJuridique;

    @Size(max = 3)
    @Column(name = "cofil")
    private String filiale;

    @Size(max = 30)
    @Column(name = "coprd")
    private String produit;

    @Size(max = 30)
    @Column(name = "idctr")
    private String contratDeReference;

    @Size(max = 30)
    @Column(name = "idctrref")
    private String contrat;

}
