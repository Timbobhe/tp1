package fr.ag2rlamondiale.paiementdigital.exception;

public class PerimetreExcluException extends RuntimeException {

    private static final long serialVersionUID = 2168889224924299839L;

    public static final String AUCUN_PERIMETRE_EXCLU_TROUVE = "Aucun périmètre exclu n'a été trouvé!";

    public static final String DUPLICATE_PERIMETRE_EXCLU = "Ce périmètre exclu exise déjà!";

    public PerimetreExcluException(String message) {
        super(message);
    }
}
