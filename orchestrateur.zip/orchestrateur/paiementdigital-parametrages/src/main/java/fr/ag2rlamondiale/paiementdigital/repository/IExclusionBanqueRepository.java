/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.Optional;
import java.util.Set;

@Repository
public interface IExclusionBanqueRepository extends JpaRepository<ExclusionBanque, String> {

    @Query("SELECT eb FROM ExclusionBanque eb WHERE eb.banque = :#{#exclusionBanque.banque} " +
            "and (:#{#exclusionBanque.dateEffet} is null or eb.dateEffet = :#{#exclusionBanque.dateEffet}) " +
            "and (:#{#exclusionBanque.dateCreation} is null or eb.dateCreation = :#{#exclusionBanque.dateCreation})")
    Set<ExclusionBanque> find(ExclusionBanque exclusionBanque);

    @Query("SELECT eb FROM ExclusionBanque eb WHERE eb.dateEffet <= ?1")
    Set<ExclusionBanque> find(Date dateRecherche);

    @Query("SELECT eb FROM ExclusionBanque eb WHERE eb.banque = ?1")
    Optional<ExclusionBanque> findById(String banque);

    @Modifying
    @Query("DELETE FROM ExclusionBanque eb WHERE eb.banque = ?1")
    void deleteById(String banque);
}
