package fr.ag2rlamondiale.paiementdigital.domain.type;

public enum NatureClientEnum {
    PP,
    PM;
}
