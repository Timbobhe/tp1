package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IExclusionBanqueFacade;
import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.repository.IExclusionBanqueRepository;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;
import java.util.stream.Collectors;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class ExclusionBanqueFacadeImplIT {

    @Autowired
    private IExclusionBanqueFacade facade;

    @Autowired
    private IExclusionBanqueRepository repository;

    private ExclusionBanque banque;

    @BeforeEach
    public void setUp() {
        banque = ExclusionBanque
                .builder()
                .banque("BRED")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();
    }

    @AfterEach
    public void tearDown() {
        banque = null;
    }

    @Test
    public void saving_banque_is_ok() {
        //WHEN
        ExclusionBanque actual = facade.save(banque);

        //THEN
        assertEquals(banque.getBanque(), actual.getBanque());
        assertEquals(banque.getDateCreation(), actual.getDateCreation());
        assertEquals(banque.getDateEffet(), actual.getDateEffet());
    }

    @Test
    public void saving_banque_throws_exception() {
        //GIVEN
        String banque = repository.findAll().stream().findFirst().get().getBanque();
        ExclusionBanque expected = repository.findById(banque).get();

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.save(expected));
    }

    @Test
    public void finding_banque_by_id_is_ok() {
        //GIVEN
        String banque = repository.findAll().stream().findFirst().get().getBanque();
        ExclusionBanque expected = repository.findById(banque).get();

        //WHEN
        ExclusionBanque actual = facade.findById(expected.getBanque());

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void finding_banque_is_ok() {
        //GIVEN
        ExclusionBanque eb = repository.save(banque);
        Set<ExclusionBanque> expected = new HashSet<>(Arrays.asList(eb));

        //WHEN
        Set<ExclusionBanque> actual = facade.find(banque);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    public void finding_unknown_banque_throws_exception() {
        //GIVEN
        ExclusionBanque banque = ExclusionBanque
                .builder()
                .banque("UNNOWN")
                .build();

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.find(banque));
    }

    @Test
    void finding_banque_by_date_is_ok() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(2021, 2, 1);
        Set<ExclusionBanque> expected = repository.find(dateRecherche);

        //WHEN
        Set<ExclusionBanque> actual = facade.find(dateRecherche);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    void finding_banque_by_older_date_gives_no_result() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(1789, 7, 14);

        //WHEN
        Set<ExclusionBanque> actual = facade.find(dateRecherche);

        //THEN
        assertEquals(Collections.EMPTY_SET, actual);
    }

    @Test
    public void updating_banque_is_ok() {
        //GIVEN
        ExclusionBanque eb = repository.save(banque);
        Date date = new Date();
        eb.setDateEffet(date);

        //WHEN
        ExclusionBanque actual = facade.update(eb);

        //THEN
        assertEquals(date, actual.getDateEffet());
        assertEquals(eb, actual);
    }

    @Test
    public void updating_banque_throws_exception() {
        //GIVEN
        ExclusionBanque banque = ExclusionBanque
                .builder()
                .banque("NEW BRED")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.update(banque));
    }

    @Test
    public void deleted_banque_by_id_is_ok() {
        //GIVEN
        ExclusionBanque expected = repository.findById("N26 Bank GmbH").get();

        //WHEN
        facade.delete(expected.getBanque());

        //THEN
        assertEquals(Optional.empty(), repository.findById(expected.getBanque()));
        assertEquals(0, repository.count());
    }


    @Test
    public void deleted_banque_by_id_throws_exception() {
        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.delete("UNKNOWN"));
    }

    @Test
    public void get_all_banques_gives_1_banque() {
        //GIVEN
        List<ExclusionBanque> expected = repository.findAll();

        //WHEN
        Set<ExclusionBanque> actual = facade.findAll();

        //THEN
        assertEquals(1, actual.size());
        assertThat(expected).hasSameElementsAs(actual.stream().collect(Collectors.toList()));
    }
}
