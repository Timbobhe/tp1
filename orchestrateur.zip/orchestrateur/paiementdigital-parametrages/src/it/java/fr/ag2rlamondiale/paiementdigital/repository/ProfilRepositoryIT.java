package fr.ag2rlamondiale.paiementdigital.repository;


import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.CollectionUtils;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class ProfilRepositoryIT {

    @Autowired
    private IProfilRepository profilRepository;

    private Profil profil;

    private Profil request;

    @BeforeEach
    public void setUp() {
        profil = profilRepository.findAll().get(0);

        request = Profil.builder()
                .metier(profil.getMetier())
                .codeApplication(profil.getCodeApplication())
                .evenementMetier(profil.getEvenementMetier())
                .natureClient(profil.getNatureClient())
                .typeClient(profil.getTypeClient())
                .build();
    }

    @AfterEach
    public void tearDown() {
        profil = null;
        request = null;
    }

    @Test
    public void profil_with_all_fields_gives_profil_as_result() {
        //WHEN
        Set<Profil> profils = profilRepository.find(request);

        //THEN
        assertEquals(1, profils.size());
        assertEquals(1,
                profils
                        .stream()
                        .filter(p ->
                                p.getMetier().equals(profil.getMetier())
                                        && p.getCodeApplication().equals(profil.getCodeApplication())
                                        && p.getEvenementMetier().equals(profil.getEvenementMetier()))
                        .count());
    }

    @Test
    public void profil_with_only_mandatories_fields_gives_profil_as_result() {
        //GIVEN
        request.setNatureClient(null);
        request.setTypeClient(null);

        //WHEN
        Set<Profil> profils = profilRepository.find(request);

        //THEN
        assertEquals(1, profils.size());
        assertEquals(1,
                profils
                        .stream()
                        .filter(p ->
                                p.getMetier().equals(profil.getMetier())
                                        && p.getCodeApplication().equals(profil.getCodeApplication())
                                        && p.getEvenementMetier() == profil.getEvenementMetier())
                        .count());
    }

    @Test
    public void unknown_metier_profil_gives_no_result() {
        //GIVEN
        request.setMetier("UNKNOWN");

        //WHEN
        Set<Profil> profils = profilRepository.find(request);

        //THEN
        assertTrue(CollectionUtils.isEmpty(profils));
    }

    @Test
    public void unknown_codeapplication_profil_gives_no_result() {
        //GIVEN
        request.setCodeApplication("UNKNOWN");

        //WHEN
        Set<Profil> profils = profilRepository.find(request);

        //THEN
        assertTrue(CollectionUtils.isEmpty(profils));
    }

    @Test
    public void no_profil_found_with_natureclient_and_representant() {
        //GIVEN
        request.setNatureClient(NatureClientEnum.PM);
        request.setTypeClient(TypeClientEnum.CLIENT);

        //WHEN
        Set<Profil> profils = profilRepository.find(request);

        //THEN
        assertTrue(CollectionUtils.isEmpty(profils));
    }

//    @Test
//    public void many_profils_found_with_only_mandatories_fields_in_request(){
//        //GIVEN
//        Profil profil = Profil.builder()
//                .metier("XXX")
//                .codeApplication(A1573)
//                .evenementMetier(TypeEvenementMetier.VRLI)
//                .typeClient(TypeClientEnum.PROSPECT)
//                .natureClient(NatureClientEnum.PM)
//                .build();
//
//        //WHEN
//        Set<Profil> profils = profilRepository.find(profil);
//
//        //THEN
//        assertEquals(2,
//                profils
//                        .stream()
//                        .filter( p ->
//                                p.getMetier().equals(profil.getMetier())
//                                && p.getCodeApplication().equals(profil.getCodeApplication())
//                                && p.getEvenementMetier().equals(profil.getEvenementMetier()))
//                        .count());
//    }
}
