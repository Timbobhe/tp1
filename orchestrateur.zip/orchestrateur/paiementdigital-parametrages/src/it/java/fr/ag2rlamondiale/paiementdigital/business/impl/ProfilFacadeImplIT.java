package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IProfilFacade;
import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.domain.type.NatureClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeClientEnum;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypeEvenementMetier;
import fr.ag2rlamondiale.paiementdigital.exception.ProfilException;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.A1573;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.RET_SUP_COL;
import static org.junit.jupiter.api.Assertions.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
class ProfilFacadeImplIT {

    @Autowired
    private IProfilFacade facade;

    @Autowired
    private IProfilRepository repository;

    @BeforeEach
    public void setUp() {

    }

    @Test
    public void saving_profil_is_ok() {
        //GIVEN
        Profil profil = Profil.builder()
                .metier("METIER")
                .codeApplication("A1111")
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PM)
                .typeClient(TypeClientEnum.PROSPECT)
                .perimetres(Collections.emptySet())
                .build();

        //WHEN
        Profil actual = facade.save(profil);

        //THEN
        assertEquals(3, repository.count());
        assertEquals("METIER", actual.getMetier());
    }

    @Test
    public void saving_profil_throws_exception() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        Profil profil = repository.findById(id).get();

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.save(profil));
    }

    @Test
    public void finding_profil_by_id_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();

        //WHEN
        Profil actual = facade.findById(id);

        //THEN
        assertNotNull(actual);
    }

    @Test
    public void finding_profil_by_id_is_throwing_exception() {
        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.findById(10000L));
    }

    @Test
    public void finding_profil_is_ok() {
        //GIVEN
        Profil profil = Profil.builder()
                .metier(RET_SUP_COL)
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PP)
                .typeClient(TypeClientEnum.CLIENT)
                .build();

        //WHEN
        Set<Profil> actual = facade.find(profil);

        //THEN
        assertEquals(1, actual.stream().filter(p -> p.getMetier().equalsIgnoreCase(profil.getMetier())).count());
    }

    @Test
    public void finding_profil_throws_exception() {
        //GIVEN
        Profil profil = Profil.builder()
                .id(100000L)
                .metier("UNKNOWN")
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PM)
                .typeClient(TypeClientEnum.TIERS)
                .build();

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.find(profil));
    }

    @Test
    public void updating_profil_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        Profil profil = repository.findById(id).get();
        profil.setCodeApplication("A1111");

        //WHEN
        Profil actual = facade.update(profil);

        //THEN
        assertEquals(profil, actual);
    }

    @Test
    public void updating_profil_throws_exception() {
        //GIVEN
        Profil profil = Profil.builder()
                .id(100000L)
                .metier("XXX")
                .codeApplication(A1573)
                .evenementMetier(TypeEvenementMetier.VRLI)
                .natureClient(NatureClientEnum.PM)
                .typeClient(TypeClientEnum.TIERS)
                .build();

        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.update(profil));
    }

    @Test
    public void deleted_profil_by_id_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();

        //WHEN
        facade.delete(id);

        //THEN
        assertEquals(Optional.empty(), repository.findById(id));
    }

    @Test
    public void deleted_profil_throws_exception() {
        //WHEN THEN
        assertThrows(ProfilException.class, () -> facade.delete(1000000L));
    }

    @Test
    public void get_all_profils_gives_2_profils() {
        //WHEN
        Set<Profil> actual = facade.findAll();

        //THEN
        assertEquals(2, actual.size());
    }

}