package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IInclusionPaysFacade;
import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.exception.ExclusionBanqueException;
import fr.ag2rlamondiale.paiementdigital.exception.InclusionPaysException;
import fr.ag2rlamondiale.paiementdigital.exception.IncorrectParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.repository.IInclusionPaysRepository;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.RET_SUP_COL;
import static fr.ag2rlamondiale.paiementdigital.domain.type.TypePaysEnum.DOMICILIATION_BANCAIRE;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class InclusionPaysFacadeImplIT {

    @Autowired
    private IInclusionPaysFacade facade;

    @Autowired
    private IInclusionPaysRepository repository;

    private String codeApplication;

    private Date dateRecherche;

    @BeforeEach
    public void setUp() {
        codeApplication = "A1573";
        dateRecherche = new Date();
    }

    @AfterEach
    public void tearDown() {
        codeApplication = null;
        dateRecherche = null;
    }

    @Test
    void finding_inclusion_pays_with_null_metier_parameter_throws_incorrectparametervalueexception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> facade.find(null, codeApplication, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_null_codeApplication_parameter_throws_incorrectparametervalueexception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class, () -> facade.find(RET_SUP_COL, null, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_null_dateRecherche_parameter_throws_incorrectparametervalueexception() {
        //WHEN THEN
        assertThrows(IncorrectParameterValueException.class,
                () -> facade.find(RET_SUP_COL, codeApplication, null));
    }

    @Test
    void unknown_parameters_throws_notfoundparametervalueexception() {
        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class,
                () -> facade.find("UNKNOWN", codeApplication, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_unknown_codeApplication_parameter_gives_empty_list() {
        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class,
                () -> facade.find(RET_SUP_COL, "UNKNOWN", dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_dateRecherche_parameter_before_date_effet_gives_empty_list() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(1789, 7, 14);
        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class,
                () -> facade.find(RET_SUP_COL, codeApplication, dateRecherche));
    }

    @Test
    void finding_inclusion_pays_with_parameters_gives_list_all_inclusion_pays() {
        //WHEN
        Set<InclusionPays> result = facade.find(RET_SUP_COL, codeApplication, dateRecherche);
        //THEN
        assertEquals(repository.count(), result.size());
    }

    @Test
    void finding_inclusion_pays_with_parameters_gives_list_inclusion_pays_with_one_element() {
        //GIVEN
        Date dateEffet = ParametrageUtils.buildShortDate(2020, 12, 1);
        Date dateCreation = ParametrageUtils.buildLongDate(2020, 12, 1);

        InclusionPays ip = InclusionPays
                .builder()
                .metier("A00")
                .codeApplication("A0000")
                .typePays(DOMICILIATION_BANCAIRE)
                .pays("Mars")
                .codeIso("MX")
                .dateEffet(dateEffet)
                .dateCreation(dateCreation)
                .build();

        repository.save(ip);

        //WHEN
        Set<InclusionPays> result = facade.find("A00", "A0000", new Date());

        //THEN
        assertEquals(1, result.size());
        assertEquals(1, result
                .stream()
                .filter(v -> v.getTypePays().equals(DOMICILIATION_BANCAIRE)
                        && ip.getPays().equals("Mars")
                        && ip.getCodeIso().equals("MX")).count());
    }

    @Test
    void finding_inclusion_pays_with_date_in_between_gives_list_inclusion_pays_with_3_elements() {
        //GIVEN
        dateRecherche = ParametrageUtils.buildShortDate(2020, 12, 31);

        //WHEN
        Set<InclusionPays> result = facade.find(RET_SUP_COL, codeApplication, dateRecherche);
        //THEN
        assertEquals(29, result.size());
    }

    @Test
    public void saving_pays_is_ok() {
        //WHEN
        InclusionPays expected = InclusionPays
                .builder()
                .metier("A00")
                .codeApplication("A0000")
                .typePays(DOMICILIATION_BANCAIRE)
                .pays("Chine")
                .codeIso("CH")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        InclusionPays actual = facade.save(expected);

        //THEN
        assertNotNull(actual.getId());
        assertEquals(expected.getPays(), actual.getPays());
        assertEquals(expected.getDateCreation(), actual.getDateCreation());
        assertEquals(expected.getDateEffet(), actual.getDateEffet());
    }

    @Test
    public void saving_pays_throws_exception() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        InclusionPays pays = repository.findById(id).get();

        //WHEN THEN
        assertThrows(ExclusionBanqueException.class, () -> facade.save(pays));
    }

    @Test
    public void finding_pays_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        InclusionPays pays = repository.findById(id).get();
        Set<InclusionPays> expected = new HashSet<>(Arrays.asList(pays));

        //WHEN
        Set<InclusionPays> actual = facade.find(pays);

        //THEN
        assertThat(actual).hasSameElementsAs(expected);
    }

    @Test
    public void finding_pays_throws_exception() {
        //GIVEN
        InclusionPays pays = InclusionPays
                .builder()
                .metier("UNKNOWN")
                .codeApplication("A0000")
                .typePays(DOMICILIATION_BANCAIRE)
                .pays("Chine")
                .codeIso("CHN")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.find(pays));
    }

    @Test
    public void finding_pays_by_id_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        InclusionPays expected = repository.findById(id).get();

        //WHEN
        InclusionPays actual = facade.findById(id);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void finding_pays_by_id_is_throwing_exception() {
        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.findById(7000L));
    }

    @Test
    public void updating_pays_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        InclusionPays expected = repository.findById(id).get();
        expected.setCodeApplication("B1435");

        //WHEN
        InclusionPays actual = facade.update(expected);

        //THEN
        assertEquals("B1435", actual.getCodeApplication());
        assertEquals(expected, actual);
    }

    @Test
    public void updating_pays_throws_exception() {
        //GIVEN
        InclusionPays pays = InclusionPays
                .builder()
                .id(1000L)
                .metier("UNKNOWN")
                .codeApplication("A0000")
                .typePays(DOMICILIATION_BANCAIRE)
                .pays("Chine")
                .codeIso("CHN")
                .dateEffet(ParametrageUtils.buildShortDate(2021, 1, 1))
                .dateCreation(ParametrageUtils.buildLongDate(2021, 1, 1))
                .build();

        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.update(pays));
    }

    @Test
    public void deleted_pays_by_id_is_ok() {
        //GIVEN
        Long id = repository.findAll().stream().max(Comparator.comparing(b -> b.getId())).get().getId();
        InclusionPays expected = repository.findById(id).get();

        //WHEN
        facade.delete(id);

        //THEN
        assertNotNull(expected);
        assertEquals(Optional.empty(), repository.findById(id));
    }

    @Test
    public void deleted_pays_by_id_throws_exception() {
        //WHEN THEN
        assertThrows(InclusionPaysException.class, () -> facade.delete(1000L));
    }

    @Test
    public void get_all_pays_gives_6_pays() {
        //GIVEN
        List<InclusionPays> expected = repository.findAll();

        //WHEN
        Set<InclusionPays> actual = facade.findAll();

        //THEN
        assertEquals(29, actual.size());
        assertThat(expected).hasSameElementsAs(actual.stream().collect(Collectors.toList()));
    }
}
