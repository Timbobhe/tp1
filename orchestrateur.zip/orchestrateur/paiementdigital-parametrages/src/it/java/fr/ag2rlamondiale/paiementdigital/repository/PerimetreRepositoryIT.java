package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.CollectionUtils;

import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.ACA;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.ACN;
import static org.junit.jupiter.api.Assertions.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class PerimetreRepositoryIT {

    @Autowired
    private IPerimetreRepository repository;

    @Test
    public void unknown_perimetre_not_found() {
        //WHEN
        Perimetre actual = repository.find(TypePerimetreEnum.CONTRAT_DE_REFERENCE, "XXXXX");

        //THEN
        assertNull(actual);
    }

    @Test
    public void perimetre_is_found() {
        //WHEN
        Perimetre actual = repository.find(TypePerimetreEnum.FILIALE, ACA);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, actual.getTypePerimetre());
        assertEquals(ACA, actual.getValeurPerimetre());
    }

    @Test
    public void unknown_excluded_perimetre_is_found() {
        //WHEN
        Set<Perimetre> actual = repository.exclusions(10000000L);

        //THEN
        assertTrue(CollectionUtils.isEmpty(actual));
    }

    @Test
    public void excluded_perimetre_is_found() {
        //GIVEN
        Perimetre acn = repository.find(TypePerimetreEnum.FILIALE, ACN);

        //WHEN
        Set<Perimetre> actual = repository.exclusions(acn.getId());

        //THEN
        assertEquals(2, actual.size());
    }
}
