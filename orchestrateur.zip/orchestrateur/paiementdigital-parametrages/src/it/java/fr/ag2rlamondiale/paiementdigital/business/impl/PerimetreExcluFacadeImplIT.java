package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IPerimetreExcluFacade;
import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.exception.PerimetreExcluException;
import fr.ag2rlamondiale.paiementdigital.repository.IPerimetreRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Collections;
import java.util.Set;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.ACA;
import static fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils.perimetre;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
class PerimetreExcluFacadeImplIT {

    @Autowired
    private IPerimetreExcluFacade facade;

    @Autowired
    private IPerimetreRepository repository;

    @Test
    public void saving_perimetre_is_ok() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre perimetre = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-111-LME", false,
                null, null, null, null, null, null);
        perimetre.setProfil(aca.getProfil());

        //WHEN
        Perimetre actual = facade.save(perimetre);

        //THEN
        assertEquals(TypePerimetreEnum.PRODUIT, actual.getTypePerimetre());
        assertEquals("RR01-111-LME", actual.getValeurPerimetre());
        assertEquals(aca.getId(), actual.getIdParent());
    }

    @Test
    public void saving_perimetre_throws_exception() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre expected = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-222-LME", false,
                null, null, null, null, null, null);
        Perimetre perimetre = repository.save(expected);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.save(perimetre));
    }

    @Test
    public void finding_perimetre_by_id_is_ok() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre expected = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-333-LME", false,
                null, null, null, null, null, Collections.emptySet());
        expected.setProfil(aca.getProfil());

        expected = repository.save(expected);

        //WHEN
        Perimetre actual = facade.findById(expected.getId());

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void finding_perimetre_by_id_is_throwing_exception() {
        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.findById(999L));
    }

    @Test
    public void finding_perimetre_is_ok() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre expected = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-444-LME", false,
                null, null, null, null, null, Collections.emptySet());
        Perimetre perimetre = repository.save(expected);

        //WHEN
        Perimetre actual = facade.find(perimetre);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void finding_perimetre_throws_exception() {
        //GIVEN
        Perimetre expected = perimetre(2222L, 1111L, TypePerimetreEnum.PRODUIT, "RR01-555-LME", false,
                null, null, null, null, null, null);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.find(expected));
    }

    @Test
    public void updating_perimetre_is_ok() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre expected = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-666-LME", false,
                null, null, null, null, null, null);
        repository.save(expected);
        expected.setValeurPerimetre("RR01-777-LME");

        //WHEN
        Perimetre actual = facade.update(expected);

        //THEN
        assertEquals(expected, actual);
    }

    @Test
    public void updating_perimetre_throws_exception() {
        //GIVEN
        Perimetre expected = perimetre(111L, 333L, TypePerimetreEnum.PRODUIT, "RR01-777-LME", false,
                null, null, null, null, null, null);

        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.update(expected));
    }

    @Test
    public void deleted_perimetre_by_id_is_ok() {
        //GIVEN
        Perimetre aca = repository.find(TypePerimetreEnum.FILIALE, ACA);
        Perimetre expected = perimetre(0L, aca.getId(), TypePerimetreEnum.PRODUIT, "RR01-888-LME", false,
                null, null, null, null, null, null);
        Perimetre perimetre = repository.save(expected);

        //WHEN
        facade.delete(perimetre.getId());

        //THEN
        assertThrows(PerimetreExcluException.class, () -> facade.findById(perimetre.getId()));
    }

    @Test
    public void deleted_perimetre_by_id_throws_exception() {
        //WHEN THEN
        assertThrows(PerimetreExcluException.class, () -> facade.delete(2222L));
    }

    @Test
    public void get_all_gives_all_perimetre_ecluded() {
        //WHEN
        Set<Perimetre> actual = facade.findAll();

        //THEN
        assertEquals(5, actual.size());
    }
}