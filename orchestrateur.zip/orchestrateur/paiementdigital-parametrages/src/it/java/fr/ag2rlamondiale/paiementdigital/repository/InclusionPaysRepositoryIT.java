package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes;
import fr.ag2rlamondiale.paiementdigital.domain.InclusionPays;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Date;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class InclusionPaysRepositoryIT {

    @Autowired
    private IInclusionPaysRepository inclusionPaysRepository;

    private String codeApplication;

    private Date dateRecherche;

    @BeforeEach
    public void setUp() {
        codeApplication = "A1573";
        dateRecherche = new Date();
    }

    @AfterEach
    public void tearDown() {
        codeApplication = null;
        dateRecherche = null;
    }

    @Test
    void finding_inclusion_pays_with_null_metier_parameter_gives_empty_list() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(null, codeApplication, dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec metier=null.");
    }

    @Test
    void finding_inclusion_pays_with_null_codeApplication_parameter_gives_empty_list() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(ProfilConstantes.RET_SUP_COL, null, dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec codeApplication=null.");
    }

    @Test
    void finding_inclusion_pays_with_null_dateRecherche_parameter_gives_empty_list() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(ProfilConstantes.RET_SUP_COL, codeApplication, null);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec dateRecherche=null.");
    }

    @Test
    void finding_inclusion_pays_with_unknown_metier_parameter_gives_empty_list() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find("UNKNOWN", codeApplication, dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec metier=UNKNOWN.");
    }

    @Test
    void finding_inclusion_pays_with_unknown_codeApplication_parameter_gives_empty_list() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(ProfilConstantes.RET_SUP_COL, "UNKNOWN", dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec codeApplication=UNKNOWN.");
    }

    @Test
    void finding_inclusion_pays_with_dateRecherche_parameter_before_dateeffet_gives_empty_list() {
        //GIVEN
        Date dateRecherche = ParametrageUtils.buildShortDate(1789, 7, 14);
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(ProfilConstantes.RET_SUP_COL, codeApplication, dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de pays doit être de 0 élément trouvé avec dateRecherche=14 juillet 1789.");
    }

    @Test
    void finding_inclusion_pays_with_parameters_gives_list_inclusionpays() {
        //WHEN
        Set<InclusionPays> result = inclusionPaysRepository.find(ProfilConstantes.RET_SUP_COL, codeApplication, dateRecherche);
        //THEN
        assertEquals(inclusionPaysRepository.count(), result.size());
    }
}
