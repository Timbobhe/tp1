package fr.ag2rlamondiale.paiementdigital.repository;

import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.ExclusionBanque;
import fr.ag2rlamondiale.paiementdigital.utils.ParametrageUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Date;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
public class ExclusionBanqueRepositoryIT {
    @Autowired
    private IExclusionBanqueRepository exclusionBanqueRepository;

    private Date dateRecherche;

    @BeforeEach
    public void setUp() {
        dateRecherche = new Date();
    }

    @AfterEach
    public void tearDown() {
        dateRecherche = null;
    }

    @Test
    void finding_exclusion_banque_with_null_dateRecherche_parameter_gives_empty_list() {
        //GIVEN
        dateRecherche = null;
        //WHEN
        Set<ExclusionBanque> result = exclusionBanqueRepository.find(dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de banques exclues doit être de 0 élément trouvé avec dateRecherche=null.");
    }

    @Test
    void finding_exclusion_banque_with_dateRecherche_parameter_before_dateEffet_gives_empty_list() {
        //GIVEN
        dateRecherche = ParametrageUtils.buildShortDate(2017, 1, 1);
        //WHEN
        Set<ExclusionBanque> result = exclusionBanqueRepository.find(dateRecherche);
        //THEN
        assertEquals(0, result.size(),
                "Le nombre de banques exclues doit être de 0 élément trouvé avec dateRecherche=1/1/2017.");
    }

    @Test
    void finding_exclusion_banque_with_parameters_gives_list_ExclusionBanque() {
        //WHEN
        Set<ExclusionBanque> result = exclusionBanqueRepository.find(dateRecherche);
        //THEN
        assertEquals(exclusionBanqueRepository.count(), result.size(),
                "Le nombre de banques exclues doit correspondre au total du contenu de la base de données avec la date du jour.");
    }
}
