package fr.ag2rlamondiale.paiementdigital.business.impl;

import fr.ag2rlamondiale.paiementdigital.business.IRecupParamLABFacade;
import fr.ag2rlamondiale.paiementdigital.config.ParametrageConfig;
import fr.ag2rlamondiale.paiementdigital.domain.Perimetre;
import fr.ag2rlamondiale.paiementdigital.domain.Profil;
import fr.ag2rlamondiale.paiementdigital.domain.RecupParamLAB;
import fr.ag2rlamondiale.paiementdigital.domain.type.TypePerimetreEnum;
import fr.ag2rlamondiale.paiementdigital.exception.NotFoundParameterValueException;
import fr.ag2rlamondiale.paiementdigital.exception.TooManyProfilsException;
import fr.ag2rlamondiale.paiementdigital.repository.IProfilRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.Objects;

import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.ACA;
import static fr.ag2rlamondiale.paiementdigital.constantes.ProfilConstantes.ARI;
import static org.junit.jupiter.api.Assertions.*;

@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = ParametrageConfig.class)
@Sql(scripts = "/sql/parametrage.sql")
class RecupParamLABFacadeImplIT {

    @Autowired
    private IRecupParamLABFacade recupParamLABFacade;

    @Autowired
    private IProfilRepository profilRepository;

    private Profil profil;

    private RecupParamLAB recupParamLAB;

    @BeforeEach
    void setUp() throws ParseException {
        profil = profilRepository.findAll().get(0);

        recupParamLAB = RecupParamLAB
                .builder()
                .metier(profil.getMetier())
                .codeApplication(profil.getCodeApplication())
                .evenementMetier(profil.getEvenementMetier())
                .natureClient(profil.getNatureClient())
                .typeClient(profil.getTypeClient())
                .structureJuridique(ARI)
                .filiale(ACA)
                .produit(null)
                .contratDeReference(null)
                .contrat(null)
                .tiersPayeur(false)
                .dateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-08-05" ))
                .build();
    }

    @AfterEach
    void tearDown() {
        profil = null;
        recupParamLAB = null;
    }

    @Test
    public void no_profil_found_throws_exception() {
        //GIVEN
        recupParamLAB.setMetier("UNKNOWN");

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void no_perimetre_found_throws_exception() {
        //GIVEN
        recupParamLAB.setFiliale("XXX");

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void too_many_profils_found_throws_exception() {
        //GIVEN
        Profil profil1 = profil.copy(profil);
        profil1.setId(null);
        profil1.setMetier("XXX");
        profil1.setPerimetres(Collections.emptySet());
        profilRepository.save(profil1);

        Profil profil2 = profil.copy(profil);
        profil2.setId(null);
        profil2.setMetier("XXX");
        profil2.setPerimetres(Collections.emptySet());
        profilRepository.save(profil2);

        recupParamLAB.setMetier("XXX");

        //WHEN THEN
        assertThrows(TooManyProfilsException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void perimetre_is_found() {
        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && date.before(perimetre.getDateFinEffet());
        assertTrue(result);
    }

    @Test
    public void perimetre_excluded_throws_exception() {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-ACA");

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void perimetre_is_found_with_unknown_produit() {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-XXX");

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && date.before(perimetre.getDateFinEffet());
        assertTrue(result);
    }

    @Test
    public void perimetre_with_date_recherche_between_date_effet_and_date_fin_effet_produit_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-ACA");
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-10" ));

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void perimetre_is_found_when_date_not_between_date_effet_and_date_fin_effet_produit() throws ParseException {
        //GIVEN
        recupParamLAB.setProduit("RR01-001-ACA");
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-13" ));

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && (Objects.isNull(perimetre.getDateFinEffet()) || date.before(perimetre.getDateFinEffet()));
        assertTrue(result);
    }

    @Test
    public void perimetre_with_date_recherche_between_date_effet_and_date_fin_effet_contrat_throws_exception() throws ParseException {
        //GIVEN
        recupParamLAB.setContrat("RRE");
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-10" ));

        //WHEN THEN
        assertThrows(NotFoundParameterValueException.class, () -> recupParamLABFacade.find(recupParamLAB));
    }

    @Test
    public void perimetre_is_found_when_date_not_between_date_effet_and_date_fin_effet_contrat() throws ParseException {
        //GIVEN
        recupParamLAB.setContrat("RRE");
        recupParamLAB.setDateRecherche(new SimpleDateFormat( "yyyy-MM-dd" ).parse( "2021-10-13" ));

        //WHEN
        Perimetre perimetre = recupParamLABFacade.find(recupParamLAB);

        //THEN
        assertEquals(TypePerimetreEnum.FILIALE, perimetre.getTypePerimetre());
        assertEquals(recupParamLAB.getFiliale(), perimetre.getValeurPerimetre());
        assertEquals(recupParamLAB.isTiersPayeur(), perimetre.isTiersPayeur());

        Date date = recupParamLAB.getDateRecherche();
        boolean result = date.after(perimetre.getDateEffet()) && (Objects.isNull(perimetre.getDateFinEffet()) || date.before(perimetre.getDateFinEffet()));
        assertTrue(result);
    }
}