package fr.ag2rlamondiale.ecrs.business.domain;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.messages.ErrorMessage;

public class UtilisateurException extends BusinessException {
    public UtilisateurException() {
    }

    public UtilisateurException(ErrorMessage errorMsg) {
        super(errorMsg);
    }

    public UtilisateurException(String codeErreur, String contextualMessage) {
        super(codeErreur, contextualMessage);
    }

    public UtilisateurException(String message) {
        super(message);
    }

    public UtilisateurException(String message, Throwable cause) {
        super(message, cause);
    }

    public UtilisateurException(Throwable cause) {
        super(cause);
    }
}
