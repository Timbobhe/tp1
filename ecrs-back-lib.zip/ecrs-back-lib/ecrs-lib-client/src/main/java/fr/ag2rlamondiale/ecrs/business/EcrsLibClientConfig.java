package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.trm.PfsConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@ComponentScan
@Configuration
@Import(PfsConfig.class)
public class EcrsLibClientConfig {
}
