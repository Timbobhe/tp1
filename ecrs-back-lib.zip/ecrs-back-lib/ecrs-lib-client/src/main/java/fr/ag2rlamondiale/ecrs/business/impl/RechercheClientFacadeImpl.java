package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IRechercheClientFacade;
import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.business.domain.PartenaireException;
import fr.ag2rlamondiale.ecrs.business.domain.UtilisateurException;
import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IRechercherPPSiloClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.function.Consumer;

import static fr.ag2rlamondiale.trm.utils.ErrorConstantes.UTILISATEUR_NON_TROUVE;

@Primary
@Service
public class RechercheClientFacadeImpl implements IRechercheClientFacade {

    @Autowired
    protected IRechercherPPSiloClient rechercherPP;

    @Autowired
    protected IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private IRechercherHabiliFacade habiliService;


    @Override
    public PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException {
        PersonnePhysique user = habiliService.rechercherParIdGdi(idGdi);
        if (null == user || null == user.getNumeroPersonneEre() && null == user.getNumeroPersonneMdpro()) {
            throw new UtilisateurException(UTILISATEUR_NON_TROUVE);
        }
        return user;
    }

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne)
            throws CommonException {
        return rechercherPersonnePhysiqueEreParNumeroPersonne(numeroDePersonne, false, null, null);
    }

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne, boolean creerHabilitation,
                                                                           IdentiteNumeriqueHabilitation identiteNumeriqueHabilitation, Consumer<Exception> handleErrorHabili) throws CommonException {

        // 1. On recherche quoi qu'il arrive dans EGESPER ERE : c'est le systeme de gestion, c'est lui qui doit detenir la verite
        IdSiloDto crit = CodeApplicationType.EGESPER_ERE.idSilo(numeroDePersonne);
        PersonnePhysiqueConsult ppc;
        try {
            ppc = consulterPersonneClient.consulterPersPhys(crit);
        } catch (TechnicalException e) {
            if (e.getCause().getMessage().contains("PERSONNE-PHYSIQUE-INEXISTANTE")) {
                throw new PartenaireException(PartenaireException.ErrorCode.UNKNOWN_USER);
            } else {
                throw e;
            }
        }
        PersonnePhysique user = new PersonnePhysique();
        user.setNom(ppc.getNom());
        user.setPrenom(ppc.getPrenom());
        user.setNumeroPersonneEre(numeroDePersonne);
        user.setCivilite(ppc.getCivilite());

        // 2. Ensuite on s'occupe de rechercher les Habilitations pour recuperer IDEXTRANET et IDGDI (ce dernier est optionnel)

        try {
            PersonnePhysique userHabili;

            if (creerHabilitation) {
                Objects.requireNonNull(identiteNumeriqueHabilitation);
                userHabili = habiliService.rechercherOuCreerHabiliPers(ppc, identiteNumeriqueHabilitation);
            } else {
                userHabili = habiliService.rechercherParNumPers(numeroDePersonne, CodeSiloType.ERE);
            }

            if (userHabili != null) {
                user.setIdGdi(userHabili.getIdGdi());
                user.setIdExtranet(userHabili.getIdExtranet());
            }
        } catch (Exception e) {
            if (handleErrorHabili != null) {
                handleErrorHabili.accept(e);
            } else {
                throw e;
            }
        }


        return user;
    }

    @Override
    public RechercherPPSiloResponseDto rechercherPPSilo(DemandeRecherchePP demandeRecherchePP) throws TechnicalException {
        return rechercherPP.rechercherPPSilo(demandeRecherchePP);
    }

    @Override
    public PersonnePhysique rechercherPersonnePhysiqueParIdHabili(IdentiteNumeriqueHabilitation idHabili) throws CommonException {
        final PersonnePhysique user = habiliService.rechercherParIdentiteNumerique(idHabili);
        if (null == user || null == user.getNumeroPersonneEre() && null == user.getNumeroPersonneMdpro()) {
            throw new UtilisateurException(UTILISATEUR_NON_TROUVE);
        }
        return user;
    }
}
