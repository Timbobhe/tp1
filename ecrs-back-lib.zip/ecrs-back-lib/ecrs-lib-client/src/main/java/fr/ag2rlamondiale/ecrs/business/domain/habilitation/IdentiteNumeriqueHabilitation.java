package fr.ag2rlamondiale.ecrs.business.domain.habilitation;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IdentiteNumeriqueHabilitation {
    private String login;

    /**
     * idPartenaire (ex : NIE = 49505)
     */
    private String identifiantFournisseurIdentiteNumerique;
}
