package fr.ag2rlamondiale.ecrs.business.impl;

import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.ecrs.business.mapping.habilitation.CreerHabiliPersMapper;
import fr.ag2rlamondiale.trm.client.rest.ICreerHabiliPersClient;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.habilitation.CreerHabiliIn;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RechercherHabiliFacadeImpl implements IRechercherHabiliFacade {
    @Autowired
    private IRechercherHabiliPersClient rechercherHabiliPersClient;

    @Autowired
    private ICreerHabiliPersClient creerHabiliPersClient;

    @Autowired
    private CreerHabiliPersMapper creerHabiliPersMapper;

    @Override
    public PersonnePhysique rechercherParIdGdi(String idGdi) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setIdGdi(idGdi);
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }

    @Override
    public PersonnePhysique rechercherParNumPers(String numPp, CodeSiloType silo) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setCodeSilo(silo);
        in.setNumeroPersonne(numPp);
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }

    @Override
    public PersonnePhysique rechercherParIdentiteNumerique(IdentiteNumeriqueHabilitation identiteNumerique) {
        RechercherHabiliIn in = new RechercherHabiliIn();
        in.setLogin(identiteNumerique.getLogin());
        in.setIdentifiantFournisseurIdentiteNumerique(identiteNumerique.getIdentifiantFournisseurIdentiteNumerique());
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }

    @Override
    public PersonnePhysique creerHabiliPers(PersonnePhysiqueConsult ppc, IdentiteNumeriqueHabilitation identiteNumerique) {
        final CreerHabiliIn creerHabiliIn = creerHabiliPersMapper.map(ppc, identiteNumerique);
        return creerHabiliPersClient.creerHabiliPers(creerHabiliIn);
    }

    @Override
    public PersonnePhysique rechercherOuCreerHabiliPers(PersonnePhysiqueConsult ppc, IdentiteNumeriqueHabilitation identiteNumerique) {
        PersonnePhysique userHabili = rechercherParIdentiteNumerique(identiteNumerique);
        if (userHabili == null) {
            userHabili = creerHabiliPers(ppc, identiteNumerique);
        }
        return userHabili;
    }

}
