package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.domain.UtilisateurException;
import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.trm.domain.personne.DemandeRecherchePP;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.RechercherPPSiloResponseDto;

import java.util.function.Consumer;

public interface IRechercheClientFacade {
    /**
     * @param idGdi
     * @return
     * @throws CommonException
     * @throws UtilisateurException si L'utilisateur n'est pas trouv� ou bien s'il n'a pas de numERE ni numMDPRD
     */
    PersonnePhysique rechercherPersonnePhysiqueParIdGdi(String idGdi) throws CommonException, UtilisateurException;

    /**
     * @param numeroDePersonne
     * @return
     * @throws CommonException
     * @see #rechercherPersonnePhysiqueEreParNumeroPersonne(String, boolean, IdentiteNumeriqueHabilitation, Consumer)
     */
    PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne) throws CommonException;

    /**
     * Rechercher une PP et rechercher ou cr&eacute;e l'Habilitation de la PP via identiteNumeriqueHabilitation.
     * <ol>
     *     <li>On recherche quoi qu'il arrive dans EGESPER ERE : c'est le syst&egrave;me de gestion, c'est lui qui doit d&eacute;tenir la v&eacute;rit&eacute;</li>
     *     <li>Ensuite on s'occupe de rechercher les Habilitations pour r&eacute;cup&eacute;rer IDEXTRANET et IDGDI (ce dernier est optionnel)</li>
     * </ol>
     *
     * @param numeroDePersonne
     * @param creerHabilitation
     * @param identiteNumeriqueHabilitation
     * @param handleErrorHabili
     * @return
     * @throws CommonException
     */
    PersonnePhysique rechercherPersonnePhysiqueEreParNumeroPersonne(String numeroDePersonne, boolean creerHabilitation, IdentiteNumeriqueHabilitation identiteNumeriqueHabilitation, Consumer<Exception> handleErrorHabili) throws CommonException;

    RechercherPPSiloResponseDto rechercherPPSilo(DemandeRecherchePP demandeRecherchePP) throws TechnicalException;

    /**
     * @param idHabili
     * @return
     * @throws CommonException
     * @throws UtilisateurException si L'utilisateur n'est pas trouv� ou bien s'il n'a pas de numERE ni numMDPRD
     */
    PersonnePhysique rechercherPersonnePhysiqueParIdHabili(IdentiteNumeriqueHabilitation idHabili) throws CommonException, UtilisateurException;

}
