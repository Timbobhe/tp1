package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;

public interface IRechercherHabiliFacade {

    PersonnePhysique rechercherParIdGdi(String idGdi);

    PersonnePhysique rechercherParNumPers(String numPp, CodeSiloType silo);

    PersonnePhysique rechercherParIdentiteNumerique(IdentiteNumeriqueHabilitation identiteNumerique);

    PersonnePhysique creerHabiliPers(PersonnePhysiqueConsult ppc, IdentiteNumeriqueHabilitation identiteNumerique);

    PersonnePhysique rechercherOuCreerHabiliPers(PersonnePhysiqueConsult ppc, IdentiteNumeriqueHabilitation identiteNumerique);

}
