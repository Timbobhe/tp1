package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.personne.ModifierPPSiloResponseDto;
import fr.ag2rlamondiale.trm.dto.personne.CoordonneesClientDto;

/**
 * Interface de la Facade de r&eacute;cup&eacute;ration et agr&eacute;gation des donn&eacute;es contrat.
 */
public interface IClientFacade extends IRechercheClientFacade {

    ModifierPPSiloResponseDto modifierCoordonneesClient(CoordonneesClientDto nouvellesCoordonnees) throws TechnicalException;

}
