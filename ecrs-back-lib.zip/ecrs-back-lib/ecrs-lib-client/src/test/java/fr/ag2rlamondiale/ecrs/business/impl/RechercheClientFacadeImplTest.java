/*
 * Cree le 3 oct. 2018. (c) Ag2r - La Mondiale, 2018. Tous droits reserves.
 */
package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.BusinessException;
import com.ag2r.common.exceptions.CommonException;
import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IRechercherHabiliFacade;
import fr.ag2rlamondiale.ecrs.business.domain.PartenaireException;
import fr.ag2rlamondiale.trm.business.IWorkflowFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IModifierPPSiloClient;
import fr.ag2rlamondiale.trm.client.soap.IRecherchePersonneClient;
import fr.ag2rlamondiale.trm.client.soap.IRechercherPPSiloClient;
import fr.ag2rlamondiale.trm.domain.personne.*;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

/**
 * Test de la classe ClientFacadeImpl
 */
@RunWith(MockitoJUnitRunner.class)
@Configuration
public class RechercheClientFacadeImplTest {
    private static final String NUM_PERS_ERE = "P0080191";
    private static final String ID_GDI = "pz5n1f";
    private static final String NOM = "NOM";
    private static final String PRENOM = "PRENOM";
    private static final String CIVILITE = "CIVILITE";

    @Mock
    private IRecherchePersonneClient recherchePersonneClient;

    @Mock
    private UserContextHolder userContextHolder;

    @Mock
    private IConsulterPersonneClient consulterPersonneClient;


    @Mock
    private IWorkflowFacade workflowFacade;

    @Mock
    private IModifierPPSiloClient modifierPPSiloClient;


    @Mock
    private IRechercherHabiliFacade habiliService;

    @Mock
    private IRechercherPPSiloClient rechercherPP;

    @InjectMocks
    RechercheClientFacadeImpl clientFacade;

    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

    @Test
    public void testRecupereListeContrat() throws CommonException {
        when(habiliService.rechercherParIdGdi(ID_GDI))
                .thenAnswer((Answer<PersonnePhysique>) invocation -> {
                    PersonnePhysique personne = new PersonnePhysique();
                    personne.setNumeroPersonneEre(NUM_PERS_ERE);
                    return personne;
                });

        PersonnePhysique retour = clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);

        Assert.assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail1() throws Exception {
        when(habiliService.rechercherParIdGdi(any()))
                .thenReturn(null);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }

    @Test(expected = BusinessException.class)
    public void testRecupereListeContratFail2() throws Exception {

        PersonnePhysique user = new PersonnePhysique();
        when(habiliService.rechercherParIdGdi(any()))
                .thenReturn(user);

        clientFacade.rechercherPersonnePhysiqueParIdGdi(ID_GDI);
    }


    @Test
    public void testrechercherPersonnePhysiqueEreParNumeroPersonne() throws CommonException {
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class)))
                .thenAnswer((Answer<PersonnePhysiqueConsult>) invocation -> {
                    PersonnePhysiqueConsult personnePhysique = new PersonnePhysiqueConsult();
                    personnePhysique.setNom(NOM);
                    personnePhysique.setPrenom(PRENOM);
                    personnePhysique.setCivilite(CIVILITE);
                    return personnePhysique;
                });

        PersonnePhysique retour = clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(NUM_PERS_ERE);

        Assert.assertEquals(NUM_PERS_ERE, retour.getNumeroPersonneEre());
    }

    @Test(expected = PartenaireException.class)
    public void testrechercherPersonnePhysiqueEreParNumeroPersonneFail1() throws Exception {
        when(consulterPersonneClient.consulterPersPhys(any(IdSiloDto.class)))
                .thenThrow(new TechnicalException("PERSONNE-PHYSIQUE-INEXISTANTE", new Throwable("PERSONNE-PHYSIQUE-INEXISTANTE")));

        clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(ID_GDI);
    }

    @Test
    public void testrechercherPPSilo() throws TechnicalException {
        when(rechercherPP.rechercherPPSilo(any())).thenReturn(new RechercherPPSiloResponseDto());

        RechercherPPSiloResponseDto rechercherPPSiloResponseDto = clientFacade.rechercherPPSilo(new DemandeRecherchePP("ID"));

        Assert.assertNotNull(rechercherPPSiloResponseDto);
    }


}
