package fr.ag2rlamondiale.ecrs.business.mapping.habilitation;

import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.habilitation.CreerHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class CreerHabiliPersMapperTest {

    @Spy
    CreerHabiliPersMapperImpl mapper;

    @Test
    public void test_mapping() throws Exception {
        // Given
        PersonnePhysiqueConsult personnePhysiqueConsult = PersonnePhysiqueConsult.builder()
                .nom("NOM")
                .prenom("PRENOM")
                .codeSexe("M")
                .codePostalNaissance("CP")
                .dateDeNaissance(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/1980"))
                .codeSilo(CodeSiloType.ERE)
                .emailPro("email")
                .id("ID")
                .telPersonnel("TELPERSO")
                .build();
        IdentiteNumeriqueHabilitation identiteNumerique = IdentiteNumeriqueHabilitation.builder()
                .login("LOGIN")
                .identifiantFournisseurIdentiteNumerique("F1")
                .build();

        // When
        final CreerHabiliIn creerHabiliIn = mapper.map(personnePhysiqueConsult, identiteNumerique);

        // Then
        assertEquals("NOM", creerHabiliIn.getNom());
        assertEquals("PRENOM", creerHabiliIn.getPrenom());
        assertEquals("M", creerHabiliIn.getCodeSexe());
        assertEquals("CP", creerHabiliIn.getCodePostalCommuneNaissance());
        assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/1980"), creerHabiliIn.getDateNaissance());
        assertEquals("email", creerHabiliIn.getEmail());
        assertEquals(Collections.singletonList("TELPERSO"), creerHabiliIn.getTelephones());
        assertEquals("ID", creerHabiliIn.getIdentifiantSilo().getValeurId());
        assertEquals("A0499", creerHabiliIn.getIdentifiantSilo().getTypeId());
        assertEquals("LOGIN", creerHabiliIn.getLogin());
        assertEquals("F1", creerHabiliIn.getIdentifiantFournisseurIdentiteNumerique());
    }

    @Test
    public void test_mapping_mapCodePostalNaissance() throws Exception {
        // Given
        PersonnePhysiqueConsult personnePhysiqueConsult = PersonnePhysiqueConsult.builder()
                .nom("NOM")
                .prenom("PRENOM")
                .codeSexe("M")
                .codePostalNaissance(null)
                .codeINSEENaissance("CodeINSEENaissance")
                .dateDeNaissance(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/1980"))
                .codeSilo(CodeSiloType.ERE)
                .emailPro("email")
                .id("ID")
                .telPersonnel("TELPERSO")
                .build();
        IdentiteNumeriqueHabilitation identiteNumerique = IdentiteNumeriqueHabilitation.builder()
                .login("LOGIN")
                .identifiantFournisseurIdentiteNumerique("F1")
                .build();

        // When
        final CreerHabiliIn creerHabiliIn = mapper.map(personnePhysiqueConsult, identiteNumerique);

        // Then
        assertEquals("NOM", creerHabiliIn.getNom());
        assertEquals("PRENOM", creerHabiliIn.getPrenom());
        assertEquals("M", creerHabiliIn.getCodeSexe());
        assertEquals("CodeINSEENaissance", creerHabiliIn.getCodePostalCommuneNaissance());
        assertEquals(new SimpleDateFormat("dd/MM/yyyy").parse("01/01/1980"), creerHabiliIn.getDateNaissance());
        assertEquals("email", creerHabiliIn.getEmail());
        assertEquals(Collections.singletonList("TELPERSO"), creerHabiliIn.getTelephones());
        assertEquals("ID", creerHabiliIn.getIdentifiantSilo().getValeurId());
        assertEquals("A0499", creerHabiliIn.getIdentifiantSilo().getTypeId());
        assertEquals("LOGIN", creerHabiliIn.getLogin());
        assertEquals("F1", creerHabiliIn.getIdentifiantFournisseurIdentiteNumerique());
    }

}
