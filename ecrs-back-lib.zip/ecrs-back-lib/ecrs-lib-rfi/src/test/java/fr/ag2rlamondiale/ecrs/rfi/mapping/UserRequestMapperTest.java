package fr.ag2rlamondiale.ecrs.rfi.mapping;

import com.ag2r.common.security.habilitations.model.IAuthorizationData;
import fr.ag2rlamondiale.ecrs.rfi.domain.BasicUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.GrantedAuthority;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils.wrapToList;
import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserRequestMapperTest {

    @InjectMocks
    UserRequestMapperImpl userRequestMapper;


    @Test
    public void test_mapping_fromUserDetails_toUserRequestDto() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_enrichi_UserDetails();

        // When
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // Then
        assertEquals(userRequest.getUid(), userDetails.getAttributesMap().get("uid"));
        assertEquals(userRequest.getAttributes().getAgCodeSexe(), wrapToList(userDetails.getAttributesMap().get("agCodeSexe")));
        assertEquals(userRequest.getAttributes().getSn(), wrapToList(userDetails.getAttributesMap().get("sn")));
        assertEquals(userRequest.getAttributes().getCompteDemo(), wrapToList(userDetails.getAttributesMap().get("compteDemo")));
        assertEquals(userRequest.getAttributes().getGivenName(), wrapToList(userDetails.getAttributesMap().get("givenName")));
        assertEquals(userRequest.getAttributes().getPersonIdMap(), wrapToList(userDetails.getAttributesMap().get("personIdMap")));
        assertEquals(userRequest.getAttributes().getBusinessIdMap(), wrapToList(userDetails.getAttributesMap().get("businessIdMap")));
        assertEquals(userRequest.getAttributes().getRoles(), userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).map(s -> s.substring(IAuthorizationData.ROLE_PREFIX.length())).collect(Collectors.toSet()));
    }


    private IUserDetails cas3_enrichi_UserDetails() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        final List<String> roles = Arrays.asList("EERE-Federation", "IMP-EERE-Salarie");
        attributes.put("roles", roles);

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("agCodeSexe", "M");
        attributes.put("compteDemo", false);
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        attributes.put("fdiPerimeterName", "FRANK");
        attributes.put("seeAlso", "part2");
        attributes.put("businessIdMap", "{idEpargneRetraite=idEpargneRetraite,refExterne=refExterne}");
        attributes.put("personIdMap", "{idA0554=IDGDI,idA1531=IDEXTRANET,id" + CodeApplicationType.EGESPER_ERE.getCode() + "=NUMPERSERE}");
        return BasicUserDetails.builder()
                .userSn((String) attributes.get("sn"))
                .userGivenName((String) attributes.get("givenName"))
                .authorities(userRequestMapper.mapToGrantedAuthority(roles))
                .attributesMap(attributes)
                .build();
    }
}
