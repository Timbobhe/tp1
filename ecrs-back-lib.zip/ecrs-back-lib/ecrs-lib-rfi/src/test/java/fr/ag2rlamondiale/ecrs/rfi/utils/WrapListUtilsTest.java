package fr.ag2rlamondiale.ecrs.rfi.utils;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class WrapListUtilsTest {

    @Test
    public void test_wrapToList() throws Exception {
        assertNull(WrapListUtils.wrapToList(null));
        assertEquals(Arrays.asList(1), WrapListUtils.wrapToList(1));
    }

    @Test
    public void test_unwrapList() throws Exception {
        assertEquals(1, (int) WrapListUtils.unwrapList(Arrays.asList(1)));
        assertNull(WrapListUtils.unwrapList(Arrays.asList()));
    }
}
