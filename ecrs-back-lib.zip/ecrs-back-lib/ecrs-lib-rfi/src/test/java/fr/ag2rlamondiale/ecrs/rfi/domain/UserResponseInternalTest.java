package fr.ag2rlamondiale.ecrs.rfi.domain;

import org.junit.Test;

import static org.junit.Assert.*;

public class UserResponseInternalTest {

    @Test
    public void test_compteDemo() throws Exception {
        final UserResponseInternal internal = UserResponseInternal.builder()
                .compteDemo(null)
                .build();

        assertNull(internal.getCompteDemo());
        assertFalse(internal.hasCompteDemo());
        assertFalse(internal.isWithCompteDemo());
    }

}
