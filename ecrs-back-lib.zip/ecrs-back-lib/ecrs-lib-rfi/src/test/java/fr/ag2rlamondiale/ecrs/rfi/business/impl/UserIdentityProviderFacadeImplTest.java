package fr.ag2rlamondiale.ecrs.rfi.business.impl;


import com.ag2r.common.security.habilitations.model.IAuthorizationData;
import fr.ag2rlamondiale.ecrs.business.IRechercheClientFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.BasicUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseInternalDto;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserRequestMapperImpl;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserResponseInternalMapperImpl;
import fr.ag2rlamondiale.trm.business.ICompteDemoFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.personne.*;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import fr.ag2rlamondiale.trm.utils.MapUtils;
import fr.ag2rlamondiale.trm.utils.Sets;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.util.ReflectionTestUtils;

import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils.wrapToList;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class UserIdentityProviderFacadeImplTest {

    @InjectMocks
    UserIdentityProviderFacadeImpl userIdentityProviderFacade;

    @Mock
    private IRechercheClientFacade clientFacade;

    @Mock
    private IConsulterPersonneClient consulterPersonneClient;

    @Mock
    private ICompteDemoFacade compteDemoFacade;

    @Mock
    private UserContextHolder userContextHolder;

    @Spy
    private UserRequestMapperImpl userRequestMapper;

    @Spy
    private UserResponseInternalMapperImpl userResponseInternalMapper;


    @Before
    public void setUp() throws Exception {
//        new RolesListFactory().setFactory(new BundleRolesList());
//        assertNotNull(RolesListFactory.getCurrentFactory());
//
//        ReflectionTestUtils.setField(SecurityDomainManager.class, "instance", new SecurityDomainManager());
//        assertNotNull(SecurityDomainManager.getInstance());
    }

    @Test
    public void test_mapping_fromUserDetails_toUserRequestDto() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_enrichi_UserDetails();

        // When
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // Then
        assertEquals(userRequest.getUid(), userDetails.getAttributesMap().get("uid"));
        assertEquals(userRequest.getAttributes().getAgCodeSexe(), wrapToList(userDetails.getAttributesMap().get("agCodeSexe")));
        assertEquals(userRequest.getAttributes().getFdiPerimeterName(), wrapToList(userDetails.getAttributesMap().get("fdiPerimeterName")));
        assertEquals(userRequest.getAttributes().getSn(), wrapToList(userDetails.getAttributesMap().get("sn")));
        assertEquals(userRequest.getAttributes().getCompteDemo(), wrapToList(userDetails.getAttributesMap().get("compteDemo")));
        assertEquals(userRequest.getAttributes().getGivenName(), wrapToList(userDetails.getAttributesMap().get("givenName")));
        assertEquals(userRequest.getAttributes().getPersonIdMap(), wrapToList(userDetails.getAttributesMap().get("personIdMap")));
        assertEquals(userRequest.getAttributes().getBusinessIdMap(), wrapToList(userDetails.getAttributesMap().get("businessIdMap")));
        assertEquals(userRequest.getAttributes().getRoles(), userDetails.getAuthorities().stream().map(GrantedAuthority::getAuthority).map(s -> s.substring(IAuthorizationData.ROLE_PREFIX.length())).collect(Collectors.toSet()));
    }

    @Test
    public void test_mapping_fromUserRequestDto_to_UserResponseInternal() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_enrichi_UserDetails();
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // When
        final UserResponseInternal userResponseInternal = userResponseInternalMapper.map(userRequest);

        // Then
        assertTrue(userResponseInternal.getIsAuthorized());
        assertEquals(userResponseInternal.getIdGdi(), userDetails.getAttributesMap().get("uid"));
        assertEquals("Monsieur", userResponseInternal.getCivilite());
        assertEquals(userResponseInternal.getNom(), userDetails.getAttributesMap().get("sn"));
        assertEquals(userResponseInternal.isWithCompteDemo(), userDetails.getAttributesMap().get("compteDemo"));
        assertEquals(userResponseInternal.getPrenom(), userDetails.getAttributesMap().get("givenName"));
        Map<String, String> personIdMap = MapUtils.parseStringMap((String) userDetails.getAttributesMap().get("personIdMap"));
        assertEquals(userResponseInternal.getPersonnePhysique().getNumeroPersonneEre(), personIdMap.get("id" + CodeApplicationType.EGESPER_ERE.getCode()));
        assertEquals(userResponseInternal.getPersonnePhysique().getNumeroPersonneMdpro(), personIdMap.get("id" + CodeApplicationType.EGESPER_MDPRO.getCode()));

        assertTrue(userResponseInternal.getIdentifiantsSiloPersonne().getListeIdSiloDto().stream().anyMatch(idPPSiloDto -> idPPSiloDto.getTypeId().equals(CodeApplicationType.EGESPER_ERE.getCode()) && idPPSiloDto.getValeurId().equals(userResponseInternal.getPersonnePhysique().getNumeroPersonneEre())));

        assertFalse(userResponseInternal.hasCompteDemo());
        assertFalse(userResponseInternal.isWithCompteDemo());
        assertNull(userResponseInternal.getCompteDemo());
    }

    @Test
    public void test_identiteInterneDepuisFederation_AvecPP_existante() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_UserDetails();
        when(clientFacade.rechercherPPSilo(any())).thenReturn(createRechercherPPSiloResponseDto("NUMPERSONNE"));
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString(), anyBoolean(), any(), any())).thenReturn(createPersonnePhysique());

        // When
        final UserResponseInternal userResponseInternal = userIdentityProviderFacade.identiteInterneDepuisFederation(userDetails);
        assertNotNull(userResponseInternal);
        assertTrue(userResponseInternal.getIsAuthorized());
        assertNotNull(userResponseInternal.getPersonnePhysique());
        assertFalse(userResponseInternal.hasCompteDemo());
        assertFalse(userResponseInternal.isWithCompteDemo());
        assertNull(userResponseInternal.getCompteDemo());
    }

    @Test
    public void test_identiteInterneDepuisFederation_AvecPP_existante_deja_enrichi() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_enrichi_UserDetails();
        when(clientFacade.rechercherPPSilo(any())).thenThrow(new RuntimeException("Ne dois pas etre appel\u00E9"));
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString(), anyBoolean(), any(), any())).thenThrow(new RuntimeException("Ne dois pas etre appel\u00E9"));

        // When
        final UserResponseInternal userResponseInternal = userIdentityProviderFacade.identiteInterneDepuisFederation(userDetails);
        assertNotNull(userResponseInternal);
        assertTrue(userResponseInternal.getIsAuthorized());
        assertNotNull(userResponseInternal.getPersonnePhysique());

        assertFalse(userResponseInternal.hasCompteDemo());
        assertFalse(userResponseInternal.isWithCompteDemo());
        assertNull(userResponseInternal.getCompteDemo());
    }

    @Test
    public void test_identiteInterneDepuisFederation_AvecPP_inexistante() throws Exception {
        // Given
        final IUserDetails userDetails = cas3_UserDetails();
        when(clientFacade.rechercherPPSilo(any())).thenReturn(createRechercherPPSiloResponseDto(null));
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString(), anyBoolean(), any(), any())).thenReturn(null);

        // When
        final UserResponseInternal userResponseInternal = userIdentityProviderFacade.identiteInterneDepuisFederation(userDetails);
        assertNotNull(userResponseInternal);
        assertFalse(userResponseInternal.getIsAuthorized());
        assertNull(userResponseInternal.getPersonnePhysique());

        assertFalse(userResponseInternal.hasCompteDemo());
        assertFalse(userResponseInternal.isWithCompteDemo());
        assertNull(userResponseInternal.getCompteDemo());
    }


    @Test
    public void test_identiteExterneDepuisConnexionIDGDI() throws Exception {
        // Prepare
        when(clientFacade.rechercherPersonnePhysiqueParIdGdi(anyString())).thenReturn(createPersonnePhysique());
        when(consulterPersonneClient.basicConsulterPersPhys(any())).thenReturn(createPersonnePhysiqueConsult());

        // Given
        final IUserDetails userDetails = cas4_UserDetails();
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // When
        final UserResponseExternalDto userResponseExternal = userIdentityProviderFacade.identiteExterne(userRequest);

        // Then
        assertTrue(userResponseExternal.getIsAuthorized());
        assertEquals("NOMNAISSANCE", userResponseExternal.getBirthName());
        assertEquals("M", userResponseExternal.getAgCodeSexe());
        assertEquals("TELPORTABLE", userResponseExternal.getMobile());
    }

    @Test
    public void test_identiteExterneDepuisConnexionFederation_nonEnrichi() throws Exception {
        // Prepare
        when(clientFacade.rechercherPPSilo(any())).thenReturn(createRechercherPPSiloResponseDto("NUMPERSONNE"));
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString(), anyBoolean(), any(), any())).thenReturn(createPersonnePhysique());
        when(consulterPersonneClient.basicConsulterPersPhys(any())).thenReturn(createPersonnePhysiqueConsult());

        // Given
        final IUserDetails userDetails = cas3_UserDetails();
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // When
        final UserResponseExternalDto userResponseExternal = userIdentityProviderFacade.identiteExterne(userRequest);

        // Then
        assertTrue(userResponseExternal.getIsAuthorized());
        assertEquals("NOMNAISSANCE", userResponseExternal.getBirthName());
        assertEquals("M", userResponseExternal.getAgCodeSexe());
        assertEquals("TELPORTABLE", userResponseExternal.getMobile());
    }

    @Test
    public void test_identiteExterneDepuisConnexionFederation_Enrichi() throws Exception {
        // Prepare
        when(clientFacade.rechercherPPSilo(any())).thenThrow(new RuntimeException("Ne dois pas etre appel\u00E9"));
        when(clientFacade.rechercherPersonnePhysiqueEreParNumeroPersonne(anyString(), anyBoolean(), any(), any())).thenThrow(new RuntimeException("Ne dois pas etre appel\u00E9"));
        when(consulterPersonneClient.basicConsulterPersPhys(any())).thenReturn(createPersonnePhysiqueConsult());

        // Given
        final IUserDetails userDetails = cas3_enrichi_UserDetails();
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);

        // When
        final UserResponseExternalDto userResponseExternal = userIdentityProviderFacade.identiteExterne(userRequest);

        // Then
        assertTrue(userResponseExternal.getIsAuthorized());
        assertEquals("NOMNAISSANCE", userResponseExternal.getBirthName());
        assertEquals("M", userResponseExternal.getAgCodeSexe());
        assertEquals("TELPORTABLE", userResponseExternal.getMobile());
    }

    @Test
    public void fromUserResponseInternal_to_UserResponseInternalDto_Pers_physique_null() throws Exception {

        // When
        final UserResponseInternalDto userResponseInternalDto = userResponseInternalMapper.map(createUserResponseInternal());

        // Then
        assertFalse(userResponseInternalDto.getIsAuthorized());
        assertEquals("", userResponseInternalDto.getPersonIdMap());
        assertNull(userResponseInternalDto.getSn());
        assertNull(userResponseInternalDto.getGivenName());
        assertFalse(userResponseInternalDto.isCompteDemo());
        assertNull(userResponseInternalDto.getAgCodeSexe());
    }

    private PersonnePhysiqueConsult createPersonnePhysiqueConsult() {
        PersonnePhysiqueConsult ppc = new PersonnePhysiqueConsult();
        ppc.setNomNaissance("NOMNAISSANCE");
        ppc.setCodeSexe("M");
        ppc.setTelPortable("TELPORTABLE");
        return ppc;
    }

    private IUserDetails cas3_UserDetails() {

        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        final List<String> roles = Arrays.asList("EERE-Federation", "IMP-EERE-Salarie");
        attributes.put("roles", roles);

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        attributes.put("fdiPerimeterName", "FRANK");
        attributes.put("seeAlso", "part2");
        attributes.put("businessIdMap", "{idEpargneRetraite=idEpargneRetraite,refExterne=refExterne}");
        return BasicUserDetails.builder()
                .userSn((String) attributes.get("sn"))
                .userGivenName((String) attributes.get("givenName"))
                .authorities(userRequestMapper.mapToGrantedAuthority(roles))
                .attributesMap(attributes)
                .build();
    }

    private IUserDetails cas3_enrichi_UserDetails() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        final List<String> roles = Arrays.asList("EERE-Federation", "IMP-EERE-Salarie");
        attributes.put("roles", roles);

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("agCodeSexe", "M");
        attributes.put("compteDemo", false);
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        attributes.put("fdiPerimeterName", "49505");
        attributes.put("seeAlso", "part2");
        attributes.put("businessIdMap", "{idEpargneRetraite=idEpargneRetraite,refExterne=refExterne}");
        attributes.put("personIdMap", "{idA0554=IDGDI,idA1531=IDEXTRANET,id" + CodeApplicationType.EGESPER_ERE.getCode() + "=NUMPERSERE}");
        return BasicUserDetails.builder()
                .userSn((String) attributes.get("sn"))
                .userGivenName((String) attributes.get("givenName"))
                .authorities(userRequestMapper.mapToGrantedAuthority(roles))
                .attributesMap(attributes)
                .build();
    }

    private IUserDetails cas4_UserDetails() {
        Map<String, Object> attributes = new HashMap<>();
        attributes.put("agDateNaissance", "19781019000000+0100");
        attributes.put("uid", "IDGDI");
        attributes.put("mail", "didier.ferraris.ext@ag2rlamondiale.fr");
        attributes.put("agGDIDateModification", "20170301151047+0100");
        final List<String> roles = Arrays.asList("IMP-EERE-Salarie");
        attributes.put("roles", roles);

        attributes.put("givenName", "FRANCK");
        attributes.put("agGDIDateDerniereConnexion", "20190725140834+0200");
        attributes.put("sn", "BONNIEUX");
        attributes.put("cn", "FRANCK BONNIEUX");
        attributes.put("agIdTechnique", "1000015158");
        attributes.put("entryDN",
                "uid=IDGDI,ou=perimetreParticuliers,ou=Particuliers,ou=Comptes utilisateurs,o=ag2rlamondiale,dc=fr");

        return BasicUserDetails.builder()
                .userSn((String) attributes.get("sn"))
                .userGivenName((String) attributes.get("givenName"))
                .authorities(userRequestMapper.mapToGrantedAuthority(roles))
                .attributesMap(attributes)
                .build();
    }

    private PersonnePhysique createPersonnePhysique() {
        PersonnePhysique pp = new PersonnePhysique();
        pp.setIdGdi("IDGDI");
        pp.setIdExtranet("IDEXTRANET");
        pp.setNom("NOM");
        pp.setPrenom("PRENOM");
        pp.setNumeroPersonneEre("NUMERE");
        pp.setNumeroPersonneMdpro("NUMMDPRO");
        return pp;
    }

    private RechercherPPSiloResponseDto createRechercherPPSiloResponseDto(String numPersonneERE) {
        RechercherPPSiloResponseDto res = new RechercherPPSiloResponseDto();
        List<PersonnePhysiqueSiloDto> personnesPhysiques = new ArrayList<>();
        res.setPersonnesPhysiques(personnesPhysiques);

        final PersonnePhysiqueSiloDto ppSilo = new PersonnePhysiqueSiloDto();
        personnesPhysiques.add(ppSilo);

        final IdentSiloDto identSiloDto = new IdentSiloDto();
        ppSilo.setIdentSiloDto(identSiloDto);
        List<IdPPSiloDto> listeIdSiloDto = new ArrayList<>();
        identSiloDto.setListeIdSiloDto(listeIdSiloDto);

        if (numPersonneERE != null) {
            listeIdSiloDto.add(IdPPSiloDto.builder().valeurId(numPersonneERE).typeId("PERSONNE_PHYSIQUE").build());
        }

        return res;
    }

    @Test
    public void test_mappingFromInputStandard() throws Exception {
        // Given
        final String json = IOUtils.resourceToString("/json/rfi-input-standard.json", StandardCharsets.UTF_8);

        // When
        final UserRequestDto userRequestDto = JsonMarshaller.fromJSON(json, UserRequestDto.class);

        // Then
        assertEquals("9daexo", userRequestDto.getUid());
        assertEquals(wrapToList("PILOTAGE"), userRequestDto.getAttributes().getSn());
        assertEquals(wrapToList("SEA"), userRequestDto.getAttributes().getGivenName());
        assertEquals(Sets.set("CET-Pilotage", "NET-Pilotage"), userRequestDto.getAttributes().getRoles());
    }

    @Test
    public void test_mappingFromInputFDI() throws Exception {
        // Given
        final String json = IOUtils.resourceToString("/json/rfi-input-fdi.json", StandardCharsets.UTF_8);

        // When
        final UserRequestDto userRequestDto = JsonMarshaller.fromJSON(json, UserRequestDto.class);

        // Then
        assertEquals("D16FA645-72E8-48D7-B43E-AD2EC4DABCAF", userRequestDto.getUid());
        assertEquals("{idEpargneRetraite=P4393784}", userRequestDto.getAttributes().businessIdMap());
        assertEquals("49505", userRequestDto.getAttributes().fdiPerimeterName());
        assertEquals(Sets.set("EERE-Salarie", "EERE-Federation"), userRequestDto.getAttributes().getRoles());
    }

    private UserResponseInternal createUserResponseInternal() {
        return UserResponseInternal.builder()
                .isAuthorized(false)
                .build();
    }
}
