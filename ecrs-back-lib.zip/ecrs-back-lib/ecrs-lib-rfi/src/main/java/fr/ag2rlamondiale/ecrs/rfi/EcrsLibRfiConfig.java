package fr.ag2rlamondiale.ecrs.rfi;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan
@Configuration
public class EcrsLibRfiConfig {
}
