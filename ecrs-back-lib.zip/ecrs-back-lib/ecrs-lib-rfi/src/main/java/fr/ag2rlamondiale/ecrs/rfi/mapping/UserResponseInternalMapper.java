package fr.ag2rlamondiale.ecrs.rfi.mapping;

import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseInternalDto;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.personne.IdPPSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.IdentSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.utils.MapUtils;
import org.mapstruct.*;

import java.util.*;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class UserResponseInternalMapper {

    @Mapping(source = ".", target = "personIdMap", qualifiedByName = "mapPersonIdMap")
    @Mapping(source = "nom", target = "sn")
    @Mapping(source = "prenom", target = "givenName")
    @Mapping(source = "civilite", target = "agCodeSexe", qualifiedByName = "mapAgCodeSexe")
    @Mapping(source = "withCompteDemo", target = "compteDemo")
    public abstract UserResponseInternalDto map(UserResponseInternal in);

    @Named("mapPersonIdMap")
    public String mapPersonIdMap(UserResponseInternal in) {
        Set<String> personIdMap = new HashSet<>();
        if (in.getIdentifiantsSiloPersonne() != null) {
            in.getIdentifiantsSiloPersonne().getListeIdSiloDto().stream()
                    .map(e -> "id" + e.getTypeId() + "=" + e.getValeurId())
                    .forEach(personIdMap::add);
        }

        if (in.getIdGdi() != null) {
            personIdMap.add("idA0554=" + in.getIdGdi());
        }
        if (in.getIdExtranet() != null) {
            personIdMap.add("idA1531=" + in.getIdExtranet());
        }

        return String.join(",", personIdMap);
    }


    @Mapping(constant = "true", target = "isAuthorized")
    @Mapping(source = "attributes.compteDemo", target = "withCompteDemo", qualifiedByName = "unwrapList")
    @Mapping(source = "attributes.sn", target = "personnePhysique.nom", qualifiedByName = "unwrapList")
    @Mapping(source = "attributes.givenName", target = "personnePhysique.prenom", qualifiedByName = "unwrapList")
    @Mapping(source = "attributes.agCodeSexe", target = "personnePhysique.civilite", qualifiedByName = "mapCivilite")
    public abstract UserResponseInternal map(UserRequestDto userRequest);

    @Named("unwrapList")
    protected <T> T unwrapList(List<T> list) {
        return WrapListUtils.unwrapList(list);
    }

    @Named("mapAgCodeSexe")
    protected String mapAgCodeSexe(String civilite) {
        if ("Madame".equals(civilite)) {
            return "F";
        }
        if ("Monsieur".equals(civilite)) {
            return "M";
        }
        return null;
    }

    @Named("mapCivilite")
    protected String mapCivilite(List<String> list) {
        final String agCodeSexe = unwrapList(list);
        if ("F".equals(agCodeSexe)) {
            return "Madame";
        }
        if ("M".equals(agCodeSexe)) {
            return "Monsieur";
        }
        return "Madame ou Monsieur";
    }

    @AfterMapping
    protected void afterMapping(@MappingTarget UserResponseInternal target, UserRequestDto userRequest) {
        Map<String, String> personIdMap = MapUtils.parseStringMap(userRequest.getAttributes().personIdMap());
        Objects.requireNonNull(personIdMap);
        final String idGdi = personIdMap.get("idA0554");
        final String idExtranet = personIdMap.get("idA1531");
        final String numeroPersonneEre = personIdMap.get("id" + CodeApplicationType.EGESPER_ERE.getCode());
        final String numeroPersonneMdp = personIdMap.get("id" + CodeApplicationType.EGESPER_MDPRO.getCode());

        final PersonnePhysique personnePhysique = target.getPersonnePhysique();
        Objects.requireNonNull(personnePhysique);

        personnePhysique.setIdGdi(idGdi);
        personnePhysique.setIdExtranet(idExtranet);
        personnePhysique.setNumeroPersonneEre(numeroPersonneEre);
        personnePhysique.setNumeroPersonneMdpro(numeroPersonneMdp);

        final IdentSiloDto identifiantsSiloPersonne = new IdentSiloDto();
        target.setIdentifiantsSiloPersonne(identifiantsSiloPersonne);

        if (numeroPersonneEre != null) {
            identifiantsSiloPersonne.getListeIdSiloDto().add(new IdPPSiloDto(numeroPersonneEre, CodeApplicationType.EGESPER_ERE.getCode()));
        }

        if (numeroPersonneMdp != null) {
            identifiantsSiloPersonne.getListeIdSiloDto().add(new IdPPSiloDto(numeroPersonneMdp, CodeApplicationType.EGESPER_MDPRO.getCode()));
        }
    }


}
