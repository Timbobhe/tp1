package fr.ag2rlamondiale.ecrs.rfi.business;

import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;

public interface IUserIdentityProviderFacade {

    UserResponseExternalDto identiteExterne(UserRequestDto userRequest);

    boolean userIsCompteDemo(IUserDetails userDetails);

    UserResponseInternal identiteInterneDepuisFederation(IUserDetails userDetails);

    UserResponseInternal identiteInterneDepuisFederation(UserRequestDto userRequest, UserRequestOptionsDto options);
}
