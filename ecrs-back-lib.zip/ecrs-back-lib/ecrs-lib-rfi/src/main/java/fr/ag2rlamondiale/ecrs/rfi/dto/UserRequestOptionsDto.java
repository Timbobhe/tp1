package fr.ag2rlamondiale.ecrs.rfi.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UserRequestOptionsDto {

    public static UserRequestOptionsDto EMPTY = new UserRequestOptionsDto();

    public static UserRequestOptionsDto escapeNull(UserRequestOptionsDto options) {
        return options != null ? options : EMPTY;
    }

    private boolean createHabili;
}
