package fr.ag2rlamondiale.ecrs.rfi.mapping;

import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@SuppressWarnings("java:S1452")
@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class UserRequestMapper {

    public static final String ROLE_PREFIX = "ROLE_";

    @Mapping(source = ".", target = "uid", qualifiedByName = "mapUid")
    @Mapping(source = "userSn", target = "attributes.sn", qualifiedByName = "wrapToList")
    @Mapping(source = "userGivenName", target = "attributes.givenName", qualifiedByName = "wrapToList")
    @Mapping(source = ".", target = "attributes.fdiPerimeterName", qualifiedByName = "mapFdiPerimeterName")
    @Mapping(source = ".", target = "attributes.agCodeSexe", qualifiedByName = "mapCodeSexe")
    @Mapping(source = ".", target = "attributes.roles", qualifiedByName = "mapRoles")
    @Mapping(source = ".", target = "attributes.businessIdMap", qualifiedByName = "mapBusinessIdMap")
    @Mapping(source = ".", target = "attributes.personIdMap", qualifiedByName = "mapPersonIdMap")
    @Mapping(source = ".", target = "attributes.compteDemo", qualifiedByName = "mapCompteDemo")
    public abstract UserRequestDto map(IUserDetails userDetails);

    @Named("mapUid")
    public String mapUid(IUserDetails userDetails) {
        return (String) userDetails.getAttributesMap().get("uid");
    }

    @Named("mapCodeSexe")
    public List<String> mapCodeSexe(IUserDetails userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("agCodeSexe"));
    }

    @Named("mapBusinessIdMap")
    public List<String> mapBusinessIdMap(IUserDetails userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("businessIdMap"));
    }

    @Named("mapPersonIdMap")
    public List<String> mapPersonIdMap(IUserDetails userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("personIdMap"));
    }

    @Named("mapFdiPerimeterName")
    public List<String> mapFdiPerimeterName(IUserDetails userDetails) {
        return wrapToList((String) userDetails.getAttributesMap().get("fdiPerimeterName"));
    }

    @Named("mapCompteDemo")
    public List<Boolean> mapCompteDemo(IUserDetails userDetails) {
        final Object compteDemo = userDetails.getAttributesMap().get("compteDemo");
        return wrapToList(compteDemo != null && (boolean) compteDemo);
    }

    @Named("wrapToList")
    protected <T> List<T> wrapToList(T e) {
        return WrapListUtils.wrapToList(e);
    }

    @Named("mapRoles")
    public Set<String> mapRoles(IUserDetails userDetails) {
        return userDetails.getAuthorities().stream()
                .map(grantedAuthority -> {
                    final String authority = grantedAuthority.getAuthority();
                    if (authority.startsWith(ROLE_PREFIX)) {
                        return authority.substring(ROLE_PREFIX.length());
                    }
                    return authority;
                })
                .collect(Collectors.toSet());
    }

    public GrantedAuthority mapToGrantedAuthority(String role) {
        return new SimpleGrantedAuthority(ROLE_PREFIX + role);
    }

    public Collection<? extends GrantedAuthority> mapToGrantedAuthority(List<String> roles) {
        if (roles == null) {
            return Collections.emptyList();
        }

        return roles.stream()
                .map(this::mapToGrantedAuthority)
                .collect(Collectors.toList());
    }


    public String mapFromGrantedAuthority(GrantedAuthority grantedAuthority) {
        final String authority = grantedAuthority.getAuthority();
        if (authority.startsWith(ROLE_PREFIX)) {
            return authority.substring(ROLE_PREFIX.length());
        }
        return authority;
    }


}
