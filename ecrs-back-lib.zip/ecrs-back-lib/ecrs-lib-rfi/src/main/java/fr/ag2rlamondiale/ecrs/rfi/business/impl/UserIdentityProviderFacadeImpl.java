package fr.ag2rlamondiale.ecrs.rfi.business.impl;

import com.ag2r.common.exceptions.CommonException;
import com.google.common.base.Strings;
import fr.ag2rlamondiale.ecrs.business.IRechercheClientFacade;
import fr.ag2rlamondiale.ecrs.business.domain.PartenaireException;
import fr.ag2rlamondiale.ecrs.business.domain.UtilisateurException;
import fr.ag2rlamondiale.ecrs.business.domain.habilitation.IdentiteNumeriqueHabilitation;
import fr.ag2rlamondiale.ecrs.rfi.business.IUserIdentityProviderFacade;
import fr.ag2rlamondiale.ecrs.rfi.domain.IUserDetails;
import fr.ag2rlamondiale.ecrs.rfi.domain.UserResponseInternal;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserRequestOptionsDto;
import fr.ag2rlamondiale.ecrs.rfi.dto.UserResponseExternalDto;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserRequestMapper;
import fr.ag2rlamondiale.ecrs.rfi.mapping.UserResponseInternalMapper;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import fr.ag2rlamondiale.trm.business.ICompteDemoFacade;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.demo.CompteDemo;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.trm.domain.comptedemo.FindCompteDemoRequestDto;
import fr.ag2rlamondiale.trm.domain.partenaire.Partenaire;
import fr.ag2rlamondiale.trm.domain.personne.*;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import fr.ag2rlamondiale.trm.security.RolesEnum;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.MapUtils;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserIdentityProviderFacadeImpl implements IUserIdentityProviderFacade {

    public static final String REF_EXTERNE = "refExterne";
    public static final String ID_EPARGNE_RETRAITE = "idEpargneRetraite";

    @Autowired
    private IRechercheClientFacade clientFacade;

    @Autowired
    private IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private ICompteDemoFacade compteDemoFacade;

    @Autowired
    private UserContextHolder userContextHolder;

    @Autowired
    private UserRequestMapper userRequestMapper;

    @Autowired
    private UserResponseInternalMapper userResponseInternalMapper;

    @SneakyThrows
    @NoAuthRequired
    @LogExecutionTime
    @Override
    public UserResponseExternalDto identiteExterne(UserRequestDto userRequest) {


        PersonnePhysique personnePhysique = null;
        if (!hasRole(userRequest, RolesEnum.FEDERATION)) {
            final String idGdi = userRequest.getUid();
            try {
                personnePhysique = clientFacade.rechercherPersonnePhysiqueParIdGdi(idGdi);
            } catch (UtilisateurException e) {
                return unauthorizedExternal();
            }
        } else if (hasRole(userRequest, RolesEnum.FEDERATION)) {
            final UserResponseInternal userResponseInternal = identiteInterneDepuisFederation(userRequest, UserRequestOptionsDto.EMPTY);
            if (Boolean.FALSE.equals(userResponseInternal.getIsAuthorized())) {
                return unauthorizedExternal();
            }
            personnePhysique = userResponseInternal.getPersonnePhysique();
        }

        if (personnePhysique != null) {

            final IdSiloDto idSilo;

            if (personnePhysique.getNumeroPersonneEre() != null) {
                idSilo = IdSiloDto.forAppli(personnePhysique.getNumeroPersonneEre(), CodeApplicationType.EGESPER_ERE);
            } else if (personnePhysique.getNumeroPersonneMdpro() != null) {
                idSilo = IdSiloDto.forAppli(personnePhysique.getNumeroPersonneEre(), CodeApplicationType.EGESPER_MDPRO);
            } else {
                return unauthorizedExternal();
            }

            final PersonnePhysiqueConsult ppc = consulterPersonneClient.basicConsulterPersPhys(idSilo);

            return UserResponseExternalDto.builder()
                    .isAuthorized(true)
                    .birthName(ppc.getNomNaissance())
                    .agCodeSexe(ppc.getCodeSexe())
                    .mobile(ppc.getTelPortable())
                    .build();
        }

        return unauthorizedExternal();
    }

    @Override
    public boolean userIsCompteDemo(IUserDetails userDetails) {
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);
        final Map<String, String> businessIdMap = MapUtils.parseStringMap(userRequest.getAttributes().businessIdMap());
        if (businessIdMap == null || businessIdMap.isEmpty()) {
            return false;
        }

        final String refExterne = Strings.emptyToNull(businessIdMap.get(REF_EXTERNE));
        CompteDemoDto compteDemo = compteDemoFacade.findCompteDemo(FindCompteDemoRequestDto.builder()
                .numReferenceExterne(refExterne)
                .build());
        return compteDemo != null;
    }


    @Override
    @NoAuthRequired
    @LogExecutionTime
    public UserResponseInternal identiteInterneDepuisFederation(IUserDetails userDetails) {
        final UserRequestDto userRequest = userRequestMapper.map(userDetails);
        return identiteInterneDepuisFederation(userRequest, UserRequestOptionsDto.builder()
                .createHabili(true)
                .build());
    }

    @SneakyThrows
    @NoAuthRequired
    @LogExecutionTime
    @Override
    @SuppressWarnings({"java:S3776", "java:S108"})
    public UserResponseInternal identiteInterneDepuisFederation(UserRequestDto userRequest, UserRequestOptionsDto options) {
        if (hasRole(userRequest, RolesEnum.FEDERATION)) {
            final UserRequestOptionsDto opts = UserRequestOptionsDto.escapeNull(options);

            final String fdiPerimeterName = WrapListUtils.unwrapList(userRequest.getAttributes().getFdiPerimeterName());

            final Map<String, String> personIdMap = MapUtils.parseStringMap(userRequest.getAttributes().personIdMap());
            if (personIdMap != null && !personIdMap.isEmpty()) {
                // On utilise les attributs pr&eacute;c&eacute;demments retourn&eacute;s
                return authorizedInternal(userRequest);
            }


            final Map<String, String> businessIdMap = MapUtils.parseStringMap(userRequest.getAttributes().businessIdMap());
            if (businessIdMap == null) {
                return unauthorizedInternal();
            }

            final String refExterne = Strings.emptyToNull(businessIdMap.get(REF_EXTERNE));
            final String idEpargneRetraite = Strings.emptyToNull(businessIdMap.get(ID_EPARGNE_RETRAITE));

            final AtomicReference<String> numPers = new AtomicReference<>(idEpargneRetraite);

            final UserResponseInternal response = UserResponseInternal.builder()
                    .isAuthorized(false) // pessimiste
                    .build();

            if (refExterne != null) {
                response.setCompteDemo(verifierCompteDemoByRefExterne(refExterne));

                DemandeRecherchePP demandeRecherchePP = new DemandeRecherchePP(refExterne);
                RechercherPPSiloResponseDto rechercherPPSilo = clientFacade.rechercherPPSilo(demandeRecherchePP);


                if (rechercherPPSilo != null && rechercherPPSilo.getPersonnesPhysiques() != null) {

                    final List<IdPPSiloDto> identifiantsPP = rechercherPPSilo.getPersonnesPhysiques().stream()
                            .flatMap(pp -> pp.getIdentSiloDto().getListeIdSiloDto().stream())
                            .filter(idPPSiloDto -> idPPSiloDto.getValeurId() != null)
                            .map(idPPSilo -> {
                                numPers.set(idPPSilo.getValeurId());
                                response.setIsAuthorized(true);
                                return new IdPPSiloDto(idPPSilo.getValeurId(), CodeApplicationType.EGESPER_ERE.getCode());
                            })
                            .collect(Collectors.toList());


                    response.setIdentifiantsSiloPersonne(new IdentSiloDto(identifiantsPP));
                }
            }

            if (numPers.get() != null) {
                // Recherche ID GDI, ID Extranet
                try {
                    IdentiteNumeriqueHabilitation idNum;
                    if (refExterne != null) {
                        idNum = IdentiteNumeriqueHabilitation.builder()
                                .login(refExterne)
                                .identifiantFournisseurIdentiteNumerique(Partenaire.CODE_NIE)
                                .build();
                    } else {
                        idNum = IdentiteNumeriqueHabilitation.builder()
                                .login(CodeApplicationType.EGESPER_ERE.getCode() + numPers.get())
                                .identifiantFournisseurIdentiteNumerique(fdiPerimeterName)
                                .build();
                    }

                    Consumer<Exception> handleErrorHabili;
                    if (response.hasCompteDemo()) {
                        handleErrorHabili = e -> {
                        };
                    } else {
                        handleErrorHabili = e -> log.warn("Erreur pendant la recherche/creation Habilitation PC", e);
                    }

                    PersonnePhysique personnePhysique = clientFacade
                            .rechercherPersonnePhysiqueEreParNumeroPersonne(numPers.get(),
                                    !response.hasCompteDemo() && opts.isCreateHabili() && idNum != null, idNum,
                                    handleErrorHabili);

                    if (personnePhysique != null) {
                        response.setIsAuthorized(true);
                        response.setPersonnePhysique(personnePhysique);

                        if (response.getIdentifiantsSiloPersonne() == null || response.getIdentifiantsSiloPersonne().isEmpty()) {
                            List<IdPPSiloDto> identifiantsPP = new ArrayList<>();
                            if (personnePhysique.getNumeroPersonneEre() != null) {
                                identifiantsPP.add(new IdPPSiloDto(personnePhysique.getNumeroPersonneEre(), CodeApplicationType.EGESPER_ERE.getCode()));
                            }
                            if (personnePhysique.getNumeroPersonneMdpro() != null) {
                                identifiantsPP.add(new IdPPSiloDto(personnePhysique.getNumeroPersonneMdpro(), CodeApplicationType.EGESPER_MDPRO.getCode()));
                            }

                            response.setIdentifiantsSiloPersonne(new IdentSiloDto(identifiantsPP));
                        }
                    }

                } catch (CommonException | PartenaireException ignore) {
                }
            }

            return response;
        }

        return unauthorizedInternal();
    }

    private UserResponseInternal authorizedInternal(UserRequestDto userRequest) {
        final UserResponseInternal internal = userResponseInternalMapper.map(userRequest);
        final Map<String, String> businessIdMap = MapUtils.parseStringMap(userRequest.getAttributes().businessIdMap());
        if (businessIdMap != null) {
            final String refExterne = Strings.emptyToNull(businessIdMap.get(REF_EXTERNE));
            internal.setCompteDemo(verifierCompteDemoByRefExterne(refExterne));
        }
        return internal;
    }

    private UserResponseExternalDto unauthorizedExternal() {
        return UserResponseExternalDto.builder()
                .isAuthorized(false)
                .build();
    }

    private UserResponseInternal unauthorizedInternal() {
        return UserResponseInternal.builder()
                .isAuthorized(false)
                .build();
    }

    private boolean hasRole(UserRequestDto userRequest, RolesEnum role) {
        return userRequest.getAttributes().getRoles().contains(role.getSuffixe());
    }

    /**
     * V&eacute;rifier si la RefExterne correspond &agrave; un Compte Demo.<br>
     * Si c'est le cas alors on va renseigner {@link fr.ag2rlamondiale.trm.security.UserContext#setCompteDemo(CompteDemo)}
     * qui va avoir pour effet de bord <u>de basculer tous les appels PFS suivants en mode Bouchonn&eacute;</u>
     *
     * @param refExterne
     * @return true si c'est un CompteDemo, false sinon
     */
    public CompteDemo verifierCompteDemoByRefExterne(String refExterne) {
        if (refExterne == null) {
            return null;
        }

        CompteDemoDto compteDemo = compteDemoFacade.findCompteDemo(FindCompteDemoRequestDto.builder()
                .numReferenceExterne(refExterne)
                .build());
        if (compteDemo != null) {
            final CompteDemo c = new CompteDemo(compteDemo.getId());
            userContextHolder.get().setCompteDemo(c);
            return c;
        }
        return null;
    }

}
