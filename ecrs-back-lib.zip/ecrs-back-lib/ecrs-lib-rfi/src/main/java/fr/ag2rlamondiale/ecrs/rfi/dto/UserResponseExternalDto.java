package fr.ag2rlamondiale.ecrs.rfi.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonPropertyOrder({
        "isAuthorized", "agCodeSexe", "birthName", "mobile"
})
public class UserResponseExternalDto {

    private Boolean isAuthorized;

    private String birthName;

    /**
     * Civit&eacute;
     * <ul>
     *     <li>"M" il faut retourner "Homme"</li>
     *     <li>"F" il faut retourner "Femme"</li>
     * </ul>
     */
    private String agCodeSexe;

    /**
     * Num&eacute;ro de t&eacute;l&eacute;phone mobile
     */
    private String mobile;

}




