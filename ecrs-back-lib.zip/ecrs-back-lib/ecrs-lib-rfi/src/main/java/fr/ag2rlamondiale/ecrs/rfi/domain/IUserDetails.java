package fr.ag2rlamondiale.ecrs.rfi.domain;

import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;

public interface IUserDetails {

    @SuppressWarnings("java:S1452")
    Collection<? extends GrantedAuthority> getAuthorities();

    String getUserSn();

    String getUserGivenName();

    Map<String, Object> getAttributesMap();
}
