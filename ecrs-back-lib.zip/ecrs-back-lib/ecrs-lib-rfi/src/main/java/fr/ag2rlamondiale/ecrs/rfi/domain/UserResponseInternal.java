package fr.ag2rlamondiale.ecrs.rfi.domain;

import fr.ag2rlamondiale.trm.demo.CompteDemo;
import fr.ag2rlamondiale.trm.domain.personne.IdentSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserResponseInternal {

    private Boolean isAuthorized;

    private CompteDemo compteDemo;

    private boolean withCompteDemo;

    private IdentSiloDto identifiantsSiloPersonne;

    private PersonnePhysique personnePhysique;

    public String getIdGdi() {
        return personnePhysique != null ? personnePhysique.getIdGdi() : null;
    }

    public String getIdExtranet() {
        return personnePhysique != null ? personnePhysique.getIdExtranet() : null;
    }

    public String getNom() {
        return personnePhysique != null ? personnePhysique.getNom() : null;
    }

    public String getPrenom() {
        return personnePhysique != null ? personnePhysique.getPrenom() : null;
    }

    public String getCivilite() {
        return personnePhysique != null ? personnePhysique.getCivilite() : null;
    }

    public boolean hasCompteDemo() {
        return this.compteDemo != null;
    }

    public void setCompteDemo(CompteDemo compteDemo) {
        this.compteDemo = compteDemo;
        this.withCompteDemo = compteDemo != null;
    }
}




