package fr.ag2rlamondiale.ecrs.rfi.utils;

import java.util.Collections;
import java.util.List;

public class WrapListUtils {

    private WrapListUtils() {
        //ignore
    }

    public static <T> List<T> wrapToList(T e) {
        if (e == null) {
            return null;
        }
        return Collections.singletonList(e);
    }

    public static <T> T unwrapList(List<T> list) {
        if (list != null && !list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }
}
