package fr.ag2rlamondiale.ecrs.rfi.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
@JsonPropertyOrder({
        "isAuthorized", "personIdMap", "sn", "givenName", "agCodeSexe", "compteDemo"
})
public class UserResponseInternalDto {

    private Boolean isAuthorized;

    private String personIdMap;

    private String sn;

    private String givenName;

    private String agCodeSexe;

    private boolean compteDemo;
}




