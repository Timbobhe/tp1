package fr.ag2rlamondiale.ecrs.rfi.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Map;

@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@Data
public class BasicUserDetails implements IUserDetails {
    private Collection<? extends GrantedAuthority> authorities;
    private String userSn;
    private String userGivenName;
    private Map<String, Object> attributesMap;
}
