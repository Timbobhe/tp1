package fr.ag2rlamondiale.ecrs.rfi.dto;

import com.fasterxml.jackson.annotation.*;
import fr.ag2rlamondiale.ecrs.rfi.utils.WrapListUtils;
import lombok.Data;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"roles", "businessIdMap", "personIdMap", "sn", "givenName", "agCodeSexe", "compteDemo", "fdiPerimeterName"})
public class AttributesDto {

    private Set<String> roles = null;

    private List<String> businessIdMap;

    private List<String> personIdMap;

    private List<String> sn;

    private List<String> givenName;

    private List<String> agCodeSexe;

    private List<Boolean> compteDemo;

    private List<String> fdiPerimeterName;

    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }


    public String personIdMap() {
        return WrapListUtils.unwrapList(this.personIdMap);
    }

    public String businessIdMap() {
        return WrapListUtils.unwrapList(this.businessIdMap);
    }

    public String fdiPerimeterName() {
        return WrapListUtils.unwrapList(this.fdiPerimeterName);
    }
}
