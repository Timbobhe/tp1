package fr.ag2rlamondiale.ecrs.domain.contrat;

import fr.ag2rlamondiale.trm.domain.contrat.*;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente un Compartiment d'un Contrat.<br>
 * <p>
 * Dans le cas ERE : Un compartiment est associé à un idAssuré, dans le cas non pacte <u>tous les compartiments ont le même IDASSURE</u>.<br>
 * Dans le cas pacte, chaque compartiment a un IDASSURE distinct.
 * </p>
 *
 * <p>
 *     Dans le cas MDP : Pour l'instant PACTE/NON PACTE un contrat a <u>un seul Compartiment</u> avec IDCONTRAT.
 * </p>
 */
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Data
public class Compartiment implements ICompartiment<ContratHeader> {
    @ToString.Exclude
    private ContratHeader contratHeader;

    private String identifiantAssure;
    private String college;
    private CompartimentType type;

    /**
     * Ne concerne que les compartiment ERE, utilisé pour l'arbitrage (support unite de compte)
     */
    private ContributionType contributionType;

    private Date dateAffiliation;
    private String libelleEtat;
    private Date dateEffetSituationAffiliation;

    private SituationContratEnum etatContrat;

    private SituationAffiliationEnum etatCompartiment;
    private String libelleEtatAssure;
    private AffichageType affichageType;
    private boolean deductible;
    private DisponibiliteType disponibilite;

    private String idCollege;

    private String raisonSocialeFront;

    public Compartiment(String identifiantAssure) {
        this.identifiantAssure = identifiantAssure;
    }

    public boolean is(CompartimentType compartimentType) {
        return type != null && type.equals(compartimentType);
    }

    public boolean is(CompartimentId compartimentId) {
        return Objects.equals(this.getCompartimentId(), compartimentId);
    }

    public CompartimentId getCompartimentId() {
        if (contratHeader.isEre()) {
            return CompartimentId.ere(this.identifiantAssure, this.type);
        } else if (contratHeader.isMdpro()) {
            return CompartimentId.mdpro(contratHeader.getId(), this.type);
        }
        throw new IllegalStateException("Silo inconnu");
    }

    public boolean isPacte() {
        return contratHeader.isPacte();
    }

    public boolean isERE() {
        return contratHeader.isEre();
    }

    public boolean isMdpro() {
        return contratHeader.isMdpro();
    }

    public String getLabel() {
        if (CompartimentType.C3.equals(type) && isERE() && isPacte()) {
            final List<String> label = new ArrayList<>();
            label.add(type.getLabel(getContratHeader().getCodeSilo(), isPacte()));
            if (getRaisonSocialeFront() != null) {
                label.add(getRaisonSocialeFront());
            }
            label.add(getCollege());
            return String.join(" - ", label);
        }

        return type.getLabel(getContratHeader().getCodeSilo(), isPacte());
    }

    @Override
    public ContratHeader getContrat() {
        return this.contratHeader;
    }
}
