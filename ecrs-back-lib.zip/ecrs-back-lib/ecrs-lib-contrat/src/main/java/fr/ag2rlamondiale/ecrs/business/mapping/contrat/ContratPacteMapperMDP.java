package fr.ag2rlamondiale.ecrs.business.mapping.contrat;

import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.utils.contrats.SituationContratCloture;
import org.mapstruct.Mapper;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_RETRAITE;
import static fr.ag2rlamondiale.trm.domain.contrat.DisponibiliteType.DISPO_SOUS_CONDITIONS;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public abstract class ContratPacteMapperMDP implements IContratPacteMapper {

    @Autowired
    private ContratMDPROHelper contratMDPROHelper;

    @Override
    public List<ContratHeader> convertToPacte(List<ContratHeaderDto> contrats, InfosContratDto infosContratDto) {
        if (contrats.size() != 1) {
            throw new IllegalArgumentException("contrats MDPRO");
        }

        final ContratHeader contrat = mapBasic(contrats.get(0));

        contrat.setDateAffiliation(contrat.getDateSitCtr());
        final boolean pacte = contratMDPROHelper.isContratPacte(contrat);
        contrat.setPacte(pacte);
        final AffichageType affichageType = SituationContratCloture.contratAffichageType(CodeSiloType.MDP,
                contrat.getEtatContrat().getCodeSilo(), contrat.getDateSitCtr(), contrat.getDateFinEffet(), contratMDPROHelper.isContainOldNumGenContratMadelin(contrat));
        contrat.setAffichageType(affichageType);
        if (AffichageType.MASQUE.equals(affichageType)) {
            return new ArrayList<>();
        }

        contrat.setCodeAssureur(infosContratDto.getContratGeneral().getCodeAssureur());
        contrat.setIdAssureurContrat(infosContratDto.getContratGeneral().getIdAssureurContrat());
        contrat.setIdAssureurContratSilo(infosContratDto.getContratGeneral().getIdAssureurContratSilo());
        contrat.setDescriptionFront(contrat.getLibelleProduit());
        contrat.setCodeCadreFiscal(infosContratDto.getContratGeneral().getCodeCadreFiscal());
        contrat.setLibCadreFiscal(infosContratDto.getContratGeneral().getLibCadreFiscal());
        contrat.setRaisonSocialeFront(infosContratDto.getContratGeneral().getContractante());
        contrat.setCodeEtat(infosContratDto.getContratGeneral().getCodeEtat());
        if (pacte) {
            return Collections.singletonList(contratPacte(contrat));
        }
        return Collections.singletonList(contratNonPacte(contrat));
    }

    /**
     * <h3>Règles pour les contrats MDPRO considérés non PACTE</h3>
     *
     * <h4>Disponibilité</h4>
     * <ul>
     *     <li>Tous les contrats sont disponibles à la Retraite</li>
     * </ul>
     *
     * <h4>Compartiments</h4>
     * La règle de construction des Compartiments s'appuie sur le <u>type de Contrat</u>  et le <u>Numéro génération du Contrat</u>; voir: {@link ContratMDPROHelper}
     *
     * <ul>
     *      <li>Type de contrat = RA09, RA10 et numGen != "pacte" => C1</li>
     *      <li>Tous les autres contrats sont classés dans "Autre Contrat"</li>
     * </ul>
     *
     * @param contratHeader
     * @return
     */
    private ContratHeader contratNonPacte(ContratHeader contratHeader) {
        final Compartiment model = modelCompartiment(contratHeader);

        if (contratMDPROHelper.isContratAutoriseNonPacte(contratHeader)) {
            final Compartiment c1 = model.toBuilder().type(CompartimentType.C1).build();
            c1.setDeductible(contratMDPROHelper.isContratDeductible(contratHeader));
            contratHeader.addCompartiment(c1);
        } else {
            contratHeader.setClasseAutreContrat(true);
        }
        return contratHeader;
    }

    @Nonnull
    private Compartiment modelCompartiment(ContratHeader contratHeader) {
        final Compartiment model = new Compartiment();
        model.setAffichageType(contratHeader.getAffichageType());
        model.setDateAffiliation(contratHeader.getDateSitCtr());
        model.setEtatContrat(contratHeader.getEtatContrat());
        model.setDeductible(false);
        model.setDisponibilite(DISPO_RETRAITE);
        return model;
    }

    /**
     * <h3>Règles pour les contrats MDPRO considérés PACTE</h3>
     *
     * <h4>Disponibilité</h4>
     * <ul>
     *     <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) sont disponibles sous Conditions (C1)</li>
     *     <li>Contrats numGen=A07, A08 sont disponibles sous conditions (C4)</li>
     *     <li>Contrats numGen=C01, C02 sont disponibles à la Retraite (C3)</li>
     *     <li>Tous les autres contrats sont disponibles à la Retraite</li>
     * </ul>
     *
     * <h4>Déductibilité</h4>
     * <ul>
     *     <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) sont déductibles (C1)</li>
     *     <li>Contrats numGen=A07, A08 ne sont pas déductibles (C4)</li>
     *     <li>Contrats numGen=C01, C02 ne sont pas déductibles (C3)</li>
     *     <li>Tous les autres contrats ne sont pas déductibles</li>
     * </ul>
     *
     * <h4>Compartiments</h4>
     * La règle de construction des Compartiments s'appuie sur le <u>type de Contrat</u>  et le <u>Numéro génération du Contrat</u>; voir: {@link ContratMDPROHelper}
     *
     * <ul>
     *      <li>Contrats Madelin, Madelin Agricole et PER (numGen = A01,A02, A03, A04) => C1</li>
     *      <li>Contrats numGen=A07, A08 ne sont pas déductibles => C4</li>
     *      <li>Contrats numGen=C01, C02 ne sont pas déductibles => C3</li>
     *      <li>Tous les autres contrats sont classés dans "Autre Contrat"</li>
     * </ul>
     *
     * @param contratHeader
     * @return
     */
    private ContratHeader contratPacte(ContratHeader contratHeader) {
        final Compartiment model = modelCompartiment(contratHeader);

        if (contratMDPROHelper.isC3Pacte(contratHeader)) {
            final Compartiment c3 = model.toBuilder().type(CompartimentType.C3)
                    .disponibilite(DISPO_RETRAITE)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .build();
            contratHeader.addCompartiment(c3);
            contratHeader.setAffichageType(AffichageType.LECTURE_SEULE);
        } else if (contratMDPROHelper.isC2Pacte(contratHeader)) {
            final Compartiment c2 = model.toBuilder().type(CompartimentType.C2)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .disponibilite(DISPO_SOUS_CONDITIONS)
                    .build();
            contratHeader.addCompartiment(c2);
            contratHeader.setAffichageType(AffichageType.LECTURE_SEULE);
        } else if (contratMDPROHelper.isContratAutorise(contratHeader)) {
            setCompartimentPourDeductibilite(contratHeader, model);
        } else {
            contratHeader.setDeductible(false);
            contratHeader.setClasseAutreContrat(true);
        }
        return contratHeader;
    }

    private void setCompartimentPourDeductibilite(ContratHeader contratHeader, Compartiment model) {
        if (contratMDPROHelper.isContratDeductible(contratHeader)) {
            final Compartiment c1 = model.toBuilder().type(CompartimentType.C1).deductible(true).disponibilite(DISPO_SOUS_CONDITIONS).build();
            contratHeader.addCompartiment(c1);
        } else {
            final Compartiment c4 = model.toBuilder().type(CompartimentType.C4).deductible(false)
                    .disponibilite(DISPO_SOUS_CONDITIONS)
                    .affichageType(AffichageType.LECTURE_SEULE)
                    .build();
            contratHeader.addCompartiment(c4);
            contratHeader.setAffichageType(AffichageType.LECTURE_SEULE);
        }
    }
}
