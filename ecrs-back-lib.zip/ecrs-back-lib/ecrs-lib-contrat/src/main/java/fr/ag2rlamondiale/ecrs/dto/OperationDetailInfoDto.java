package fr.ag2rlamondiale.ecrs.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OperationDetailInfoDto {
    private String operationId;
    private String identifiantStrucInv;
    private String label;
    private BigDecimal montant;
    private BigDecimal nbreParts;
    private BigDecimal valeurLiquidative;

    public OperationDetailInfoDto(String operationId, String identifiantStrucInv, String label, BigDecimal montant) {
        this.operationId = operationId;
        this.identifiantStrucInv = identifiantStrucInv;
        this.label = label;
        this.montant = montant;
    }
}
