package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.business.domain.operation.OperationCompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.DetailsOperationDto;
import fr.ag2rlamondiale.ecrs.dto.OperationDetailInfoDto;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.echeancier.DemandeSiloRequestDto;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.operation.*;
import fr.ag2rlamondiale.trm.domain.structinv.IdDansSiloDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class OperationFacadeImpl implements IOperationFacade {
    private static final Set<String> CODES_ETAT_OPERATION = Sets.newHashSet(CodeSituationOperationType.ARECAL.name(),
                                                                            CodeSituationOperationType.PRTVLR.name(), CodeSituationOperationType.ESTIME.name(),
                                                                            CodeSituationOperationType.ENREG.name());
    private static final List<CodeTypeOperationEREType> CODES_TYPE_OPERATION_VERSEMENT_ERE = Arrays
            .asList(CodeTypeOperationEREType.RPO, CodeTypeOperationEREType.RVL, CodeTypeOperationEREType.RPU);
    private static final List<CodeTypeOperationMDPType> CODES_TYPE_OPERATION_VERSEMENT_MDPRO = Arrays.asList(
            CodeTypeOperationMDPType.VC, CodeTypeOperationMDPType.VT, CodeTypeOperationMDPType.NA,
            CodeTypeOperationMDPType.NT, CodeTypeOperationMDPType.NL, CodeTypeOperationMDPType.VL,
            CodeTypeOperationMDPType.VP);
    public static final List<CodeTypeOperationEREType> TypesOperationsCotisationsBrutesERE = Collections
            .unmodifiableList(Lists.newArrayList(CodeTypeOperationEREType.RCP, CodeTypeOperationEREType.RCN));
    public static final List<CodeTypeOperationEREType> TypesOperationsCotisationsCETERE = Collections.unmodifiableList(Arrays
                                                                                                                               .asList(CodeTypeOperationEREType.RPX_19, CodeTypeOperationEREType.RPX_30));
    public static final List<CodeTypeOperationEREType> TypesOperationsVIFERE = Collections.unmodifiableList(Arrays
                                                                                                                    .asList(CodeTypeOperationEREType.RPO, CodeTypeOperationEREType.RVL, CodeTypeOperationEREType.RPX_20));

    @Autowired
    private IOperationsClient operationClient;

    @Override
    public List<Operation> getOperationsForArbitrageERE(String idAssure) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(CodeSiloType.ERE);
        demande.setIdAssure(idAssure);
        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);
        // On ne considere ici que les operations arbitrage à l'initiative de l'assure

        rechercherOperationsDto.setCodeTypeOperationsERE(Collections.singletonList(CodeTypeOperationEREType.GARB_A));

        final LocalDate now = LocalDate.now();
        final Date minDate = DateUtils.createDate(1, 1, now.getYear());
        final Date maxDate = DateUtils.createDate(1, 1, now.getYear() + 1);
        rechercherOperationsDto.setMinDate(minDate);
        rechercherOperationsDto.setMaxDate(maxDate);

        try {
            return operationClient.rechercherOperations(rechercherOperationsDto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public List<Operation> getOperationsForArbitrageFutureERE(String idAssure) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(CodeSiloType.ERE);
        demande.setIdAssure(idAssure);
        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);
        // On ne considere ici que les operations arbitrage Future
        final List<CodeTypeOperationEREType> codeTypeOperations = new ArrayList<>(3);
        codeTypeOperations.add(CodeTypeOperationEREType.SARB_A);
        codeTypeOperations.add(CodeTypeOperationEREType.SARB_V);
        codeTypeOperations.add(CodeTypeOperationEREType.SARB_R);

        rechercherOperationsDto.setCodeTypeOperationsERE(codeTypeOperations);

        final LocalDate now = LocalDate.now();
        final Date minDate = DateUtils.createDate(1, Calendar.JANUARY, now.getYear());
        final Date maxDate = DateUtils.createDate(1, Calendar.JANUARY, now.getYear() + 1);
        rechercherOperationsDto.setMinDate(minDate);
        rechercherOperationsDto.setMaxDate(maxDate);

        try {
            return operationClient.rechercherOperations(rechercherOperationsDto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    /**
     * Recuperer les operation avec code Etat Opération C, P, M et E (a recalculer,
     * partiellement valorise, estime, enregistre)
     *
     * @param idAssure
     * @return
     */
    @Override
    public List<Operation> getOperationsEnCoursERE(String idAssure) {
        // Pour calculer le nbre op effectuees, on recupere toutes les operations sauf
        // "ANNULE"
        final List<Operation> operations = getOperationsForArbitrageERE(idAssure);
        // Add future operations
        operations.stream().filter(this::isEncoursOperation).collect(Collectors.toList())
                           .addAll(getOperationsForArbitrageFutureERE(idAssure));
        return operations;
    }

    @Override
    public List<Operation> findOperationsToReCalculate(String idAssure, CodeSiloType codeSiloType) {
        Objects.requireNonNull(idAssure);
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(codeSiloType);
        demande.setIdAssure(idAssure);
        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);
        setCodeSituationOperation(codeSiloType, rechercherOperationsDto);
        Date now = new Date();
        rechercherOperationsDto
                .setMinDate(Date.from(now.toInstant().atZone(ZoneId.systemDefault()).minusYears(3).toInstant()));
        rechercherOperationsDto.setMaxDate(now);

        try {
            return operationClient.rechercherOperations(rechercherOperationsDto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException();
        }
    }

    private void setCodeSituationOperation(CodeSiloType codeSiloType, RechercherOperationsDto rechercherOperationsDto) {
        if (CodeSiloType.ERE.equals(codeSiloType)) {
            rechercherOperationsDto
                    .setCodeSituationOperationsERE(Collections.singletonList(CodeSituationOperationType.ARECAL.name()));
        } else if (CodeSiloType.MDP.equals(codeSiloType)) {
            rechercherOperationsDto
                    .setCodeSituationOperationsMDP(Collections.singletonList(CodeSituationOperationType.ARECAL.name()));
        }
    }

    /**
     * Check if code operation is equal to C, P, M or E (a recalculer, partiellement
     * valorise, estime, enregistre).
     *
     * @param operation
     * @return
     */
    private boolean isEncoursOperation(Operation operation) {
        if (operation == null || StringUtils.isEmpty(operation.getCodeSituationOperation())) {
            return false;
        }

        return CODES_ETAT_OPERATION.contains(operation.getCodeSituationOperation());
    }

    @Override
    public List<Operation> getOperationsForVersementSynthese(Compartiment compartiment, Date minDate, Date maxDate) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        final CodeSiloType codeSiloType = compartiment.getContratHeader().getCodeSilo();
        demande.setCodeSiloType(codeSiloType);
        RechercherOperationsDto rechercherOperationsDto;

        if (CodeSiloType.ERE.equals(codeSiloType)) {
            demande.setIdAssure(compartiment.getIdentifiantAssure());

            rechercherOperationsDto = new RechercherOperationsDto(demande);
            rechercherOperationsDto.setCodeTypeOperationsERE(CODES_TYPE_OPERATION_VERSEMENT_ERE);
            rechercherOperationsDto.setCodeSituationOperationsERE(Arrays.asList(CodeSituationOperationType.VALOR.name(),
                                                                                CodeSituationOperationType.PRTVLR.name(), CodeSituationOperationType.ARECAL.name(),
                                                                                CodeSituationOperationType.ESTIME.name(), CodeSituationOperationType.ENREG.name()));
        } else {
            demande.setIdContrat(compartiment.getContratHeader().getId());

            rechercherOperationsDto = new RechercherOperationsDto(demande);
            rechercherOperationsDto.setCodeTypeOperationsMDP(CODES_TYPE_OPERATION_VERSEMENT_MDPRO);
            rechercherOperationsDto.setCodeSituationOperationsMDP(
                    Arrays.asList(CodeSituationOperationType.VALOR.name(), CodeSituationOperationType.PRTVLR.name()));
        }
        rechercherOperationsDto.setMinDate(minDate);
        rechercherOperationsDto.setMaxDate(maxDate);
        try {
            List<Operation> operations = operationClient.rechercherOperations(rechercherOperationsDto);
            if (operations != null && !operations.isEmpty()) {
                operations.forEach(operation -> operation.setDeductible(compartiment.isDeductible()));
            }
            return operations != null ? operations : new ArrayList<>();
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public List<Operation> getOperationsForDetailsContratsPacte(Compartiment compartiment, Date minDate, Date maxDate) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        final CodeSiloType codeSiloType = compartiment.getContratHeader().getCodeSilo();
        demande.setCodeSiloType(codeSiloType);
        RechercherOperationsDto rechercherOperationsDto = null;

        if (CodeSiloType.ERE.equals(codeSiloType)) {
            demande.setIdAssure(compartiment.getIdentifiantAssure());
        } else if (CodeSiloType.MDP.equals(codeSiloType)) {
            demande.setIdContrat(compartiment.getContrat().getId());
        }
        rechercherOperationsDto = new RechercherOperationsDto(demande);
        rechercherOperationsDto.setMinDate(minDate);
        rechercherOperationsDto.setMaxDate(maxDate);
        try {
            List<Operation> operations = operationClient.rechercherOperations(rechercherOperationsDto);
            return operations != null ? operations : new ArrayList<>();
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public List<Operation> getOperationsForDetailsContratsNonPacte(ContratHeader contratHeader, Date minDate,
                                                                   Date maxDate) {

        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        final CodeSiloType codeSiloType = contratHeader.getCodeSilo();
        demande.setCodeSiloType(codeSiloType);
        RechercherOperationsDto rechercherOperationsDto;

        if (CodeSiloType.ERE.equals(codeSiloType)) {
            demande.setIdAssure(contratHeader.getIdentifiantAssure());

            rechercherOperationsDto = new RechercherOperationsDto(demande);
            rechercherOperationsDto
                    .setCodeSituationOperationsERE(Collections.singletonList(CodeSituationOperationType.VALOR.name()));
        } else {
            demande.setIdContrat(contratHeader.getId());
            rechercherOperationsDto = new RechercherOperationsDto(demande);
            rechercherOperationsDto
                    .setCodeSituationOperationsMDP(Collections.singletonList(CodeSituationOperationType.VALOR.name()));
        }
        rechercherOperationsDto.setMinDate(minDate);
        rechercherOperationsDto.setMaxDate(maxDate);

        try {
            List<Operation> operations = operationClient.rechercherOperations(rechercherOperationsDto);
            return operations != null ? operations : new ArrayList<>();
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public List<OperationCompartiment> getOperationsForDetailsContratsPacte(
            ContratHeader contratHeader, Date minDate, Date maxDate) {
        return contratHeader.getCompartiments()
                .stream()
                .map(compartiment -> {
                    final List<Operation> operations = getOperationsForDetailsContratsPacte(compartiment, minDate, maxDate);
                    return operations.stream().map(o -> new OperationCompartiment(o, compartiment)).collect(Collectors.toList());
                })
                .flatMap(List::stream)
                .collect(Collectors.toList());
    }

    // Construit la (les) ligne(s) "Détail" du tableau d'opération. Construction
    // temporaire
    @Override
    public List<OperationDetailInfoDto> getOperationsDetailsForDetailsContrat(String idOperation, String codeSiloType)
            throws TechnicalException {

        OperationDetailDto operationDetail = this.getOperationDetail(idOperation,
                                                                     CodeSiloType.fromLibelle(codeSiloType));

        List<OperationDetailInfoDto> operationDetailInfos = new ArrayList<>();

        String libelle;
        BigDecimal montantNet;
        for (OccurStructInvDto supportInvestissementDto : operationDetail.getSupportInvestissement()) {
            libelle = LibelleSupportUtils.getLibelleDetailOperation(supportInvestissementDto,
                                                                    operationDetail.getGrilles(), operationDetail.isOrigineVersCibleOperation());

            montantNet = supportInvestissementDto.getMontantOccurSupportInv();

            operationDetailInfos.add(new OperationDetailInfoDto(operationDetail.getOperationId(),
                                                                LibelleSupportUtils.getIdentifiantStrucInv(supportInvestissementDto), libelle, montantNet));
        }

        Map<String, List<OperationDetailInfoDto>> operationDetailInfosByIdentifiantStrucInv = operationDetailInfos
                .stream().collect(Collectors.groupingBy(OperationDetailInfoDto::getIdentifiantStrucInv));
        operationDetailInfos.clear();
        for (Map.Entry<String, List<OperationDetailInfoDto>> entry : operationDetailInfosByIdentifiantStrucInv
                .entrySet()) {
            operationDetailInfos.add(new OperationDetailInfoDto(entry.getValue().get(0).getOperationId(),
                                                                entry.getKey(), entry.getValue().get(0).getLabel(), entry.getValue()
                                                                        .stream()
                                                                        .map(OperationDetailInfoDto::getMontant)
                                                                        .reduce(BigDecimal.ZERO, BigDecimal::add)));
        }

        List<OperationDetailInfoDto> operationDetailInfosPositif = operationDetailInfos.stream()
                .filter(operationDetailInfoDto -> BigDecimal.ZERO.compareTo(operationDetailInfoDto.getMontant()) < 0)
                .sorted(Comparator.comparing((OperationDetailInfoDto::getMontant))).collect(Collectors.toList());

        List<OperationDetailInfoDto> operationDetailInfosNegatif = operationDetailInfos.stream()
                .filter(operationDetailInfoDto -> BigDecimal.ZERO.compareTo(operationDetailInfoDto.getMontant()) > 0)
                .sorted(Comparator.comparing((OperationDetailInfoDto::getMontant)).reversed())
                .collect(Collectors.toList());

        operationDetailInfos.clear();
        operationDetailInfos.addAll(operationDetailInfosNegatif);
        operationDetailInfos.addAll(operationDetailInfosPositif);

        return operationDetailInfos;
    }

    private OperationDetailDto getOperationDetail(String idOperation, CodeSiloType codeSiloType)
            throws TechnicalException {
        IdDansSiloDto idDansSiloDto = IdDansSiloDto.builder().valeurId(idOperation).codeSystemeInformation(codeSiloType)
                                                             .build();
        OperationDetailDto operationDetailDto = operationClient.consulterStructInvestOperations(idDansSiloDto);

        // Filtre des supports pour ne garder que les supports de type grille
        List<OccurStructInvDto> grilles = operationDetailDto.getSupportInvestissement()
                .stream()
                .filter(occurStructInvDto -> occurStructInvDto.getGrilleInv() != null
                        && occurStructInvDto.getMontantOccurSupportInv() != null)
                .collect(Collectors.toList());

        // Filtre des supports pour garder que les supports de type profil ou horizon
        // avec des fonds
        List<OccurStructInvDto> supportsTypeProfilHorizon = operationDetailDto.getSupportInvestissement()
                .stream()
                .filter(occurStructInvDto -> (occurStructInvDto.getProfilInv() != null
                        && occurStructInvDto.getMontantOccurSupportInv() != null
                        && occurStructInvDto.getMontantOccurSupportInv().doubleValue() != 0)
                        || (occurStructInvDto.getHorizonInv() != null
                        && occurStructInvDto.getMontantOccurSupportInv() != null
                        && occurStructInvDto.getMontantOccurSupportInv().doubleValue() != 0))
                .collect(Collectors.toList());

        List<OccurStructInvDto> supportsTypeProfilHorizonFiltred = new ArrayList<>(supportsTypeProfilHorizon);
        for (OccurStructInvDto parent : supportsTypeProfilHorizon) {
            supportsTypeProfilHorizonFiltred
                    .removeIf(fils -> parent.getIdOccurStructInv().equals(fils.getIdOccurParentStructInv()));
        }

        operationDetailDto.setSupportInvestissement(supportsTypeProfilHorizonFiltred);
        operationDetailDto.setGrilles(grilles);
        return operationDetailDto;
    }

    // TODO code commenté pour le moment. Construction de l'arbre des structures
    // d'investissement par Yohan en cours ds une autre US
    public DetailsOperationDto getOperationsDetailsForVersementSynthese(String idOperation, String codeSiloType) {
        return null;
    }

    /*
     * @Override public DetailsOperationDto
     * getOperationsDetailsForVersementSynthese(String idOperation, String
     * codeSiloType) throws TechnicalException { IdDansSiloDto idDansSiloDto = new
     * IdDansSiloDto(); DetailsOperationDto detailsOperationVersementDto;
     * idDansSiloDto.setValeurId(idOperation);
     * idDansSiloDto.setCodeSystemeInformation(
     * codeSiloType.equals(CodeSiloType.ERE.getLibelle()) ? CodeSiloType.ERE :
     * CodeSiloType.MDP); OperationDetailDto operationDetailDto =
     * operationClient.consulterStructInvestOperations(idDansSiloDto);
     * List<OperationDetailInfoDto> opDetailInfoDto =
     * buildOperationDetailInfosVersementSynthese(operationDetailDto, codeSiloType);
     * Map<String, List<OperationDetailInfoDto>> map =
     * opDetailInfoDto.stream().collect(Collectors.groupingBy(OperationDetailInfoDto
     * ::getIdentifiantStrucInv)); opDetailInfoDto = new ArrayList<>(); for
     * (Map.Entry<String, List<OperationDetailInfoDto>> entry : map.entrySet()) {
     * opDetailInfoDto.add(new
     * OperationDetailInfoDto(entry.getValue().get(0).getOperationId(),
     * entry.getKey(), entry.getValue().get(0).getLabel(),
     * entry.getValue().stream().filter(occ -> occ.getMontant() !=
     * null).map(OperationDetailInfoDto::getMontant).reduce(BigDecimal.ZERO,
     * BigDecimal::add), null, null)); } detailsOperationVersementDto =
     * DetailsOperationDto.builder()
     * .montantNetOperation(operationDetailDto.getMontantNet().doubleValue())
     * .typeOperation(operationDetailDto.getLibTypeOperation())
     * .operationInvestissements(opDetailInfoDto).build();
     *
     * return detailsOperationVersementDto; }
     *
     *
     * private List<OperationDetailInfoDto>
     * buildOperationDetailInfosVersementSynthese(OperationDetailDto
     * operationDetailDto, String codeSiloType) { //TODO méthode à refactorer en
     * java 8 : pourquoi ? List<OperationDetailInfoDto> operationDetailInfoDtoList =
     * new ArrayList<>(); if (CodeSiloType.ERE.name().equals(codeSiloType)) {
     * List<OccurStructInvDto> listThirdLevelStructInvest =
     * getThirdLevelFromTree(operationDetailDto); for (OccurStructInvDto
     * occurStructInvDto : listThirdLevelStructInvest) {
     * buildGrilleInvDto(occurStructInvDto, operationDetailDto,
     * operationDetailInfoDtoList); buildProfilInvDto(occurStructInvDto,
     * operationDetailDto, operationDetailInfoDtoList); } return
     * operationDetailInfoDtoList; } else { Map<Integer, List<OccurStructInvDto>>
     * structInvestByLevel = getAllLevel(operationDetailDto); for
     * (Map.Entry<Integer, List<OccurStructInvDto>> entry :
     * structInvestByLevel.entrySet()) { if
     * (hasOperationDetailInfoDtoList(operationDetailDto,
     * operationDetailInfoDtoList, entry)) return operationDetailInfoDtoList; }
     * return operationDetailInfoDtoList; } }
     */

    /*
     * @Override public DetailsOperationDto
     * getOperationsDetailsForDetailsContrat(String idOperation, String
     * codeSiloType) throws TechnicalException { IdDansSiloDto idDansSiloDto = new
     * IdDansSiloDto(); DetailsOperationDto detailsOperationDto;
     * idDansSiloDto.setValeurId(idOperation);
     * idDansSiloDto.setCodeSystemeInformation(
     * codeSiloType.equals(CodeSiloType.ERE.getLibelle()) ? CodeSiloType.ERE :
     * CodeSiloType.MDP); OperationDetailDto operationDetailDto =
     * operationClient.consulterStructInvestOperations(idDansSiloDto);
     * List<OperationDetailInfoDto> opDetailInfoDto =
     * buildOperationDetailInfosDetailsContrat(operationDetailDto, codeSiloType);
     * Map<String, List<OperationDetailInfoDto>> map =
     * opDetailInfoDto.stream().collect(Collectors.groupingBy(OperationDetailInfoDto
     * ::getIdentifiantStrucInv)); opDetailInfoDto = new ArrayList<>(); for
     * (Map.Entry<String, List<OperationDetailInfoDto>> entry : map.entrySet()) {
     * opDetailInfoDto.add(new
     * OperationDetailInfoDto(entry.getValue().get(0).getOperationId(),
     * entry.getKey(), entry.getValue().get(0).getLabel(),
     * entry.getValue().stream().filter(occ -> occ.getMontant() !=
     * null).map(OperationDetailInfoDto::getMontant).reduce(0.0, Double::sum),
     * entry.getValue().stream().filter(occ -> occ.getNbreParts() !=
     * null).map(OperationDetailInfoDto::getNbreParts).reduce(BigDecimal.ZERO,
     * BigDecimal::add), entry.getValue().stream().filter(occ ->
     * occ.getValeurLiquidative() !=
     * null).map(OperationDetailInfoDto::getValeurLiquidative).reduce(BigDecimal.
     * ZERO, BigDecimal::add)));
     *
     * } detailsOperationDto = DetailsOperationDto.builder()
     * .montantNetOperation(operationDetailDto.getMontantNet().doubleValue())
     * .typeOperation(operationDetailDto.getLibTypeOperation())
     * .operationInvestissements(opDetailInfoDto).build();
     *
     * return detailsOperationDto; }
     */

    /*
     * private List<OperationDetailInfoDto>
     * buildOperationDetailInfosDetailsContrat(OperationDetailDto
     * operationDetailDto, String codeSiloType) { List<OperationDetailInfoDto>
     * operationDetailInfoDtoList = new ArrayList<>(); if
     * (CodeSiloType.ERE.name().equals(codeSiloType)) { List<OccurStructInvDto>
     * listThirdLevelStructInvest = getThirdLevelFromTree(operationDetailDto);
     * //List<OccurStructInvDto> listFourthLevelStructInvest =
     * getOccurStructInvDtoLevel(listThirdLevelStructInvest,
     * operationDetailDto.getSupportInvestissement()); for (OccurStructInvDto
     * occurStructInvDto : listThirdLevelStructInvest) {
     * buildGrilleInvDto(occurStructInvDto, operationDetailDto,
     * operationDetailInfoDtoList); buildProfilInvDto(occurStructInvDto,
     * operationDetailDto, operationDetailInfoDtoList); } // recuperation des
     * supports du 4eme niveau à remettre après verification
     *//*
     * for (OccurStructInvDto occurStructInvDto : listFourthLevelStructInvest) {
     *
     * buildSupportInvDto(occurStructInvDto, operationDetailDto,
     * operationDetailInfoDtoList); }
     *//*
     * return operationDetailInfoDtoList; } else { Map<Integer,
     * List<OccurStructInvDto>> structInvestByLevel =
     * getAllLevel(operationDetailDto); for (Map.Entry<Integer,
     * List<OccurStructInvDto>> entry : structInvestByLevel.entrySet()) { if
     * (hasOperationDetailInfoDtoList(operationDetailDto,
     * operationDetailInfoDtoList, entry)) return operationDetailInfoDtoList; }
     * return operationDetailInfoDtoList; } }
     */

    /*
     * public boolean hasOperationDetailInfoDtoList(OperationDetailDto
     * operationDetailDto, List<OperationDetailInfoDto> operationDetailInfoDtoList,
     * Map.Entry<Integer, List<OccurStructInvDto>> entry) { if (entry.getValue() !=
     * null && operationDetailDto != null) { for (OccurStructInvDto
     * occurStructInvDto : entry.getValue()) { buildSupportInvDto(occurStructInvDto,
     * operationDetailDto, operationDetailInfoDtoList);
     * buildGrilleInvDto(occurStructInvDto, operationDetailDto,
     * operationDetailInfoDtoList); buildProfilInvDto(occurStructInvDto,
     * operationDetailDto, operationDetailInfoDtoList);
     * buildTarifInvDto(occurStructInvDto, operationDetailDto,
     * operationDetailInfoDtoList); buildContributionInvDto(occurStructInvDto,
     * operationDetailDto, operationDetailInfoDtoList); } } return
     * !operationDetailInfoDtoList.isEmpty(); }
     */

    /*
     * public void buildProfilInvDto(OccurStructInvDto occurStructInvDto,
     * OperationDetailDto operationDetailDto, List<OperationDetailInfoDto>
     * operationDetailInfoDtoList) { ProfilInvDto profilInvDto =
     * occurStructInvDto.getProfilInv(); if (profilInvDto != null &&
     * profilInvDto.getTxRepartitionProfilInv() != null &&
     * (profilInvDto.getTxRepartitionProfilInv().doubleValue() > 0 ||
     * operationDetailDto.getMontantNet().compareTo(BigDecimal.ZERO) == 0)) {
     * operationDetailInfoDtoList.add(new
     * OperationDetailInfoDto(operationDetailDto.getOperationId(),
     * profilInvDto.getIdProfilInv(), profilInvDto.getNomProfilInv(),
     * occurStructInvDto.getMontantOccurSupportInv(), null, null)); } }
     */

    /*
     * public void buildContributionInvDto(OccurStructInvDto occurStructInvDto,
     * OperationDetailDto operationDetailDto, List<OperationDetailInfoDto>
     * operationDetailInfoDtoList) { ContributionInvDto contributionInvDto =
     * occurStructInvDto.getContributionInv(); if (contributionInvDto != null &&
     * contributionInvDto.getTxRepartitionContribution() != null &&
     * (contributionInvDto.getTxRepartitionContribution().doubleValue() > 0 ||
     * operationDetailDto.getMontantNet().compareTo(BigDecimal.ZERO) == 0)) {
     * operationDetailInfoDtoList.add(new
     * OperationDetailInfoDto(operationDetailDto.getOperationId(),
     * contributionInvDto.getCodeContributionInv(),
     * contributionInvDto.getLibContributionInvSilo(),
     * occurStructInvDto.getMontantOccurSupportInv(), null, null)); } }
     */

    /*
     * public void buildTarifInvDto(OccurStructInvDto occurStructInvDto,
     * OperationDetailDto operationDetailDto, List<OperationDetailInfoDto>
     * operationDetailInfoDtoList) { TarifInvDto tarifInvDto =
     * occurStructInvDto.getTarifInv(); if (tarifInvDto != null &&
     * tarifInvDto.getTxRepartitionTarifInv() != null &&
     * (tarifInvDto.getTxRepartitionTarifInv().doubleValue() > 0 ||
     * operationDetailDto.getMontantNet().compareTo(BigDecimal.ZERO) == 0)) {
     * operationDetailInfoDtoList.add(new
     * OperationDetailInfoDto(operationDetailDto.getOperationId(),
     * tarifInvDto.getIdTarifInv(), tarifInvDto.getNomTarifInv(),
     * occurStructInvDto.getMontantOccurSupportInv(), null, null)); } }
     */

    /*
     * public void buildGrilleInvDto(OccurStructInvDto occurStructInvDto,
     * OperationDetailDto operationDetailDto, List<OperationDetailInfoDto>
     * operationDetailInfoDtoList) { GrilleInvDto grilleInvDto =
     * occurStructInvDto.getGrilleInv(); if (grilleInvDto != null &&
     * grilleInvDto.getTxRepartitionGrilleInv() != null &&
     * (grilleInvDto.getTxRepartitionGrilleInv().doubleValue() > 0 ||
     * operationDetailDto.getMontantNet().compareTo(BigDecimal.ZERO) == 0)) {
     * operationDetailInfoDtoList.add(new
     * OperationDetailInfoDto(operationDetailDto.getOperationId(),
     * grilleInvDto.getIdGrilleInv(), grilleInvDto.getNomGrilleInv(),
     * occurStructInvDto.getMontantOccurSupportInv(), null, null)); } }
     */

    /*
     * public void buildSupportInvDto(OccurStructInvDto occurStructInvDto,
     * OperationDetailDto operationDetailDto, List<OperationDetailInfoDto>
     * operationDetailInfoDtoList) { SupportInvDto supportInvDto =
     * occurStructInvDto.getSupportInv(); if (supportInvDto != null &&
     * supportInvDto.getTxRepartitionSupportInv() != null &&
     * (supportInvDto.getTxRepartitionSupportInv().doubleValue() > 0 ||
     * operationDetailDto.getMontantNet().compareTo(BigDecimal.ZERO) == 0)) { for
     * (OccurStructInvDto supportParent :
     * operationDetailDto.getSupportInvestissement()) { if
     * (occurStructInvDto.getIdOccurParentStructInv().equals(supportParent.
     * getIdOccurStructInv())) { String libelleSupportInvDto =
     * supportParent.getProfilInv() != null ?
     * supportParent.getProfilInv().getNomProfilInv() :
     * supportParent.getGrilleInv().getNomGrilleInv();
     * supportInvDto.setNomSupportInv(libelleSupportInvDto); } }
     * operationDetailInfoDtoList.add(new
     * OperationDetailInfoDto(operationDetailDto.getOperationId(),
     * supportInvDto.getIdSupportInv(), supportInvDto.getNomSupportInv(),
     * occurStructInvDto.getMontantOccurSupportInv(),
     * supportInvDto.getNbePartFonds(), supportInvDto.getValeurLiquidativeFond()));
     * } }
     */

    /*
     * public List<OccurStructInvDto> getThirdLevelFromTree(OperationDetailDto
     * operationDetailDto) { List<OccurStructInvDto> listSupportInvestissement =
     * operationDetailDto.getSupportInvestissement(); List<OccurStructInvDto>
     * secondLevel = new ArrayList<>(); if (listSupportInvestissement != null) { for
     * (OccurStructInvDto occ : listSupportInvestissement) { if
     * (occ.getIdOccurParentStructInv().equals(operationDetailDto.
     * getIdStructureInvestissement())) secondLevel.add(occ); } return
     * getOccurStructInvDtoLevel(secondLevel, listSupportInvestissement); } else {
     * return new ArrayList<>(); } }
     */

    /*
     * public Map<Integer, List<OccurStructInvDto>> getAllLevel(OperationDetailDto
     * operationDetailDto) { List<OccurStructInvDto> listSupportInvestissement =
     * operationDetailDto.getSupportInvestissement(); Map<Integer,
     * List<OccurStructInvDto>> result = new HashMap<>(); List<OccurStructInvDto>
     * level = new ArrayList<>(); if (listSupportInvestissement != null) { for
     * (OccurStructInvDto occ : listSupportInvestissement) { if
     * (occ.getIdOccurParentStructInv().equals(operationDetailDto.
     * getIdStructureInvestissement())) level.add(occ); } result.put(2, level);
     * result.put(3, getOccurStructInvDtoLevel(result.get(2),
     * listSupportInvestissement)); result.put(4,
     * getOccurStructInvDtoLevel(result.get(3), listSupportInvestissement));
     * result.put(5, getOccurStructInvDtoLevel(result.get(4),
     * listSupportInvestissement)); result.put(6,
     * getOccurStructInvDtoLevel(result.get(5), listSupportInvestissement)); return
     * result; } return new HashMap<>(); }
     */

    /*
     * public List<OccurStructInvDto>
     * getOccurStructInvDtoLevel(List<OccurStructInvDto> precedentLevel,
     * List<OccurStructInvDto> listSupportInvestissement) { List<OccurStructInvDto>
     * level = new ArrayList<>(); for (OccurStructInvDto parentOcc : precedentLevel)
     * { List<OccurStructInvDto> childrenOcc = new ArrayList<>(); for
     * (OccurStructInvDto occ : listSupportInvestissement) { if
     * (occ.getIdOccurParentStructInv().equals(parentOcc.getIdOccurStructInv()))
     * childrenOcc.add(occ); } level.addAll(childrenOcc); } return level.isEmpty() ?
     * new ArrayList<>() : level; }
     */

    @Override
    public List<Operation> getOperationsCotisationsBrutesERE(String idAssure, Date dateDebut, Date dateFin) {
        return getOperationsERE(idAssure, dateDebut, dateFin, TypesOperationsCotisationsBrutesERE);
    }

    @Override
    public List<Operation> getOperationsCotisationsCETERE(String idAssure, Date dateDebut, Date dateFin) {
        return getOperationsERE(idAssure, dateDebut, dateFin, TypesOperationsCotisationsCETERE);
    }

    @Override
    public List<Operation> getOperationsVIFERE(String idAssure, Date dateDebut, Date dateFin) {
        return getOperationsERE(idAssure, dateDebut, dateFin, TypesOperationsVIFERE);
    }

    private List<Operation> getOperationsERE(String idAssure, Date dateDebut, Date dateFin,
                                             List<CodeTypeOperationEREType> typesOperations) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        demande.setCodeSiloType(CodeSiloType.ERE);
        demande.setIdAssure(idAssure);
        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);

        rechercherOperationsDto.setCodeTypeOperationsERE(typesOperations);

        rechercherOperationsDto.setMinDate(dateDebut);
        rechercherOperationsDto.setMaxDate(dateFin);

        try {
            return operationClient.rechercherOperations(rechercherOperationsDto);
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

    @Override
    public List<Operation> getOperationsCotisationsEtVersementsSimulateurs(ContratHeader contratHeader, Date dateDebut, Date dateFin, List<CodeTypeOperationMDPType> codesTypeOpe) {
        DemandeSiloRequestDto demande = new DemandeSiloRequestDto();
        final CodeSiloType codeSiloType = contratHeader.getCodeSilo();

        demande.setCodeSiloType(codeSiloType);

        demande.setIdContrat(contratHeader.getId());

        RechercherOperationsDto rechercherOperationsDto = new RechercherOperationsDto(demande);
        rechercherOperationsDto.setCodeTypeOperationsMDP(codesTypeOpe);
        rechercherOperationsDto.setCodeSituationOperationsMDP(
                Arrays.asList(CodeSituationOperationType.VALOR.name(), CodeSituationOperationType.PRTVLR.name()));
        rechercherOperationsDto.setMinDate(dateDebut);
        rechercherOperationsDto.setMaxDate(dateFin);
        try {
            List<Operation> operations = operationClient.rechercherOperations(rechercherOperationsDto);
            if (operations != null && !operations.isEmpty()) {
                operations.forEach(operation -> operation.setDeductible(contratHeader.isDeductible()));
                return operations;
            }
            return new ArrayList<>();
        } catch (TechnicalException e) {
            throw new TechnicalRuntimeException(e);
        }
    }

}
