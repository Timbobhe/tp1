package fr.ag2rlamondiale.ecrs.utils.contrat;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;

import java.util.List;

public class ContratHelper {

    private ContratHelper() {
        // ignore
    }

    /**
     * On ne tient pas compte des contrats d&eacute;sactiv&eacute;s
     * @param contrats
     * @return
     */
    public static boolean isFilialeACA(List<ContratHeader> contrats) {
        if (contrats == null || contrats.isEmpty()) {
            return false;
        }
        return contrats.stream()
                .filter(contratHeader -> !contratHeader.getAffichageType().isDisabled())
                .allMatch(ContratHeader::isFilialeACA);
    }

    public static boolean containsEre(List<ContratHeader> contrats) {
        if (contrats == null || contrats.isEmpty()) {
            return true;
        }
        return contrats.stream()
                .filter(contratHeader -> !contratHeader.getAffichageType().isDisabled())
                .anyMatch(ContratHeader::isEre);
    }
}
