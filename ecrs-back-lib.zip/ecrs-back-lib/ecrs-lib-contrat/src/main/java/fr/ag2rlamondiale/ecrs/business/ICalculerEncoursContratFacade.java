package fr.ag2rlamondiale.ecrs.business;

import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.trm.business.IBaseCalculerEncoursContratFacade;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.encours.CalculerEncoursContratDto;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.EvolutionCompteEncours;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import org.springframework.scheduling.annotation.Async;

import java.util.Date;
import java.util.List;
import java.util.concurrent.Future;

public interface ICalculerEncoursContratFacade extends IBaseCalculerEncoursContratFacade {

    /**
     * Récupère l'encours <b>quelque soit le type</b> de contrat
     *
     * @param contratHeader
     * @return
     */
    EncoursDto getEncoursDto(ContratHeader contratHeader);

    /**
     * Récupère l'encours <b>quelque soit le type</b> de contrat
     *
     * @param compartiment
     * @return
     */
    EncoursDto getEncoursDto(Compartiment compartiment);

    CompteEncours getCompteEncoursNonPacte(ContratHeader contratHeader);

    EncoursDto getEncoursDto(ContratHeader contratHeader, List<CompartimentType> compartimentTypes);

    EncoursDto getEncoursDtoPacte(ContratHeader contratHeader);

    CompteEncours getCompteEncoursCompartiment(Compartiment compartiment);

    Encours getEncoursCompartimentEreNonPacte(Compartiment compartiment);

    @Async
    Future<EvolutionCompteEncours> getEncoursAtDateAsync(ContratHeader contrat, Date atDate);

    EvolutionCompteEncours getEncoursAtDate(ContratHeader contrat, Date atDate);
}
