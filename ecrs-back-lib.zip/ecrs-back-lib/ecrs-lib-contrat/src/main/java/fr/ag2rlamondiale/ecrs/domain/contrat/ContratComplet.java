package fr.ag2rlamondiale.ecrs.domain.contrat;

import fr.ag2rlamondiale.trm.domain.contrat.BaseContratComplet;

public class ContratComplet extends BaseContratComplet<ContratHeader> {

    public ContratComplet() {
        super();
    }

    public ContratComplet(ContratHeader contratHeader) {
        super();
        this.setContratHeader(contratHeader);
    }
}
