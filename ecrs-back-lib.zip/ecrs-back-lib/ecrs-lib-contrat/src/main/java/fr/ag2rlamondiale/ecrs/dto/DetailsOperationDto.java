package fr.ag2rlamondiale.ecrs.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class DetailsOperationDto {
    private String typeOperation;
    private double montantNetOperation;
    List<OperationDetailInfoDto> operationInvestissements;
}
