package fr.ag2rlamondiale.ecrs.utils.contrat;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentId;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.trm.utils.Sets.set;

@Service
public class ContratVifHelper {

    @Autowired
    private IConsulterPersonneClient consulterPersonneClient;

    @Autowired
    private ContratMDPROHelper contratMDPROHelper;

    public boolean isVifPossible(ContratComplet contrat) {
        return isVifPossible(contrat, null);
    }

    public boolean isVifPossible(ContratComplet contrat, CompartimentId compartimentId) {
        if (contrat == null || contrat.getContratHeader() == null) {
            return false;
        }

        if (contrat.is(MDP)) {
            return estVifPossibleSelonContratMDP(contrat.getContratHeader());
        }

        IdSiloDto idSiloDto = getIdSiloDto(contrat.getContratHeader());
        PersonnePhysiqueConsult pp;
        try {
            pp = consulterPersonneClient.consulterPersPhys(idSiloDto);
        } catch (TechnicalException e) {
            return false;
        }

        if (pp.getAge() == null || (pp.getAge() > pp.getLimiteAgeVIF())) {
            return false;
        }

        return estVifPossibleSelonContratERE(contrat, compartimentId);
    }

    public boolean isVifPossibleByListCompartimentTypes(ContratComplet contrat, List<CompartimentType> compartimentTypes) {
        return contrat.getContratHeader().compartiments(compartimentTypes).stream()
                .anyMatch(c -> this.isVifPossible(contrat, c.getCompartimentId()));
    }

    private boolean estVifPossibleSelonContratMDP(ContratHeader contratHeader) {
        return contratMDPROHelper.isVifPossible(contratHeader);
    }

    private IdSiloDto getIdSiloDto(ContratHeader contratHeader) {
        if (contratHeader.isEre()) {
            return new IdSiloDto(contratHeader.getPersonId(),
                    CodeApplicationType.EGESPER_ERE.getCode(), ERE.getLibelle());
        } else {
            return new IdSiloDto(contratHeader.getPersonId(),
                    CodeApplicationType.EGESPER_MDPRO.getCode(), MDP.getLibelle());
        }
    }

    private boolean estVifPossibleSelonContratERE(ContratComplet contrat,
                                                  CompartimentId compartimentId) {
        ContratGeneral contratGeneral = contrat.getContratGeneral();
        if ("1".equals(contratGeneral.getOptContratEpargne().getIndRefusVIF())
                || contratGeneral.getOptContratEpargne().isIndResiliation()) {
            return false;
        }

        if (contrat.isPacte()) {
            if (SituationAffiliationEnum.LIBERE.getCodeSilo()
                    .equalsIgnoreCase(contrat.compteGeneralesEre(compartimentId).getCodeEtat())) {
                Encours encours = contrat.encours(compartimentId).getValue();
                return encours.hasVLVersement();
            }

        } else {
            if (!set("3", "4", "5").contains(contratGeneral.getOptContratEpargne().getCodeTypeTenueCompte())) {
                return false;
            }

            if (SituationAffiliationEnum.LIBERE.getCodeSilo()
                    .equalsIgnoreCase(contrat.getCompteGeneralesERE().getCodeEtat())) {
                Encours encours = contrat.getEncours().getValue();
                return encours.hasVLVersement();
            }
        }

        return true;
    }
}
