package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.ICalculerEncoursContratFacade;
import fr.ag2rlamondiale.ecrs.business.IOperationFacade;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.OperationToRecalculate;
import fr.ag2rlamondiale.trm.business.IBaseCalculerEncoursContratFacade;
import fr.ag2rlamondiale.trm.business.impl.BaseCalculerEncoursContratFacadeImpl;
import fr.ag2rlamondiale.trm.client.soap.ICalculerEncoursContratClient;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.contrat.IContrat;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.exception.CodeSiloTypeNonGereException;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.spring.AppImpl;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.time.ZoneId;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.RUNTIME_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.SIMPLE_KEY_GENERATOR;

interface ICacheCalculerEncoursContratFacade {
    String CACHE_NAME = "ICacheCalculerEncoursContratFacade.calculerEncoursContrat";

    CompteEncours calculerEncoursContrat(CalculerEncoursContratDto dto);
}

@Slf4j
@Service
@Primary
@AppImpl(implemtationOf = IBaseCalculerEncoursContratFacade.class)
public class CalculerEncoursContratFacadeImpl extends BaseCalculerEncoursContratFacadeImpl implements ICalculerEncoursContratFacade, ICacheCalculerEncoursContratFacade, SelfReferencingBean {
    public static final String ENCOURS_CONTRAT_EN_ERREUR = "Service calculerEncoursContrat en erreur : {}";
    private static final String ENCOURS_OP_A_RECALCULER = "ERR_90020";

    @Autowired
    private IOperationFacade operationFacade;

    @Autowired
    private ICalculerEncoursContratClient calculerEncoursContratClient;

    private ICacheCalculerEncoursContratFacade springProxy = this;

    private CompteEncours basicCalculerEncours(CalculerEncoursContratDto dto) {
        try {
            return calculerEncoursContratClient.calculerEncoursContrat(dto);
        } catch (TechnicalException e) {
            log.error(ENCOURS_CONTRAT_EN_ERREUR, e.toString());
            CompteEncours compteEncours = new CompteEncours();
            compteEncours.setEncoursEnErreur(true);
            return compteEncours;
        }
    }


    @Override
    @Cacheable(value = CACHE_NAME, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = SIMPLE_KEY_GENERATOR)
    public CompteEncours calculerEncoursContrat(CalculerEncoursContratDto dto) {
        try {
            return calculerEncoursContratClient.calculerEncoursContratNoCache(dto);
        } catch (TechnicalException e) {
            if (!dto.isRecalculOperationARecalculer()) {
                return encoursEnErreur(e);
            }
            OperationToRecalculate operationToRecalculate = hasOperationToRecalculate(e, dto);
            if (operationToRecalculate.isHasOperation()) {
                Date dayBefore = getJourPrecedent(operationToRecalculate.getOperation().getDate());
                dto.setDateEncours(dayBefore);
                return basicCalculerEncours(dto);
            }
            return encoursEnErreur(e);
        }
    }

    @Nonnull
    private CompteEncours encoursEnErreur(TechnicalException e) {
        CompteEncours compteEncours = new CompteEncours();
        setEncoursInError(e, compteEncours);
        return compteEncours;
    }

    @Nonnull
    public Date getJourPrecedent(Date dateOperation) {
        return Date.from(dateOperation.toInstant()
                                      .atZone(ZoneId.systemDefault())
                                      .minusDays(1)
                                      .toInstant());
    }

    @Override
    /**
     * A utiliser uniquement pour un contrat mdPro ou ERE non pacte
     */
    public CompteEncours getCompteEncoursNonPacte(ContratHeader contratHeader) {
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        dto.setCodeSiloType(contratHeader.getCodeSilo());
        if (contratHeader.isMdpro()) {
            dto.setIdContrat(contratHeader.getId());
        } else {
            dto.setIdAssure(contratHeader.getIdentifiantAssure());
        }
        return this.springProxy.calculerEncoursContrat(dto);
    }

    @Override
    public EncoursDto getEncoursDto(ContratHeader contratHeader) {
        if (contratHeader.isEre() && !contratHeader.isPacte() || contratHeader.isMdpro()) {
            CompteEncours compteEncours = this.getCompteEncoursNonPacte(contratHeader);
            return new EncoursDto(compteEncours);
        } else {
            return this.getEncoursDtoPacte(contratHeader);
        }
    }

    @Override
    public EncoursDto getEncoursDto(Compartiment compartiment) {
        if (compartiment.isMdpro() || compartiment.isERE() && compartiment.isPacte()) {
            CompteEncours compteEncours = this.getCompteEncoursCompartiment(compartiment);
            return new EncoursDto(compteEncours);
        } else if (compartiment.isERE() && !compartiment.isPacte()) {
            Encours encoursEreNonPacte = this.getEncoursCompartimentEreNonPacte(compartiment);
            return new EncoursDto(encoursEreNonPacte);
        }
        return EncoursDto.builder()
                .encoursEnErreur(false)
                .montantEncours(0.0)
                .build();
    }

    @Override
    public EncoursDto getEncoursDto(ContratHeader contratHeader, List<CompartimentType> compartimentTypes) {
        List<EncoursDto> encoursCompartiments = new ArrayList<>();
        for (Compartiment compartiment : contratHeader.compartiments(compartimentTypes)) {
            EncoursDto compteEncours = getEncoursDto(compartiment);
            encoursCompartiments.add(compteEncours);
        }
        boolean encoursEnErreur = encoursCompartiments.stream().anyMatch(EncoursDto::isEncoursEnErreur);
        if (!encoursEnErreur) {
            return EncoursDto.builder()
                    .montantEncours(sommeEncoursCompartiments(encoursCompartiments))
                    .dateEncours(encoursCompartiments.get(0).getDateEncours())
                    .encoursEnErreur(false)
                    .build();
        }
        return EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
    }

    @Override
    public EncoursDto getEncoursDtoPacte(ContratHeader contratHeader) {
        List<EncoursDto> encoursCompartiments = new ArrayList<>();
        for (Compartiment compartiment : contratHeader.getCompartiments()) {
            CompteEncours compteEncours = getCompteEncoursCompartiment(compartiment);
            encoursCompartiments.add(new EncoursDto(compteEncours));
        }
        boolean encoursEnErreur = encoursCompartiments.stream().anyMatch(EncoursDto::isEncoursEnErreur);
        if (!encoursEnErreur) {
            return EncoursDto.builder()
                    .montantEncours(sommeEncoursCompartiments(encoursCompartiments))
                    .dateEncours(getDatePlusRecenteDesCompartiments(encoursCompartiments))
                    .encoursEnErreur(false)
                    .build();
        }
        return EncoursDto.builder()
                .encoursEnErreur(true)
                .build();
    }

    private String getDatePlusRecenteDesCompartiments(List<EncoursDto> encoursCompartiments) {
        return encoursCompartiments.stream()
                .map(u -> DateUtils.stringToDate(u.getDateEncours()))
                .max(Date::compareTo)
                .map(DateUtils::dateToString)
                .orElse(null);
    }

    private Double sommeEncoursCompartiments(List<EncoursDto> encoursDtoList) {
        Double encours = 0.0;
        for (EncoursDto encoursDto : encoursDtoList) {
            if (!encoursDto.isEncoursEnErreur()) {
                encours += encoursDto.getMontantEncours();
            }
        }
        return encours;
    }

    public CompteEncours getCompteEncoursCompartiment(Compartiment compartiment) {
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        final ContratHeader contratHeader = compartiment.getContratHeader();
        dto.setCodeSiloType(contratHeader.getCodeSilo());
        if (contratHeader.isMdpro()) {
            dto.setIdContrat(contratHeader.getId());
        } else {
            dto.setIdAssure(compartiment.getIdentifiantAssure());
        }
        return this.springProxy.calculerEncoursContrat(dto);
    }

    /**
     * Calcul de l'Encours construit en récupérant les <b>montants</b> des {@link ContributionType} correspond au {@link Compartiment#getType()}
     *
     * @param compartiment
     * @return
     */
    public Encours getEncoursCompartimentEreNonPacte(Compartiment compartiment) {
        final CompteEncours compteEncours = getCompteEncoursCompartiment(compartiment);
        BasicEncours res = new BasicEncours();
        if (compteEncours.isEnErreur()) {
            res.setEnErreur(true);
            return res;
        }
        if (CompartimentType.C1.equals(compartiment.getType()) || CompartimentType.C4.equals(compartiment.getType())) {
            res.setHasVLVersement(compteEncours.hasVLVersement());
        }
        res.setMontant(BigDecimal.ZERO);
        res.setDate(compteEncours.getDate());

        ContributionType.forCompartimentNonPacte(compartiment.getType()).forEach(contributionType -> {
            final BigDecimal mnt = getMontantByCodeContributionInv(compteEncours, contributionType.getCode());
            res.addMontant(mnt);
        });

        return res;
    }

    @Override
    @Async
    public Future<EvolutionCompteEncours> getEncoursAtDateAsync(ContratHeader contrat, Date atDate) {
        return CompletableFuture.completedFuture(getEncoursAtDate(contrat, atDate));
    }

    @Override
    public EvolutionCompteEncours getEncoursAtDate(ContratHeader contrat, Date atDate) {
        if (contrat.isEre() && contrat.isPacte()) {
            return getEncoursAtDateErePacte(contrat, atDate);
        }

        if (!contrat.isPacte()) {
            return getEncoursAtDateNonPacte(contrat, atDate);
        }

        throw new CodeSiloTypeNonGereException(contrat.getCodeSilo());
    }

    public EvolutionCompteEncours getEncoursAtDateErePacte(ContratHeader contrat, Date atDate) {
        final List<CompartimentEncours> compartimentEncours = contrat.getCompartiments()
                .stream()
                .map(compart -> CompartimentEncours.builder()
                        .compartimentType(compart.getType())
                        .encours(getEncoursAtDate(compart, atDate))
                        .deductible(compart.isDeductible())
                        .build())
                .collect(Collectors.toList());

        final BasicEncours encours = compartimentEncours.stream()
                .map(CompartimentEncours::getEncours)
                .map(BasicEncours::new)
                .reduce(new BasicEncours(), (a, b) -> {
                    a.setEnErreur(a.isEnErreur() && b.isEnErreur());
                    if (!a.isEnErreur()) {
                        a.setHasVLVersement(a.hasVLVersement() || b.hasVLVersement());
                        a.addMontant(b.getMontant());
                    }
                    return a;
                });
        if (encours.getDate() == null || encours.getDate().compareTo(atDate) > 0) {
            encours.setDate(atDate);
        }
        return EvolutionCompteEncours.builder()
                .encours(encours)
                .compartimentEncours(compartimentEncours)
                .build();
    }

    public EvolutionCompteEncours getEncoursAtDateNonPacte(ContratHeader contrat, Date atDate) {
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        dto.setCodeSiloType(contrat.getCodeSilo());
        dto.setDateEncours(atDate);
        if (contrat.isMdpro()) {
            dto.setIdContrat(contrat.getNomContrat());
        } else if (contrat.isEre()) {
            dto.setIdAssure(contrat.getIdentifiantAssure());
        }
        final CompteEncours compteEncours = this.springProxy.calculerEncoursContrat(dto);
        if (compteEncours.getDate() == null || compteEncours.getDate().compareTo(atDate) > 0) {
            compteEncours.setDateValeur(atDate);
        }
        return EvolutionCompteEncours.builder()
                .encours(compteEncours)
                .build();
    }

    public Encours getEncoursAtDate(Compartiment compartiment, Date atDate) {
        IContrat contrat = compartiment.getContrat();
        if (contrat.isEre() && !contrat.isPacte()) {
            return this.getEncoursCompartimentEreNonPacteAtDate(compartiment, atDate);
        } else {
            CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
            dto.setCodeSiloType(contrat.getCodeSilo());
            dto.setDateEncours(atDate);
            if (contrat.isMdpro()) {
                dto.setIdContrat(contrat.getNomContrat());
            } else if (contrat.isEre()) {
                dto.setIdAssure(compartiment.getCompartimentId().getIdAssure());
            } else {
                throw new CodeSiloTypeNonGereException(contrat.getCodeSilo());
            }

            return this.springProxy.calculerEncoursContrat(dto);
        }
    }

    private Encours getEncoursCompartimentEreNonPacteAtDate(Compartiment compartiment, Date atDate) {
        IContrat contrat = compartiment.getContrat();
        CalculerEncoursContratDto dto = new CalculerEncoursContratDto();
        dto.setCodeSiloType(contrat.getCodeSilo());
        dto.setIdAssure(contrat.getIdAssureNonPacte());
        dto.setDateEncours(atDate);
        CompteEncours compteEncours = this.springProxy.calculerEncoursContrat(dto);
        BasicEncours res = new BasicEncours();
        if (compteEncours.isEnErreur()) {
            res.setEnErreur(true);
        } else {
            if (CompartimentType.C1.equals(compartiment.getType()) || CompartimentType.C4.equals(compartiment.getType())) {
                res.setHasVLVersement(compteEncours.hasVLVersement());
            }

            res.setMontant(BigDecimal.ZERO);
            res.setDate(compteEncours.getDate());
            ContributionType.forCompartimentNonPacte(compartiment.getType())
                    .stream()
                    .map(contributionType -> this.getMontantByCodeContributionInv(compteEncours, contributionType.getCode()))
                    .forEach(res::addMontant);
        }
        return res;
    }


    private BigDecimal getMontantByCodeContributionInv(CompteEncours compteEncours, String codeContribution) {
        if (compteEncours.getOccurStructInvList() == null) {
            return BigDecimal.ZERO;
        }
        return compteEncours.getOccurStructInvList()
                .stream()
                .filter(occ -> occ.getContributionInv() != null)
                .filter(occ -> codeContribution.equals(occ.getContributionInv().getCodeContributionInv()))
                .map(OccurStructInvDto::getMontantOccurSupportInv)
                .findFirst()
                .orElse(BigDecimal.ZERO);
    }

    private boolean isOperationOfLastThreeMonths(Operation operation) {
        return operation.getDate().after(dateThreeMonthsAgo())
                && operation.getDate().before(DateUtils.getTodayTimelessDate());
    }

    @Nonnull
    public Date dateThreeMonthsAgo() {
        return Date.from(DateUtils.getTodayTimelessDate()
                                  .toInstant()
                                  .atZone(ZoneId.systemDefault())
                                  .minusMonths(3)
                                  .toInstant());
    }

    private boolean hasErrorEncoursToRecalculate(TechnicalException e) {
        return e.getCause() != null && e.getCause().getMessage() != null
                && e.getCause().getMessage().contains(ENCOURS_OP_A_RECALCULER);
    }

    private OperationToRecalculate hasOperationToRecalculate(TechnicalException e, CalculerEncoursContratDto dto) {
        OperationToRecalculate operationToRecalculate = new OperationToRecalculate();
        if (hasErrorEncoursToRecalculate(e)) {
            List<Operation> operations = operationFacade.findOperationsToReCalculate(dto.getIdAssure(), dto.getCodeSiloType());
            if (!CollectionUtils.isEmpty(operations)) {
                Optional<Operation> oldestOperationOfPastThreeMonths = operations.stream()
                        .filter(this::isOperationOfLastThreeMonths)
                        .min(Comparator.comparing(Operation::getDate));
                operationToRecalculate.setHasOperation(oldestOperationOfPastThreeMonths.isPresent());
                operationToRecalculate.setOperation(oldestOperationOfPastThreeMonths.orElse(null));
            }
        }
        return operationToRecalculate;
    }


    private void setEncoursInError(TechnicalException e, CompteEncours compteEncours) {
        log.error(ENCOURS_CONTRAT_EN_ERREUR, e.toString());
        compteEncours.setEncoursEnErreur(true);
    }

    @Override
    public void setProxy(Object proxy) {
        this.springProxy = (ICacheCalculerEncoursContratFacade) proxy;
    }

}
