package fr.ag2rlamondiale.ecrs;

import fr.ag2rlamondiale.ecrs.business.EcrsLibClientConfig;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@ComponentScan
@Configuration
@Import(EcrsLibClientConfig.class)
public class EcrsLibContratConfig {
}
