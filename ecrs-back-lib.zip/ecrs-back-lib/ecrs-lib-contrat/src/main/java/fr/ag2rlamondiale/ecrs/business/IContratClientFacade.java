package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;

import java.util.List;

public interface IContratClientFacade {
    List<ContratHeader> rechercherContratsPersonne(PersonnePhysique personnePhysique) throws TechnicalException;

    List<ContratHeader> rechercherContratsPersonne(RechercherContratsDto critere) throws TechnicalException;

    List<ContratHeader> rechercherContratsEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException;

    List<ContratHeader> rechercherContratsRetraiteSuppEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException;

    void forceCacheEvictRechercherContratsPersonne(RechercherContratsDto critere);
}
