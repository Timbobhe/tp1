package fr.ag2rlamondiale.ecrs.business.mapping.contrat;

import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;

import java.util.List;

public interface IContratPacteMapper {

    List<ContratHeader> convertToPacte(List<ContratHeaderDto> contratHeaderDto, InfosContratDto infosContratDto);

    ContratHeader mapBasic(ContratHeaderDto dto);
}
