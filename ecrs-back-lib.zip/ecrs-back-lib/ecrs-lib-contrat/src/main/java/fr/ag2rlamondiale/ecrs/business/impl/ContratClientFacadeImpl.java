package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.IContratClientFacade;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperERE;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperMDP;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.compte.ConsulterCompteGeneralesEREDto;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import fr.ag2rlamondiale.trm.utils.Lambda;
import fr.ag2rlamondiale.trm.utils.SelfReferencingBean;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Nonnull;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.cache.CacheConstants.RUNTIME_CACHE_RESOLVER;
import static fr.ag2rlamondiale.trm.cache.CacheConstants.XCALLER_SIMPLE_KEY_GENERATOR;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.ERE;
import static fr.ag2rlamondiale.trm.domain.CodeSiloType.MDP;
import static fr.ag2rlamondiale.trm.utils.Lambda.handleException;

@Slf4j
@Service
public class ContratClientFacadeImpl implements IContratClientFacade, SelfReferencingBean {
    private static final String CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP = "CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP";
    private static final String CACHE_RECHERCHER_CONTRATS_EPARGNE_PREVOYANCE = "CACHE_RECHERCHER_CONTRATS_EPARGNE_PREVOYANCE";
    private static final String CACHE_RECHERCHER_CONTRATS_RETRAITE_SUPP_AND_EPARGNE_PREVOYANCE = "CACHE_RECHERCHER_CONTRATS_RETRAITE_SUPP_AND_EPARGNE_PREVOYANCE";
    @Autowired
    private IContratsClient contratClient;

    @Autowired
    private ContratPacteMapperERE contratPacteMapperERE;

    @Autowired
    private ContratPacteMapperMDP contratPacteMapperMDP;

    private IContratClientFacade springProxy;

    @Override
    public List<ContratHeader> rechercherContratsPersonne(PersonnePhysique personnePhysique) throws TechnicalException {
        List<RechercherContratsDto> criteres = new ArrayList<>();
        if (personnePhysique.getNumeroPersonneEre()!=null) {
            RechercherContratsDto critere = new RechercherContratsDto();
            critere.setCodeSilo(ERE);
            critere.setPersonId(personnePhysique.getNumeroPersonneEre());
            critere.setCodeAppli(ERE.ptv());
            criteres.add(critere);
        }

        if (personnePhysique.getNumeroPersonneMdpro()!=null) {
            RechercherContratsDto critere = new RechercherContratsDto();
            critere.setCodeSilo(MDP);
            critere.setPersonId(personnePhysique.getNumeroPersonneMdpro());
            critere.setCodeAppli(MDP.ptv());
            criteres.add(critere);
        }

        if (criteres.isEmpty()) {
            throw new IllegalArgumentException("La PP n'a pas de numero ERE et MDP");
        }

        return criteres.stream()
                .parallel()
                .flatMap(critere -> handleException(() -> this.springProxy.rechercherContratsPersonne(critere).stream()))
                .collect(Collectors.toList());
    }

    @Override
    @LogExecutionTime
    @Cacheable(cacheNames = CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = XCALLER_SIMPLE_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsPersonne(RechercherContratsDto critere) throws TechnicalException {
        Objects.requireNonNull(critere.getPersonId());
        final List<ContratHeaderDto> contratsDto = contratClient.rechercherContratsRetraiteSupp(critere);
        prefetchInfosContrat(contratsDto);
        return convertToPacte(contratsDto);
    }

    @Override
    @LogExecutionTime
    @Cacheable(cacheNames = CACHE_RECHERCHER_CONTRATS_EPARGNE_PREVOYANCE, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = XCALLER_SIMPLE_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException {
        Objects.requireNonNull(critere.getPersonId());
        final List<ContratHeaderDto> contratsDto = contratClient.rechercherContratsEpargnePrevoyance(critere);
        prefetchInfosContrat(contratsDto);
        return convertToPacte(contratsDto);
    }

    @Override
    @LogExecutionTime
    @Cacheable(cacheNames = CACHE_RECHERCHER_CONTRATS_RETRAITE_SUPP_AND_EPARGNE_PREVOYANCE, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = XCALLER_SIMPLE_KEY_GENERATOR)
    public List<ContratHeader> rechercherContratsRetraiteSuppEpargnePrevoyance(RechercherContratsDto critere) throws TechnicalException {
        Objects.requireNonNull(critere.getPersonId());
        final List<ContratHeaderDto> contratsDto = contratClient.rechercherContratsPersonneV3(critere);
        prefetchInfosContrat(contratsDto);
        return convertToPacte(contratsDto);
    }

    @Nonnull
    private List<ContratHeader> convertToPacte(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        final List<ContratHeader> liste = new ArrayList<>();

        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final ContratId contratId = entry.getKey();
            final List<ContratHeaderDto> contrats = entry.getValue();

            final InfosContratDto infosContratDto = retrieveInfosContrat(contratId, contrats);
            if (contratId.is(MDP)) {
                liste.addAll(contratPacteMapperMDP.convertToPacte(distinctMDP(contrats), infosContratDto));
            } else if (contratId.is(ERE)) {
                List<ContratHeader> collect = contratPacteMapperERE.convertToPacte(contrats, infosContratDto).stream()
                        .filter(contratHeader1 -> !AffichageType.MASQUE.equals(contratHeader1.getAffichageType()))
                        .collect(Collectors.toList());
                liste.addAll(collect);
            }
        }
        return liste;
    }

    @Nonnull
    private List<ContratHeaderDto> distinctMDP(List<ContratHeaderDto> contrats) {
        if (contrats.size() == 1) {
            return contrats;
        }

        final List<ContratHeaderDto> res = contrats.stream().distinct().collect(Collectors.toList());
        if (contrats.size() > res.size()) {
            log.warn("BACK 8X retourne des contrats MDP en doublon {}", contrats);
        }
        return res;
    }

    private InfosContratDto retrieveInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        InfosContratDto infosContratDto = new InfosContratDto();
        final ContratGeneral contratGeneral = this.contratClient
                .consulterContratGenerales(new ConsulterContratGeneralesDto(contratId));
        infosContratDto.setContratGeneral(contratGeneral);

        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() -> {
                    final CompteGeneralesERE cge = this.contratClient
                            .consulterCompteGeneralesERE(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()));
                    infosContratDto.add(cge);
                }));
            }
        }

        return infosContratDto;
    }

    private void prefetchInfosContrat(List<ContratHeaderDto> contratsDto) throws TechnicalException {
        final Map<ContratId, List<ContratHeaderDto>> map = contratsDto.stream().collect(Collectors.groupingBy(ContratHeaderDto::getContratId));
        for (Map.Entry<ContratId, List<ContratHeaderDto>> entry : map.entrySet()) {
            final ContratId contratId = entry.getKey();
            final List<ContratHeaderDto> contratHeaderDtos = entry.getValue();
            prefetchInfosContrat(contratId, contratHeaderDtos);
        }
    }

    private void prefetchInfosContrat(ContratId contratId, List<ContratHeaderDto> contrats) throws TechnicalException {
        this.contratClient.consulterContratGeneralesAsync(new ConsulterContratGeneralesDto(contratId));
        for (ContratHeaderDto contratHeaderDto : contrats) {
            if (ERE.equals(contratHeaderDto.getCodeSilo())) {
                contratHeaderDto.getCompart().forEach(compart -> Lambda.handleException(() -> {
                    this.contratClient
                            .consulterCompteGeneralesEREAsync(new ConsulterCompteGeneralesEREDto(compart.getIdAssure()));
                }));
            }
        }
    }

    @Override
    @CacheEvict(cacheNames = {CACHE_RECHERCHER_CONTRATS_PERSONNE_RETRAITE_SUPP, CACHE_RECHERCHER_CONTRATS_EPARGNE_PREVOYANCE, CACHE_RECHERCHER_CONTRATS_RETRAITE_SUPP_AND_EPARGNE_PREVOYANCE}, cacheResolver = RUNTIME_CACHE_RESOLVER, keyGenerator = XCALLER_SIMPLE_KEY_GENERATOR)
    public void forceCacheEvictRechercherContratsPersonne(RechercherContratsDto critere) {
        contratClient.forceCacheEvictRechercherContratsPersonne(critere);
    }

    @Override
    public void setProxy(Object o) {
        this.springProxy = (IContratClientFacade) o;
    }
}
