package fr.ag2rlamondiale.ecrs.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import org.apache.commons.collections4.CollectionUtils;

import java.util.List;

public class LibelleSupportUtils {

    /**
     * Prefixe du libellé d'une ligne de détail d'une opération d'arbitrage ou de changement
     * d'horizon pour le support d'origine
     */
    private static final String ORIGINE_PREFIX = "De : ";

    /**
     * Prefixe du libellé d'une ligne de détail d'une opération d'arbitrage ou de changement
     * d'horizon pour le support de destination
     */
    private static final String DEST_PREFIX = "Vers : ";

    private static final String ERROR_CONST = "Structure d'investissement inconnue: ";

    private LibelleSupportUtils() {
        //EMPTY
    }

    public static String getLibelleDetailOperation(OccurStructInvDto supportInvestissementDto, List<OccurStructInvDto> grilles, boolean isOrigineVersCibleOperation) throws TechnicalException {
        String libelle = getNom(supportInvestissementDto);
        // Si la structure est de type Grille Horizon, il faut dans
        // le libelle prefixer l'horizon par le nom de la grille.
        if (CollectionUtils.isNotEmpty(grilles) && supportInvestissementDto.getHorizonInv() != null) {
            libelle = getLibelleGrilleHorizon(supportInvestissementDto, grilles, libelle);
        }

        // Dans le cas d'une operation de mouvement d'une structure vers une autre structure
        // d'investissement, on prefixe la structure d'origine par "De : " et la structure
        // cible par "Vers : "
        if (isOrigineVersCibleOperation) {
            // Pour reconnaitre la structure d'origine, on regarde le montant présent sur le
            // support: celui-ci sera négatif. Pour la structure cible, le montant sera positif
            boolean isStructureOrigine = supportInvestissementDto.getMontantOccurSupportInv() != null && supportInvestissementDto.getMontantOccurSupportInv().doubleValue() < 0.0D;
            if (isStructureOrigine) {
                libelle = ORIGINE_PREFIX + libelle;
            } else {
                libelle = DEST_PREFIX + libelle;
            }
        }

        return libelle;
    }

    private static String getLibelleGrilleHorizon(OccurStructInvDto supportInvestissementDto, List<OccurStructInvDto> grilles, String libelle) throws TechnicalException {
        String idStructInvestGrille = supportInvestissementDto.getIdOccurParentStructInv();
        for (OccurStructInvDto occurStructInv : grilles) {
            if (occurStructInv.getIdOccurStructInv().equals(idStructInvestGrille)) {
                String libelleGrille = getNom(occurStructInv);
                if (libelleGrille != null && !libelleGrille.isEmpty()) {
                    libelle = formatLibelleGrilleHorizon(libelleGrille, libelle);
                }
                break;
            }
        }
        return libelle;
    }

    private static String formatLibelleGrilleHorizon(String libelleGrille, String libelleHorizon) {
        return libelleGrille + " : " + libelleHorizon;
    }

    private static String getNom(OccurStructInvDto structInv) throws TechnicalException {
        if (structInv.getGrilleInv() != null) {
            return structInv.getGrilleInv().getNomGrilleInv();
        } else if (structInv.getHorizonInv() != null) {
            return structInv.getHorizonInv().getNomHorizonInv();
        } else if (structInv.getProfilInv() != null) {
            return structInv.getProfilInv().getNomProfilInv();
        } else if (structInv.getSupportInv() != null) {
            return structInv.getSupportInv().getNomSupportInv();
        } else if (structInv.getTarifInv() != null) {
            return structInv.getTarifInv().getNomTarifInv();
        } else {
            throw new TechnicalException(ERROR_CONST + structInv);
        }
    }

    public static String getIdentifiantStrucInv(OccurStructInvDto structInv) throws TechnicalException {
        if (structInv.getGrilleInv() != null) {
            return structInv.getGrilleInv().getIdGrilleInv();
        } else if (structInv.getHorizonInv() != null) {
            return structInv.getHorizonInv().getIdHorizonInv();
        } else if (structInv.getProfilInv() != null) {
            return structInv.getProfilInv().getIdProfilInv();
        } else if (structInv.getSupportInv() != null) {
            return structInv.getSupportInv().getIdSupportInv();
        } else if (structInv.getTarifInv() != null) {
            return structInv.getTarifInv().getIdTarifInv();
        } else {
            throw new TechnicalException(ERROR_CONST + structInv);
        }
    }
}
