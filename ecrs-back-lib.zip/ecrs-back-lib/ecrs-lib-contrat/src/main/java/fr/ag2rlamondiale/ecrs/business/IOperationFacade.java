package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.domain.operation.OperationCompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.DetailsOperationDto;
import fr.ag2rlamondiale.ecrs.dto.OperationDetailInfoDto;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationMDPType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;

import java.util.Date;
import java.util.List;

public interface IOperationFacade {

    List<Operation> getOperationsForArbitrageERE(String idAssure);

    List<Operation> getOperationsForArbitrageFutureERE(String idAssure);

    List<Operation> getOperationsEnCoursERE(String idAssure);

    List<Operation> findOperationsToReCalculate(String idAssure, CodeSiloType codeSiloType);

    List<Operation> getOperationsForVersementSynthese(Compartiment compartiment, Date minDate, Date maxDate);

    List<Operation> getOperationsForDetailsContratsPacte(Compartiment compartiment, Date minDate, Date maxDate);

    List<Operation> getOperationsForDetailsContratsNonPacte(ContratHeader contratHeader, Date minDate, Date maxDate);

    List<OperationCompartiment> getOperationsForDetailsContratsPacte(ContratHeader contratHeader, Date minDate,
                                                                     Date maxDate);

    DetailsOperationDto getOperationsDetailsForVersementSynthese(String idOperation, String codeSiloType)
            throws TechnicalException;

//    DetailsOperationDto getOperationsDetailsForDetailsContrat(String idOperation, String codeSiloType) throws TechnicalException;

    List<Operation> getOperationsCotisationsBrutesERE(String idAssure, Date dateDebut, Date dateFin);

    List<OperationDetailInfoDto> getOperationsDetailsForDetailsContrat(String idOperation, String codeSiloType) throws TechnicalException;
    List<Operation> getOperationsCotisationsCETERE(String idAssure, Date dateDebut, Date dateFin);

    List<Operation> getOperationsVIFERE(String idAssure, Date dateDebut, Date dateFin);

	List<Operation> getOperationsCotisationsEtVersementsSimulateurs(ContratHeader contratHeader, Date dateDebut, Date dateFin, List<CodeTypeOperationMDPType> codesTypeOpe);

}
