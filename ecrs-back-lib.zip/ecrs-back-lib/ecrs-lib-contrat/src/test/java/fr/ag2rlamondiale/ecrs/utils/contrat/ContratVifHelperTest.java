package fr.ag2rlamondiale.ecrs.utils.contrat;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.trm.client.soap.IConsulterPersonneClient;
import fr.ag2rlamondiale.trm.domain.CodeApplicationType;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratComplet;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.OptContratEpargne;
import fr.ag2rlamondiale.trm.domain.encours.CompteEncours;
import fr.ag2rlamondiale.trm.domain.encours.ContributionInvDto;
import fr.ag2rlamondiale.trm.domain.encours.Encours;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.personne.IdSiloDto;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysiqueConsult;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import fr.ag2rlamondiale.trm.utils.Memoizer;
import fr.ag2rlamondiale.trm.utils.contrats.SituationAffiliationEnum;
import fr.ag2rlamondiale.trm.domain.contrat.SituationContratEnum;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import javax.annotation.Nonnull;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ContratVifHelperTest {

    @InjectMocks
    ContratVifHelper contratVifHelper;

    @Spy
    @InjectMocks
    ContratMDPROHelper contratMDPROHelper;

    @Mock
    UserContextHolder userContextHolder;

    @Mock
    IConsulterPersonneClient consulterPersonneClient;

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    @Before
    public void init() throws TechnicalException {
        MockitoAnnotations.initMocks(this);

        when(userContextHolder.get()).thenReturn(getUserContext());
        IdSiloDto idEre = idEre();
        IdSiloDto idEreAgeSup = idEreAgeSup();
        IdSiloDto idMdpro = idMdpro();
        when(consulterPersonneClient.consulterPersPhys(idEre)).thenReturn(getPersonnePhysiqueConsult(false));
        when(consulterPersonneClient.consulterPersPhys(idEreAgeSup)).thenReturn(getPersonnePhysiqueConsult(true));
        when(consulterPersonneClient.consulterPersPhys(idMdpro)).thenReturn(getPersonnePhysiqueConsult(false));

        ProduitJson produitDeductible = createProduitJson("RA09", "V10", "PERP", Boolean.TRUE);
        ProduitJson produitNonDeductible = createProduitJson("RA10", "V10", null, null);
        when(paramConsoleFacade.findProduitMdpro("RA09V10")).thenReturn(produitDeductible);
        when(paramConsoleFacade.findProduitMdpro("RA10V10")).thenReturn(produitNonDeductible);
    }

    private ProduitJson createProduitJson(String typeContrat, String numGen, String fiscalite, Boolean deductible) {
        ProduitJson produit = new ProduitJson();
        produit.setCodeFiliale("LMX");
        produit.setTypeContrat(typeContrat);
        produit.setNumeroGeneration(numGen);
        produit.setLibelleFiscalite(fiscalite);
        produit.setDeductible(deductible);
        return produit;
    }

    @Nonnull
    private IdSiloDto idMdpro() {
        return new IdSiloDto("MDP", CodeApplicationType.EGESPER_MDPRO.getCode(), CodeSiloType.MDP.getLibelle());
    }

    @Nonnull
    private IdSiloDto idEre() {
        return new IdSiloDto("ERE",
                CodeApplicationType.EGESPER_ERE.getCode(), CodeSiloType.ERE.getLibelle());
    }

    @Nonnull
    private IdSiloDto idEreAgeSup() {
        return new IdSiloDto("ERE65",
                CodeApplicationType.EGESPER_ERE.getCode(), CodeSiloType.ERE.getLibelle());
    }

    private PersonnePhysiqueConsult getPersonnePhysiqueConsult(boolean ageSup) {
        PersonnePhysiqueConsult pp = new PersonnePhysiqueConsult();
        if (ageSup) {
            pp.setAge(65);
            pp.setLimiteAgeVIF(62);
        } else {
            pp.setAge(62);
            pp.setLimiteAgeVIF(65);
        }
        return pp;
    }

    private UserContext getUserContext() {
        UserContext user = new UserContext();
        user.setNumeroPersonneEre("ERE");
        user.setNumeroPersonneMdpro("MDP");
        return user;
    }

    @Test
    public void isVifPossibleTest1() {
        ContratComplet complet = null;
        boolean retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
        complet = new ContratComplet();
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
        complet.setCompteGeneralesERE(new CompteGeneralesERE());
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
        ContratGeneral general = getContratGeneral(false);
        complet.setContratGeneral(general);
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
    }

    @Test
    public void isVifPossibleTest2_ere() {
        ContratComplet complet = new ContratComplet();
        complet.setCompteGeneralesERE(new CompteGeneralesERE());
        ContratGeneral general = getContratGeneral(true);

        general.setOptContratEpargne(new OptContratEpargne());
        complet.setContratGeneral(general);

        complet.setContratHeader(getContratHeaderEre(true));
        boolean retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
    }

    @Test
    public void isVifPossibleTest2_mdpro() {
        ContratComplet complet = new ContratComplet();
        ContratGeneral general = getContratGeneral(true);

        general.setOptContratEpargne(new OptContratEpargne());
        complet.setContratGeneral(general);

        complet.setContratHeader(getContratHeaderMDPRO("RA09", "V10"));
        assertTrue(contratVifHelper.isVifPossible(complet));
    }

    @Test
    public void isVifPossibleTest3_mdpro() {
        ContratComplet complet = new ContratComplet();
        ContratGeneral general = getContratGeneral(true);

        general.setOptContratEpargne(new OptContratEpargne());
        complet.setContratGeneral(general);

        complet.setContratHeader(getContratHeaderMDPRO("RA10", "V10"));
        assertFalse(contratVifHelper.isVifPossible(complet));
    }

    @Nonnull
    private ContratHeader getContratHeaderMdpro() {
        final ContratHeader contratHeader = getContratHeader(CodeSiloType.MDP);
        contratHeader.setPersonId(idMdpro().getLibIdPersonne());
        return contratHeader;
    }

    @Nonnull
    private ContratHeader getContratHeaderEre(boolean ageSup) {
        final ContratHeader contratHeader = getContratHeader(CodeSiloType.ERE);
        final IdSiloDto id = ageSup ? idEreAgeSup() : idEre();
        contratHeader.setPersonId(id.getLibIdPersonne());
        return contratHeader;
    }

    @Test
    public void isVifPossibleTest3() {
        ContratComplet complet = new ContratComplet();
        complet.setContratHeader(getContratHeaderEre(false));
        Memoizer<Encours> memoizer = new Memoizer<>(this::createEncours);
        complet.setEncours(memoizer);
        complet.setCompteGeneralesERE(new CompteGeneralesERE());
        ContratGeneral general = getContratGeneral(true);
        general.setOptContratEpargne(getOptContratEpargne("1", true, "3"));
        complet.setContratGeneral(general);

        boolean retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);

        complet.getContratGeneral().setOptContratEpargne(getOptContratEpargne("1", true, "1"));
        complet.getContratHeader().setEtatContrat(SituationContratEnum.REDUIT);
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);

        complet.getContratGeneral().setOptContratEpargne(getOptContratEpargne("1", false, "1"));
        complet.getContratHeader().setEtatContrat(SituationContratEnum.REDUIT);
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);

        complet.getContratGeneral().setOptContratEpargne(getOptContratEpargne("1", true, "1"));
        complet.getContratHeader().setEtatContrat(SituationContratEnum.RACHETE_OFFICE);
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);

        complet.getContratGeneral().setOptContratEpargne(getOptContratEpargne("2", false, "3"));
        complet.getContratHeader().setEtatContrat(SituationContratEnum.REDUIT);
        complet.getCompteGeneralesERE().setCodeEtat(SituationAffiliationEnum.TERME.getCodeSilo());
        retour = contratVifHelper.isVifPossible(complet);
        assertTrue(retour);

        complet.getContratGeneral().setOptContratEpargne(getOptContratEpargne("2", false, "3"));
        complet.getContratHeader().setEtatContrat(SituationContratEnum.REDUIT);
        complet.getCompteGeneralesERE().setCodeEtat(SituationAffiliationEnum.LIBERE.getCodeSilo());
        retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
    }

    @Test
    public void isVifPossibleFail() throws TechnicalException {
        ContratComplet complet = new ContratComplet();
        complet.setCompteGeneralesERE(new CompteGeneralesERE());
        ContratGeneral general = getContratGeneral(true);
        general.setOptContratEpargne(getOptContratEpargne("1", false, "3"));
        complet.setContratGeneral(general);
        complet.setContratHeader(getContratHeaderEre(false));
        IdSiloDto id1 = idEre();
        when(consulterPersonneClient.consulterPersPhys(id1)).thenThrow(new TechnicalException());
        boolean retour = contratVifHelper.isVifPossible(complet);
        assertFalse(retour);
    }

    private CompteEncours createEncours() {
        CompteEncours encours = new CompteEncours();
        encours.setDateValeur(new Date());
        encours.setMontantEncours(BigDecimal.TEN);
        encours.setOccurStructInvList(createOccuList());
        return encours;
    }

    private List<OccurStructInvDto> createOccuList() {
        OccurStructInvDto occ0 = new OccurStructInvDto();
        occ0.setIdOccurParentStructInv("1");
        ContributionInvDto contrib0 = new ContributionInvDto();
        contrib0.setCodeContributionInv("VERLIB");

        OccurStructInvDto occ1 = new OccurStructInvDto();
        occ1.setIdOccurParentStructInv("1");
        ContributionInvDto contrib1 = new ContributionInvDto();
        contrib1.setCodeContributionInv("PPATRO");

        OccurStructInvDto occ2 = new OccurStructInvDto();
        occ2.setIdOccurParentStructInv("1");
        ContributionInvDto contrib2 = new ContributionInvDto();
        contrib2.setCodeContributionInv("PSALAR");

        occ0.setMontantOccurSupportInv(BigDecimal.TEN);
        occ1.setMontantOccurSupportInv(BigDecimal.TEN);
        occ2.setMontantOccurSupportInv(BigDecimal.TEN);
        occ0.setContributionInv(contrib0);
        occ1.setContributionInv(contrib1);
        occ2.setContributionInv(contrib2);

        return Arrays.asList(occ0, occ1, occ2);
    }

    private ContratHeader getContratHeader(CodeSiloType codeSilo) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(codeSilo);
        return contratHeader;
    }

    private ContratHeader getContratHeaderMDPRO(String typeContrat, String numGenContrat) {
        return ContratHeader.builder()
                .typeContrat(typeContrat)
                .numGenContrat(numGenContrat)
                .codeSilo(CodeSiloType.MDP)
                .etatContrat(SituationContratEnum.EN_COURS)
                .build();
    }

    private ContratGeneral getContratGeneral(boolean withOpt) {
        ContratGeneral general = new ContratGeneral();
        if (withOpt) {
            OptContratEpargne opt = new OptContratEpargne();
            general.setOptContratEpargne(opt);
        }
        return general;
    }

    private OptContratEpargne getOptContratEpargne(String indRefusVIF, boolean isIndResiliation,
                                                   String codeTypeTenueCompte) {
        OptContratEpargne opt = new OptContratEpargne();
        opt.setIndRefusVIF(indRefusVIF);
        opt.setIndResiliation(isIndResiliation);
        opt.setCodeTypeTenueCompte(codeTypeTenueCompte);
        return opt;
    }
}
