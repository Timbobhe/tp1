package fr.ag2rlamondiale.ecrs.domain.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.*;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class ContratHeaderTest {

    @Test
    void test_getCodeFiliale_MDP() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .build();

        // When
        final String codeFiliale = contratHeader.getCodeFiliale();

        // Then
        assertEquals("LMX", codeFiliale);
    }

    @Test
    void test_getCodeFiliale_ERE() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .codeFiliale("codeFiliale")
                .build();

        // When
        final String codeFiliale = contratHeader.getCodeFiliale();

        // Then
        assertEquals("codeFiliale", codeFiliale);
    }

    @Test
    void test_getCodeFiliale_ACA_true() throws Exception {
        // Given
        for (String codeFiliale : ContratConstants.FILIALES_ACA) {
            ContratHeader contratHeader = ContratHeader.builder()
                    .codeSilo(CodeSiloType.ERE)
                    .codeFiliale(codeFiliale)
                    .build();

            // When
            final boolean filialeACA = contratHeader.isFilialeACA();

            // Then
            assertTrue(filialeACA);
        }
    }

    @Test
    void test_getCodeFiliale_ACA_false() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .codeFiliale("autre")
                .build();

        // When
        final boolean filialeACA = contratHeader.isFilialeACA();

        // Then
        assertFalse(filialeACA);
    }

    @Test
    void test_silo_ere() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .identifiantAssure("idAssure")
                .build();

        // Then
        assertTrue(contratHeader.is(CodeSiloType.ERE));
        assertTrue(contratHeader.isEre());
        assertFalse(contratHeader.isMdpro());
        assertEquals("idAssure", contratHeader.getIdentifiantAssureParDefaut());

    }

    @Test
    void test_silo_mdp() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .build();

        // Then
        assertTrue(contratHeader.is(CodeSiloType.MDP));
        assertTrue(contratHeader.isMdpro());
        assertFalse(contratHeader.isEre());
    }

    @Test
    void test_compartiments() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .build();

        // Then
        assertFalse(contratHeader.hasCompartiments());
    }

    @Test
    void test_contratId_ere() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .idAdherente("ID_ADHERENTE")
                .idContractante("ID_CONTRACTANTE")
                .idCollege("ID_COLLEGE")
                .build();

        // When
        final ContratId contratId = contratHeader.getContratId();

        // Then
        assertTrue(contratId.is(CodeSiloType.ERE));
        assertEquals("ID", contratId.getNomContrat());
        assertEquals("ID_ADHERENTE", contratId.getIdAdherente());
        assertEquals("ID_CONTRACTANTE", contratId.getIdContractante());
        assertEquals("ID_COLLEGE", contratId.getIdCollege());
    }

    @Test
    void test_contratId_mdp() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .idAdherente("ID_ADHERENTE")
                .idContractante("ID_CONTRACTANTE")
                .idCollege("ID_COLLEGE")
                .build();

        // When
        final ContratId contratId = contratHeader.getContratId();

        // Then
        assertTrue(contratId.is(CodeSiloType.MDP));
        assertEquals("ID", contratId.getNomContrat());
        assertNull(contratId.getIdAdherente(), "ID_ADHERENTE");
        assertNull(contratId.getIdContractante(), "ID_CONTRACTANTE");
        assertNull(contratId.getIdCollege(), "ID_COLLEGE");
    }

    @Test
    void test_getMetierContrat() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .idAdherente("ID_ADHERENTE")
                .idContractante("ID_CONTRACTANTE")
                .idCollege("ID_COLLEGE")
                .build();

        // Then
        assertEquals(MetierContratType.RETRAITE_SUPPLEMENTAIRE, contratHeader.getMetierContrat());
    }

    @Test
    void test_isMadelin_false() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .idAdherente("ID_ADHERENTE")
                .idContractante("ID_CONTRACTANTE")
                .idCollege("ID_COLLEGE")
                .build();


        // Then
        assertFalse(contratHeader.isMadelin());
    }

    @Test
    void test_contrat_pacte_ere() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("ID")
                .idAdherente("ID_ADHERENTE")
                .idContractante("ID_CONTRACTANTE")
                .idCollege("ID_COLLEGE")
                .pacte(true)
                .build();

        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C1)
                .identifiantAssure("id1")
                .build());

        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C4)
                .identifiantAssure("id4")
                .build());

        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C2)
                .identifiantAssure("id2")
                .build());

        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C3)
                .identifiantAssure("id3a")
                .build());

        contratHeader.addCompartiment(Compartiment.builder()
                .type(CompartimentType.C3)
                .identifiantAssure("id3b")
                .build());

        // When
        final Set<String> identifiantsAssures = contratHeader.getIdentifiantsAssures();
        final List<Compartiment> compartimentsC1 = contratHeader.compartiments(CompartimentType.C1);
        final List<Compartiment> compartimentsC4 = contratHeader.compartiments(CompartimentType.C4);
        final List<Compartiment> compartimentsC2 = contratHeader.compartiments(CompartimentType.C2);
        final List<Compartiment> compartimentsC3 = contratHeader.compartiments(CompartimentType.C3);

        // Then
        assertEquals(Set.of("id1", "id2", "id3a", "id3b", "id4"), identifiantsAssures);
        assertEquals(1, compartimentsC1.size());
        assertEquals(1, compartimentsC2.size());
        assertEquals(1, compartimentsC4.size());
        assertEquals(2, compartimentsC3.size());
        assertEquals(2, contratHeader.compartiments(List.of(CompartimentType.C1, CompartimentType.C4)).size());
        assertNotNull(contratHeader.compartimentEre("id3b"));
        assertNull(contratHeader.compartimentEre("id5"));
        assertEquals(CompartimentId.ere("id1", CompartimentType.C1), contratHeader.compartimentEre("id1").getCompartimentId());
        assertTrue(contratHeader.hasCompartiments(CompartimentType.C1));

        AtomicInteger nb = new AtomicInteger(0);
        contratHeader.compartiment(CompartimentType.C3, compartiment -> nb.addAndGet(1));
        assertEquals(2, nb.get());

        contratHeader.compartiment(CompartimentType.C1, compartiment -> assertEquals(contratHeader, compartiment.getContratHeader()));
        contratHeader.compartiment(CompartimentType.C4, compartiment -> assertEquals(contratHeader, compartiment.getContratHeader()));
        contratHeader.compartiment(CompartimentType.C2, compartiment -> assertEquals(contratHeader, compartiment.getContratHeader()));
        contratHeader.compartiment(CompartimentType.C3, compartiment -> assertEquals(contratHeader, compartiment.getContratHeader()));

        contratHeader.compartiment(CompartimentType.C1, compartiment -> assertSame(compartiment, contratHeader.compartiment(compartiment.getCompartimentId())));
        contratHeader.compartiment(CompartimentType.C4, compartiment -> assertSame(compartiment, contratHeader.compartiment(compartiment.getCompartimentId())));
        contratHeader.compartiment(CompartimentType.C2, compartiment -> assertSame(compartiment, contratHeader.compartiment(compartiment.getCompartimentId())));
        contratHeader.compartiment(CompartimentType.C3, compartiment -> assertSame(compartiment, contratHeader.compartiment(compartiment.getCompartimentId())));

        contratHeader.compartiment(CompartimentType.C1, compartiment -> {
            assertTrue(compartiment.isERE());
            assertFalse(compartiment.isMdpro());
            assertTrue(compartiment.isPacte());
        });


        assertTrue(contratHeader.concerneAssure("id1"));
        assertFalse(contratHeader.concerneAssure("idX"));
    }

    @Test
    void test_mdp() throws Exception {
        // Given
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.MDP)
                .id("ID")
                .numGenContrat("V21")
                .typeContrat("RA09")
                .build();

        // When
        assertTrue(contratHeader.isMadelin());
        assertTrue(contratHeader.getIdentifiantsAssures().isEmpty());
    }
}
