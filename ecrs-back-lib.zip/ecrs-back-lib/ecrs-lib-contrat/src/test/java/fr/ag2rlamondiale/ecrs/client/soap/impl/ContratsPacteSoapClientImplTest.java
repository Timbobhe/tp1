package fr.ag2rlamondiale.ecrs.client.soap.impl;

import fr.ag2rlamondiale.ecrs.business.impl.ContratClientFacadeImpl;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperEREImpl;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperMDPImpl;
import fr.ag2rlamondiale.ecrs.client.soap.impl.mock.ContratClientConfig;
import fr.ag2rlamondiale.ecrs.client.soap.impl.mock.ContratsClientMock;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.utils.contrat.ContratMDPROHelper;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.dto.RechercherContratsDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class ContratsPacteSoapClientImplTest {

    @InjectMocks
    private ContratClientFacadeImpl contratClientFacade;

    @InjectMocks
    private ContratPacteMapperEREImpl contratPacteMapperERE;

    @InjectMocks
    private ContratPacteMapperMDPImpl contratPacteMapperMDP;

    @Mock
    private ContratMDPROHelper contratMDPROHelper;

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    private IContratsClient contratClient;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        ReflectionTestUtils.setField(contratClientFacade, "contratPacteMapperERE", contratPacteMapperERE);
        ReflectionTestUtils.setField(contratClientFacade, "contratPacteMapperMDP", contratPacteMapperMDP);
        ReflectionTestUtils.setField(contratMDPROHelper, "paramConsoleFacade", paramConsoleFacade);
        when(contratMDPROHelper.isContratPacte(any(ContratHeader.class))).thenReturn(Boolean.TRUE);
    }

    @Test
    public void test_rechercherContratsPersonne_ERE() throws Exception {
        contratClient = new ContratsClientMock(ContratClientConfig.P5210012);
        ReflectionTestUtils.setField(contratClientFacade, "contratClient", contratClient);

        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsPersonne(new RechercherContratsDto(CodeSiloType.ERE, "P5210012"));

        log.info("Contrats = {}", contratHeaders.size());
        assertEquals(1, contratHeaders.size());

        for (ContratHeader contratHeader : contratHeaders) {
            log.info("{}", contratHeader);
        }
    }

    @Test
    public void test_rechercherContratsPersonne_ERE_petit_collectif() throws Exception {
        contratClient = new ContratsClientMock(ContratClientConfig.P4565355);
        ReflectionTestUtils.setField(contratClientFacade, "contratClient", contratClient);

        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsPersonne(new RechercherContratsDto(CodeSiloType.ERE, "P5159994"));

        log.info("Contrats = {}", contratHeaders.size());
        assertEquals(3, contratHeaders.size());

        for (ContratHeader contratHeader : contratHeaders) {
            log.info("{}", contratHeader);
        }

        final ContratHeader contratHeader = contratHeaders.stream()
                .filter(contrat -> StringUtils.equalsIgnoreCase("RG152215407", contrat.getId()))
                .findFirst()
                .get();
        assertTrue(contratHeader.isPetitCollectifPTV());
    }

    @Test
    public void test_rechercherContratsPersonne_MDP() throws Exception {
        contratClient = new ContratsClientMock(ContratClientConfig.P1022071);
        ReflectionTestUtils.setField(contratClientFacade, "contratClient", contratClient);

        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsPersonne(new RechercherContratsDto(CodeSiloType.MDP, "P1022071"));

        log.info("Contrats = {}", contratHeaders.size());
        assertEquals(2, contratHeaders.size());

        for (ContratHeader contratHeader : contratHeaders) {
            log.info("{}", contratHeader);
        }
    }

    @Test
    public void test_rechercherContratsPersonne_MDP_P0770514() throws Exception {
        contratClient = new ContratsClientMock(ContratClientConfig.P0770514);
        ReflectionTestUtils.setField(contratClientFacade, "contratClient", contratClient);

        final List<ContratHeader> contratHeaders = contratClientFacade.rechercherContratsPersonne(new RechercherContratsDto(CodeSiloType.MDP, "P0770514"));

        log.info("Contrats = {}", contratHeaders.size());
        assertEquals(1, contratHeaders.size());

        for (ContratHeader contratHeader : contratHeaders) {
            log.info("{}", contratHeader);
        }
    }

}
