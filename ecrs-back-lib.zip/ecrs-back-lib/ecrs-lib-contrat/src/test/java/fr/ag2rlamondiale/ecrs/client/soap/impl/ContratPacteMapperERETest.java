package fr.ag2rlamondiale.ecrs.client.soap.impl;

import com.alm.esb.service.contratconsult_3.consultercontratgenerales_1.ConsulterContratGeneralesResponseType;
import com.alm.esb.service.gestcontratere_1.consultercomptegeneralesere_1.ConsulterCompteGeneralesEREResponseType;
import com.alm.esb.service.gestctrpers_1.rechercherctrperssilo_3.RechercherCtrPersSiloResponseType;
import fr.ag2rlamondiale.ecrs.business.mapping.contrat.ContratPacteMapperEREImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.business.IParamConsoleFacade;
import fr.ag2rlamondiale.trm.client.soap.impl.ContratsSoapClientImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.DateMapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.comptes.ConsulterCompteGeneralesEREResponseMapperImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.contrats.LibelleOffreMdp3Mapper;
import fr.ag2rlamondiale.trm.client.soap.mapping.contrats.RechercherContratsResponse3MapperImpl;
import fr.ag2rlamondiale.trm.client.soap.mapping.contratsgenerales.ConsulterContratGeneralesResponseMapperImpl;
import fr.ag2rlamondiale.trm.csv.EtatAssureMapper;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.commun.ProduitJson;
import fr.ag2rlamondiale.trm.domain.compte.CompteGeneralesERE;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.ContratId;
import fr.ag2rlamondiale.trm.domain.contrat.dto.ContratHeaderDto;
import fr.ag2rlamondiale.trm.domain.contrat.dto.InfosContratDto;
import fr.ag2rlamondiale.trm.domain.qad.SupportInvestissementJson;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Slf4j
@RunWith(MockitoJUnitRunner.Silent.class)
public class ContratPacteMapperERETest {

    @InjectMocks
    private RechercherContratsResponse3MapperImpl mapperRechercherContratsResponse3;

    @InjectMocks
    private ConsulterContratGeneralesResponseMapperImpl consulterContratGeneralesResponseMapper;

    @InjectMocks
    private ConsulterCompteGeneralesEREResponseMapperImpl compteGeneralesEREResponseMapper;

    @Spy
    DateMapper dateMapper;

    @Spy
    EtatAssureMapper etatAssureMapper;

    @Spy
    @InjectMocks
    LibelleOffreMdp3Mapper libelleOffreMdpMapper;

    @Mock
    IParamConsoleFacade paramConsoleFacade;

    private ContratPacteMapperEREImpl sut = new ContratPacteMapperEREImpl();

    @Before
    public void init() {
        IParamConsoleFacade produitFacade = mock(IParamConsoleFacade.class);
        when(produitFacade.findProduitMdpro(eq("RA09V41"))).thenReturn(produit("Retraite Professionnels"));
        ProduitJson produitJson = new ProduitJson();
        produitJson.setLibelle("ACA");
        produitJson.setTypeContrat("RG04");
        produitJson.setNumeroGeneration("003");
        produitJson.setLibelle("MOCKDATA");
        when(produitFacade.findProduitEre(any(String.class), any(String.class), any(String.class))).thenReturn(Optional.of(produitJson));
        ReflectionTestUtils.setField(libelleOffreMdpMapper, "produitFacade", produitFacade);
        ReflectionTestUtils.setField(mapperRechercherContratsResponse3, "libelleOffreMdpMapper", libelleOffreMdpMapper);
        ReflectionTestUtils.setField(consulterContratGeneralesResponseMapper, "libelleOffreMdpMapper", libelleOffreMdpMapper);
        ReflectionTestUtils.setField(consulterContratGeneralesResponseMapper, "paramConsoleFacade", produitFacade);
        when(paramConsoleFacade.getSupportsInvestissement(any())).thenReturn(supportInvestissement("9495", "24 trimestres"));
        MockitoAnnotations.initMocks(this);
    }

    private SupportInvestissementJson supportInvestissement(String code, String libelle) {
        SupportInvestissementJson support = new SupportInvestissementJson();
        support.setCodeSupport(code);
        support.setLibelleFront(libelle);
        return support;
    }

    @Test
    public void test_convertToPacte_P5210012() {

        //Given
        List<ContratHeaderDto> contratHeaderDtoList = buildContratHeaderDtoList("P5210012");

        ContratId contratId = ContratId.builder()
                .codeSilo(CodeSiloType.ERE)
                .nomContrat("RG152223361")
                .idContractante("S3878274")
                .build();

        ContratGeneral contratGeneral = buildContratGeneral("RG152223361");

        InfosContratDto infosContratDto = new InfosContratDto();
        infosContratDto.setContratGeneral(contratGeneral);

        List<String> idAssures = Arrays.asList("1398838", "1398839", "1398840", "1398841", "1398842");
        idAssures.forEach(idAssure -> infosContratDto.add(buildCompteGeneraleERE(idAssure)));

        //When
        List<ContratHeader> result = sut.convertToPacte(contratHeaderDtoList, infosContratDto);

        //Then
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
        Assert.assertNotNull(result.get(0));
        Assert.assertEquals(5, result.get(0).getCompartiments().size());
    }

    @Test
    public void test_convertToPacte_P4286686() {

        //Given
        List<ContratHeaderDto> contratHeaderDtoList = buildContratHeaderDtoList("P4286686");

        ContratGeneral contratGeneral = buildContratGeneral("RG152223361");

        InfosContratDto infosContratDto = new InfosContratDto();
        infosContratDto.setContratGeneral(contratGeneral);

        List<String> idAssures = Collections.singletonList("690805");
        idAssures.forEach(idAssure -> infosContratDto.add(buildCompteGeneraleERE(idAssure)));

        //When
        List<ContratHeader> result = sut.convertToPacte(contratHeaderDtoList, infosContratDto);

        //Then
        Assert.assertNotNull(result);
        Assert.assertEquals(1, result.size());
        Assert.assertNotNull(result.get(0));
        Assert.assertEquals(1, result.get(0).getCompartiments().size());
    }

    private List<ContratHeaderDto> buildContratHeaderDtoList(String numPersonne) {
        final String ressourcePath = "/xml/RechercherCtrPersSilo_3.ERE_" + numPersonne + ".xml";
        RechercherCtrPersSiloResponseType result = null;
        try {
            result = XmlMarshaller.convertSoapBodyToObject(ressourcePath, RechercherCtrPersSiloResponseType.class);
        } catch (RuntimeException e) {
            log.error("Erreur \u00E0 la r\u00E9cup\u00E9ration du RechercherCtrPersSilo pour numPersonne {} depuis {}", numPersonne, ressourcePath, e);
            throw e;
        }

        return mapperRechercherContratsResponse3.rechercherContratsTypeToDto(result).getContrats()
                .stream()
                .filter(ContratsSoapClientImpl::isRetraiteSupp)
                .peek(c -> c.setPersonId(numPersonne))
                .collect(Collectors.toList());
    }

    private ContratGeneral buildContratGeneral(String numContrat) {
        final String ressourcePath = "/xml/ConsulterContratGenerales_5.ERE_" + numContrat + ".xml";
        try {
            ConsulterContratGeneralesResponseType ccgr = XmlMarshaller.convertSoapBodyToObject(ressourcePath, ConsulterContratGeneralesResponseType.class);
            return consulterContratGeneralesResponseMapper.consulterContratGeneralesTypeToDto((ccgr));
        } catch (RuntimeException e) {
            log.error("Erreur \u00E0 la r\u00E9cup\u00E9ration du ContratGeneral pour numContrat {} depuis {}", numContrat, ressourcePath, e);
            throw e;
        }
    }

    private CompteGeneralesERE buildCompteGeneraleERE(String idAssure) {
        final String ressourcePath = "/xml/ConsulterCompteGeneralesERE_1." + idAssure + ".xml";
        try {
            final ConsulterCompteGeneralesEREResponseType responseType = XmlMarshaller.convertSoapBodyToObject(ressourcePath, ConsulterCompteGeneralesEREResponseType.class);
            return compteGeneralesEREResponseMapper.toCompteGeneralesERE(responseType);
        } catch (RuntimeException e) {
            log.error("Erreur \u00E0 la r\u00E9cup\u00E9ration du CompteGeneralesERE pour idAssure {} depuis {}", idAssure, ressourcePath, e);
            throw e;
        }
    }

    private ProduitJson produit(String libelle) {
        ProduitJson p = new ProduitJson();
        p.setLibelle(libelle);
        return p;
    }
}
