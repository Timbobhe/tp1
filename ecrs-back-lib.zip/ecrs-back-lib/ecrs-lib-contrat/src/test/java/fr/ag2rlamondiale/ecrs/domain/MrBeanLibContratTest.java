package fr.ag2rlamondiale.ecrs.domain;

import fr.ag2rlamondiale.ecrs.EcrsLibContratConfig;
import fr.ag2rlamondiale.trm.testing.MrBeanTester;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class MrBeanLibContratTest {

    @Test
    public void testApiBean() {
        MrBeanTester beanTester = newMrBeanTester();
        beanTester.addClasses("fr.ag2rlamondiale.ecrs.domain", EcrsLibContratConfig.class);
        beanTester.addClasses("fr.ag2rlamondiale.ecrs.dto", EcrsLibContratConfig.class);
        beanTester.test();
        assertNotNull(beanTester);
    }


    private MrBeanTester newMrBeanTester() {
        MrBeanTester beanTester = new MrBeanTester();
        beanTester.setClassPredicate(
                beanTester.getClassPredicate().and(clazz -> !clazz.getSimpleName().endsWith("MapperImpl")));

        return beanTester;
    }

}
