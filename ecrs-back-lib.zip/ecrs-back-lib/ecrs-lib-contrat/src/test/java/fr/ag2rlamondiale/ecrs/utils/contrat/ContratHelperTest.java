package fr.ag2rlamondiale.ecrs.utils.contrat;

import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.AffichageType;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ContratHelperTest {

    @Test
    public void isFilialeACA_1() {
        List<ContratHeader> contrats = Arrays.asList(contrat("ACA", true), contrat("ARI", true));
        assertTrue(ContratHelper.isFilialeACA(contrats));
    }

    @Test
    public void isFilialeACA_10() {
        List<ContratHeader> contrats = Arrays.asList(contrat("TOTO", true), contrat("ARI", false));
        assertFalse(ContratHelper.isFilialeACA(contrats));
    }

    @Test
    public void isFilialeACA_2() {
        List<ContratHeader> contrats = Arrays.asList(contrat("ACA", true), contrat("TOTO", true), contrat("FDP", true));
        assertFalse(ContratHelper.isFilialeACA(contrats));
    }

    @Test
    public void isFilialeACA_3() {
        List<ContratHeader> contrats = Collections.emptyList();
        assertFalse(ContratHelper.isFilialeACA(contrats));
    }

    @Test
    public void isFilialeACA_4() {
        List<ContratHeader> contrats = null;
        assertFalse(ContratHelper.isFilialeACA(contrats));
    }

    private ContratHeader contrat(String codeFiliale, boolean enable) {
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        contratHeader.setCodeFiliale(codeFiliale);
        contratHeader.setAffichageType(AffichageType.NORMAL);
        return contratHeader;
    }
}
