package fr.ag2rlamondiale.ecrs.business;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.ecrs.business.impl.CalculerEncoursContratFacadeImpl;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.trm.client.soap.ICalculerEncoursContratClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.structinv.ContributionType;
import fr.ag2rlamondiale.trm.dto.contrat.EncoursDto;
import fr.ag2rlamondiale.trm.utils.DateUtils;
import fr.ag2rlamondiale.trm.utils.JsonMarshaller;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static fr.ag2rlamondiale.trm.domain.constantes.Constantes.DEFAULT_DATE_FORMAT;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
@Configuration
public class CalculerEncoursContratFacadeImplTest {

    @Mock
    ICalculerEncoursContratClient calculerEncoursContratClient;

    @Mock
    IOperationFacade operationFacade;


    @InjectMocks
    CalculerEncoursContratFacadeImpl sut;

    @Test
    public void calculerEncoursContratERETest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);

        // When
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratHeader);
        // Then
        Assert.assertEquals("1", compteEncours.getIdStructInv());
    }

    @Test
    public void calculerEncoursContratMDPROTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.MDP);

        // When
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratHeader);
        // Then
        Assert.assertEquals("1", compteEncours.getIdStructInv());
    }

    @Test
    public void calculerEncoursContratEnErreur() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenThrow(new TechnicalException("fds"));


        //When
        ContratHeader contratHeader = new ContratHeader();
        contratHeader.setCodeSilo(CodeSiloType.ERE);
        CompteEncours compteEncours = sut.getCompteEncoursNonPacte(contratHeader);

        Assert.assertTrue(compteEncours.isEncoursEnErreur());
    }

    @Test
    public void getCompteEncoursContratTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When
        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(false)
                .build();

        EncoursDto encoursDto = sut.getEncoursDto(contratHeader);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(100.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursContrat2Test() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratHeader(contratHeader).build();
        Compartiment compartiment2 = Compartiment.builder().contratHeader(contratHeader).build();
        contratHeader.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(contratHeader);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(200.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursContratEnErreurTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setEncoursEnErreur(true);
                    return compteEncours;
                });

        //When

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratHeader(contratHeader).build();
        Compartiment compartiment2 = Compartiment.builder().contratHeader(contratHeader).build();
        contratHeader.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(contratHeader);

        Assert.assertTrue(encoursDto.isEncoursEnErreur());
    }

    @Test
    public void getCompteEncoursCompartimentTest() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(true)
                .build();
        Compartiment compartiment1 = Compartiment.builder().contratHeader(contratHeader).build();
        Compartiment compartiment2 = Compartiment.builder().contratHeader(contratHeader).build();
        contratHeader.setCompartiments(Arrays.asList(compartiment1, compartiment2));

        EncoursDto encoursDto = sut.getEncoursDto(compartiment1);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(100.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void getCompteEncoursCompartiment2Test() throws TechnicalException {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        //When

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .pacte(false)
                .build();
        Compartiment compartiment1 = Compartiment.builder()
                .contratHeader(contratHeader)
                .type(CompartimentType.C1)
                .build();
        contratHeader.setCompartiments(Collections.singletonList(compartiment1));

        EncoursDto encoursDto = sut.getEncoursDto(compartiment1);

        Assert.assertFalse(encoursDto.isEncoursEnErreur());
        Assert.assertEquals(Double.valueOf(0.0), encoursDto.getMontantEncours());
        Assert.assertEquals("10/10/2020", encoursDto.getDateEncours());
    }

    @Test
    public void should_calculate_encours_when_error_operation_a_recalculer() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if (argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(1, 2));
        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());

        Assert.assertEquals(JsonMarshaller.toJSON(createCompteEncours_en_Erreur()), JsonMarshaller.toJSON(actual));
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_exception_is_not_operation_a_recalculer() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any())).thenThrow(new TechnicalException());
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(1, 2));

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_no_operation_found() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if (argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(null);

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }

    @Test
    public void should_have_encours_en_erreur_when_recalculate_encours_and_no_operation_in_last_three_months() throws TechnicalException {
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any())).thenAnswer(invocation -> {
            CalculerEncoursContratDto argument = (CalculerEncoursContratDto) invocation.getArguments()[0];
            if (argument.getDateEncours() == null) {
                throw new TechnicalException(new Throwable("ERR_90020"));
            } else {
                return createCompteEncours();
            }
        });
        when(operationFacade.findOperationsToReCalculate(anyString(), any(CodeSiloType.class))).thenReturn(createOperationList(5, 6));

        CompteEncours actual = sut.calculerEncoursContrat(new CalculerEncoursContratDto());
        Assert.assertTrue(actual.isEncoursEnErreur());
    }

    @Test
    public void test_should_have_encours_at_date_for_contrat_non_pacte() throws Exception {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("id")
                .identifiantAssure("idAssure")
                .pacte(false)
                .build();

        // When
        final EvolutionCompteEncours encoursAtDateNonPacte = sut.getEncoursAtDateNonPacte(contratHeader, new Date());
        final EvolutionCompteEncours encoursAtDate = sut.getEncoursAtDate(contratHeader, new Date());

        // Then
        assertNotNull(encoursAtDateNonPacte);
        assertEquals(encoursAtDateNonPacte.getEncours().getMontant(), encoursAtDate.getEncours().getMontant());
    }

    @Test
    public void test_should_have_encours_at_date_for_contrat_ere_pacte() throws Exception {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    return compteEncours;
                });

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("id")
                .pacte(true)
                .build();

        contratHeader.addCompartiment(Compartiment.builder()
                                              .type(CompartimentType.C1)
                                              .identifiantAssure("idAssure1")
                                              .build());

        contratHeader.addCompartiment(Compartiment.builder()
                                              .type(CompartimentType.C3)
                                              .identifiantAssure("idAssure3")
                                              .build());


        // When
        final EvolutionCompteEncours encoursAtDateErePacte = sut.getEncoursAtDateErePacte(contratHeader, new Date());
        final EvolutionCompteEncours encoursAtDate = sut.getEncoursAtDate(contratHeader, new Date());

        // Then
        assertNotNull(encoursAtDateErePacte);
        assertEquals(new BigDecimal("200.0"), encoursAtDateErePacte.getEncours().getMontant());
        assertEquals(encoursAtDateErePacte.getEncours().getMontant(), encoursAtDate.getEncours().getMontant());
    }


    @Test
    public void test_should_have_encours_at_date_for_compartiment_ere_non_pacte() throws Exception {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    Map<ContributionType, String> montants = new HashMap<>();
                    montants.put(ContributionType.VERSEMENT_LIBRE, "100");
                    montants.put(ContributionType.PART_PATRONALE, "400");
                    montants.put(ContributionType.PART_SALARIALE, "100");

                    compteEncours.setOccurStructInvList(occurStructInvList(montants));
                    return compteEncours;
                });

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("id")
                .identifiantAssure("idAssure")
                .pacte(false)
                .build();

        final Compartiment c1 = contratHeader.addCompartiment(
                Compartiment.builder()
                        .type(CompartimentType.C1)
                        .identifiantAssure("idAssure")
                        .build());

        final Compartiment c3 = contratHeader.addCompartiment(
                Compartiment.builder()
                        .type(CompartimentType.C3)
                        .identifiantAssure("idAssure")
                        .build());


        // When
        final Encours encoursAtDateC1 = sut.getEncoursAtDate(c1, new Date());
        final Encours encoursAtDateC3 = sut.getEncoursAtDate(c3, new Date());

        // Then
        assertEquals(new BigDecimal(100), encoursAtDateC1.getMontant());
        assertEquals(new BigDecimal(500), encoursAtDateC3.getMontant());
    }


    @Test
    public void test_should_have_encours_contrat_pour_compartimentType() throws Exception {
        // Given
        when(calculerEncoursContratClient.calculerEncoursContratNoCache(any(CalculerEncoursContratDto.class)))
                .thenAnswer((Answer<CompteEncours>) object -> {
                    CompteEncours compteEncours = new CompteEncours();
                    compteEncours.setMontantEncours(new BigDecimal("100.0"));
                    compteEncours.setDateValeur(DateUtils.createDate(10, 10, 2020));
                    compteEncours.setIdStructInv("1");
                    Map<ContributionType, String> montants = new HashMap<>();
                    montants.put(ContributionType.VERSEMENT_LIBRE, "100");
                    montants.put(ContributionType.PART_PATRONALE, "400");
                    montants.put(ContributionType.PART_SALARIALE, "100");

                    compteEncours.setOccurStructInvList(occurStructInvList(montants));
                    return compteEncours;
                });

        ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .id("id")
                .identifiantAssure("idAssure")
                .pacte(false)
                .build();

        final Compartiment c1 = contratHeader.addCompartiment(
                Compartiment.builder()
                        .type(CompartimentType.C1)
                        .identifiantAssure("idAssure")
                        .build());

        final Compartiment c3 = contratHeader.addCompartiment(
                Compartiment.builder()
                        .type(CompartimentType.C3)
                        .identifiantAssure("idAssure")
                        .build());


        // When
        final Encours encoursAtDateC1 = sut.getEncoursDto(contratHeader, List.of(CompartimentType.C1));
        final Encours encoursAtDateC3 = sut.getEncoursDto(contratHeader, List.of(CompartimentType.C3));

        // Then
        assertEquals(new BigDecimal(100), encoursAtDateC1.getMontant());
        assertEquals(new BigDecimal(500), encoursAtDateC3.getMontant());
    }

    private List<OccurStructInvDto> occurStructInvList(Map<ContributionType, String> montantsParContribution) {
        List<OccurStructInvDto> res = new ArrayList<>();
        AtomicInteger code = new AtomicInteger(1);
        montantsParContribution.forEach((contributionType, s) -> {
            OccurStructInvDto occurStructInv = new OccurStructInvDto();
            occurStructInv.setIdOccurParentStructInv("" + code.getAndIncrement());
            occurStructInv.setMontantOccurSupportInv(new BigDecimal(s));

            ContributionInvDto contributionInv = new ContributionInvDto();
            contributionInv.setCodeContributionInv(contributionType.getCode());
            occurStructInv.setContributionInv(contributionInv);

            res.add(occurStructInv);
        });
        return res;
    }


    @Test
    public void test_should_return_jour_precedent() throws Exception {
        final Date date = DateUtils.createTimelessDate("01/03/2022");
        final Date jourPrecedent = sut.getJourPrecedent(date);
        assertEquals("28/02/2022", new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(jourPrecedent));
    }

    @Test
    public void test_should_return_date_3_mois_avant() throws Exception {
        Date today = new Date();
        final Date date = sut.dateThreeMonthsAgo();
        final long between = ChronoUnit.DAYS.between(date.toInstant(), today.toInstant());
        assertTrue(between >= 3*28);
    }


    private CompteEncours createCompteEncours() {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setMontantEncours(new BigDecimal("100"));
        return compteEncours;
    }

    private CompteEncours createCompteEncours_en_Erreur() {
        CompteEncours compteEncours = new CompteEncours();
        compteEncours.setMontantEncours(new BigDecimal("0"));
        compteEncours.setEncoursEnErreur(true);
        return compteEncours;
    }

    private List<Operation> createOperationList(int firstOperation, int secondOperation) {
        List<Operation> operations = new ArrayList<>();
        Operation operation1 = new Operation();
        operation1.setId("operation1");
        operation1.setDate(Date.from(new Date().toInstant()
                                               .atZone(ZoneId.systemDefault())
                                               .minusMonths(firstOperation)
                                               .toInstant()));
        operations.add(operation1);
        Operation operation2 = new Operation();
        operation2.setId("operation2");
        operation2.setDate(Date.from(new Date().toInstant()
                                               .atZone(ZoneId.systemDefault())
                                               .minusMonths(secondOperation)
                                               .toInstant()));
        operations.add(operation2);
        return operations;
    }
}
