package fr.ag2rlamondiale.ecrs.business.impl;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnit;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;
import org.mockito.stubbing.Answer;
import org.springframework.context.annotation.Configuration;

import com.ag2r.common.exceptions.TechnicalException;

import fr.ag2rlamondiale.ecrs.business.domain.operation.OperationCompartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.Compartiment;
import fr.ag2rlamondiale.ecrs.domain.contrat.ContratHeader;
import fr.ag2rlamondiale.ecrs.dto.DetailsOperationDto;
import fr.ag2rlamondiale.ecrs.dto.OperationDetailInfoDto;
import fr.ag2rlamondiale.trm.client.soap.IOperationsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.CompartimentType;
import fr.ag2rlamondiale.trm.domain.encours.*;
import fr.ag2rlamondiale.trm.domain.encours.OccurStructInvDto;
import fr.ag2rlamondiale.trm.domain.encours.ProfilInvDto;
import fr.ag2rlamondiale.trm.domain.encours.SupportInvDto;
import fr.ag2rlamondiale.trm.domain.operation.CodeTypeOperationEREType;
import fr.ag2rlamondiale.trm.domain.operation.Operation;
import fr.ag2rlamondiale.trm.domain.operation.OperationDetailDto;
import fr.ag2rlamondiale.trm.domain.operation.RechercherOperationsDto;
import fr.ag2rlamondiale.trm.domain.structinv.IdDansSiloDto;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;

@RunWith(MockitoJUnitRunner.class)
@Configuration
public class OperationFacadeImplTest {
    private static final String ID_OPERATION = "81169648";
    private static final String ID_ASSURE = "84940";

    @Mock
    IOperationsClient operationsClient;

    @InjectMocks
    OperationFacadeImpl operationFacade;


    @Rule
    public MockitoRule rule = MockitoJUnit.rule();

//    @Before
//    public void setUp() throws Exception {
//        IWithCodeSilo withCodeSilo = () -> CodeSiloType.MDP;
//        System.out.println(withCodeSilo.getCodeSilo());
//    }


    @Test
    public void should_find_operations_to_recalculate_for_mdpro() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId(ID_OPERATION);
                    return Collections.singletonList(operation);
                });
        List<Operation> actual = operationFacade.findOperationsToReCalculate(ID_ASSURE, CodeSiloType.MDP);
        Assert.assertEquals(ID_OPERATION, actual.get(0).getId());
    }


    @Test(expected = TechnicalRuntimeException.class)
    public void should_throw_exception_when_trying_to_find_operations_to_recalculate() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class))).thenThrow(new TechnicalException());
        operationFacade.findOperationsToReCalculate(ID_ASSURE, CodeSiloType.ERE);
    }

    @Test
    public void getOperationsForVersementSyntheseTest() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId(ID_OPERATION);
                    return Collections.singletonList(operation);
                });


        final ContratHeader contratHeader = ContratHeader.builder()
                .id("IDCONTRAT")
                .codeSilo(CodeSiloType.ERE)
                .build();

        Compartiment compartimentC1 = Compartiment.builder()
                .identifiantAssure("281134")
                .type(CompartimentType.C1)
                .build();

        contratHeader.addCompartiment(compartimentC1);

        List<Operation> operations = operationFacade.getOperationsForVersementSynthese(compartimentC1, new Date(), new Date());
        Assert.assertEquals(ID_OPERATION, operations.get(0).getId());
    }

    @Test
    public void getOperationsForArbitrageEREOrFuture() throws TechnicalException {
        //When
        List<Operation> operations = createOperations();
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class))).thenReturn(operations);
        //Then
        List<Operation> operationsRst = operationFacade.getOperationsForArbitrageERE("AS45998");
        Assert.assertNotNull(operationsRst.get(0));
    }

    private List<Operation> createOperations() {
        Operation op1 = new Operation();
        op1.setCodeTypeOperation(CodeTypeOperationEREType.GARB_A.name());
        op1.setCodeSituationOperation("CODE_OPE");
        List<Operation> list = Arrays.asList(op1);
        return list;
    }

    @Test
    public void getOperationsForDetailsContratsPacteTest() throws TechnicalException {
        when(operationsClient.rechercherOperations(Matchers.any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId("144910652");
                    return Collections.singletonList(operation);
                });
        ContratHeader contratHeader = ContratHeader.builder()
                .id("RA01")
                .idContractante("S4164948")
                .pacte(true)
                .identifiantAssure("281134")
                .codeSilo(CodeSiloType.ERE)
                .build();

        Compartiment compartimentC1 = Compartiment.builder()
                .identifiantAssure("281134")
                .type(CompartimentType.C1).contratHeader(contratHeader)
                .build();


        List<Operation> operations = operationFacade.getOperationsForDetailsContratsPacte(compartimentC1, new Date(), new Date());
        Assert.assertNotNull(operations);
    }

    @Test
    public void getOperationsForDetailsContratsNonPacteTest() throws TechnicalException {
        when(operationsClient.rechercherOperations(Matchers.any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId("144910652");
                    return Collections.singletonList(operation);
                });


        final ContratHeader contratHeader = ContratHeader.builder()
                .codeSilo(CodeSiloType.ERE)
                .build();


        List<Operation> operations = operationFacade.getOperationsForDetailsContratsNonPacte(contratHeader, new Date(), new Date());
        Assert.assertNotNull(operations);
    }

    @Test
    public void getOperationsForDetailsContratTestMDPRO() throws TechnicalException {

        when(operationsClient.consulterStructInvestOperations(any(IdDansSiloDto.class))).thenReturn(createOperationDetailDto());
        List<OperationDetailInfoDto> operations = operationFacade.getOperationsDetailsForDetailsContrat(ID_OPERATION, "MDP");

        Assert.assertNotNull(operations);
    }

    @Test
    public void getOperationsForDetailsContratTestERE() throws TechnicalException {

        when(operationsClient.consulterStructInvestOperations(any(IdDansSiloDto.class))).thenReturn(createOperationDetailDto());
        List<OperationDetailInfoDto> operations = operationFacade.getOperationsDetailsForDetailsContrat(ID_OPERATION, "ERE");

        Assert.assertNotNull(operations);
    }

    @Test
    public void getLibelleDetailOperation() throws TechnicalException {
        Assert.assertNotNull(LibelleSupportUtils.getLibelleDetailOperation(createOperationDetailDto().getSupportInvestissement().get(0)
        ,createOperationDetailDto().getSupportInvestissement(), true));
    }

    private OperationDetailInfoDto getDetailsOperationDto() {
        OperationDetailInfoDto operationDetailInfoDto = new OperationDetailInfoDto();
        operationDetailInfoDto.setOperationId("A_144910652");
        operationDetailInfoDto.setMontant(new BigDecimal("34.6"));
        operationDetailInfoDto.setLabel("Réalignement");
        operationDetailInfoDto.setNbreParts(BigDecimal.valueOf(2));
        operationDetailInfoDto.setValeurLiquidative(BigDecimal.valueOf(12.6));
        operationDetailInfoDto.setIdentifiantStrucInv("Struct_144910652");

        return operationDetailInfoDto;
    }

    @Test
    public void getOperationsForArbitrageFutureERETest() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId(ID_OPERATION);
                    return Collections.singletonList(operation);
                });

        Assert.assertNotNull(operationFacade.getOperationsForArbitrageFutureERE("IDASSURE"));
    }

    @Test(expected = TechnicalRuntimeException.class)
    public void getOperationsForArbitrageFutureERETestThrowException() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class))).thenThrow(new TechnicalException());
        operationFacade.getOperationsForArbitrageFutureERE("IDASSURE");
    }

    @Test(expected = TechnicalRuntimeException.class)
    public void getOperationsForArbitrageERETestThrowException() throws TechnicalException {
        when(operationsClient.rechercherOperations(any(RechercherOperationsDto.class))).thenThrow(new TechnicalException());
        operationFacade.getOperationsForArbitrageERE("IDASSURE");
    }

    @Test()
    public void getOperationsEnCoursERETest() {
        Assert.assertNotNull(operationFacade.getOperationsEnCoursERE("IDASSURE"));
    }

    @Test()
    public void getOperationsForDetailsContratsPacteTestWithContratHeader() throws TechnicalException {
        when(operationsClient.rechercherOperations(Matchers.any(RechercherOperationsDto.class)))
                .thenAnswer((Answer<List<Operation>>) invocation -> {
                    Operation operation = new Operation();
                    operation.setId("144910652");
                    return Collections.singletonList(operation);
                });
        ContratHeader contratHeader = ContratHeader.builder()
                .id("RA01")
                .idContractante("S4164948")
                .pacte(true)
                .identifiantAssure("281134")
                .codeSilo(CodeSiloType.ERE)
                .build();

        Compartiment compartimentC1 = Compartiment.builder()
                .identifiantAssure("281134")
                .type(CompartimentType.C1)
                .contratHeader(contratHeader)
                .build();
        Compartiment compartimentC2 = Compartiment.builder()
                .identifiantAssure("281134")
                .type(CompartimentType.C2)
                .contratHeader(contratHeader)
                .build();

        contratHeader.setCompartiments(Arrays.asList(compartimentC2,compartimentC1));

        List<OperationCompartiment> operations = operationFacade.getOperationsForDetailsContratsPacte(contratHeader, new Date(), new Date());
        Assert.assertNotNull(operations);
    }


/*
    @Test
    public void buildSupportInvDtoTest() {
        OperationDetailDto opDetailDto = new OperationDetailDto();
        opDetailDto.setMontantNet(new BigDecimal("234.78", MathContext.DECIMAL64));
        opDetailDto.setLibTypeOperation("42_TYPE_OPE");
        opDetailDto.setSupportInvestissement(new ArrayList<>());
        SupportInvDto SupportInvDto = new SupportInvDto();
        SupportInvDto.setTxRepartitionSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        OccurStructInvDto occurStructInvDto = new OccurStructInvDto();
        occurStructInvDto.setMontantOccurSupportInv(new BigDecimal("234.78", MathContext.DECIMAL64));
        occurStructInvDto.setSupportInv(SupportInvDto);
        List<OperationDetailInfoDto> operationDetailInfoDtoList = new ArrayList<>();
        operationFacade.buildSupportInvDto(createOperationDetailDto().getSupportInvestissement().get(1),createOperationDetailDto(),operationDetailInfoDtoList);
        assertTrue(operationDetailInfoDtoList.size()>0);
    }*/

    private OperationDetailDto createOperationDetailDto(){
        ProfilInvDto profilOcc1 = new ProfilInvDto();
        profilOcc1.setIdProfilInv("IDSTRUCTINV1");
        profilOcc1.setTxRepartitionProfilInv(new BigDecimal(10));
        ProfilInvDto profilOcc2 = new ProfilInvDto();
        profilOcc2.setTxRepartitionProfilInv(new BigDecimal(10));
        profilOcc2.setIdProfilInv("IDSTRUCTINV2");
        ProfilInvDto profilOcc3 = new ProfilInvDto();
        profilOcc3.setIdProfilInv("IDSTRUCTINV3");
        profilOcc3.setTxRepartitionProfilInv(new BigDecimal(10));
        HorizonInvDto horizonOcc1 = new HorizonInvDto();
        horizonOcc1.setIdHorizonInv("IDSTRUCTINV1");
        horizonOcc1.setNomHorizonInv("Gestion Pilotée");
        SupportInvDto suppOcc2 = new SupportInvDto();
        suppOcc2.setIdSupportInv("IDSUPPINV2");
        suppOcc2.setTxRepartitionSupportInv(new BigDecimal(10));
        GrilleInvDto grilleOcc1 = new GrilleInvDto();
        grilleOcc1.setIdGrilleInv("IDSTRUCTINV1");
        grilleOcc1.setNomGrilleInv("Grille pilotée");
        grilleOcc1.setTxRepartitionGrilleInv(new BigDecimal(10));


        OperationDetailDto operationDetailDto = new OperationDetailDto();
        operationDetailDto.setOperationId("OPERATIONID");
        operationDetailDto.setMontantNet(BigDecimal.valueOf(87));
        operationDetailDto.setCodeTypeOperation("AF");
        operationDetailDto.setLibTypeOperation("Actif");
        operationDetailDto.setIdStructureInvestissement("PARENT");


        OccurStructInvDto occ1 = new OccurStructInvDto();
        occ1.setIdOccurStructInv("IDSTRUCTINV1");
        occ1.setIdOccurParentStructInv("PARENT");
        occ1.setMontantOccurSupportInv(new BigDecimal(10));
        occ1.setProfilInv(profilOcc1);
        occ1.setHorizonInv(horizonOcc1);
        occ1.setGrilleInv(grilleOcc1);


        OccurStructInvDto occ2 = new OccurStructInvDto();
        occ2.setIdOccurStructInv("IDOCC2");
        occ2.setIdOccurParentStructInv("IDOCC1");
        occ2.setMontantOccurSupportInv(new BigDecimal(10));
        occ2.setProfilInv(profilOcc2);
        occ2.setSupportInv(suppOcc2);

        OccurStructInvDto occ3 = new OccurStructInvDto();
        occ3.setIdOccurStructInv("PARENT");
        occ3.setIdOccurParentStructInv("IDOCC2");
        occ3.setMontantOccurSupportInv(new BigDecimal(10));
        occ3.setProfilInv(profilOcc3);
        occ3.setGrilleInv(grilleOcc1);

        operationDetailDto.setSupportInvestissement(Arrays.asList(occ1,occ2,occ3));
        return operationDetailDto;
    }
}
