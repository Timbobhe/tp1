
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ActivitePartnrtType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ActivitePartnrtType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeActiviteGestDeleguee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libActiviteGestDeleguee" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActivitePartnrtType", propOrder = {
    "codeActiviteGestDeleguee",
    "libActiviteGestDeleguee"
})
public class ActivitePartnrtType {

    protected String codeActiviteGestDeleguee;
    protected String libActiviteGestDeleguee;

    /**
     * Obtient la valeur de la propriété codeActiviteGestDeleguee.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeActiviteGestDeleguee() {
        return codeActiviteGestDeleguee;
    }

    /**
     * Définit la valeur de la propriété codeActiviteGestDeleguee.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeActiviteGestDeleguee(String value) {
        this.codeActiviteGestDeleguee = value;
    }

    /**
     * Obtient la valeur de la propriété libActiviteGestDeleguee.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibActiviteGestDeleguee() {
        return libActiviteGestDeleguee;
    }

    /**
     * Définit la valeur de la propriété libActiviteGestDeleguee.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibActiviteGestDeleguee(String value) {
        this.libActiviteGestDeleguee = value;
    }

}
