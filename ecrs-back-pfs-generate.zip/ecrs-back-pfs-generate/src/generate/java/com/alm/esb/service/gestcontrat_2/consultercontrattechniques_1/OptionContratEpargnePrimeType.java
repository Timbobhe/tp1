
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OptionContratEpargnePrimeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OptionContratEpargnePrimeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="txFraisSurVersementFacultatif" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="txFraisSurVersementPeriodique" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="txFraisSurVersementExceptionnel" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="montantFraisSurVersementFacultatif" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="montantFraisSurVersementPeriodique" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="montantFraisSurVersementExceptionnel" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptionContratEpargnePrimeType", propOrder = {
    "txFraisSurVersementFacultatif",
    "txFraisSurVersementPeriodique",
    "txFraisSurVersementExceptionnel",
    "montantFraisSurVersementFacultatif",
    "montantFraisSurVersementPeriodique",
    "montantFraisSurVersementExceptionnel"
})
public class OptionContratEpargnePrimeType {

    protected BigDecimal txFraisSurVersementFacultatif;
    protected BigDecimal txFraisSurVersementPeriodique;
    protected BigDecimal txFraisSurVersementExceptionnel;
    protected BigDecimal montantFraisSurVersementFacultatif;
    protected BigDecimal montantFraisSurVersementPeriodique;
    protected BigDecimal montantFraisSurVersementExceptionnel;

    /**
     * Obtient la valeur de la propriété txFraisSurVersementFacultatif.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurVersementFacultatif() {
        return txFraisSurVersementFacultatif;
    }

    /**
     * Définit la valeur de la propriété txFraisSurVersementFacultatif.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurVersementFacultatif(BigDecimal value) {
        this.txFraisSurVersementFacultatif = value;
    }

    /**
     * Obtient la valeur de la propriété txFraisSurVersementPeriodique.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurVersementPeriodique() {
        return txFraisSurVersementPeriodique;
    }

    /**
     * Définit la valeur de la propriété txFraisSurVersementPeriodique.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurVersementPeriodique(BigDecimal value) {
        this.txFraisSurVersementPeriodique = value;
    }

    /**
     * Obtient la valeur de la propriété txFraisSurVersementExceptionnel.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurVersementExceptionnel() {
        return txFraisSurVersementExceptionnel;
    }

    /**
     * Définit la valeur de la propriété txFraisSurVersementExceptionnel.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurVersementExceptionnel(BigDecimal value) {
        this.txFraisSurVersementExceptionnel = value;
    }

    /**
     * Obtient la valeur de la propriété montantFraisSurVersementFacultatif.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantFraisSurVersementFacultatif() {
        return montantFraisSurVersementFacultatif;
    }

    /**
     * Définit la valeur de la propriété montantFraisSurVersementFacultatif.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantFraisSurVersementFacultatif(BigDecimal value) {
        this.montantFraisSurVersementFacultatif = value;
    }

    /**
     * Obtient la valeur de la propriété montantFraisSurVersementPeriodique.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantFraisSurVersementPeriodique() {
        return montantFraisSurVersementPeriodique;
    }

    /**
     * Définit la valeur de la propriété montantFraisSurVersementPeriodique.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantFraisSurVersementPeriodique(BigDecimal value) {
        this.montantFraisSurVersementPeriodique = value;
    }

    /**
     * Obtient la valeur de la propriété montantFraisSurVersementExceptionnel.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantFraisSurVersementExceptionnel() {
        return montantFraisSurVersementExceptionnel;
    }

    /**
     * Définit la valeur de la propriété montantFraisSurVersementExceptionnel.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantFraisSurVersementExceptionnel(BigDecimal value) {
        this.montantFraisSurVersementExceptionnel = value;
    }

}
