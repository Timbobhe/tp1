
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratGeneralesFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratGeneralesFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}Contrat" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratGeneralesFuncType", propOrder = {
    "contrat"
})
public class ConsulterContratGeneralesFuncType {

    @XmlElement(name = "Contrat")
    protected ContratType contrat;

    /**
     * Obtient la valeur de la propriété contrat.
     * 
     * @return
     *     possible object is
     *     {@link ContratType }
     *     
     */
    public ContratType getContrat() {
        return contrat;
    }

    /**
     * Définit la valeur de la propriété contrat.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratType }
     *     
     */
    public void setContrat(ContratType value) {
        this.contrat = value;
    }

}
