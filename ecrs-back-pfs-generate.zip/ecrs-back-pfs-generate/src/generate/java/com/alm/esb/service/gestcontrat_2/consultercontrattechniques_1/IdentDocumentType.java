
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentDocumentType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentDocumentType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeTypeDocSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeDocSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indAnnuel" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indObligatoire" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indRecue" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="millesime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentDocumentType", propOrder = {
    "codeTypeDocSilo",
    "libTypeDocSilo",
    "indAnnuel",
    "indObligatoire",
    "indRecue",
    "millesime"
})
public class IdentDocumentType {

    protected String codeTypeDocSilo;
    protected String libTypeDocSilo;
    protected Boolean indAnnuel;
    protected Boolean indObligatoire;
    protected Boolean indRecue;
    protected String millesime;

    /**
     * Obtient la valeur de la propriété codeTypeDocSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeDocSilo() {
        return codeTypeDocSilo;
    }

    /**
     * Définit la valeur de la propriété codeTypeDocSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeDocSilo(String value) {
        this.codeTypeDocSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeDocSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeDocSilo() {
        return libTypeDocSilo;
    }

    /**
     * Définit la valeur de la propriété libTypeDocSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeDocSilo(String value) {
        this.libTypeDocSilo = value;
    }

    /**
     * Obtient la valeur de la propriété indAnnuel.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndAnnuel() {
        return indAnnuel;
    }

    /**
     * Définit la valeur de la propriété indAnnuel.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndAnnuel(Boolean value) {
        this.indAnnuel = value;
    }

    /**
     * Obtient la valeur de la propriété indObligatoire.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndObligatoire() {
        return indObligatoire;
    }

    /**
     * Définit la valeur de la propriété indObligatoire.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndObligatoire(Boolean value) {
        this.indObligatoire = value;
    }

    /**
     * Obtient la valeur de la propriété indRecue.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndRecue() {
        return indRecue;
    }

    /**
     * Définit la valeur de la propriété indRecue.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndRecue(Boolean value) {
        this.indRecue = value;
    }

    /**
     * Obtient la valeur de la propriété millesime.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMillesime() {
        return millesime;
    }

    /**
     * Définit la valeur de la propriété millesime.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMillesime(String value) {
        this.millesime = value;
    }

}
