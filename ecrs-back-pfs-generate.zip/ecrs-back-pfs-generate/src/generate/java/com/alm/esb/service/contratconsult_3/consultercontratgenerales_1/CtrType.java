
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentCtrType"/>
 *         &lt;element name="InfoCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}InfoCtrType" minOccurs="0"/>
 *         &lt;element name="Souscripteurs" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SouscripteursType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="OfrCialSousc" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}OfrCialSousc2Type" minOccurs="0"/>
 *         &lt;element name="Prime" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}PrimeType" minOccurs="0"/>
 *         &lt;element name="EchrPaimtPrime" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}EchrPaimtPrimeType" minOccurs="0"/>
 *         &lt;element name="ActrCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}ActrCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="OptCtrEparg" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}OptCtrEpargType" minOccurs="0"/>
 *         &lt;element name="OptRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}OptRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CtrColl" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrCollType" minOccurs="0"/>
 *         &lt;element name="CtrIndv" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrIndvType" minOccurs="0"/>
 *         &lt;element name="TrsfCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}TrsfCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="StructOrganisation" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}StructOrgaType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ActivPartnrt" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}ActivPartnrtType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RolePers" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}RolePersType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="indBlocFicheParam" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="PartclRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}PartclRenteType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtrType", propOrder = {
    "identSiloCtr",
    "infoCtr",
    "souscripteurs",
    "ofrCialSousc",
    "prime",
    "echrPaimtPrime",
    "actrCtr",
    "optCtrEparg",
    "optRente",
    "ctrColl",
    "ctrIndv",
    "trsfCtr",
    "structOrganisation",
    "activPartnrt",
    "rolePers",
    "indBlocFicheParam",
    "partclRente"
})
public class CtrType {

    @XmlElement(name = "IdentSiloCtr", required = true)
    protected IdentCtrType identSiloCtr;
    @XmlElement(name = "InfoCtr")
    protected InfoCtrType infoCtr;
    @XmlElement(name = "Souscripteurs")
    protected List<SouscripteursType> souscripteurs;
    @XmlElement(name = "OfrCialSousc")
    protected OfrCialSousc2Type ofrCialSousc;
    @XmlElement(name = "Prime")
    protected PrimeType prime;
    @XmlElement(name = "EchrPaimtPrime")
    protected EchrPaimtPrimeType echrPaimtPrime;
    @XmlElement(name = "ActrCtr")
    protected List<ActrCtrType> actrCtr;
    @XmlElement(name = "OptCtrEparg")
    protected OptCtrEpargType optCtrEparg;
    @XmlElement(name = "OptRente")
    protected List<OptRenteType> optRente;
    @XmlElement(name = "CtrColl")
    protected CtrCollType ctrColl;
    @XmlElement(name = "CtrIndv")
    protected CtrIndvType ctrIndv;
    @XmlElement(name = "TrsfCtr")
    protected List<TrsfCtrType> trsfCtr;
    @XmlElement(name = "StructOrganisation")
    protected List<StructOrgaType> structOrganisation;
    @XmlElement(name = "ActivPartnrt")
    protected List<ActivPartnrtType> activPartnrt;
    @XmlElement(name = "RolePers")
    protected List<RolePersType> rolePers;
    protected Boolean indBlocFicheParam;
    @XmlElement(name = "PartclRente")
    protected PartclRenteType partclRente;

    /**
     * Obtient la valeur de la propriété identSiloCtr.
     * 
     * @return
     *     possible object is
     *     {@link IdentCtrType }
     *     
     */
    public IdentCtrType getIdentSiloCtr() {
        return identSiloCtr;
    }

    /**
     * Définit la valeur de la propriété identSiloCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentCtrType }
     *     
     */
    public void setIdentSiloCtr(IdentCtrType value) {
        this.identSiloCtr = value;
    }

    /**
     * Obtient la valeur de la propriété infoCtr.
     * 
     * @return
     *     possible object is
     *     {@link InfoCtrType }
     *     
     */
    public InfoCtrType getInfoCtr() {
        return infoCtr;
    }

    /**
     * Définit la valeur de la propriété infoCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoCtrType }
     *     
     */
    public void setInfoCtr(InfoCtrType value) {
        this.infoCtr = value;
    }

    /**
     * Gets the value of the souscripteurs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the souscripteurs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSouscripteurs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SouscripteursType }
     * 
     * 
     */
    public List<SouscripteursType> getSouscripteurs() {
        if (souscripteurs == null) {
            souscripteurs = new ArrayList<SouscripteursType>();
        }
        return this.souscripteurs;
    }

    /**
     * Obtient la valeur de la propriété ofrCialSousc.
     * 
     * @return
     *     possible object is
     *     {@link OfrCialSousc2Type }
     *     
     */
    public OfrCialSousc2Type getOfrCialSousc() {
        return ofrCialSousc;
    }

    /**
     * Définit la valeur de la propriété ofrCialSousc.
     * 
     * @param value
     *     allowed object is
     *     {@link OfrCialSousc2Type }
     *     
     */
    public void setOfrCialSousc(OfrCialSousc2Type value) {
        this.ofrCialSousc = value;
    }

    /**
     * Obtient la valeur de la propriété prime.
     * 
     * @return
     *     possible object is
     *     {@link PrimeType }
     *     
     */
    public PrimeType getPrime() {
        return prime;
    }

    /**
     * Définit la valeur de la propriété prime.
     * 
     * @param value
     *     allowed object is
     *     {@link PrimeType }
     *     
     */
    public void setPrime(PrimeType value) {
        this.prime = value;
    }

    /**
     * Obtient la valeur de la propriété echrPaimtPrime.
     * 
     * @return
     *     possible object is
     *     {@link EchrPaimtPrimeType }
     *     
     */
    public EchrPaimtPrimeType getEchrPaimtPrime() {
        return echrPaimtPrime;
    }

    /**
     * Définit la valeur de la propriété echrPaimtPrime.
     * 
     * @param value
     *     allowed object is
     *     {@link EchrPaimtPrimeType }
     *     
     */
    public void setEchrPaimtPrime(EchrPaimtPrimeType value) {
        this.echrPaimtPrime = value;
    }

    /**
     * Gets the value of the actrCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the actrCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActrCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActrCtrType }
     * 
     * 
     */
    public List<ActrCtrType> getActrCtr() {
        if (actrCtr == null) {
            actrCtr = new ArrayList<ActrCtrType>();
        }
        return this.actrCtr;
    }

    /**
     * Obtient la valeur de la propriété optCtrEparg.
     * 
     * @return
     *     possible object is
     *     {@link OptCtrEpargType }
     *     
     */
    public OptCtrEpargType getOptCtrEparg() {
        return optCtrEparg;
    }

    /**
     * Définit la valeur de la propriété optCtrEparg.
     * 
     * @param value
     *     allowed object is
     *     {@link OptCtrEpargType }
     *     
     */
    public void setOptCtrEparg(OptCtrEpargType value) {
        this.optCtrEparg = value;
    }

    /**
     * Gets the value of the optRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the optRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOptRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OptRenteType }
     * 
     * 
     */
    public List<OptRenteType> getOptRente() {
        if (optRente == null) {
            optRente = new ArrayList<OptRenteType>();
        }
        return this.optRente;
    }

    /**
     * Obtient la valeur de la propriété ctrColl.
     * 
     * @return
     *     possible object is
     *     {@link CtrCollType }
     *     
     */
    public CtrCollType getCtrColl() {
        return ctrColl;
    }

    /**
     * Définit la valeur de la propriété ctrColl.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrCollType }
     *     
     */
    public void setCtrColl(CtrCollType value) {
        this.ctrColl = value;
    }

    /**
     * Obtient la valeur de la propriété ctrIndv.
     * 
     * @return
     *     possible object is
     *     {@link CtrIndvType }
     *     
     */
    public CtrIndvType getCtrIndv() {
        return ctrIndv;
    }

    /**
     * Définit la valeur de la propriété ctrIndv.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrIndvType }
     *     
     */
    public void setCtrIndv(CtrIndvType value) {
        this.ctrIndv = value;
    }

    /**
     * Gets the value of the trsfCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trsfCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrsfCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TrsfCtrType }
     * 
     * 
     */
    public List<TrsfCtrType> getTrsfCtr() {
        if (trsfCtr == null) {
            trsfCtr = new ArrayList<TrsfCtrType>();
        }
        return this.trsfCtr;
    }

    /**
     * Gets the value of the structOrganisation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the structOrganisation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStructOrganisation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StructOrgaType }
     * 
     * 
     */
    public List<StructOrgaType> getStructOrganisation() {
        if (structOrganisation == null) {
            structOrganisation = new ArrayList<StructOrgaType>();
        }
        return this.structOrganisation;
    }

    /**
     * Gets the value of the activPartnrt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the activPartnrt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActivPartnrt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActivPartnrtType }
     * 
     * 
     */
    public List<ActivPartnrtType> getActivPartnrt() {
        if (activPartnrt == null) {
            activPartnrt = new ArrayList<ActivPartnrtType>();
        }
        return this.activPartnrt;
    }

    /**
     * Gets the value of the rolePers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rolePers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRolePers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RolePersType }
     * 
     * 
     */
    public List<RolePersType> getRolePers() {
        if (rolePers == null) {
            rolePers = new ArrayList<RolePersType>();
        }
        return this.rolePers;
    }

    /**
     * Obtient la valeur de la propriété indBlocFicheParam.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndBlocFicheParam() {
        return indBlocFicheParam;
    }

    /**
     * Définit la valeur de la propriété indBlocFicheParam.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndBlocFicheParam(Boolean value) {
        this.indBlocFicheParam = value;
    }

    /**
     * Obtient la valeur de la propriété partclRente.
     * 
     * @return
     *     possible object is
     *     {@link PartclRenteType }
     *     
     */
    public PartclRenteType getPartclRente() {
        return partclRente;
    }

    /**
     * Définit la valeur de la propriété partclRente.
     * 
     * @param value
     *     allowed object is
     *     {@link PartclRenteType }
     *     
     */
    public void setPartclRente(PartclRenteType value) {
        this.partclRente = value;
    }

}
