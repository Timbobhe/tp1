
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OfrCialSouscType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OfrCialSouscType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentOfrSousctn" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentOfrSousctnType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OfrCialSouscType", propOrder = {
    "identOfrSousctn"
})
public class OfrCialSouscType {

    @XmlElement(name = "IdentOfrSousctn")
    protected IdentOfrSousctnType identOfrSousctn;

    /**
     * Obtient la valeur de la propriété identOfrSousctn.
     * 
     * @return
     *     possible object is
     *     {@link IdentOfrSousctnType }
     *     
     */
    public IdentOfrSousctnType getIdentOfrSousctn() {
        return identOfrSousctn;
    }

    /**
     * Définit la valeur de la propriété identOfrSousctn.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentOfrSousctnType }
     *     
     */
    public void setIdentOfrSousctn(IdentOfrSousctnType value) {
        this.identOfrSousctn = value;
    }

}
