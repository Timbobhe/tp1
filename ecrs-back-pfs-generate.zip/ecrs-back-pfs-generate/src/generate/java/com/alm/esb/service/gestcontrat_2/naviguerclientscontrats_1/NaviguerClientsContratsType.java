
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour NaviguerClientsContratsType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="NaviguerClientsContratsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1}NavCliCon"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NaviguerClientsContratsType", propOrder = {
    "navCliCon"
})
public class NaviguerClientsContratsType {

    @XmlElement(name = "NavCliCon", required = true)
    protected NavCliConType navCliCon;

    /**
     * Obtient la valeur de la propriété navCliCon.
     * 
     * @return
     *     possible object is
     *     {@link NavCliConType }
     *     
     */
    public NavCliConType getNavCliCon() {
        return navCliCon;
    }

    /**
     * Définit la valeur de la propriété navCliCon.
     * 
     * @param value
     *     allowed object is
     *     {@link NavCliConType }
     *     
     */
    public void setNavCliCon(NavCliConType value) {
        this.navCliCon = value;
    }

}
