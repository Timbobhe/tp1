
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OccurStructInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OccurStructInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idOccurStructInv" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="idOccurParentStructInv" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeModeGestionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeGestionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeGestionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeGestionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatureSupportInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatureSupportInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatureSupportInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatureSupportInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantOccurSupportInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="deviseOccurSupportInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ContributionInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}ContributionInvType" minOccurs="0"/>
 *         &lt;element name="GrilleInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}GrilleInvType" minOccurs="0"/>
 *         &lt;element name="HorizonInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}HorizonInvType" minOccurs="0"/>
 *         &lt;element name="ProfilInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}ProfilInvType" minOccurs="0"/>
 *         &lt;element name="SupportInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}SupportInvType" minOccurs="0"/>
 *         &lt;element name="TarifInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}TarifInvType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OccurStructInvType", propOrder = {
    "idOccurStructInv",
    "idOccurParentStructInv",
    "codeModeGestionInv",
    "libModeGestionInv",
    "codeModeGestionInvSilo",
    "libModeGestionInvSilo",
    "codeNatureSupportInv",
    "libNatureSupportInv",
    "codeNatureSupportInvSilo",
    "libNatureSupportInvSilo",
    "montantOccurSupportInv",
    "deviseOccurSupportInv",
    "contributionInv",
    "grilleInv",
    "horizonInv",
    "profilInv",
    "supportInv",
    "tarifInv"
})
public class OccurStructInvType {

    @XmlElement(required = true)
    protected String idOccurStructInv;
    @XmlElement(required = true)
    protected String idOccurParentStructInv;
    protected String codeModeGestionInv;
    protected String libModeGestionInv;
    protected String codeModeGestionInvSilo;
    protected String libModeGestionInvSilo;
    protected String codeNatureSupportInv;
    protected String libNatureSupportInv;
    protected String codeNatureSupportInvSilo;
    protected String libNatureSupportInvSilo;
    protected BigDecimal montantOccurSupportInv;
    protected String deviseOccurSupportInv;
    @XmlElement(name = "ContributionInv")
    protected ContributionInvType contributionInv;
    @XmlElement(name = "GrilleInv")
    protected GrilleInvType grilleInv;
    @XmlElement(name = "HorizonInv")
    protected HorizonInvType horizonInv;
    @XmlElement(name = "ProfilInv")
    protected ProfilInvType profilInv;
    @XmlElement(name = "SupportInv")
    protected SupportInvType supportInv;
    @XmlElement(name = "TarifInv")
    protected TarifInvType tarifInv;

    /**
     * Obtient la valeur de la propriété idOccurStructInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdOccurStructInv() {
        return idOccurStructInv;
    }

    /**
     * Définit la valeur de la propriété idOccurStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdOccurStructInv(String value) {
        this.idOccurStructInv = value;
    }

    /**
     * Obtient la valeur de la propriété idOccurParentStructInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdOccurParentStructInv() {
        return idOccurParentStructInv;
    }

    /**
     * Définit la valeur de la propriété idOccurParentStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdOccurParentStructInv(String value) {
        this.idOccurParentStructInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGestionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGestionInv() {
        return codeModeGestionInv;
    }

    /**
     * Définit la valeur de la propriété codeModeGestionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGestionInv(String value) {
        this.codeModeGestionInv = value;
    }

    /**
     * Obtient la valeur de la propriété libModeGestionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeGestionInv() {
        return libModeGestionInv;
    }

    /**
     * Définit la valeur de la propriété libModeGestionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeGestionInv(String value) {
        this.libModeGestionInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGestionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGestionInvSilo() {
        return codeModeGestionInvSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeGestionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGestionInvSilo(String value) {
        this.codeModeGestionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeGestionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeGestionInvSilo() {
        return libModeGestionInvSilo;
    }

    /**
     * Définit la valeur de la propriété libModeGestionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeGestionInvSilo(String value) {
        this.libModeGestionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatureSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatureSupportInv() {
        return codeNatureSupportInv;
    }

    /**
     * Définit la valeur de la propriété codeNatureSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatureSupportInv(String value) {
        this.codeNatureSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété libNatureSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatureSupportInv() {
        return libNatureSupportInv;
    }

    /**
     * Définit la valeur de la propriété libNatureSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatureSupportInv(String value) {
        this.libNatureSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatureSupportInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatureSupportInvSilo() {
        return codeNatureSupportInvSilo;
    }

    /**
     * Définit la valeur de la propriété codeNatureSupportInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatureSupportInvSilo(String value) {
        this.codeNatureSupportInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libNatureSupportInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatureSupportInvSilo() {
        return libNatureSupportInvSilo;
    }

    /**
     * Définit la valeur de la propriété libNatureSupportInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatureSupportInvSilo(String value) {
        this.libNatureSupportInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété montantOccurSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantOccurSupportInv() {
        return montantOccurSupportInv;
    }

    /**
     * Définit la valeur de la propriété montantOccurSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantOccurSupportInv(BigDecimal value) {
        this.montantOccurSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété deviseOccurSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviseOccurSupportInv() {
        return deviseOccurSupportInv;
    }

    /**
     * Définit la valeur de la propriété deviseOccurSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviseOccurSupportInv(String value) {
        this.deviseOccurSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété contributionInv.
     * 
     * @return
     *     possible object is
     *     {@link ContributionInvType }
     *     
     */
    public ContributionInvType getContributionInv() {
        return contributionInv;
    }

    /**
     * Définit la valeur de la propriété contributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link ContributionInvType }
     *     
     */
    public void setContributionInv(ContributionInvType value) {
        this.contributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété grilleInv.
     * 
     * @return
     *     possible object is
     *     {@link GrilleInvType }
     *     
     */
    public GrilleInvType getGrilleInv() {
        return grilleInv;
    }

    /**
     * Définit la valeur de la propriété grilleInv.
     * 
     * @param value
     *     allowed object is
     *     {@link GrilleInvType }
     *     
     */
    public void setGrilleInv(GrilleInvType value) {
        this.grilleInv = value;
    }

    /**
     * Obtient la valeur de la propriété horizonInv.
     * 
     * @return
     *     possible object is
     *     {@link HorizonInvType }
     *     
     */
    public HorizonInvType getHorizonInv() {
        return horizonInv;
    }

    /**
     * Définit la valeur de la propriété horizonInv.
     * 
     * @param value
     *     allowed object is
     *     {@link HorizonInvType }
     *     
     */
    public void setHorizonInv(HorizonInvType value) {
        this.horizonInv = value;
    }

    /**
     * Obtient la valeur de la propriété profilInv.
     * 
     * @return
     *     possible object is
     *     {@link ProfilInvType }
     *     
     */
    public ProfilInvType getProfilInv() {
        return profilInv;
    }

    /**
     * Définit la valeur de la propriété profilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link ProfilInvType }
     *     
     */
    public void setProfilInv(ProfilInvType value) {
        this.profilInv = value;
    }

    /**
     * Obtient la valeur de la propriété supportInv.
     * 
     * @return
     *     possible object is
     *     {@link SupportInvType }
     *     
     */
    public SupportInvType getSupportInv() {
        return supportInv;
    }

    /**
     * Définit la valeur de la propriété supportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link SupportInvType }
     *     
     */
    public void setSupportInv(SupportInvType value) {
        this.supportInv = value;
    }

    /**
     * Obtient la valeur de la propriété tarifInv.
     * 
     * @return
     *     possible object is
     *     {@link TarifInvType }
     *     
     */
    public TarifInvType getTarifInv() {
        return tarifInv;
    }

    /**
     * Définit la valeur de la propriété tarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link TarifInvType }
     *     
     */
    public void setTarifInv(TarifInvType value) {
        this.tarifInv = value;
    }

}
