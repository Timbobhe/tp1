
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SouscripteursType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SouscripteursType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdSiloSousc" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdSiloSouscType" minOccurs="0"/>
 *         &lt;element name="SignqSouscPP" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqSouscPPType" minOccurs="0"/>
 *         &lt;element name="DetPP" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DetPPType" minOccurs="0"/>
 *         &lt;element name="AutreNatio" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AutreNatioType" minOccurs="0"/>
 *         &lt;element name="SignqSouscPM" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqSouscPMType" minOccurs="0"/>
 *         &lt;element name="DossCom" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DossComType" minOccurs="0"/>
 *         &lt;element name="codeCCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SouscripteursType", propOrder = {
    "idSiloSousc",
    "signqSouscPP",
    "detPP",
    "autreNatio",
    "signqSouscPM",
    "dossCom",
    "codeCCN",
    "libCCN"
})
public class SouscripteursType {

    @XmlElement(name = "IdSiloSousc")
    protected IdSiloSouscType idSiloSousc;
    @XmlElement(name = "SignqSouscPP")
    protected SignqSouscPPType signqSouscPP;
    @XmlElement(name = "DetPP")
    protected DetPPType detPP;
    @XmlElement(name = "AutreNatio")
    protected AutreNatioType autreNatio;
    @XmlElement(name = "SignqSouscPM")
    protected SignqSouscPMType signqSouscPM;
    @XmlElement(name = "DossCom")
    protected DossComType dossCom;
    protected String codeCCN;
    protected String libCCN;

    /**
     * Obtient la valeur de la propriété idSiloSousc.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloSouscType }
     *     
     */
    public IdSiloSouscType getIdSiloSousc() {
        return idSiloSousc;
    }

    /**
     * Définit la valeur de la propriété idSiloSousc.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloSouscType }
     *     
     */
    public void setIdSiloSousc(IdSiloSouscType value) {
        this.idSiloSousc = value;
    }

    /**
     * Obtient la valeur de la propriété signqSouscPP.
     * 
     * @return
     *     possible object is
     *     {@link SignqSouscPPType }
     *     
     */
    public SignqSouscPPType getSignqSouscPP() {
        return signqSouscPP;
    }

    /**
     * Définit la valeur de la propriété signqSouscPP.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqSouscPPType }
     *     
     */
    public void setSignqSouscPP(SignqSouscPPType value) {
        this.signqSouscPP = value;
    }

    /**
     * Obtient la valeur de la propriété detPP.
     * 
     * @return
     *     possible object is
     *     {@link DetPPType }
     *     
     */
    public DetPPType getDetPP() {
        return detPP;
    }

    /**
     * Définit la valeur de la propriété detPP.
     * 
     * @param value
     *     allowed object is
     *     {@link DetPPType }
     *     
     */
    public void setDetPP(DetPPType value) {
        this.detPP = value;
    }

    /**
     * Obtient la valeur de la propriété autreNatio.
     * 
     * @return
     *     possible object is
     *     {@link AutreNatioType }
     *     
     */
    public AutreNatioType getAutreNatio() {
        return autreNatio;
    }

    /**
     * Définit la valeur de la propriété autreNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link AutreNatioType }
     *     
     */
    public void setAutreNatio(AutreNatioType value) {
        this.autreNatio = value;
    }

    /**
     * Obtient la valeur de la propriété signqSouscPM.
     * 
     * @return
     *     possible object is
     *     {@link SignqSouscPMType }
     *     
     */
    public SignqSouscPMType getSignqSouscPM() {
        return signqSouscPM;
    }

    /**
     * Définit la valeur de la propriété signqSouscPM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqSouscPMType }
     *     
     */
    public void setSignqSouscPM(SignqSouscPMType value) {
        this.signqSouscPM = value;
    }

    /**
     * Obtient la valeur de la propriété dossCom.
     * 
     * @return
     *     possible object is
     *     {@link DossComType }
     *     
     */
    public DossComType getDossCom() {
        return dossCom;
    }

    /**
     * Définit la valeur de la propriété dossCom.
     * 
     * @param value
     *     allowed object is
     *     {@link DossComType }
     *     
     */
    public void setDossCom(DossComType value) {
        this.dossCom = value;
    }

    /**
     * Obtient la valeur de la propriété codeCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCCN() {
        return codeCCN;
    }

    /**
     * Définit la valeur de la propriété codeCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCCN(String value) {
        this.codeCCN = value;
    }

    /**
     * Obtient la valeur de la propriété libCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCCN() {
        return libCCN;
    }

    /**
     * Définit la valeur de la propriété libCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCCN(String value) {
        this.libCCN = value;
    }

}
