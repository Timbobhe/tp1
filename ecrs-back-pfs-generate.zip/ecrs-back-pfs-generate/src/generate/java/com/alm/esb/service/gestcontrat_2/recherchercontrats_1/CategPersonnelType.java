
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CategPersonnelType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CategPersonnelType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeCategPersonnel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCategPersonnel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CategPersonnelType", propOrder = {
    "codeCategPersonnel",
    "libCategPersonnel",
    "codeSitCategPers",
    "libSitCategPers"
})
public class CategPersonnelType {

    protected String codeCategPersonnel;
    protected String libCategPersonnel;
    protected String codeSitCategPers;
    protected String libSitCategPers;

    /**
     * Obtient la valeur de la propriété codeCategPersonnel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCategPersonnel() {
        return codeCategPersonnel;
    }

    /**
     * Définit la valeur de la propriété codeCategPersonnel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCategPersonnel(String value) {
        this.codeCategPersonnel = value;
    }

    /**
     * Obtient la valeur de la propriété libCategPersonnel.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCategPersonnel() {
        return libCategPersonnel;
    }

    /**
     * Définit la valeur de la propriété libCategPersonnel.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCategPersonnel(String value) {
        this.libCategPersonnel = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCategPers() {
        return codeSitCategPers;
    }

    /**
     * Définit la valeur de la propriété codeSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCategPers(String value) {
        this.codeSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCategPers() {
        return libSitCategPers;
    }

    /**
     * Définit la valeur de la propriété libSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCategPers(String value) {
        this.libSitCategPers = value;
    }

}
