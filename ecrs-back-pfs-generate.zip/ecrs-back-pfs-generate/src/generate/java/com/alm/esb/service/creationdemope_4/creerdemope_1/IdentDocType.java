
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentDocType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentDocType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numOrdreDoc" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="typeDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeDocPiecesJointes" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentDocType", propOrder = {
    "idDoc",
    "nomDoc",
    "numOrdreDoc",
    "typeDoc",
    "typeDocPiecesJointes"
})
public class IdentDocType {

    protected String idDoc;
    protected String nomDoc;
    protected BigInteger numOrdreDoc;
    protected String typeDoc;
    protected String typeDocPiecesJointes;

    /**
     * Obtient la valeur de la propriété idDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDoc() {
        return idDoc;
    }

    /**
     * Définit la valeur de la propriété idDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDoc(String value) {
        this.idDoc = value;
    }

    /**
     * Obtient la valeur de la propriété nomDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomDoc() {
        return nomDoc;
    }

    /**
     * Définit la valeur de la propriété nomDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomDoc(String value) {
        this.nomDoc = value;
    }

    /**
     * Obtient la valeur de la propriété numOrdreDoc.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNumOrdreDoc() {
        return numOrdreDoc;
    }

    /**
     * Définit la valeur de la propriété numOrdreDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNumOrdreDoc(BigInteger value) {
        this.numOrdreDoc = value;
    }

    /**
     * Obtient la valeur de la propriété typeDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeDoc() {
        return typeDoc;
    }

    /**
     * Définit la valeur de la propriété typeDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeDoc(String value) {
        this.typeDoc = value;
    }

    /**
     * Obtient la valeur de la propriété typeDocPiecesJointes.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeDocPiecesJointes() {
        return typeDocPiecesJointes;
    }

    /**
     * Définit la valeur de la propriété typeDocPiecesJointes.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeDocPiecesJointes(String value) {
        this.typeDocPiecesJointes = value;
    }

}
