
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour CalculerEncoursContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CalculerEncoursContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}IdentContratSilo"/>
 *         &lt;element name="profondeurStruct" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEncours" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeTypeEncourSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indSitEstimeeSilo" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CalculerEncoursContratType", propOrder = {
    "identContratSilo",
    "profondeurStruct",
    "dateEncours",
    "codeTypeEncourSilo",
    "indSitEstimeeSilo"
})
public class CalculerEncoursContratType {

    @XmlElement(name = "IdentContratSilo", required = true)
    protected IdentContratSiloType identContratSilo;
    protected String profondeurStruct;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEncours;
    protected String codeTypeEncourSilo;
    protected Boolean indSitEstimeeSilo;

    /**
     * Obtient la valeur de la propriété identContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratSiloType }
     *     
     */
    public IdentContratSiloType getIdentContratSilo() {
        return identContratSilo;
    }

    /**
     * Définit la valeur de la propriété identContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratSiloType }
     *     
     */
    public void setIdentContratSilo(IdentContratSiloType value) {
        this.identContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété profondeurStruct.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProfondeurStruct() {
        return profondeurStruct;
    }

    /**
     * Définit la valeur de la propriété profondeurStruct.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProfondeurStruct(String value) {
        this.profondeurStruct = value;
    }

    /**
     * Obtient la valeur de la propriété dateEncours.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEncours() {
        return dateEncours;
    }

    /**
     * Définit la valeur de la propriété dateEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEncours(XMLGregorianCalendar value) {
        this.dateEncours = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeEncourSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeEncourSilo() {
        return codeTypeEncourSilo;
    }

    /**
     * Définit la valeur de la propriété codeTypeEncourSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeEncourSilo(String value) {
        this.codeTypeEncourSilo = value;
    }

    /**
     * Obtient la valeur de la propriété indSitEstimeeSilo.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndSitEstimeeSilo() {
        return indSitEstimeeSilo;
    }

    /**
     * Définit la valeur de la propriété indSitEstimeeSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndSitEstimeeSilo(Boolean value) {
        this.indSitEstimeeSilo = value;
    }

}
