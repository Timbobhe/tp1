
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour TarifInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="TarifInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idTarifInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomTarifInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txRepartitionTarifInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TarifInvType", propOrder = {
    "idTarifInv",
    "nomTarifInv",
    "txRepartitionTarifInv"
})
public class TarifInvType {

    protected String idTarifInv;
    protected String nomTarifInv;
    protected BigDecimal txRepartitionTarifInv;

    /**
     * Obtient la valeur de la propriété idTarifInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdTarifInv() {
        return idTarifInv;
    }

    /**
     * Définit la valeur de la propriété idTarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdTarifInv(String value) {
        this.idTarifInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomTarifInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomTarifInv() {
        return nomTarifInv;
    }

    /**
     * Définit la valeur de la propriété nomTarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomTarifInv(String value) {
        this.nomTarifInv = value;
    }

    /**
     * Obtient la valeur de la propriété txRepartitionTarifInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRepartitionTarifInv() {
        return txRepartitionTarifInv;
    }

    /**
     * Définit la valeur de la propriété txRepartitionTarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRepartitionTarifInv(BigDecimal value) {
        this.txRepartitionTarifInv = value;
    }

}
