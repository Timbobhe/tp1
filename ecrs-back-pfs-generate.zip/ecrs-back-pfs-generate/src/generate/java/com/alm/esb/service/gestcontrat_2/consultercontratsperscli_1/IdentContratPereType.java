
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratPereType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratPereType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}IdentsPere" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratPereType", propOrder = {
    "identsPere"
})
public class IdentContratPereType {

    @XmlElement(name = "IdentsPere")
    protected CIdentsPereType identsPere;

    /**
     * Obtient la valeur de la propriété identsPere.
     * 
     * @return
     *     possible object is
     *     {@link CIdentsPereType }
     *     
     */
    public CIdentsPereType getIdentsPere() {
        return identsPere;
    }

    /**
     * Définit la valeur de la propriété identsPere.
     * 
     * @param value
     *     allowed object is
     *     {@link CIdentsPereType }
     *     
     */
    public void setIdentsPere(CIdentsPereType value) {
        this.identsPere = value;
    }

}
