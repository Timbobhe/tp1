
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CalculerEncoursContratFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CalculerEncoursContratFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}CalculerEncoursContrat" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}CalculerEncoursContratResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CalculerEncoursContratFullType", propOrder = {
    "calculerEncoursContrat",
    "calculerEncoursContratResponse"
})
public class CalculerEncoursContratFullType {

    @XmlElement(name = "CalculerEncoursContrat")
    protected CalculerEncoursContratType calculerEncoursContrat;
    @XmlElement(name = "CalculerEncoursContratResponse")
    protected CalculerEncoursContratResponseType calculerEncoursContratResponse;

    /**
     * Obtient la valeur de la propriété calculerEncoursContrat.
     * 
     * @return
     *     possible object is
     *     {@link CalculerEncoursContratType }
     *     
     */
    public CalculerEncoursContratType getCalculerEncoursContrat() {
        return calculerEncoursContrat;
    }

    /**
     * Définit la valeur de la propriété calculerEncoursContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link CalculerEncoursContratType }
     *     
     */
    public void setCalculerEncoursContrat(CalculerEncoursContratType value) {
        this.calculerEncoursContrat = value;
    }

    /**
     * Obtient la valeur de la propriété calculerEncoursContratResponse.
     * 
     * @return
     *     possible object is
     *     {@link CalculerEncoursContratResponseType }
     *     
     */
    public CalculerEncoursContratResponseType getCalculerEncoursContratResponse() {
        return calculerEncoursContratResponse;
    }

    /**
     * Définit la valeur de la propriété calculerEncoursContratResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link CalculerEncoursContratResponseType }
     *     
     */
    public void setCalculerEncoursContratResponse(CalculerEncoursContratResponseType value) {
        this.calculerEncoursContratResponse = value;
    }

}
