
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OffreCommSouscriteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OffreCommSouscriteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeOffreComm" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libOffreComm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numgenContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdentOfrSoustn" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}IdentOfrSoustnType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OffreCommSouscriteType", propOrder = {
    "codeOffreComm",
    "libOffreComm",
    "codeTypeContrat",
    "numgenContrat",
    "identOfrSoustn"
})
public class OffreCommSouscriteType {

    @XmlElement(required = true)
    protected String codeOffreComm;
    protected String libOffreComm;
    protected String codeTypeContrat;
    protected String numgenContrat;
    @XmlElement(name = "IdentOfrSoustn")
    protected IdentOfrSoustnType identOfrSoustn;

    /**
     * Obtient la valeur de la propriété codeOffreComm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOffreComm() {
        return codeOffreComm;
    }

    /**
     * Définit la valeur de la propriété codeOffreComm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOffreComm(String value) {
        this.codeOffreComm = value;
    }

    /**
     * Obtient la valeur de la propriété libOffreComm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOffreComm() {
        return libOffreComm;
    }

    /**
     * Définit la valeur de la propriété libOffreComm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOffreComm(String value) {
        this.libOffreComm = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeContrat() {
        return codeTypeContrat;
    }

    /**
     * Définit la valeur de la propriété codeTypeContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeContrat(String value) {
        this.codeTypeContrat = value;
    }

    /**
     * Obtient la valeur de la propriété numgenContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumgenContrat() {
        return numgenContrat;
    }

    /**
     * Définit la valeur de la propriété numgenContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumgenContrat(String value) {
        this.numgenContrat = value;
    }

    /**
     * Obtient la valeur de la propriété identOfrSoustn.
     * 
     * @return
     *     possible object is
     *     {@link IdentOfrSoustnType }
     *     
     */
    public IdentOfrSoustnType getIdentOfrSoustn() {
        return identOfrSoustn;
    }

    /**
     * Définit la valeur de la propriété identOfrSoustn.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentOfrSoustnType }
     *     
     */
    public void setIdentOfrSoustn(IdentOfrSoustnType value) {
        this.identOfrSoustn = value;
    }

}
