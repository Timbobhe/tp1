
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ActeurContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ActeurContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAssureurContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libAssureurContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idApporteurAffaire" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libApporteurAffaire" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idDistribproduit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDistribproduit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActeurContratType", propOrder = {
    "idAssureurContrat",
    "libAssureurContrat",
    "idApporteurAffaire",
    "libApporteurAffaire",
    "idDistribproduit",
    "libDistribproduit"
})
public class ActeurContratType {

    protected String idAssureurContrat;
    protected String libAssureurContrat;
    protected String idApporteurAffaire;
    protected String libApporteurAffaire;
    protected String idDistribproduit;
    protected String libDistribproduit;

    /**
     * Obtient la valeur de la propriété idAssureurContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAssureurContrat() {
        return idAssureurContrat;
    }

    /**
     * Définit la valeur de la propriété idAssureurContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAssureurContrat(String value) {
        this.idAssureurContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libAssureurContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAssureurContrat() {
        return libAssureurContrat;
    }

    /**
     * Définit la valeur de la propriété libAssureurContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAssureurContrat(String value) {
        this.libAssureurContrat = value;
    }

    /**
     * Obtient la valeur de la propriété idApporteurAffaire.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdApporteurAffaire() {
        return idApporteurAffaire;
    }

    /**
     * Définit la valeur de la propriété idApporteurAffaire.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdApporteurAffaire(String value) {
        this.idApporteurAffaire = value;
    }

    /**
     * Obtient la valeur de la propriété libApporteurAffaire.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibApporteurAffaire() {
        return libApporteurAffaire;
    }

    /**
     * Définit la valeur de la propriété libApporteurAffaire.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibApporteurAffaire(String value) {
        this.libApporteurAffaire = value;
    }

    /**
     * Obtient la valeur de la propriété idDistribproduit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDistribproduit() {
        return idDistribproduit;
    }

    /**
     * Définit la valeur de la propriété idDistribproduit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDistribproduit(String value) {
        this.idDistribproduit = value;
    }

    /**
     * Obtient la valeur de la propriété libDistribproduit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDistribproduit() {
        return libDistribproduit;
    }

    /**
     * Définit la valeur de la propriété libDistribproduit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDistribproduit(String value) {
        this.libDistribproduit = value;
    }

}
