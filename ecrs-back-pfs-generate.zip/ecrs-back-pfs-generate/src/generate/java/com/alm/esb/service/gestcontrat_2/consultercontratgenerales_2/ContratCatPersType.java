
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratCatPersType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratCatPersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InfoContrat" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}InfoContratEffetType" minOccurs="0"/>
 *         &lt;element name="OfrCialSousc" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}OfrCialSouscType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratCatPersType", propOrder = {
    "infoContrat",
    "ofrCialSousc"
})
public class ContratCatPersType {

    @XmlElement(name = "InfoContrat")
    protected InfoContratEffetType infoContrat;
    @XmlElement(name = "OfrCialSousc")
    protected OfrCialSouscType ofrCialSousc;

    /**
     * Obtient la valeur de la propriété infoContrat.
     * 
     * @return
     *     possible object is
     *     {@link InfoContratEffetType }
     *     
     */
    public InfoContratEffetType getInfoContrat() {
        return infoContrat;
    }

    /**
     * Définit la valeur de la propriété infoContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoContratEffetType }
     *     
     */
    public void setInfoContrat(InfoContratEffetType value) {
        this.infoContrat = value;
    }

    /**
     * Obtient la valeur de la propriété ofrCialSousc.
     * 
     * @return
     *     possible object is
     *     {@link OfrCialSouscType }
     *     
     */
    public OfrCialSouscType getOfrCialSousc() {
        return ofrCialSousc;
    }

    /**
     * Définit la valeur de la propriété ofrCialSousc.
     * 
     * @param value
     *     allowed object is
     *     {@link OfrCialSouscType }
     *     
     */
    public void setOfrCialSousc(OfrCialSouscType value) {
        this.ofrCialSousc = value;
    }

}
