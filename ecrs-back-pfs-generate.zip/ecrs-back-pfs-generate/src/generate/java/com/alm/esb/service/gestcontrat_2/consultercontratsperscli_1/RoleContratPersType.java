
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour RoleContratPersType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RoleContratPersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeRoleContrat" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libRoleContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeRoleContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebRole" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="dateFinRole" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="idClientPartenaire" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idGDI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RoleContratPersType", propOrder = {
    "codeRoleContrat",
    "libRoleContrat",
    "codeRoleContratSilo",
    "dateDebRole",
    "dateFinRole",
    "idClientPartenaire",
    "idGDI"
})
public class RoleContratPersType {

    @XmlElement(required = true)
    protected String codeRoleContrat;
    protected String libRoleContrat;
    protected String codeRoleContratSilo;
    @XmlElement(required = true)
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebRole;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinRole;
    protected String idClientPartenaire;
    protected String idGDI;

    /**
     * Obtient la valeur de la propriété codeRoleContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRoleContrat() {
        return codeRoleContrat;
    }

    /**
     * Définit la valeur de la propriété codeRoleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRoleContrat(String value) {
        this.codeRoleContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libRoleContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibRoleContrat() {
        return libRoleContrat;
    }

    /**
     * Définit la valeur de la propriété libRoleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibRoleContrat(String value) {
        this.libRoleContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeRoleContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRoleContratSilo() {
        return codeRoleContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeRoleContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRoleContratSilo(String value) {
        this.codeRoleContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebRole.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebRole() {
        return dateDebRole;
    }

    /**
     * Définit la valeur de la propriété dateDebRole.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebRole(XMLGregorianCalendar value) {
        this.dateDebRole = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinRole.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinRole() {
        return dateFinRole;
    }

    /**
     * Définit la valeur de la propriété dateFinRole.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinRole(XMLGregorianCalendar value) {
        this.dateFinRole = value;
    }

    /**
     * Obtient la valeur de la propriété idClientPartenaire.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdClientPartenaire() {
        return idClientPartenaire;
    }

    /**
     * Définit la valeur de la propriété idClientPartenaire.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdClientPartenaire(String value) {
        this.idClientPartenaire = value;
    }

    /**
     * Obtient la valeur de la propriété idGDI.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdGDI() {
        return idGDI;
    }

    /**
     * Définit la valeur de la propriété idGDI.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdGDI(String value) {
        this.idGDI = value;
    }

}
