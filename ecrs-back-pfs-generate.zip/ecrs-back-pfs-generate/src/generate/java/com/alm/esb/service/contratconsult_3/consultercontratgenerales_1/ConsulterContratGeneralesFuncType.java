
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratGeneralesFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratGeneralesFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CtrAssur" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratGeneralesFuncType", propOrder = {
    "ctrAssur"
})
public class ConsulterContratGeneralesFuncType {

    @XmlElement(name = "CtrAssur")
    protected CtrType ctrAssur;

    /**
     * Obtient la valeur de la propriété ctrAssur.
     * 
     * @return
     *     possible object is
     *     {@link CtrType }
     *     
     */
    public CtrType getCtrAssur() {
        return ctrAssur;
    }

    /**
     * Définit la valeur de la propriété ctrAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrType }
     *     
     */
    public void setCtrAssur(CtrType value) {
        this.ctrAssur = value;
    }

}
