
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdContratSourceType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdContratSourceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="50"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeAppli" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *               &lt;maxLength value="10"/>
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdContratSourceType", propOrder = {
    "idSilo",
    "codeAppli"
})
public class IdContratSourceType {

    protected String idSilo;
    protected String codeAppli;

    /**
     * Obtient la valeur de la propriété idSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSilo() {
        return idSilo;
    }

    /**
     * Définit la valeur de la propriété idSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSilo(String value) {
        this.idSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAppli() {
        return codeAppli;
    }

    /**
     * Définit la valeur de la propriété codeAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAppli(String value) {
        this.codeAppli = value;
    }

}
