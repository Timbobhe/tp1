
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour TarifInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="TarifInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idTarifPrimeInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomTarifInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionTarifInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionProfilInvDefaut" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TarifInvType", propOrder = {
    "idTarifPrimeInv",
    "nomTarifInv",
    "tauxRepartitionTarifInv",
    "tauxRepartitionProfilInvDefaut"
})
public class TarifInvType {

    protected String idTarifPrimeInv;
    protected String nomTarifInv;
    protected BigDecimal tauxRepartitionTarifInv;
    protected BigDecimal tauxRepartitionProfilInvDefaut;

    /**
     * Obtient la valeur de la propriété idTarifPrimeInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdTarifPrimeInv() {
        return idTarifPrimeInv;
    }

    /**
     * Définit la valeur de la propriété idTarifPrimeInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdTarifPrimeInv(String value) {
        this.idTarifPrimeInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomTarifInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomTarifInv() {
        return nomTarifInv;
    }

    /**
     * Définit la valeur de la propriété nomTarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomTarifInv(String value) {
        this.nomTarifInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionTarifInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionTarifInv() {
        return tauxRepartitionTarifInv;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionTarifInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionTarifInv(BigDecimal value) {
        this.tauxRepartitionTarifInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionProfilInvDefaut() {
        return tauxRepartitionProfilInvDefaut;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionProfilInvDefaut(BigDecimal value) {
        this.tauxRepartitionProfilInvDefaut = value;
    }

}
