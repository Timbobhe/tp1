
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ProfilInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ProfilInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idProfilInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomProfilInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txRepartitionProfilInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicTxDerogeableProfilInv" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProfilInvType", propOrder = {
    "idProfilInv",
    "nomProfilInv",
    "txRepartitionProfilInv",
    "indicTxDerogeableProfilInv"
})
public class ProfilInvType {

    protected String idProfilInv;
    protected String nomProfilInv;
    protected BigDecimal txRepartitionProfilInv;
    protected Boolean indicTxDerogeableProfilInv;

    /**
     * Obtient la valeur de la propriété idProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdProfilInv() {
        return idProfilInv;
    }

    /**
     * Définit la valeur de la propriété idProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdProfilInv(String value) {
        this.idProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomProfilInv() {
        return nomProfilInv;
    }

    /**
     * Définit la valeur de la propriété nomProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomProfilInv(String value) {
        this.nomProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété txRepartitionProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRepartitionProfilInv() {
        return txRepartitionProfilInv;
    }

    /**
     * Définit la valeur de la propriété txRepartitionProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRepartitionProfilInv(BigDecimal value) {
        this.txRepartitionProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété indicTxDerogeableProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicTxDerogeableProfilInv() {
        return indicTxDerogeableProfilInv;
    }

    /**
     * Définit la valeur de la propriété indicTxDerogeableProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicTxDerogeableProfilInv(Boolean value) {
        this.indicTxDerogeableProfilInv = value;
    }

}
