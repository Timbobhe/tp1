
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentificationContratSiloType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentificationContratSiloType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentifiantSilo" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IdentifiantSiloType" maxOccurs="unbounded"/>
 *         &lt;element name="codeApplication" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeSystemeInformation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificationContratSiloType", propOrder = {
    "identifiantSilo",
    "codeApplication",
    "codeSystemeInformation"
})
public class IdentificationContratSiloType {

    @XmlElement(name = "IdentifiantSilo", required = true)
    protected List<IdentifiantSiloType> identifiantSilo;
    @XmlElement(required = true)
    protected String codeApplication;
    @XmlElement(required = true)
    protected String codeSystemeInformation;

    /**
     * Gets the value of the identifiantSilo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identifiantSilo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentifiantSilo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentifiantSiloType }
     * 
     * 
     */
    public List<IdentifiantSiloType> getIdentifiantSilo() {
        if (identifiantSilo == null) {
            identifiantSilo = new ArrayList<IdentifiantSiloType>();
        }
        return this.identifiantSilo;
    }

    /**
     * Obtient la valeur de la propriété codeApplication.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeApplication() {
        return codeApplication;
    }

    /**
     * Définit la valeur de la propriété codeApplication.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeApplication(String value) {
        this.codeApplication = value;
    }

    /**
     * Obtient la valeur de la propriété codeSystemeInformation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSystemeInformation() {
        return codeSystemeInformation;
    }

    /**
     * Définit la valeur de la propriété codeSystemeInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSystemeInformation(String value) {
        this.codeSystemeInformation = value;
    }

}
