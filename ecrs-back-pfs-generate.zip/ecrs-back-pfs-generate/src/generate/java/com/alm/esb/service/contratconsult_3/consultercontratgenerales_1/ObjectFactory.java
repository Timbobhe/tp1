
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.contratconsult_3.consultercontratgenerales_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConsulterContratGeneralesResponse_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ConsulterContratGeneralesResponse");
    private final static QName _ConsulterContratGenerales_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ConsulterContratGenerales");
    private final static QName _ConsulterContratGeneralesFunc_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ConsulterContratGeneralesFunc");
    private final static QName _ConsulterContratGeneralesFull_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ConsulterContratGeneralesFull");
    private final static QName _RequestJSONRoot_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "RequestJSONRoot");
    private final static QName _ConsulterContratGeneralesResponseFull_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ConsulterContratGeneralesResponseFull");
    private final static QName _ResponseJSONRoot_QNAME = new QName("http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", "ResponseJSONRoot");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.contratconsult_3.consultercontratgenerales_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesType }
     * 
     */
    public ConsulterContratGeneralesType createConsulterContratGeneralesType() {
        return new ConsulterContratGeneralesType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesResponseType }
     * 
     */
    public ConsulterContratGeneralesResponseType createConsulterContratGeneralesResponseType() {
        return new ConsulterContratGeneralesResponseType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesFuncType }
     * 
     */
    public ConsulterContratGeneralesFuncType createConsulterContratGeneralesFuncType() {
        return new ConsulterContratGeneralesFuncType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesFullType }
     * 
     */
    public ConsulterContratGeneralesFullType createConsulterContratGeneralesFullType() {
        return new ConsulterContratGeneralesFullType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesResponseFullType }
     * 
     */
    public ConsulterContratGeneralesResponseFullType createConsulterContratGeneralesResponseFullType() {
        return new ConsulterContratGeneralesResponseFullType();
    }

    /**
     * Create an instance of {@link RequestJSONRootType }
     * 
     */
    public RequestJSONRootType createRequestJSONRootType() {
        return new RequestJSONRootType();
    }

    /**
     * Create an instance of {@link ResponseJSONRootType }
     * 
     */
    public ResponseJSONRootType createResponseJSONRootType() {
        return new ResponseJSONRootType();
    }

    /**
     * Create an instance of {@link IdentCtrType }
     * 
     */
    public IdentCtrType createIdentCtrType() {
        return new IdentCtrType();
    }

    /**
     * Create an instance of {@link EchrPaimtPrimeType }
     * 
     */
    public EchrPaimtPrimeType createEchrPaimtPrimeType() {
        return new EchrPaimtPrimeType();
    }

    /**
     * Create an instance of {@link InfoCtrType }
     * 
     */
    public InfoCtrType createInfoCtrType() {
        return new InfoCtrType();
    }

    /**
     * Create an instance of {@link IdentPersType }
     * 
     */
    public IdentPersType createIdentPersType() {
        return new IdentPersType();
    }

    /**
     * Create an instance of {@link AssurePrcpType }
     * 
     */
    public AssurePrcpType createAssurePrcpType() {
        return new AssurePrcpType();
    }

    /**
     * Create an instance of {@link CtrAdherenteType }
     * 
     */
    public CtrAdherenteType createCtrAdherenteType() {
        return new CtrAdherenteType();
    }

    /**
     * Create an instance of {@link CoordonneesCmptBancType }
     * 
     */
    public CoordonneesCmptBancType createCoordonneesCmptBancType() {
        return new CoordonneesCmptBancType();
    }

    /**
     * Create an instance of {@link IdentDansSiloType }
     * 
     */
    public IdentDansSiloType createIdentDansSiloType() {
        return new IdentDansSiloType();
    }

    /**
     * Create an instance of {@link CtntxType }
     * 
     */
    public CtntxType createCtntxType() {
        return new CtntxType();
    }

    /**
     * Create an instance of {@link IdentCtrAdherenteType }
     * 
     */
    public IdentCtrAdherenteType createIdentCtrAdherenteType() {
        return new IdentCtrAdherenteType();
    }

    /**
     * Create an instance of {@link SignqPMType }
     * 
     */
    public SignqPMType createSignqPMType() {
        return new SignqPMType();
    }

    /**
     * Create an instance of {@link GarSouscritesType }
     * 
     */
    public GarSouscritesType createGarSouscritesType() {
        return new GarSouscritesType();
    }

    /**
     * Create an instance of {@link AffilCtrType }
     * 
     */
    public AffilCtrType createAffilCtrType() {
        return new AffilCtrType();
    }

    /**
     * Create an instance of {@link PdtType }
     * 
     */
    public PdtType createPdtType() {
        return new PdtType();
    }

    /**
     * Create an instance of {@link SignaletiqueAdherentePMType }
     * 
     */
    public SignaletiqueAdherentePMType createSignaletiqueAdherentePMType() {
        return new SignaletiqueAdherentePMType();
    }

    /**
     * Create an instance of {@link TrsfCtrType }
     * 
     */
    public TrsfCtrType createTrsfCtrType() {
        return new TrsfCtrType();
    }

    /**
     * Create an instance of {@link AppelCotisType }
     * 
     */
    public AppelCotisType createAppelCotisType() {
        return new AppelCotisType();
    }

    /**
     * Create an instance of {@link PdtCtrType }
     * 
     */
    public PdtCtrType createPdtCtrType() {
        return new PdtCtrType();
    }

    /**
     * Create an instance of {@link AdhType }
     * 
     */
    public AdhType createAdhType() {
        return new AdhType();
    }

    /**
     * Create an instance of {@link CtrCollType }
     * 
     */
    public CtrCollType createCtrCollType() {
        return new CtrCollType();
    }

    /**
     * Create an instance of {@link GestType }
     * 
     */
    public GestType createGestType() {
        return new GestType();
    }

    /**
     * Create an instance of {@link SignqSouscPPType }
     * 
     */
    public SignqSouscPPType createSignqSouscPPType() {
        return new SignqSouscPPType();
    }

    /**
     * Create an instance of {@link OfrCialSouscType }
     * 
     */
    public OfrCialSouscType createOfrCialSouscType() {
        return new OfrCialSouscType();
    }

    /**
     * Create an instance of {@link CatPrslAdherenteType }
     * 
     */
    public CatPrslAdherenteType createCatPrslAdherenteType() {
        return new CatPrslAdherenteType();
    }

    /**
     * Create an instance of {@link IdentCtrPereType }
     * 
     */
    public IdentCtrPereType createIdentCtrPereType() {
        return new IdentCtrPereType();
    }

    /**
     * Create an instance of {@link AutreNatioType }
     * 
     */
    public AutreNatioType createAutreNatioType() {
        return new AutreNatioType();
    }

    /**
     * Create an instance of {@link IdentOfrSousctnType }
     * 
     */
    public IdentOfrSousctnType createIdentOfrSousctnType() {
        return new IdentOfrSousctnType();
    }

    /**
     * Create an instance of {@link RibType }
     * 
     */
    public RibType createRibType() {
        return new RibType();
    }

    /**
     * Create an instance of {@link DossComType }
     * 
     */
    public DossComType createDossComType() {
        return new DossComType();
    }

    /**
     * Create an instance of {@link RolePersType }
     * 
     */
    public RolePersType createRolePersType() {
        return new RolePersType();
    }

    /**
     * Create an instance of {@link CoordonneesBancType }
     * 
     */
    public CoordonneesBancType createCoordonneesBancType() {
        return new CoordonneesBancType();
    }

    /**
     * Create an instance of {@link IdentsPereType }
     * 
     */
    public IdentsPereType createIdentsPereType() {
        return new IdentsPereType();
    }

    /**
     * Create an instance of {@link ClauseCtrType }
     * 
     */
    public ClauseCtrType createClauseCtrType() {
        return new ClauseCtrType();
    }

    /**
     * Create an instance of {@link SouscripteursType }
     * 
     */
    public SouscripteursType createSouscripteursType() {
        return new SouscripteursType();
    }

    /**
     * Create an instance of {@link ActivPartnrtType }
     * 
     */
    public ActivPartnrtType createActivPartnrtType() {
        return new ActivPartnrtType();
    }

    /**
     * Create an instance of {@link OptCtrEpargType }
     * 
     */
    public OptCtrEpargType createOptCtrEpargType() {
        return new OptCtrEpargType();
    }

    /**
     * Create an instance of {@link SignqPPAssurAddType }
     * 
     */
    public SignqPPAssurAddType createSignqPPAssurAddType() {
        return new SignqPPAssurAddType();
    }

    /**
     * Create an instance of {@link SignqPPType }
     * 
     */
    public SignqPPType createSignqPPType() {
        return new SignqPPType();
    }

    /**
     * Create an instance of {@link InfoCtrEffetType }
     * 
     */
    public InfoCtrEffetType createInfoCtrEffetType() {
        return new InfoCtrEffetType();
    }

    /**
     * Create an instance of {@link OfrCialSousc2Type }
     * 
     */
    public OfrCialSousc2Type createOfrCialSousc2Type() {
        return new OfrCialSousc2Type();
    }

    /**
     * Create an instance of {@link OptRenteType }
     * 
     */
    public OptRenteType createOptRenteType() {
        return new OptRenteType();
    }

    /**
     * Create an instance of {@link SignaletiquePPAssurPrincType }
     * 
     */
    public SignaletiquePPAssurPrincType createSignaletiquePPAssurPrincType() {
        return new SignaletiquePPAssurPrincType();
    }

    /**
     * Create an instance of {@link IdSiloAdherenteType }
     * 
     */
    public IdSiloAdherenteType createIdSiloAdherenteType() {
        return new IdSiloAdherenteType();
    }

    /**
     * Create an instance of {@link VenteType }
     * 
     */
    public VenteType createVenteType() {
        return new VenteType();
    }

    /**
     * Create an instance of {@link DetGarType }
     * 
     */
    public DetGarType createDetGarType() {
        return new DetGarType();
    }

    /**
     * Create an instance of {@link CatPrslType }
     * 
     */
    public CatPrslType createCatPrslType() {
        return new CatPrslType();
    }

    /**
     * Create an instance of {@link DetPPType }
     * 
     */
    public DetPPType createDetPPType() {
        return new DetPPType();
    }

    /**
     * Create an instance of {@link IdentCtrSrcType }
     * 
     */
    public IdentCtrSrcType createIdentCtrSrcType() {
        return new IdentCtrSrcType();
    }

    /**
     * Create an instance of {@link LibClauseType }
     * 
     */
    public LibClauseType createLibClauseType() {
        return new LibClauseType();
    }

    /**
     * Create an instance of {@link CtrCatPersType }
     * 
     */
    public CtrCatPersType createCtrCatPersType() {
        return new CtrCatPersType();
    }

    /**
     * Create an instance of {@link CotisType }
     * 
     */
    public CotisType createCotisType() {
        return new CotisType();
    }

    /**
     * Create an instance of {@link IdSiloSouscType }
     * 
     */
    public IdSiloSouscType createIdSiloSouscType() {
        return new IdSiloSouscType();
    }

    /**
     * Create an instance of {@link IdentSiloCtrType }
     * 
     */
    public IdentSiloCtrType createIdentSiloCtrType() {
        return new IdentSiloCtrType();
    }

    /**
     * Create an instance of {@link IdOfrSousctnType }
     * 
     */
    public IdOfrSousctnType createIdOfrSousctnType() {
        return new IdOfrSousctnType();
    }

    /**
     * Create an instance of {@link AssuresAddType }
     * 
     */
    public AssuresAddType createAssuresAddType() {
        return new AssuresAddType();
    }

    /**
     * Create an instance of {@link PartclRenteType }
     * 
     */
    public PartclRenteType createPartclRenteType() {
        return new PartclRenteType();
    }

    /**
     * Create an instance of {@link SignqSouscPMType }
     * 
     */
    public SignqSouscPMType createSignqSouscPMType() {
        return new SignqSouscPMType();
    }

    /**
     * Create an instance of {@link CtrCollAdherenteType }
     * 
     */
    public CtrCollAdherenteType createCtrCollAdherenteType() {
        return new CtrCollAdherenteType();
    }

    /**
     * Create an instance of {@link PrimeType }
     * 
     */
    public PrimeType createPrimeType() {
        return new PrimeType();
    }

    /**
     * Create an instance of {@link CtrIndvType }
     * 
     */
    public CtrIndvType createCtrIndvType() {
        return new CtrIndvType();
    }

    /**
     * Create an instance of {@link ActrCtrType }
     * 
     */
    public ActrCtrType createActrCtrType() {
        return new ActrCtrType();
    }

    /**
     * Create an instance of {@link ClausesCtrType }
     * 
     */
    public ClausesCtrType createClausesCtrType() {
        return new ClausesCtrType();
    }

    /**
     * Create an instance of {@link CtrType }
     * 
     */
    public CtrType createCtrType() {
        return new CtrType();
    }

    /**
     * Create an instance of {@link IdentContratPereType }
     * 
     */
    public IdentContratPereType createIdentContratPereType() {
        return new IdentContratPereType();
    }

    /**
     * Create an instance of {@link SignqAdherentePMType }
     * 
     */
    public SignqAdherentePMType createSignqAdherentePMType() {
        return new SignqAdherentePMType();
    }

    /**
     * Create an instance of {@link CtxTypeType }
     * 
     */
    public CtxTypeType createCtxTypeType() {
        return new CtxTypeType();
    }

    /**
     * Create an instance of {@link StructOrgaType }
     * 
     */
    public StructOrgaType createStructOrgaType() {
        return new StructOrgaType();
    }

    /**
     * Create an instance of {@link PdtSupType }
     * 
     */
    public PdtSupType createPdtSupType() {
        return new PdtSupType();
    }

    /**
     * Create an instance of {@link IdentSiloContratType }
     * 
     */
    public IdentSiloContratType createIdentSiloContratType() {
        return new IdentSiloContratType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ConsulterContratGeneralesResponse")
    public JAXBElement<ConsulterContratGeneralesResponseType> createConsulterContratGeneralesResponse(ConsulterContratGeneralesResponseType value) {
        return new JAXBElement<ConsulterContratGeneralesResponseType>(_ConsulterContratGeneralesResponse_QNAME, ConsulterContratGeneralesResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ConsulterContratGenerales")
    public JAXBElement<ConsulterContratGeneralesType> createConsulterContratGenerales(ConsulterContratGeneralesType value) {
        return new JAXBElement<ConsulterContratGeneralesType>(_ConsulterContratGenerales_QNAME, ConsulterContratGeneralesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ConsulterContratGeneralesFunc")
    public JAXBElement<ConsulterContratGeneralesFuncType> createConsulterContratGeneralesFunc(ConsulterContratGeneralesFuncType value) {
        return new JAXBElement<ConsulterContratGeneralesFuncType>(_ConsulterContratGeneralesFunc_QNAME, ConsulterContratGeneralesFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ConsulterContratGeneralesFull")
    public JAXBElement<ConsulterContratGeneralesFullType> createConsulterContratGeneralesFull(ConsulterContratGeneralesFullType value) {
        return new JAXBElement<ConsulterContratGeneralesFullType>(_ConsulterContratGeneralesFull_QNAME, ConsulterContratGeneralesFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestJSONRootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "RequestJSONRoot")
    public JAXBElement<RequestJSONRootType> createRequestJSONRoot(RequestJSONRootType value) {
        return new JAXBElement<RequestJSONRootType>(_RequestJSONRoot_QNAME, RequestJSONRootType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesResponseFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ConsulterContratGeneralesResponseFull")
    public JAXBElement<ConsulterContratGeneralesResponseFullType> createConsulterContratGeneralesResponseFull(ConsulterContratGeneralesResponseFullType value) {
        return new JAXBElement<ConsulterContratGeneralesResponseFullType>(_ConsulterContratGeneralesResponseFull_QNAME, ConsulterContratGeneralesResponseFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResponseJSONRootType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", name = "ResponseJSONRoot")
    public JAXBElement<ResponseJSONRootType> createResponseJSONRoot(ResponseJSONRootType value) {
        return new JAXBElement<ResponseJSONRootType>(_ResponseJSONRoot_QNAME, ResponseJSONRootType.class, null, value);
    }

}
