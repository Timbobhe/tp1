
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_4;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdContrat" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}IdContratType" minOccurs="0"/>
 *         &lt;element name="ContratAssur" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}ContratAssurType" minOccurs="0"/>
 *         &lt;element name="Souscripteur" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}SouscripteurType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="OfrCialSousc" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}OfrCialSouscType" minOccurs="0"/>
 *         &lt;element name="GestionnaireContrat" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}GestionnaireContratType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratType", propOrder = {
    "idContrat",
    "contratAssur",
    "souscripteur",
    "ofrCialSousc",
    "gestionnaireContrat"
})
public class ContratType {

    @XmlElement(name = "IdContrat")
    protected IdContratType idContrat;
    @XmlElement(name = "ContratAssur")
    protected ContratAssurType contratAssur;
    @XmlElement(name = "Souscripteur")
    protected List<SouscripteurType> souscripteur;
    @XmlElement(name = "OfrCialSousc")
    protected OfrCialSouscType ofrCialSousc;
    @XmlElement(name = "GestionnaireContrat")
    protected GestionnaireContratType gestionnaireContrat;

    /**
     * Obtient la valeur de la propriété idContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdContratType }
     *     
     */
    public IdContratType getIdContrat() {
        return idContrat;
    }

    /**
     * Définit la valeur de la propriété idContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdContratType }
     *     
     */
    public void setIdContrat(IdContratType value) {
        this.idContrat = value;
    }

    /**
     * Obtient la valeur de la propriété contratAssur.
     * 
     * @return
     *     possible object is
     *     {@link ContratAssurType }
     *     
     */
    public ContratAssurType getContratAssur() {
        return contratAssur;
    }

    /**
     * Définit la valeur de la propriété contratAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratAssurType }
     *     
     */
    public void setContratAssur(ContratAssurType value) {
        this.contratAssur = value;
    }

    /**
     * Gets the value of the souscripteur property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the souscripteur property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSouscripteur().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SouscripteurType }
     * 
     * 
     */
    public List<SouscripteurType> getSouscripteur() {
        if (souscripteur == null) {
            souscripteur = new ArrayList<SouscripteurType>();
        }
        return this.souscripteur;
    }

    /**
     * Obtient la valeur de la propriété ofrCialSousc.
     * 
     * @return
     *     possible object is
     *     {@link OfrCialSouscType }
     *     
     */
    public OfrCialSouscType getOfrCialSousc() {
        return ofrCialSousc;
    }

    /**
     * Définit la valeur de la propriété ofrCialSousc.
     * 
     * @param value
     *     allowed object is
     *     {@link OfrCialSouscType }
     *     
     */
    public void setOfrCialSousc(OfrCialSouscType value) {
        this.ofrCialSousc = value;
    }

    /**
     * Obtient la valeur de la propriété gestionnaireContrat.
     * 
     * @return
     *     possible object is
     *     {@link GestionnaireContratType }
     *     
     */
    public GestionnaireContratType getGestionnaireContrat() {
        return gestionnaireContrat;
    }

    /**
     * Définit la valeur de la propriété gestionnaireContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link GestionnaireContratType }
     *     
     */
    public void setGestionnaireContrat(GestionnaireContratType value) {
        this.gestionnaireContrat = value;
    }

}
