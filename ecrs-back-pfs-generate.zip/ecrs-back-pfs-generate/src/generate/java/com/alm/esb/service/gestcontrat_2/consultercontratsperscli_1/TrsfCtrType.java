
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour TrsfCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="TrsfCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="mutualisationDesEncours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TrsfCtrType", propOrder = {
    "mutualisationDesEncours"
})
public class TrsfCtrType {

    protected String mutualisationDesEncours;

    /**
     * Obtient la valeur de la propriété mutualisationDesEncours.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMutualisationDesEncours() {
        return mutualisationDesEncours;
    }

    /**
     * Définit la valeur de la propriété mutualisationDesEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMutualisationDesEncours(String value) {
        this.mutualisationDesEncours = value;
    }

}
