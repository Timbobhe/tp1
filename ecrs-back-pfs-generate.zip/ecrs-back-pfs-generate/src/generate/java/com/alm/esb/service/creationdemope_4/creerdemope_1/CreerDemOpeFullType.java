
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CreerDemOpeFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CreerDemOpeFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}CreerDemOpe" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}CreerDemOpeResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreerDemOpeFullType", propOrder = {
    "creerDemOpe",
    "creerDemOpeResponse"
})
public class CreerDemOpeFullType {

    @XmlElement(name = "CreerDemOpe")
    protected CreerDemOpeType creerDemOpe;
    @XmlElement(name = "CreerDemOpeResponse")
    protected CreerDemOpeResponseType creerDemOpeResponse;

    /**
     * Obtient la valeur de la propriété creerDemOpe.
     * 
     * @return
     *     possible object is
     *     {@link CreerDemOpeType }
     *     
     */
    public CreerDemOpeType getCreerDemOpe() {
        return creerDemOpe;
    }

    /**
     * Définit la valeur de la propriété creerDemOpe.
     * 
     * @param value
     *     allowed object is
     *     {@link CreerDemOpeType }
     *     
     */
    public void setCreerDemOpe(CreerDemOpeType value) {
        this.creerDemOpe = value;
    }

    /**
     * Obtient la valeur de la propriété creerDemOpeResponse.
     * 
     * @return
     *     possible object is
     *     {@link CreerDemOpeResponseType }
     *     
     */
    public CreerDemOpeResponseType getCreerDemOpeResponse() {
        return creerDemOpeResponse;
    }

    /**
     * Définit la valeur de la propriété creerDemOpeResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link CreerDemOpeResponseType }
     *     
     */
    public void setCreerDemOpeResponse(CreerDemOpeResponseType value) {
        this.creerDemOpeResponse = value;
    }

}
