
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SouscripteursType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SouscripteursType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}IdentSiloSouscript" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}SignaletiqueSouscriptPP" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}SignaletiqueSouscriptPM" minOccurs="0"/>
 *         &lt;element name="codeCCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCCN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SouscripteursType", propOrder = {
    "identSiloSouscript",
    "signaletiqueSouscriptPP",
    "signaletiqueSouscriptPM",
    "codeCCN",
    "libCCN"
})
public class SouscripteursType {

    @XmlElement(name = "IdentSiloSouscript")
    protected IdentSiloType identSiloSouscript;
    @XmlElement(name = "SignaletiqueSouscriptPP")
    protected SignaletiquePPType signaletiqueSouscriptPP;
    @XmlElement(name = "SignaletiqueSouscriptPM")
    protected SignaletiquePMType signaletiqueSouscriptPM;
    protected String codeCCN;
    protected String libCCN;

    /**
     * Obtient la valeur de la propriété identSiloSouscript.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloSouscript() {
        return identSiloSouscript;
    }

    /**
     * Définit la valeur de la propriété identSiloSouscript.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloSouscript(IdentSiloType value) {
        this.identSiloSouscript = value;
    }

    /**
     * Obtient la valeur de la propriété signaletiqueSouscriptPP.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiquePPType }
     *     
     */
    public SignaletiquePPType getSignaletiqueSouscriptPP() {
        return signaletiqueSouscriptPP;
    }

    /**
     * Définit la valeur de la propriété signaletiqueSouscriptPP.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiquePPType }
     *     
     */
    public void setSignaletiqueSouscriptPP(SignaletiquePPType value) {
        this.signaletiqueSouscriptPP = value;
    }

    /**
     * Obtient la valeur de la propriété signaletiqueSouscriptPM.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiquePMType }
     *     
     */
    public SignaletiquePMType getSignaletiqueSouscriptPM() {
        return signaletiqueSouscriptPM;
    }

    /**
     * Définit la valeur de la propriété signaletiqueSouscriptPM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiquePMType }
     *     
     */
    public void setSignaletiqueSouscriptPM(SignaletiquePMType value) {
        this.signaletiqueSouscriptPM = value;
    }

    /**
     * Obtient la valeur de la propriété codeCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCCN() {
        return codeCCN;
    }

    /**
     * Définit la valeur de la propriété codeCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCCN(String value) {
        this.codeCCN = value;
    }

    /**
     * Obtient la valeur de la propriété libCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCCN() {
        return libCCN;
    }

    /**
     * Définit la valeur de la propriété libCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCCN(String value) {
        this.libCCN = value;
    }

}
