
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour StructInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="StructInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificationStructInv" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}IdentificationStructInvType"/>
 *         &lt;element name="OccStructInv" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}OccStructInvType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructInvType", propOrder = {
    "identificationStructInv",
    "occStructInv"
})
public class StructInvType {

    @XmlElement(name = "IdentificationStructInv", required = true)
    protected IdentificationStructInvType identificationStructInv;
    @XmlElement(name = "OccStructInv", required = true)
    protected List<OccStructInvType> occStructInv;

    /**
     * Obtient la valeur de la propriété identificationStructInv.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationStructInvType }
     *     
     */
    public IdentificationStructInvType getIdentificationStructInv() {
        return identificationStructInv;
    }

    /**
     * Définit la valeur de la propriété identificationStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationStructInvType }
     *     
     */
    public void setIdentificationStructInv(IdentificationStructInvType value) {
        this.identificationStructInv = value;
    }

    /**
     * Gets the value of the occStructInv property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the occStructInv property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOccStructInv().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OccStructInvType }
     * 
     * 
     */
    public List<OccStructInvType> getOccStructInv() {
        if (occStructInv == null) {
            occStructInv = new ArrayList<OccStructInvType>();
        }
        return this.occStructInv;
    }

}
