
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ParametrageEditionsType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ParametrageEditionsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indPapierDerogeable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ParametresEdition" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}ParametresEditionType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParametrageEditionsType", propOrder = {
    "indPapierDerogeable",
    "parametresEdition"
})
public class ParametrageEditionsType {

    protected Boolean indPapierDerogeable;
    @XmlElement(name = "ParametresEdition")
    protected List<ParametresEditionType> parametresEdition;

    /**
     * Obtient la valeur de la propriété indPapierDerogeable.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndPapierDerogeable() {
        return indPapierDerogeable;
    }

    /**
     * Définit la valeur de la propriété indPapierDerogeable.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndPapierDerogeable(Boolean value) {
        this.indPapierDerogeable = value;
    }

    /**
     * Gets the value of the parametresEdition property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the parametresEdition property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getParametresEdition().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ParametresEditionType }
     * 
     * 
     */
    public List<ParametresEditionType> getParametresEdition() {
        if (parametresEdition == null) {
            parametresEdition = new ArrayList<ParametresEditionType>();
        }
        return this.parametresEdition;
    }

}
