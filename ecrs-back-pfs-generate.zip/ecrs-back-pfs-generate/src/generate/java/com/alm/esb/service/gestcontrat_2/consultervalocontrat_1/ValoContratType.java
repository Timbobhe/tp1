
package com.alm.esb.service.gestcontrat_2.consultervalocontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour ValoContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ValoContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numContrat" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateCalcul" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="epargneContrat" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="epargneContratNette" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="mntBrutVersInitial" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="cumulBrutVersLibres" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="cumulBrutRachats" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="mntAvancesEnCours" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="mntInteretsAvances" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateEffetDernVers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="mntNetDernVers" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateEffetDernRachat" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="mntNetDernRachat" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateEffetDernAvance" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="mntNetDernAvance" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValoContratType", propOrder = {
    "numContrat",
    "dateCalcul",
    "epargneContrat",
    "epargneContratNette",
    "mntBrutVersInitial",
    "cumulBrutVersLibres",
    "cumulBrutRachats",
    "mntAvancesEnCours",
    "mntInteretsAvances",
    "dateEffetDernVers",
    "mntNetDernVers",
    "dateEffetDernRachat",
    "mntNetDernRachat",
    "dateEffetDernAvance",
    "mntNetDernAvance"
})
public class ValoContratType {

    @XmlElement(required = true)
    protected String numContrat;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateCalcul;
    protected BigDecimal epargneContrat;
    protected BigDecimal epargneContratNette;
    protected BigDecimal mntBrutVersInitial;
    protected BigDecimal cumulBrutVersLibres;
    protected BigDecimal cumulBrutRachats;
    protected BigDecimal mntAvancesEnCours;
    protected BigDecimal mntInteretsAvances;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetDernVers;
    protected BigDecimal mntNetDernVers;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetDernRachat;
    protected BigDecimal mntNetDernRachat;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetDernAvance;
    protected BigDecimal mntNetDernAvance;

    /**
     * Obtient la valeur de la propriété numContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumContrat() {
        return numContrat;
    }

    /**
     * Définit la valeur de la propriété numContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumContrat(String value) {
        this.numContrat = value;
    }

    /**
     * Obtient la valeur de la propriété dateCalcul.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateCalcul() {
        return dateCalcul;
    }

    /**
     * Définit la valeur de la propriété dateCalcul.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateCalcul(XMLGregorianCalendar value) {
        this.dateCalcul = value;
    }

    /**
     * Obtient la valeur de la propriété epargneContrat.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEpargneContrat() {
        return epargneContrat;
    }

    /**
     * Définit la valeur de la propriété epargneContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEpargneContrat(BigDecimal value) {
        this.epargneContrat = value;
    }

    /**
     * Obtient la valeur de la propriété epargneContratNette.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getEpargneContratNette() {
        return epargneContratNette;
    }

    /**
     * Définit la valeur de la propriété epargneContratNette.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setEpargneContratNette(BigDecimal value) {
        this.epargneContratNette = value;
    }

    /**
     * Obtient la valeur de la propriété mntBrutVersInitial.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntBrutVersInitial() {
        return mntBrutVersInitial;
    }

    /**
     * Définit la valeur de la propriété mntBrutVersInitial.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntBrutVersInitial(BigDecimal value) {
        this.mntBrutVersInitial = value;
    }

    /**
     * Obtient la valeur de la propriété cumulBrutVersLibres.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCumulBrutVersLibres() {
        return cumulBrutVersLibres;
    }

    /**
     * Définit la valeur de la propriété cumulBrutVersLibres.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCumulBrutVersLibres(BigDecimal value) {
        this.cumulBrutVersLibres = value;
    }

    /**
     * Obtient la valeur de la propriété cumulBrutRachats.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getCumulBrutRachats() {
        return cumulBrutRachats;
    }

    /**
     * Définit la valeur de la propriété cumulBrutRachats.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setCumulBrutRachats(BigDecimal value) {
        this.cumulBrutRachats = value;
    }

    /**
     * Obtient la valeur de la propriété mntAvancesEnCours.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntAvancesEnCours() {
        return mntAvancesEnCours;
    }

    /**
     * Définit la valeur de la propriété mntAvancesEnCours.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntAvancesEnCours(BigDecimal value) {
        this.mntAvancesEnCours = value;
    }

    /**
     * Obtient la valeur de la propriété mntInteretsAvances.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntInteretsAvances() {
        return mntInteretsAvances;
    }

    /**
     * Définit la valeur de la propriété mntInteretsAvances.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntInteretsAvances(BigDecimal value) {
        this.mntInteretsAvances = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetDernVers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetDernVers() {
        return dateEffetDernVers;
    }

    /**
     * Définit la valeur de la propriété dateEffetDernVers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetDernVers(XMLGregorianCalendar value) {
        this.dateEffetDernVers = value;
    }

    /**
     * Obtient la valeur de la propriété mntNetDernVers.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntNetDernVers() {
        return mntNetDernVers;
    }

    /**
     * Définit la valeur de la propriété mntNetDernVers.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntNetDernVers(BigDecimal value) {
        this.mntNetDernVers = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetDernRachat.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetDernRachat() {
        return dateEffetDernRachat;
    }

    /**
     * Définit la valeur de la propriété dateEffetDernRachat.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetDernRachat(XMLGregorianCalendar value) {
        this.dateEffetDernRachat = value;
    }

    /**
     * Obtient la valeur de la propriété mntNetDernRachat.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntNetDernRachat() {
        return mntNetDernRachat;
    }

    /**
     * Définit la valeur de la propriété mntNetDernRachat.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntNetDernRachat(BigDecimal value) {
        this.mntNetDernRachat = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetDernAvance.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetDernAvance() {
        return dateEffetDernAvance;
    }

    /**
     * Définit la valeur de la propriété dateEffetDernAvance.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetDernAvance(XMLGregorianCalendar value) {
        this.dateEffetDernAvance = value;
    }

    /**
     * Obtient la valeur de la propriété mntNetDernAvance.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntNetDernAvance() {
        return mntNetDernAvance;
    }

    /**
     * Définit la valeur de la propriété mntNetDernAvance.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntNetDernAvance(BigDecimal value) {
        this.mntNetDernAvance = value;
    }

}
