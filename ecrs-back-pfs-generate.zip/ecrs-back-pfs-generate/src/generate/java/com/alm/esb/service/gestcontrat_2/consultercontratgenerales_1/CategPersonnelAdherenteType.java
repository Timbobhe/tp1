
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour CategPersonnelAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CategPersonnelAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCategPersSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffetCategPers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="libSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCategPersSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitCategPers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CategPersonnelAdherenteType", propOrder = {
    "idCategPers",
    "codeCategPers",
    "libCategPers",
    "codeSitCategPers",
    "codeSitCategPersSilo",
    "dateEffetCategPers",
    "libSitCategPers",
    "libSitCategPersSilo",
    "dateSitCategPers"
})
public class CategPersonnelAdherenteType {

    protected String idCategPers;
    protected String codeCategPers;
    protected String libCategPers;
    protected String codeSitCategPers;
    protected String codeSitCategPersSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetCategPers;
    protected String libSitCategPers;
    protected String libSitCategPersSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitCategPers;

    /**
     * Obtient la valeur de la propriété idCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCategPers() {
        return idCategPers;
    }

    /**
     * Définit la valeur de la propriété idCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCategPers(String value) {
        this.idCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCategPers() {
        return codeCategPers;
    }

    /**
     * Définit la valeur de la propriété codeCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCategPers(String value) {
        this.codeCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCategPers() {
        return libCategPers;
    }

    /**
     * Définit la valeur de la propriété libCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCategPers(String value) {
        this.libCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCategPers() {
        return codeSitCategPers;
    }

    /**
     * Définit la valeur de la propriété codeSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCategPers(String value) {
        this.codeSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCategPersSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCategPersSilo() {
        return codeSitCategPersSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitCategPersSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCategPersSilo(String value) {
        this.codeSitCategPersSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetCategPers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetCategPers() {
        return dateEffetCategPers;
    }

    /**
     * Définit la valeur de la propriété dateEffetCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetCategPers(XMLGregorianCalendar value) {
        this.dateEffetCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCategPers() {
        return libSitCategPers;
    }

    /**
     * Définit la valeur de la propriété libSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCategPers(String value) {
        this.libSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCategPersSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCategPersSilo() {
        return libSitCategPersSilo;
    }

    /**
     * Définit la valeur de la propriété libSitCategPersSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCategPersSilo(String value) {
        this.libSitCategPersSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitCategPers() {
        return dateSitCategPers;
    }

    /**
     * Définit la valeur de la propriété dateSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitCategPers(XMLGregorianCalendar value) {
        this.dateSitCategPers = value;
    }

}
