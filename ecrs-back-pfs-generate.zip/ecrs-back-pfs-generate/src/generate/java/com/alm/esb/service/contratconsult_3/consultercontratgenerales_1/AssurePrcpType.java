
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AssurePrcpType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AssurePrcpType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloAssurePrcp" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdSiloSouscType" minOccurs="0"/>
 *         &lt;element name="SignqPPAssurePrcp" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqSouscPPType" minOccurs="0"/>
 *         &lt;element name="DetPP" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DetPPType" minOccurs="0"/>
 *         &lt;element name="AutreNatio" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AutreNatioType" minOccurs="0"/>
 *         &lt;element name="DossCom" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DossComType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssurePrcpType", propOrder = {
    "identSiloAssurePrcp",
    "signqPPAssurePrcp",
    "detPP",
    "autreNatio",
    "dossCom"
})
public class AssurePrcpType {

    @XmlElement(name = "IdentSiloAssurePrcp")
    protected IdSiloSouscType identSiloAssurePrcp;
    @XmlElement(name = "SignqPPAssurePrcp")
    protected SignqSouscPPType signqPPAssurePrcp;
    @XmlElement(name = "DetPP")
    protected DetPPType detPP;
    @XmlElement(name = "AutreNatio")
    protected AutreNatioType autreNatio;
    @XmlElement(name = "DossCom")
    protected DossComType dossCom;

    /**
     * Obtient la valeur de la propriété identSiloAssurePrcp.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloSouscType }
     *     
     */
    public IdSiloSouscType getIdentSiloAssurePrcp() {
        return identSiloAssurePrcp;
    }

    /**
     * Définit la valeur de la propriété identSiloAssurePrcp.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloSouscType }
     *     
     */
    public void setIdentSiloAssurePrcp(IdSiloSouscType value) {
        this.identSiloAssurePrcp = value;
    }

    /**
     * Obtient la valeur de la propriété signqPPAssurePrcp.
     * 
     * @return
     *     possible object is
     *     {@link SignqSouscPPType }
     *     
     */
    public SignqSouscPPType getSignqPPAssurePrcp() {
        return signqPPAssurePrcp;
    }

    /**
     * Définit la valeur de la propriété signqPPAssurePrcp.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqSouscPPType }
     *     
     */
    public void setSignqPPAssurePrcp(SignqSouscPPType value) {
        this.signqPPAssurePrcp = value;
    }

    /**
     * Obtient la valeur de la propriété detPP.
     * 
     * @return
     *     possible object is
     *     {@link DetPPType }
     *     
     */
    public DetPPType getDetPP() {
        return detPP;
    }

    /**
     * Définit la valeur de la propriété detPP.
     * 
     * @param value
     *     allowed object is
     *     {@link DetPPType }
     *     
     */
    public void setDetPP(DetPPType value) {
        this.detPP = value;
    }

    /**
     * Obtient la valeur de la propriété autreNatio.
     * 
     * @return
     *     possible object is
     *     {@link AutreNatioType }
     *     
     */
    public AutreNatioType getAutreNatio() {
        return autreNatio;
    }

    /**
     * Définit la valeur de la propriété autreNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link AutreNatioType }
     *     
     */
    public void setAutreNatio(AutreNatioType value) {
        this.autreNatio = value;
    }

    /**
     * Obtient la valeur de la propriété dossCom.
     * 
     * @return
     *     possible object is
     *     {@link DossComType }
     *     
     */
    public DossComType getDossCom() {
        return dossCom;
    }

    /**
     * Définit la valeur de la propriété dossCom.
     * 
     * @param value
     *     allowed object is
     *     {@link DossComType }
     *     
     */
    public void setDossCom(DossComType value) {
        this.dossCom = value;
    }

}
