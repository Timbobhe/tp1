
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SouscripteurType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SouscripteurType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeCCN" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libCCN" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeCCNInt" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libCCNInt" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SouscripteurType", propOrder = {
    "codeCCN",
    "libCCN",
    "codeCCNInt",
    "libCCNInt"
})
public class SouscripteurType {

    protected String codeCCN;
    protected String libCCN;
    protected String codeCCNInt;
    protected String libCCNInt;

    /**
     * Obtient la valeur de la propriété codeCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCCN() {
        return codeCCN;
    }

    /**
     * Définit la valeur de la propriété codeCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCCN(String value) {
        this.codeCCN = value;
    }

    /**
     * Obtient la valeur de la propriété libCCN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCCN() {
        return libCCN;
    }

    /**
     * Définit la valeur de la propriété libCCN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCCN(String value) {
        this.libCCN = value;
    }

    /**
     * Obtient la valeur de la propriété codeCCNInt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCCNInt() {
        return codeCCNInt;
    }

    /**
     * Définit la valeur de la propriété codeCCNInt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCCNInt(String value) {
        this.codeCCNInt = value;
    }

    /**
     * Obtient la valeur de la propriété libCCNInt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCCNInt() {
        return libCCNInt;
    }

    /**
     * Définit la valeur de la propriété libCCNInt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCCNInt(String value) {
        this.libCCNInt = value;
    }

}
