
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratPereType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratPereType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentsPere" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratPereType", propOrder = {
    "identsPere"
})
public class IdentContratPereType {

    @XmlElement(name = "IdentsPere", required = true)
    protected List<IdentsPereType> identsPere;

    /**
     * Gets the value of the identsPere property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identsPere property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentsPere().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentsPereType }
     * 
     * 
     */
    public List<IdentsPereType> getIdentsPere() {
        if (identsPere == null) {
            identsPere = new ArrayList<IdentsPereType>();
        }
        return this.identsPere;
    }

}
