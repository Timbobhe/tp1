
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour AdhesionType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AdhesionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAdhesion" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="dateEffetAdhesion" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitAdhesion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitAdhesion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitAdhesionSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitAdhesionSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitAdhesion" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}IdentSiloAdherente" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}SignaletiqueAdherentePM" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ContratAdherente" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdhesionType", propOrder = {
    "idAdhesion",
    "dateEffetAdhesion",
    "codeSitAdhesion",
    "libSitAdhesion",
    "codeSitAdhesionSilo",
    "libSitAdhesionSilo",
    "dateSitAdhesion",
    "identSiloAdherente",
    "signaletiqueAdherentePM",
    "contratAdherente"
})
public class AdhesionType {

    @XmlElement(required = true)
    protected String idAdhesion;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetAdhesion;
    protected String codeSitAdhesion;
    protected String libSitAdhesion;
    protected String codeSitAdhesionSilo;
    protected String libSitAdhesionSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitAdhesion;
    @XmlElement(name = "IdentSiloAdherente")
    protected IdentSiloType identSiloAdherente;
    @XmlElement(name = "SignaletiqueAdherentePM")
    protected SignaletiqueAdherentePMType signaletiqueAdherentePM;
    @XmlElement(name = "ContratAdherente")
    protected ContratAdherenteType contratAdherente;

    /**
     * Obtient la valeur de la propriété idAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAdhesion() {
        return idAdhesion;
    }

    /**
     * Définit la valeur de la propriété idAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAdhesion(String value) {
        this.idAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetAdhesion() {
        return dateEffetAdhesion;
    }

    /**
     * Définit la valeur de la propriété dateEffetAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetAdhesion(XMLGregorianCalendar value) {
        this.dateEffetAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitAdhesion() {
        return codeSitAdhesion;
    }

    /**
     * Définit la valeur de la propriété codeSitAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitAdhesion(String value) {
        this.codeSitAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété libSitAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitAdhesion() {
        return libSitAdhesion;
    }

    /**
     * Définit la valeur de la propriété libSitAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitAdhesion(String value) {
        this.libSitAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitAdhesionSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitAdhesionSilo() {
        return codeSitAdhesionSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitAdhesionSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitAdhesionSilo(String value) {
        this.codeSitAdhesionSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libSitAdhesionSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitAdhesionSilo() {
        return libSitAdhesionSilo;
    }

    /**
     * Définit la valeur de la propriété libSitAdhesionSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitAdhesionSilo(String value) {
        this.libSitAdhesionSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitAdhesion() {
        return dateSitAdhesion;
    }

    /**
     * Définit la valeur de la propriété dateSitAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitAdhesion(XMLGregorianCalendar value) {
        this.dateSitAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété identSiloAdherente.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloAdherente() {
        return identSiloAdherente;
    }

    /**
     * Définit la valeur de la propriété identSiloAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloAdherente(IdentSiloType value) {
        this.identSiloAdherente = value;
    }

    /**
     * Obtient la valeur de la propriété signaletiqueAdherentePM.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiqueAdherentePMType }
     *     
     */
    public SignaletiqueAdherentePMType getSignaletiqueAdherentePM() {
        return signaletiqueAdherentePM;
    }

    /**
     * Définit la valeur de la propriété signaletiqueAdherentePM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiqueAdherentePMType }
     *     
     */
    public void setSignaletiqueAdherentePM(SignaletiqueAdherentePMType value) {
        this.signaletiqueAdherentePM = value;
    }

    /**
     * Obtient la valeur de la propriété contratAdherente.
     * 
     * @return
     *     possible object is
     *     {@link ContratAdherenteType }
     *     
     */
    public ContratAdherenteType getContratAdherente() {
        return contratAdherente;
    }

    /**
     * Définit la valeur de la propriété contratAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratAdherenteType }
     *     
     */
    public void setContratAdherente(ContratAdherenteType value) {
        this.contratAdherente = value;
    }

}
