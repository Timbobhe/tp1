
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour GarSouscritesType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GarSouscritesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indPriseEnChrgAytDrt" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="DetGar" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DetGarType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GarSouscritesType", propOrder = {
    "indPriseEnChrgAytDrt",
    "detGar"
})
public class GarSouscritesType {

    protected Boolean indPriseEnChrgAytDrt;
    @XmlElement(name = "DetGar")
    protected DetGarType detGar;

    /**
     * Obtient la valeur de la propriété indPriseEnChrgAytDrt.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndPriseEnChrgAytDrt() {
        return indPriseEnChrgAytDrt;
    }

    /**
     * Définit la valeur de la propriété indPriseEnChrgAytDrt.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndPriseEnChrgAytDrt(Boolean value) {
        this.indPriseEnChrgAytDrt = value;
    }

    /**
     * Obtient la valeur de la propriété detGar.
     * 
     * @return
     *     possible object is
     *     {@link DetGarType }
     *     
     */
    public DetGarType getDetGar() {
        return detGar;
    }

    /**
     * Définit la valeur de la propriété detGar.
     * 
     * @param value
     *     allowed object is
     *     {@link DetGarType }
     *     
     */
    public void setDetGar(DetGarType value) {
        this.detGar = value;
    }

}
