
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AdhesionType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AdhesionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="identSiloAdherente" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}IdentificationType"/>
 *         &lt;element name="SignalAdherentePM" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SignalAdherentePMType" minOccurs="0"/>
 *         &lt;element name="codeSituationAdhesion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSituationAdhesion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdhesionType", propOrder = {
    "identSiloAdherente",
    "signalAdherentePM",
    "codeSituationAdhesion",
    "libSituationAdhesion"
})
public class AdhesionType {

    @XmlElement(required = true)
    protected IdentificationType identSiloAdherente;
    @XmlElement(name = "SignalAdherentePM")
    protected SignalAdherentePMType signalAdherentePM;
    protected String codeSituationAdhesion;
    protected String libSituationAdhesion;

    /**
     * Obtient la valeur de la propriété identSiloAdherente.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getIdentSiloAdherente() {
        return identSiloAdherente;
    }

    /**
     * Définit la valeur de la propriété identSiloAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setIdentSiloAdherente(IdentificationType value) {
        this.identSiloAdherente = value;
    }

    /**
     * Obtient la valeur de la propriété signalAdherentePM.
     * 
     * @return
     *     possible object is
     *     {@link SignalAdherentePMType }
     *     
     */
    public SignalAdherentePMType getSignalAdherentePM() {
        return signalAdherentePM;
    }

    /**
     * Définit la valeur de la propriété signalAdherentePM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignalAdherentePMType }
     *     
     */
    public void setSignalAdherentePM(SignalAdherentePMType value) {
        this.signalAdherentePM = value;
    }

    /**
     * Obtient la valeur de la propriété codeSituationAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSituationAdhesion() {
        return codeSituationAdhesion;
    }

    /**
     * Définit la valeur de la propriété codeSituationAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSituationAdhesion(String value) {
        this.codeSituationAdhesion = value;
    }

    /**
     * Obtient la valeur de la propriété libSituationAdhesion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSituationAdhesion() {
        return libSituationAdhesion;
    }

    /**
     * Définit la valeur de la propriété libSituationAdhesion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSituationAdhesion(String value) {
        this.libSituationAdhesion = value;
    }

}
