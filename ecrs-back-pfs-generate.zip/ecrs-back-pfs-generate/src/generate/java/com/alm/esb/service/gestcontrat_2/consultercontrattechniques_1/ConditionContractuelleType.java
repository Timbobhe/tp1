
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConditionContractuelleType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConditionContractuelleType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ageLegalDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMinDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMaxDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="txFraisSurRevalorisationRente" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="txRendementMinGaranti" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConditionContractuelleType", propOrder = {
    "ageLegalDepartRetraite",
    "ageMinDepartRetraite",
    "ageMaxDepartRetraite",
    "txFraisSurRevalorisationRente",
    "txRendementMinGaranti"
})
public class ConditionContractuelleType {

    protected BigInteger ageLegalDepartRetraite;
    protected BigInteger ageMinDepartRetraite;
    protected BigInteger ageMaxDepartRetraite;
    protected BigDecimal txFraisSurRevalorisationRente;
    protected BigDecimal txRendementMinGaranti;

    /**
     * Obtient la valeur de la propriété ageLegalDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeLegalDepartRetraite() {
        return ageLegalDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageLegalDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeLegalDepartRetraite(BigInteger value) {
        this.ageLegalDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété ageMinDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMinDepartRetraite() {
        return ageMinDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageMinDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMinDepartRetraite(BigInteger value) {
        this.ageMinDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété ageMaxDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMaxDepartRetraite() {
        return ageMaxDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageMaxDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMaxDepartRetraite(BigInteger value) {
        this.ageMaxDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété txFraisSurRevalorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurRevalorisationRente() {
        return txFraisSurRevalorisationRente;
    }

    /**
     * Définit la valeur de la propriété txFraisSurRevalorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurRevalorisationRente(BigDecimal value) {
        this.txFraisSurRevalorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété txRendementMinGaranti.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRendementMinGaranti() {
        return txRendementMinGaranti;
    }

    /**
     * Définit la valeur de la propriété txRendementMinGaranti.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRendementMinGaranti(BigDecimal value) {
        this.txRendementMinGaranti = value;
    }

}
