
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentificationDansSiloType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentificationDansSiloType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idDansSilo" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}idDansSiloType"/>
 *         &lt;element name="codeApplication" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSystemeInformation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificationDansSiloType", propOrder = {
    "idDansSilo",
    "codeApplication",
    "codeSystemeInformation"
})
public class IdentificationDansSiloType {

    @XmlElement(required = true)
    protected IdDansSiloType idDansSilo;
    protected String codeApplication;
    protected String codeSystemeInformation;

    /**
     * Obtient la valeur de la propriété idDansSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdDansSiloType }
     *     
     */
    public IdDansSiloType getIdDansSilo() {
        return idDansSilo;
    }

    /**
     * Définit la valeur de la propriété idDansSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdDansSiloType }
     *     
     */
    public void setIdDansSilo(IdDansSiloType value) {
        this.idDansSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeApplication.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeApplication() {
        return codeApplication;
    }

    /**
     * Définit la valeur de la propriété codeApplication.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeApplication(String value) {
        this.codeApplication = value;
    }

    /**
     * Obtient la valeur de la propriété codeSystemeInformation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSystemeInformation() {
        return codeSystemeInformation;
    }

    /**
     * Définit la valeur de la propriété codeSystemeInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSystemeInformation(String value) {
        this.codeSystemeInformation = value;
    }

}
