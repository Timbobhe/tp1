
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour EchrPaimtPrimeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="EchrPaimtPrimeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codePeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriod" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codePeriodSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriodiciteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEchPaiementCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEchPaiementCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEchPaiementCotisSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEchPaiementCotisSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mntPrimeFractTTC" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeMoyenPaimt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libMoyenPaimt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeDevise" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CoordonneesBanc" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CoordonneesBancType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EchrPaimtPrimeType", propOrder = {
    "codePeriod",
    "libPeriod",
    "codePeriodSilo",
    "libPeriodiciteSilo",
    "codeEchPaiementCotis",
    "libEchPaiementCotis",
    "codeEchPaiementCotisSilo",
    "libEchPaiementCotisSilo",
    "mntPrimeFractTTC",
    "codeMoyenPaimt",
    "libMoyenPaimt",
    "codeDevise",
    "coordonneesBanc"
})
public class EchrPaimtPrimeType {

    protected String codePeriod;
    protected String libPeriod;
    protected String codePeriodSilo;
    protected String libPeriodiciteSilo;
    protected String codeEchPaiementCotis;
    protected String libEchPaiementCotis;
    protected String codeEchPaiementCotisSilo;
    protected String libEchPaiementCotisSilo;
    protected BigDecimal mntPrimeFractTTC;
    protected String codeMoyenPaimt;
    protected String libMoyenPaimt;
    protected String codeDevise;
    @XmlElement(name = "CoordonneesBanc")
    protected CoordonneesBancType coordonneesBanc;

    /**
     * Obtient la valeur de la propriété codePeriod.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriod() {
        return codePeriod;
    }

    /**
     * Définit la valeur de la propriété codePeriod.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriod(String value) {
        this.codePeriod = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriod.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriod() {
        return libPeriod;
    }

    /**
     * Définit la valeur de la propriété libPeriod.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriod(String value) {
        this.libPeriod = value;
    }

    /**
     * Obtient la valeur de la propriété codePeriodSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodSilo() {
        return codePeriodSilo;
    }

    /**
     * Définit la valeur de la propriété codePeriodSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodSilo(String value) {
        this.codePeriodSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriodiciteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriodiciteSilo() {
        return libPeriodiciteSilo;
    }

    /**
     * Définit la valeur de la propriété libPeriodiciteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriodiciteSilo(String value) {
        this.libPeriodiciteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeEchPaiementCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEchPaiementCotis() {
        return codeEchPaiementCotis;
    }

    /**
     * Définit la valeur de la propriété codeEchPaiementCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEchPaiementCotis(String value) {
        this.codeEchPaiementCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libEchPaiementCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEchPaiementCotis() {
        return libEchPaiementCotis;
    }

    /**
     * Définit la valeur de la propriété libEchPaiementCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEchPaiementCotis(String value) {
        this.libEchPaiementCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeEchPaiementCotisSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEchPaiementCotisSilo() {
        return codeEchPaiementCotisSilo;
    }

    /**
     * Définit la valeur de la propriété codeEchPaiementCotisSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEchPaiementCotisSilo(String value) {
        this.codeEchPaiementCotisSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libEchPaiementCotisSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEchPaiementCotisSilo() {
        return libEchPaiementCotisSilo;
    }

    /**
     * Définit la valeur de la propriété libEchPaiementCotisSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEchPaiementCotisSilo(String value) {
        this.libEchPaiementCotisSilo = value;
    }

    /**
     * Obtient la valeur de la propriété mntPrimeFractTTC.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntPrimeFractTTC() {
        return mntPrimeFractTTC;
    }

    /**
     * Définit la valeur de la propriété mntPrimeFractTTC.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntPrimeFractTTC(BigDecimal value) {
        this.mntPrimeFractTTC = value;
    }

    /**
     * Obtient la valeur de la propriété codeMoyenPaimt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMoyenPaimt() {
        return codeMoyenPaimt;
    }

    /**
     * Définit la valeur de la propriété codeMoyenPaimt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMoyenPaimt(String value) {
        this.codeMoyenPaimt = value;
    }

    /**
     * Obtient la valeur de la propriété libMoyenPaimt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibMoyenPaimt() {
        return libMoyenPaimt;
    }

    /**
     * Définit la valeur de la propriété libMoyenPaimt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibMoyenPaimt(String value) {
        this.libMoyenPaimt = value;
    }

    /**
     * Obtient la valeur de la propriété codeDevise.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDevise() {
        return codeDevise;
    }

    /**
     * Définit la valeur de la propriété codeDevise.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDevise(String value) {
        this.codeDevise = value;
    }

    /**
     * Obtient la valeur de la propriété coordonneesBanc.
     * 
     * @return
     *     possible object is
     *     {@link CoordonneesBancType }
     *     
     */
    public CoordonneesBancType getCoordonneesBanc() {
        return coordonneesBanc;
    }

    /**
     * Définit la valeur de la propriété coordonneesBanc.
     * 
     * @param value
     *     allowed object is
     *     {@link CoordonneesBancType }
     *     
     */
    public void setCoordonneesBanc(CoordonneesBancType value) {
        this.coordonneesBanc = value;
    }

}
