
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentCtrAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentCtrAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentSiloContratType" minOccurs="0"/>
 *         &lt;element name="IdentCtrPere" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentContratPereType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentCtrAdherenteType", propOrder = {
    "identSiloCtr",
    "identCtrPere"
})
public class IdentCtrAdherenteType {

    @XmlElement(name = "IdentSiloCtr")
    protected IdentSiloContratType identSiloCtr;
    @XmlElement(name = "IdentCtrPere")
    protected IdentContratPereType identCtrPere;

    /**
     * Obtient la valeur de la propriété identSiloCtr.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloContratType }
     *     
     */
    public IdentSiloContratType getIdentSiloCtr() {
        return identSiloCtr;
    }

    /**
     * Définit la valeur de la propriété identSiloCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloContratType }
     *     
     */
    public void setIdentSiloCtr(IdentSiloContratType value) {
        this.identSiloCtr = value;
    }

    /**
     * Obtient la valeur de la propriété identCtrPere.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratPereType }
     *     
     */
    public IdentContratPereType getIdentCtrPere() {
        return identCtrPere;
    }

    /**
     * Définit la valeur de la propriété identCtrPere.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratPereType }
     *     
     */
    public void setIdentCtrPere(IdentContratPereType value) {
        this.identCtrPere = value;
    }

}
