
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_4;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour PersClienteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PersClienteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSilo" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}IdentSiloType" minOccurs="0"/>
 *         &lt;element name="ContratPers" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}ContratPersType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PersClienteType", propOrder = {
    "identSilo",
    "contratPers"
})
public class PersClienteType {

    @XmlElement(name = "IdentSilo")
    protected IdentSiloType identSilo;
    @XmlElement(name = "ContratPers")
    protected List<ContratPersType> contratPers;

    /**
     * Obtient la valeur de la propriété identSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSilo() {
        return identSilo;
    }

    /**
     * Définit la valeur de la propriété identSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSilo(IdentSiloType value) {
        this.identSilo = value;
    }

    /**
     * Gets the value of the contratPers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the contratPers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getContratPers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ContratPersType }
     * 
     * 
     */
    public List<ContratPersType> getContratPers() {
        if (contratPers == null) {
            contratPers = new ArrayList<ContratPersType>();
        }
        return this.contratPers;
    }

}
