
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}IdentContrat"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}InfoContrat"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}Souscripteurs" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}OfrCialSousc" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}EcheancierPaiementPrime" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ActeurContrat" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}OptContratEpargne" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}Rib" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ContratColl" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ContratIndividuel" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}TrsfCtr" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}StructOrga" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ActivitePartnrt" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}Cotis" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratType", propOrder = {
    "identContrat",
    "infoContrat",
    "souscripteurs",
    "ofrCialSousc",
    "echeancierPaiementPrime",
    "acteurContrat",
    "optContratEpargne",
    "rib",
    "contratColl",
    "contratIndividuel",
    "trsfCtr",
    "structOrga",
    "activitePartnrt",
    "cotis"
})
public class ContratType {

    @XmlElement(name = "IdentContrat", required = true)
    protected IdentContratType identContrat;
    @XmlElement(name = "InfoContrat", required = true)
    protected InfoContratType infoContrat;
    @XmlElement(name = "Souscripteurs")
    protected List<SouscripteursType> souscripteurs;
    @XmlElement(name = "OfrCialSousc")
    protected OfrCialSouscType ofrCialSousc;
    @XmlElement(name = "EcheancierPaiementPrime")
    protected EcheancierPaiementPrimeType echeancierPaiementPrime;
    @XmlElement(name = "ActeurContrat")
    protected List<ActeurContratType> acteurContrat;
    @XmlElement(name = "OptContratEpargne")
    protected OptContratEpargneType optContratEpargne;
    @XmlElement(name = "Rib")
    protected RibType rib;
    @XmlElement(name = "ContratColl")
    protected ContratCollType contratColl;
    @XmlElement(name = "ContratIndividuel")
    protected ContratIndividuelType contratIndividuel;
    @XmlElement(name = "TrsfCtr")
    protected List<TrsfCtrType> trsfCtr;
    @XmlElement(name = "StructOrga")
    protected List<StructOrgaType> structOrga;
    @XmlElement(name = "ActivitePartnrt")
    protected List<ActivitePartnrtType> activitePartnrt;
    @XmlElement(name = "Cotis")
    protected List<CotisType> cotis;

    /**
     * Obtient la valeur de la propriété identContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratType }
     *     
     */
    public IdentContratType getIdentContrat() {
        return identContrat;
    }

    /**
     * Définit la valeur de la propriété identContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratType }
     *     
     */
    public void setIdentContrat(IdentContratType value) {
        this.identContrat = value;
    }

    /**
     * Obtient la valeur de la propriété infoContrat.
     * 
     * @return
     *     possible object is
     *     {@link InfoContratType }
     *     
     */
    public InfoContratType getInfoContrat() {
        return infoContrat;
    }

    /**
     * Définit la valeur de la propriété infoContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoContratType }
     *     
     */
    public void setInfoContrat(InfoContratType value) {
        this.infoContrat = value;
    }

    /**
     * Gets the value of the souscripteurs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the souscripteurs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSouscripteurs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SouscripteursType }
     * 
     * 
     */
    public List<SouscripteursType> getSouscripteurs() {
        if (souscripteurs == null) {
            souscripteurs = new ArrayList<SouscripteursType>();
        }
        return this.souscripteurs;
    }

    /**
     * Obtient la valeur de la propriété ofrCialSousc.
     * 
     * @return
     *     possible object is
     *     {@link OfrCialSouscType }
     *     
     */
    public OfrCialSouscType getOfrCialSousc() {
        return ofrCialSousc;
    }

    /**
     * Définit la valeur de la propriété ofrCialSousc.
     * 
     * @param value
     *     allowed object is
     *     {@link OfrCialSouscType }
     *     
     */
    public void setOfrCialSousc(OfrCialSouscType value) {
        this.ofrCialSousc = value;
    }

    /**
     * Obtient la valeur de la propriété echeancierPaiementPrime.
     * 
     * @return
     *     possible object is
     *     {@link EcheancierPaiementPrimeType }
     *     
     */
    public EcheancierPaiementPrimeType getEcheancierPaiementPrime() {
        return echeancierPaiementPrime;
    }

    /**
     * Définit la valeur de la propriété echeancierPaiementPrime.
     * 
     * @param value
     *     allowed object is
     *     {@link EcheancierPaiementPrimeType }
     *     
     */
    public void setEcheancierPaiementPrime(EcheancierPaiementPrimeType value) {
        this.echeancierPaiementPrime = value;
    }

    /**
     * Gets the value of the acteurContrat property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the acteurContrat property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActeurContrat().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActeurContratType }
     * 
     * 
     */
    public List<ActeurContratType> getActeurContrat() {
        if (acteurContrat == null) {
            acteurContrat = new ArrayList<ActeurContratType>();
        }
        return this.acteurContrat;
    }

    /**
     * Obtient la valeur de la propriété optContratEpargne.
     * 
     * @return
     *     possible object is
     *     {@link OptContratEpargneType }
     *     
     */
    public OptContratEpargneType getOptContratEpargne() {
        return optContratEpargne;
    }

    /**
     * Définit la valeur de la propriété optContratEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link OptContratEpargneType }
     *     
     */
    public void setOptContratEpargne(OptContratEpargneType value) {
        this.optContratEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété rib.
     * 
     * @return
     *     possible object is
     *     {@link RibType }
     *     
     */
    public RibType getRib() {
        return rib;
    }

    /**
     * Définit la valeur de la propriété rib.
     * 
     * @param value
     *     allowed object is
     *     {@link RibType }
     *     
     */
    public void setRib(RibType value) {
        this.rib = value;
    }

    /**
     * Obtient la valeur de la propriété contratColl.
     * 
     * @return
     *     possible object is
     *     {@link ContratCollType }
     *     
     */
    public ContratCollType getContratColl() {
        return contratColl;
    }

    /**
     * Définit la valeur de la propriété contratColl.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratCollType }
     *     
     */
    public void setContratColl(ContratCollType value) {
        this.contratColl = value;
    }

    /**
     * Obtient la valeur de la propriété contratIndividuel.
     * 
     * @return
     *     possible object is
     *     {@link ContratIndividuelType }
     *     
     */
    public ContratIndividuelType getContratIndividuel() {
        return contratIndividuel;
    }

    /**
     * Définit la valeur de la propriété contratIndividuel.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratIndividuelType }
     *     
     */
    public void setContratIndividuel(ContratIndividuelType value) {
        this.contratIndividuel = value;
    }

    /**
     * Gets the value of the trsfCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trsfCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrsfCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TrsfCtrType }
     * 
     * 
     */
    public List<TrsfCtrType> getTrsfCtr() {
        if (trsfCtr == null) {
            trsfCtr = new ArrayList<TrsfCtrType>();
        }
        return this.trsfCtr;
    }

    /**
     * Gets the value of the structOrga property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the structOrga property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStructOrga().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StructOrgaType }
     * 
     * 
     */
    public List<StructOrgaType> getStructOrga() {
        if (structOrga == null) {
            structOrga = new ArrayList<StructOrgaType>();
        }
        return this.structOrga;
    }

    /**
     * Gets the value of the activitePartnrt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the activitePartnrt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActivitePartnrt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActivitePartnrtType }
     * 
     * 
     */
    public List<ActivitePartnrtType> getActivitePartnrt() {
        if (activitePartnrt == null) {
            activitePartnrt = new ArrayList<ActivitePartnrtType>();
        }
        return this.activitePartnrt;
    }

    /**
     * Gets the value of the cotis property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cotis property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCotis().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CotisType }
     * 
     * 
     */
    public List<CotisType> getCotis() {
        if (cotis == null) {
            cotis = new ArrayList<CotisType>();
        }
        return this.cotis;
    }

}
