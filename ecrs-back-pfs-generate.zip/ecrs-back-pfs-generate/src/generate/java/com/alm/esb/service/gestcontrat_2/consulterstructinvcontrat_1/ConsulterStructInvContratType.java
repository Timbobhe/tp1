
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterStructInvContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterStructInvContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificationDansSilo" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}IdentificationDansSiloType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterStructInvContratType", propOrder = {
    "identificationDansSilo"
})
public class ConsulterStructInvContratType {

    @XmlElement(name = "IdentificationDansSilo", required = true)
    protected IdentificationDansSiloType identificationDansSilo;

    /**
     * Obtient la valeur de la propriété identificationDansSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationDansSiloType }
     *     
     */
    public IdentificationDansSiloType getIdentificationDansSilo() {
        return identificationDansSilo;
    }

    /**
     * Définit la valeur de la propriété identificationDansSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationDansSiloType }
     *     
     */
    public void setIdentificationDansSilo(IdentificationDansSiloType value) {
        this.identificationDansSilo = value;
    }

}
