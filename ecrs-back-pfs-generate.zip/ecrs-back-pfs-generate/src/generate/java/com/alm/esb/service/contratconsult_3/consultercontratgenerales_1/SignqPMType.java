
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour SignqPMType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SignqPMType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="raisonSociale" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSIREN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSIRET" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SignqPMType", propOrder = {
    "raisonSociale",
    "codeSIREN",
    "codeSIRET"
})
public class SignqPMType {

    protected String raisonSociale;
    protected String codeSIREN;
    protected String codeSIRET;

    /**
     * Obtient la valeur de la propriété raisonSociale.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRaisonSociale() {
        return raisonSociale;
    }

    /**
     * Définit la valeur de la propriété raisonSociale.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRaisonSociale(String value) {
        this.raisonSociale = value;
    }

    /**
     * Obtient la valeur de la propriété codeSIREN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSIREN() {
        return codeSIREN;
    }

    /**
     * Définit la valeur de la propriété codeSIREN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSIREN(String value) {
        this.codeSIREN = value;
    }

    /**
     * Obtient la valeur de la propriété codeSIRET.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSIRET() {
        return codeSIRET;
    }

    /**
     * Définit la valeur de la propriété codeSIRET.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSIRET(String value) {
        this.codeSIRET = value;
    }

}
