
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentSiloCourtType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentSiloCourtType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idSilo">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeAppli">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeSysInfo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentSiloCourtType", propOrder = {
    "idSilo",
    "codeAppli",
    "codeSysInfo"
})
public class IdentSiloCourtType {

    @XmlElement(required = true)
    protected String idSilo;
    @XmlElement(required = true)
    protected String codeAppli;
    protected String codeSysInfo;

    /**
     * Obtient la valeur de la propriété idSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSilo() {
        return idSilo;
    }

    /**
     * Définit la valeur de la propriété idSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSilo(String value) {
        this.idSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAppli() {
        return codeAppli;
    }

    /**
     * Définit la valeur de la propriété codeAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAppli(String value) {
        this.codeAppli = value;
    }

    /**
     * Obtient la valeur de la propriété codeSysInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSysInfo() {
        return codeSysInfo;
    }

    /**
     * Définit la valeur de la propriété codeSysInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSysInfo(String value) {
        this.codeSysInfo = value;
    }

}
