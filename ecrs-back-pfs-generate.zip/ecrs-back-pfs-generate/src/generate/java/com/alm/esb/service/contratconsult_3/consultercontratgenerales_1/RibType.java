
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RibType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RibType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numCmpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCmpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEtab" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeGuichet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RibType", propOrder = {
    "numCmpt",
    "libCmpt",
    "codeEtab",
    "codeGuichet",
    "cle"
})
public class RibType {

    protected String numCmpt;
    protected String libCmpt;
    protected String codeEtab;
    protected String codeGuichet;
    protected String cle;

    /**
     * Obtient la valeur de la propriété numCmpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumCmpt() {
        return numCmpt;
    }

    /**
     * Définit la valeur de la propriété numCmpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumCmpt(String value) {
        this.numCmpt = value;
    }

    /**
     * Obtient la valeur de la propriété libCmpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCmpt() {
        return libCmpt;
    }

    /**
     * Définit la valeur de la propriété libCmpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCmpt(String value) {
        this.libCmpt = value;
    }

    /**
     * Obtient la valeur de la propriété codeEtab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEtab() {
        return codeEtab;
    }

    /**
     * Définit la valeur de la propriété codeEtab.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEtab(String value) {
        this.codeEtab = value;
    }

    /**
     * Obtient la valeur de la propriété codeGuichet.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGuichet() {
        return codeGuichet;
    }

    /**
     * Définit la valeur de la propriété codeGuichet.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGuichet(String value) {
        this.codeGuichet = value;
    }

    /**
     * Obtient la valeur de la propriété cle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCle() {
        return cle;
    }

    /**
     * Définit la valeur de la propriété cle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCle(String value) {
        this.cle = value;
    }

}
