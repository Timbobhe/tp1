
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ParametresEditionType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ParametresEditionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdSiloAdherente" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IdSiloAdherenteType" minOccurs="0"/>
 *         &lt;element name="codeCatPrsl" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="Edition" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}EditionType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ParametresEditionType", propOrder = {
    "idSiloAdherente",
    "codeCatPrsl",
    "edition"
})
public class ParametresEditionType {

    @XmlElement(name = "IdSiloAdherente")
    protected IdSiloAdherenteType idSiloAdherente;
    protected BigInteger codeCatPrsl;
    @XmlElement(name = "Edition")
    protected List<EditionType> edition;

    /**
     * Obtient la valeur de la propriété idSiloAdherente.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloAdherenteType }
     *     
     */
    public IdSiloAdherenteType getIdSiloAdherente() {
        return idSiloAdherente;
    }

    /**
     * Définit la valeur de la propriété idSiloAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloAdherenteType }
     *     
     */
    public void setIdSiloAdherente(IdSiloAdherenteType value) {
        this.idSiloAdherente = value;
    }

    /**
     * Obtient la valeur de la propriété codeCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCodeCatPrsl() {
        return codeCatPrsl;
    }

    /**
     * Définit la valeur de la propriété codeCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCodeCatPrsl(BigInteger value) {
        this.codeCatPrsl = value;
    }

    /**
     * Gets the value of the edition property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the edition property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getEdition().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link EditionType }
     * 
     * 
     */
    public List<EditionType> getEdition() {
        if (edition == null) {
            edition = new ArrayList<EditionType>();
        }
        return this.edition;
    }

}
