
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AssureAdditionnelsType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AssureAdditionnelsType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}IdentSiloAssurAdd" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}SignaletiquePPAssurAdd" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssureAdditionnelsType", propOrder = {
    "identSiloAssurAdd",
    "signaletiquePPAssurAdd"
})
public class AssureAdditionnelsType {

    @XmlElement(name = "IdentSiloAssurAdd")
    protected IdentSiloType identSiloAssurAdd;
    @XmlElement(name = "SignaletiquePPAssurAdd")
    protected SignaletiquePPType2 signaletiquePPAssurAdd;

    /**
     * Obtient la valeur de la propriété identSiloAssurAdd.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloAssurAdd() {
        return identSiloAssurAdd;
    }

    /**
     * Définit la valeur de la propriété identSiloAssurAdd.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloAssurAdd(IdentSiloType value) {
        this.identSiloAssurAdd = value;
    }

    /**
     * Obtient la valeur de la propriété signaletiquePPAssurAdd.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiquePPType2 }
     *     
     */
    public SignaletiquePPType2 getSignaletiquePPAssurAdd() {
        return signaletiquePPAssurAdd;
    }

    /**
     * Définit la valeur de la propriété signaletiquePPAssurAdd.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiquePPType2 }
     *     
     */
    public void setSignaletiquePPAssurAdd(SignaletiquePPType2 value) {
        this.signaletiquePPAssurAdd = value;
    }

}
