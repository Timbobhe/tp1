
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratIndividuelType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratIndividuelType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}AssurePrincipal" maxOccurs="unbounded"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}AssureAdditionnels" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="clauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}LibClause" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratIndividuelType", propOrder = {
    "assurePrincipal",
    "assureAdditionnels",
    "clauseBenef",
    "libClause"
})
public class ContratIndividuelType {

    @XmlElement(name = "AssurePrincipal", required = true)
    protected List<AssurePrincipalType> assurePrincipal;
    @XmlElement(name = "AssureAdditionnels")
    protected List<AssureAdditionnelsType> assureAdditionnels;
    protected String clauseBenef;
    @XmlElement(name = "LibClause")
    protected List<LibClauseType> libClause;

    /**
     * Gets the value of the assurePrincipal property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assurePrincipal property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssurePrincipal().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssurePrincipalType }
     * 
     * 
     */
    public List<AssurePrincipalType> getAssurePrincipal() {
        if (assurePrincipal == null) {
            assurePrincipal = new ArrayList<AssurePrincipalType>();
        }
        return this.assurePrincipal;
    }

    /**
     * Gets the value of the assureAdditionnels property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assureAdditionnels property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssureAdditionnels().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssureAdditionnelsType }
     * 
     * 
     */
    public List<AssureAdditionnelsType> getAssureAdditionnels() {
        if (assureAdditionnels == null) {
            assureAdditionnels = new ArrayList<AssureAdditionnelsType>();
        }
        return this.assureAdditionnels;
    }

    /**
     * Obtient la valeur de la propriété clauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClauseBenef() {
        return clauseBenef;
    }

    /**
     * Définit la valeur de la propriété clauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClauseBenef(String value) {
        this.clauseBenef = value;
    }

    /**
     * Gets the value of the libClause property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the libClause property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLibClause().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LibClauseType }
     * 
     * 
     */
    public List<LibClauseType> getLibClause() {
        if (libClause == null) {
            libClause = new ArrayList<LibClauseType>();
        }
        return this.libClause;
    }

}
