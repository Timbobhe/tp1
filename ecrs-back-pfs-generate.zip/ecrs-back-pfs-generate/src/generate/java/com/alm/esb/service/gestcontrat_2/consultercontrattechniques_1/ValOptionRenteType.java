
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ValOptionRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ValOptionRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="uniteOptionRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="valOptionRente" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValOptionRenteType", propOrder = {
    "uniteOptionRente",
    "valOptionRente"
})
public class ValOptionRenteType {

    protected String uniteOptionRente;
    @XmlElement(required = true)
    protected String valOptionRente;

    /**
     * Obtient la valeur de la propriété uniteOptionRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUniteOptionRente() {
        return uniteOptionRente;
    }

    /**
     * Définit la valeur de la propriété uniteOptionRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUniteOptionRente(String value) {
        this.uniteOptionRente = value;
    }

    /**
     * Obtient la valeur de la propriété valOptionRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValOptionRente() {
        return valOptionRente;
    }

    /**
     * Définit la valeur de la propriété valOptionRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValOptionRente(String value) {
        this.valOptionRente = value;
    }

}
