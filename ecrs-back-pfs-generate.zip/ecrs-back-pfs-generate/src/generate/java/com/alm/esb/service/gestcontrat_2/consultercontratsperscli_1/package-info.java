@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;
