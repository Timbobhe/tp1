
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour PrimeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PrimeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="mntAnnTTC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeClasseCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libClasseCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PrimeType", propOrder = {
    "mntAnnTTC",
    "tauxCotis",
    "codeClasseCotis",
    "libClasseCotis"
})
public class PrimeType {

    protected String mntAnnTTC;
    protected String tauxCotis;
    protected String codeClasseCotis;
    protected String libClasseCotis;

    /**
     * Obtient la valeur de la propriété mntAnnTTC.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMntAnnTTC() {
        return mntAnnTTC;
    }

    /**
     * Définit la valeur de la propriété mntAnnTTC.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMntAnnTTC(String value) {
        this.mntAnnTTC = value;
    }

    /**
     * Obtient la valeur de la propriété tauxCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTauxCotis() {
        return tauxCotis;
    }

    /**
     * Définit la valeur de la propriété tauxCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTauxCotis(String value) {
        this.tauxCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeClasseCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeClasseCotis() {
        return codeClasseCotis;
    }

    /**
     * Définit la valeur de la propriété codeClasseCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeClasseCotis(String value) {
        this.codeClasseCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libClasseCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibClasseCotis() {
        return libClasseCotis;
    }

    /**
     * Définit la valeur de la propriété libClasseCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibClasseCotis(String value) {
        this.libClasseCotis = value;
    }

}
