
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ActrCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ActrCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAssCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libAssCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idAssCtrSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idApportAffr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libApportAffr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idGestrCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libGestrCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idDistPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDistPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idConseiller" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libConseiller" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActrCtrType", propOrder = {
    "idAssCtr",
    "libAssCtr",
    "idAssCtrSilo",
    "idApportAffr",
    "libApportAffr",
    "idGestrCtr",
    "libGestrCtr",
    "idDistPdt",
    "libDistPdt",
    "idConseiller",
    "libConseiller"
})
public class ActrCtrType {

    protected String idAssCtr;
    protected String libAssCtr;
    protected String idAssCtrSilo;
    protected String idApportAffr;
    protected String libApportAffr;
    protected String idGestrCtr;
    protected String libGestrCtr;
    protected String idDistPdt;
    protected String libDistPdt;
    protected String idConseiller;
    protected String libConseiller;

    /**
     * Obtient la valeur de la propriété idAssCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAssCtr() {
        return idAssCtr;
    }

    /**
     * Définit la valeur de la propriété idAssCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAssCtr(String value) {
        this.idAssCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libAssCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAssCtr() {
        return libAssCtr;
    }

    /**
     * Définit la valeur de la propriété libAssCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAssCtr(String value) {
        this.libAssCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idAssCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAssCtrSilo() {
        return idAssCtrSilo;
    }

    /**
     * Définit la valeur de la propriété idAssCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAssCtrSilo(String value) {
        this.idAssCtrSilo = value;
    }

    /**
     * Obtient la valeur de la propriété idApportAffr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdApportAffr() {
        return idApportAffr;
    }

    /**
     * Définit la valeur de la propriété idApportAffr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdApportAffr(String value) {
        this.idApportAffr = value;
    }

    /**
     * Obtient la valeur de la propriété libApportAffr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibApportAffr() {
        return libApportAffr;
    }

    /**
     * Définit la valeur de la propriété libApportAffr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibApportAffr(String value) {
        this.libApportAffr = value;
    }

    /**
     * Obtient la valeur de la propriété idGestrCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdGestrCtr() {
        return idGestrCtr;
    }

    /**
     * Définit la valeur de la propriété idGestrCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdGestrCtr(String value) {
        this.idGestrCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libGestrCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibGestrCtr() {
        return libGestrCtr;
    }

    /**
     * Définit la valeur de la propriété libGestrCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibGestrCtr(String value) {
        this.libGestrCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idDistPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdDistPdt() {
        return idDistPdt;
    }

    /**
     * Définit la valeur de la propriété idDistPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdDistPdt(String value) {
        this.idDistPdt = value;
    }

    /**
     * Obtient la valeur de la propriété libDistPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDistPdt() {
        return libDistPdt;
    }

    /**
     * Définit la valeur de la propriété libDistPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDistPdt(String value) {
        this.libDistPdt = value;
    }

    /**
     * Obtient la valeur de la propriété idConseiller.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdConseiller() {
        return idConseiller;
    }

    /**
     * Définit la valeur de la propriété idConseiller.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdConseiller(String value) {
        this.idConseiller = value;
    }

    /**
     * Obtient la valeur de la propriété libConseiller.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibConseiller() {
        return libConseiller;
    }

    /**
     * Définit la valeur de la propriété libConseiller.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibConseiller(String value) {
        this.libConseiller = value;
    }

}
