
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.fmk.esb.framework.esbtechpivotschema.PivotTechType;
import com.unilog.wof.shared.context.tibco.ErreurInfosType;


/**
 * <p>Classe Java pour ConsulterContratsPersCliInterfaceType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratsPersCliInterfaceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.fmk.com/ESB/Framework/ESBTechPivotSchema}PivotTech"/>
 *         &lt;element ref="{http://context.shared.wof.unilog.com/tibco}ErreurInfos" minOccurs="0"/>
 *         &lt;element name="CorrelatedOC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratsPersCliInterfaceType", propOrder = {
    "pivotTech",
    "erreurInfos",
    "correlatedOC"
})
public class ConsulterContratsPersCliInterfaceType {

    @XmlElement(name = "PivotTech", namespace = "http://www.fmk.com/ESB/Framework/ESBTechPivotSchema", required = true)
    protected PivotTechType pivotTech;
    @XmlElement(name = "ErreurInfos", namespace = "http://context.shared.wof.unilog.com/tibco")
    protected ErreurInfosType erreurInfos;
    @XmlElement(name = "CorrelatedOC")
    protected String correlatedOC;

    /**
     * Obtient la valeur de la propriété pivotTech.
     * 
     * @return
     *     possible object is
     *     {@link PivotTechType }
     *     
     */
    public PivotTechType getPivotTech() {
        return pivotTech;
    }

    /**
     * Définit la valeur de la propriété pivotTech.
     * 
     * @param value
     *     allowed object is
     *     {@link PivotTechType }
     *     
     */
    public void setPivotTech(PivotTechType value) {
        this.pivotTech = value;
    }

    /**
     * Obtient la valeur de la propriété erreurInfos.
     * 
     * @return
     *     possible object is
     *     {@link ErreurInfosType }
     *     
     */
    public ErreurInfosType getErreurInfos() {
        return erreurInfos;
    }

    /**
     * Définit la valeur de la propriété erreurInfos.
     * 
     * @param value
     *     allowed object is
     *     {@link ErreurInfosType }
     *     
     */
    public void setErreurInfos(ErreurInfosType value) {
        this.erreurInfos = value;
    }

    /**
     * Obtient la valeur de la propriété correlatedOC.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCorrelatedOC() {
        return correlatedOC;
    }

    /**
     * Définit la valeur de la propriété correlatedOC.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCorrelatedOC(String value) {
        this.correlatedOC = value;
    }

}
