
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoValoType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoValoType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeModeRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeRevaloSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeRevaloSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mntCaptlConst" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeDeviseMntCaptl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDeviseMntCaptl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codePeriodRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriodRevalo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mntAnnRente" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeDeviseMntRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDeviseMntRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeEchPaimt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeEchPaimt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeEchPaimtSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeEchPaimtSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateRevalo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateProchaineRevalo" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateProchainPaimt" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="InfoPrelevSoclRevalo" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}InfoPrelevSoclRevaloType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoValoType", propOrder = {
    "codeModeRevalo",
    "libModeRevalo",
    "codeModeRevaloSilo",
    "libModeRevaloSilo",
    "codeTypeRevalo",
    "libTypeRevalo",
    "mntCaptlConst",
    "codeDeviseMntCaptl",
    "libDeviseMntCaptl",
    "codePeriodRevalo",
    "libPeriodRevalo",
    "mntAnnRente",
    "codeDeviseMntRente",
    "libDeviseMntRente",
    "codeTypeEchPaimt",
    "libTypeEchPaimt",
    "codeTypeEchPaimtSilo",
    "libTypeEchPaimtSilo",
    "dateRevalo",
    "dateProchaineRevalo",
    "dateProchainPaimt",
    "infoPrelevSoclRevalo"
})
public class InfoValoType {

    protected String codeModeRevalo;
    protected String libModeRevalo;
    protected String codeModeRevaloSilo;
    protected String libModeRevaloSilo;
    protected String codeTypeRevalo;
    protected String libTypeRevalo;
    protected BigDecimal mntCaptlConst;
    protected String codeDeviseMntCaptl;
    protected String libDeviseMntCaptl;
    protected String codePeriodRevalo;
    protected String libPeriodRevalo;
    protected BigDecimal mntAnnRente;
    protected String codeDeviseMntRente;
    protected String libDeviseMntRente;
    protected String codeTypeEchPaimt;
    protected String libTypeEchPaimt;
    protected String codeTypeEchPaimtSilo;
    protected String libTypeEchPaimtSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateRevalo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchaineRevalo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchainPaimt;
    @XmlElement(name = "InfoPrelevSoclRevalo")
    protected List<InfoPrelevSoclRevaloType> infoPrelevSoclRevalo;

    /**
     * Obtient la valeur de la propriété codeModeRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeRevalo() {
        return codeModeRevalo;
    }

    /**
     * Définit la valeur de la propriété codeModeRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeRevalo(String value) {
        this.codeModeRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeRevalo() {
        return libModeRevalo;
    }

    /**
     * Définit la valeur de la propriété libModeRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeRevalo(String value) {
        this.libModeRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeRevaloSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeRevaloSilo() {
        return codeModeRevaloSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeRevaloSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeRevaloSilo(String value) {
        this.codeModeRevaloSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeRevaloSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeRevaloSilo() {
        return libModeRevaloSilo;
    }

    /**
     * Définit la valeur de la propriété libModeRevaloSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeRevaloSilo(String value) {
        this.libModeRevaloSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeRevalo() {
        return codeTypeRevalo;
    }

    /**
     * Définit la valeur de la propriété codeTypeRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeRevalo(String value) {
        this.codeTypeRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeRevalo() {
        return libTypeRevalo;
    }

    /**
     * Définit la valeur de la propriété libTypeRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeRevalo(String value) {
        this.libTypeRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété mntCaptlConst.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntCaptlConst() {
        return mntCaptlConst;
    }

    /**
     * Définit la valeur de la propriété mntCaptlConst.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntCaptlConst(BigDecimal value) {
        this.mntCaptlConst = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseMntCaptl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseMntCaptl() {
        return codeDeviseMntCaptl;
    }

    /**
     * Définit la valeur de la propriété codeDeviseMntCaptl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseMntCaptl(String value) {
        this.codeDeviseMntCaptl = value;
    }

    /**
     * Obtient la valeur de la propriété libDeviseMntCaptl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDeviseMntCaptl() {
        return libDeviseMntCaptl;
    }

    /**
     * Définit la valeur de la propriété libDeviseMntCaptl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDeviseMntCaptl(String value) {
        this.libDeviseMntCaptl = value;
    }

    /**
     * Obtient la valeur de la propriété codePeriodRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodRevalo() {
        return codePeriodRevalo;
    }

    /**
     * Définit la valeur de la propriété codePeriodRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodRevalo(String value) {
        this.codePeriodRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriodRevalo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriodRevalo() {
        return libPeriodRevalo;
    }

    /**
     * Définit la valeur de la propriété libPeriodRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriodRevalo(String value) {
        this.libPeriodRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété mntAnnRente.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntAnnRente() {
        return mntAnnRente;
    }

    /**
     * Définit la valeur de la propriété mntAnnRente.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntAnnRente(BigDecimal value) {
        this.mntAnnRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseMntRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseMntRente() {
        return codeDeviseMntRente;
    }

    /**
     * Définit la valeur de la propriété codeDeviseMntRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseMntRente(String value) {
        this.codeDeviseMntRente = value;
    }

    /**
     * Obtient la valeur de la propriété libDeviseMntRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDeviseMntRente() {
        return libDeviseMntRente;
    }

    /**
     * Définit la valeur de la propriété libDeviseMntRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDeviseMntRente(String value) {
        this.libDeviseMntRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeEchPaimt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeEchPaimt() {
        return codeTypeEchPaimt;
    }

    /**
     * Définit la valeur de la propriété codeTypeEchPaimt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeEchPaimt(String value) {
        this.codeTypeEchPaimt = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeEchPaimt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeEchPaimt() {
        return libTypeEchPaimt;
    }

    /**
     * Définit la valeur de la propriété libTypeEchPaimt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeEchPaimt(String value) {
        this.libTypeEchPaimt = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeEchPaimtSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeEchPaimtSilo() {
        return codeTypeEchPaimtSilo;
    }

    /**
     * Définit la valeur de la propriété codeTypeEchPaimtSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeEchPaimtSilo(String value) {
        this.codeTypeEchPaimtSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeEchPaimtSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeEchPaimtSilo() {
        return libTypeEchPaimtSilo;
    }

    /**
     * Définit la valeur de la propriété libTypeEchPaimtSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeEchPaimtSilo(String value) {
        this.libTypeEchPaimtSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateRevalo.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateRevalo() {
        return dateRevalo;
    }

    /**
     * Définit la valeur de la propriété dateRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateRevalo(XMLGregorianCalendar value) {
        this.dateRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchaineRevalo.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchaineRevalo() {
        return dateProchaineRevalo;
    }

    /**
     * Définit la valeur de la propriété dateProchaineRevalo.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchaineRevalo(XMLGregorianCalendar value) {
        this.dateProchaineRevalo = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchainPaimt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchainPaimt() {
        return dateProchainPaimt;
    }

    /**
     * Définit la valeur de la propriété dateProchainPaimt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchainPaimt(XMLGregorianCalendar value) {
        this.dateProchainPaimt = value;
    }

    /**
     * Gets the value of the infoPrelevSoclRevalo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoPrelevSoclRevalo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoPrelevSoclRevalo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoPrelevSoclRevaloType }
     * 
     * 
     */
    public List<InfoPrelevSoclRevaloType> getInfoPrelevSoclRevalo() {
        if (infoPrelevSoclRevalo == null) {
            infoPrelevSoclRevalo = new ArrayList<InfoPrelevSoclRevaloType>();
        }
        return this.infoPrelevSoclRevalo;
    }

}
