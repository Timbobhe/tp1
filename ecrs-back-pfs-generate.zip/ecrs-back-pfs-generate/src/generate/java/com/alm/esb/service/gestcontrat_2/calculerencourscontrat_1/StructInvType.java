
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour StructInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="StructInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificationStructInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}IdentificationStructInvType"/>
 *         &lt;element name="OccurStructInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}OccurStructInvType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructInvType", propOrder = {
    "identificationStructInv",
    "occurStructInv"
})
public class StructInvType {

    @XmlElement(name = "IdentificationStructInv", required = true)
    protected IdentificationStructInvType identificationStructInv;
    @XmlElement(name = "OccurStructInv")
    protected List<OccurStructInvType> occurStructInv;

    /**
     * Obtient la valeur de la propriété identificationStructInv.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationStructInvType }
     *     
     */
    public IdentificationStructInvType getIdentificationStructInv() {
        return identificationStructInv;
    }

    /**
     * Définit la valeur de la propriété identificationStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationStructInvType }
     *     
     */
    public void setIdentificationStructInv(IdentificationStructInvType value) {
        this.identificationStructInv = value;
    }

    /**
     * Gets the value of the occurStructInv property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the occurStructInv property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOccurStructInv().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OccurStructInvType }
     * 
     * 
     */
    public List<OccurStructInvType> getOccurStructInv() {
        if (occurStructInv == null) {
            occurStructInv = new ArrayList<OccurStructInvType>();
        }
        return this.occurStructInv;
    }

}
