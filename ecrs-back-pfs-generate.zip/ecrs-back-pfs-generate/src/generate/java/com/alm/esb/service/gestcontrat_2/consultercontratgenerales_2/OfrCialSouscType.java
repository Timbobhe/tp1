
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OfrCialSouscType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OfrCialSouscType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentOfrSoustn" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}IdentOfrSoustnType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OfrCialSouscType", propOrder = {
    "identOfrSoustn"
})
public class OfrCialSouscType {

    @XmlElement(name = "IdentOfrSoustn")
    protected IdentOfrSoustnType identOfrSoustn;

    /**
     * Obtient la valeur de la propriété identOfrSoustn.
     * 
     * @return
     *     possible object is
     *     {@link IdentOfrSoustnType }
     *     
     */
    public IdentOfrSoustnType getIdentOfrSoustn() {
        return identOfrSoustn;
    }

    /**
     * Définit la valeur de la propriété identOfrSoustn.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentOfrSoustnType }
     *     
     */
    public void setIdentOfrSoustn(IdentOfrSoustnType value) {
        this.identOfrSoustn = value;
    }

}
