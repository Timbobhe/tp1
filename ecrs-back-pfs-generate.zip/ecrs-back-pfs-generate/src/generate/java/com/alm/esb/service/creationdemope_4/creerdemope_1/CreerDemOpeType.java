
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CreerDemOpeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CreerDemOpeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DemOpe" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}DemOpeType"/>
 *         &lt;element name="InfoCompl" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}InfoComplType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Formulaire" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}FormulaireType" minOccurs="0"/>
 *         &lt;element name="PiecesJointes" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}PiecesJointesType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreerDemOpeType", propOrder = {
    "demOpe",
    "infoCompl",
    "formulaire",
    "piecesJointes"
})
public class CreerDemOpeType {

    @XmlElement(name = "DemOpe", required = true)
    protected DemOpeType demOpe;
    @XmlElement(name = "InfoCompl")
    protected List<InfoComplType> infoCompl;
    @XmlElement(name = "Formulaire")
    protected FormulaireType formulaire;
    @XmlElement(name = "PiecesJointes")
    protected List<PiecesJointesType> piecesJointes;

    /**
     * Obtient la valeur de la propriété demOpe.
     * 
     * @return
     *     possible object is
     *     {@link DemOpeType }
     *     
     */
    public DemOpeType getDemOpe() {
        return demOpe;
    }

    /**
     * Définit la valeur de la propriété demOpe.
     * 
     * @param value
     *     allowed object is
     *     {@link DemOpeType }
     *     
     */
    public void setDemOpe(DemOpeType value) {
        this.demOpe = value;
    }

    /**
     * Gets the value of the infoCompl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoCompl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoCompl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoComplType }
     * 
     * 
     */
    public List<InfoComplType> getInfoCompl() {
        if (infoCompl == null) {
            infoCompl = new ArrayList<InfoComplType>();
        }
        return this.infoCompl;
    }

    /**
     * Obtient la valeur de la propriété formulaire.
     * 
     * @return
     *     possible object is
     *     {@link FormulaireType }
     *     
     */
    public FormulaireType getFormulaire() {
        return formulaire;
    }

    /**
     * Définit la valeur de la propriété formulaire.
     * 
     * @param value
     *     allowed object is
     *     {@link FormulaireType }
     *     
     */
    public void setFormulaire(FormulaireType value) {
        this.formulaire = value;
    }

    /**
     * Gets the value of the piecesJointes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the piecesJointes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPiecesJointes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PiecesJointesType }
     * 
     * 
     */
    public List<PiecesJointesType> getPiecesJointes() {
        if (piecesJointes == null) {
            piecesJointes = new ArrayList<PiecesJointesType>();
        }
        return this.piecesJointes;
    }

}
