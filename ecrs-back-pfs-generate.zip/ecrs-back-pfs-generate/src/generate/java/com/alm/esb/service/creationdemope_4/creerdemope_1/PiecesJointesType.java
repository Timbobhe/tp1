
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour PiecesJointesType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PiecesJointesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentDoc" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdentDocType" minOccurs="0"/>
 *         &lt;element name="IdxDoc" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdxDocType" minOccurs="0"/>
 *         &lt;element name="NumerisDoc" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}NumerisDocType" minOccurs="0"/>
 *         &lt;element name="EmisDoc" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}EmisDocType" minOccurs="0"/>
 *         &lt;element name="fichierJoint" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PiecesJointesType", propOrder = {
    "identDoc",
    "idxDoc",
    "numerisDoc",
    "emisDoc",
    "fichierJoint"
})
public class PiecesJointesType {

    @XmlElement(name = "IdentDoc")
    protected IdentDocType identDoc;
    @XmlElement(name = "IdxDoc")
    protected IdxDocType idxDoc;
    @XmlElement(name = "NumerisDoc")
    protected NumerisDocType numerisDoc;
    @XmlElement(name = "EmisDoc")
    protected EmisDocType emisDoc;
    protected byte[] fichierJoint;

    /**
     * Obtient la valeur de la propriété identDoc.
     * 
     * @return
     *     possible object is
     *     {@link IdentDocType }
     *     
     */
    public IdentDocType getIdentDoc() {
        return identDoc;
    }

    /**
     * Définit la valeur de la propriété identDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentDocType }
     *     
     */
    public void setIdentDoc(IdentDocType value) {
        this.identDoc = value;
    }

    /**
     * Obtient la valeur de la propriété idxDoc.
     * 
     * @return
     *     possible object is
     *     {@link IdxDocType }
     *     
     */
    public IdxDocType getIdxDoc() {
        return idxDoc;
    }

    /**
     * Définit la valeur de la propriété idxDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link IdxDocType }
     *     
     */
    public void setIdxDoc(IdxDocType value) {
        this.idxDoc = value;
    }

    /**
     * Obtient la valeur de la propriété numerisDoc.
     * 
     * @return
     *     possible object is
     *     {@link NumerisDocType }
     *     
     */
    public NumerisDocType getNumerisDoc() {
        return numerisDoc;
    }

    /**
     * Définit la valeur de la propriété numerisDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link NumerisDocType }
     *     
     */
    public void setNumerisDoc(NumerisDocType value) {
        this.numerisDoc = value;
    }

    /**
     * Obtient la valeur de la propriété emisDoc.
     * 
     * @return
     *     possible object is
     *     {@link EmisDocType }
     *     
     */
    public EmisDocType getEmisDoc() {
        return emisDoc;
    }

    /**
     * Définit la valeur de la propriété emisDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link EmisDocType }
     *     
     */
    public void setEmisDoc(EmisDocType value) {
        this.emisDoc = value;
    }

    /**
     * Obtient la valeur de la propriété fichierJoint.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getFichierJoint() {
        return fichierJoint;
    }

    /**
     * Définit la valeur de la propriété fichierJoint.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setFichierJoint(byte[] value) {
        this.fichierJoint = value;
    }

}
