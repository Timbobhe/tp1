
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour TrsfCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="TrsfCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="mutlDesEnc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeOriCtrTransfere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOriCtrTransfere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TrsfCtrType", propOrder = {
    "mutlDesEnc",
    "codeOriCtrTransfere",
    "libOriCtrTransfere"
})
public class TrsfCtrType {

    protected String mutlDesEnc;
    protected String codeOriCtrTransfere;
    protected String libOriCtrTransfere;

    /**
     * Obtient la valeur de la propriété mutlDesEnc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMutlDesEnc() {
        return mutlDesEnc;
    }

    /**
     * Définit la valeur de la propriété mutlDesEnc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMutlDesEnc(String value) {
        this.mutlDesEnc = value;
    }

    /**
     * Obtient la valeur de la propriété codeOriCtrTransfere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOriCtrTransfere() {
        return codeOriCtrTransfere;
    }

    /**
     * Définit la valeur de la propriété codeOriCtrTransfere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOriCtrTransfere(String value) {
        this.codeOriCtrTransfere = value;
    }

    /**
     * Obtient la valeur de la propriété libOriCtrTransfere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOriCtrTransfere() {
        return libOriCtrTransfere;
    }

    /**
     * Définit la valeur de la propriété libOriCtrTransfere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOriCtrTransfere(String value) {
        this.libOriCtrTransfere = value;
    }

}
