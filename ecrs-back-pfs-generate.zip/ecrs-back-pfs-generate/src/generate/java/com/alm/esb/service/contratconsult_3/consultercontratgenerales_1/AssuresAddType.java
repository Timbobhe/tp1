
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AssuresAddType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AssuresAddType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloAssurAdd" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdSiloSouscType" minOccurs="0"/>
 *         &lt;element name="SignqPPAssureAdd" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqPPAssurAddType" minOccurs="0"/>
 *         &lt;element name="DetPP" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DetPPType" minOccurs="0"/>
 *         &lt;element name="AutreNatio" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AutreNatioType" minOccurs="0"/>
 *         &lt;element name="DossCom" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}DossComType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssuresAddType", propOrder = {
    "identSiloAssurAdd",
    "signqPPAssureAdd",
    "detPP",
    "autreNatio",
    "dossCom"
})
public class AssuresAddType {

    @XmlElement(name = "IdentSiloAssurAdd")
    protected IdSiloSouscType identSiloAssurAdd;
    @XmlElement(name = "SignqPPAssureAdd")
    protected SignqPPAssurAddType signqPPAssureAdd;
    @XmlElement(name = "DetPP")
    protected DetPPType detPP;
    @XmlElement(name = "AutreNatio")
    protected AutreNatioType autreNatio;
    @XmlElement(name = "DossCom")
    protected DossComType dossCom;

    /**
     * Obtient la valeur de la propriété identSiloAssurAdd.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloSouscType }
     *     
     */
    public IdSiloSouscType getIdentSiloAssurAdd() {
        return identSiloAssurAdd;
    }

    /**
     * Définit la valeur de la propriété identSiloAssurAdd.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloSouscType }
     *     
     */
    public void setIdentSiloAssurAdd(IdSiloSouscType value) {
        this.identSiloAssurAdd = value;
    }

    /**
     * Obtient la valeur de la propriété signqPPAssureAdd.
     * 
     * @return
     *     possible object is
     *     {@link SignqPPAssurAddType }
     *     
     */
    public SignqPPAssurAddType getSignqPPAssureAdd() {
        return signqPPAssureAdd;
    }

    /**
     * Définit la valeur de la propriété signqPPAssureAdd.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqPPAssurAddType }
     *     
     */
    public void setSignqPPAssureAdd(SignqPPAssurAddType value) {
        this.signqPPAssureAdd = value;
    }

    /**
     * Obtient la valeur de la propriété detPP.
     * 
     * @return
     *     possible object is
     *     {@link DetPPType }
     *     
     */
    public DetPPType getDetPP() {
        return detPP;
    }

    /**
     * Définit la valeur de la propriété detPP.
     * 
     * @param value
     *     allowed object is
     *     {@link DetPPType }
     *     
     */
    public void setDetPP(DetPPType value) {
        this.detPP = value;
    }

    /**
     * Obtient la valeur de la propriété autreNatio.
     * 
     * @return
     *     possible object is
     *     {@link AutreNatioType }
     *     
     */
    public AutreNatioType getAutreNatio() {
        return autreNatio;
    }

    /**
     * Définit la valeur de la propriété autreNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link AutreNatioType }
     *     
     */
    public void setAutreNatio(AutreNatioType value) {
        this.autreNatio = value;
    }

    /**
     * Obtient la valeur de la propriété dossCom.
     * 
     * @return
     *     possible object is
     *     {@link DossComType }
     *     
     */
    public DossComType getDossCom() {
        return dossCom;
    }

    /**
     * Définit la valeur de la propriété dossCom.
     * 
     * @param value
     *     allowed object is
     *     {@link DossComType }
     *     
     */
    public void setDossCom(DossComType value) {
        this.dossCom = value;
    }

}
