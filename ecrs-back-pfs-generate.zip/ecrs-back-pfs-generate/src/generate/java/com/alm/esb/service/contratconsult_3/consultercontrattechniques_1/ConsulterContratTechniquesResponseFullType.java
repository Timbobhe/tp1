
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratTechniquesResponseFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratTechniquesResponseFullType">
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}ConsulterContratTechniquesResponseType">
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratTechniquesResponseFullType")
public class ConsulterContratTechniquesResponseFullType
    extends ConsulterContratTechniquesResponseType
{


}
