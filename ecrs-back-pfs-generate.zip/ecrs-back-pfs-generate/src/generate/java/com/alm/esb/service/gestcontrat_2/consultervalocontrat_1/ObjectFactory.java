
package com.alm.esb.service.gestcontrat_2.consultervalocontrat_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.consultervalocontrat_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConsulterValoContratFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", "ConsulterValoContratFull");
    private final static QName _ConsulterValoContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", "ConsulterValoContrat");
    private final static QName _ConsulterValoContratResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", "ConsulterValoContratResponse");
    private final static QName _ConsulterValoContratFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", "ConsulterValoContratFunc");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.consultervalocontrat_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsulterValoContratFuncType }
     * 
     */
    public ConsulterValoContratFuncType createConsulterValoContratFuncType() {
        return new ConsulterValoContratFuncType();
    }

    /**
     * Create an instance of {@link ConsulterValoContratType }
     * 
     */
    public ConsulterValoContratType createConsulterValoContratType() {
        return new ConsulterValoContratType();
    }

    /**
     * Create an instance of {@link ConsulterValoContratFullType }
     * 
     */
    public ConsulterValoContratFullType createConsulterValoContratFullType() {
        return new ConsulterValoContratFullType();
    }

    /**
     * Create an instance of {@link ConsulterValoContratResponseType }
     * 
     */
    public ConsulterValoContratResponseType createConsulterValoContratResponseType() {
        return new ConsulterValoContratResponseType();
    }

    /**
     * Create an instance of {@link ValoContratType }
     * 
     */
    public ValoContratType createValoContratType() {
        return new ValoContratType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterValoContratFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", name = "ConsulterValoContratFull")
    public JAXBElement<ConsulterValoContratFullType> createConsulterValoContratFull(ConsulterValoContratFullType value) {
        return new JAXBElement<ConsulterValoContratFullType>(_ConsulterValoContratFull_QNAME, ConsulterValoContratFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterValoContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", name = "ConsulterValoContrat")
    public JAXBElement<ConsulterValoContratType> createConsulterValoContrat(ConsulterValoContratType value) {
        return new JAXBElement<ConsulterValoContratType>(_ConsulterValoContrat_QNAME, ConsulterValoContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterValoContratResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", name = "ConsulterValoContratResponse")
    public JAXBElement<ConsulterValoContratResponseType> createConsulterValoContratResponse(ConsulterValoContratResponseType value) {
        return new JAXBElement<ConsulterValoContratResponseType>(_ConsulterValoContratResponse_QNAME, ConsulterValoContratResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterValoContratFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1", name = "ConsulterValoContratFunc")
    public JAXBElement<ConsulterValoContratFuncType> createConsulterValoContratFunc(ConsulterValoContratFuncType value) {
        return new JAXBElement<ConsulterValoContratFuncType>(_ConsulterValoContratFunc_QNAME, ConsulterValoContratFuncType.class, null, value);
    }

}
