
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour ClausesContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ClausesContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeTypeClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeClauseBenefSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numClause" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutClauseBenef" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinClauseBenef" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}InfoBenef" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClausesContratType", propOrder = {
    "codeTypeClauseBenef",
    "libTypeClauseBenef",
    "libTypeClauseBenefSilo",
    "numClause",
    "dateDebutClauseBenef",
    "dateFinClauseBenef",
    "infoBenef"
})
public class ClausesContratType {

    protected String codeTypeClauseBenef;
    protected String libTypeClauseBenef;
    protected String libTypeClauseBenefSilo;
    protected String numClause;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutClauseBenef;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinClauseBenef;
    @XmlElement(name = "InfoBenef")
    protected InfoBeneficiaireType infoBenef;

    /**
     * Obtient la valeur de la propriété codeTypeClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeClauseBenef() {
        return codeTypeClauseBenef;
    }

    /**
     * Définit la valeur de la propriété codeTypeClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeClauseBenef(String value) {
        this.codeTypeClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeClauseBenef() {
        return libTypeClauseBenef;
    }

    /**
     * Définit la valeur de la propriété libTypeClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeClauseBenef(String value) {
        this.libTypeClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeClauseBenefSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeClauseBenefSilo() {
        return libTypeClauseBenefSilo;
    }

    /**
     * Définit la valeur de la propriété libTypeClauseBenefSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeClauseBenefSilo(String value) {
        this.libTypeClauseBenefSilo = value;
    }

    /**
     * Obtient la valeur de la propriété numClause.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumClause() {
        return numClause;
    }

    /**
     * Définit la valeur de la propriété numClause.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumClause(String value) {
        this.numClause = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutClauseBenef() {
        return dateDebutClauseBenef;
    }

    /**
     * Définit la valeur de la propriété dateDebutClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutClauseBenef(XMLGregorianCalendar value) {
        this.dateDebutClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinClauseBenef() {
        return dateFinClauseBenef;
    }

    /**
     * Définit la valeur de la propriété dateFinClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinClauseBenef(XMLGregorianCalendar value) {
        this.dateFinClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété infoBenef.
     * 
     * @return
     *     possible object is
     *     {@link InfoBeneficiaireType }
     *     
     */
    public InfoBeneficiaireType getInfoBenef() {
        return infoBenef;
    }

    /**
     * Définit la valeur de la propriété infoBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoBeneficiaireType }
     *     
     */
    public void setInfoBenef(InfoBeneficiaireType value) {
        this.infoBenef = value;
    }

}
