
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AffilContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AffilContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numAffiliation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="indicAffilComplete" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AffilContratType", propOrder = {
    "numAffiliation",
    "indicAffilComplete"
})
public class AffilContratType {

    @XmlElement(required = true)
    protected String numAffiliation;
    protected Boolean indicAffilComplete;

    /**
     * Obtient la valeur de la propriété numAffiliation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumAffiliation() {
        return numAffiliation;
    }

    /**
     * Définit la valeur de la propriété numAffiliation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumAffiliation(String value) {
        this.numAffiliation = value;
    }

    /**
     * Obtient la valeur de la propriété indicAffilComplete.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicAffilComplete() {
        return indicAffilComplete;
    }

    /**
     * Définit la valeur de la propriété indicAffilComplete.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicAffilComplete(Boolean value) {
        this.indicAffilComplete = value;
    }

}
