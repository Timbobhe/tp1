
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ClauseCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ClauseCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="descClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClauseCtrType", propOrder = {
    "descClauseBenef",
    "codeTypeClauseBenef",
    "libTypeClauseBenef"
})
public class ClauseCtrType {

    protected String descClauseBenef;
    protected String codeTypeClauseBenef;
    protected String libTypeClauseBenef;

    /**
     * Obtient la valeur de la propriété descClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescClauseBenef() {
        return descClauseBenef;
    }

    /**
     * Définit la valeur de la propriété descClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescClauseBenef(String value) {
        this.descClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeClauseBenef() {
        return codeTypeClauseBenef;
    }

    /**
     * Définit la valeur de la propriété codeTypeClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeClauseBenef(String value) {
        this.codeTypeClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeClauseBenef() {
        return libTypeClauseBenef;
    }

    /**
     * Définit la valeur de la propriété libTypeClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeClauseBenef(String value) {
        this.libTypeClauseBenef = value;
    }

}
