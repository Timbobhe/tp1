
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OptionRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OptionRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeOptionRenteContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOptionRenteContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeOptionRenteContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOptionRenteContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeAutorisationSimulationRenteContratGroupe" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libAutorisationSimulationRenteContratGroupe" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeAutorisationSimulationRenteContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libAutorisationSimulationRenteContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="valLibreOptionRente" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="ValOptionRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}ValOptionRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="InfoValo" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}InfoValoType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptionRenteType", propOrder = {
    "codeOptionRenteContrat",
    "libOptionRenteContrat",
    "codeOptionRenteContratSilo",
    "libOptionRenteContratSilo",
    "codeAutorisationSimulationRenteContratGroupe",
    "libAutorisationSimulationRenteContratGroupe",
    "codeAutorisationSimulationRenteContratSilo",
    "libAutorisationSimulationRenteContratSilo",
    "valLibreOptionRente",
    "valOptionRente",
    "infoValo"
})
public class OptionRenteType {

    protected String codeOptionRenteContrat;
    protected String libOptionRenteContrat;
    protected String codeOptionRenteContratSilo;
    protected String libOptionRenteContratSilo;
    protected String codeAutorisationSimulationRenteContratGroupe;
    protected String libAutorisationSimulationRenteContratGroupe;
    protected String codeAutorisationSimulationRenteContratSilo;
    protected String libAutorisationSimulationRenteContratSilo;
    protected Boolean valLibreOptionRente;
    @XmlElement(name = "ValOptionRente")
    protected List<ValOptionRenteType> valOptionRente;
    @XmlElement(name = "InfoValo")
    protected List<InfoValoType> infoValo;

    /**
     * Obtient la valeur de la propriété codeOptionRenteContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOptionRenteContrat() {
        return codeOptionRenteContrat;
    }

    /**
     * Définit la valeur de la propriété codeOptionRenteContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOptionRenteContrat(String value) {
        this.codeOptionRenteContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libOptionRenteContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOptionRenteContrat() {
        return libOptionRenteContrat;
    }

    /**
     * Définit la valeur de la propriété libOptionRenteContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOptionRenteContrat(String value) {
        this.libOptionRenteContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeOptionRenteContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOptionRenteContratSilo() {
        return codeOptionRenteContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeOptionRenteContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOptionRenteContratSilo(String value) {
        this.codeOptionRenteContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libOptionRenteContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOptionRenteContratSilo() {
        return libOptionRenteContratSilo;
    }

    /**
     * Définit la valeur de la propriété libOptionRenteContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOptionRenteContratSilo(String value) {
        this.libOptionRenteContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAutorisationSimulationRenteContratGroupe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAutorisationSimulationRenteContratGroupe() {
        return codeAutorisationSimulationRenteContratGroupe;
    }

    /**
     * Définit la valeur de la propriété codeAutorisationSimulationRenteContratGroupe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAutorisationSimulationRenteContratGroupe(String value) {
        this.codeAutorisationSimulationRenteContratGroupe = value;
    }

    /**
     * Obtient la valeur de la propriété libAutorisationSimulationRenteContratGroupe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAutorisationSimulationRenteContratGroupe() {
        return libAutorisationSimulationRenteContratGroupe;
    }

    /**
     * Définit la valeur de la propriété libAutorisationSimulationRenteContratGroupe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAutorisationSimulationRenteContratGroupe(String value) {
        this.libAutorisationSimulationRenteContratGroupe = value;
    }

    /**
     * Obtient la valeur de la propriété codeAutorisationSimulationRenteContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAutorisationSimulationRenteContratSilo() {
        return codeAutorisationSimulationRenteContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeAutorisationSimulationRenteContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAutorisationSimulationRenteContratSilo(String value) {
        this.codeAutorisationSimulationRenteContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libAutorisationSimulationRenteContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAutorisationSimulationRenteContratSilo() {
        return libAutorisationSimulationRenteContratSilo;
    }

    /**
     * Définit la valeur de la propriété libAutorisationSimulationRenteContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAutorisationSimulationRenteContratSilo(String value) {
        this.libAutorisationSimulationRenteContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété valLibreOptionRente.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isValLibreOptionRente() {
        return valLibreOptionRente;
    }

    /**
     * Définit la valeur de la propriété valLibreOptionRente.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setValLibreOptionRente(Boolean value) {
        this.valLibreOptionRente = value;
    }

    /**
     * Gets the value of the valOptionRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the valOptionRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValOptionRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValOptionRenteType }
     * 
     * 
     */
    public List<ValOptionRenteType> getValOptionRente() {
        if (valOptionRente == null) {
            valOptionRente = new ArrayList<ValOptionRenteType>();
        }
        return this.valOptionRente;
    }

    /**
     * Gets the value of the infoValo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoValo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoValo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoValoType }
     * 
     * 
     */
    public List<InfoValoType> getInfoValo() {
        if (infoValo == null) {
            infoValo = new ArrayList<InfoValoType>();
        }
        return this.infoValo;
    }

}
