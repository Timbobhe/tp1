
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}IdentContrat"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}InfoContrat" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}Souscripteurs" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}OffreCommSouscrite" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}EchPaiementPrime" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ActeurContrat" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}OptContratEpargne" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}Rib" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ContratColl" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ContratIndiv" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}TrsfCtr" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}StructOrga" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ActivitePartnrt" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratType", propOrder = {
    "identContrat",
    "infoContrat",
    "souscripteurs",
    "offreCommSouscrite",
    "echPaiementPrime",
    "acteurContrat",
    "optContratEpargne",
    "rib",
    "contratColl",
    "contratIndiv",
    "trsfCtr",
    "structOrga",
    "activitePartnrt"
})
public class ContratType {

    @XmlElement(name = "IdentContrat", required = true)
    protected IdentContratType identContrat;
    @XmlElement(name = "InfoContrat")
    protected InfoContratType infoContrat;
    @XmlElement(name = "Souscripteurs")
    protected List<SouscripteursType> souscripteurs;
    @XmlElement(name = "OffreCommSouscrite")
    protected OffreCommSouscriteType offreCommSouscrite;
    @XmlElement(name = "EchPaiementPrime")
    protected EchPaiementPrimeType echPaiementPrime;
    @XmlElement(name = "ActeurContrat")
    protected List<ActeurContratType> acteurContrat;
    @XmlElement(name = "OptContratEpargne")
    protected OptContratEpargneType optContratEpargne;
    @XmlElement(name = "Rib")
    protected RibType rib;
    @XmlElement(name = "ContratColl")
    protected ContratCollType contratColl;
    @XmlElement(name = "ContratIndiv")
    protected ContratIndivType contratIndiv;
    @XmlElement(name = "TrsfCtr")
    protected List<TrsfCtrType> trsfCtr;
    @XmlElement(name = "StructOrga")
    protected List<StructOrgaType> structOrga;
    @XmlElement(name = "ActivitePartnrt")
    protected List<ActivitePartnrtType> activitePartnrt;

    /**
     * Obtient la valeur de la propriété identContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratType }
     *     
     */
    public IdentContratType getIdentContrat() {
        return identContrat;
    }

    /**
     * Définit la valeur de la propriété identContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratType }
     *     
     */
    public void setIdentContrat(IdentContratType value) {
        this.identContrat = value;
    }

    /**
     * Obtient la valeur de la propriété infoContrat.
     * 
     * @return
     *     possible object is
     *     {@link InfoContratType }
     *     
     */
    public InfoContratType getInfoContrat() {
        return infoContrat;
    }

    /**
     * Définit la valeur de la propriété infoContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoContratType }
     *     
     */
    public void setInfoContrat(InfoContratType value) {
        this.infoContrat = value;
    }

    /**
     * Gets the value of the souscripteurs property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the souscripteurs property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSouscripteurs().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SouscripteursType }
     * 
     * 
     */
    public List<SouscripteursType> getSouscripteurs() {
        if (souscripteurs == null) {
            souscripteurs = new ArrayList<SouscripteursType>();
        }
        return this.souscripteurs;
    }

    /**
     * Obtient la valeur de la propriété offreCommSouscrite.
     * 
     * @return
     *     possible object is
     *     {@link OffreCommSouscriteType }
     *     
     */
    public OffreCommSouscriteType getOffreCommSouscrite() {
        return offreCommSouscrite;
    }

    /**
     * Définit la valeur de la propriété offreCommSouscrite.
     * 
     * @param value
     *     allowed object is
     *     {@link OffreCommSouscriteType }
     *     
     */
    public void setOffreCommSouscrite(OffreCommSouscriteType value) {
        this.offreCommSouscrite = value;
    }

    /**
     * Obtient la valeur de la propriété echPaiementPrime.
     * 
     * @return
     *     possible object is
     *     {@link EchPaiementPrimeType }
     *     
     */
    public EchPaiementPrimeType getEchPaiementPrime() {
        return echPaiementPrime;
    }

    /**
     * Définit la valeur de la propriété echPaiementPrime.
     * 
     * @param value
     *     allowed object is
     *     {@link EchPaiementPrimeType }
     *     
     */
    public void setEchPaiementPrime(EchPaiementPrimeType value) {
        this.echPaiementPrime = value;
    }

    /**
     * Gets the value of the acteurContrat property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the acteurContrat property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActeurContrat().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActeurContratType }
     * 
     * 
     */
    public List<ActeurContratType> getActeurContrat() {
        if (acteurContrat == null) {
            acteurContrat = new ArrayList<ActeurContratType>();
        }
        return this.acteurContrat;
    }

    /**
     * Obtient la valeur de la propriété optContratEpargne.
     * 
     * @return
     *     possible object is
     *     {@link OptContratEpargneType }
     *     
     */
    public OptContratEpargneType getOptContratEpargne() {
        return optContratEpargne;
    }

    /**
     * Définit la valeur de la propriété optContratEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link OptContratEpargneType }
     *     
     */
    public void setOptContratEpargne(OptContratEpargneType value) {
        this.optContratEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété rib.
     * 
     * @return
     *     possible object is
     *     {@link RibType }
     *     
     */
    public RibType getRib() {
        return rib;
    }

    /**
     * Définit la valeur de la propriété rib.
     * 
     * @param value
     *     allowed object is
     *     {@link RibType }
     *     
     */
    public void setRib(RibType value) {
        this.rib = value;
    }

    /**
     * Obtient la valeur de la propriété contratColl.
     * 
     * @return
     *     possible object is
     *     {@link ContratCollType }
     *     
     */
    public ContratCollType getContratColl() {
        return contratColl;
    }

    /**
     * Définit la valeur de la propriété contratColl.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratCollType }
     *     
     */
    public void setContratColl(ContratCollType value) {
        this.contratColl = value;
    }

    /**
     * Obtient la valeur de la propriété contratIndiv.
     * 
     * @return
     *     possible object is
     *     {@link ContratIndivType }
     *     
     */
    public ContratIndivType getContratIndiv() {
        return contratIndiv;
    }

    /**
     * Définit la valeur de la propriété contratIndiv.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratIndivType }
     *     
     */
    public void setContratIndiv(ContratIndivType value) {
        this.contratIndiv = value;
    }

    /**
     * Gets the value of the trsfCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the trsfCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getTrsfCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link TrsfCtrType }
     * 
     * 
     */
    public List<TrsfCtrType> getTrsfCtr() {
        if (trsfCtr == null) {
            trsfCtr = new ArrayList<TrsfCtrType>();
        }
        return this.trsfCtr;
    }

    /**
     * Gets the value of the structOrga property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the structOrga property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStructOrga().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link StructOrgaType }
     * 
     * 
     */
    public List<StructOrgaType> getStructOrga() {
        if (structOrga == null) {
            structOrga = new ArrayList<StructOrgaType>();
        }
        return this.structOrga;
    }

    /**
     * Gets the value of the activitePartnrt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the activitePartnrt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getActivitePartnrt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ActivitePartnrtType }
     * 
     * 
     */
    public List<ActivitePartnrtType> getActivitePartnrt() {
        if (activitePartnrt == null) {
            activitePartnrt = new ArrayList<ActivitePartnrtType>();
        }
        return this.activitePartnrt;
    }

}
