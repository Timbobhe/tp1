
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentSiloContrat" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentContratPere" minOccurs="0"/>
 *         &lt;element name="libContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeBrcheAssur" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libBrcheAssur" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeBrcheAssurSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libBrcheAssurSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratType", propOrder = {
    "identSiloContrat",
    "identContratPere",
    "libContrat",
    "codeNatContrat",
    "libNatContrat",
    "codeNatContratSilo",
    "libNatContratSilo",
    "codeBrcheAssur",
    "libBrcheAssur",
    "codeBrcheAssurSilo",
    "libBrcheAssurSilo"
})
public class IdentContratType {

    @XmlElement(name = "IdentSiloContrat")
    protected IdentSiloType identSiloContrat;
    @XmlElement(name = "IdentContratPere")
    protected IdentContratPereType identContratPere;
    protected String libContrat;
    protected String codeNatContrat;
    protected String libNatContrat;
    protected String codeNatContratSilo;
    protected String libNatContratSilo;
    protected String codeBrcheAssur;
    protected String libBrcheAssur;
    protected String codeBrcheAssurSilo;
    protected String libBrcheAssurSilo;

    /**
     * Obtient la valeur de la propriété identSiloContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloContrat() {
        return identSiloContrat;
    }

    /**
     * Définit la valeur de la propriété identSiloContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloContrat(IdentSiloType value) {
        this.identSiloContrat = value;
    }

    /**
     * Obtient la valeur de la propriété identContratPere.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratPereType }
     *     
     */
    public IdentContratPereType getIdentContratPere() {
        return identContratPere;
    }

    /**
     * Définit la valeur de la propriété identContratPere.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratPereType }
     *     
     */
    public void setIdentContratPere(IdentContratPereType value) {
        this.identContratPere = value;
    }

    /**
     * Obtient la valeur de la propriété libContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContrat() {
        return libContrat;
    }

    /**
     * Définit la valeur de la propriété libContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContrat(String value) {
        this.libContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatContrat() {
        return codeNatContrat;
    }

    /**
     * Définit la valeur de la propriété codeNatContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatContrat(String value) {
        this.codeNatContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libNatContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatContrat() {
        return libNatContrat;
    }

    /**
     * Définit la valeur de la propriété libNatContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatContrat(String value) {
        this.libNatContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatContratSilo() {
        return codeNatContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeNatContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatContratSilo(String value) {
        this.codeNatContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libNatContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatContratSilo() {
        return libNatContratSilo;
    }

    /**
     * Définit la valeur de la propriété libNatContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatContratSilo(String value) {
        this.libNatContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrcheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrcheAssur() {
        return codeBrcheAssur;
    }

    /**
     * Définit la valeur de la propriété codeBrcheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrcheAssur(String value) {
        this.codeBrcheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété libBrcheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibBrcheAssur() {
        return libBrcheAssur;
    }

    /**
     * Définit la valeur de la propriété libBrcheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibBrcheAssur(String value) {
        this.libBrcheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrcheAssurSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrcheAssurSilo() {
        return codeBrcheAssurSilo;
    }

    /**
     * Définit la valeur de la propriété codeBrcheAssurSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrcheAssurSilo(String value) {
        this.codeBrcheAssurSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libBrcheAssurSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibBrcheAssurSilo() {
        return libBrcheAssurSilo;
    }

    /**
     * Définit la valeur de la propriété libBrcheAssurSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibBrcheAssurSilo(String value) {
        this.libBrcheAssurSilo = value;
    }

}
