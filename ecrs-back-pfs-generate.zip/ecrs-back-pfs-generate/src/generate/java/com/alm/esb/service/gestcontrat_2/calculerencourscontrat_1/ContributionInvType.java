
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContributionInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContributionInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="identifiantContributionInvestissement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeContributionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libContributionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeContributionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libContributionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txRepartitionContribution" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicTxDerogeableContributionInv" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContributionInvType", propOrder = {
    "identifiantContributionInvestissement",
    "codeContributionInv",
    "libContributionInv",
    "codeContributionInvSilo",
    "libContributionInvSilo",
    "txRepartitionContribution",
    "indicTxDerogeableContributionInv"
})
public class ContributionInvType {

    protected String identifiantContributionInvestissement;
    protected String codeContributionInv;
    protected String libContributionInv;
    protected String codeContributionInvSilo;
    protected String libContributionInvSilo;
    protected BigDecimal txRepartitionContribution;
    protected Boolean indicTxDerogeableContributionInv;

    /**
     * Obtient la valeur de la propriété identifiantContributionInvestissement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifiantContributionInvestissement() {
        return identifiantContributionInvestissement;
    }

    /**
     * Définit la valeur de la propriété identifiantContributionInvestissement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifiantContributionInvestissement(String value) {
        this.identifiantContributionInvestissement = value;
    }

    /**
     * Obtient la valeur de la propriété codeContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeContributionInv() {
        return codeContributionInv;
    }

    /**
     * Définit la valeur de la propriété codeContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeContributionInv(String value) {
        this.codeContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété libContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContributionInv() {
        return libContributionInv;
    }

    /**
     * Définit la valeur de la propriété libContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContributionInv(String value) {
        this.libContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeContributionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeContributionInvSilo() {
        return codeContributionInvSilo;
    }

    /**
     * Définit la valeur de la propriété codeContributionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeContributionInvSilo(String value) {
        this.codeContributionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libContributionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContributionInvSilo() {
        return libContributionInvSilo;
    }

    /**
     * Définit la valeur de la propriété libContributionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContributionInvSilo(String value) {
        this.libContributionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété txRepartitionContribution.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRepartitionContribution() {
        return txRepartitionContribution;
    }

    /**
     * Définit la valeur de la propriété txRepartitionContribution.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRepartitionContribution(BigDecimal value) {
        this.txRepartitionContribution = value;
    }

    /**
     * Obtient la valeur de la propriété indicTxDerogeableContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicTxDerogeableContributionInv() {
        return indicTxDerogeableContributionInv;
    }

    /**
     * Définit la valeur de la propriété indicTxDerogeableContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicTxDerogeableContributionInv(Boolean value) {
        this.indicTxDerogeableContributionInv = value;
    }

}
