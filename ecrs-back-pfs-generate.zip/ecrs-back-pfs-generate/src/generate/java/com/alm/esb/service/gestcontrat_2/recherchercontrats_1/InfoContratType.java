
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSituationContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSituationContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numExterneContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idPortefeuilleContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoContratType", propOrder = {
    "dateEffet",
    "codeSituationContrat",
    "libSituationContrat",
    "numExterneContrat",
    "idPortefeuilleContrat"
})
public class InfoContratType {

    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffet;
    protected String codeSituationContrat;
    protected String libSituationContrat;
    protected String numExterneContrat;
    protected String idPortefeuilleContrat;

    /**
     * Obtient la valeur de la propriété dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffet() {
        return dateEffet;
    }

    /**
     * Définit la valeur de la propriété dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffet(XMLGregorianCalendar value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propriété codeSituationContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSituationContrat() {
        return codeSituationContrat;
    }

    /**
     * Définit la valeur de la propriété codeSituationContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSituationContrat(String value) {
        this.codeSituationContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libSituationContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSituationContrat() {
        return libSituationContrat;
    }

    /**
     * Définit la valeur de la propriété libSituationContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSituationContrat(String value) {
        this.libSituationContrat = value;
    }

    /**
     * Obtient la valeur de la propriété numExterneContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumExterneContrat() {
        return numExterneContrat;
    }

    /**
     * Définit la valeur de la propriété numExterneContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumExterneContrat(String value) {
        this.numExterneContrat = value;
    }

    /**
     * Obtient la valeur de la propriété idPortefeuilleContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdPortefeuilleContrat() {
        return idPortefeuilleContrat;
    }

    /**
     * Définit la valeur de la propriété idPortefeuilleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdPortefeuilleContrat(String value) {
        this.idPortefeuilleContrat = value;
    }

}
