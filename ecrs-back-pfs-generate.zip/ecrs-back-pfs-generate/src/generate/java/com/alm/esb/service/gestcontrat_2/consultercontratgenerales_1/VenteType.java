
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour VenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="VenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dirRgial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSect" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "VenteType", propOrder = {
    "dirRgial",
    "codeSect"
})
public class VenteType {

    protected String dirRgial;
    protected String codeSect;

    /**
     * Obtient la valeur de la propriété dirRgial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDirRgial() {
        return dirRgial;
    }

    /**
     * Définit la valeur de la propriété dirRgial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDirRgial(String value) {
        this.dirRgial = value;
    }

    /**
     * Obtient la valeur de la propriété codeSect.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSect() {
        return codeSect;
    }

    /**
     * Définit la valeur de la propriété codeSect.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSect(String value) {
        this.codeSect = value;
    }

}
