
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterClausesBenefCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterClausesBenefCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}IdentCtrSilo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterClausesBenefCtrType", propOrder = {
    "identCtrSilo"
})
public class ConsulterClausesBenefCtrType {

    @XmlElement(name = "IdentCtrSilo")
    protected IdentificationContratSiloType identCtrSilo;

    /**
     * Obtient la valeur de la propriété identCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationContratSiloType }
     *     
     */
    public IdentificationContratSiloType getIdentCtrSilo() {
        return identCtrSilo;
    }

    /**
     * Définit la valeur de la propriété identCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationContratSiloType }
     *     
     */
    public void setIdentCtrSilo(IdentificationContratSiloType value) {
        this.identCtrSilo = value;
    }

}
