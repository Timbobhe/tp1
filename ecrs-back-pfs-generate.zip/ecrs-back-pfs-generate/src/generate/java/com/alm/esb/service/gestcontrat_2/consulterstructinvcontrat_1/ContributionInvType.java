
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContributionInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContributionInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idContributionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeContributionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libContributionInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeContributionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libContributionInvSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionContribution" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicateurTauxDerogeableContributionInv" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionContributionDefaut" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContributionInvType", propOrder = {
    "idContributionInv",
    "codeContributionInv",
    "libContributionInv",
    "codeContributionInvSilo",
    "libContributionInvSilo",
    "tauxRepartitionContribution",
    "indicateurTauxDerogeableContributionInv",
    "tauxRepartitionContributionDefaut"
})
public class ContributionInvType {

    protected String idContributionInv;
    protected String codeContributionInv;
    protected String libContributionInv;
    protected String codeContributionInvSilo;
    protected String libContributionInvSilo;
    protected BigDecimal tauxRepartitionContribution;
    protected Boolean indicateurTauxDerogeableContributionInv;
    protected BigDecimal tauxRepartitionContributionDefaut;

    /**
     * Obtient la valeur de la propriété idContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdContributionInv() {
        return idContributionInv;
    }

    /**
     * Définit la valeur de la propriété idContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdContributionInv(String value) {
        this.idContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeContributionInv() {
        return codeContributionInv;
    }

    /**
     * Définit la valeur de la propriété codeContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeContributionInv(String value) {
        this.codeContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété libContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContributionInv() {
        return libContributionInv;
    }

    /**
     * Définit la valeur de la propriété libContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContributionInv(String value) {
        this.libContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeContributionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeContributionInvSilo() {
        return codeContributionInvSilo;
    }

    /**
     * Définit la valeur de la propriété codeContributionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeContributionInvSilo(String value) {
        this.codeContributionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libContributionInvSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContributionInvSilo() {
        return libContributionInvSilo;
    }

    /**
     * Définit la valeur de la propriété libContributionInvSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContributionInvSilo(String value) {
        this.libContributionInvSilo = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionContribution.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionContribution() {
        return tauxRepartitionContribution;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionContribution.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionContribution(BigDecimal value) {
        this.tauxRepartitionContribution = value;
    }

    /**
     * Obtient la valeur de la propriété indicateurTauxDerogeableContributionInv.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicateurTauxDerogeableContributionInv() {
        return indicateurTauxDerogeableContributionInv;
    }

    /**
     * Définit la valeur de la propriété indicateurTauxDerogeableContributionInv.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicateurTauxDerogeableContributionInv(Boolean value) {
        this.indicateurTauxDerogeableContributionInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionContributionDefaut.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionContributionDefaut() {
        return tauxRepartitionContributionDefaut;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionContributionDefaut.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionContributionDefaut(BigDecimal value) {
        this.tauxRepartitionContributionDefaut = value;
    }

}
