
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour DossComType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="DossComType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeRoleComm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codePaysIso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPaysIso" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DossComType", propOrder = {
    "codeRoleComm",
    "codePaysIso",
    "libPaysIso"
})
public class DossComType {

    protected String codeRoleComm;
    protected String codePaysIso;
    protected String libPaysIso;

    /**
     * Obtient la valeur de la propriété codeRoleComm.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRoleComm() {
        return codeRoleComm;
    }

    /**
     * Définit la valeur de la propriété codeRoleComm.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRoleComm(String value) {
        this.codeRoleComm = value;
    }

    /**
     * Obtient la valeur de la propriété codePaysIso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePaysIso() {
        return codePaysIso;
    }

    /**
     * Définit la valeur de la propriété codePaysIso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePaysIso(String value) {
        this.codePaysIso = value;
    }

    /**
     * Obtient la valeur de la propriété libPaysIso.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPaysIso() {
        return libPaysIso;
    }

    /**
     * Définit la valeur de la propriété libPaysIso.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPaysIso(String value) {
        this.libPaysIso = value;
    }

}
