
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdOfrSousctnType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdOfrSousctnType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeAppli" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdOfrSousctnType", propOrder = {
    "idSilo",
    "codeAppli"
})
public class IdOfrSousctnType {

    protected String idSilo;
    protected String codeAppli;

    /**
     * Obtient la valeur de la propriété idSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSilo() {
        return idSilo;
    }

    /**
     * Définit la valeur de la propriété idSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSilo(String value) {
        this.idSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAppli() {
        return codeAppli;
    }

    /**
     * Définit la valeur de la propriété codeAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAppli(String value) {
        this.codeAppli = value;
    }

}
