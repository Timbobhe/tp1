
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour GrilleInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GrilleInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idGrilleInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomGrilleInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txRepartitionGrilleInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicTxDerogeableGrilleInv" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GrilleInvType", propOrder = {
    "idGrilleInv",
    "nomGrilleInv",
    "txRepartitionGrilleInv",
    "indicTxDerogeableGrilleInv"
})
public class GrilleInvType {

    protected String idGrilleInv;
    protected String nomGrilleInv;
    protected BigDecimal txRepartitionGrilleInv;
    protected Boolean indicTxDerogeableGrilleInv;

    /**
     * Obtient la valeur de la propriété idGrilleInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdGrilleInv() {
        return idGrilleInv;
    }

    /**
     * Définit la valeur de la propriété idGrilleInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdGrilleInv(String value) {
        this.idGrilleInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomGrilleInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomGrilleInv() {
        return nomGrilleInv;
    }

    /**
     * Définit la valeur de la propriété nomGrilleInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomGrilleInv(String value) {
        this.nomGrilleInv = value;
    }

    /**
     * Obtient la valeur de la propriété txRepartitionGrilleInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRepartitionGrilleInv() {
        return txRepartitionGrilleInv;
    }

    /**
     * Définit la valeur de la propriété txRepartitionGrilleInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRepartitionGrilleInv(BigDecimal value) {
        this.txRepartitionGrilleInv = value;
    }

    /**
     * Obtient la valeur de la propriété indicTxDerogeableGrilleInv.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicTxDerogeableGrilleInv() {
        return indicTxDerogeableGrilleInv;
    }

    /**
     * Définit la valeur de la propriété indicTxDerogeableGrilleInv.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicTxDerogeableGrilleInv(Boolean value) {
        this.indicTxDerogeableGrilleInv = value;
    }

}
