
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numUE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateEmis" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCtrSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeFiscEpargne" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libFiscEpargne" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeFiscEpargneSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeChainCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeChainCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeGestSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdentCtrSrc" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentCtrSrcType" minOccurs="0"/>
 *         &lt;element name="codeCpteGestCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCpteGestCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeOptFiscaliteAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOptFiscaliteAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numExtCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idPortfCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomPortfCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="motifFin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateChain" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="indGestRepartie" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indCtrResponsable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="nivPrisChrg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="comZLS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeOriCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateMigrCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateCreatCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateReceptCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateNotifSS" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="Ctntx" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtntxType" minOccurs="0"/>
 *         &lt;element name="briqueUROrigine" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateMigrationCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateTermeCtr" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="etatCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoCtrType", propOrder = {
    "numUE",
    "dateEffet",
    "dateFinEffet",
    "dateEmis",
    "codeSitCtr",
    "libSitCtr",
    "codeSitCtrSilo",
    "libSitContratSilo",
    "dateSitCtr",
    "codeFiscEpargne",
    "libFiscEpargne",
    "codeFiscEpargneSilo",
    "typeChainCtrRef",
    "libTypeChainCtrRef",
    "codeModeGest",
    "libModeGest",
    "codeModeGestSilo",
    "idCtrRef",
    "libCtrRef",
    "identCtrSrc",
    "codeCpteGestCotis",
    "libCpteGestCotis",
    "codeOptFiscaliteAffil",
    "libOptFiscaliteAffil",
    "numExtCtr",
    "idPortfCtr",
    "nomPortfCtr",
    "motifFin",
    "dateChain",
    "indGestRepartie",
    "indCtrResponsable",
    "nivPrisChrg",
    "comZLS",
    "codeOriCtr",
    "dateMigrCtr",
    "dateCreatCtr",
    "dateReceptCtr",
    "dateNotifSS",
    "ctntx",
    "briqueUROrigine",
    "dateMigrationCtr",
    "dateTermeCtr",
    "etatCtr"
})
public class InfoCtrType {

    protected String numUE;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEmis;
    protected String codeSitCtr;
    protected String libSitCtr;
    protected String codeSitCtrSilo;
    protected String libSitContratSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitCtr;
    protected String codeFiscEpargne;
    protected String libFiscEpargne;
    protected String codeFiscEpargneSilo;
    protected String typeChainCtrRef;
    protected String libTypeChainCtrRef;
    protected String codeModeGest;
    protected String libModeGest;
    protected String codeModeGestSilo;
    protected String idCtrRef;
    protected String libCtrRef;
    @XmlElement(name = "IdentCtrSrc")
    protected IdentCtrSrcType identCtrSrc;
    protected String codeCpteGestCotis;
    protected String libCpteGestCotis;
    protected String codeOptFiscaliteAffil;
    protected String libOptFiscaliteAffil;
    protected String numExtCtr;
    protected String idPortfCtr;
    protected String nomPortfCtr;
    protected String motifFin;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateChain;
    protected Boolean indGestRepartie;
    protected Boolean indCtrResponsable;
    protected String nivPrisChrg;
    protected String comZLS;
    protected String codeOriCtr;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateMigrCtr;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateCreatCtr;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateReceptCtr;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateNotifSS;
    @XmlElement(name = "Ctntx")
    protected CtntxType ctntx;
    protected String briqueUROrigine;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateMigrationCtr;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateTermeCtr;
    protected String etatCtr;

    /**
     * Obtient la valeur de la propriété numUE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumUE() {
        return numUE;
    }

    /**
     * Définit la valeur de la propriété numUE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumUE(String value) {
        this.numUE = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffet() {
        return dateEffet;
    }

    /**
     * Définit la valeur de la propriété dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffet(XMLGregorianCalendar value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffet() {
        return dateFinEffet;
    }

    /**
     * Définit la valeur de la propriété dateFinEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffet(XMLGregorianCalendar value) {
        this.dateFinEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateEmis.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEmis() {
        return dateEmis;
    }

    /**
     * Définit la valeur de la propriété dateEmis.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEmis(XMLGregorianCalendar value) {
        this.dateEmis = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCtr() {
        return codeSitCtr;
    }

    /**
     * Définit la valeur de la propriété codeSitCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCtr(String value) {
        this.codeSitCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCtr() {
        return libSitCtr;
    }

    /**
     * Définit la valeur de la propriété libSitCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCtr(String value) {
        this.libSitCtr = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCtrSilo() {
        return codeSitCtrSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCtrSilo(String value) {
        this.codeSitCtrSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libSitContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitContratSilo() {
        return libSitContratSilo;
    }

    /**
     * Définit la valeur de la propriété libSitContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitContratSilo(String value) {
        this.libSitContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitCtr() {
        return dateSitCtr;
    }

    /**
     * Définit la valeur de la propriété dateSitCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitCtr(XMLGregorianCalendar value) {
        this.dateSitCtr = value;
    }

    /**
     * Obtient la valeur de la propriété codeFiscEpargne.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFiscEpargne() {
        return codeFiscEpargne;
    }

    /**
     * Définit la valeur de la propriété codeFiscEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFiscEpargne(String value) {
        this.codeFiscEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété libFiscEpargne.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibFiscEpargne() {
        return libFiscEpargne;
    }

    /**
     * Définit la valeur de la propriété libFiscEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibFiscEpargne(String value) {
        this.libFiscEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété codeFiscEpargneSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFiscEpargneSilo() {
        return codeFiscEpargneSilo;
    }

    /**
     * Définit la valeur de la propriété codeFiscEpargneSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFiscEpargneSilo(String value) {
        this.codeFiscEpargneSilo = value;
    }

    /**
     * Obtient la valeur de la propriété typeChainCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeChainCtrRef() {
        return typeChainCtrRef;
    }

    /**
     * Définit la valeur de la propriété typeChainCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeChainCtrRef(String value) {
        this.typeChainCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeChainCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeChainCtrRef() {
        return libTypeChainCtrRef;
    }

    /**
     * Définit la valeur de la propriété libTypeChainCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeChainCtrRef(String value) {
        this.libTypeChainCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGest() {
        return codeModeGest;
    }

    /**
     * Définit la valeur de la propriété codeModeGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGest(String value) {
        this.codeModeGest = value;
    }

    /**
     * Obtient la valeur de la propriété libModeGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeGest() {
        return libModeGest;
    }

    /**
     * Définit la valeur de la propriété libModeGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeGest(String value) {
        this.libModeGest = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGestSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGestSilo() {
        return codeModeGestSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeGestSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGestSilo(String value) {
        this.codeModeGestSilo = value;
    }

    /**
     * Obtient la valeur de la propriété idCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCtrRef() {
        return idCtrRef;
    }

    /**
     * Définit la valeur de la propriété idCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCtrRef(String value) {
        this.idCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété libCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCtrRef() {
        return libCtrRef;
    }

    /**
     * Définit la valeur de la propriété libCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCtrRef(String value) {
        this.libCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété identCtrSrc.
     * 
     * @return
     *     possible object is
     *     {@link IdentCtrSrcType }
     *     
     */
    public IdentCtrSrcType getIdentCtrSrc() {
        return identCtrSrc;
    }

    /**
     * Définit la valeur de la propriété identCtrSrc.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentCtrSrcType }
     *     
     */
    public void setIdentCtrSrc(IdentCtrSrcType value) {
        this.identCtrSrc = value;
    }

    /**
     * Obtient la valeur de la propriété codeCpteGestCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCpteGestCotis() {
        return codeCpteGestCotis;
    }

    /**
     * Définit la valeur de la propriété codeCpteGestCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCpteGestCotis(String value) {
        this.codeCpteGestCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libCpteGestCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCpteGestCotis() {
        return libCpteGestCotis;
    }

    /**
     * Définit la valeur de la propriété libCpteGestCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCpteGestCotis(String value) {
        this.libCpteGestCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeOptFiscaliteAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOptFiscaliteAffil() {
        return codeOptFiscaliteAffil;
    }

    /**
     * Définit la valeur de la propriété codeOptFiscaliteAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOptFiscaliteAffil(String value) {
        this.codeOptFiscaliteAffil = value;
    }

    /**
     * Obtient la valeur de la propriété libOptFiscaliteAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOptFiscaliteAffil() {
        return libOptFiscaliteAffil;
    }

    /**
     * Définit la valeur de la propriété libOptFiscaliteAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOptFiscaliteAffil(String value) {
        this.libOptFiscaliteAffil = value;
    }

    /**
     * Obtient la valeur de la propriété numExtCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumExtCtr() {
        return numExtCtr;
    }

    /**
     * Définit la valeur de la propriété numExtCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumExtCtr(String value) {
        this.numExtCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idPortfCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdPortfCtr() {
        return idPortfCtr;
    }

    /**
     * Définit la valeur de la propriété idPortfCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdPortfCtr(String value) {
        this.idPortfCtr = value;
    }

    /**
     * Obtient la valeur de la propriété nomPortfCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomPortfCtr() {
        return nomPortfCtr;
    }

    /**
     * Définit la valeur de la propriété nomPortfCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomPortfCtr(String value) {
        this.nomPortfCtr = value;
    }

    /**
     * Obtient la valeur de la propriété motifFin.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifFin() {
        return motifFin;
    }

    /**
     * Définit la valeur de la propriété motifFin.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifFin(String value) {
        this.motifFin = value;
    }

    /**
     * Obtient la valeur de la propriété dateChain.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateChain() {
        return dateChain;
    }

    /**
     * Définit la valeur de la propriété dateChain.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateChain(XMLGregorianCalendar value) {
        this.dateChain = value;
    }

    /**
     * Obtient la valeur de la propriété indGestRepartie.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndGestRepartie() {
        return indGestRepartie;
    }

    /**
     * Définit la valeur de la propriété indGestRepartie.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndGestRepartie(Boolean value) {
        this.indGestRepartie = value;
    }

    /**
     * Obtient la valeur de la propriété indCtrResponsable.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndCtrResponsable() {
        return indCtrResponsable;
    }

    /**
     * Définit la valeur de la propriété indCtrResponsable.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndCtrResponsable(Boolean value) {
        this.indCtrResponsable = value;
    }

    /**
     * Obtient la valeur de la propriété nivPrisChrg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNivPrisChrg() {
        return nivPrisChrg;
    }

    /**
     * Définit la valeur de la propriété nivPrisChrg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNivPrisChrg(String value) {
        this.nivPrisChrg = value;
    }

    /**
     * Obtient la valeur de la propriété comZLS.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComZLS() {
        return comZLS;
    }

    /**
     * Définit la valeur de la propriété comZLS.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComZLS(String value) {
        this.comZLS = value;
    }

    /**
     * Obtient la valeur de la propriété codeOriCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOriCtr() {
        return codeOriCtr;
    }

    /**
     * Définit la valeur de la propriété codeOriCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOriCtr(String value) {
        this.codeOriCtr = value;
    }

    /**
     * Obtient la valeur de la propriété dateMigrCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateMigrCtr() {
        return dateMigrCtr;
    }

    /**
     * Définit la valeur de la propriété dateMigrCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateMigrCtr(XMLGregorianCalendar value) {
        this.dateMigrCtr = value;
    }

    /**
     * Obtient la valeur de la propriété dateCreatCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateCreatCtr() {
        return dateCreatCtr;
    }

    /**
     * Définit la valeur de la propriété dateCreatCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateCreatCtr(XMLGregorianCalendar value) {
        this.dateCreatCtr = value;
    }

    /**
     * Obtient la valeur de la propriété dateReceptCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateReceptCtr() {
        return dateReceptCtr;
    }

    /**
     * Définit la valeur de la propriété dateReceptCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateReceptCtr(XMLGregorianCalendar value) {
        this.dateReceptCtr = value;
    }

    /**
     * Obtient la valeur de la propriété dateNotifSS.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateNotifSS() {
        return dateNotifSS;
    }

    /**
     * Définit la valeur de la propriété dateNotifSS.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateNotifSS(XMLGregorianCalendar value) {
        this.dateNotifSS = value;
    }

    /**
     * Obtient la valeur de la propriété ctntx.
     * 
     * @return
     *     possible object is
     *     {@link CtntxType }
     *     
     */
    public CtntxType getCtntx() {
        return ctntx;
    }

    /**
     * Définit la valeur de la propriété ctntx.
     * 
     * @param value
     *     allowed object is
     *     {@link CtntxType }
     *     
     */
    public void setCtntx(CtntxType value) {
        this.ctntx = value;
    }

    /**
     * Obtient la valeur de la propriété briqueUROrigine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBriqueUROrigine() {
        return briqueUROrigine;
    }

    /**
     * Définit la valeur de la propriété briqueUROrigine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBriqueUROrigine(String value) {
        this.briqueUROrigine = value;
    }

    /**
     * Obtient la valeur de la propriété dateMigrationCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateMigrationCtr() {
        return dateMigrationCtr;
    }

    /**
     * Définit la valeur de la propriété dateMigrationCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateMigrationCtr(XMLGregorianCalendar value) {
        this.dateMigrationCtr = value;
    }

    /**
     * Obtient la valeur de la propriété dateTermeCtr.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateTermeCtr() {
        return dateTermeCtr;
    }

    /**
     * Définit la valeur de la propriété dateTermeCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateTermeCtr(XMLGregorianCalendar value) {
        this.dateTermeCtr = value;
    }

    /**
     * Obtient la valeur de la propriété etatCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEtatCtr() {
        return etatCtr;
    }

    /**
     * Définit la valeur de la propriété etatCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEtatCtr(String value) {
        this.etatCtr = value;
    }

}
