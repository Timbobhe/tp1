
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AssurePrincipalType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AssurePrincipalType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}IdentSiloAssurPrinc" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}SignaletiquePPAssurPrinc" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssurePrincipalType", propOrder = {
    "identSiloAssurPrinc",
    "signaletiquePPAssurPrinc"
})
public class AssurePrincipalType {

    @XmlElement(name = "IdentSiloAssurPrinc")
    protected IdentSiloType identSiloAssurPrinc;
    @XmlElement(name = "SignaletiquePPAssurPrinc")
    protected SignaletiquePPType2 signaletiquePPAssurPrinc;

    /**
     * Obtient la valeur de la propriété identSiloAssurPrinc.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloAssurPrinc() {
        return identSiloAssurPrinc;
    }

    /**
     * Définit la valeur de la propriété identSiloAssurPrinc.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloAssurPrinc(IdentSiloType value) {
        this.identSiloAssurPrinc = value;
    }

    /**
     * Obtient la valeur de la propriété signaletiquePPAssurPrinc.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiquePPType2 }
     *     
     */
    public SignaletiquePPType2 getSignaletiquePPAssurPrinc() {
        return signaletiquePPAssurPrinc;
    }

    /**
     * Définit la valeur de la propriété signaletiquePPAssurPrinc.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiquePPType2 }
     *     
     */
    public void setSignaletiquePPAssurPrinc(SignaletiquePPType2 value) {
        this.signaletiquePPAssurPrinc = value;
    }

}
