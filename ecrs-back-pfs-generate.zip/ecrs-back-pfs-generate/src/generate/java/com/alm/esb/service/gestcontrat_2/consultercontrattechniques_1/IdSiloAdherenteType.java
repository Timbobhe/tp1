
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdSiloAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdSiloAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdSilo" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IdSiloParamType" minOccurs="0"/>
 *         &lt;element name="libNomSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeApplication" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libApplication" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSystemeInformation" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libSystemeInformation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdSiloAdherenteType", propOrder = {
    "idSilo",
    "libNomSilo",
    "codeApplication",
    "libApplication",
    "codeSystemeInformation",
    "libSystemeInformation"
})
public class IdSiloAdherenteType {

    @XmlElement(name = "IdSilo")
    protected IdSiloParamType idSilo;
    protected String libNomSilo;
    @XmlElement(required = true)
    protected String codeApplication;
    protected String libApplication;
    @XmlElement(required = true)
    protected String codeSystemeInformation;
    protected String libSystemeInformation;

    /**
     * Obtient la valeur de la propriété idSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloParamType }
     *     
     */
    public IdSiloParamType getIdSilo() {
        return idSilo;
    }

    /**
     * Définit la valeur de la propriété idSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloParamType }
     *     
     */
    public void setIdSilo(IdSiloParamType value) {
        this.idSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libNomSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNomSilo() {
        return libNomSilo;
    }

    /**
     * Définit la valeur de la propriété libNomSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNomSilo(String value) {
        this.libNomSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeApplication.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeApplication() {
        return codeApplication;
    }

    /**
     * Définit la valeur de la propriété codeApplication.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeApplication(String value) {
        this.codeApplication = value;
    }

    /**
     * Obtient la valeur de la propriété libApplication.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibApplication() {
        return libApplication;
    }

    /**
     * Définit la valeur de la propriété libApplication.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibApplication(String value) {
        this.libApplication = value;
    }

    /**
     * Obtient la valeur de la propriété codeSystemeInformation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSystemeInformation() {
        return codeSystemeInformation;
    }

    /**
     * Définit la valeur de la propriété codeSystemeInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSystemeInformation(String value) {
        this.codeSystemeInformation = value;
    }

    /**
     * Obtient la valeur de la propriété libSystemeInformation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSystemeInformation() {
        return libSystemeInformation;
    }

    /**
     * Définit la valeur de la propriété libSystemeInformation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSystemeInformation(String value) {
        this.libSystemeInformation = value;
    }

}
