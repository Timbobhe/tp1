
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour MajrtRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="MajrtRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeComplementRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleTypeComplementRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantMajoration" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeDeviseMontantMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleDeviseMontantMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxMajoration" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateDebutApplicationMajoration" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinApplicationMajoration" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateProchainPaiementMajoration" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codePeriodiciteMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libellePeriodiciteMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleTypeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeAssietteCalculTauxMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleAssietteCalculTauxMajoration" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="InfoPrelevementSocial" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}InfoPrelevSoclType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "MajrtRenteType", propOrder = {
    "codeMajoration",
    "libelleMajoration",
    "typeComplementRente",
    "libelleTypeComplementRente",
    "montantMajoration",
    "codeDeviseMontantMajoration",
    "libelleDeviseMontantMajoration",
    "tauxMajoration",
    "dateDebutApplicationMajoration",
    "dateFinApplicationMajoration",
    "dateProchainPaiementMajoration",
    "codePeriodiciteMajoration",
    "libellePeriodiciteMajoration",
    "codeTypeRevalorisation",
    "libelleTypeRevalorisation",
    "codeAssietteCalculTauxMajoration",
    "libelleAssietteCalculTauxMajoration",
    "infoPrelevementSocial"
})
public class MajrtRenteType {

    protected String codeMajoration;
    protected String libelleMajoration;
    protected String typeComplementRente;
    protected String libelleTypeComplementRente;
    protected BigDecimal montantMajoration;
    protected String codeDeviseMontantMajoration;
    protected String libelleDeviseMontantMajoration;
    protected BigDecimal tauxMajoration;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutApplicationMajoration;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinApplicationMajoration;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchainPaiementMajoration;
    protected String codePeriodiciteMajoration;
    protected String libellePeriodiciteMajoration;
    protected String codeTypeRevalorisation;
    protected String libelleTypeRevalorisation;
    protected String codeAssietteCalculTauxMajoration;
    protected String libelleAssietteCalculTauxMajoration;
    @XmlElement(name = "InfoPrelevementSocial")
    protected List<InfoPrelevSoclType> infoPrelevementSocial;

    /**
     * Obtient la valeur de la propriété codeMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMajoration() {
        return codeMajoration;
    }

    /**
     * Définit la valeur de la propriété codeMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMajoration(String value) {
        this.codeMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété libelleMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleMajoration() {
        return libelleMajoration;
    }

    /**
     * Définit la valeur de la propriété libelleMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleMajoration(String value) {
        this.libelleMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété typeComplementRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeComplementRente() {
        return typeComplementRente;
    }

    /**
     * Définit la valeur de la propriété typeComplementRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeComplementRente(String value) {
        this.typeComplementRente = value;
    }

    /**
     * Obtient la valeur de la propriété libelleTypeComplementRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleTypeComplementRente() {
        return libelleTypeComplementRente;
    }

    /**
     * Définit la valeur de la propriété libelleTypeComplementRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleTypeComplementRente(String value) {
        this.libelleTypeComplementRente = value;
    }

    /**
     * Obtient la valeur de la propriété montantMajoration.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantMajoration() {
        return montantMajoration;
    }

    /**
     * Définit la valeur de la propriété montantMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantMajoration(BigDecimal value) {
        this.montantMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseMontantMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseMontantMajoration() {
        return codeDeviseMontantMajoration;
    }

    /**
     * Définit la valeur de la propriété codeDeviseMontantMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseMontantMajoration(String value) {
        this.codeDeviseMontantMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété libelleDeviseMontantMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleDeviseMontantMajoration() {
        return libelleDeviseMontantMajoration;
    }

    /**
     * Définit la valeur de la propriété libelleDeviseMontantMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleDeviseMontantMajoration(String value) {
        this.libelleDeviseMontantMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété tauxMajoration.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxMajoration() {
        return tauxMajoration;
    }

    /**
     * Définit la valeur de la propriété tauxMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxMajoration(BigDecimal value) {
        this.tauxMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutApplicationMajoration.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutApplicationMajoration() {
        return dateDebutApplicationMajoration;
    }

    /**
     * Définit la valeur de la propriété dateDebutApplicationMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutApplicationMajoration(XMLGregorianCalendar value) {
        this.dateDebutApplicationMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinApplicationMajoration.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinApplicationMajoration() {
        return dateFinApplicationMajoration;
    }

    /**
     * Définit la valeur de la propriété dateFinApplicationMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinApplicationMajoration(XMLGregorianCalendar value) {
        this.dateFinApplicationMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchainPaiementMajoration.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchainPaiementMajoration() {
        return dateProchainPaiementMajoration;
    }

    /**
     * Définit la valeur de la propriété dateProchainPaiementMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchainPaiementMajoration(XMLGregorianCalendar value) {
        this.dateProchainPaiementMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété codePeriodiciteMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodiciteMajoration() {
        return codePeriodiciteMajoration;
    }

    /**
     * Définit la valeur de la propriété codePeriodiciteMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodiciteMajoration(String value) {
        this.codePeriodiciteMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété libellePeriodiciteMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibellePeriodiciteMajoration() {
        return libellePeriodiciteMajoration;
    }

    /**
     * Définit la valeur de la propriété libellePeriodiciteMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibellePeriodiciteMajoration(String value) {
        this.libellePeriodiciteMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeRevalorisation() {
        return codeTypeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété codeTypeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeRevalorisation(String value) {
        this.codeTypeRevalorisation = value;
    }

    /**
     * Obtient la valeur de la propriété libelleTypeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleTypeRevalorisation() {
        return libelleTypeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété libelleTypeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleTypeRevalorisation(String value) {
        this.libelleTypeRevalorisation = value;
    }

    /**
     * Obtient la valeur de la propriété codeAssietteCalculTauxMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAssietteCalculTauxMajoration() {
        return codeAssietteCalculTauxMajoration;
    }

    /**
     * Définit la valeur de la propriété codeAssietteCalculTauxMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAssietteCalculTauxMajoration(String value) {
        this.codeAssietteCalculTauxMajoration = value;
    }

    /**
     * Obtient la valeur de la propriété libelleAssietteCalculTauxMajoration.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleAssietteCalculTauxMajoration() {
        return libelleAssietteCalculTauxMajoration;
    }

    /**
     * Définit la valeur de la propriété libelleAssietteCalculTauxMajoration.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleAssietteCalculTauxMajoration(String value) {
        this.libelleAssietteCalculTauxMajoration = value;
    }

    /**
     * Gets the value of the infoPrelevementSocial property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoPrelevementSocial property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoPrelevementSocial().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoPrelevSoclType }
     * 
     * 
     */
    public List<InfoPrelevSoclType> getInfoPrelevementSocial() {
        if (infoPrelevementSocial == null) {
            infoPrelevementSocial = new ArrayList<InfoPrelevSoclType>();
        }
        return this.infoPrelevementSocial;
    }

}
