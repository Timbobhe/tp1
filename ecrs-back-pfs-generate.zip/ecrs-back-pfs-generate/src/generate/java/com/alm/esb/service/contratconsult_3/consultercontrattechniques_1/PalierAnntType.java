
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour PalierAnntType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PalierAnntType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="identifiantPalier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantPalier" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeDeviseMontantPalier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleDeviseMontantPalier" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutPalier" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinPalier" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PalierAnntType", propOrder = {
    "identifiantPalier",
    "montantPalier",
    "codeDeviseMontantPalier",
    "libelleDeviseMontantPalier",
    "dateDebutPalier",
    "dateFinPalier"
})
public class PalierAnntType {

    protected String identifiantPalier;
    protected BigDecimal montantPalier;
    protected String codeDeviseMontantPalier;
    protected String libelleDeviseMontantPalier;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutPalier;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinPalier;

    /**
     * Obtient la valeur de la propriété identifiantPalier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifiantPalier() {
        return identifiantPalier;
    }

    /**
     * Définit la valeur de la propriété identifiantPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifiantPalier(String value) {
        this.identifiantPalier = value;
    }

    /**
     * Obtient la valeur de la propriété montantPalier.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantPalier() {
        return montantPalier;
    }

    /**
     * Définit la valeur de la propriété montantPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantPalier(BigDecimal value) {
        this.montantPalier = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseMontantPalier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseMontantPalier() {
        return codeDeviseMontantPalier;
    }

    /**
     * Définit la valeur de la propriété codeDeviseMontantPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseMontantPalier(String value) {
        this.codeDeviseMontantPalier = value;
    }

    /**
     * Obtient la valeur de la propriété libelleDeviseMontantPalier.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleDeviseMontantPalier() {
        return libelleDeviseMontantPalier;
    }

    /**
     * Définit la valeur de la propriété libelleDeviseMontantPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleDeviseMontantPalier(String value) {
        this.libelleDeviseMontantPalier = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutPalier.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutPalier() {
        return dateDebutPalier;
    }

    /**
     * Définit la valeur de la propriété dateDebutPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutPalier(XMLGregorianCalendar value) {
        this.dateDebutPalier = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinPalier.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinPalier() {
        return dateFinPalier;
    }

    /**
     * Définit la valeur de la propriété dateFinPalier.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinPalier(XMLGregorianCalendar value) {
        this.dateFinPalier = value;
    }

}
