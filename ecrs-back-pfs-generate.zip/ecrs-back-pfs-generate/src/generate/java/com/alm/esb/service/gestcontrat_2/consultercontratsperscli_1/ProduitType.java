
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ProduitType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ProduitType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeProduit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libProduit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ageMaxEnfantMajeur" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMinEnfantMajeur" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProduitType", propOrder = {
    "codeProduit",
    "libProduit",
    "ageMaxEnfantMajeur",
    "ageMinEnfantMajeur"
})
public class ProduitType {

    protected String codeProduit;
    protected String libProduit;
    protected BigInteger ageMaxEnfantMajeur;
    protected BigInteger ageMinEnfantMajeur;

    /**
     * Obtient la valeur de la propriété codeProduit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeProduit() {
        return codeProduit;
    }

    /**
     * Définit la valeur de la propriété codeProduit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeProduit(String value) {
        this.codeProduit = value;
    }

    /**
     * Obtient la valeur de la propriété libProduit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibProduit() {
        return libProduit;
    }

    /**
     * Définit la valeur de la propriété libProduit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibProduit(String value) {
        this.libProduit = value;
    }

    /**
     * Obtient la valeur de la propriété ageMaxEnfantMajeur.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMaxEnfantMajeur() {
        return ageMaxEnfantMajeur;
    }

    /**
     * Définit la valeur de la propriété ageMaxEnfantMajeur.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMaxEnfantMajeur(BigInteger value) {
        this.ageMaxEnfantMajeur = value;
    }

    /**
     * Obtient la valeur de la propriété ageMinEnfantMajeur.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMinEnfantMajeur() {
        return ageMinEnfantMajeur;
    }

    /**
     * Définit la valeur de la propriété ageMinEnfantMajeur.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMinEnfantMajeur(BigInteger value) {
        this.ageMinEnfantMajeur = value;
    }

}
