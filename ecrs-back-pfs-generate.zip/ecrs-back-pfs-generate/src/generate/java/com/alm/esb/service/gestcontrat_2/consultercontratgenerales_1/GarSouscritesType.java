
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour GarSouscritesType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GarSouscritesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeStructCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libStructCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="delaiForfaitaireCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GarSouscritesType", propOrder = {
    "codeStructCotis",
    "libStructCotis",
    "delaiForfaitaireCotis"
})
public class GarSouscritesType {

    protected String codeStructCotis;
    protected String libStructCotis;
    protected String delaiForfaitaireCotis;

    /**
     * Obtient la valeur de la propriété codeStructCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeStructCotis() {
        return codeStructCotis;
    }

    /**
     * Définit la valeur de la propriété codeStructCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeStructCotis(String value) {
        this.codeStructCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libStructCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibStructCotis() {
        return libStructCotis;
    }

    /**
     * Définit la valeur de la propriété libStructCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibStructCotis(String value) {
        this.libStructCotis = value;
    }

    /**
     * Obtient la valeur de la propriété delaiForfaitaireCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDelaiForfaitaireCotis() {
        return delaiForfaitaireCotis;
    }

    /**
     * Définit la valeur de la propriété delaiForfaitaireCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDelaiForfaitaireCotis(String value) {
        this.delaiForfaitaireCotis = value;
    }

}
