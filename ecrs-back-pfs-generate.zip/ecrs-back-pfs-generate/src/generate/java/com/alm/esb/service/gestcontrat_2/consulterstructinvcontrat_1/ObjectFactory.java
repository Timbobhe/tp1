
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConsulterStructInvContratFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", "ConsulterStructInvContratFunc");
    private final static QName _ConsulterStructInvContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", "ConsulterStructInvContrat");
    private final static QName _ConsulterStructInvContratFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", "ConsulterStructInvContratFull");
    private final static QName _ConsulterStructInvContratResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", "ConsulterStructInvContratResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsulterStructInvContratFuncType }
     * 
     */
    public ConsulterStructInvContratFuncType createConsulterStructInvContratFuncType() {
        return new ConsulterStructInvContratFuncType();
    }

    /**
     * Create an instance of {@link ConsulterStructInvContratResponseType }
     * 
     */
    public ConsulterStructInvContratResponseType createConsulterStructInvContratResponseType() {
        return new ConsulterStructInvContratResponseType();
    }

    /**
     * Create an instance of {@link ConsulterStructInvContratType }
     * 
     */
    public ConsulterStructInvContratType createConsulterStructInvContratType() {
        return new ConsulterStructInvContratType();
    }

    /**
     * Create an instance of {@link ConsulterStructInvContratFullType }
     * 
     */
    public ConsulterStructInvContratFullType createConsulterStructInvContratFullType() {
        return new ConsulterStructInvContratFullType();
    }

    /**
     * Create an instance of {@link OccStructInvType }
     * 
     */
    public OccStructInvType createOccStructInvType() {
        return new OccStructInvType();
    }

    /**
     * Create an instance of {@link ProfilInvType }
     * 
     */
    public ProfilInvType createProfilInvType() {
        return new ProfilInvType();
    }

    /**
     * Create an instance of {@link IdentificationStructInvType }
     * 
     */
    public IdentificationStructInvType createIdentificationStructInvType() {
        return new IdentificationStructInvType();
    }

    /**
     * Create an instance of {@link SupportInvType }
     * 
     */
    public SupportInvType createSupportInvType() {
        return new SupportInvType();
    }

    /**
     * Create an instance of {@link StructInvType }
     * 
     */
    public StructInvType createStructInvType() {
        return new StructInvType();
    }

    /**
     * Create an instance of {@link IdentificationDansSiloType }
     * 
     */
    public IdentificationDansSiloType createIdentificationDansSiloType() {
        return new IdentificationDansSiloType();
    }

    /**
     * Create an instance of {@link GrilleInvType }
     * 
     */
    public GrilleInvType createGrilleInvType() {
        return new GrilleInvType();
    }

    /**
     * Create an instance of {@link HorizonInvType }
     * 
     */
    public HorizonInvType createHorizonInvType() {
        return new HorizonInvType();
    }

    /**
     * Create an instance of {@link IdDansSiloType }
     * 
     */
    public IdDansSiloType createIdDansSiloType() {
        return new IdDansSiloType();
    }

    /**
     * Create an instance of {@link TarifInvType }
     * 
     */
    public TarifInvType createTarifInvType() {
        return new TarifInvType();
    }

    /**
     * Create an instance of {@link ContributionInvType }
     * 
     */
    public ContributionInvType createContributionInvType() {
        return new ContributionInvType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterStructInvContratFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", name = "ConsulterStructInvContratFunc")
    public JAXBElement<ConsulterStructInvContratFuncType> createConsulterStructInvContratFunc(ConsulterStructInvContratFuncType value) {
        return new JAXBElement<ConsulterStructInvContratFuncType>(_ConsulterStructInvContratFunc_QNAME, ConsulterStructInvContratFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterStructInvContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", name = "ConsulterStructInvContrat")
    public JAXBElement<ConsulterStructInvContratType> createConsulterStructInvContrat(ConsulterStructInvContratType value) {
        return new JAXBElement<ConsulterStructInvContratType>(_ConsulterStructInvContrat_QNAME, ConsulterStructInvContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterStructInvContratFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", name = "ConsulterStructInvContratFull")
    public JAXBElement<ConsulterStructInvContratFullType> createConsulterStructInvContratFull(ConsulterStructInvContratFullType value) {
        return new JAXBElement<ConsulterStructInvContratFullType>(_ConsulterStructInvContratFull_QNAME, ConsulterStructInvContratFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterStructInvContratResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1", name = "ConsulterStructInvContratResponse")
    public JAXBElement<ConsulterStructInvContratResponseType> createConsulterStructInvContratResponse(ConsulterStructInvContratResponseType value) {
        return new JAXBElement<ConsulterStructInvContratResponseType>(_ConsulterStructInvContratResponse_QNAME, ConsulterStructInvContratResponseType.class, null, value);
    }

}
