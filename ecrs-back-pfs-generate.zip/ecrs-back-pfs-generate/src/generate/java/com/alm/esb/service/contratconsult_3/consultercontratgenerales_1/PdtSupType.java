
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour PdtSupType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PdtSupType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codePdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomCial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomFamillePdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutEffetPdt" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffetPdt" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PdtSupType", propOrder = {
    "codePdt",
    "libPdt",
    "nomCial",
    "nomFamillePdt",
    "dateDebutEffetPdt",
    "dateFinEffetPdt"
})
public class PdtSupType {

    protected String codePdt;
    protected String libPdt;
    protected String nomCial;
    protected String nomFamillePdt;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutEffetPdt;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffetPdt;

    /**
     * Obtient la valeur de la propriété codePdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePdt() {
        return codePdt;
    }

    /**
     * Définit la valeur de la propriété codePdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePdt(String value) {
        this.codePdt = value;
    }

    /**
     * Obtient la valeur de la propriété libPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPdt() {
        return libPdt;
    }

    /**
     * Définit la valeur de la propriété libPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPdt(String value) {
        this.libPdt = value;
    }

    /**
     * Obtient la valeur de la propriété nomCial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomCial() {
        return nomCial;
    }

    /**
     * Définit la valeur de la propriété nomCial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomCial(String value) {
        this.nomCial = value;
    }

    /**
     * Obtient la valeur de la propriété nomFamillePdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomFamillePdt() {
        return nomFamillePdt;
    }

    /**
     * Définit la valeur de la propriété nomFamillePdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomFamillePdt(String value) {
        this.nomFamillePdt = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutEffetPdt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutEffetPdt() {
        return dateDebutEffetPdt;
    }

    /**
     * Définit la valeur de la propriété dateDebutEffetPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutEffetPdt(XMLGregorianCalendar value) {
        this.dateDebutEffetPdt = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetPdt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffetPdt() {
        return dateFinEffetPdt;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffetPdt(XMLGregorianCalendar value) {
        this.dateFinEffetPdt = value;
    }

}
