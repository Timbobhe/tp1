
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ProfilInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ProfilInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idProfilInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomProfilInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionProfilInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicateurTauxDerogeableProfilInv" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionProfilInvDefaut" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProfilInvType", propOrder = {
    "idProfilInv",
    "nomProfilInv",
    "tauxRepartitionProfilInv",
    "indicateurTauxDerogeableProfilInv",
    "tauxRepartitionProfilInvDefaut"
})
public class ProfilInvType {

    protected String idProfilInv;
    protected String nomProfilInv;
    protected BigDecimal tauxRepartitionProfilInv;
    protected Boolean indicateurTauxDerogeableProfilInv;
    protected BigDecimal tauxRepartitionProfilInvDefaut;

    /**
     * Obtient la valeur de la propriété idProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdProfilInv() {
        return idProfilInv;
    }

    /**
     * Définit la valeur de la propriété idProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdProfilInv(String value) {
        this.idProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomProfilInv() {
        return nomProfilInv;
    }

    /**
     * Définit la valeur de la propriété nomProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomProfilInv(String value) {
        this.nomProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionProfilInv() {
        return tauxRepartitionProfilInv;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionProfilInv(BigDecimal value) {
        this.tauxRepartitionProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété indicateurTauxDerogeableProfilInv.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicateurTauxDerogeableProfilInv() {
        return indicateurTauxDerogeableProfilInv;
    }

    /**
     * Définit la valeur de la propriété indicateurTauxDerogeableProfilInv.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicateurTauxDerogeableProfilInv(Boolean value) {
        this.indicateurTauxDerogeableProfilInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionProfilInvDefaut() {
        return tauxRepartitionProfilInvDefaut;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionProfilInvDefaut(BigDecimal value) {
        this.tauxRepartitionProfilInvDefaut = value;
    }

}
