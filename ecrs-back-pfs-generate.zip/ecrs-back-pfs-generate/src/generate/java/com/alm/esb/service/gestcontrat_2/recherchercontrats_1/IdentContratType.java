
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}IdentificationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratType", propOrder = {
    "identSiloContrat"
})
public class IdentContratType {

    @XmlElement(name = "IdentSiloContrat")
    protected IdentificationType identSiloContrat;

    /**
     * Obtient la valeur de la propriété identSiloContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getIdentSiloContrat() {
        return identSiloContrat;
    }

    /**
     * Définit la valeur de la propriété identSiloContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setIdentSiloContrat(IdentificationType value) {
        this.identSiloContrat = value;
    }

}
