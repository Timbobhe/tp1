
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentificationContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentificationContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificationSilo" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}IdentificationSiloType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificationContratType", propOrder = {
    "identificationSilo"
})
public class IdentificationContratType {

    @XmlElement(name = "IdentificationSilo", required = true)
    protected IdentificationSiloType identificationSilo;

    /**
     * Obtient la valeur de la propriété identificationSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationSiloType }
     *     
     */
    public IdentificationSiloType getIdentificationSilo() {
        return identificationSilo;
    }

    /**
     * Définit la valeur de la propriété identificationSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationSiloType }
     *     
     */
    public void setIdentificationSilo(IdentificationSiloType value) {
        this.identificationSilo = value;
    }

}
