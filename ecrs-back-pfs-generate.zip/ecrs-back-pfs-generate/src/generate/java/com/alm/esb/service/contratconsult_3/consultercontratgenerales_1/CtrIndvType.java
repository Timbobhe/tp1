
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CtrIndvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtrIndvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="AssurePrcp" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AssurePrcpType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AssuresAdd" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AssuresAddType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Pdt" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}PdtCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ClausesCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}ClausesCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Cotis" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CotisType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtrIndvType", propOrder = {
    "assurePrcp",
    "assuresAdd",
    "pdt",
    "clausesCtr",
    "cotis"
})
public class CtrIndvType {

    @XmlElement(name = "AssurePrcp")
    protected List<AssurePrcpType> assurePrcp;
    @XmlElement(name = "AssuresAdd")
    protected List<AssuresAddType> assuresAdd;
    @XmlElement(name = "Pdt")
    protected List<PdtCtrType> pdt;
    @XmlElement(name = "ClausesCtr")
    protected List<ClausesCtrType> clausesCtr;
    @XmlElement(name = "Cotis")
    protected List<CotisType> cotis;

    /**
     * Gets the value of the assurePrcp property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assurePrcp property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssurePrcp().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssurePrcpType }
     * 
     * 
     */
    public List<AssurePrcpType> getAssurePrcp() {
        if (assurePrcp == null) {
            assurePrcp = new ArrayList<AssurePrcpType>();
        }
        return this.assurePrcp;
    }

    /**
     * Gets the value of the assuresAdd property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assuresAdd property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssuresAdd().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssuresAddType }
     * 
     * 
     */
    public List<AssuresAddType> getAssuresAdd() {
        if (assuresAdd == null) {
            assuresAdd = new ArrayList<AssuresAddType>();
        }
        return this.assuresAdd;
    }

    /**
     * Gets the value of the pdt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pdt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPdt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PdtCtrType }
     * 
     * 
     */
    public List<PdtCtrType> getPdt() {
        if (pdt == null) {
            pdt = new ArrayList<PdtCtrType>();
        }
        return this.pdt;
    }

    /**
     * Gets the value of the clausesCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clausesCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClausesCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClausesCtrType }
     * 
     * 
     */
    public List<ClausesCtrType> getClausesCtr() {
        if (clausesCtr == null) {
            clausesCtr = new ArrayList<ClausesCtrType>();
        }
        return this.clausesCtr;
    }

    /**
     * Gets the value of the cotis property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cotis property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCotis().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CotisType }
     * 
     * 
     */
    public List<CotisType> getCotis() {
        if (cotis == null) {
            cotis = new ArrayList<CotisType>();
        }
        return this.cotis;
    }

}
