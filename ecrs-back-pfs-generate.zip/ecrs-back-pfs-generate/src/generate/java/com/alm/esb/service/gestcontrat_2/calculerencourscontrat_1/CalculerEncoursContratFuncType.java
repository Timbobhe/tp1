
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CalculerEncoursContratFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CalculerEncoursContratFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="StructInv" type="{http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1}StructInvType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CalculerEncoursContratFuncType", propOrder = {
    "structInv"
})
public class CalculerEncoursContratFuncType {

    @XmlElement(name = "StructInv")
    protected StructInvType structInv;

    /**
     * Obtient la valeur de la propriété structInv.
     * 
     * @return
     *     possible object is
     *     {@link StructInvType }
     *     
     */
    public StructInvType getStructInv() {
        return structInv;
    }

    /**
     * Définit la valeur de la propriété structInv.
     * 
     * @param value
     *     allowed object is
     *     {@link StructInvType }
     *     
     */
    public void setStructInv(StructInvType value) {
        this.structInv = value;
    }

}
