
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentSiloContrat" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentContratPere" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratAdherenteType", propOrder = {
    "identSiloContrat",
    "identContratPere"
})
public class IdentContratAdherenteType {

    @XmlElement(name = "IdentSiloContrat")
    protected IdentSiloType identSiloContrat;
    @XmlElement(name = "IdentContratPere")
    protected IdentContratPereType identContratPere;

    /**
     * Obtient la valeur de la propriété identSiloContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloContrat() {
        return identSiloContrat;
    }

    /**
     * Définit la valeur de la propriété identSiloContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloContrat(IdentSiloType value) {
        this.identSiloContrat = value;
    }

    /**
     * Obtient la valeur de la propriété identContratPere.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratPereType }
     *     
     */
    public IdentContratPereType getIdentContratPere() {
        return identContratPere;
    }

    /**
     * Définit la valeur de la propriété identContratPere.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratPereType }
     *     
     */
    public void setIdentContratPere(IdentContratPereType value) {
        this.identContratPere = value;
    }

}
