
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ClausesCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ClausesCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="descClauseCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="descClauseBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numClause" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txRepartition" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClausesCtrType", propOrder = {
    "descClauseCtr",
    "descClauseBenef",
    "numClause",
    "txRepartition"
})
public class ClausesCtrType {

    protected String descClauseCtr;
    protected String descClauseBenef;
    protected String numClause;
    protected String txRepartition;

    /**
     * Obtient la valeur de la propriété descClauseCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescClauseCtr() {
        return descClauseCtr;
    }

    /**
     * Définit la valeur de la propriété descClauseCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescClauseCtr(String value) {
        this.descClauseCtr = value;
    }

    /**
     * Obtient la valeur de la propriété descClauseBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescClauseBenef() {
        return descClauseBenef;
    }

    /**
     * Définit la valeur de la propriété descClauseBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescClauseBenef(String value) {
        this.descClauseBenef = value;
    }

    /**
     * Obtient la valeur de la propriété numClause.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumClause() {
        return numClause;
    }

    /**
     * Définit la valeur de la propriété numClause.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumClause(String value) {
        this.numClause = value;
    }

    /**
     * Obtient la valeur de la propriété txRepartition.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTxRepartition() {
        return txRepartition;
    }

    /**
     * Définit la valeur de la propriété txRepartition.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTxRepartition(String value) {
        this.txRepartition = value;
    }

}
