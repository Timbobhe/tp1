
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour DetPPType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="DetPPType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeINSEEPaysNais" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DetPPType", propOrder = {
    "codeINSEEPaysNais",
    "codeNatio"
})
public class DetPPType {

    protected String codeINSEEPaysNais;
    protected String codeNatio;

    /**
     * Obtient la valeur de la propriété codeINSEEPaysNais.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeINSEEPaysNais() {
        return codeINSEEPaysNais;
    }

    /**
     * Définit la valeur de la propriété codeINSEEPaysNais.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeINSEEPaysNais(String value) {
        this.codeINSEEPaysNais = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatio() {
        return codeNatio;
    }

    /**
     * Définit la valeur de la propriété codeNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatio(String value) {
        this.codeNatio = value;
    }

}
