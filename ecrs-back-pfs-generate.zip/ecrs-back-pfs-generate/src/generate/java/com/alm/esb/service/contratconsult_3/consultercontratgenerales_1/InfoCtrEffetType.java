
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoCtrEffetType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoCtrEffetType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="motifCessation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateMiseEnGest" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoCtrEffetType", propOrder = {
    "dateEffet",
    "dateFinEffet",
    "codeSitCtr",
    "libSitCtr",
    "motifCessation",
    "dateMiseEnGest"
})
public class InfoCtrEffetType {

    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffet;
    protected String codeSitCtr;
    protected String libSitCtr;
    protected String motifCessation;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateMiseEnGest;

    /**
     * Obtient la valeur de la propriété dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffet() {
        return dateEffet;
    }

    /**
     * Définit la valeur de la propriété dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffet(XMLGregorianCalendar value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffet() {
        return dateFinEffet;
    }

    /**
     * Définit la valeur de la propriété dateFinEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffet(XMLGregorianCalendar value) {
        this.dateFinEffet = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCtr() {
        return codeSitCtr;
    }

    /**
     * Définit la valeur de la propriété codeSitCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCtr(String value) {
        this.codeSitCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCtr() {
        return libSitCtr;
    }

    /**
     * Définit la valeur de la propriété libSitCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCtr(String value) {
        this.libSitCtr = value;
    }

    /**
     * Obtient la valeur de la propriété motifCessation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifCessation() {
        return motifCessation;
    }

    /**
     * Définit la valeur de la propriété motifCessation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifCessation(String value) {
        this.motifCessation = value;
    }

    /**
     * Obtient la valeur de la propriété dateMiseEnGest.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateMiseEnGest() {
        return dateMiseEnGest;
    }

    /**
     * Définit la valeur de la propriété dateMiseEnGest.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateMiseEnGest(XMLGregorianCalendar value) {
        this.dateMiseEnGest = value;
    }

}
