
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratsPersCliFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratsPersCliFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ConsulterContratsPersCli" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}ConsulterContratsPersCliResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratsPersCliFullType", propOrder = {
    "consulterContratsPersCli",
    "consulterContratsPersCliResponse"
})
public class ConsulterContratsPersCliFullType {

    @XmlElement(name = "ConsulterContratsPersCli")
    protected ConsulterContratsPersCliType consulterContratsPersCli;
    @XmlElement(name = "ConsulterContratsPersCliResponse")
    protected ConsulterContratsPersCliResponseType consulterContratsPersCliResponse;

    /**
     * Obtient la valeur de la propriété consulterContratsPersCli.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratsPersCliType }
     *     
     */
    public ConsulterContratsPersCliType getConsulterContratsPersCli() {
        return consulterContratsPersCli;
    }

    /**
     * Définit la valeur de la propriété consulterContratsPersCli.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratsPersCliType }
     *     
     */
    public void setConsulterContratsPersCli(ConsulterContratsPersCliType value) {
        this.consulterContratsPersCli = value;
    }

    /**
     * Obtient la valeur de la propriété consulterContratsPersCliResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratsPersCliResponseType }
     *     
     */
    public ConsulterContratsPersCliResponseType getConsulterContratsPersCliResponse() {
        return consulterContratsPersCliResponse;
    }

    /**
     * Définit la valeur de la propriété consulterContratsPersCliResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratsPersCliResponseType }
     *     
     */
    public void setConsulterContratsPersCliResponse(ConsulterContratsPersCliResponseType value) {
        this.consulterContratsPersCliResponse = value;
    }

}
