
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_3;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour NavCliConType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="NavCliConType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloCourt" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_3}IdentSiloCourtType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="indGold" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}boolean">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NavCliConType", propOrder = {
    "identSiloCourt",
    "indGold"
})
public class NavCliConType {

    @XmlElement(name = "IdentSiloCourt")
    protected List<IdentSiloCourtType> identSiloCourt;
    protected Boolean indGold;

    /**
     * Gets the value of the identSiloCourt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identSiloCourt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentSiloCourt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentSiloCourtType }
     * 
     * 
     */
    public List<IdentSiloCourtType> getIdentSiloCourt() {
        if (identSiloCourt == null) {
            identSiloCourt = new ArrayList<IdentSiloCourtType>();
        }
        return this.identSiloCourt;
    }

    /**
     * Obtient la valeur de la propriété indGold.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndGold() {
        return indGold;
    }

    /**
     * Définit la valeur de la propriété indGold.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndGold(Boolean value) {
        this.indGold = value;
    }

}
