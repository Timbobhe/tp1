
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OptContratEpargneType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OptContratEpargneType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeGestCompte" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libGestCompte" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeGestCompteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libGestCompteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeFondGere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeFondGere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeFondGereSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeFondGereSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indicAutorChoixPlacementDiff" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indicRefusVersementFacultatif" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indicTarifVersementPrimeAutorise" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indicRefusArbitrageInternet" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="nbeArbitrageAnn" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="nbeArbitrageCtr" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="indicSortieTotaleContrat" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indicTypeArbitrageAutorise" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptContratEpargneType", propOrder = {
    "codeGestCompte",
    "libGestCompte",
    "codeGestCompteSilo",
    "libGestCompteSilo",
    "codeTypeFondGere",
    "libTypeFondGere",
    "codeTypeFondGereSilo",
    "libTypeFondGereSilo",
    "indicAutorChoixPlacementDiff",
    "indicRefusVersementFacultatif",
    "indicTarifVersementPrimeAutorise",
    "indicRefusArbitrageInternet",
    "nbeArbitrageAnn",
    "nbeArbitrageCtr",
    "indicSortieTotaleContrat",
    "indicTypeArbitrageAutorise"
})
public class OptContratEpargneType {

    protected String codeGestCompte;
    protected String libGestCompte;
    protected String codeGestCompteSilo;
    protected String libGestCompteSilo;
    protected String codeTypeFondGere;
    protected String libTypeFondGere;
    protected String codeTypeFondGereSilo;
    protected String libTypeFondGereSilo;
    protected Boolean indicAutorChoixPlacementDiff;
    protected Boolean indicRefusVersementFacultatif;
    protected Boolean indicTarifVersementPrimeAutorise;
    protected Boolean indicRefusArbitrageInternet;
    protected BigInteger nbeArbitrageAnn;
    protected BigInteger nbeArbitrageCtr;
    protected Boolean indicSortieTotaleContrat;
    protected Boolean indicTypeArbitrageAutorise;

    /**
     * Obtient la valeur de la propriété codeGestCompte.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGestCompte() {
        return codeGestCompte;
    }

    /**
     * Définit la valeur de la propriété codeGestCompte.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGestCompte(String value) {
        this.codeGestCompte = value;
    }

    /**
     * Obtient la valeur de la propriété libGestCompte.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibGestCompte() {
        return libGestCompte;
    }

    /**
     * Définit la valeur de la propriété libGestCompte.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibGestCompte(String value) {
        this.libGestCompte = value;
    }

    /**
     * Obtient la valeur de la propriété codeGestCompteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGestCompteSilo() {
        return codeGestCompteSilo;
    }

    /**
     * Définit la valeur de la propriété codeGestCompteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGestCompteSilo(String value) {
        this.codeGestCompteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libGestCompteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibGestCompteSilo() {
        return libGestCompteSilo;
    }

    /**
     * Définit la valeur de la propriété libGestCompteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibGestCompteSilo(String value) {
        this.libGestCompteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeFondGere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeFondGere() {
        return codeTypeFondGere;
    }

    /**
     * Définit la valeur de la propriété codeTypeFondGere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeFondGere(String value) {
        this.codeTypeFondGere = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeFondGere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeFondGere() {
        return libTypeFondGere;
    }

    /**
     * Définit la valeur de la propriété libTypeFondGere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeFondGere(String value) {
        this.libTypeFondGere = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeFondGereSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeFondGereSilo() {
        return codeTypeFondGereSilo;
    }

    /**
     * Définit la valeur de la propriété codeTypeFondGereSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeFondGereSilo(String value) {
        this.codeTypeFondGereSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeFondGereSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeFondGereSilo() {
        return libTypeFondGereSilo;
    }

    /**
     * Définit la valeur de la propriété libTypeFondGereSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeFondGereSilo(String value) {
        this.libTypeFondGereSilo = value;
    }

    /**
     * Obtient la valeur de la propriété indicAutorChoixPlacementDiff.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicAutorChoixPlacementDiff() {
        return indicAutorChoixPlacementDiff;
    }

    /**
     * Définit la valeur de la propriété indicAutorChoixPlacementDiff.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicAutorChoixPlacementDiff(Boolean value) {
        this.indicAutorChoixPlacementDiff = value;
    }

    /**
     * Obtient la valeur de la propriété indicRefusVersementFacultatif.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicRefusVersementFacultatif() {
        return indicRefusVersementFacultatif;
    }

    /**
     * Définit la valeur de la propriété indicRefusVersementFacultatif.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicRefusVersementFacultatif(Boolean value) {
        this.indicRefusVersementFacultatif = value;
    }

    /**
     * Obtient la valeur de la propriété indicTarifVersementPrimeAutorise.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicTarifVersementPrimeAutorise() {
        return indicTarifVersementPrimeAutorise;
    }

    /**
     * Définit la valeur de la propriété indicTarifVersementPrimeAutorise.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicTarifVersementPrimeAutorise(Boolean value) {
        this.indicTarifVersementPrimeAutorise = value;
    }

    /**
     * Obtient la valeur de la propriété indicRefusArbitrageInternet.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicRefusArbitrageInternet() {
        return indicRefusArbitrageInternet;
    }

    /**
     * Définit la valeur de la propriété indicRefusArbitrageInternet.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicRefusArbitrageInternet(Boolean value) {
        this.indicRefusArbitrageInternet = value;
    }

    /**
     * Obtient la valeur de la propriété nbeArbitrageAnn.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNbeArbitrageAnn() {
        return nbeArbitrageAnn;
    }

    /**
     * Définit la valeur de la propriété nbeArbitrageAnn.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNbeArbitrageAnn(BigInteger value) {
        this.nbeArbitrageAnn = value;
    }

    /**
     * Obtient la valeur de la propriété nbeArbitrageCtr.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNbeArbitrageCtr() {
        return nbeArbitrageCtr;
    }

    /**
     * Définit la valeur de la propriété nbeArbitrageCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNbeArbitrageCtr(BigInteger value) {
        this.nbeArbitrageCtr = value;
    }

    /**
     * Obtient la valeur de la propriété indicSortieTotaleContrat.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicSortieTotaleContrat() {
        return indicSortieTotaleContrat;
    }

    /**
     * Définit la valeur de la propriété indicSortieTotaleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicSortieTotaleContrat(Boolean value) {
        this.indicSortieTotaleContrat = value;
    }

    /**
     * Obtient la valeur de la propriété indicTypeArbitrageAutorise.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicTypeArbitrageAutorise() {
        return indicTypeArbitrageAutorise;
    }

    /**
     * Définit la valeur de la propriété indicTypeArbitrageAutorise.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicTypeArbitrageAutorise(Boolean value) {
        this.indicTypeArbitrageAutorise = value;
    }

}
