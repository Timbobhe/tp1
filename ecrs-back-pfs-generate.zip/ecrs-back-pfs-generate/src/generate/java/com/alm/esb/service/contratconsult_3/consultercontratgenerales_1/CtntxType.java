
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour CtntxType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtntxType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indCtntx" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="dateDebutCtntx" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="motifCtntx" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtntxType", propOrder = {
    "indCtntx",
    "dateDebutCtntx",
    "motifCtntx"
})
public class CtntxType {

    protected Boolean indCtntx;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutCtntx;
    protected String motifCtntx;

    /**
     * Obtient la valeur de la propriété indCtntx.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndCtntx() {
        return indCtntx;
    }

    /**
     * Définit la valeur de la propriété indCtntx.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndCtntx(Boolean value) {
        this.indCtntx = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutCtntx.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutCtntx() {
        return dateDebutCtntx;
    }

    /**
     * Définit la valeur de la propriété dateDebutCtntx.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutCtntx(XMLGregorianCalendar value) {
        this.dateDebutCtntx = value;
    }

    /**
     * Obtient la valeur de la propriété motifCtntx.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifCtntx() {
        return motifCtntx;
    }

    /**
     * Définit la valeur de la propriété motifCtntx.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifCtntx(String value) {
        this.motifCtntx = value;
    }

}
