
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratGeneralesFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratGeneralesFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}ConsulterContratGenerales" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}ConsulterContratGeneralesResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratGeneralesFullType", propOrder = {
    "consulterContratGenerales",
    "consulterContratGeneralesResponse"
})
public class ConsulterContratGeneralesFullType {

    @XmlElement(name = "ConsulterContratGenerales")
    protected ConsulterContratGeneralesType consulterContratGenerales;
    @XmlElement(name = "ConsulterContratGeneralesResponse")
    protected ConsulterContratGeneralesResponseType consulterContratGeneralesResponse;

    /**
     * Obtient la valeur de la propriété consulterContratGenerales.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratGeneralesType }
     *     
     */
    public ConsulterContratGeneralesType getConsulterContratGenerales() {
        return consulterContratGenerales;
    }

    /**
     * Définit la valeur de la propriété consulterContratGenerales.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratGeneralesType }
     *     
     */
    public void setConsulterContratGenerales(ConsulterContratGeneralesType value) {
        this.consulterContratGenerales = value;
    }

    /**
     * Obtient la valeur de la propriété consulterContratGeneralesResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratGeneralesResponseType }
     *     
     */
    public ConsulterContratGeneralesResponseType getConsulterContratGeneralesResponse() {
        return consulterContratGeneralesResponse;
    }

    /**
     * Définit la valeur de la propriété consulterContratGeneralesResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratGeneralesResponseType }
     *     
     */
    public void setConsulterContratGeneralesResponse(ConsulterContratGeneralesResponseType value) {
        this.consulterContratGeneralesResponse = value;
    }

}
