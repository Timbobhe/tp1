
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratCollType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratCollType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indSuiviParticulier" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeMontageTechnique" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="motifMontageTechnique" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}CategPersonnel" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}Affiliation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}Adhesion" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratCollType", propOrder = {
    "indSuiviParticulier",
    "codeMontageTechnique",
    "motifMontageTechnique",
    "categPersonnel",
    "affiliation",
    "adhesion"
})
public class ContratCollType {

    protected Boolean indSuiviParticulier;
    protected String codeMontageTechnique;
    protected String motifMontageTechnique;
    @XmlElement(name = "CategPersonnel")
    protected List<CategPersonnelType> categPersonnel;
    @XmlElement(name = "Affiliation")
    protected List<AffilContratType> affiliation;
    @XmlElement(name = "Adhesion")
    protected List<AdhesionType> adhesion;

    /**
     * Obtient la valeur de la propriété indSuiviParticulier.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndSuiviParticulier() {
        return indSuiviParticulier;
    }

    /**
     * Définit la valeur de la propriété indSuiviParticulier.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndSuiviParticulier(Boolean value) {
        this.indSuiviParticulier = value;
    }

    /**
     * Obtient la valeur de la propriété codeMontageTechnique.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMontageTechnique() {
        return codeMontageTechnique;
    }

    /**
     * Définit la valeur de la propriété codeMontageTechnique.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMontageTechnique(String value) {
        this.codeMontageTechnique = value;
    }

    /**
     * Obtient la valeur de la propriété motifMontageTechnique.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifMontageTechnique() {
        return motifMontageTechnique;
    }

    /**
     * Définit la valeur de la propriété motifMontageTechnique.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifMontageTechnique(String value) {
        this.motifMontageTechnique = value;
    }

    /**
     * Gets the value of the categPersonnel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the categPersonnel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCategPersonnel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CategPersonnelType }
     * 
     * 
     */
    public List<CategPersonnelType> getCategPersonnel() {
        if (categPersonnel == null) {
            categPersonnel = new ArrayList<CategPersonnelType>();
        }
        return this.categPersonnel;
    }

    /**
     * Gets the value of the affiliation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affiliation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffiliation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffilContratType }
     * 
     * 
     */
    public List<AffilContratType> getAffiliation() {
        if (affiliation == null) {
            affiliation = new ArrayList<AffilContratType>();
        }
        return this.affiliation;
    }

    /**
     * Gets the value of the adhesion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the adhesion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdhesion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdhesionType }
     * 
     * 
     */
    public List<AdhesionType> getAdhesion() {
        if (adhesion == null) {
            adhesion = new ArrayList<AdhesionType>();
        }
        return this.adhesion;
    }

}
