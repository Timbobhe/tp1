
package com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _IdSilo_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "IdSilo");
    private final static QName _CalculerEncoursContratFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "CalculerEncoursContratFunc");
    private final static QName _CalculerEncoursContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "CalculerEncoursContrat");
    private final static QName _CalculerEncoursContratResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "CalculerEncoursContratResponse");
    private final static QName _CalculerEncoursContratFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "CalculerEncoursContratFull");
    private final static QName _IdentContratSilo_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", "IdentContratSilo");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.calculerencourscontrat_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CalculerEncoursContratType }
     * 
     */
    public CalculerEncoursContratType createCalculerEncoursContratType() {
        return new CalculerEncoursContratType();
    }

    /**
     * Create an instance of {@link CalculerEncoursContratResponseType }
     * 
     */
    public CalculerEncoursContratResponseType createCalculerEncoursContratResponseType() {
        return new CalculerEncoursContratResponseType();
    }

    /**
     * Create an instance of {@link CalculerEncoursContratFuncType }
     * 
     */
    public CalculerEncoursContratFuncType createCalculerEncoursContratFuncType() {
        return new CalculerEncoursContratFuncType();
    }

    /**
     * Create an instance of {@link IdSiloType }
     * 
     */
    public IdSiloType createIdSiloType() {
        return new IdSiloType();
    }

    /**
     * Create an instance of {@link CalculerEncoursContratFullType }
     * 
     */
    public CalculerEncoursContratFullType createCalculerEncoursContratFullType() {
        return new CalculerEncoursContratFullType();
    }

    /**
     * Create an instance of {@link IdentContratSiloType }
     * 
     */
    public IdentContratSiloType createIdentContratSiloType() {
        return new IdentContratSiloType();
    }

    /**
     * Create an instance of {@link ProfilInvType }
     * 
     */
    public ProfilInvType createProfilInvType() {
        return new ProfilInvType();
    }

    /**
     * Create an instance of {@link IdentificationStructInvType }
     * 
     */
    public IdentificationStructInvType createIdentificationStructInvType() {
        return new IdentificationStructInvType();
    }

    /**
     * Create an instance of {@link OccurStructInvType }
     * 
     */
    public OccurStructInvType createOccurStructInvType() {
        return new OccurStructInvType();
    }

    /**
     * Create an instance of {@link SupportInvType }
     * 
     */
    public SupportInvType createSupportInvType() {
        return new SupportInvType();
    }

    /**
     * Create an instance of {@link StructInvType }
     * 
     */
    public StructInvType createStructInvType() {
        return new StructInvType();
    }

    /**
     * Create an instance of {@link GrilleInvType }
     * 
     */
    public GrilleInvType createGrilleInvType() {
        return new GrilleInvType();
    }

    /**
     * Create an instance of {@link HorizonInvType }
     * 
     */
    public HorizonInvType createHorizonInvType() {
        return new HorizonInvType();
    }

    /**
     * Create an instance of {@link TarifInvType }
     * 
     */
    public TarifInvType createTarifInvType() {
        return new TarifInvType();
    }

    /**
     * Create an instance of {@link ContributionInvType }
     * 
     */
    public ContributionInvType createContributionInvType() {
        return new ContributionInvType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "IdSilo")
    public JAXBElement<IdSiloType> createIdSilo(IdSiloType value) {
        return new JAXBElement<IdSiloType>(_IdSilo_QNAME, IdSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerEncoursContratFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "CalculerEncoursContratFunc")
    public JAXBElement<CalculerEncoursContratFuncType> createCalculerEncoursContratFunc(CalculerEncoursContratFuncType value) {
        return new JAXBElement<CalculerEncoursContratFuncType>(_CalculerEncoursContratFunc_QNAME, CalculerEncoursContratFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerEncoursContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "CalculerEncoursContrat")
    public JAXBElement<CalculerEncoursContratType> createCalculerEncoursContrat(CalculerEncoursContratType value) {
        return new JAXBElement<CalculerEncoursContratType>(_CalculerEncoursContrat_QNAME, CalculerEncoursContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerEncoursContratResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "CalculerEncoursContratResponse")
    public JAXBElement<CalculerEncoursContratResponseType> createCalculerEncoursContratResponse(CalculerEncoursContratResponseType value) {
        return new JAXBElement<CalculerEncoursContratResponseType>(_CalculerEncoursContratResponse_QNAME, CalculerEncoursContratResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CalculerEncoursContratFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "CalculerEncoursContratFull")
    public JAXBElement<CalculerEncoursContratFullType> createCalculerEncoursContratFull(CalculerEncoursContratFullType value) {
        return new JAXBElement<CalculerEncoursContratFullType>(_CalculerEncoursContratFull_QNAME, CalculerEncoursContratFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentContratSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/CalculerEncoursContrat_1", name = "IdentContratSilo")
    public JAXBElement<IdentContratSiloType> createIdentContratSilo(IdentContratSiloType value) {
        return new JAXBElement<IdentContratSiloType>(_IdentContratSilo_QNAME, IdentContratSiloType.class, null, value);
    }

}
