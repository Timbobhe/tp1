
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour SupportInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="SupportInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idSupportInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeISIN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomSupportInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCategorieFonds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCategorieFonds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCategorieFondsSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCategorieFondsSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionSupportInv" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="tauxRepartitionProfilInvDefaut" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="valeurLiquidativeFond" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateValeurLiquidative" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="nombrePartFonds" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="deviseFonds" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SupportInvType", propOrder = {
    "idSupportInv",
    "codeISIN",
    "nomSupportInv",
    "codeCategorieFonds",
    "libCategorieFonds",
    "codeCategorieFondsSilo",
    "libCategorieFondsSilo",
    "tauxRepartitionSupportInv",
    "tauxRepartitionProfilInvDefaut",
    "valeurLiquidativeFond",
    "dateValeurLiquidative",
    "nombrePartFonds",
    "deviseFonds"
})
public class SupportInvType {

    protected String idSupportInv;
    protected String codeISIN;
    protected String nomSupportInv;
    protected String codeCategorieFonds;
    protected String libCategorieFonds;
    protected String codeCategorieFondsSilo;
    protected String libCategorieFondsSilo;
    protected BigDecimal tauxRepartitionSupportInv;
    protected BigDecimal tauxRepartitionProfilInvDefaut;
    protected BigDecimal valeurLiquidativeFond;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateValeurLiquidative;
    protected BigDecimal nombrePartFonds;
    protected String deviseFonds;

    /**
     * Obtient la valeur de la propriété idSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSupportInv() {
        return idSupportInv;
    }

    /**
     * Définit la valeur de la propriété idSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSupportInv(String value) {
        this.idSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeISIN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeISIN() {
        return codeISIN;
    }

    /**
     * Définit la valeur de la propriété codeISIN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeISIN(String value) {
        this.codeISIN = value;
    }

    /**
     * Obtient la valeur de la propriété nomSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomSupportInv() {
        return nomSupportInv;
    }

    /**
     * Définit la valeur de la propriété nomSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomSupportInv(String value) {
        this.nomSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeCategorieFonds.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCategorieFonds() {
        return codeCategorieFonds;
    }

    /**
     * Définit la valeur de la propriété codeCategorieFonds.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCategorieFonds(String value) {
        this.codeCategorieFonds = value;
    }

    /**
     * Obtient la valeur de la propriété libCategorieFonds.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCategorieFonds() {
        return libCategorieFonds;
    }

    /**
     * Définit la valeur de la propriété libCategorieFonds.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCategorieFonds(String value) {
        this.libCategorieFonds = value;
    }

    /**
     * Obtient la valeur de la propriété codeCategorieFondsSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCategorieFondsSilo() {
        return codeCategorieFondsSilo;
    }

    /**
     * Définit la valeur de la propriété codeCategorieFondsSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCategorieFondsSilo(String value) {
        this.codeCategorieFondsSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libCategorieFondsSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCategorieFondsSilo() {
        return libCategorieFondsSilo;
    }

    /**
     * Définit la valeur de la propriété libCategorieFondsSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCategorieFondsSilo(String value) {
        this.libCategorieFondsSilo = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionSupportInv.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionSupportInv() {
        return tauxRepartitionSupportInv;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionSupportInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionSupportInv(BigDecimal value) {
        this.tauxRepartitionSupportInv = value;
    }

    /**
     * Obtient la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxRepartitionProfilInvDefaut() {
        return tauxRepartitionProfilInvDefaut;
    }

    /**
     * Définit la valeur de la propriété tauxRepartitionProfilInvDefaut.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxRepartitionProfilInvDefaut(BigDecimal value) {
        this.tauxRepartitionProfilInvDefaut = value;
    }

    /**
     * Obtient la valeur de la propriété valeurLiquidativeFond.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getValeurLiquidativeFond() {
        return valeurLiquidativeFond;
    }

    /**
     * Définit la valeur de la propriété valeurLiquidativeFond.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setValeurLiquidativeFond(BigDecimal value) {
        this.valeurLiquidativeFond = value;
    }

    /**
     * Obtient la valeur de la propriété dateValeurLiquidative.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateValeurLiquidative() {
        return dateValeurLiquidative;
    }

    /**
     * Définit la valeur de la propriété dateValeurLiquidative.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateValeurLiquidative(XMLGregorianCalendar value) {
        this.dateValeurLiquidative = value;
    }

    /**
     * Obtient la valeur de la propriété nombrePartFonds.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNombrePartFonds() {
        return nombrePartFonds;
    }

    /**
     * Définit la valeur de la propriété nombrePartFonds.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNombrePartFonds(BigDecimal value) {
        this.nombrePartFonds = value;
    }

    /**
     * Obtient la valeur de la propriété deviseFonds.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviseFonds() {
        return deviseFonds;
    }

    /**
     * Définit la valeur de la propriété deviseFonds.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviseFonds(String value) {
        this.deviseFonds = value;
    }

}
