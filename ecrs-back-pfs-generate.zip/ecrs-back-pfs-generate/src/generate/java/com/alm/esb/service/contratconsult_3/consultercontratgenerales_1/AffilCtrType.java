
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AffilCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AffilCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAffil" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="indAffilComplete" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AffilCtrType", propOrder = {
    "idAffil",
    "indAffilComplete"
})
public class AffilCtrType {

    @XmlElement(required = true)
    protected String idAffil;
    protected Boolean indAffilComplete;

    /**
     * Obtient la valeur de la propriété idAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAffil() {
        return idAffil;
    }

    /**
     * Définit la valeur de la propriété idAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAffil(String value) {
        this.idAffil = value;
    }

    /**
     * Obtient la valeur de la propriété indAffilComplete.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndAffilComplete() {
        return indAffilComplete;
    }

    /**
     * Définit la valeur de la propriété indAffilComplete.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndAffilComplete(Boolean value) {
        this.indAffilComplete = value;
    }

}
