@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;
