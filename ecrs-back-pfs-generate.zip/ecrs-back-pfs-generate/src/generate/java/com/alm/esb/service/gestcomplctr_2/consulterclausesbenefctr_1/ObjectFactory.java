
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _AffilCtr_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "AffilCtr");
    private final static QName _IdentCtrSilo_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "IdentCtrSilo");
    private final static QName _SignqPPAssureAdd_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "SignqPPAssureAdd");
    private final static QName _ConsulterClausesBenefCtrResponse_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "ConsulterClausesBenefCtrResponse");
    private final static QName _CtrAssur_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "CtrAssur");
    private final static QName _ConsulterClausesBenefCtr_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "ConsulterClausesBenefCtr");
    private final static QName _InfoBenef_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "InfoBenef");
    private final static QName _CtrIndv_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "CtrIndv");
    private final static QName _ClausesCtr_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "ClausesCtr");
    private final static QName _ConsulterClausesBenefCtrFull_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "ConsulterClausesBenefCtrFull");
    private final static QName _ConsulterClausesBenefCtrFunc_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "ConsulterClausesBenefCtrFunc");
    private final static QName _CtrColl_QNAME = new QName("http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", "CtrColl");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsulterClausesBenefCtrType }
     * 
     */
    public ConsulterClausesBenefCtrType createConsulterClausesBenefCtrType() {
        return new ConsulterClausesBenefCtrType();
    }

    /**
     * Create an instance of {@link ConsulterClausesBenefCtrResponseType }
     * 
     */
    public ConsulterClausesBenefCtrResponseType createConsulterClausesBenefCtrResponseType() {
        return new ConsulterClausesBenefCtrResponseType();
    }

    /**
     * Create an instance of {@link SignaletiquePPAssureAdditionnelType }
     * 
     */
    public SignaletiquePPAssureAdditionnelType createSignaletiquePPAssureAdditionnelType() {
        return new SignaletiquePPAssureAdditionnelType();
    }

    /**
     * Create an instance of {@link ConsulterClausesBenefCtrFuncType }
     * 
     */
    public ConsulterClausesBenefCtrFuncType createConsulterClausesBenefCtrFuncType() {
        return new ConsulterClausesBenefCtrFuncType();
    }

    /**
     * Create an instance of {@link InfoBeneficiaireType }
     * 
     */
    public InfoBeneficiaireType createInfoBeneficiaireType() {
        return new InfoBeneficiaireType();
    }

    /**
     * Create an instance of {@link IdentificationContratSiloType }
     * 
     */
    public IdentificationContratSiloType createIdentificationContratSiloType() {
        return new IdentificationContratSiloType();
    }

    /**
     * Create an instance of {@link ContratIndividuelType }
     * 
     */
    public ContratIndividuelType createContratIndividuelType() {
        return new ContratIndividuelType();
    }

    /**
     * Create an instance of {@link ContratCollectifType }
     * 
     */
    public ContratCollectifType createContratCollectifType() {
        return new ContratCollectifType();
    }

    /**
     * Create an instance of {@link ClausesContratType }
     * 
     */
    public ClausesContratType createClausesContratType() {
        return new ClausesContratType();
    }

    /**
     * Create an instance of {@link ConsulterClausesBenefCtrFullType }
     * 
     */
    public ConsulterClausesBenefCtrFullType createConsulterClausesBenefCtrFullType() {
        return new ConsulterClausesBenefCtrFullType();
    }

    /**
     * Create an instance of {@link ContratAssureType }
     * 
     */
    public ContratAssureType createContratAssureType() {
        return new ContratAssureType();
    }

    /**
     * Create an instance of {@link AffiliationsContratType }
     * 
     */
    public AffiliationsContratType createAffiliationsContratType() {
        return new AffiliationsContratType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AffiliationsContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "AffilCtr")
    public JAXBElement<AffiliationsContratType> createAffilCtr(AffiliationsContratType value) {
        return new JAXBElement<AffiliationsContratType>(_AffilCtr_QNAME, AffiliationsContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentificationContratSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "IdentCtrSilo")
    public JAXBElement<IdentificationContratSiloType> createIdentCtrSilo(IdentificationContratSiloType value) {
        return new JAXBElement<IdentificationContratSiloType>(_IdentCtrSilo_QNAME, IdentificationContratSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiquePPAssureAdditionnelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "SignqPPAssureAdd")
    public JAXBElement<SignaletiquePPAssureAdditionnelType> createSignqPPAssureAdd(SignaletiquePPAssureAdditionnelType value) {
        return new JAXBElement<SignaletiquePPAssureAdditionnelType>(_SignqPPAssureAdd_QNAME, SignaletiquePPAssureAdditionnelType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterClausesBenefCtrResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "ConsulterClausesBenefCtrResponse")
    public JAXBElement<ConsulterClausesBenefCtrResponseType> createConsulterClausesBenefCtrResponse(ConsulterClausesBenefCtrResponseType value) {
        return new JAXBElement<ConsulterClausesBenefCtrResponseType>(_ConsulterClausesBenefCtrResponse_QNAME, ConsulterClausesBenefCtrResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratAssureType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "CtrAssur")
    public JAXBElement<ContratAssureType> createCtrAssur(ContratAssureType value) {
        return new JAXBElement<ContratAssureType>(_CtrAssur_QNAME, ContratAssureType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterClausesBenefCtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "ConsulterClausesBenefCtr")
    public JAXBElement<ConsulterClausesBenefCtrType> createConsulterClausesBenefCtr(ConsulterClausesBenefCtrType value) {
        return new JAXBElement<ConsulterClausesBenefCtrType>(_ConsulterClausesBenefCtr_QNAME, ConsulterClausesBenefCtrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InfoBeneficiaireType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "InfoBenef")
    public JAXBElement<InfoBeneficiaireType> createInfoBenef(InfoBeneficiaireType value) {
        return new JAXBElement<InfoBeneficiaireType>(_InfoBenef_QNAME, InfoBeneficiaireType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratIndividuelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "CtrIndv")
    public JAXBElement<ContratIndividuelType> createCtrIndv(ContratIndividuelType value) {
        return new JAXBElement<ContratIndividuelType>(_CtrIndv_QNAME, ContratIndividuelType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ClausesContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "ClausesCtr")
    public JAXBElement<ClausesContratType> createClausesCtr(ClausesContratType value) {
        return new JAXBElement<ClausesContratType>(_ClausesCtr_QNAME, ClausesContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterClausesBenefCtrFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "ConsulterClausesBenefCtrFull")
    public JAXBElement<ConsulterClausesBenefCtrFullType> createConsulterClausesBenefCtrFull(ConsulterClausesBenefCtrFullType value) {
        return new JAXBElement<ConsulterClausesBenefCtrFullType>(_ConsulterClausesBenefCtrFull_QNAME, ConsulterClausesBenefCtrFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterClausesBenefCtrFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "ConsulterClausesBenefCtrFunc")
    public JAXBElement<ConsulterClausesBenefCtrFuncType> createConsulterClausesBenefCtrFunc(ConsulterClausesBenefCtrFuncType value) {
        return new JAXBElement<ConsulterClausesBenefCtrFuncType>(_ConsulterClausesBenefCtrFunc_QNAME, ConsulterClausesBenefCtrFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratCollectifType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1", name = "CtrColl")
    public JAXBElement<ContratCollectifType> createCtrColl(ContratCollectifType value) {
        return new JAXBElement<ContratCollectifType>(_CtrColl_QNAME, ContratCollectifType.class, null, value);
    }

}
