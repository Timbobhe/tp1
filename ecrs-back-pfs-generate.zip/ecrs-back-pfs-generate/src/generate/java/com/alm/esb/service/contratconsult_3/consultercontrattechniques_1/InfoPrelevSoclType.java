
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour InfoPrelevSoclType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoPrelevSoclType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="typePrelevement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libellePrelevement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutEffetPrelevement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateFinEffetPrelevement" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="tauxPrelevement" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoPrelevSoclType", propOrder = {
    "typePrelevement",
    "libellePrelevement",
    "dateDebutEffetPrelevement",
    "dateFinEffetPrelevement",
    "tauxPrelevement"
})
public class InfoPrelevSoclType {

    protected String typePrelevement;
    protected String libellePrelevement;
    protected String dateDebutEffetPrelevement;
    protected BigDecimal dateFinEffetPrelevement;
    protected BigDecimal tauxPrelevement;

    /**
     * Obtient la valeur de la propriété typePrelevement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypePrelevement() {
        return typePrelevement;
    }

    /**
     * Définit la valeur de la propriété typePrelevement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypePrelevement(String value) {
        this.typePrelevement = value;
    }

    /**
     * Obtient la valeur de la propriété libellePrelevement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibellePrelevement() {
        return libellePrelevement;
    }

    /**
     * Définit la valeur de la propriété libellePrelevement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibellePrelevement(String value) {
        this.libellePrelevement = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutEffetPrelevement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDateDebutEffetPrelevement() {
        return dateDebutEffetPrelevement;
    }

    /**
     * Définit la valeur de la propriété dateDebutEffetPrelevement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDateDebutEffetPrelevement(String value) {
        this.dateDebutEffetPrelevement = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetPrelevement.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDateFinEffetPrelevement() {
        return dateFinEffetPrelevement;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetPrelevement.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDateFinEffetPrelevement(BigDecimal value) {
        this.dateFinEffetPrelevement = value;
    }

    /**
     * Obtient la valeur de la propriété tauxPrelevement.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxPrelevement() {
        return tauxPrelevement;
    }

    /**
     * Définit la valeur de la propriété tauxPrelevement.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxPrelevement(BigDecimal value) {
        this.tauxPrelevement = value;
    }

}
