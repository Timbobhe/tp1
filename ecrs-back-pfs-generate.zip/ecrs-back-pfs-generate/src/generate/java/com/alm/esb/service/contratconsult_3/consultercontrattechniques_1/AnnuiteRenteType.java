
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour AnnuiteRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AnnuiteRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateFinAnnuite" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeDeviseAnnuite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantAnnuite" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="libelleDeviseAnnuite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateFinEffetValorisation" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="tauxValorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateProchaineRevalorisation" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="PalierAnnuite" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}PalierAnntType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AnnuiteRenteType", propOrder = {
    "dateFinAnnuite",
    "codeDeviseAnnuite",
    "montantAnnuite",
    "libelleDeviseAnnuite",
    "dateFinEffetValorisation",
    "tauxValorisation",
    "dateProchaineRevalorisation",
    "palierAnnuite"
})
public class AnnuiteRenteType {

    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinAnnuite;
    protected String codeDeviseAnnuite;
    protected BigDecimal montantAnnuite;
    protected String libelleDeviseAnnuite;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffetValorisation;
    protected String tauxValorisation;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchaineRevalorisation;
    @XmlElement(name = "PalierAnnuite")
    protected List<PalierAnntType> palierAnnuite;

    /**
     * Obtient la valeur de la propriété dateFinAnnuite.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinAnnuite() {
        return dateFinAnnuite;
    }

    /**
     * Définit la valeur de la propriété dateFinAnnuite.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinAnnuite(XMLGregorianCalendar value) {
        this.dateFinAnnuite = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseAnnuite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseAnnuite() {
        return codeDeviseAnnuite;
    }

    /**
     * Définit la valeur de la propriété codeDeviseAnnuite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseAnnuite(String value) {
        this.codeDeviseAnnuite = value;
    }

    /**
     * Obtient la valeur de la propriété montantAnnuite.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantAnnuite() {
        return montantAnnuite;
    }

    /**
     * Définit la valeur de la propriété montantAnnuite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantAnnuite(BigDecimal value) {
        this.montantAnnuite = value;
    }

    /**
     * Obtient la valeur de la propriété libelleDeviseAnnuite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleDeviseAnnuite() {
        return libelleDeviseAnnuite;
    }

    /**
     * Définit la valeur de la propriété libelleDeviseAnnuite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleDeviseAnnuite(String value) {
        this.libelleDeviseAnnuite = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetValorisation.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffetValorisation() {
        return dateFinEffetValorisation;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetValorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffetValorisation(XMLGregorianCalendar value) {
        this.dateFinEffetValorisation = value;
    }

    /**
     * Obtient la valeur de la propriété tauxValorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTauxValorisation() {
        return tauxValorisation;
    }

    /**
     * Définit la valeur de la propriété tauxValorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTauxValorisation(String value) {
        this.tauxValorisation = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchaineRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchaineRevalorisation() {
        return dateProchaineRevalorisation;
    }

    /**
     * Définit la valeur de la propriété dateProchaineRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchaineRevalorisation(XMLGregorianCalendar value) {
        this.dateProchaineRevalorisation = value;
    }

    /**
     * Gets the value of the palierAnnuite property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the palierAnnuite property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPalierAnnuite().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PalierAnntType }
     * 
     * 
     */
    public List<PalierAnntType> getPalierAnnuite() {
        if (palierAnnuite == null) {
            palierAnnuite = new ArrayList<PalierAnntType>();
        }
        return this.palierAnnuite;
    }

}
