
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentContratPereType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentContratPereType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentsPere" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentsPereType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentContratPereType", propOrder = {
    "identsPere"
})
public class IdentContratPereType {

    @XmlElement(name = "IdentsPere")
    protected IdentsPereType identsPere;

    /**
     * Obtient la valeur de la propriété identsPere.
     * 
     * @return
     *     possible object is
     *     {@link IdentsPereType }
     *     
     */
    public IdentsPereType getIdentsPere() {
        return identsPere;
    }

    /**
     * Définit la valeur de la propriété identsPere.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentsPereType }
     *     
     */
    public void setIdentsPere(IdentsPereType value) {
        this.identsPere = value;
    }

}
