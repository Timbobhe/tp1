
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AssurePrincipalType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AssurePrincipalType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloAssurePrincipal" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}IdentificationType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssurePrincipalType", propOrder = {
    "identSiloAssurePrincipal"
})
public class AssurePrincipalType {

    @XmlElement(name = "IdentSiloAssurePrincipal", required = true)
    protected IdentificationType identSiloAssurePrincipal;

    /**
     * Obtient la valeur de la propriété identSiloAssurePrincipal.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getIdentSiloAssurePrincipal() {
        return identSiloAssurePrincipal;
    }

    /**
     * Définit la valeur de la propriété identSiloAssurePrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setIdentSiloAssurePrincipal(IdentificationType value) {
        this.identSiloAssurePrincipal = value;
    }

}
