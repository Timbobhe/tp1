
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratAssureType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratAssureType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}CtrColl" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}CtrIndv" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratAssureType", propOrder = {
    "ctrColl",
    "ctrIndv"
})
public class ContratAssureType {

    @XmlElement(name = "CtrColl")
    protected ContratCollectifType ctrColl;
    @XmlElement(name = "CtrIndv")
    protected ContratIndividuelType ctrIndv;

    /**
     * Obtient la valeur de la propriété ctrColl.
     * 
     * @return
     *     possible object is
     *     {@link ContratCollectifType }
     *     
     */
    public ContratCollectifType getCtrColl() {
        return ctrColl;
    }

    /**
     * Définit la valeur de la propriété ctrColl.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratCollectifType }
     *     
     */
    public void setCtrColl(ContratCollectifType value) {
        this.ctrColl = value;
    }

    /**
     * Obtient la valeur de la propriété ctrIndv.
     * 
     * @return
     *     possible object is
     *     {@link ContratIndividuelType }
     *     
     */
    public ContratIndividuelType getCtrIndv() {
        return ctrIndv;
    }

    /**
     * Définit la valeur de la propriété ctrIndv.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratIndividuelType }
     *     
     */
    public void setCtrIndv(ContratIndividuelType value) {
        this.ctrIndv = value;
    }

}
