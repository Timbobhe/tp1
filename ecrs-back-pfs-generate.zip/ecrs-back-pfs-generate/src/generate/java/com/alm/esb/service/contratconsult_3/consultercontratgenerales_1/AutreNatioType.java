
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AutreNatioType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AutreNatioType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeNatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatio" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AutreNatioType", propOrder = {
    "codeNatio",
    "libNatio"
})
public class AutreNatioType {

    protected String codeNatio;
    protected String libNatio;

    /**
     * Obtient la valeur de la propriété codeNatio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatio() {
        return codeNatio;
    }

    /**
     * Définit la valeur de la propriété codeNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatio(String value) {
        this.codeNatio = value;
    }

    /**
     * Obtient la valeur de la propriété libNatio.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatio() {
        return libNatio;
    }

    /**
     * Définit la valeur de la propriété libNatio.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatio(String value) {
        this.libNatio = value;
    }

}
