
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterClausesBenefCtrFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterClausesBenefCtrFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}ConsulterClausesBenefCtr" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}ConsulterClausesBenefCtrResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterClausesBenefCtrFullType", propOrder = {
    "consulterClausesBenefCtr",
    "consulterClausesBenefCtrResponse"
})
public class ConsulterClausesBenefCtrFullType {

    @XmlElement(name = "ConsulterClausesBenefCtr")
    protected ConsulterClausesBenefCtrType consulterClausesBenefCtr;
    @XmlElement(name = "ConsulterClausesBenefCtrResponse")
    protected ConsulterClausesBenefCtrResponseType consulterClausesBenefCtrResponse;

    /**
     * Obtient la valeur de la propriété consulterClausesBenefCtr.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterClausesBenefCtrType }
     *     
     */
    public ConsulterClausesBenefCtrType getConsulterClausesBenefCtr() {
        return consulterClausesBenefCtr;
    }

    /**
     * Définit la valeur de la propriété consulterClausesBenefCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterClausesBenefCtrType }
     *     
     */
    public void setConsulterClausesBenefCtr(ConsulterClausesBenefCtrType value) {
        this.consulterClausesBenefCtr = value;
    }

    /**
     * Obtient la valeur de la propriété consulterClausesBenefCtrResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterClausesBenefCtrResponseType }
     *     
     */
    public ConsulterClausesBenefCtrResponseType getConsulterClausesBenefCtrResponse() {
        return consulterClausesBenefCtrResponse;
    }

    /**
     * Définit la valeur de la propriété consulterClausesBenefCtrResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterClausesBenefCtrResponseType }
     *     
     */
    public void setConsulterClausesBenefCtrResponse(ConsulterClausesBenefCtrResponseType value) {
        this.consulterClausesBenefCtrResponse = value;
    }

}
