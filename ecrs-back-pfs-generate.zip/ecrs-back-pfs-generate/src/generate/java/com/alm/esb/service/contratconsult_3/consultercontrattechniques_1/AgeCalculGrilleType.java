
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ageCalculGrilleType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ageCalculGrilleType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ageCalculGrille" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="indModifAgeCalculAutorise" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ageCalculGrilleType", propOrder = {
    "ageCalculGrille",
    "indModifAgeCalculAutorise"
})
public class AgeCalculGrilleType {

    protected BigInteger ageCalculGrille;
    protected Boolean indModifAgeCalculAutorise;

    /**
     * Obtient la valeur de la propriété ageCalculGrille.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeCalculGrille() {
        return ageCalculGrille;
    }

    /**
     * Définit la valeur de la propriété ageCalculGrille.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeCalculGrille(BigInteger value) {
        this.ageCalculGrille = value;
    }

    /**
     * Obtient la valeur de la propriété indModifAgeCalculAutorise.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndModifAgeCalculAutorise() {
        return indModifAgeCalculAutorise;
    }

    /**
     * Définit la valeur de la propriété indModifAgeCalculAutorise.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndModifAgeCalculAutorise(Boolean value) {
        this.indModifAgeCalculAutorise = value;
    }

}
