
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentSiloCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="IdentSiloCtrPere" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentDansSiloType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="libCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNatCtrSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeBrcheAssur" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libBrcheAssur" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeBrcheAssurSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentCtrType", propOrder = {
    "identSiloCtr",
    "identSiloCtrPere",
    "libCtr",
    "codeNatCtr",
    "libNatCtr",
    "codeNatCtrSilo",
    "codeBrcheAssur",
    "libBrcheAssur",
    "codeBrcheAssurSilo"
})
public class IdentCtrType {

    @XmlElement(name = "IdentSiloCtr")
    protected List<IdentSiloCtrType> identSiloCtr;
    @XmlElement(name = "IdentSiloCtrPere")
    protected List<IdentDansSiloType> identSiloCtrPere;
    protected String libCtr;
    protected String codeNatCtr;
    protected String libNatCtr;
    protected String codeNatCtrSilo;
    protected String codeBrcheAssur;
    protected String libBrcheAssur;
    protected String codeBrcheAssurSilo;

    /**
     * Gets the value of the identSiloCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identSiloCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentSiloCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentSiloCtrType }
     * 
     * 
     */
    public List<IdentSiloCtrType> getIdentSiloCtr() {
        if (identSiloCtr == null) {
            identSiloCtr = new ArrayList<IdentSiloCtrType>();
        }
        return this.identSiloCtr;
    }

    /**
     * Gets the value of the identSiloCtrPere property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identSiloCtrPere property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentSiloCtrPere().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentDansSiloType }
     * 
     * 
     */
    public List<IdentDansSiloType> getIdentSiloCtrPere() {
        if (identSiloCtrPere == null) {
            identSiloCtrPere = new ArrayList<IdentDansSiloType>();
        }
        return this.identSiloCtrPere;
    }

    /**
     * Obtient la valeur de la propriété libCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCtr() {
        return libCtr;
    }

    /**
     * Définit la valeur de la propriété libCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCtr(String value) {
        this.libCtr = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatCtr() {
        return codeNatCtr;
    }

    /**
     * Définit la valeur de la propriété codeNatCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatCtr(String value) {
        this.codeNatCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libNatCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatCtr() {
        return libNatCtr;
    }

    /**
     * Définit la valeur de la propriété libNatCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatCtr(String value) {
        this.libNatCtr = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatCtrSilo() {
        return codeNatCtrSilo;
    }

    /**
     * Définit la valeur de la propriété codeNatCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatCtrSilo(String value) {
        this.codeNatCtrSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrcheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrcheAssur() {
        return codeBrcheAssur;
    }

    /**
     * Définit la valeur de la propriété codeBrcheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrcheAssur(String value) {
        this.codeBrcheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété libBrcheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibBrcheAssur() {
        return libBrcheAssur;
    }

    /**
     * Définit la valeur de la propriété libBrcheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibBrcheAssur(String value) {
        this.libBrcheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrcheAssurSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrcheAssurSilo() {
        return codeBrcheAssurSilo;
    }

    /**
     * Définit la valeur de la propriété codeBrcheAssurSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrcheAssurSilo(String value) {
        this.codeBrcheAssurSilo = value;
    }

}
