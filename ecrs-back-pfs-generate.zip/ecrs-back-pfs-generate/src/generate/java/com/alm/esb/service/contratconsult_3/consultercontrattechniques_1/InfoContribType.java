
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour InfoContribType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoContribType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeContributionEncours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleContributionEncours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="deviseEncours" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantEncours" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoContribType", propOrder = {
    "codeContributionEncours",
    "libelleContributionEncours",
    "deviseEncours",
    "montantEncours"
})
public class InfoContribType {

    protected String codeContributionEncours;
    protected String libelleContributionEncours;
    protected String deviseEncours;
    protected BigDecimal montantEncours;

    /**
     * Obtient la valeur de la propriété codeContributionEncours.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeContributionEncours() {
        return codeContributionEncours;
    }

    /**
     * Définit la valeur de la propriété codeContributionEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeContributionEncours(String value) {
        this.codeContributionEncours = value;
    }

    /**
     * Obtient la valeur de la propriété libelleContributionEncours.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleContributionEncours() {
        return libelleContributionEncours;
    }

    /**
     * Définit la valeur de la propriété libelleContributionEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleContributionEncours(String value) {
        this.libelleContributionEncours = value;
    }

    /**
     * Obtient la valeur de la propriété deviseEncours.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviseEncours() {
        return deviseEncours;
    }

    /**
     * Définit la valeur de la propriété deviseEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviseEncours(String value) {
        this.deviseEncours = value;
    }

    /**
     * Obtient la valeur de la propriété montantEncours.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantEncours() {
        return montantEncours;
    }

    /**
     * Définit la valeur de la propriété montantEncours.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantEncours(BigDecimal value) {
        this.montantEncours = value;
    }

}
