
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numUE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSItContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitContratSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitContrat" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeFiscEpargne" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libFiscEpargne" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeFiscEpargneSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libFiscEpargneSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffetFiscale" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="typeChainageCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeChainageCtrRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeGestion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeGestion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeGestionSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeGestionSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idContratRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libContratRef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCpteGestCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCpteGestCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeOptFiscaliteAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOptFiscaliteAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numExterneContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idPortefeuilleContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomPortefeuilleContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="motifCessation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateChainage" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateMiseEnGest" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="indGestRepartie" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="comZLS" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Ctx" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}CtxTypeType" minOccurs="0"/>
 *         &lt;element name="briqueUROrigine" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indCtrResponsable" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoContratType", propOrder = {
    "numUE",
    "dateEffet",
    "dateFinEffet",
    "codeSitContrat",
    "libSitContrat",
    "codeSItContratSilo",
    "libSitContratSilo",
    "dateSitContrat",
    "codeFiscEpargne",
    "libFiscEpargne",
    "codeFiscEpargneSilo",
    "libFiscEpargneSilo",
    "dateEffetFiscale",
    "typeChainageCtrRef",
    "libTypeChainageCtrRef",
    "codeModeGestion",
    "libModeGestion",
    "codeModeGestionSilo",
    "libModeGestionSilo",
    "idContratRef",
    "libContratRef",
    "codeCpteGestCotis",
    "libCpteGestCotis",
    "codeOptFiscaliteAffil",
    "libOptFiscaliteAffil",
    "numExterneContrat",
    "idPortefeuilleContrat",
    "nomPortefeuilleContrat",
    "motifCessation",
    "dateChainage",
    "dateMiseEnGest",
    "indGestRepartie",
    "comZLS",
    "ctx",
    "briqueUROrigine",
    "indCtrResponsable"
})
public class InfoContratType {

    protected String numUE;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffet;
    protected String codeSitContrat;
    protected String libSitContrat;
    protected String codeSItContratSilo;
    protected String libSitContratSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitContrat;
    protected String codeFiscEpargne;
    protected String libFiscEpargne;
    protected String codeFiscEpargneSilo;
    protected String libFiscEpargneSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetFiscale;
    protected String typeChainageCtrRef;
    protected String libTypeChainageCtrRef;
    protected String codeModeGestion;
    protected String libModeGestion;
    protected String codeModeGestionSilo;
    protected String libModeGestionSilo;
    protected String idContratRef;
    protected String libContratRef;
    protected String codeCpteGestCotis;
    protected String libCpteGestCotis;
    protected String codeOptFiscaliteAffil;
    protected String libOptFiscaliteAffil;
    protected String numExterneContrat;
    protected String idPortefeuilleContrat;
    protected String nomPortefeuilleContrat;
    protected String motifCessation;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateChainage;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateMiseEnGest;
    protected Boolean indGestRepartie;
    protected String comZLS;
    @XmlElement(name = "Ctx")
    protected CtxTypeType ctx;
    protected String briqueUROrigine;
    protected Boolean indCtrResponsable;

    /**
     * Obtient la valeur de la propriété numUE.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumUE() {
        return numUE;
    }

    /**
     * Définit la valeur de la propriété numUE.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumUE(String value) {
        this.numUE = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffet() {
        return dateEffet;
    }

    /**
     * Définit la valeur de la propriété dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffet(XMLGregorianCalendar value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffet() {
        return dateFinEffet;
    }

    /**
     * Définit la valeur de la propriété dateFinEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffet(XMLGregorianCalendar value) {
        this.dateFinEffet = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitContrat() {
        return codeSitContrat;
    }

    /**
     * Définit la valeur de la propriété codeSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitContrat(String value) {
        this.codeSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitContrat() {
        return libSitContrat;
    }

    /**
     * Définit la valeur de la propriété libSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitContrat(String value) {
        this.libSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeSItContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSItContratSilo() {
        return codeSItContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeSItContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSItContratSilo(String value) {
        this.codeSItContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libSitContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitContratSilo() {
        return libSitContratSilo;
    }

    /**
     * Définit la valeur de la propriété libSitContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitContratSilo(String value) {
        this.libSitContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitContrat() {
        return dateSitContrat;
    }

    /**
     * Définit la valeur de la propriété dateSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitContrat(XMLGregorianCalendar value) {
        this.dateSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeFiscEpargne.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFiscEpargne() {
        return codeFiscEpargne;
    }

    /**
     * Définit la valeur de la propriété codeFiscEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFiscEpargne(String value) {
        this.codeFiscEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété libFiscEpargne.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibFiscEpargne() {
        return libFiscEpargne;
    }

    /**
     * Définit la valeur de la propriété libFiscEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibFiscEpargne(String value) {
        this.libFiscEpargne = value;
    }

    /**
     * Obtient la valeur de la propriété codeFiscEpargneSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFiscEpargneSilo() {
        return codeFiscEpargneSilo;
    }

    /**
     * Définit la valeur de la propriété codeFiscEpargneSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFiscEpargneSilo(String value) {
        this.codeFiscEpargneSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libFiscEpargneSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibFiscEpargneSilo() {
        return libFiscEpargneSilo;
    }

    /**
     * Définit la valeur de la propriété libFiscEpargneSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibFiscEpargneSilo(String value) {
        this.libFiscEpargneSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetFiscale.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetFiscale() {
        return dateEffetFiscale;
    }

    /**
     * Définit la valeur de la propriété dateEffetFiscale.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetFiscale(XMLGregorianCalendar value) {
        this.dateEffetFiscale = value;
    }

    /**
     * Obtient la valeur de la propriété typeChainageCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeChainageCtrRef() {
        return typeChainageCtrRef;
    }

    /**
     * Définit la valeur de la propriété typeChainageCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeChainageCtrRef(String value) {
        this.typeChainageCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeChainageCtrRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeChainageCtrRef() {
        return libTypeChainageCtrRef;
    }

    /**
     * Définit la valeur de la propriété libTypeChainageCtrRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeChainageCtrRef(String value) {
        this.libTypeChainageCtrRef = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGestion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGestion() {
        return codeModeGestion;
    }

    /**
     * Définit la valeur de la propriété codeModeGestion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGestion(String value) {
        this.codeModeGestion = value;
    }

    /**
     * Obtient la valeur de la propriété libModeGestion.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeGestion() {
        return libModeGestion;
    }

    /**
     * Définit la valeur de la propriété libModeGestion.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeGestion(String value) {
        this.libModeGestion = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeGestionSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeGestionSilo() {
        return codeModeGestionSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeGestionSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeGestionSilo(String value) {
        this.codeModeGestionSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeGestionSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeGestionSilo() {
        return libModeGestionSilo;
    }

    /**
     * Définit la valeur de la propriété libModeGestionSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeGestionSilo(String value) {
        this.libModeGestionSilo = value;
    }

    /**
     * Obtient la valeur de la propriété idContratRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdContratRef() {
        return idContratRef;
    }

    /**
     * Définit la valeur de la propriété idContratRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdContratRef(String value) {
        this.idContratRef = value;
    }

    /**
     * Obtient la valeur de la propriété libContratRef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibContratRef() {
        return libContratRef;
    }

    /**
     * Définit la valeur de la propriété libContratRef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibContratRef(String value) {
        this.libContratRef = value;
    }

    /**
     * Obtient la valeur de la propriété codeCpteGestCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCpteGestCotis() {
        return codeCpteGestCotis;
    }

    /**
     * Définit la valeur de la propriété codeCpteGestCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCpteGestCotis(String value) {
        this.codeCpteGestCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libCpteGestCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCpteGestCotis() {
        return libCpteGestCotis;
    }

    /**
     * Définit la valeur de la propriété libCpteGestCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCpteGestCotis(String value) {
        this.libCpteGestCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeOptFiscaliteAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOptFiscaliteAffil() {
        return codeOptFiscaliteAffil;
    }

    /**
     * Définit la valeur de la propriété codeOptFiscaliteAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOptFiscaliteAffil(String value) {
        this.codeOptFiscaliteAffil = value;
    }

    /**
     * Obtient la valeur de la propriété libOptFiscaliteAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOptFiscaliteAffil() {
        return libOptFiscaliteAffil;
    }

    /**
     * Définit la valeur de la propriété libOptFiscaliteAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOptFiscaliteAffil(String value) {
        this.libOptFiscaliteAffil = value;
    }

    /**
     * Obtient la valeur de la propriété numExterneContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumExterneContrat() {
        return numExterneContrat;
    }

    /**
     * Définit la valeur de la propriété numExterneContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumExterneContrat(String value) {
        this.numExterneContrat = value;
    }

    /**
     * Obtient la valeur de la propriété idPortefeuilleContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdPortefeuilleContrat() {
        return idPortefeuilleContrat;
    }

    /**
     * Définit la valeur de la propriété idPortefeuilleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdPortefeuilleContrat(String value) {
        this.idPortefeuilleContrat = value;
    }

    /**
     * Obtient la valeur de la propriété nomPortefeuilleContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomPortefeuilleContrat() {
        return nomPortefeuilleContrat;
    }

    /**
     * Définit la valeur de la propriété nomPortefeuilleContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomPortefeuilleContrat(String value) {
        this.nomPortefeuilleContrat = value;
    }

    /**
     * Obtient la valeur de la propriété motifCessation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifCessation() {
        return motifCessation;
    }

    /**
     * Définit la valeur de la propriété motifCessation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifCessation(String value) {
        this.motifCessation = value;
    }

    /**
     * Obtient la valeur de la propriété dateChainage.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateChainage() {
        return dateChainage;
    }

    /**
     * Définit la valeur de la propriété dateChainage.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateChainage(XMLGregorianCalendar value) {
        this.dateChainage = value;
    }

    /**
     * Obtient la valeur de la propriété dateMiseEnGest.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateMiseEnGest() {
        return dateMiseEnGest;
    }

    /**
     * Définit la valeur de la propriété dateMiseEnGest.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateMiseEnGest(XMLGregorianCalendar value) {
        this.dateMiseEnGest = value;
    }

    /**
     * Obtient la valeur de la propriété indGestRepartie.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndGestRepartie() {
        return indGestRepartie;
    }

    /**
     * Définit la valeur de la propriété indGestRepartie.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndGestRepartie(Boolean value) {
        this.indGestRepartie = value;
    }

    /**
     * Obtient la valeur de la propriété comZLS.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComZLS() {
        return comZLS;
    }

    /**
     * Définit la valeur de la propriété comZLS.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComZLS(String value) {
        this.comZLS = value;
    }

    /**
     * Obtient la valeur de la propriété ctx.
     * 
     * @return
     *     possible object is
     *     {@link CtxTypeType }
     *     
     */
    public CtxTypeType getCtx() {
        return ctx;
    }

    /**
     * Définit la valeur de la propriété ctx.
     * 
     * @param value
     *     allowed object is
     *     {@link CtxTypeType }
     *     
     */
    public void setCtx(CtxTypeType value) {
        this.ctx = value;
    }

    /**
     * Obtient la valeur de la propriété briqueUROrigine.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBriqueUROrigine() {
        return briqueUROrigine;
    }

    /**
     * Définit la valeur de la propriété briqueUROrigine.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBriqueUROrigine(String value) {
        this.briqueUROrigine = value;
    }

    /**
     * Obtient la valeur de la propriété indCtrResponsable.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndCtrResponsable() {
        return indCtrResponsable;
    }

    /**
     * Définit la valeur de la propriété indCtrResponsable.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndCtrResponsable(Boolean value) {
        this.indCtrResponsable = value;
    }

}
