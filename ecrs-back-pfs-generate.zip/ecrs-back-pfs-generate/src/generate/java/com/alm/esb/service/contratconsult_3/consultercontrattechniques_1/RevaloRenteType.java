
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RevaloRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RevaloRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeModeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleModeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleTypeRevalorisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RevaloRenteType", propOrder = {
    "codeModeRevalorisation",
    "libelleModeRevalorisation",
    "codeTypeRevalorisation",
    "libelleTypeRevalorisation"
})
public class RevaloRenteType {

    protected String codeModeRevalorisation;
    protected String libelleModeRevalorisation;
    protected String codeTypeRevalorisation;
    protected String libelleTypeRevalorisation;

    /**
     * Obtient la valeur de la propriété codeModeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeRevalorisation() {
        return codeModeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété codeModeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeRevalorisation(String value) {
        this.codeModeRevalorisation = value;
    }

    /**
     * Obtient la valeur de la propriété libelleModeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleModeRevalorisation() {
        return libelleModeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété libelleModeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleModeRevalorisation(String value) {
        this.libelleModeRevalorisation = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeRevalorisation() {
        return codeTypeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété codeTypeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeRevalorisation(String value) {
        this.codeTypeRevalorisation = value;
    }

    /**
     * Obtient la valeur de la propriété libelleTypeRevalorisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleTypeRevalorisation() {
        return libelleTypeRevalorisation;
    }

    /**
     * Définit la valeur de la propriété libelleTypeRevalorisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleTypeRevalorisation(String value) {
        this.libelleTypeRevalorisation = value;
    }

}
