
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OfrCialSouscType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OfrCialSouscType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeOfrCial" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libOfrCialLg" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libOfrCialCrt" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OfrCialSouscType", propOrder = {
    "codeOfrCial",
    "libOfrCialLg",
    "libOfrCialCrt"
})
public class OfrCialSouscType {

    protected String codeOfrCial;
    protected String libOfrCialLg;
    protected String libOfrCialCrt;

    /**
     * Obtient la valeur de la propriété codeOfrCial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOfrCial() {
        return codeOfrCial;
    }

    /**
     * Définit la valeur de la propriété codeOfrCial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOfrCial(String value) {
        this.codeOfrCial = value;
    }

    /**
     * Obtient la valeur de la propriété libOfrCialLg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOfrCialLg() {
        return libOfrCialLg;
    }

    /**
     * Définit la valeur de la propriété libOfrCialLg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOfrCialLg(String value) {
        this.libOfrCialLg = value;
    }

    /**
     * Obtient la valeur de la propriété libOfrCialCrt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOfrCialCrt() {
        return libOfrCialCrt;
    }

    /**
     * Définit la valeur de la propriété libOfrCialCrt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOfrCialCrt(String value) {
        this.libOfrCialCrt = value;
    }

}
