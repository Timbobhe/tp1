
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RechercherContratsFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RechercherContratsFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}RechercherContrats" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}RechercherContratsResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RechercherContratsFullType", propOrder = {
    "rechercherContrats",
    "rechercherContratsResponse"
})
public class RechercherContratsFullType {

    @XmlElement(name = "RechercherContrats")
    protected RechercherContratsType rechercherContrats;
    @XmlElement(name = "RechercherContratsResponse")
    protected RechercherContratsResponseType rechercherContratsResponse;

    /**
     * Obtient la valeur de la propriété rechercherContrats.
     * 
     * @return
     *     possible object is
     *     {@link RechercherContratsType }
     *     
     */
    public RechercherContratsType getRechercherContrats() {
        return rechercherContrats;
    }

    /**
     * Définit la valeur de la propriété rechercherContrats.
     * 
     * @param value
     *     allowed object is
     *     {@link RechercherContratsType }
     *     
     */
    public void setRechercherContrats(RechercherContratsType value) {
        this.rechercherContrats = value;
    }

    /**
     * Obtient la valeur de la propriété rechercherContratsResponse.
     * 
     * @return
     *     possible object is
     *     {@link RechercherContratsResponseType }
     *     
     */
    public RechercherContratsResponseType getRechercherContratsResponse() {
        return rechercherContratsResponse;
    }

    /**
     * Définit la valeur de la propriété rechercherContratsResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link RechercherContratsResponseType }
     *     
     */
    public void setRechercherContratsResponse(RechercherContratsResponseType value) {
        this.rechercherContratsResponse = value;
    }

}
