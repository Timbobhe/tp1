
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CtrCollType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtrCollType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indSuiviPartcl" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indPrsmptPrsl" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeMntgTech" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="motifMntgTech" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeMotifAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libMotifAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeDetailMotifAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDetailMotifAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="CatPrsl" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CatPrslType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AffilCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AffilCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="Adh" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}AdhType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ClauseCtr" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}ClauseCtrType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtrCollType", propOrder = {
    "indSuiviPartcl",
    "indPrsmptPrsl",
    "codeMntgTech",
    "motifMntgTech",
    "codeMotifAdh",
    "libMotifAdh",
    "codeDetailMotifAdh",
    "libDetailMotifAdh",
    "catPrsl",
    "affilCtr",
    "adh",
    "clauseCtr"
})
public class CtrCollType {

    protected Boolean indSuiviPartcl;
    protected Boolean indPrsmptPrsl;
    protected String codeMntgTech;
    protected String motifMntgTech;
    protected String codeMotifAdh;
    protected String libMotifAdh;
    protected String codeDetailMotifAdh;
    protected String libDetailMotifAdh;
    @XmlElement(name = "CatPrsl")
    protected List<CatPrslType> catPrsl;
    @XmlElement(name = "AffilCtr")
    protected List<AffilCtrType> affilCtr;
    @XmlElement(name = "Adh")
    protected List<AdhType> adh;
    @XmlElement(name = "ClauseCtr")
    protected List<ClauseCtrType> clauseCtr;

    /**
     * Obtient la valeur de la propriété indSuiviPartcl.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndSuiviPartcl() {
        return indSuiviPartcl;
    }

    /**
     * Définit la valeur de la propriété indSuiviPartcl.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndSuiviPartcl(Boolean value) {
        this.indSuiviPartcl = value;
    }

    /**
     * Obtient la valeur de la propriété indPrsmptPrsl.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndPrsmptPrsl() {
        return indPrsmptPrsl;
    }

    /**
     * Définit la valeur de la propriété indPrsmptPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndPrsmptPrsl(Boolean value) {
        this.indPrsmptPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété codeMntgTech.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMntgTech() {
        return codeMntgTech;
    }

    /**
     * Définit la valeur de la propriété codeMntgTech.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMntgTech(String value) {
        this.codeMntgTech = value;
    }

    /**
     * Obtient la valeur de la propriété motifMntgTech.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMotifMntgTech() {
        return motifMntgTech;
    }

    /**
     * Définit la valeur de la propriété motifMntgTech.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMotifMntgTech(String value) {
        this.motifMntgTech = value;
    }

    /**
     * Obtient la valeur de la propriété codeMotifAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMotifAdh() {
        return codeMotifAdh;
    }

    /**
     * Définit la valeur de la propriété codeMotifAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMotifAdh(String value) {
        this.codeMotifAdh = value;
    }

    /**
     * Obtient la valeur de la propriété libMotifAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibMotifAdh() {
        return libMotifAdh;
    }

    /**
     * Définit la valeur de la propriété libMotifAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibMotifAdh(String value) {
        this.libMotifAdh = value;
    }

    /**
     * Obtient la valeur de la propriété codeDetailMotifAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDetailMotifAdh() {
        return codeDetailMotifAdh;
    }

    /**
     * Définit la valeur de la propriété codeDetailMotifAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDetailMotifAdh(String value) {
        this.codeDetailMotifAdh = value;
    }

    /**
     * Obtient la valeur de la propriété libDetailMotifAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDetailMotifAdh() {
        return libDetailMotifAdh;
    }

    /**
     * Définit la valeur de la propriété libDetailMotifAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDetailMotifAdh(String value) {
        this.libDetailMotifAdh = value;
    }

    /**
     * Gets the value of the catPrsl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the catPrsl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCatPrsl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CatPrslType }
     * 
     * 
     */
    public List<CatPrslType> getCatPrsl() {
        if (catPrsl == null) {
            catPrsl = new ArrayList<CatPrslType>();
        }
        return this.catPrsl;
    }

    /**
     * Gets the value of the affilCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the affilCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAffilCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AffilCtrType }
     * 
     * 
     */
    public List<AffilCtrType> getAffilCtr() {
        if (affilCtr == null) {
            affilCtr = new ArrayList<AffilCtrType>();
        }
        return this.affilCtr;
    }

    /**
     * Gets the value of the adh property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the adh property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdh().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdhType }
     * 
     * 
     */
    public List<AdhType> getAdh() {
        if (adh == null) {
            adh = new ArrayList<AdhType>();
        }
        return this.adh;
    }

    /**
     * Gets the value of the clauseCtr property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the clauseCtr property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getClauseCtr().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ClauseCtrType }
     * 
     * 
     */
    public List<ClauseCtrType> getClauseCtr() {
        if (clauseCtr == null) {
            clauseCtr = new ArrayList<ClauseCtrType>();
        }
        return this.clauseCtr;
    }

}
