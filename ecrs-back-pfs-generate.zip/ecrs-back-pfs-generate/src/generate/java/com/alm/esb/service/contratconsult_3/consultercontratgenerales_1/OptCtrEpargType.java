
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour OptCtrEpargType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OptCtrEpargType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeGestCmpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libGestCmpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeGestCmptSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeFndGere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeFndGere" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeFndGereSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indAutionChoixPlcmtDifferent" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indRefusVersmFaclt" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indTarifctVersmPrimeAutor" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indRefusArbitInet" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indSortieTotaleCtr" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indTypeArbitAutor" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="echFixeArbit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indArbitInterdit" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="libFiscEparg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateChoixRente" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeFiscEpargSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffetFisc" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinFisc" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="nbeArbitrageAnn" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="nbeArbitrageCtr" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="indReinvRemun" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OptCtrEpargType", propOrder = {
    "codeGestCmpt",
    "libGestCmpt",
    "codeGestCmptSilo",
    "codeTypeFndGere",
    "libTypeFndGere",
    "codeTypeFndGereSilo",
    "indAutionChoixPlcmtDifferent",
    "indRefusVersmFaclt",
    "indTarifctVersmPrimeAutor",
    "indRefusArbitInet",
    "indSortieTotaleCtr",
    "indTypeArbitAutor",
    "echFixeArbit",
    "indArbitInterdit",
    "libFiscEparg",
    "dateChoixRente",
    "codeFiscEpargSilo",
    "dateEffetFisc",
    "dateFinFisc",
    "nbeArbitrageAnn",
    "nbeArbitrageCtr",
    "indReinvRemun"
})
public class OptCtrEpargType {

    protected String codeGestCmpt;
    protected String libGestCmpt;
    protected String codeGestCmptSilo;
    protected String codeTypeFndGere;
    protected String libTypeFndGere;
    protected String codeTypeFndGereSilo;
    protected Boolean indAutionChoixPlcmtDifferent;
    protected Boolean indRefusVersmFaclt;
    protected Boolean indTarifctVersmPrimeAutor;
    protected Boolean indRefusArbitInet;
    protected Boolean indSortieTotaleCtr;
    protected Boolean indTypeArbitAutor;
    protected String echFixeArbit;
    protected Boolean indArbitInterdit;
    protected String libFiscEparg;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateChoixRente;
    protected String codeFiscEpargSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetFisc;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinFisc;
    protected BigInteger nbeArbitrageAnn;
    protected BigInteger nbeArbitrageCtr;
    protected Boolean indReinvRemun;

    /**
     * Obtient la valeur de la propriété codeGestCmpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGestCmpt() {
        return codeGestCmpt;
    }

    /**
     * Définit la valeur de la propriété codeGestCmpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGestCmpt(String value) {
        this.codeGestCmpt = value;
    }

    /**
     * Obtient la valeur de la propriété libGestCmpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibGestCmpt() {
        return libGestCmpt;
    }

    /**
     * Définit la valeur de la propriété libGestCmpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibGestCmpt(String value) {
        this.libGestCmpt = value;
    }

    /**
     * Obtient la valeur de la propriété codeGestCmptSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGestCmptSilo() {
        return codeGestCmptSilo;
    }

    /**
     * Définit la valeur de la propriété codeGestCmptSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGestCmptSilo(String value) {
        this.codeGestCmptSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeFndGere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeFndGere() {
        return codeTypeFndGere;
    }

    /**
     * Définit la valeur de la propriété codeTypeFndGere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeFndGere(String value) {
        this.codeTypeFndGere = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeFndGere.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeFndGere() {
        return libTypeFndGere;
    }

    /**
     * Définit la valeur de la propriété libTypeFndGere.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeFndGere(String value) {
        this.libTypeFndGere = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeFndGereSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeFndGereSilo() {
        return codeTypeFndGereSilo;
    }

    /**
     * Définit la valeur de la propriété codeTypeFndGereSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeFndGereSilo(String value) {
        this.codeTypeFndGereSilo = value;
    }

    /**
     * Obtient la valeur de la propriété indAutionChoixPlcmtDifferent.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndAutionChoixPlcmtDifferent() {
        return indAutionChoixPlcmtDifferent;
    }

    /**
     * Définit la valeur de la propriété indAutionChoixPlcmtDifferent.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndAutionChoixPlcmtDifferent(Boolean value) {
        this.indAutionChoixPlcmtDifferent = value;
    }

    /**
     * Obtient la valeur de la propriété indRefusVersmFaclt.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndRefusVersmFaclt() {
        return indRefusVersmFaclt;
    }

    /**
     * Définit la valeur de la propriété indRefusVersmFaclt.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndRefusVersmFaclt(Boolean value) {
        this.indRefusVersmFaclt = value;
    }

    /**
     * Obtient la valeur de la propriété indTarifctVersmPrimeAutor.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndTarifctVersmPrimeAutor() {
        return indTarifctVersmPrimeAutor;
    }

    /**
     * Définit la valeur de la propriété indTarifctVersmPrimeAutor.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndTarifctVersmPrimeAutor(Boolean value) {
        this.indTarifctVersmPrimeAutor = value;
    }

    /**
     * Obtient la valeur de la propriété indRefusArbitInet.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndRefusArbitInet() {
        return indRefusArbitInet;
    }

    /**
     * Définit la valeur de la propriété indRefusArbitInet.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndRefusArbitInet(Boolean value) {
        this.indRefusArbitInet = value;
    }

    /**
     * Obtient la valeur de la propriété indSortieTotaleCtr.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndSortieTotaleCtr() {
        return indSortieTotaleCtr;
    }

    /**
     * Définit la valeur de la propriété indSortieTotaleCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndSortieTotaleCtr(Boolean value) {
        this.indSortieTotaleCtr = value;
    }

    /**
     * Obtient la valeur de la propriété indTypeArbitAutor.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndTypeArbitAutor() {
        return indTypeArbitAutor;
    }

    /**
     * Définit la valeur de la propriété indTypeArbitAutor.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndTypeArbitAutor(Boolean value) {
        this.indTypeArbitAutor = value;
    }

    /**
     * Obtient la valeur de la propriété echFixeArbit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEchFixeArbit() {
        return echFixeArbit;
    }

    /**
     * Définit la valeur de la propriété echFixeArbit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEchFixeArbit(String value) {
        this.echFixeArbit = value;
    }

    /**
     * Obtient la valeur de la propriété indArbitInterdit.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndArbitInterdit() {
        return indArbitInterdit;
    }

    /**
     * Définit la valeur de la propriété indArbitInterdit.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndArbitInterdit(Boolean value) {
        this.indArbitInterdit = value;
    }

    /**
     * Obtient la valeur de la propriété libFiscEparg.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibFiscEparg() {
        return libFiscEparg;
    }

    /**
     * Définit la valeur de la propriété libFiscEparg.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibFiscEparg(String value) {
        this.libFiscEparg = value;
    }

    /**
     * Obtient la valeur de la propriété dateChoixRente.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateChoixRente() {
        return dateChoixRente;
    }

    /**
     * Définit la valeur de la propriété dateChoixRente.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateChoixRente(XMLGregorianCalendar value) {
        this.dateChoixRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeFiscEpargSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFiscEpargSilo() {
        return codeFiscEpargSilo;
    }

    /**
     * Définit la valeur de la propriété codeFiscEpargSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFiscEpargSilo(String value) {
        this.codeFiscEpargSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetFisc.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetFisc() {
        return dateEffetFisc;
    }

    /**
     * Définit la valeur de la propriété dateEffetFisc.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetFisc(XMLGregorianCalendar value) {
        this.dateEffetFisc = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinFisc.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinFisc() {
        return dateFinFisc;
    }

    /**
     * Définit la valeur de la propriété dateFinFisc.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinFisc(XMLGregorianCalendar value) {
        this.dateFinFisc = value;
    }

    /**
     * Obtient la valeur de la propriété nbeArbitrageAnn.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNbeArbitrageAnn() {
        return nbeArbitrageAnn;
    }

    /**
     * Définit la valeur de la propriété nbeArbitrageAnn.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNbeArbitrageAnn(BigInteger value) {
        this.nbeArbitrageAnn = value;
    }

    /**
     * Obtient la valeur de la propriété nbeArbitrageCtr.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getNbeArbitrageCtr() {
        return nbeArbitrageCtr;
    }

    /**
     * Définit la valeur de la propriété nbeArbitrageCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setNbeArbitrageCtr(BigInteger value) {
        this.nbeArbitrageCtr = value;
    }

    /**
     * Obtient la valeur de la propriété indReinvRemun.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndReinvRemun() {
        return indReinvRemun;
    }

    /**
     * Définit la valeur de la propriété indReinvRemun.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndReinvRemun(Boolean value) {
        this.indReinvRemun = value;
    }

}
