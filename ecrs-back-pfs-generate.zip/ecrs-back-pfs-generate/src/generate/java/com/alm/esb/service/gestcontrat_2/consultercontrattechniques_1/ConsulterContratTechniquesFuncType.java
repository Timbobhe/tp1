
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratTechniquesFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratTechniquesFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentificationContrat" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IdentificationContratType"/>
 *         &lt;element name="EcheancierPaiementPrime" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}EcheancierPaiementPrimeType" minOccurs="0"/>
 *         &lt;element name="OptionContratEpargne" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}OptionContratEpargnePrimeType" minOccurs="0"/>
 *         &lt;element name="ValorisationRente" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}ValorisationRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="OptionRente" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}OptionRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ConditionContractuelle" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}ConditionContractuelleType" minOccurs="0"/>
 *         &lt;element name="ParametrageEditions" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}ParametrageEditionsType" minOccurs="0"/>
 *         &lt;element name="PieceJustificative" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}PieceJustificativeType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratTechniquesFuncType", propOrder = {
    "identificationContrat",
    "echeancierPaiementPrime",
    "optionContratEpargne",
    "valorisationRente",
    "optionRente",
    "conditionContractuelle",
    "parametrageEditions",
    "pieceJustificative"
})
public class ConsulterContratTechniquesFuncType {

    @XmlElement(name = "IdentificationContrat", required = true)
    protected IdentificationContratType identificationContrat;
    @XmlElement(name = "EcheancierPaiementPrime")
    protected EcheancierPaiementPrimeType echeancierPaiementPrime;
    @XmlElement(name = "OptionContratEpargne")
    protected OptionContratEpargnePrimeType optionContratEpargne;
    @XmlElement(name = "ValorisationRente")
    protected List<ValorisationRenteType> valorisationRente;
    @XmlElement(name = "OptionRente")
    protected List<OptionRenteType> optionRente;
    @XmlElement(name = "ConditionContractuelle")
    protected ConditionContractuelleType conditionContractuelle;
    @XmlElement(name = "ParametrageEditions")
    protected ParametrageEditionsType parametrageEditions;
    @XmlElement(name = "PieceJustificative")
    protected List<PieceJustificativeType> pieceJustificative;

    /**
     * Obtient la valeur de la propriété identificationContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationContratType }
     *     
     */
    public IdentificationContratType getIdentificationContrat() {
        return identificationContrat;
    }

    /**
     * Définit la valeur de la propriété identificationContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationContratType }
     *     
     */
    public void setIdentificationContrat(IdentificationContratType value) {
        this.identificationContrat = value;
    }

    /**
     * Obtient la valeur de la propriété echeancierPaiementPrime.
     * 
     * @return
     *     possible object is
     *     {@link EcheancierPaiementPrimeType }
     *     
     */
    public EcheancierPaiementPrimeType getEcheancierPaiementPrime() {
        return echeancierPaiementPrime;
    }

    /**
     * Définit la valeur de la propriété echeancierPaiementPrime.
     * 
     * @param value
     *     allowed object is
     *     {@link EcheancierPaiementPrimeType }
     *     
     */
    public void setEcheancierPaiementPrime(EcheancierPaiementPrimeType value) {
        this.echeancierPaiementPrime = value;
    }

    /**
     * Obtient la valeur de la propriété optionContratEpargne.
     * 
     * @return
     *     possible object is
     *     {@link OptionContratEpargnePrimeType }
     *     
     */
    public OptionContratEpargnePrimeType getOptionContratEpargne() {
        return optionContratEpargne;
    }

    /**
     * Définit la valeur de la propriété optionContratEpargne.
     * 
     * @param value
     *     allowed object is
     *     {@link OptionContratEpargnePrimeType }
     *     
     */
    public void setOptionContratEpargne(OptionContratEpargnePrimeType value) {
        this.optionContratEpargne = value;
    }

    /**
     * Gets the value of the valorisationRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the valorisationRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValorisationRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ValorisationRenteType }
     * 
     * 
     */
    public List<ValorisationRenteType> getValorisationRente() {
        if (valorisationRente == null) {
            valorisationRente = new ArrayList<ValorisationRenteType>();
        }
        return this.valorisationRente;
    }

    /**
     * Gets the value of the optionRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the optionRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOptionRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link OptionRenteType }
     * 
     * 
     */
    public List<OptionRenteType> getOptionRente() {
        if (optionRente == null) {
            optionRente = new ArrayList<OptionRenteType>();
        }
        return this.optionRente;
    }

    /**
     * Obtient la valeur de la propriété conditionContractuelle.
     * 
     * @return
     *     possible object is
     *     {@link ConditionContractuelleType }
     *     
     */
    public ConditionContractuelleType getConditionContractuelle() {
        return conditionContractuelle;
    }

    /**
     * Définit la valeur de la propriété conditionContractuelle.
     * 
     * @param value
     *     allowed object is
     *     {@link ConditionContractuelleType }
     *     
     */
    public void setConditionContractuelle(ConditionContractuelleType value) {
        this.conditionContractuelle = value;
    }

    /**
     * Obtient la valeur de la propriété parametrageEditions.
     * 
     * @return
     *     possible object is
     *     {@link ParametrageEditionsType }
     *     
     */
    public ParametrageEditionsType getParametrageEditions() {
        return parametrageEditions;
    }

    /**
     * Définit la valeur de la propriété parametrageEditions.
     * 
     * @param value
     *     allowed object is
     *     {@link ParametrageEditionsType }
     *     
     */
    public void setParametrageEditions(ParametrageEditionsType value) {
        this.parametrageEditions = value;
    }

    /**
     * Gets the value of the pieceJustificative property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pieceJustificative property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPieceJustificative().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PieceJustificativeType }
     * 
     * 
     */
    public List<PieceJustificativeType> getPieceJustificative() {
        if (pieceJustificative == null) {
            pieceJustificative = new ArrayList<PieceJustificativeType>();
        }
        return this.pieceJustificative;
    }

}
