
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour AdhType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AdhType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdSiloAdherente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdSiloAdherenteType" minOccurs="0"/>
 *         &lt;element name="idAdh" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="SignqAdherentePM" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqAdherentePMType" minOccurs="0"/>
 *         &lt;element name="dateEffetAdh" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitAdh" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitAdhSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitAdh" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="CtrAdh" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrAdherenteType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdhType", propOrder = {
    "idSiloAdherente",
    "idAdh",
    "signqAdherentePM",
    "dateEffetAdh",
    "codeSitAdh",
    "libSitAdh",
    "codeSitAdhSilo",
    "dateSitAdh",
    "ctrAdh"
})
public class AdhType {

    @XmlElement(name = "IdSiloAdherente")
    protected IdSiloAdherenteType idSiloAdherente;
    @XmlElement(required = true)
    protected String idAdh;
    @XmlElement(name = "SignqAdherentePM")
    protected SignqAdherentePMType signqAdherentePM;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetAdh;
    protected String codeSitAdh;
    protected String libSitAdh;
    protected String codeSitAdhSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitAdh;
    @XmlElement(name = "CtrAdh")
    protected CtrAdherenteType ctrAdh;

    /**
     * Obtient la valeur de la propriété idSiloAdherente.
     * 
     * @return
     *     possible object is
     *     {@link IdSiloAdherenteType }
     *     
     */
    public IdSiloAdherenteType getIdSiloAdherente() {
        return idSiloAdherente;
    }

    /**
     * Définit la valeur de la propriété idSiloAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link IdSiloAdherenteType }
     *     
     */
    public void setIdSiloAdherente(IdSiloAdherenteType value) {
        this.idSiloAdherente = value;
    }

    /**
     * Obtient la valeur de la propriété idAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAdh() {
        return idAdh;
    }

    /**
     * Définit la valeur de la propriété idAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAdh(String value) {
        this.idAdh = value;
    }

    /**
     * Obtient la valeur de la propriété signqAdherentePM.
     * 
     * @return
     *     possible object is
     *     {@link SignqAdherentePMType }
     *     
     */
    public SignqAdherentePMType getSignqAdherentePM() {
        return signqAdherentePM;
    }

    /**
     * Définit la valeur de la propriété signqAdherentePM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqAdherentePMType }
     *     
     */
    public void setSignqAdherentePM(SignqAdherentePMType value) {
        this.signqAdherentePM = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetAdh.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetAdh() {
        return dateEffetAdh;
    }

    /**
     * Définit la valeur de la propriété dateEffetAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetAdh(XMLGregorianCalendar value) {
        this.dateEffetAdh = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitAdh() {
        return codeSitAdh;
    }

    /**
     * Définit la valeur de la propriété codeSitAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitAdh(String value) {
        this.codeSitAdh = value;
    }

    /**
     * Obtient la valeur de la propriété libSitAdh.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitAdh() {
        return libSitAdh;
    }

    /**
     * Définit la valeur de la propriété libSitAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitAdh(String value) {
        this.libSitAdh = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitAdhSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitAdhSilo() {
        return codeSitAdhSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitAdhSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitAdhSilo(String value) {
        this.codeSitAdhSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitAdh.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitAdh() {
        return dateSitAdh;
    }

    /**
     * Définit la valeur de la propriété dateSitAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitAdh(XMLGregorianCalendar value) {
        this.dateSitAdh = value;
    }

    /**
     * Obtient la valeur de la propriété ctrAdh.
     * 
     * @return
     *     possible object is
     *     {@link CtrAdherenteType }
     *     
     */
    public CtrAdherenteType getCtrAdh() {
        return ctrAdh;
    }

    /**
     * Définit la valeur de la propriété ctrAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrAdherenteType }
     *     
     */
    public void setCtrAdh(CtrAdherenteType value) {
        this.ctrAdh = value;
    }

}
