
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CriteresRechercheType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CriteresRechercheType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SituationContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SituationContratType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SituationAdhesion" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SituationAdhesionType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SituationCategPersonnel" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SituationCategPersType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="SituationAffiliation" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SituationAffiliationType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RolePersContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}RolePersContratType" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CriteresRechercheType", propOrder = {
    "situationContrat",
    "situationAdhesion",
    "situationCategPersonnel",
    "situationAffiliation",
    "rolePersContrat"
})
public class CriteresRechercheType {

    @XmlElement(name = "SituationContrat")
    protected List<SituationContratType> situationContrat;
    @XmlElement(name = "SituationAdhesion")
    protected List<SituationAdhesionType> situationAdhesion;
    @XmlElement(name = "SituationCategPersonnel")
    protected List<SituationCategPersType> situationCategPersonnel;
    @XmlElement(name = "SituationAffiliation")
    protected List<SituationAffiliationType> situationAffiliation;
    @XmlElement(name = "RolePersContrat", required = true)
    protected List<RolePersContratType> rolePersContrat;

    /**
     * Gets the value of the situationContrat property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the situationContrat property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSituationContrat().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SituationContratType }
     * 
     * 
     */
    public List<SituationContratType> getSituationContrat() {
        if (situationContrat == null) {
            situationContrat = new ArrayList<SituationContratType>();
        }
        return this.situationContrat;
    }

    /**
     * Gets the value of the situationAdhesion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the situationAdhesion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSituationAdhesion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SituationAdhesionType }
     * 
     * 
     */
    public List<SituationAdhesionType> getSituationAdhesion() {
        if (situationAdhesion == null) {
            situationAdhesion = new ArrayList<SituationAdhesionType>();
        }
        return this.situationAdhesion;
    }

    /**
     * Gets the value of the situationCategPersonnel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the situationCategPersonnel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSituationCategPersonnel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SituationCategPersType }
     * 
     * 
     */
    public List<SituationCategPersType> getSituationCategPersonnel() {
        if (situationCategPersonnel == null) {
            situationCategPersonnel = new ArrayList<SituationCategPersType>();
        }
        return this.situationCategPersonnel;
    }

    /**
     * Gets the value of the situationAffiliation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the situationAffiliation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSituationAffiliation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SituationAffiliationType }
     * 
     * 
     */
    public List<SituationAffiliationType> getSituationAffiliation() {
        if (situationAffiliation == null) {
            situationAffiliation = new ArrayList<SituationAffiliationType>();
        }
        return this.situationAffiliation;
    }

    /**
     * Gets the value of the rolePersContrat property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the rolePersContrat property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRolePersContrat().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RolePersContratType }
     * 
     * 
     */
    public List<RolePersContratType> getRolePersContrat() {
        if (rolePersContrat == null) {
            rolePersContrat = new ArrayList<RolePersContratType>();
        }
        return this.rolePersContrat;
    }

}
