
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour ContratAssurType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratAssurType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dateEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffet" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateEmission" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeSitContrat" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libSitContrat" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeSitContratSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="dateSitContrat" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="IdContratSource" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}IdContratSourceType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratAssurType", propOrder = {
    "dateEffet",
    "dateFinEffet",
    "dateEmission",
    "codeSitContrat",
    "libSitContrat",
    "codeSitContratSilo",
    "dateSitContrat",
    "idContratSource"
})
public class ContratAssurType {

    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffet;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEmission;
    protected String codeSitContrat;
    protected String libSitContrat;
    protected String codeSitContratSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitContrat;
    @XmlElement(name = "IdContratSource")
    protected IdContratSourceType idContratSource;

    /**
     * Obtient la valeur de la propriété dateEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffet() {
        return dateEffet;
    }

    /**
     * Définit la valeur de la propriété dateEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffet(XMLGregorianCalendar value) {
        this.dateEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffet.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffet() {
        return dateFinEffet;
    }

    /**
     * Définit la valeur de la propriété dateFinEffet.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffet(XMLGregorianCalendar value) {
        this.dateFinEffet = value;
    }

    /**
     * Obtient la valeur de la propriété dateEmission.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEmission() {
        return dateEmission;
    }

    /**
     * Définit la valeur de la propriété dateEmission.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEmission(XMLGregorianCalendar value) {
        this.dateEmission = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitContrat() {
        return codeSitContrat;
    }

    /**
     * Définit la valeur de la propriété codeSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitContrat(String value) {
        this.codeSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitContrat() {
        return libSitContrat;
    }

    /**
     * Définit la valeur de la propriété libSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitContrat(String value) {
        this.libSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitContratSilo() {
        return codeSitContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitContratSilo(String value) {
        this.codeSitContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitContrat.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitContrat() {
        return dateSitContrat;
    }

    /**
     * Définit la valeur de la propriété dateSitContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitContrat(XMLGregorianCalendar value) {
        this.dateSitContrat = value;
    }

    /**
     * Obtient la valeur de la propriété idContratSource.
     * 
     * @return
     *     possible object is
     *     {@link IdContratSourceType }
     *     
     */
    public IdContratSourceType getIdContratSource() {
        return idContratSource;
    }

    /**
     * Définit la valeur de la propriété idContratSource.
     * 
     * @param value
     *     allowed object is
     *     {@link IdContratSourceType }
     *     
     */
    public void setIdContratSource(IdContratSourceType value) {
        this.idContratSource = value;
    }

}
