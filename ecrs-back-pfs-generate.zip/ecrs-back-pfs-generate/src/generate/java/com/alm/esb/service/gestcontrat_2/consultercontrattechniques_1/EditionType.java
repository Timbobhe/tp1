
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour EditionType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="EditionType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeDoc" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IndParam" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IndParamType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EditionType", propOrder = {
    "codeDoc",
    "libDoc",
    "typeDoc",
    "indParam"
})
public class EditionType {

    protected String codeDoc;
    protected String libDoc;
    protected String typeDoc;
    @XmlElement(name = "IndParam")
    protected List<IndParamType> indParam;

    /**
     * Obtient la valeur de la propriété codeDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDoc() {
        return codeDoc;
    }

    /**
     * Définit la valeur de la propriété codeDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDoc(String value) {
        this.codeDoc = value;
    }

    /**
     * Obtient la valeur de la propriété libDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDoc() {
        return libDoc;
    }

    /**
     * Définit la valeur de la propriété libDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDoc(String value) {
        this.libDoc = value;
    }

    /**
     * Obtient la valeur de la propriété typeDoc.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeDoc() {
        return typeDoc;
    }

    /**
     * Définit la valeur de la propriété typeDoc.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeDoc(String value) {
        this.typeDoc = value;
    }

    /**
     * Gets the value of the indParam property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the indParam property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIndParam().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IndParamType }
     * 
     * 
     */
    public List<IndParamType> getIndParam() {
        if (indParam == null) {
            indParam = new ArrayList<IndParamType>();
        }
        return this.indParam;
    }

}
