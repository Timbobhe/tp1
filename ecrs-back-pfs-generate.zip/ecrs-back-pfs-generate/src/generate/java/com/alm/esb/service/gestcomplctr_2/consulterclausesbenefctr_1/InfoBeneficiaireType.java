
package com.alm.esb.service.gestcomplctr_2.consulterclausesbenefctr_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour InfoBeneficiaireType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoBeneficiaireType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestComplCtr_2/ConsulterClausesBenefCtr_1}SignqPPAssureAdd" minOccurs="0"/>
 *         &lt;element name="codeTypeBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeBenef" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeBenefSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoBeneficiaireType", propOrder = {
    "signqPPAssureAdd",
    "codeTypeBenef",
    "libTypeBenef",
    "libTypeBenefSilo"
})
public class InfoBeneficiaireType {

    @XmlElement(name = "SignqPPAssureAdd")
    protected SignaletiquePPAssureAdditionnelType signqPPAssureAdd;
    protected String codeTypeBenef;
    protected String libTypeBenef;
    protected String libTypeBenefSilo;

    /**
     * Obtient la valeur de la propriété signqPPAssureAdd.
     * 
     * @return
     *     possible object is
     *     {@link SignaletiquePPAssureAdditionnelType }
     *     
     */
    public SignaletiquePPAssureAdditionnelType getSignqPPAssureAdd() {
        return signqPPAssureAdd;
    }

    /**
     * Définit la valeur de la propriété signqPPAssureAdd.
     * 
     * @param value
     *     allowed object is
     *     {@link SignaletiquePPAssureAdditionnelType }
     *     
     */
    public void setSignqPPAssureAdd(SignaletiquePPAssureAdditionnelType value) {
        this.signqPPAssureAdd = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeBenef() {
        return codeTypeBenef;
    }

    /**
     * Définit la valeur de la propriété codeTypeBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeBenef(String value) {
        this.codeTypeBenef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeBenef.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeBenef() {
        return libTypeBenef;
    }

    /**
     * Définit la valeur de la propriété libTypeBenef.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeBenef(String value) {
        this.libTypeBenef = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeBenefSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeBenefSilo() {
        return libTypeBenefSilo;
    }

    /**
     * Définit la valeur de la propriété libTypeBenefSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeBenefSilo(String value) {
        this.libTypeBenefSilo = value;
    }

}
