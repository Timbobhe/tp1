
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ActeurContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ActeurContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="identAssContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identApporteurAffaire" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identDistribProduit" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ActeurContratType", propOrder = {
    "identAssContrat",
    "identApporteurAffaire",
    "identDistribProduit"
})
public class ActeurContratType {

    protected String identAssContrat;
    protected String identApporteurAffaire;
    protected String identDistribProduit;

    /**
     * Obtient la valeur de la propriété identAssContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentAssContrat() {
        return identAssContrat;
    }

    /**
     * Définit la valeur de la propriété identAssContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentAssContrat(String value) {
        this.identAssContrat = value;
    }

    /**
     * Obtient la valeur de la propriété identApporteurAffaire.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentApporteurAffaire() {
        return identApporteurAffaire;
    }

    /**
     * Définit la valeur de la propriété identApporteurAffaire.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentApporteurAffaire(String value) {
        this.identApporteurAffaire = value;
    }

    /**
     * Obtient la valeur de la propriété identDistribProduit.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentDistribProduit() {
        return identDistribProduit;
    }

    /**
     * Définit la valeur de la propriété identDistribProduit.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentDistribProduit(String value) {
        this.identDistribProduit = value;
    }

}
