
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour GestionnaireContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="GestionnaireContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idAssCtr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libAssCtr" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="idAssCtrSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="indGestTiers" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}boolean">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libCieAssur" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GestionnaireContratType", propOrder = {
    "idAssCtr",
    "libAssCtr",
    "idAssCtrSilo",
    "indGestTiers",
    "libCieAssur"
})
public class GestionnaireContratType {

    protected String idAssCtr;
    protected String libAssCtr;
    protected String idAssCtrSilo;
    protected Boolean indGestTiers;
    protected String libCieAssur;

    /**
     * Obtient la valeur de la propriété idAssCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAssCtr() {
        return idAssCtr;
    }

    /**
     * Définit la valeur de la propriété idAssCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAssCtr(String value) {
        this.idAssCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libAssCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAssCtr() {
        return libAssCtr;
    }

    /**
     * Définit la valeur de la propriété libAssCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAssCtr(String value) {
        this.libAssCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idAssCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdAssCtrSilo() {
        return idAssCtrSilo;
    }

    /**
     * Définit la valeur de la propriété idAssCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdAssCtrSilo(String value) {
        this.idAssCtrSilo = value;
    }

    /**
     * Obtient la valeur de la propriété indGestTiers.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndGestTiers() {
        return indGestTiers;
    }

    /**
     * Définit la valeur de la propriété indGestTiers.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndGestTiers(Boolean value) {
        this.indGestTiers = value;
    }

    /**
     * Obtient la valeur de la propriété libCieAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCieAssur() {
        return libCieAssur;
    }

    /**
     * Définit la valeur de la propriété libCieAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCieAssur(String value) {
        this.libCieAssur = value;
    }

}
