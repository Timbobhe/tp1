
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratAssuranceType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratAssuranceType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}IdentContratType"/>
 *         &lt;element name="InfoContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}InfoContratType"/>
 *         &lt;element name="Souscripteur" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}SouscripteurType" maxOccurs="unbounded"/>
 *         &lt;element name="CategPersonnel" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}CategPersonnelType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AssurePrincipal" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}AssurePrincipalType" minOccurs="0"/>
 *         &lt;element name="OffreCialeSouscrite" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}OffreCialeSouscriteType" minOccurs="0"/>
 *         &lt;element name="ActeurContrat" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}ActeurContratType" minOccurs="0"/>
 *         &lt;element name="Adhesion" type="{http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1}AdhesionType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratAssuranceType", propOrder = {
    "identContrat",
    "infoContrat",
    "souscripteur",
    "categPersonnel",
    "assurePrincipal",
    "offreCialeSouscrite",
    "acteurContrat",
    "adhesion"
})
public class ContratAssuranceType {

    @XmlElement(name = "IdentContrat", required = true)
    protected IdentContratType identContrat;
    @XmlElement(name = "InfoContrat", required = true)
    protected InfoContratType infoContrat;
    @XmlElement(name = "Souscripteur", required = true)
    protected List<SouscripteurType> souscripteur;
    @XmlElement(name = "CategPersonnel")
    protected List<CategPersonnelType> categPersonnel;
    @XmlElement(name = "AssurePrincipal")
    protected AssurePrincipalType assurePrincipal;
    @XmlElement(name = "OffreCialeSouscrite")
    protected OffreCialeSouscriteType offreCialeSouscrite;
    @XmlElement(name = "ActeurContrat")
    protected ActeurContratType acteurContrat;
    @XmlElement(name = "Adhesion")
    protected List<AdhesionType> adhesion;

    /**
     * Obtient la valeur de la propriété identContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratType }
     *     
     */
    public IdentContratType getIdentContrat() {
        return identContrat;
    }

    /**
     * Définit la valeur de la propriété identContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratType }
     *     
     */
    public void setIdentContrat(IdentContratType value) {
        this.identContrat = value;
    }

    /**
     * Obtient la valeur de la propriété infoContrat.
     * 
     * @return
     *     possible object is
     *     {@link InfoContratType }
     *     
     */
    public InfoContratType getInfoContrat() {
        return infoContrat;
    }

    /**
     * Définit la valeur de la propriété infoContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link InfoContratType }
     *     
     */
    public void setInfoContrat(InfoContratType value) {
        this.infoContrat = value;
    }

    /**
     * Gets the value of the souscripteur property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the souscripteur property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSouscripteur().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link SouscripteurType }
     * 
     * 
     */
    public List<SouscripteurType> getSouscripteur() {
        if (souscripteur == null) {
            souscripteur = new ArrayList<SouscripteurType>();
        }
        return this.souscripteur;
    }

    /**
     * Gets the value of the categPersonnel property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the categPersonnel property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCategPersonnel().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CategPersonnelType }
     * 
     * 
     */
    public List<CategPersonnelType> getCategPersonnel() {
        if (categPersonnel == null) {
            categPersonnel = new ArrayList<CategPersonnelType>();
        }
        return this.categPersonnel;
    }

    /**
     * Obtient la valeur de la propriété assurePrincipal.
     * 
     * @return
     *     possible object is
     *     {@link AssurePrincipalType }
     *     
     */
    public AssurePrincipalType getAssurePrincipal() {
        return assurePrincipal;
    }

    /**
     * Définit la valeur de la propriété assurePrincipal.
     * 
     * @param value
     *     allowed object is
     *     {@link AssurePrincipalType }
     *     
     */
    public void setAssurePrincipal(AssurePrincipalType value) {
        this.assurePrincipal = value;
    }

    /**
     * Obtient la valeur de la propriété offreCialeSouscrite.
     * 
     * @return
     *     possible object is
     *     {@link OffreCialeSouscriteType }
     *     
     */
    public OffreCialeSouscriteType getOffreCialeSouscrite() {
        return offreCialeSouscrite;
    }

    /**
     * Définit la valeur de la propriété offreCialeSouscrite.
     * 
     * @param value
     *     allowed object is
     *     {@link OffreCialeSouscriteType }
     *     
     */
    public void setOffreCialeSouscrite(OffreCialeSouscriteType value) {
        this.offreCialeSouscrite = value;
    }

    /**
     * Obtient la valeur de la propriété acteurContrat.
     * 
     * @return
     *     possible object is
     *     {@link ActeurContratType }
     *     
     */
    public ActeurContratType getActeurContrat() {
        return acteurContrat;
    }

    /**
     * Définit la valeur de la propriété acteurContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link ActeurContratType }
     *     
     */
    public void setActeurContrat(ActeurContratType value) {
        this.acteurContrat = value;
    }

    /**
     * Gets the value of the adhesion property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the adhesion property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAdhesion().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AdhesionType }
     * 
     * 
     */
    public List<AdhesionType> getAdhesion() {
        if (adhesion == null) {
            adhesion = new ArrayList<AdhesionType>();
        }
        return this.adhesion;
    }

}
