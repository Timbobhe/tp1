
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour DemOpeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="DemOpeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="indATC" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="codeRoutageDem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeOpe" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="opeDem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="versDem" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="instantEmisDem" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="IdCtrSilo" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdCtrSiloType" minOccurs="0"/>
 *         &lt;element name="IdentPers" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdentPersType" minOccurs="0"/>
 *         &lt;element name="IdDemSilo" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdDemSiloType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DemOpeType", propOrder = {
    "indATC",
    "codeRoutageDem",
    "typeOpe",
    "opeDem",
    "versDem",
    "instantEmisDem",
    "idCtrSilo",
    "identPers",
    "idDemSilo"
})
public class DemOpeType {

    protected boolean indATC;
    @XmlElement(required = true)
    protected String codeRoutageDem;
    @XmlElement(required = true)
    protected String typeOpe;
    protected String opeDem;
    @XmlElement(required = true)
    protected String versDem;
    @XmlElement(required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar instantEmisDem;
    @XmlElement(name = "IdCtrSilo")
    protected IdCtrSiloType idCtrSilo;
    @XmlElement(name = "IdentPers")
    protected IdentPersType identPers;
    @XmlElement(name = "IdDemSilo")
    protected IdDemSiloType idDemSilo;

    /**
     * Obtient la valeur de la propriété indATC.
     * 
     */
    public boolean isIndATC() {
        return indATC;
    }

    /**
     * Définit la valeur de la propriété indATC.
     * 
     */
    public void setIndATC(boolean value) {
        this.indATC = value;
    }

    /**
     * Obtient la valeur de la propriété codeRoutageDem.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRoutageDem() {
        return codeRoutageDem;
    }

    /**
     * Définit la valeur de la propriété codeRoutageDem.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRoutageDem(String value) {
        this.codeRoutageDem = value;
    }

    /**
     * Obtient la valeur de la propriété typeOpe.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeOpe() {
        return typeOpe;
    }

    /**
     * Définit la valeur de la propriété typeOpe.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeOpe(String value) {
        this.typeOpe = value;
    }

    /**
     * Obtient la valeur de la propriété opeDem.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpeDem() {
        return opeDem;
    }

    /**
     * Définit la valeur de la propriété opeDem.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpeDem(String value) {
        this.opeDem = value;
    }

    /**
     * Obtient la valeur de la propriété versDem.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersDem() {
        return versDem;
    }

    /**
     * Définit la valeur de la propriété versDem.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersDem(String value) {
        this.versDem = value;
    }

    /**
     * Obtient la valeur de la propriété instantEmisDem.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getInstantEmisDem() {
        return instantEmisDem;
    }

    /**
     * Définit la valeur de la propriété instantEmisDem.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setInstantEmisDem(XMLGregorianCalendar value) {
        this.instantEmisDem = value;
    }

    /**
     * Obtient la valeur de la propriété idCtrSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdCtrSiloType }
     *     
     */
    public IdCtrSiloType getIdCtrSilo() {
        return idCtrSilo;
    }

    /**
     * Définit la valeur de la propriété idCtrSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdCtrSiloType }
     *     
     */
    public void setIdCtrSilo(IdCtrSiloType value) {
        this.idCtrSilo = value;
    }

    /**
     * Obtient la valeur de la propriété identPers.
     * 
     * @return
     *     possible object is
     *     {@link IdentPersType }
     *     
     */
    public IdentPersType getIdentPers() {
        return identPers;
    }

    /**
     * Définit la valeur de la propriété identPers.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentPersType }
     *     
     */
    public void setIdentPers(IdentPersType value) {
        this.identPers = value;
    }

    /**
     * Obtient la valeur de la propriété idDemSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdDemSiloType }
     *     
     */
    public IdDemSiloType getIdDemSilo() {
        return idDemSilo;
    }

    /**
     * Définit la valeur de la propriété idDemSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdDemSiloType }
     *     
     */
    public void setIdDemSilo(IdDemSiloType value) {
        this.idDemSilo = value;
    }

}
