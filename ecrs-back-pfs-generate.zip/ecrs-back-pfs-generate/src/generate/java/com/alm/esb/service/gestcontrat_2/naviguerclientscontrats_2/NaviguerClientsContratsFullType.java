
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_2;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour NaviguerClientsContratsFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="NaviguerClientsContratsFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_2}NaviguerClientsContrats" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_2}NaviguerClientsContratsResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NaviguerClientsContratsFullType", propOrder = {
    "naviguerClientsContrats",
    "naviguerClientsContratsResponse"
})
public class NaviguerClientsContratsFullType {

    @XmlElement(name = "NaviguerClientsContrats")
    protected NaviguerClientsContratsType naviguerClientsContrats;
    @XmlElement(name = "NaviguerClientsContratsResponse")
    protected NaviguerClientsContratsResponseType naviguerClientsContratsResponse;

    /**
     * Obtient la valeur de la propriété naviguerClientsContrats.
     * 
     * @return
     *     possible object is
     *     {@link NaviguerClientsContratsType }
     *     
     */
    public NaviguerClientsContratsType getNaviguerClientsContrats() {
        return naviguerClientsContrats;
    }

    /**
     * Définit la valeur de la propriété naviguerClientsContrats.
     * 
     * @param value
     *     allowed object is
     *     {@link NaviguerClientsContratsType }
     *     
     */
    public void setNaviguerClientsContrats(NaviguerClientsContratsType value) {
        this.naviguerClientsContrats = value;
    }

    /**
     * Obtient la valeur de la propriété naviguerClientsContratsResponse.
     * 
     * @return
     *     possible object is
     *     {@link NaviguerClientsContratsResponseType }
     *     
     */
    public NaviguerClientsContratsResponseType getNaviguerClientsContratsResponse() {
        return naviguerClientsContratsResponse;
    }

    /**
     * Définit la valeur de la propriété naviguerClientsContratsResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link NaviguerClientsContratsResponseType }
     *     
     */
    public void setNaviguerClientsContratsResponse(NaviguerClientsContratsResponseType value) {
        this.naviguerClientsContratsResponse = value;
    }

}
