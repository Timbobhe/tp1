
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RolePersType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RolePersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeRolePersCtr" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libRolePersCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdPers" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentPersType" minOccurs="0"/>
 *         &lt;element name="SignqPP" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqPPType" minOccurs="0"/>
 *         &lt;element name="SignqPM" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}SignqPMType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RolePersType", propOrder = {
    "codeRolePersCtr",
    "libRolePersCtr",
    "idPers",
    "signqPP",
    "signqPM"
})
public class RolePersType {

    @XmlElement(required = true)
    protected String codeRolePersCtr;
    protected String libRolePersCtr;
    @XmlElement(name = "IdPers")
    protected IdentPersType idPers;
    @XmlElement(name = "SignqPP")
    protected SignqPPType signqPP;
    @XmlElement(name = "SignqPM")
    protected SignqPMType signqPM;

    /**
     * Obtient la valeur de la propriété codeRolePersCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeRolePersCtr() {
        return codeRolePersCtr;
    }

    /**
     * Définit la valeur de la propriété codeRolePersCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeRolePersCtr(String value) {
        this.codeRolePersCtr = value;
    }

    /**
     * Obtient la valeur de la propriété libRolePersCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibRolePersCtr() {
        return libRolePersCtr;
    }

    /**
     * Définit la valeur de la propriété libRolePersCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibRolePersCtr(String value) {
        this.libRolePersCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idPers.
     * 
     * @return
     *     possible object is
     *     {@link IdentPersType }
     *     
     */
    public IdentPersType getIdPers() {
        return idPers;
    }

    /**
     * Définit la valeur de la propriété idPers.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentPersType }
     *     
     */
    public void setIdPers(IdentPersType value) {
        this.idPers = value;
    }

    /**
     * Obtient la valeur de la propriété signqPP.
     * 
     * @return
     *     possible object is
     *     {@link SignqPPType }
     *     
     */
    public SignqPPType getSignqPP() {
        return signqPP;
    }

    /**
     * Définit la valeur de la propriété signqPP.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqPPType }
     *     
     */
    public void setSignqPP(SignqPPType value) {
        this.signqPP = value;
    }

    /**
     * Obtient la valeur de la propriété signqPM.
     * 
     * @return
     *     possible object is
     *     {@link SignqPMType }
     *     
     */
    public SignqPMType getSignqPM() {
        return signqPM;
    }

    /**
     * Définit la valeur de la propriété signqPM.
     * 
     * @param value
     *     allowed object is
     *     {@link SignqPMType }
     *     
     */
    public void setSignqPM(SignqPMType value) {
        this.signqPM = value;
    }

}
