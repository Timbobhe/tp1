
package com.alm.esb.service.gestcontrat_2.consultervalocontrat_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.fmk.esb.framework.esbtechpivotschema.WSResponseMetaInfoType;


/**
 * <p>Classe Java pour ConsulterValoContratResponseType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterValoContratResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterValoContrat_1}ConsulterValoContratFunc" minOccurs="0"/>
 *         &lt;element name="ResponseMetaInfo" type="{http://www.fmk.com/ESB/Framework/ESBTechPivotSchema}WSResponseMetaInfoType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterValoContratResponseType", propOrder = {
    "consulterValoContratFunc",
    "responseMetaInfo"
})
public class ConsulterValoContratResponseType {

    @XmlElement(name = "ConsulterValoContratFunc")
    protected ConsulterValoContratFuncType consulterValoContratFunc;
    @XmlElement(name = "ResponseMetaInfo")
    protected List<WSResponseMetaInfoType> responseMetaInfo;

    /**
     * Obtient la valeur de la propriété consulterValoContratFunc.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterValoContratFuncType }
     *     
     */
    public ConsulterValoContratFuncType getConsulterValoContratFunc() {
        return consulterValoContratFunc;
    }

    /**
     * Définit la valeur de la propriété consulterValoContratFunc.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterValoContratFuncType }
     *     
     */
    public void setConsulterValoContratFunc(ConsulterValoContratFuncType value) {
        this.consulterValoContratFunc = value;
    }

    /**
     * Gets the value of the responseMetaInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the responseMetaInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getResponseMetaInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link WSResponseMetaInfoType }
     * 
     * 
     */
    public List<WSResponseMetaInfoType> getResponseMetaInfo() {
        if (responseMetaInfo == null) {
            responseMetaInfo = new ArrayList<WSResponseMetaInfoType>();
        }
        return this.responseMetaInfo;
    }

}
