
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour ValorisationRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ValorisationRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idTarifInvestissement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numeroTarifContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txTechniqueValorisationRente" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="dateDebutEffetTxTechniqueValorisationRente" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeTableMortaliteValorisationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTableMortaliteValorisationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTableMortaliteValorisationRenteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTableMortaliteValorisationRenteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="txFraisSurRente" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indicateurTarifBloque" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeNatCtrProprietaireTarif" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNatCtrProprietaireTarif" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeValoTarifRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libTypeValoTarifRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ValorisationRenteType", propOrder = {
    "idTarifInvestissement",
    "numeroTarifContrat",
    "txTechniqueValorisationRente",
    "dateDebutEffetTxTechniqueValorisationRente",
    "codeTableMortaliteValorisationRente",
    "libTableMortaliteValorisationRente",
    "codeTableMortaliteValorisationRenteSilo",
    "libTableMortaliteValorisationRenteSilo",
    "txFraisSurRente",
    "indicateurTarifBloque",
    "codeNatCtrProprietaireTarif",
    "libNatCtrProprietaireTarif",
    "codeTypeValoTarifRente",
    "libTypeValoTarifRente"
})
public class ValorisationRenteType {

    protected String idTarifInvestissement;
    protected String numeroTarifContrat;
    protected BigDecimal txTechniqueValorisationRente;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutEffetTxTechniqueValorisationRente;
    protected String codeTableMortaliteValorisationRente;
    protected String libTableMortaliteValorisationRente;
    protected String codeTableMortaliteValorisationRenteSilo;
    protected String libTableMortaliteValorisationRenteSilo;
    protected BigDecimal txFraisSurRente;
    protected Boolean indicateurTarifBloque;
    protected String codeNatCtrProprietaireTarif;
    protected String libNatCtrProprietaireTarif;
    protected String codeTypeValoTarifRente;
    protected String libTypeValoTarifRente;

    /**
     * Obtient la valeur de la propriété idTarifInvestissement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdTarifInvestissement() {
        return idTarifInvestissement;
    }

    /**
     * Définit la valeur de la propriété idTarifInvestissement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdTarifInvestissement(String value) {
        this.idTarifInvestissement = value;
    }

    /**
     * Obtient la valeur de la propriété numeroTarifContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumeroTarifContrat() {
        return numeroTarifContrat;
    }

    /**
     * Définit la valeur de la propriété numeroTarifContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumeroTarifContrat(String value) {
        this.numeroTarifContrat = value;
    }

    /**
     * Obtient la valeur de la propriété txTechniqueValorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxTechniqueValorisationRente() {
        return txTechniqueValorisationRente;
    }

    /**
     * Définit la valeur de la propriété txTechniqueValorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxTechniqueValorisationRente(BigDecimal value) {
        this.txTechniqueValorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutEffetTxTechniqueValorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutEffetTxTechniqueValorisationRente() {
        return dateDebutEffetTxTechniqueValorisationRente;
    }

    /**
     * Définit la valeur de la propriété dateDebutEffetTxTechniqueValorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutEffetTxTechniqueValorisationRente(XMLGregorianCalendar value) {
        this.dateDebutEffetTxTechniqueValorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeTableMortaliteValorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTableMortaliteValorisationRente() {
        return codeTableMortaliteValorisationRente;
    }

    /**
     * Définit la valeur de la propriété codeTableMortaliteValorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTableMortaliteValorisationRente(String value) {
        this.codeTableMortaliteValorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété libTableMortaliteValorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTableMortaliteValorisationRente() {
        return libTableMortaliteValorisationRente;
    }

    /**
     * Définit la valeur de la propriété libTableMortaliteValorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTableMortaliteValorisationRente(String value) {
        this.libTableMortaliteValorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeTableMortaliteValorisationRenteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTableMortaliteValorisationRenteSilo() {
        return codeTableMortaliteValorisationRenteSilo;
    }

    /**
     * Définit la valeur de la propriété codeTableMortaliteValorisationRenteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTableMortaliteValorisationRenteSilo(String value) {
        this.codeTableMortaliteValorisationRenteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libTableMortaliteValorisationRenteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTableMortaliteValorisationRenteSilo() {
        return libTableMortaliteValorisationRenteSilo;
    }

    /**
     * Définit la valeur de la propriété libTableMortaliteValorisationRenteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTableMortaliteValorisationRenteSilo(String value) {
        this.libTableMortaliteValorisationRenteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété txFraisSurRente.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurRente() {
        return txFraisSurRente;
    }

    /**
     * Définit la valeur de la propriété txFraisSurRente.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurRente(BigDecimal value) {
        this.txFraisSurRente = value;
    }

    /**
     * Obtient la valeur de la propriété indicateurTarifBloque.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndicateurTarifBloque() {
        return indicateurTarifBloque;
    }

    /**
     * Définit la valeur de la propriété indicateurTarifBloque.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndicateurTarifBloque(Boolean value) {
        this.indicateurTarifBloque = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatCtrProprietaireTarif.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatCtrProprietaireTarif() {
        return codeNatCtrProprietaireTarif;
    }

    /**
     * Définit la valeur de la propriété codeNatCtrProprietaireTarif.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatCtrProprietaireTarif(String value) {
        this.codeNatCtrProprietaireTarif = value;
    }

    /**
     * Obtient la valeur de la propriété libNatCtrProprietaireTarif.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatCtrProprietaireTarif() {
        return libNatCtrProprietaireTarif;
    }

    /**
     * Définit la valeur de la propriété libNatCtrProprietaireTarif.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatCtrProprietaireTarif(String value) {
        this.libNatCtrProprietaireTarif = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeValoTarifRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeValoTarifRente() {
        return codeTypeValoTarifRente;
    }

    /**
     * Définit la valeur de la propriété codeTypeValoTarifRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeValoTarifRente(String value) {
        this.codeTypeValoTarifRente = value;
    }

    /**
     * Obtient la valeur de la propriété libTypeValoTarifRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibTypeValoTarifRente() {
        return libTypeValoTarifRente;
    }

    /**
     * Définit la valeur de la propriété libTypeValoTarifRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibTypeValoTarifRente(String value) {
        this.libTypeValoTarifRente = value;
    }

}
