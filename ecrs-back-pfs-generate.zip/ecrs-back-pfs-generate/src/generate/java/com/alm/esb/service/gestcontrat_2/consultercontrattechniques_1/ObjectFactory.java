
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ConsulterContratTechniquesFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", "ConsulterContratTechniquesFull");
    private final static QName _ConsulterContratTechniques_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", "ConsulterContratTechniques");
    private final static QName _ConsulterContratTechniquesFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", "ConsulterContratTechniquesFunc");
    private final static QName _ConsulterContratTechniquesResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", "ConsulterContratTechniquesResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ConsulterContratTechniquesFuncType }
     * 
     */
    public ConsulterContratTechniquesFuncType createConsulterContratTechniquesFuncType() {
        return new ConsulterContratTechniquesFuncType();
    }

    /**
     * Create an instance of {@link ConsulterContratTechniquesType }
     * 
     */
    public ConsulterContratTechniquesType createConsulterContratTechniquesType() {
        return new ConsulterContratTechniquesType();
    }

    /**
     * Create an instance of {@link ConsulterContratTechniquesResponseType }
     * 
     */
    public ConsulterContratTechniquesResponseType createConsulterContratTechniquesResponseType() {
        return new ConsulterContratTechniquesResponseType();
    }

    /**
     * Create an instance of {@link ConsulterContratTechniquesFullType }
     * 
     */
    public ConsulterContratTechniquesFullType createConsulterContratTechniquesFullType() {
        return new ConsulterContratTechniquesFullType();
    }

    /**
     * Create an instance of {@link ValOptionRenteType }
     * 
     */
    public ValOptionRenteType createValOptionRenteType() {
        return new ValOptionRenteType();
    }

    /**
     * Create an instance of {@link EditionType }
     * 
     */
    public EditionType createEditionType() {
        return new EditionType();
    }

    /**
     * Create an instance of {@link IdentDocumentType }
     * 
     */
    public IdentDocumentType createIdentDocumentType() {
        return new IdentDocumentType();
    }

    /**
     * Create an instance of {@link OptionContratEpargnePrimeType }
     * 
     */
    public OptionContratEpargnePrimeType createOptionContratEpargnePrimeType() {
        return new OptionContratEpargnePrimeType();
    }

    /**
     * Create an instance of {@link ValorisationRenteType }
     * 
     */
    public ValorisationRenteType createValorisationRenteType() {
        return new ValorisationRenteType();
    }

    /**
     * Create an instance of {@link IdentificationContratSiloType }
     * 
     */
    public IdentificationContratSiloType createIdentificationContratSiloType() {
        return new IdentificationContratSiloType();
    }

    /**
     * Create an instance of {@link IdSiloAdherenteType }
     * 
     */
    public IdSiloAdherenteType createIdSiloAdherenteType() {
        return new IdSiloAdherenteType();
    }

    /**
     * Create an instance of {@link IdentificationContratType }
     * 
     */
    public IdentificationContratType createIdentificationContratType() {
        return new IdentificationContratType();
    }

    /**
     * Create an instance of {@link OptionRenteType }
     * 
     */
    public OptionRenteType createOptionRenteType() {
        return new OptionRenteType();
    }

    /**
     * Create an instance of {@link IdSiloParamType }
     * 
     */
    public IdSiloParamType createIdSiloParamType() {
        return new IdSiloParamType();
    }

    /**
     * Create an instance of {@link EcheancierPaiementPrimeType }
     * 
     */
    public EcheancierPaiementPrimeType createEcheancierPaiementPrimeType() {
        return new EcheancierPaiementPrimeType();
    }

    /**
     * Create an instance of {@link IdSiloType }
     * 
     */
    public IdSiloType createIdSiloType() {
        return new IdSiloType();
    }

    /**
     * Create an instance of {@link ParametresEditionType }
     * 
     */
    public ParametresEditionType createParametresEditionType() {
        return new ParametresEditionType();
    }

    /**
     * Create an instance of {@link IdentificationSiloType }
     * 
     */
    public IdentificationSiloType createIdentificationSiloType() {
        return new IdentificationSiloType();
    }

    /**
     * Create an instance of {@link IndParamType }
     * 
     */
    public IndParamType createIndParamType() {
        return new IndParamType();
    }

    /**
     * Create an instance of {@link IdentifiantSiloType }
     * 
     */
    public IdentifiantSiloType createIdentifiantSiloType() {
        return new IdentifiantSiloType();
    }

    /**
     * Create an instance of {@link InfoPrelevSoclRevaloType }
     * 
     */
    public InfoPrelevSoclRevaloType createInfoPrelevSoclRevaloType() {
        return new InfoPrelevSoclRevaloType();
    }

    /**
     * Create an instance of {@link ParametrageEditionsType }
     * 
     */
    public ParametrageEditionsType createParametrageEditionsType() {
        return new ParametrageEditionsType();
    }

    /**
     * Create an instance of {@link ConditionContractuelleType }
     * 
     */
    public ConditionContractuelleType createConditionContractuelleType() {
        return new ConditionContractuelleType();
    }

    /**
     * Create an instance of {@link PieceJustificativeType }
     * 
     */
    public PieceJustificativeType createPieceJustificativeType() {
        return new PieceJustificativeType();
    }

    /**
     * Create an instance of {@link InfoValoType }
     * 
     */
    public InfoValoType createInfoValoType() {
        return new InfoValoType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratTechniquesFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", name = "ConsulterContratTechniquesFull")
    public JAXBElement<ConsulterContratTechniquesFullType> createConsulterContratTechniquesFull(ConsulterContratTechniquesFullType value) {
        return new JAXBElement<ConsulterContratTechniquesFullType>(_ConsulterContratTechniquesFull_QNAME, ConsulterContratTechniquesFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratTechniquesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", name = "ConsulterContratTechniques")
    public JAXBElement<ConsulterContratTechniquesType> createConsulterContratTechniques(ConsulterContratTechniquesType value) {
        return new JAXBElement<ConsulterContratTechniquesType>(_ConsulterContratTechniques_QNAME, ConsulterContratTechniquesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratTechniquesFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", name = "ConsulterContratTechniquesFunc")
    public JAXBElement<ConsulterContratTechniquesFuncType> createConsulterContratTechniquesFunc(ConsulterContratTechniquesFuncType value) {
        return new JAXBElement<ConsulterContratTechniquesFuncType>(_ConsulterContratTechniquesFunc_QNAME, ConsulterContratTechniquesFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratTechniquesResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1", name = "ConsulterContratTechniquesResponse")
    public JAXBElement<ConsulterContratTechniquesResponseType> createConsulterContratTechniquesResponse(ConsulterContratTechniquesResponseType value) {
        return new JAXBElement<ConsulterContratTechniquesResponseType>(_ConsulterContratTechniquesResponse_QNAME, ConsulterContratTechniquesResponseType.class, null, value);
    }

}
