
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentContratAdherente"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}ContratCollAdherente" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratAdherenteType", propOrder = {
    "identContratAdherente",
    "contratCollAdherente"
})
public class ContratAdherenteType {

    @XmlElement(name = "IdentContratAdherente", required = true)
    protected IdentContratAdherenteType identContratAdherente;
    @XmlElement(name = "ContratCollAdherente")
    protected ContratCollAdherenteType contratCollAdherente;

    /**
     * Obtient la valeur de la propriété identContratAdherente.
     * 
     * @return
     *     possible object is
     *     {@link IdentContratAdherenteType }
     *     
     */
    public IdentContratAdherenteType getIdentContratAdherente() {
        return identContratAdherente;
    }

    /**
     * Définit la valeur de la propriété identContratAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentContratAdherenteType }
     *     
     */
    public void setIdentContratAdherente(IdentContratAdherenteType value) {
        this.identContratAdherente = value;
    }

    /**
     * Obtient la valeur de la propriété contratCollAdherente.
     * 
     * @return
     *     possible object is
     *     {@link ContratCollAdherenteType }
     *     
     */
    public ContratCollAdherenteType getContratCollAdherente() {
        return contratCollAdherente;
    }

    /**
     * Définit la valeur de la propriété contratCollAdherente.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratCollAdherenteType }
     *     
     */
    public void setContratCollAdherente(ContratCollAdherenteType value) {
        this.contratCollAdherente = value;
    }

}
