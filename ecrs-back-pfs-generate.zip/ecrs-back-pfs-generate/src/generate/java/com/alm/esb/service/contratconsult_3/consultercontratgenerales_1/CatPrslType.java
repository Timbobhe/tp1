
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour CatPrslType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CatPrslType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idCatPrsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCatPrsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCatPrsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeTrsmJustifSante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeTrsmJustifSante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeTrsmJustifSanteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeAffil" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeAffilSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModePortb" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModePortb" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModePortbSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCatPrsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCatPrsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCatPrslSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffetCatPrsl" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffetCatPrsl" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateSitCatPers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codePpl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPpl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNonGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNonGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ageMoyenPpl" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="efctPpl" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="efctHommePpl" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="indImpactCotis" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeNivCouv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNivCouv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indEligAffilInet" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indLimitBenefUniq" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeCPN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCPN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Pdt" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}PdtType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="GarSouscrites" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}GarSouscritesType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="CtrCatPers" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrCatPersType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CatPrslType", propOrder = {
    "idCatPrsl",
    "codeCatPrsl",
    "libCatPrsl",
    "codeModeTrsmJustifSante",
    "libModeTrsmJustifSante",
    "codeModeTrsmJustifSanteSilo",
    "codeModeAffil",
    "libModeAffil",
    "codeModeAffilSilo",
    "codeModePortb",
    "libModePortb",
    "codeModePortbSilo",
    "codeSitCatPrsl",
    "libSitCatPrsl",
    "codeSitCatPrslSilo",
    "dateEffetCatPrsl",
    "dateFinEffetCatPrsl",
    "dateSitCatPers",
    "codePpl",
    "libPpl",
    "codeNonGest",
    "libNonGest",
    "ageMoyenPpl",
    "efctPpl",
    "efctHommePpl",
    "indImpactCotis",
    "codeNivCouv",
    "libNivCouv",
    "indEligAffilInet",
    "indLimitBenefUniq",
    "codeCPN",
    "libCPN",
    "pdt",
    "garSouscrites",
    "ctrCatPers"
})
public class CatPrslType {

    protected String idCatPrsl;
    protected String codeCatPrsl;
    protected String libCatPrsl;
    protected String codeModeTrsmJustifSante;
    protected String libModeTrsmJustifSante;
    protected String codeModeTrsmJustifSanteSilo;
    protected String codeModeAffil;
    protected String libModeAffil;
    protected String codeModeAffilSilo;
    protected String codeModePortb;
    protected String libModePortb;
    protected String codeModePortbSilo;
    protected String codeSitCatPrsl;
    protected String libSitCatPrsl;
    protected String codeSitCatPrslSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetCatPrsl;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffetCatPrsl;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitCatPers;
    protected String codePpl;
    protected String libPpl;
    protected String codeNonGest;
    protected String libNonGest;
    protected BigInteger ageMoyenPpl;
    protected BigInteger efctPpl;
    protected BigInteger efctHommePpl;
    protected Boolean indImpactCotis;
    protected String codeNivCouv;
    protected String libNivCouv;
    protected Boolean indEligAffilInet;
    protected Boolean indLimitBenefUniq;
    protected String codeCPN;
    protected String libCPN;
    @XmlElement(name = "Pdt")
    protected List<PdtType> pdt;
    @XmlElement(name = "GarSouscrites")
    protected List<GarSouscritesType> garSouscrites;
    @XmlElement(name = "CtrCatPers")
    protected CtrCatPersType ctrCatPers;

    /**
     * Obtient la valeur de la propriété idCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCatPrsl() {
        return idCatPrsl;
    }

    /**
     * Définit la valeur de la propriété idCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCatPrsl(String value) {
        this.idCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété codeCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCatPrsl() {
        return codeCatPrsl;
    }

    /**
     * Définit la valeur de la propriété codeCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCatPrsl(String value) {
        this.codeCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété libCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCatPrsl() {
        return libCatPrsl;
    }

    /**
     * Définit la valeur de la propriété libCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCatPrsl(String value) {
        this.libCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeTrsmJustifSante.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeTrsmJustifSante() {
        return codeModeTrsmJustifSante;
    }

    /**
     * Définit la valeur de la propriété codeModeTrsmJustifSante.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeTrsmJustifSante(String value) {
        this.codeModeTrsmJustifSante = value;
    }

    /**
     * Obtient la valeur de la propriété libModeTrsmJustifSante.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeTrsmJustifSante() {
        return libModeTrsmJustifSante;
    }

    /**
     * Définit la valeur de la propriété libModeTrsmJustifSante.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeTrsmJustifSante(String value) {
        this.libModeTrsmJustifSante = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeTrsmJustifSanteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeTrsmJustifSanteSilo() {
        return codeModeTrsmJustifSanteSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeTrsmJustifSanteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeTrsmJustifSanteSilo(String value) {
        this.codeModeTrsmJustifSanteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeAffil() {
        return codeModeAffil;
    }

    /**
     * Définit la valeur de la propriété codeModeAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeAffil(String value) {
        this.codeModeAffil = value;
    }

    /**
     * Obtient la valeur de la propriété libModeAffil.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeAffil() {
        return libModeAffil;
    }

    /**
     * Définit la valeur de la propriété libModeAffil.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeAffil(String value) {
        this.libModeAffil = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeAffilSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeAffilSilo() {
        return codeModeAffilSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeAffilSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeAffilSilo(String value) {
        this.codeModeAffilSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeModePortb.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModePortb() {
        return codeModePortb;
    }

    /**
     * Définit la valeur de la propriété codeModePortb.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModePortb(String value) {
        this.codeModePortb = value;
    }

    /**
     * Obtient la valeur de la propriété libModePortb.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModePortb() {
        return libModePortb;
    }

    /**
     * Définit la valeur de la propriété libModePortb.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModePortb(String value) {
        this.libModePortb = value;
    }

    /**
     * Obtient la valeur de la propriété codeModePortbSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModePortbSilo() {
        return codeModePortbSilo;
    }

    /**
     * Définit la valeur de la propriété codeModePortbSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModePortbSilo(String value) {
        this.codeModePortbSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCatPrsl() {
        return codeSitCatPrsl;
    }

    /**
     * Définit la valeur de la propriété codeSitCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCatPrsl(String value) {
        this.codeSitCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCatPrsl() {
        return libSitCatPrsl;
    }

    /**
     * Définit la valeur de la propriété libSitCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCatPrsl(String value) {
        this.libSitCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCatPrslSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCatPrslSilo() {
        return codeSitCatPrslSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitCatPrslSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCatPrslSilo(String value) {
        this.codeSitCatPrslSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetCatPrsl() {
        return dateEffetCatPrsl;
    }

    /**
     * Définit la valeur de la propriété dateEffetCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetCatPrsl(XMLGregorianCalendar value) {
        this.dateEffetCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetCatPrsl.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffetCatPrsl() {
        return dateFinEffetCatPrsl;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetCatPrsl.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffetCatPrsl(XMLGregorianCalendar value) {
        this.dateFinEffetCatPrsl = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitCatPers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitCatPers() {
        return dateSitCatPers;
    }

    /**
     * Définit la valeur de la propriété dateSitCatPers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitCatPers(XMLGregorianCalendar value) {
        this.dateSitCatPers = value;
    }

    /**
     * Obtient la valeur de la propriété codePpl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePpl() {
        return codePpl;
    }

    /**
     * Définit la valeur de la propriété codePpl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePpl(String value) {
        this.codePpl = value;
    }

    /**
     * Obtient la valeur de la propriété libPpl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPpl() {
        return libPpl;
    }

    /**
     * Définit la valeur de la propriété libPpl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPpl(String value) {
        this.libPpl = value;
    }

    /**
     * Obtient la valeur de la propriété codeNonGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNonGest() {
        return codeNonGest;
    }

    /**
     * Définit la valeur de la propriété codeNonGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNonGest(String value) {
        this.codeNonGest = value;
    }

    /**
     * Obtient la valeur de la propriété libNonGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNonGest() {
        return libNonGest;
    }

    /**
     * Définit la valeur de la propriété libNonGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNonGest(String value) {
        this.libNonGest = value;
    }

    /**
     * Obtient la valeur de la propriété ageMoyenPpl.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMoyenPpl() {
        return ageMoyenPpl;
    }

    /**
     * Définit la valeur de la propriété ageMoyenPpl.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMoyenPpl(BigInteger value) {
        this.ageMoyenPpl = value;
    }

    /**
     * Obtient la valeur de la propriété efctPpl.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEfctPpl() {
        return efctPpl;
    }

    /**
     * Définit la valeur de la propriété efctPpl.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEfctPpl(BigInteger value) {
        this.efctPpl = value;
    }

    /**
     * Obtient la valeur de la propriété efctHommePpl.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getEfctHommePpl() {
        return efctHommePpl;
    }

    /**
     * Définit la valeur de la propriété efctHommePpl.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setEfctHommePpl(BigInteger value) {
        this.efctHommePpl = value;
    }

    /**
     * Obtient la valeur de la propriété indImpactCotis.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndImpactCotis() {
        return indImpactCotis;
    }

    /**
     * Définit la valeur de la propriété indImpactCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndImpactCotis(Boolean value) {
        this.indImpactCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeNivCouv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNivCouv() {
        return codeNivCouv;
    }

    /**
     * Définit la valeur de la propriété codeNivCouv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNivCouv(String value) {
        this.codeNivCouv = value;
    }

    /**
     * Obtient la valeur de la propriété libNivCouv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNivCouv() {
        return libNivCouv;
    }

    /**
     * Définit la valeur de la propriété libNivCouv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNivCouv(String value) {
        this.libNivCouv = value;
    }

    /**
     * Obtient la valeur de la propriété indEligAffilInet.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndEligAffilInet() {
        return indEligAffilInet;
    }

    /**
     * Définit la valeur de la propriété indEligAffilInet.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndEligAffilInet(Boolean value) {
        this.indEligAffilInet = value;
    }

    /**
     * Obtient la valeur de la propriété indLimitBenefUniq.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndLimitBenefUniq() {
        return indLimitBenefUniq;
    }

    /**
     * Définit la valeur de la propriété indLimitBenefUniq.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndLimitBenefUniq(Boolean value) {
        this.indLimitBenefUniq = value;
    }

    /**
     * Obtient la valeur de la propriété codeCPN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCPN() {
        return codeCPN;
    }

    /**
     * Définit la valeur de la propriété codeCPN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCPN(String value) {
        this.codeCPN = value;
    }

    /**
     * Obtient la valeur de la propriété libCPN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCPN() {
        return libCPN;
    }

    /**
     * Définit la valeur de la propriété libCPN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCPN(String value) {
        this.libCPN = value;
    }

    /**
     * Gets the value of the pdt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pdt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPdt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PdtType }
     * 
     * 
     */
    public List<PdtType> getPdt() {
        if (pdt == null) {
            pdt = new ArrayList<PdtType>();
        }
        return this.pdt;
    }

    /**
     * Gets the value of the garSouscrites property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the garSouscrites property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGarSouscrites().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GarSouscritesType }
     * 
     * 
     */
    public List<GarSouscritesType> getGarSouscrites() {
        if (garSouscrites == null) {
            garSouscrites = new ArrayList<GarSouscritesType>();
        }
        return this.garSouscrites;
    }

    /**
     * Obtient la valeur de la propriété ctrCatPers.
     * 
     * @return
     *     possible object is
     *     {@link CtrCatPersType }
     *     
     */
    public CtrCatPersType getCtrCatPers() {
        return ctrCatPers;
    }

    /**
     * Définit la valeur de la propriété ctrCatPers.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrCatPersType }
     *     
     */
    public void setCtrCatPers(CtrCatPersType value) {
        this.ctrCatPers = value;
    }

}
