
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdSiloParamType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdSiloParamType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="valId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdSiloParamType", propOrder = {
    "valId",
    "typeId"
})
public class IdSiloParamType {

    protected String valId;
    protected String typeId;

    /**
     * Obtient la valeur de la propriété valId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValId() {
        return valId;
    }

    /**
     * Définit la valeur de la propriété valId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValId(String value) {
        this.valId = value;
    }

    /**
     * Obtient la valeur de la propriété typeId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * Définit la valeur de la propriété typeId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeId(String value) {
        this.typeId = value;
    }

}
