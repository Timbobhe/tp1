
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterStructInvContratFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterStructInvContratFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}ConsulterStructInvContrat" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterStructInvContrat_1}ConsulterStructInvContratResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterStructInvContratFullType", propOrder = {
    "consulterStructInvContrat",
    "consulterStructInvContratResponse"
})
public class ConsulterStructInvContratFullType {

    @XmlElement(name = "ConsulterStructInvContrat")
    protected ConsulterStructInvContratType consulterStructInvContrat;
    @XmlElement(name = "ConsulterStructInvContratResponse")
    protected ConsulterStructInvContratResponseType consulterStructInvContratResponse;

    /**
     * Obtient la valeur de la propriété consulterStructInvContrat.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterStructInvContratType }
     *     
     */
    public ConsulterStructInvContratType getConsulterStructInvContrat() {
        return consulterStructInvContrat;
    }

    /**
     * Définit la valeur de la propriété consulterStructInvContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterStructInvContratType }
     *     
     */
    public void setConsulterStructInvContrat(ConsulterStructInvContratType value) {
        this.consulterStructInvContrat = value;
    }

    /**
     * Obtient la valeur de la propriété consulterStructInvContratResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterStructInvContratResponseType }
     *     
     */
    public ConsulterStructInvContratResponseType getConsulterStructInvContratResponse() {
        return consulterStructInvContratResponse;
    }

    /**
     * Définit la valeur de la propriété consulterStructInvContratResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterStructInvContratResponseType }
     *     
     */
    public void setConsulterStructInvContratResponse(ConsulterStructInvContratResponseType value) {
        this.consulterStructInvContratResponse = value;
    }

}
