
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour NavCliConType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="NavCliConType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="IdentGroupeCourt" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1}IdentGroupeCourtType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="IdentSiloCourt" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1}IdentSiloCourtType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NavCliConType", propOrder = {
    "identGroupeCourt",
    "identSiloCourt"
})
public class NavCliConType {

    @XmlElement(name = "IdentGroupeCourt")
    protected List<IdentGroupeCourtType> identGroupeCourt;
    @XmlElement(name = "IdentSiloCourt")
    protected List<IdentSiloCourtType> identSiloCourt;

    /**
     * Gets the value of the identGroupeCourt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identGroupeCourt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentGroupeCourt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentGroupeCourtType }
     * 
     * 
     */
    public List<IdentGroupeCourtType> getIdentGroupeCourt() {
        if (identGroupeCourt == null) {
            identGroupeCourt = new ArrayList<IdentGroupeCourtType>();
        }
        return this.identGroupeCourt;
    }

    /**
     * Gets the value of the identSiloCourt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the identSiloCourt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getIdentSiloCourt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link IdentSiloCourtType }
     * 
     * 
     */
    public List<IdentSiloCourtType> getIdentSiloCourt() {
        if (identSiloCourt == null) {
            identSiloCourt = new ArrayList<IdentSiloCourtType>();
        }
        return this.identSiloCourt;
    }

}
