
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour PieceJustificativeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PieceJustificativeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentDocument" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}IdentDocumentType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PieceJustificativeType", propOrder = {
    "identDocument"
})
public class PieceJustificativeType {

    @XmlElement(name = "IdentDocument")
    protected IdentDocumentType identDocument;

    /**
     * Obtient la valeur de la propriété identDocument.
     * 
     * @return
     *     possible object is
     *     {@link IdentDocumentType }
     *     
     */
    public IdentDocumentType getIdentDocument() {
        return identDocument;
    }

    /**
     * Définit la valeur de la propriété identDocument.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentDocumentType }
     *     
     */
    public void setIdentDocument(IdentDocumentType value) {
        this.identDocument = value;
    }

}
