
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CoordonneesCmptBancType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CoordonneesCmptBancType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeBIC" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeIBAN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="titulaireCmpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEtab" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEtab" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Rib" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}RibType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoordonneesCmptBancType", propOrder = {
    "codeBIC",
    "codeIBAN",
    "titulaireCmpt",
    "codeEtab",
    "libEtab",
    "rib"
})
public class CoordonneesCmptBancType {

    protected String codeBIC;
    protected String codeIBAN;
    protected String titulaireCmpt;
    protected String codeEtab;
    protected String libEtab;
    @XmlElement(name = "Rib")
    protected RibType rib;

    /**
     * Obtient la valeur de la propriété codeBIC.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBIC() {
        return codeBIC;
    }

    /**
     * Définit la valeur de la propriété codeBIC.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBIC(String value) {
        this.codeBIC = value;
    }

    /**
     * Obtient la valeur de la propriété codeIBAN.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeIBAN() {
        return codeIBAN;
    }

    /**
     * Définit la valeur de la propriété codeIBAN.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeIBAN(String value) {
        this.codeIBAN = value;
    }

    /**
     * Obtient la valeur de la propriété titulaireCmpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTitulaireCmpt() {
        return titulaireCmpt;
    }

    /**
     * Définit la valeur de la propriété titulaireCmpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTitulaireCmpt(String value) {
        this.titulaireCmpt = value;
    }

    /**
     * Obtient la valeur de la propriété codeEtab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEtab() {
        return codeEtab;
    }

    /**
     * Définit la valeur de la propriété codeEtab.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEtab(String value) {
        this.codeEtab = value;
    }

    /**
     * Obtient la valeur de la propriété libEtab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEtab() {
        return libEtab;
    }

    /**
     * Définit la valeur de la propriété libEtab.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEtab(String value) {
        this.libEtab = value;
    }

    /**
     * Obtient la valeur de la propriété rib.
     * 
     * @return
     *     possible object is
     *     {@link RibType }
     *     
     */
    public RibType getRib() {
        return rib;
    }

    /**
     * Définit la valeur de la propriété rib.
     * 
     * @param value
     *     allowed object is
     *     {@link RibType }
     *     
     */
    public void setRib(RibType value) {
        this.rib = value;
    }

}
