
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour HorizonInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="HorizonInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idHorizonInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomHorizonInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="borneMinVersementInv" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="borneMaxVersementInv" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="borneMinDeplacerCapitalInvesti" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="borneMaxDeplacerCapitalInvesti" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "HorizonInvType", propOrder = {
    "idHorizonInv",
    "nomHorizonInv",
    "borneMinVersementInv",
    "borneMaxVersementInv",
    "borneMinDeplacerCapitalInvesti",
    "borneMaxDeplacerCapitalInvesti"
})
public class HorizonInvType {

    protected String idHorizonInv;
    protected String nomHorizonInv;
    protected BigInteger borneMinVersementInv;
    protected BigInteger borneMaxVersementInv;
    protected BigInteger borneMinDeplacerCapitalInvesti;
    protected BigInteger borneMaxDeplacerCapitalInvesti;

    /**
     * Obtient la valeur de la propriété idHorizonInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdHorizonInv() {
        return idHorizonInv;
    }

    /**
     * Définit la valeur de la propriété idHorizonInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdHorizonInv(String value) {
        this.idHorizonInv = value;
    }

    /**
     * Obtient la valeur de la propriété nomHorizonInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomHorizonInv() {
        return nomHorizonInv;
    }

    /**
     * Définit la valeur de la propriété nomHorizonInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomHorizonInv(String value) {
        this.nomHorizonInv = value;
    }

    /**
     * Obtient la valeur de la propriété borneMinVersementInv.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBorneMinVersementInv() {
        return borneMinVersementInv;
    }

    /**
     * Définit la valeur de la propriété borneMinVersementInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBorneMinVersementInv(BigInteger value) {
        this.borneMinVersementInv = value;
    }

    /**
     * Obtient la valeur de la propriété borneMaxVersementInv.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBorneMaxVersementInv() {
        return borneMaxVersementInv;
    }

    /**
     * Définit la valeur de la propriété borneMaxVersementInv.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBorneMaxVersementInv(BigInteger value) {
        this.borneMaxVersementInv = value;
    }

    /**
     * Obtient la valeur de la propriété borneMinDeplacerCapitalInvesti.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBorneMinDeplacerCapitalInvesti() {
        return borneMinDeplacerCapitalInvesti;
    }

    /**
     * Définit la valeur de la propriété borneMinDeplacerCapitalInvesti.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBorneMinDeplacerCapitalInvesti(BigInteger value) {
        this.borneMinDeplacerCapitalInvesti = value;
    }

    /**
     * Obtient la valeur de la propriété borneMaxDeplacerCapitalInvesti.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getBorneMaxDeplacerCapitalInvesti() {
        return borneMaxDeplacerCapitalInvesti;
    }

    /**
     * Définit la valeur de la propriété borneMaxDeplacerCapitalInvesti.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setBorneMaxDeplacerCapitalInvesti(BigInteger value) {
        this.borneMaxDeplacerCapitalInvesti = value;
    }

}
