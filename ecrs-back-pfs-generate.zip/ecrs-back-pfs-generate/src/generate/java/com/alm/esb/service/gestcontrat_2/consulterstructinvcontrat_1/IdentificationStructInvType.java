
package com.alm.esb.service.gestcontrat_2.consulterstructinvcontrat_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour IdentificationStructInvType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentificationStructInvType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idStructInv" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeSituationStructInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSituationStructInv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSituationStructInv" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentificationStructInvType", propOrder = {
    "idStructInv",
    "codeSituationStructInv",
    "libSituationStructInv",
    "dateSituationStructInv"
})
public class IdentificationStructInvType {

    @XmlElement(required = true)
    protected String idStructInv;
    protected String codeSituationStructInv;
    protected String libSituationStructInv;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSituationStructInv;

    /**
     * Obtient la valeur de la propriété idStructInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdStructInv() {
        return idStructInv;
    }

    /**
     * Définit la valeur de la propriété idStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdStructInv(String value) {
        this.idStructInv = value;
    }

    /**
     * Obtient la valeur de la propriété codeSituationStructInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSituationStructInv() {
        return codeSituationStructInv;
    }

    /**
     * Définit la valeur de la propriété codeSituationStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSituationStructInv(String value) {
        this.codeSituationStructInv = value;
    }

    /**
     * Obtient la valeur de la propriété libSituationStructInv.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSituationStructInv() {
        return libSituationStructInv;
    }

    /**
     * Définit la valeur de la propriété libSituationStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSituationStructInv(String value) {
        this.libSituationStructInv = value;
    }

    /**
     * Obtient la valeur de la propriété dateSituationStructInv.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSituationStructInv() {
        return dateSituationStructInv;
    }

    /**
     * Définit la valeur de la propriété dateSituationStructInv.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSituationStructInv(XMLGregorianCalendar value) {
        this.dateSituationStructInv = value;
    }

}
