
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.creationdemope_4.creerdemope_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreerDemOpeResponse_QNAME = new QName("http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", "CreerDemOpeResponse");
    private final static QName _CreerDemOpeFull_QNAME = new QName("http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", "CreerDemOpeFull");
    private final static QName _CreerDemOpe_QNAME = new QName("http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", "CreerDemOpe");
    private final static QName _CreerDemOpeFunc_QNAME = new QName("http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", "CreerDemOpeFunc");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.creationdemope_4.creerdemope_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreerDemOpeFuncType }
     * 
     */
    public CreerDemOpeFuncType createCreerDemOpeFuncType() {
        return new CreerDemOpeFuncType();
    }

    /**
     * Create an instance of {@link CreerDemOpeResponseType }
     * 
     */
    public CreerDemOpeResponseType createCreerDemOpeResponseType() {
        return new CreerDemOpeResponseType();
    }

    /**
     * Create an instance of {@link CreerDemOpeFullType }
     * 
     */
    public CreerDemOpeFullType createCreerDemOpeFullType() {
        return new CreerDemOpeFullType();
    }

    /**
     * Create an instance of {@link CreerDemOpeType }
     * 
     */
    public CreerDemOpeType createCreerDemOpeType() {
        return new CreerDemOpeType();
    }

    /**
     * Create an instance of {@link PiecesJointesType }
     * 
     */
    public PiecesJointesType createPiecesJointesType() {
        return new PiecesJointesType();
    }

    /**
     * Create an instance of {@link IdCtrSiloType }
     * 
     */
    public IdCtrSiloType createIdCtrSiloType() {
        return new IdCtrSiloType();
    }

    /**
     * Create an instance of {@link IdentPersType }
     * 
     */
    public IdentPersType createIdentPersType() {
        return new IdentPersType();
    }

    /**
     * Create an instance of {@link EmisDocType }
     * 
     */
    public EmisDocType createEmisDocType() {
        return new EmisDocType();
    }

    /**
     * Create an instance of {@link FormulaireType }
     * 
     */
    public FormulaireType createFormulaireType() {
        return new FormulaireType();
    }

    /**
     * Create an instance of {@link IdxDocType }
     * 
     */
    public IdxDocType createIdxDocType() {
        return new IdxDocType();
    }

    /**
     * Create an instance of {@link DemOpeType }
     * 
     */
    public DemOpeType createDemOpeType() {
        return new DemOpeType();
    }

    /**
     * Create an instance of {@link IdentDocType }
     * 
     */
    public IdentDocType createIdentDocType() {
        return new IdentDocType();
    }

    /**
     * Create an instance of {@link NumerisDocType }
     * 
     */
    public NumerisDocType createNumerisDocType() {
        return new NumerisDocType();
    }

    /**
     * Create an instance of {@link IdDemSiloType }
     * 
     */
    public IdDemSiloType createIdDemSiloType() {
        return new IdDemSiloType();
    }

    /**
     * Create an instance of {@link IdDemSiloResponseType }
     * 
     */
    public IdDemSiloResponseType createIdDemSiloResponseType() {
        return new IdDemSiloResponseType();
    }

    /**
     * Create an instance of {@link InfoComplType }
     * 
     */
    public InfoComplType createInfoComplType() {
        return new InfoComplType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreerDemOpeResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", name = "CreerDemOpeResponse")
    public JAXBElement<CreerDemOpeResponseType> createCreerDemOpeResponse(CreerDemOpeResponseType value) {
        return new JAXBElement<CreerDemOpeResponseType>(_CreerDemOpeResponse_QNAME, CreerDemOpeResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreerDemOpeFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", name = "CreerDemOpeFull")
    public JAXBElement<CreerDemOpeFullType> createCreerDemOpeFull(CreerDemOpeFullType value) {
        return new JAXBElement<CreerDemOpeFullType>(_CreerDemOpeFull_QNAME, CreerDemOpeFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreerDemOpeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", name = "CreerDemOpe")
    public JAXBElement<CreerDemOpeType> createCreerDemOpe(CreerDemOpeType value) {
        return new JAXBElement<CreerDemOpeType>(_CreerDemOpe_QNAME, CreerDemOpeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreerDemOpeFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1", name = "CreerDemOpeFunc")
    public JAXBElement<CreerDemOpeFuncType> createCreerDemOpeFunc(CreerDemOpeFuncType value) {
        return new JAXBElement<CreerDemOpeFuncType>(_CreerDemOpeFunc_QNAME, CreerDemOpeFuncType.class, null, value);
    }

}
