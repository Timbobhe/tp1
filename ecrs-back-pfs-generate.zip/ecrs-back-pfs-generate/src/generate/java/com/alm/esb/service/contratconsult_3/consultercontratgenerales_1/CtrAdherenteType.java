
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CtrAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtrAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentCtrAdh" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdentCtrAdherenteType"/>
 *         &lt;element name="CtrColl" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CtrCollAdherenteType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtrAdherenteType", propOrder = {
    "identCtrAdh",
    "ctrColl"
})
public class CtrAdherenteType {

    @XmlElement(name = "IdentCtrAdh", required = true)
    protected IdentCtrAdherenteType identCtrAdh;
    @XmlElement(name = "CtrColl")
    protected CtrCollAdherenteType ctrColl;

    /**
     * Obtient la valeur de la propriété identCtrAdh.
     * 
     * @return
     *     possible object is
     *     {@link IdentCtrAdherenteType }
     *     
     */
    public IdentCtrAdherenteType getIdentCtrAdh() {
        return identCtrAdh;
    }

    /**
     * Définit la valeur de la propriété identCtrAdh.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentCtrAdherenteType }
     *     
     */
    public void setIdentCtrAdh(IdentCtrAdherenteType value) {
        this.identCtrAdh = value;
    }

    /**
     * Obtient la valeur de la propriété ctrColl.
     * 
     * @return
     *     possible object is
     *     {@link CtrCollAdherenteType }
     *     
     */
    public CtrCollAdherenteType getCtrColl() {
        return ctrColl;
    }

    /**
     * Définit la valeur de la propriété ctrColl.
     * 
     * @param value
     *     allowed object is
     *     {@link CtrCollAdherenteType }
     *     
     */
    public void setCtrColl(CtrCollAdherenteType value) {
        this.ctrColl = value;
    }

}
