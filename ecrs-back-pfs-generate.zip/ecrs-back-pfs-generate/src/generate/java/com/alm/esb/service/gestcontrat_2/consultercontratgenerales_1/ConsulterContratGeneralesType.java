
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratGeneralesType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratGeneralesType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_1}IdentSilo"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratGeneralesType", propOrder = {
    "identSilo"
})
public class ConsulterContratGeneralesType {

    @XmlElement(name = "IdentSilo", required = true)
    protected IdentDansSiloType identSilo;

    /**
     * Obtient la valeur de la propriété identSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdentDansSiloType }
     *     
     */
    public IdentDansSiloType getIdentSilo() {
        return identSilo;
    }

    /**
     * Définit la valeur de la propriété identSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentDansSiloType }
     *     
     */
    public void setIdentSilo(IdentDansSiloType value) {
        this.identSilo = value;
    }

}
