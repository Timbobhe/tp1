
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Pdt_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Pdt");
    private final static QName _Rib_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Rib");
    private final static QName _ConsulterContratGeneralesResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ConsulterContratGeneralesResponse");
    private final static QName _IdentsPere_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentsPere");
    private final static QName _IdentSilo_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSilo");
    private final static QName _Vente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Vente");
    private final static QName _ContratColl_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ContratColl");
    private final static QName _SignaletiquePPAssurAdd_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "SignaletiquePPAssurAdd");
    private final static QName _IdentSiloSouscript_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSiloSouscript");
    private final static QName _EchPaiementPrime_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "EchPaiementPrime");
    private final static QName _ActeurContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ActeurContrat");
    private final static QName _IdentContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentContrat");
    private final static QName _Souscripteurs_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Souscripteurs");
    private final static QName _ConsulterContratGenerales_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ConsulterContratGenerales");
    private final static QName _TrsfCtr_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "TrsfCtr");
    private final static QName _Adhesion_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Adhesion");
    private final static QName _AssureAdditionnels_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "AssureAdditionnels");
    private final static QName _LibClause_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "LibClause");
    private final static QName _IdentSiloContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSiloContrat");
    private final static QName _Contrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Contrat");
    private final static QName _StructOrga_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "StructOrga");
    private final static QName _AssurePrincipal_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "AssurePrincipal");
    private final static QName _OffreCommSouscrite_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "OffreCommSouscrite");
    private final static QName _IdentContratAdherente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentContratAdherente");
    private final static QName _IdentSiloAdherente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSiloAdherente");
    private final static QName _IdSilo_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdSilo");
    private final static QName _AffilContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "AffilContrat");
    private final static QName _ContratCatPers_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ContratCatPers");
    private final static QName _IdentContratPere_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentContratPere");
    private final static QName _GarSouscrites_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "GarSouscrites");
    private final static QName _Gest_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Gest");
    private final static QName _ActivitePartnrt_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ActivitePartnrt");
    private final static QName _IdentSiloAssurPrinc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSiloAssurPrinc");
    private final static QName _OptContratEpargne_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "OptContratEpargne");
    private final static QName _CategPersonnelAdherente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "CategPersonnelAdherente");
    private final static QName _InfoContrat_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "InfoContrat");
    private final static QName _ConsulterContratGeneralesFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ConsulterContratGeneralesFull");
    private final static QName _ContratIndiv_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ContratIndiv");
    private final static QName _SignaletiqueSouscriptPM_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "SignaletiqueSouscriptPM");
    private final static QName _SignaletiqueSouscriptPP_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "SignaletiqueSouscriptPP");
    private final static QName _CategPersonnel_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "CategPersonnel");
    private final static QName _Cotis_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Cotis");
    private final static QName _ContratCollAdherente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ContratCollAdherente");
    private final static QName _IdentSiloAssurAdd_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "IdentSiloAssurAdd");
    private final static QName _Produit_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "Produit");
    private final static QName _ConsulterContratGeneralesFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ConsulterContratGeneralesFunc");
    private final static QName _ContratAdherente_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "ContratAdherente");
    private final static QName _AppelCotis_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "AppelCotis");
    private final static QName _SignaletiquePPAssurPrinc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "SignaletiquePPAssurPrinc");
    private final static QName _CtxType_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "CtxType");
    private final static QName _SignaletiqueAdherentePM_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", "SignaletiqueAdherentePM");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link IdentContratAdherenteType }
     * 
     */
    public IdentContratAdherenteType createIdentContratAdherenteType() {
        return new IdentContratAdherenteType();
    }

    /**
     * Create an instance of {@link IdentSiloType }
     * 
     */
    public IdentSiloType createIdentSiloType() {
        return new IdentSiloType();
    }

    /**
     * Create an instance of {@link CategPersonnelAdherenteType }
     * 
     */
    public CategPersonnelAdherenteType createCategPersonnelAdherenteType() {
        return new CategPersonnelAdherenteType();
    }

    /**
     * Create an instance of {@link EchPaiementPrimeType }
     * 
     */
    public EchPaiementPrimeType createEchPaiementPrimeType() {
        return new EchPaiementPrimeType();
    }

    /**
     * Create an instance of {@link ActeurContratType }
     * 
     */
    public ActeurContratType createActeurContratType() {
        return new ActeurContratType();
    }

    /**
     * Create an instance of {@link IdSiloType }
     * 
     */
    public IdSiloType createIdSiloType() {
        return new IdSiloType();
    }

    /**
     * Create an instance of {@link SignaletiquePPAssurPrincType }
     * 
     */
    public SignaletiquePPAssurPrincType createSignaletiquePPAssurPrincType() {
        return new SignaletiquePPAssurPrincType();
    }

    /**
     * Create an instance of {@link AffilContratType }
     * 
     */
    public AffilContratType createAffilContratType() {
        return new AffilContratType();
    }

    /**
     * Create an instance of {@link IdentContratType }
     * 
     */
    public IdentContratType createIdentContratType() {
        return new IdentContratType();
    }

    /**
     * Create an instance of {@link SouscripteursType }
     * 
     */
    public SouscripteursType createSouscripteursType() {
        return new SouscripteursType();
    }

    /**
     * Create an instance of {@link ContratCatPersType }
     * 
     */
    public ContratCatPersType createContratCatPersType() {
        return new ContratCatPersType();
    }

    /**
     * Create an instance of {@link CtxTypeType }
     * 
     */
    public CtxTypeType createCtxTypeType() {
        return new CtxTypeType();
    }

    /**
     * Create an instance of {@link InfoContratType }
     * 
     */
    public InfoContratType createInfoContratType() {
        return new InfoContratType();
    }

    /**
     * Create an instance of {@link IdentContratPereType }
     * 
     */
    public IdentContratPereType createIdentContratPereType() {
        return new IdentContratPereType();
    }

    /**
     * Create an instance of {@link SignaletiqueAdherentePMType }
     * 
     */
    public SignaletiqueAdherentePMType createSignaletiqueAdherentePMType() {
        return new SignaletiqueAdherentePMType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesFullType }
     * 
     */
    public ConsulterContratGeneralesFullType createConsulterContratGeneralesFullType() {
        return new ConsulterContratGeneralesFullType();
    }

    /**
     * Create an instance of {@link ContratIndivType }
     * 
     */
    public ContratIndivType createContratIndivType() {
        return new ContratIndivType();
    }

    /**
     * Create an instance of {@link AssurePrincipalType }
     * 
     */
    public AssurePrincipalType createAssurePrincipalType() {
        return new AssurePrincipalType();
    }

    /**
     * Create an instance of {@link ContratAdherenteType }
     * 
     */
    public ContratAdherenteType createContratAdherenteType() {
        return new ContratAdherenteType();
    }

    /**
     * Create an instance of {@link OffreCommSouscriteType }
     * 
     */
    public OffreCommSouscriteType createOffreCommSouscriteType() {
        return new OffreCommSouscriteType();
    }

    /**
     * Create an instance of {@link ContratCollType }
     * 
     */
    public ContratCollType createContratCollType() {
        return new ContratCollType();
    }

    /**
     * Create an instance of {@link SignaletiquePPAssurAddType }
     * 
     */
    public SignaletiquePPAssurAddType createSignaletiquePPAssurAddType() {
        return new SignaletiquePPAssurAddType();
    }

    /**
     * Create an instance of {@link AppelCotisType }
     * 
     */
    public AppelCotisType createAppelCotisType() {
        return new AppelCotisType();
    }

    /**
     * Create an instance of {@link IdentDansSiloType }
     * 
     */
    public IdentDansSiloType createIdentDansSiloType() {
        return new IdentDansSiloType();
    }

    /**
     * Create an instance of {@link ActivitePartnrtType }
     * 
     */
    public ActivitePartnrtType createActivitePartnrtType() {
        return new ActivitePartnrtType();
    }

    /**
     * Create an instance of {@link ProduitType }
     * 
     */
    public ProduitType createProduitType() {
        return new ProduitType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesFuncType }
     * 
     */
    public ConsulterContratGeneralesFuncType createConsulterContratGeneralesFuncType() {
        return new ConsulterContratGeneralesFuncType();
    }

    /**
     * Create an instance of {@link StructOrgaType }
     * 
     */
    public StructOrgaType createStructOrgaType() {
        return new StructOrgaType();
    }

    /**
     * Create an instance of {@link VenteType }
     * 
     */
    public VenteType createVenteType() {
        return new VenteType();
    }

    /**
     * Create an instance of {@link OptContratEpargneType }
     * 
     */
    public OptContratEpargneType createOptContratEpargneType() {
        return new OptContratEpargneType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesType }
     * 
     */
    public ConsulterContratGeneralesType createConsulterContratGeneralesType() {
        return new ConsulterContratGeneralesType();
    }

    /**
     * Create an instance of {@link ProduitSupType }
     * 
     */
    public ProduitSupType createProduitSupType() {
        return new ProduitSupType();
    }

    /**
     * Create an instance of {@link SignaletiquePMType }
     * 
     */
    public SignaletiquePMType createSignaletiquePMType() {
        return new SignaletiquePMType();
    }

    /**
     * Create an instance of {@link SignaletiquePPType }
     * 
     */
    public SignaletiquePPType createSignaletiquePPType() {
        return new SignaletiquePPType();
    }

    /**
     * Create an instance of {@link TrsfCtrType }
     * 
     */
    public TrsfCtrType createTrsfCtrType() {
        return new TrsfCtrType();
    }

    /**
     * Create an instance of {@link RibType }
     * 
     */
    public RibType createRibType() {
        return new RibType();
    }

    /**
     * Create an instance of {@link CategPersonnelType }
     * 
     */
    public CategPersonnelType createCategPersonnelType() {
        return new CategPersonnelType();
    }

    /**
     * Create an instance of {@link AdhesionType }
     * 
     */
    public AdhesionType createAdhesionType() {
        return new AdhesionType();
    }

    /**
     * Create an instance of {@link GarSouscritesType }
     * 
     */
    public GarSouscritesType createGarSouscritesType() {
        return new GarSouscritesType();
    }

    /**
     * Create an instance of {@link AssureAdditionnelsType }
     * 
     */
    public AssureAdditionnelsType createAssureAdditionnelsType() {
        return new AssureAdditionnelsType();
    }

    /**
     * Create an instance of {@link ConsulterContratGeneralesResponseType }
     * 
     */
    public ConsulterContratGeneralesResponseType createConsulterContratGeneralesResponseType() {
        return new ConsulterContratGeneralesResponseType();
    }

    /**
     * Create an instance of {@link CotisType }
     * 
     */
    public CotisType createCotisType() {
        return new CotisType();
    }

    /**
     * Create an instance of {@link IdentsPereType }
     * 
     */
    public IdentsPereType createIdentsPereType() {
        return new IdentsPereType();
    }

    /**
     * Create an instance of {@link LibClauseType }
     * 
     */
    public LibClauseType createLibClauseType() {
        return new LibClauseType();
    }

    /**
     * Create an instance of {@link ContratType }
     * 
     */
    public ContratType createContratType() {
        return new ContratType();
    }

    /**
     * Create an instance of {@link ContratCollAdherenteType }
     * 
     */
    public ContratCollAdherenteType createContratCollAdherenteType() {
        return new ContratCollAdherenteType();
    }

    /**
     * Create an instance of {@link GestType }
     * 
     */
    public GestType createGestType() {
        return new GestType();
    }

    /**
     * Create an instance of {@link OfrCialSouscType }
     * 
     */
    public OfrCialSouscType createOfrCialSouscType() {
        return new OfrCialSouscType();
    }

    /**
     * Create an instance of {@link InfoContratEffetType }
     * 
     */
    public InfoContratEffetType createInfoContratEffetType() {
        return new InfoContratEffetType();
    }

    /**
     * Create an instance of {@link IdentOfrSoustnType }
     * 
     */
    public IdentOfrSoustnType createIdentOfrSoustnType() {
        return new IdentOfrSoustnType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduitSupType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Pdt")
    public JAXBElement<ProduitSupType> createPdt(ProduitSupType value) {
        return new JAXBElement<ProduitSupType>(_Pdt_QNAME, ProduitSupType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RibType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Rib")
    public JAXBElement<RibType> createRib(RibType value) {
        return new JAXBElement<RibType>(_Rib_QNAME, RibType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ConsulterContratGeneralesResponse")
    public JAXBElement<ConsulterContratGeneralesResponseType> createConsulterContratGeneralesResponse(ConsulterContratGeneralesResponseType value) {
        return new JAXBElement<ConsulterContratGeneralesResponseType>(_ConsulterContratGeneralesResponse_QNAME, ConsulterContratGeneralesResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentsPereType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentsPere")
    public JAXBElement<IdentsPereType> createIdentsPere(IdentsPereType value) {
        return new JAXBElement<IdentsPereType>(_IdentsPere_QNAME, IdentsPereType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentDansSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSilo")
    public JAXBElement<IdentDansSiloType> createIdentSilo(IdentDansSiloType value) {
        return new JAXBElement<IdentDansSiloType>(_IdentSilo_QNAME, IdentDansSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VenteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Vente")
    public JAXBElement<VenteType> createVente(VenteType value) {
        return new JAXBElement<VenteType>(_Vente_QNAME, VenteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratCollType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ContratColl")
    public JAXBElement<ContratCollType> createContratColl(ContratCollType value) {
        return new JAXBElement<ContratCollType>(_ContratColl_QNAME, ContratCollType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiquePPAssurAddType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "SignaletiquePPAssurAdd")
    public JAXBElement<SignaletiquePPAssurAddType> createSignaletiquePPAssurAdd(SignaletiquePPAssurAddType value) {
        return new JAXBElement<SignaletiquePPAssurAddType>(_SignaletiquePPAssurAdd_QNAME, SignaletiquePPAssurAddType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSiloSouscript")
    public JAXBElement<IdentSiloType> createIdentSiloSouscript(IdentSiloType value) {
        return new JAXBElement<IdentSiloType>(_IdentSiloSouscript_QNAME, IdentSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EchPaiementPrimeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "EchPaiementPrime")
    public JAXBElement<EchPaiementPrimeType> createEchPaiementPrime(EchPaiementPrimeType value) {
        return new JAXBElement<EchPaiementPrimeType>(_EchPaiementPrime_QNAME, EchPaiementPrimeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActeurContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ActeurContrat")
    public JAXBElement<ActeurContratType> createActeurContrat(ActeurContratType value) {
        return new JAXBElement<ActeurContratType>(_ActeurContrat_QNAME, ActeurContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentContrat")
    public JAXBElement<IdentContratType> createIdentContrat(IdentContratType value) {
        return new JAXBElement<IdentContratType>(_IdentContrat_QNAME, IdentContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SouscripteursType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Souscripteurs")
    public JAXBElement<SouscripteursType> createSouscripteurs(SouscripteursType value) {
        return new JAXBElement<SouscripteursType>(_Souscripteurs_QNAME, SouscripteursType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ConsulterContratGenerales")
    public JAXBElement<ConsulterContratGeneralesType> createConsulterContratGenerales(ConsulterContratGeneralesType value) {
        return new JAXBElement<ConsulterContratGeneralesType>(_ConsulterContratGenerales_QNAME, ConsulterContratGeneralesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TrsfCtrType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "TrsfCtr")
    public JAXBElement<TrsfCtrType> createTrsfCtr(TrsfCtrType value) {
        return new JAXBElement<TrsfCtrType>(_TrsfCtr_QNAME, TrsfCtrType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AdhesionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Adhesion")
    public JAXBElement<AdhesionType> createAdhesion(AdhesionType value) {
        return new JAXBElement<AdhesionType>(_Adhesion_QNAME, AdhesionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssureAdditionnelsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "AssureAdditionnels")
    public JAXBElement<AssureAdditionnelsType> createAssureAdditionnels(AssureAdditionnelsType value) {
        return new JAXBElement<AssureAdditionnelsType>(_AssureAdditionnels_QNAME, AssureAdditionnelsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LibClauseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "LibClause")
    public JAXBElement<LibClauseType> createLibClause(LibClauseType value) {
        return new JAXBElement<LibClauseType>(_LibClause_QNAME, LibClauseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSiloContrat")
    public JAXBElement<IdentSiloType> createIdentSiloContrat(IdentSiloType value) {
        return new JAXBElement<IdentSiloType>(_IdentSiloContrat_QNAME, IdentSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Contrat")
    public JAXBElement<ContratType> createContrat(ContratType value) {
        return new JAXBElement<ContratType>(_Contrat_QNAME, ContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StructOrgaType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "StructOrga")
    public JAXBElement<StructOrgaType> createStructOrga(StructOrgaType value) {
        return new JAXBElement<StructOrgaType>(_StructOrga_QNAME, StructOrgaType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssurePrincipalType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "AssurePrincipal")
    public JAXBElement<AssurePrincipalType> createAssurePrincipal(AssurePrincipalType value) {
        return new JAXBElement<AssurePrincipalType>(_AssurePrincipal_QNAME, AssurePrincipalType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OffreCommSouscriteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "OffreCommSouscrite")
    public JAXBElement<OffreCommSouscriteType> createOffreCommSouscrite(OffreCommSouscriteType value) {
        return new JAXBElement<OffreCommSouscriteType>(_OffreCommSouscrite_QNAME, OffreCommSouscriteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentContratAdherenteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentContratAdherente")
    public JAXBElement<IdentContratAdherenteType> createIdentContratAdherente(IdentContratAdherenteType value) {
        return new JAXBElement<IdentContratAdherenteType>(_IdentContratAdherente_QNAME, IdentContratAdherenteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSiloAdherente")
    public JAXBElement<IdentSiloType> createIdentSiloAdherente(IdentSiloType value) {
        return new JAXBElement<IdentSiloType>(_IdentSiloAdherente_QNAME, IdentSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdSilo")
    public JAXBElement<IdSiloType> createIdSilo(IdSiloType value) {
        return new JAXBElement<IdSiloType>(_IdSilo_QNAME, IdSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AffilContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "AffilContrat")
    public JAXBElement<AffilContratType> createAffilContrat(AffilContratType value) {
        return new JAXBElement<AffilContratType>(_AffilContrat_QNAME, AffilContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratCatPersType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ContratCatPers")
    public JAXBElement<ContratCatPersType> createContratCatPers(ContratCatPersType value) {
        return new JAXBElement<ContratCatPersType>(_ContratCatPers_QNAME, ContratCatPersType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentContratPereType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentContratPere")
    public JAXBElement<IdentContratPereType> createIdentContratPere(IdentContratPereType value) {
        return new JAXBElement<IdentContratPereType>(_IdentContratPere_QNAME, IdentContratPereType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GarSouscritesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "GarSouscrites")
    public JAXBElement<GarSouscritesType> createGarSouscrites(GarSouscritesType value) {
        return new JAXBElement<GarSouscritesType>(_GarSouscrites_QNAME, GarSouscritesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Gest")
    public JAXBElement<GestType> createGest(GestType value) {
        return new JAXBElement<GestType>(_Gest_QNAME, GestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ActivitePartnrtType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ActivitePartnrt")
    public JAXBElement<ActivitePartnrtType> createActivitePartnrt(ActivitePartnrtType value) {
        return new JAXBElement<ActivitePartnrtType>(_ActivitePartnrt_QNAME, ActivitePartnrtType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSiloAssurPrinc")
    public JAXBElement<IdentSiloType> createIdentSiloAssurPrinc(IdentSiloType value) {
        return new JAXBElement<IdentSiloType>(_IdentSiloAssurPrinc_QNAME, IdentSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OptContratEpargneType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "OptContratEpargne")
    public JAXBElement<OptContratEpargneType> createOptContratEpargne(OptContratEpargneType value) {
        return new JAXBElement<OptContratEpargneType>(_OptContratEpargne_QNAME, OptContratEpargneType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CategPersonnelAdherenteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "CategPersonnelAdherente")
    public JAXBElement<CategPersonnelAdherenteType> createCategPersonnelAdherente(CategPersonnelAdherenteType value) {
        return new JAXBElement<CategPersonnelAdherenteType>(_CategPersonnelAdherente_QNAME, CategPersonnelAdherenteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InfoContratType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "InfoContrat")
    public JAXBElement<InfoContratType> createInfoContrat(InfoContratType value) {
        return new JAXBElement<InfoContratType>(_InfoContrat_QNAME, InfoContratType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ConsulterContratGeneralesFull")
    public JAXBElement<ConsulterContratGeneralesFullType> createConsulterContratGeneralesFull(ConsulterContratGeneralesFullType value) {
        return new JAXBElement<ConsulterContratGeneralesFullType>(_ConsulterContratGeneralesFull_QNAME, ConsulterContratGeneralesFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratIndivType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ContratIndiv")
    public JAXBElement<ContratIndivType> createContratIndiv(ContratIndivType value) {
        return new JAXBElement<ContratIndivType>(_ContratIndiv_QNAME, ContratIndivType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiquePMType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "SignaletiqueSouscriptPM")
    public JAXBElement<SignaletiquePMType> createSignaletiqueSouscriptPM(SignaletiquePMType value) {
        return new JAXBElement<SignaletiquePMType>(_SignaletiqueSouscriptPM_QNAME, SignaletiquePMType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiquePPType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "SignaletiqueSouscriptPP")
    public JAXBElement<SignaletiquePPType> createSignaletiqueSouscriptPP(SignaletiquePPType value) {
        return new JAXBElement<SignaletiquePPType>(_SignaletiqueSouscriptPP_QNAME, SignaletiquePPType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CategPersonnelType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "CategPersonnel")
    public JAXBElement<CategPersonnelType> createCategPersonnel(CategPersonnelType value) {
        return new JAXBElement<CategPersonnelType>(_CategPersonnel_QNAME, CategPersonnelType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CotisType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Cotis")
    public JAXBElement<CotisType> createCotis(CotisType value) {
        return new JAXBElement<CotisType>(_Cotis_QNAME, CotisType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratCollAdherenteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ContratCollAdherente")
    public JAXBElement<ContratCollAdherenteType> createContratCollAdherente(ContratCollAdherenteType value) {
        return new JAXBElement<ContratCollAdherenteType>(_ContratCollAdherente_QNAME, ContratCollAdherenteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdentSiloType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "IdentSiloAssurAdd")
    public JAXBElement<IdentSiloType> createIdentSiloAssurAdd(IdentSiloType value) {
        return new JAXBElement<IdentSiloType>(_IdentSiloAssurAdd_QNAME, IdentSiloType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProduitType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "Produit")
    public JAXBElement<ProduitType> createProduit(ProduitType value) {
        return new JAXBElement<ProduitType>(_Produit_QNAME, ProduitType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ConsulterContratGeneralesFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ConsulterContratGeneralesFunc")
    public JAXBElement<ConsulterContratGeneralesFuncType> createConsulterContratGeneralesFunc(ConsulterContratGeneralesFuncType value) {
        return new JAXBElement<ConsulterContratGeneralesFuncType>(_ConsulterContratGeneralesFunc_QNAME, ConsulterContratGeneralesFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ContratAdherenteType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "ContratAdherente")
    public JAXBElement<ContratAdherenteType> createContratAdherente(ContratAdherenteType value) {
        return new JAXBElement<ContratAdherenteType>(_ContratAdherente_QNAME, ContratAdherenteType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AppelCotisType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "AppelCotis")
    public JAXBElement<AppelCotisType> createAppelCotis(AppelCotisType value) {
        return new JAXBElement<AppelCotisType>(_AppelCotis_QNAME, AppelCotisType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiquePPAssurPrincType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "SignaletiquePPAssurPrinc")
    public JAXBElement<SignaletiquePPAssurPrincType> createSignaletiquePPAssurPrinc(SignaletiquePPAssurPrincType value) {
        return new JAXBElement<SignaletiquePPAssurPrincType>(_SignaletiquePPAssurPrinc_QNAME, SignaletiquePPAssurPrincType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CtxTypeType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "CtxType")
    public JAXBElement<CtxTypeType> createCtxType(CtxTypeType value) {
        return new JAXBElement<CtxTypeType>(_CtxType_QNAME, CtxTypeType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SignaletiqueAdherentePMType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2", name = "SignaletiqueAdherentePM")
    public JAXBElement<SignaletiqueAdherentePMType> createSignaletiqueAdherentePM(SignaletiqueAdherentePMType value) {
        return new JAXBElement<SignaletiqueAdherentePMType>(_SignaletiqueAdherentePM_QNAME, SignaletiqueAdherentePMType.class, null, value);
    }

}
