
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour CategPersonnelType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CategPersonnelType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeTrsJustifSante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeTrsJustifSante" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeTrsJustifSanteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeTrsJustifSanteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeAffiliation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeAffiliation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModeAffiliationSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModeAffiliationSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModePortabilite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModePortabilite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeModePortabiliteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libModePortabiliteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSitCategPersSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateEffetCategPers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="libSitCategPers" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSitCategPersSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateSitCategPers" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codePopulation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPopulation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeNonGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNonGest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="Pdt" type="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ProduitType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}GarSouscrites" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratGenerales_2}ContratCatPers" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CategPersonnelType", propOrder = {
    "idCategPers",
    "codeCategPers",
    "libCategPers",
    "codeModeTrsJustifSante",
    "libModeTrsJustifSante",
    "codeModeTrsJustifSanteSilo",
    "libModeTrsJustifSanteSilo",
    "codeModeAffiliation",
    "libModeAffiliation",
    "codeModeAffiliationSilo",
    "libModeAffiliationSilo",
    "codeModePortabilite",
    "libModePortabilite",
    "codeModePortabiliteSilo",
    "libModePortabiliteSilo",
    "codeSitCategPers",
    "codeSitCategPersSilo",
    "dateEffetCategPers",
    "libSitCategPers",
    "libSitCategPersSilo",
    "dateSitCategPers",
    "codePopulation",
    "libPopulation",
    "codeNonGest",
    "libNonGest",
    "pdt",
    "garSouscrites",
    "contratCatPers"
})
public class CategPersonnelType {

    protected String idCategPers;
    protected String codeCategPers;
    protected String libCategPers;
    protected String codeModeTrsJustifSante;
    protected String libModeTrsJustifSante;
    protected String codeModeTrsJustifSanteSilo;
    protected String libModeTrsJustifSanteSilo;
    protected String codeModeAffiliation;
    protected String libModeAffiliation;
    protected String codeModeAffiliationSilo;
    protected String libModeAffiliationSilo;
    protected String codeModePortabilite;
    protected String libModePortabilite;
    protected String codeModePortabiliteSilo;
    protected String libModePortabiliteSilo;
    protected String codeSitCategPers;
    protected String codeSitCategPersSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateEffetCategPers;
    protected String libSitCategPers;
    protected String libSitCategPersSilo;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateSitCategPers;
    protected String codePopulation;
    protected String libPopulation;
    protected String codeNonGest;
    protected String libNonGest;
    @XmlElement(name = "Pdt")
    protected List<ProduitType> pdt;
    @XmlElement(name = "GarSouscrites")
    protected List<GarSouscritesType> garSouscrites;
    @XmlElement(name = "ContratCatPers")
    protected ContratCatPersType contratCatPers;

    /**
     * Obtient la valeur de la propriété idCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdCategPers() {
        return idCategPers;
    }

    /**
     * Définit la valeur de la propriété idCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdCategPers(String value) {
        this.idCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeCategPers() {
        return codeCategPers;
    }

    /**
     * Définit la valeur de la propriété codeCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeCategPers(String value) {
        this.codeCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCategPers() {
        return libCategPers;
    }

    /**
     * Définit la valeur de la propriété libCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCategPers(String value) {
        this.libCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeTrsJustifSante.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeTrsJustifSante() {
        return codeModeTrsJustifSante;
    }

    /**
     * Définit la valeur de la propriété codeModeTrsJustifSante.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeTrsJustifSante(String value) {
        this.codeModeTrsJustifSante = value;
    }

    /**
     * Obtient la valeur de la propriété libModeTrsJustifSante.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeTrsJustifSante() {
        return libModeTrsJustifSante;
    }

    /**
     * Définit la valeur de la propriété libModeTrsJustifSante.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeTrsJustifSante(String value) {
        this.libModeTrsJustifSante = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeTrsJustifSanteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeTrsJustifSanteSilo() {
        return codeModeTrsJustifSanteSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeTrsJustifSanteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeTrsJustifSanteSilo(String value) {
        this.codeModeTrsJustifSanteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeTrsJustifSanteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeTrsJustifSanteSilo() {
        return libModeTrsJustifSanteSilo;
    }

    /**
     * Définit la valeur de la propriété libModeTrsJustifSanteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeTrsJustifSanteSilo(String value) {
        this.libModeTrsJustifSanteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeAffiliation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeAffiliation() {
        return codeModeAffiliation;
    }

    /**
     * Définit la valeur de la propriété codeModeAffiliation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeAffiliation(String value) {
        this.codeModeAffiliation = value;
    }

    /**
     * Obtient la valeur de la propriété libModeAffiliation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeAffiliation() {
        return libModeAffiliation;
    }

    /**
     * Définit la valeur de la propriété libModeAffiliation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeAffiliation(String value) {
        this.libModeAffiliation = value;
    }

    /**
     * Obtient la valeur de la propriété codeModeAffiliationSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModeAffiliationSilo() {
        return codeModeAffiliationSilo;
    }

    /**
     * Définit la valeur de la propriété codeModeAffiliationSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModeAffiliationSilo(String value) {
        this.codeModeAffiliationSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModeAffiliationSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModeAffiliationSilo() {
        return libModeAffiliationSilo;
    }

    /**
     * Définit la valeur de la propriété libModeAffiliationSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModeAffiliationSilo(String value) {
        this.libModeAffiliationSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeModePortabilite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModePortabilite() {
        return codeModePortabilite;
    }

    /**
     * Définit la valeur de la propriété codeModePortabilite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModePortabilite(String value) {
        this.codeModePortabilite = value;
    }

    /**
     * Obtient la valeur de la propriété libModePortabilite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModePortabilite() {
        return libModePortabilite;
    }

    /**
     * Définit la valeur de la propriété libModePortabilite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModePortabilite(String value) {
        this.libModePortabilite = value;
    }

    /**
     * Obtient la valeur de la propriété codeModePortabiliteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeModePortabiliteSilo() {
        return codeModePortabiliteSilo;
    }

    /**
     * Définit la valeur de la propriété codeModePortabiliteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeModePortabiliteSilo(String value) {
        this.codeModePortabiliteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libModePortabiliteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibModePortabiliteSilo() {
        return libModePortabiliteSilo;
    }

    /**
     * Définit la valeur de la propriété libModePortabiliteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibModePortabiliteSilo(String value) {
        this.libModePortabiliteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCategPers() {
        return codeSitCategPers;
    }

    /**
     * Définit la valeur de la propriété codeSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCategPers(String value) {
        this.codeSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codeSitCategPersSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSitCategPersSilo() {
        return codeSitCategPersSilo;
    }

    /**
     * Définit la valeur de la propriété codeSitCategPersSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSitCategPersSilo(String value) {
        this.codeSitCategPersSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateEffetCategPers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateEffetCategPers() {
        return dateEffetCategPers;
    }

    /**
     * Définit la valeur de la propriété dateEffetCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateEffetCategPers(XMLGregorianCalendar value) {
        this.dateEffetCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCategPers() {
        return libSitCategPers;
    }

    /**
     * Définit la valeur de la propriété libSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCategPers(String value) {
        this.libSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété libSitCategPersSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSitCategPersSilo() {
        return libSitCategPersSilo;
    }

    /**
     * Définit la valeur de la propriété libSitCategPersSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSitCategPersSilo(String value) {
        this.libSitCategPersSilo = value;
    }

    /**
     * Obtient la valeur de la propriété dateSitCategPers.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateSitCategPers() {
        return dateSitCategPers;
    }

    /**
     * Définit la valeur de la propriété dateSitCategPers.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateSitCategPers(XMLGregorianCalendar value) {
        this.dateSitCategPers = value;
    }

    /**
     * Obtient la valeur de la propriété codePopulation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePopulation() {
        return codePopulation;
    }

    /**
     * Définit la valeur de la propriété codePopulation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePopulation(String value) {
        this.codePopulation = value;
    }

    /**
     * Obtient la valeur de la propriété libPopulation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPopulation() {
        return libPopulation;
    }

    /**
     * Définit la valeur de la propriété libPopulation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPopulation(String value) {
        this.libPopulation = value;
    }

    /**
     * Obtient la valeur de la propriété codeNonGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNonGest() {
        return codeNonGest;
    }

    /**
     * Définit la valeur de la propriété codeNonGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNonGest(String value) {
        this.codeNonGest = value;
    }

    /**
     * Obtient la valeur de la propriété libNonGest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNonGest() {
        return libNonGest;
    }

    /**
     * Définit la valeur de la propriété libNonGest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNonGest(String value) {
        this.libNonGest = value;
    }

    /**
     * Gets the value of the pdt property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the pdt property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPdt().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProduitType }
     * 
     * 
     */
    public List<ProduitType> getPdt() {
        if (pdt == null) {
            pdt = new ArrayList<ProduitType>();
        }
        return this.pdt;
    }

    /**
     * Gets the value of the garSouscrites property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the garSouscrites property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getGarSouscrites().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link GarSouscritesType }
     * 
     * 
     */
    public List<GarSouscritesType> getGarSouscrites() {
        if (garSouscrites == null) {
            garSouscrites = new ArrayList<GarSouscritesType>();
        }
        return this.garSouscrites;
    }

    /**
     * Obtient la valeur de la propriété contratCatPers.
     * 
     * @return
     *     possible object is
     *     {@link ContratCatPersType }
     *     
     */
    public ContratCatPersType getContratCatPers() {
        return contratCatPers;
    }

    /**
     * Définit la valeur de la propriété contratCatPers.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratCatPersType }
     *     
     */
    public void setContratCatPers(ContratCatPersType value) {
        this.contratCatPers = value;
    }

}
