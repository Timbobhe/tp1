
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentsPereType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentsPereType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="valeurId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeId" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentsPereType", propOrder = {
    "valeurId",
    "typeId"
})
public class IdentsPereType {

    @XmlElement(required = true)
    protected String valeurId;
    @XmlElement(required = true)
    protected String typeId;

    /**
     * Obtient la valeur de la propriété valeurId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValeurId() {
        return valeurId;
    }

    /**
     * Définit la valeur de la propriété valeurId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValeurId(String value) {
        this.valeurId = value;
    }

    /**
     * Obtient la valeur de la propriété typeId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * Définit la valeur de la propriété typeId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeId(String value) {
        this.typeId = value;
    }

}
