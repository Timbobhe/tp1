
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour OfrCialSousc2Type complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="OfrCialSousc2Type">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeOfrCial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libOfrCial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeTypeCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="numGenCtr" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="IdOfrSousctn" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}IdOfrSousctnType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OfrCialSousc2Type", propOrder = {
    "codeOfrCial",
    "libOfrCial",
    "codeTypeCtr",
    "numGenCtr",
    "idOfrSousctn"
})
public class OfrCialSousc2Type {

    protected String codeOfrCial;
    protected String libOfrCial;
    protected String codeTypeCtr;
    protected String numGenCtr;
    @XmlElement(name = "IdOfrSousctn")
    protected IdOfrSousctnType idOfrSousctn;

    /**
     * Obtient la valeur de la propriété codeOfrCial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeOfrCial() {
        return codeOfrCial;
    }

    /**
     * Définit la valeur de la propriété codeOfrCial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeOfrCial(String value) {
        this.codeOfrCial = value;
    }

    /**
     * Obtient la valeur de la propriété libOfrCial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibOfrCial() {
        return libOfrCial;
    }

    /**
     * Définit la valeur de la propriété libOfrCial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibOfrCial(String value) {
        this.libOfrCial = value;
    }

    /**
     * Obtient la valeur de la propriété codeTypeCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeTypeCtr() {
        return codeTypeCtr;
    }

    /**
     * Définit la valeur de la propriété codeTypeCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeTypeCtr(String value) {
        this.codeTypeCtr = value;
    }

    /**
     * Obtient la valeur de la propriété numGenCtr.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumGenCtr() {
        return numGenCtr;
    }

    /**
     * Définit la valeur de la propriété numGenCtr.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumGenCtr(String value) {
        this.numGenCtr = value;
    }

    /**
     * Obtient la valeur de la propriété idOfrSousctn.
     * 
     * @return
     *     possible object is
     *     {@link IdOfrSousctnType }
     *     
     */
    public IdOfrSousctnType getIdOfrSousctn() {
        return idOfrSousctn;
    }

    /**
     * Définit la valeur de la propriété idOfrSousctn.
     * 
     * @param value
     *     allowed object is
     *     {@link IdOfrSousctnType }
     *     
     */
    public void setIdOfrSousctn(IdOfrSousctnType value) {
        this.idOfrSousctn = value;
    }

}
