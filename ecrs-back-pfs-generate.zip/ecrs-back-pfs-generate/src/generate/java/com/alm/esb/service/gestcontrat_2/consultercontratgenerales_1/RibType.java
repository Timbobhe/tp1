
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RibType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RibType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="numCompte" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libCompte" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEtablissement" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeGuichet" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RibType", propOrder = {
    "numCompte",
    "libCompte",
    "codeEtablissement",
    "codeGuichet",
    "cle"
})
public class RibType {

    protected String numCompte;
    protected String libCompte;
    protected String codeEtablissement;
    protected String codeGuichet;
    protected String cle;

    /**
     * Obtient la valeur de la propriété numCompte.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNumCompte() {
        return numCompte;
    }

    /**
     * Définit la valeur de la propriété numCompte.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNumCompte(String value) {
        this.numCompte = value;
    }

    /**
     * Obtient la valeur de la propriété libCompte.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibCompte() {
        return libCompte;
    }

    /**
     * Définit la valeur de la propriété libCompte.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibCompte(String value) {
        this.libCompte = value;
    }

    /**
     * Obtient la valeur de la propriété codeEtablissement.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEtablissement() {
        return codeEtablissement;
    }

    /**
     * Définit la valeur de la propriété codeEtablissement.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEtablissement(String value) {
        this.codeEtablissement = value;
    }

    /**
     * Obtient la valeur de la propriété codeGuichet.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeGuichet() {
        return codeGuichet;
    }

    /**
     * Définit la valeur de la propriété codeGuichet.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeGuichet(String value) {
        this.codeGuichet = value;
    }

    /**
     * Obtient la valeur de la propriété cle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCle() {
        return cle;
    }

    /**
     * Définit la valeur de la propriété cle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCle(String value) {
        this.cle = value;
    }

}
