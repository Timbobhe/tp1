
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour EcheancierPaiementPrimeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="EcheancierPaiementPrimeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codePeriodicite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriodicite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEcheancePaiementCotisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEcheancePaiementCotisation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EcheancierPaiementPrimeType", propOrder = {
    "codePeriodicite",
    "libPeriodicite",
    "codeEcheancePaiementCotisation",
    "libEcheancePaiementCotisation"
})
public class EcheancierPaiementPrimeType {

    protected String codePeriodicite;
    protected String libPeriodicite;
    protected String codeEcheancePaiementCotisation;
    protected String libEcheancePaiementCotisation;

    /**
     * Obtient la valeur de la propriété codePeriodicite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodicite() {
        return codePeriodicite;
    }

    /**
     * Définit la valeur de la propriété codePeriodicite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodicite(String value) {
        this.codePeriodicite = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriodicite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriodicite() {
        return libPeriodicite;
    }

    /**
     * Définit la valeur de la propriété libPeriodicite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriodicite(String value) {
        this.libPeriodicite = value;
    }

    /**
     * Obtient la valeur de la propriété codeEcheancePaiementCotisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEcheancePaiementCotisation() {
        return codeEcheancePaiementCotisation;
    }

    /**
     * Définit la valeur de la propriété codeEcheancePaiementCotisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEcheancePaiementCotisation(String value) {
        this.codeEcheancePaiementCotisation = value;
    }

    /**
     * Obtient la valeur de la propriété libEcheancePaiementCotisation.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEcheancePaiementCotisation() {
        return libEcheancePaiementCotisation;
    }

    /**
     * Définit la valeur de la propriété libEcheancePaiementCotisation.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEcheancePaiementCotisation(String value) {
        this.libEcheancePaiementCotisation = value;
    }

}
