
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour DivisionRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="DivisionRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codeDivisionRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libelleDivisionRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="MajorationRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}MajrtRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="RevalorisationRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}RevaloRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="AnnuiteRente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}AnnuiteRenteType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DivisionRenteType", propOrder = {
    "codeDivisionRente",
    "libelleDivisionRente",
    "majorationRente",
    "revalorisationRente",
    "annuiteRente"
})
public class DivisionRenteType {

    protected String codeDivisionRente;
    protected String libelleDivisionRente;
    @XmlElement(name = "MajorationRente")
    protected List<MajrtRenteType> majorationRente;
    @XmlElement(name = "RevalorisationRente")
    protected List<RevaloRenteType> revalorisationRente;
    @XmlElement(name = "AnnuiteRente")
    protected List<AnnuiteRenteType> annuiteRente;

    /**
     * Obtient la valeur de la propriété codeDivisionRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDivisionRente() {
        return codeDivisionRente;
    }

    /**
     * Définit la valeur de la propriété codeDivisionRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDivisionRente(String value) {
        this.codeDivisionRente = value;
    }

    /**
     * Obtient la valeur de la propriété libelleDivisionRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleDivisionRente() {
        return libelleDivisionRente;
    }

    /**
     * Définit la valeur de la propriété libelleDivisionRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleDivisionRente(String value) {
        this.libelleDivisionRente = value;
    }

    /**
     * Gets the value of the majorationRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the majorationRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getMajorationRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link MajrtRenteType }
     * 
     * 
     */
    public List<MajrtRenteType> getMajorationRente() {
        if (majorationRente == null) {
            majorationRente = new ArrayList<MajrtRenteType>();
        }
        return this.majorationRente;
    }

    /**
     * Gets the value of the revalorisationRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the revalorisationRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRevalorisationRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RevaloRenteType }
     * 
     * 
     */
    public List<RevaloRenteType> getRevalorisationRente() {
        if (revalorisationRente == null) {
            revalorisationRente = new ArrayList<RevaloRenteType>();
        }
        return this.revalorisationRente;
    }

    /**
     * Gets the value of the annuiteRente property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the annuiteRente property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAnnuiteRente().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AnnuiteRenteType }
     * 
     * 
     */
    public List<AnnuiteRenteType> getAnnuiteRente() {
        if (annuiteRente == null) {
            annuiteRente = new ArrayList<AnnuiteRenteType>();
        }
        return this.annuiteRente;
    }

}
