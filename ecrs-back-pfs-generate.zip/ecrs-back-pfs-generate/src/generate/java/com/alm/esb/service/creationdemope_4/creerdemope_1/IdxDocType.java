
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdxDocType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdxDocType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idActrIdx" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdxDocType", propOrder = {
    "idActrIdx"
})
public class IdxDocType {

    protected String idActrIdx;

    /**
     * Obtient la valeur de la propriété idActrIdx.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdActrIdx() {
        return idActrIdx;
    }

    /**
     * Définit la valeur de la propriété idActrIdx.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdActrIdx(String value) {
        this.idActrIdx = value;
    }

}
