
package com.alm.esb.service.gestcontrat_2.consultercontratgenerales_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour EchPaiementPrimeType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="EchPaiementPrimeType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codePeriodicite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriodicite" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codePeriodiciteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPeriodiciteSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEchPaiementCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEchPaiementCotis" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEchPaiementCotisSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEchPaiementCotisSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeDevise" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="montantPrimeAnnualisee" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EchPaiementPrimeType", propOrder = {
    "codePeriodicite",
    "libPeriodicite",
    "codePeriodiciteSilo",
    "libPeriodiciteSilo",
    "codeEchPaiementCotis",
    "libEchPaiementCotis",
    "codeEchPaiementCotisSilo",
    "libEchPaiementCotisSilo",
    "codeDevise",
    "montantPrimeAnnualisee"
})
public class EchPaiementPrimeType {

    protected String codePeriodicite;
    protected String libPeriodicite;
    protected String codePeriodiciteSilo;
    protected String libPeriodiciteSilo;
    protected String codeEchPaiementCotis;
    protected String libEchPaiementCotis;
    protected String codeEchPaiementCotisSilo;
    protected String libEchPaiementCotisSilo;
    protected String codeDevise;
    protected BigDecimal montantPrimeAnnualisee;

    /**
     * Obtient la valeur de la propriété codePeriodicite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodicite() {
        return codePeriodicite;
    }

    /**
     * Définit la valeur de la propriété codePeriodicite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodicite(String value) {
        this.codePeriodicite = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriodicite.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriodicite() {
        return libPeriodicite;
    }

    /**
     * Définit la valeur de la propriété libPeriodicite.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriodicite(String value) {
        this.libPeriodicite = value;
    }

    /**
     * Obtient la valeur de la propriété codePeriodiciteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodiciteSilo() {
        return codePeriodiciteSilo;
    }

    /**
     * Définit la valeur de la propriété codePeriodiciteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodiciteSilo(String value) {
        this.codePeriodiciteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libPeriodiciteSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPeriodiciteSilo() {
        return libPeriodiciteSilo;
    }

    /**
     * Définit la valeur de la propriété libPeriodiciteSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPeriodiciteSilo(String value) {
        this.libPeriodiciteSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeEchPaiementCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEchPaiementCotis() {
        return codeEchPaiementCotis;
    }

    /**
     * Définit la valeur de la propriété codeEchPaiementCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEchPaiementCotis(String value) {
        this.codeEchPaiementCotis = value;
    }

    /**
     * Obtient la valeur de la propriété libEchPaiementCotis.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEchPaiementCotis() {
        return libEchPaiementCotis;
    }

    /**
     * Définit la valeur de la propriété libEchPaiementCotis.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEchPaiementCotis(String value) {
        this.libEchPaiementCotis = value;
    }

    /**
     * Obtient la valeur de la propriété codeEchPaiementCotisSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEchPaiementCotisSilo() {
        return codeEchPaiementCotisSilo;
    }

    /**
     * Définit la valeur de la propriété codeEchPaiementCotisSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEchPaiementCotisSilo(String value) {
        this.codeEchPaiementCotisSilo = value;
    }

    /**
     * Obtient la valeur de la propriété libEchPaiementCotisSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEchPaiementCotisSilo() {
        return libEchPaiementCotisSilo;
    }

    /**
     * Définit la valeur de la propriété libEchPaiementCotisSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEchPaiementCotisSilo(String value) {
        this.libEchPaiementCotisSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeDevise.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDevise() {
        return codeDevise;
    }

    /**
     * Définit la valeur de la propriété codeDevise.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDevise(String value) {
        this.codeDevise = value;
    }

    /**
     * Obtient la valeur de la propriété montantPrimeAnnualisee.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantPrimeAnnualisee() {
        return montantPrimeAnnualisee;
    }

    /**
     * Définit la valeur de la propriété montantPrimeAnnualisee.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantPrimeAnnualisee(BigDecimal value) {
        this.montantPrimeAnnualisee = value;
    }

}
