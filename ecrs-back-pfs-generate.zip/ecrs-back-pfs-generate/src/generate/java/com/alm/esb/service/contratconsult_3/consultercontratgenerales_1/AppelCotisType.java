
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour AppelCotisType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="AppelCotisType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="dest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="modeSupportDecl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indBlocage" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeMotifBlocage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libMotifBlocage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AppelCotisType", propOrder = {
    "dest",
    "modeSupportDecl",
    "indBlocage",
    "codeMotifBlocage",
    "libMotifBlocage"
})
public class AppelCotisType {

    protected String dest;
    protected String modeSupportDecl;
    protected Boolean indBlocage;
    protected String codeMotifBlocage;
    protected String libMotifBlocage;

    /**
     * Obtient la valeur de la propriété dest.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDest() {
        return dest;
    }

    /**
     * Définit la valeur de la propriété dest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDest(String value) {
        this.dest = value;
    }

    /**
     * Obtient la valeur de la propriété modeSupportDecl.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getModeSupportDecl() {
        return modeSupportDecl;
    }

    /**
     * Définit la valeur de la propriété modeSupportDecl.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setModeSupportDecl(String value) {
        this.modeSupportDecl = value;
    }

    /**
     * Obtient la valeur de la propriété indBlocage.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndBlocage() {
        return indBlocage;
    }

    /**
     * Définit la valeur de la propriété indBlocage.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndBlocage(Boolean value) {
        this.indBlocage = value;
    }

    /**
     * Obtient la valeur de la propriété codeMotifBlocage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeMotifBlocage() {
        return codeMotifBlocage;
    }

    /**
     * Définit la valeur de la propriété codeMotifBlocage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeMotifBlocage(String value) {
        this.codeMotifBlocage = value;
    }

    /**
     * Obtient la valeur de la propriété libMotifBlocage.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibMotifBlocage() {
        return libMotifBlocage;
    }

    /**
     * Définit la valeur de la propriété libMotifBlocage.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibMotifBlocage(String value) {
        this.libMotifBlocage = value;
    }

}
