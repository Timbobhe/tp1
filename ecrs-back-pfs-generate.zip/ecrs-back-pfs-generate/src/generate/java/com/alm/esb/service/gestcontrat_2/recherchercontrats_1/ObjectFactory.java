
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.recherchercontrats_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RechercherContratsFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", "RechercherContratsFull");
    private final static QName _RechercherContratsFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", "RechercherContratsFunc");
    private final static QName _RechercherContratsResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", "RechercherContratsResponse");
    private final static QName _RechercherContrats_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", "RechercherContrats");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.recherchercontrats_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RechercherContratsFuncType }
     * 
     */
    public RechercherContratsFuncType createRechercherContratsFuncType() {
        return new RechercherContratsFuncType();
    }

    /**
     * Create an instance of {@link RechercherContratsType }
     * 
     */
    public RechercherContratsType createRechercherContratsType() {
        return new RechercherContratsType();
    }

    /**
     * Create an instance of {@link RechercherContratsResponseType }
     * 
     */
    public RechercherContratsResponseType createRechercherContratsResponseType() {
        return new RechercherContratsResponseType();
    }

    /**
     * Create an instance of {@link RechercherContratsFullType }
     * 
     */
    public RechercherContratsFullType createRechercherContratsFullType() {
        return new RechercherContratsFullType();
    }

    /**
     * Create an instance of {@link OffreCialeSouscriteType }
     * 
     */
    public OffreCialeSouscriteType createOffreCialeSouscriteType() {
        return new OffreCialeSouscriteType();
    }

    /**
     * Create an instance of {@link IdPersonneDansSiloType }
     * 
     */
    public IdPersonneDansSiloType createIdPersonneDansSiloType() {
        return new IdPersonneDansSiloType();
    }

    /**
     * Create an instance of {@link SignalSouscrptPMType }
     * 
     */
    public SignalSouscrptPMType createSignalSouscrptPMType() {
        return new SignalSouscrptPMType();
    }

    /**
     * Create an instance of {@link IdentContratType }
     * 
     */
    public IdentContratType createIdentContratType() {
        return new IdentContratType();
    }

    /**
     * Create an instance of {@link InfoContratType }
     * 
     */
    public InfoContratType createInfoContratType() {
        return new InfoContratType();
    }

    /**
     * Create an instance of {@link SouscripteurType }
     * 
     */
    public SouscripteurType createSouscripteurType() {
        return new SouscripteurType();
    }

    /**
     * Create an instance of {@link ContratAssuranceType }
     * 
     */
    public ContratAssuranceType createContratAssuranceType() {
        return new ContratAssuranceType();
    }

    /**
     * Create an instance of {@link SituationAdhesionType }
     * 
     */
    public SituationAdhesionType createSituationAdhesionType() {
        return new SituationAdhesionType();
    }

    /**
     * Create an instance of {@link IdentificationType }
     * 
     */
    public IdentificationType createIdentificationType() {
        return new IdentificationType();
    }

    /**
     * Create an instance of {@link SituationCategPersType }
     * 
     */
    public SituationCategPersType createSituationCategPersType() {
        return new SituationCategPersType();
    }

    /**
     * Create an instance of {@link SituationContratType }
     * 
     */
    public SituationContratType createSituationContratType() {
        return new SituationContratType();
    }

    /**
     * Create an instance of {@link AssurePrincipalType }
     * 
     */
    public AssurePrincipalType createAssurePrincipalType() {
        return new AssurePrincipalType();
    }

    /**
     * Create an instance of {@link ActeurContratType }
     * 
     */
    public ActeurContratType createActeurContratType() {
        return new ActeurContratType();
    }

    /**
     * Create an instance of {@link AdhesionType }
     * 
     */
    public AdhesionType createAdhesionType() {
        return new AdhesionType();
    }

    /**
     * Create an instance of {@link CriteresEchantillonnageType }
     * 
     */
    public CriteresEchantillonnageType createCriteresEchantillonnageType() {
        return new CriteresEchantillonnageType();
    }

    /**
     * Create an instance of {@link CriteresRechercheType }
     * 
     */
    public CriteresRechercheType createCriteresRechercheType() {
        return new CriteresRechercheType();
    }

    /**
     * Create an instance of {@link SituationAffiliationType }
     * 
     */
    public SituationAffiliationType createSituationAffiliationType() {
        return new SituationAffiliationType();
    }

    /**
     * Create an instance of {@link RolePersContratType }
     * 
     */
    public RolePersContratType createRolePersContratType() {
        return new RolePersContratType();
    }

    /**
     * Create an instance of {@link CategPersonnelType }
     * 
     */
    public CategPersonnelType createCategPersonnelType() {
        return new CategPersonnelType();
    }

    /**
     * Create an instance of {@link SignalAdherentePMType }
     * 
     */
    public SignalAdherentePMType createSignalAdherentePMType() {
        return new SignalAdherentePMType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RechercherContratsFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", name = "RechercherContratsFull")
    public JAXBElement<RechercherContratsFullType> createRechercherContratsFull(RechercherContratsFullType value) {
        return new JAXBElement<RechercherContratsFullType>(_RechercherContratsFull_QNAME, RechercherContratsFullType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RechercherContratsFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", name = "RechercherContratsFunc")
    public JAXBElement<RechercherContratsFuncType> createRechercherContratsFunc(RechercherContratsFuncType value) {
        return new JAXBElement<RechercherContratsFuncType>(_RechercherContratsFunc_QNAME, RechercherContratsFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RechercherContratsResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", name = "RechercherContratsResponse")
    public JAXBElement<RechercherContratsResponseType> createRechercherContratsResponse(RechercherContratsResponseType value) {
        return new JAXBElement<RechercherContratsResponseType>(_RechercherContratsResponse_QNAME, RechercherContratsResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RechercherContratsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/RechercherContrats_1", name = "RechercherContrats")
    public JAXBElement<RechercherContratsType> createRechercherContrats(RechercherContratsType value) {
        return new JAXBElement<RechercherContratsType>(_RechercherContrats_QNAME, RechercherContratsType.class, null, value);
    }

}
