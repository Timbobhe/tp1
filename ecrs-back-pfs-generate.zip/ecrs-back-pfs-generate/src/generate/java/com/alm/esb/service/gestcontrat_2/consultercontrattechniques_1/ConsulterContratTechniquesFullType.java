
package com.alm.esb.service.gestcontrat_2.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratTechniquesFullType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratTechniquesFullType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}ConsulterContratTechniques" minOccurs="0"/>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratTechniques_1}ConsulterContratTechniquesResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratTechniquesFullType", propOrder = {
    "consulterContratTechniques",
    "consulterContratTechniquesResponse"
})
public class ConsulterContratTechniquesFullType {

    @XmlElement(name = "ConsulterContratTechniques")
    protected ConsulterContratTechniquesType consulterContratTechniques;
    @XmlElement(name = "ConsulterContratTechniquesResponse")
    protected ConsulterContratTechniquesResponseType consulterContratTechniquesResponse;

    /**
     * Obtient la valeur de la propriété consulterContratTechniques.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratTechniquesType }
     *     
     */
    public ConsulterContratTechniquesType getConsulterContratTechniques() {
        return consulterContratTechniques;
    }

    /**
     * Définit la valeur de la propriété consulterContratTechniques.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratTechniquesType }
     *     
     */
    public void setConsulterContratTechniques(ConsulterContratTechniquesType value) {
        this.consulterContratTechniques = value;
    }

    /**
     * Obtient la valeur de la propriété consulterContratTechniquesResponse.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratTechniquesResponseType }
     *     
     */
    public ConsulterContratTechniquesResponseType getConsulterContratTechniquesResponse() {
        return consulterContratTechniquesResponse;
    }

    /**
     * Définit la valeur de la propriété consulterContratTechniquesResponse.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratTechniquesResponseType }
     *     
     */
    public void setConsulterContratTechniquesResponse(ConsulterContratTechniquesResponseType value) {
        this.consulterContratTechniquesResponse = value;
    }

}
