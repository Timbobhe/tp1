
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour StructOrgaType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="StructOrgaType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Gest" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}GestType" minOccurs="0"/>
 *         &lt;element name="Vente" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}VenteType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StructOrgaType", propOrder = {
    "gest",
    "vente"
})
public class StructOrgaType {

    @XmlElement(name = "Gest")
    protected GestType gest;
    @XmlElement(name = "Vente")
    protected VenteType vente;

    /**
     * Obtient la valeur de la propriété gest.
     * 
     * @return
     *     possible object is
     *     {@link GestType }
     *     
     */
    public GestType getGest() {
        return gest;
    }

    /**
     * Définit la valeur de la propriété gest.
     * 
     * @param value
     *     allowed object is
     *     {@link GestType }
     *     
     */
    public void setGest(GestType value) {
        this.gest = value;
    }

    /**
     * Obtient la valeur de la propriété vente.
     * 
     * @return
     *     possible object is
     *     {@link VenteType }
     *     
     */
    public VenteType getVente() {
        return vente;
    }

    /**
     * Définit la valeur de la propriété vente.
     * 
     * @param value
     *     allowed object is
     *     {@link VenteType }
     *     
     */
    public void setVente(VenteType value) {
        this.vente = value;
    }

}
