
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdentSiloCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdentSiloCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="idSilo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="typeId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNomSilo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeAppli" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="libAppli" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSysInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libSysInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdentSiloCtrType", propOrder = {
    "idSilo",
    "typeId",
    "libNomSilo",
    "codeAppli",
    "libAppli",
    "codeSysInfo",
    "libSysInfo"
})
public class IdentSiloCtrType {

    @XmlElement(required = true)
    protected String idSilo;
    protected String typeId;
    protected String libNomSilo;
    @XmlElement(required = true)
    protected String codeAppli;
    protected String libAppli;
    protected String codeSysInfo;
    protected String libSysInfo;

    /**
     * Obtient la valeur de la propriété idSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdSilo() {
        return idSilo;
    }

    /**
     * Définit la valeur de la propriété idSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdSilo(String value) {
        this.idSilo = value;
    }

    /**
     * Obtient la valeur de la propriété typeId.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeId() {
        return typeId;
    }

    /**
     * Définit la valeur de la propriété typeId.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeId(String value) {
        this.typeId = value;
    }

    /**
     * Obtient la valeur de la propriété libNomSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNomSilo() {
        return libNomSilo;
    }

    /**
     * Définit la valeur de la propriété libNomSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNomSilo(String value) {
        this.libNomSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAppli() {
        return codeAppli;
    }

    /**
     * Définit la valeur de la propriété codeAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAppli(String value) {
        this.codeAppli = value;
    }

    /**
     * Obtient la valeur de la propriété libAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibAppli() {
        return libAppli;
    }

    /**
     * Définit la valeur de la propriété libAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibAppli(String value) {
        this.libAppli = value;
    }

    /**
     * Obtient la valeur de la propriété codeSysInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSysInfo() {
        return codeSysInfo;
    }

    /**
     * Définit la valeur de la propriété codeSysInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSysInfo(String value) {
        this.codeSysInfo = value;
    }

    /**
     * Obtient la valeur de la propriété libSysInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibSysInfo() {
        return libSysInfo;
    }

    /**
     * Définit la valeur de la propriété libSysInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibSysInfo(String value) {
        this.libSysInfo = value;
    }

}
