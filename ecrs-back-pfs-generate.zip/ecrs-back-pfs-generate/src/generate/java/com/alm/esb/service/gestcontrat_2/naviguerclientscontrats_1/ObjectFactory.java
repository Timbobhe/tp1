
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _NavCliCon_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", "NavCliCon");
    private final static QName _NaviguerClientsContrats_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", "NaviguerClientsContrats");
    private final static QName _NaviguerClientsContratsResponse_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", "NaviguerClientsContratsResponse");
    private final static QName _NaviguerClientsContratsFunc_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", "NaviguerClientsContratsFunc");
    private final static QName _NaviguerClientsContratsFull_QNAME = new QName("http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", "NaviguerClientsContratsFull");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_1
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NaviguerClientsContratsResponseType }
     * 
     */
    public NaviguerClientsContratsResponseType createNaviguerClientsContratsResponseType() {
        return new NaviguerClientsContratsResponseType();
    }

    /**
     * Create an instance of {@link NavCliConType }
     * 
     */
    public NavCliConType createNavCliConType() {
        return new NavCliConType();
    }

    /**
     * Create an instance of {@link NaviguerClientsContratsFullType }
     * 
     */
    public NaviguerClientsContratsFullType createNaviguerClientsContratsFullType() {
        return new NaviguerClientsContratsFullType();
    }

    /**
     * Create an instance of {@link NaviguerClientsContratsFuncType }
     * 
     */
    public NaviguerClientsContratsFuncType createNaviguerClientsContratsFuncType() {
        return new NaviguerClientsContratsFuncType();
    }

    /**
     * Create an instance of {@link NaviguerClientsContratsType }
     * 
     */
    public NaviguerClientsContratsType createNaviguerClientsContratsType() {
        return new NaviguerClientsContratsType();
    }

    /**
     * Create an instance of {@link IdContratSourceType }
     * 
     */
    public IdContratSourceType createIdContratSourceType() {
        return new IdContratSourceType();
    }

    /**
     * Create an instance of {@link IdContratType }
     * 
     */
    public IdContratType createIdContratType() {
        return new IdContratType();
    }

    /**
     * Create an instance of {@link ContratAssurType }
     * 
     */
    public ContratAssurType createContratAssurType() {
        return new ContratAssurType();
    }

    /**
     * Create an instance of {@link ContratPersType }
     * 
     */
    public ContratPersType createContratPersType() {
        return new ContratPersType();
    }

    /**
     * Create an instance of {@link GestionnaireContratType }
     * 
     */
    public GestionnaireContratType createGestionnaireContratType() {
        return new GestionnaireContratType();
    }

    /**
     * Create an instance of {@link SouscripteurType }
     * 
     */
    public SouscripteurType createSouscripteurType() {
        return new SouscripteurType();
    }

    /**
     * Create an instance of {@link IdentSiloType }
     * 
     */
    public IdentSiloType createIdentSiloType() {
        return new IdentSiloType();
    }

    /**
     * Create an instance of {@link PersClienteType }
     * 
     */
    public PersClienteType createPersClienteType() {
        return new PersClienteType();
    }

    /**
     * Create an instance of {@link ContratType }
     * 
     */
    public ContratType createContratType() {
        return new ContratType();
    }

    /**
     * Create an instance of {@link IdentGroupeType }
     * 
     */
    public IdentGroupeType createIdentGroupeType() {
        return new IdentGroupeType();
    }

    /**
     * Create an instance of {@link IdentSiloCourtType }
     * 
     */
    public IdentSiloCourtType createIdentSiloCourtType() {
        return new IdentSiloCourtType();
    }

    /**
     * Create an instance of {@link IdentGroupeCourtType }
     * 
     */
    public IdentGroupeCourtType createIdentGroupeCourtType() {
        return new IdentGroupeCourtType();
    }

    /**
     * Create an instance of {@link RoleContratPersType }
     * 
     */
    public RoleContratPersType createRoleContratPersType() {
        return new RoleContratPersType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NavCliConType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", name = "NavCliCon")
    public JAXBElement<NavCliConType> createNavCliCon(NavCliConType value) {
        return new JAXBElement<NavCliConType>(_NavCliCon_QNAME, NavCliConType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NaviguerClientsContratsType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", name = "NaviguerClientsContrats")
    public JAXBElement<NaviguerClientsContratsType> createNaviguerClientsContrats(NaviguerClientsContratsType value) {
        return new JAXBElement<NaviguerClientsContratsType>(_NaviguerClientsContrats_QNAME, NaviguerClientsContratsType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NaviguerClientsContratsResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", name = "NaviguerClientsContratsResponse")
    public JAXBElement<NaviguerClientsContratsResponseType> createNaviguerClientsContratsResponse(NaviguerClientsContratsResponseType value) {
        return new JAXBElement<NaviguerClientsContratsResponseType>(_NaviguerClientsContratsResponse_QNAME, NaviguerClientsContratsResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NaviguerClientsContratsFuncType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", name = "NaviguerClientsContratsFunc")
    public JAXBElement<NaviguerClientsContratsFuncType> createNaviguerClientsContratsFunc(NaviguerClientsContratsFuncType value) {
        return new JAXBElement<NaviguerClientsContratsFuncType>(_NaviguerClientsContratsFunc_QNAME, NaviguerClientsContratsFuncType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link NaviguerClientsContratsFullType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_1", name = "NaviguerClientsContratsFull")
    public JAXBElement<NaviguerClientsContratsFullType> createNaviguerClientsContratsFull(NaviguerClientsContratsFullType value) {
        return new JAXBElement<NaviguerClientsContratsFullType>(_NaviguerClientsContratsFull_QNAME, NaviguerClientsContratsFullType.class, null, value);
    }

}
