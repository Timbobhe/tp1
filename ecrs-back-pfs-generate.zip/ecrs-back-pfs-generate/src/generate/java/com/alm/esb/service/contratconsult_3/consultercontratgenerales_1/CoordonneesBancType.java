
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CoordonneesBancType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CoordonneesBancType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CoordonneesCmptBanc" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CoordonneesCmptBancType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CoordonneesBancType", propOrder = {
    "coordonneesCmptBanc"
})
public class CoordonneesBancType {

    @XmlElement(name = "CoordonneesCmptBanc")
    protected CoordonneesCmptBancType coordonneesCmptBanc;

    /**
     * Obtient la valeur de la propriété coordonneesCmptBanc.
     * 
     * @return
     *     possible object is
     *     {@link CoordonneesCmptBancType }
     *     
     */
    public CoordonneesCmptBancType getCoordonneesCmptBanc() {
        return coordonneesCmptBanc;
    }

    /**
     * Définit la valeur de la propriété coordonneesCmptBanc.
     * 
     * @param value
     *     allowed object is
     *     {@link CoordonneesCmptBancType }
     *     
     */
    public void setCoordonneesCmptBanc(CoordonneesCmptBancType value) {
        this.coordonneesCmptBanc = value;
    }

}
