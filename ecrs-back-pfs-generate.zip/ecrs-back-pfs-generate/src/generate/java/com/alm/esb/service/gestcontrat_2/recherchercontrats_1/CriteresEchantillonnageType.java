
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CriteresEchantillonnageType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CriteresEchantillonnageType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="seuilAbandon" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CriteresEchantillonnageType", propOrder = {
    "seuilAbandon"
})
public class CriteresEchantillonnageType {

    protected BigInteger seuilAbandon;

    /**
     * Obtient la valeur de la propriété seuilAbandon.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getSeuilAbandon() {
        return seuilAbandon;
    }

    /**
     * Définit la valeur de la propriété seuilAbandon.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setSeuilAbandon(BigInteger value) {
        this.seuilAbandon = value;
    }

}
