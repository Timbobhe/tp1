
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConsulterContratsPersCliFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratsPersCliFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.alm.com/esb/service/GestContrat_2/ConsulterContratsPersCli_1}PersCliente"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratsPersCliFuncType", propOrder = {
    "persCliente"
})
public class ConsulterContratsPersCliFuncType {

    @XmlElement(name = "PersCliente", required = true)
    protected PersClienteType persCliente;

    /**
     * Obtient la valeur de la propriété persCliente.
     * 
     * @return
     *     possible object is
     *     {@link PersClienteType }
     *     
     */
    public PersClienteType getPersCliente() {
        return persCliente;
    }

    /**
     * Définit la valeur de la propriété persCliente.
     * 
     * @param value
     *     allowed object is
     *     {@link PersClienteType }
     *     
     */
    public void setPersCliente(PersClienteType value) {
        this.persCliente = value;
    }

}
