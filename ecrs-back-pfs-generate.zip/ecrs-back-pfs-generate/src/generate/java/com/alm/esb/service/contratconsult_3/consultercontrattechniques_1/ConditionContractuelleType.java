
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ConditionContractuelleType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConditionContractuelleType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ageLegalDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMinDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMaxDepartRetraite" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="txFraisSurRevalorisationRente" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="txRendementMinGaranti" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeTermeContrat" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="libelleTermeContrat" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ageTermeContrat" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageCalculGrille" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}ageCalculGrilleType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="ageSimulationRAS" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="indModifAgeSimulationAutorise" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConditionContractuelleType", propOrder = {
    "ageLegalDepartRetraite",
    "ageMinDepartRetraite",
    "ageMaxDepartRetraite",
    "txFraisSurRevalorisationRente",
    "txRendementMinGaranti",
    "codeTermeContrat",
    "libelleTermeContrat",
    "ageTermeContrat",
    "ageCalculGrille",
    "ageSimulationRAS",
    "indModifAgeSimulationAutorise"
})
public class ConditionContractuelleType {

    protected BigInteger ageLegalDepartRetraite;
    protected BigInteger ageMinDepartRetraite;
    protected BigInteger ageMaxDepartRetraite;
    protected BigDecimal txFraisSurRevalorisationRente;
    protected BigDecimal txRendementMinGaranti;
    protected BigInteger codeTermeContrat;
    protected String libelleTermeContrat;
    protected BigInteger ageTermeContrat;
    protected List<AgeCalculGrilleType> ageCalculGrille;
    protected BigInteger ageSimulationRAS;
    protected Boolean indModifAgeSimulationAutorise;

    /**
     * Obtient la valeur de la propriété ageLegalDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeLegalDepartRetraite() {
        return ageLegalDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageLegalDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeLegalDepartRetraite(BigInteger value) {
        this.ageLegalDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété ageMinDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMinDepartRetraite() {
        return ageMinDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageMinDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMinDepartRetraite(BigInteger value) {
        this.ageMinDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété ageMaxDepartRetraite.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMaxDepartRetraite() {
        return ageMaxDepartRetraite;
    }

    /**
     * Définit la valeur de la propriété ageMaxDepartRetraite.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMaxDepartRetraite(BigInteger value) {
        this.ageMaxDepartRetraite = value;
    }

    /**
     * Obtient la valeur de la propriété txFraisSurRevalorisationRente.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxFraisSurRevalorisationRente() {
        return txFraisSurRevalorisationRente;
    }

    /**
     * Définit la valeur de la propriété txFraisSurRevalorisationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxFraisSurRevalorisationRente(BigDecimal value) {
        this.txFraisSurRevalorisationRente = value;
    }

    /**
     * Obtient la valeur de la propriété txRendementMinGaranti.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTxRendementMinGaranti() {
        return txRendementMinGaranti;
    }

    /**
     * Définit la valeur de la propriété txRendementMinGaranti.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTxRendementMinGaranti(BigDecimal value) {
        this.txRendementMinGaranti = value;
    }

    /**
     * Obtient la valeur de la propriété codeTermeContrat.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getCodeTermeContrat() {
        return codeTermeContrat;
    }

    /**
     * Définit la valeur de la propriété codeTermeContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setCodeTermeContrat(BigInteger value) {
        this.codeTermeContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libelleTermeContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelleTermeContrat() {
        return libelleTermeContrat;
    }

    /**
     * Définit la valeur de la propriété libelleTermeContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelleTermeContrat(String value) {
        this.libelleTermeContrat = value;
    }

    /**
     * Obtient la valeur de la propriété ageTermeContrat.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeTermeContrat() {
        return ageTermeContrat;
    }

    /**
     * Définit la valeur de la propriété ageTermeContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeTermeContrat(BigInteger value) {
        this.ageTermeContrat = value;
    }

    /**
     * Gets the value of the ageCalculGrille property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the ageCalculGrille property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAgeCalculGrille().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AgeCalculGrilleType }
     * 
     * 
     */
    public List<AgeCalculGrilleType> getAgeCalculGrille() {
        if (ageCalculGrille == null) {
            ageCalculGrille = new ArrayList<AgeCalculGrilleType>();
        }
        return this.ageCalculGrille;
    }

    /**
     * Obtient la valeur de la propriété ageSimulationRAS.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeSimulationRAS() {
        return ageSimulationRAS;
    }

    /**
     * Définit la valeur de la propriété ageSimulationRAS.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeSimulationRAS(BigInteger value) {
        this.ageSimulationRAS = value;
    }

    /**
     * Obtient la valeur de la propriété indModifAgeSimulationAutorise.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndModifAgeSimulationAutorise() {
        return indModifAgeSimulationAutorise;
    }

    /**
     * Définit la valeur de la propriété indModifAgeSimulationAutorise.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndModifAgeSimulationAutorise(Boolean value) {
        this.indModifAgeSimulationAutorise = value;
    }

}
