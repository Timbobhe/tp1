
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_2;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour ContratPersType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ContratPersType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Contrat" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_2}ContratType"/>
 *         &lt;element name="RoleContratPers" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_2}RoleContratPersType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ContratPersType", propOrder = {
    "contrat",
    "roleContratPers"
})
public class ContratPersType {

    @XmlElement(name = "Contrat", required = true)
    protected ContratType contrat;
    @XmlElement(name = "RoleContratPers")
    protected List<RoleContratPersType> roleContratPers;

    /**
     * Obtient la valeur de la propriété contrat.
     * 
     * @return
     *     possible object is
     *     {@link ContratType }
     *     
     */
    public ContratType getContrat() {
        return contrat;
    }

    /**
     * Définit la valeur de la propriété contrat.
     * 
     * @param value
     *     allowed object is
     *     {@link ContratType }
     *     
     */
    public void setContrat(ContratType value) {
        this.contrat = value;
    }

    /**
     * Gets the value of the roleContratPers property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the roleContratPers property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getRoleContratPers().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RoleContratPersType }
     * 
     * 
     */
    public List<RoleContratPersType> getRoleContratPers() {
        if (roleContratPers == null) {
            roleContratPers = new ArrayList<RoleContratPersType>();
        }
        return this.roleContratPers;
    }

}
