
package com.alm.esb.service.gestcontrat_2.naviguerclientscontrats_4;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdContratType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdContratType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentSiloContrat" type="{http://www.alm.com/esb/service/GestContrat_2/NaviguerClientsContrats_4}IdentSiloType" minOccurs="0"/>
 *         &lt;element name="codeNatContrat" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libNatContrat" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeNatContratSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeBrancheAssur" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libBrancheAssur" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeBrancheAssurSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeBrancheAssurDet" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="libBrancheAssurDet" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *         &lt;element name="codeBrancheAssurDetSilo" minOccurs="0">
 *           &lt;simpleType>
 *             &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *             &lt;/restriction>
 *           &lt;/simpleType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdContratType", propOrder = {
    "identSiloContrat",
    "codeNatContrat",
    "libNatContrat",
    "codeNatContratSilo",
    "codeBrancheAssur",
    "libBrancheAssur",
    "codeBrancheAssurSilo",
    "codeBrancheAssurDet",
    "libBrancheAssurDet",
    "codeBrancheAssurDetSilo"
})
public class IdContratType {

    @XmlElement(name = "IdentSiloContrat")
    protected IdentSiloType identSiloContrat;
    protected String codeNatContrat;
    protected String libNatContrat;
    protected String codeNatContratSilo;
    protected String codeBrancheAssur;
    protected String libBrancheAssur;
    protected String codeBrancheAssurSilo;
    protected String codeBrancheAssurDet;
    protected String libBrancheAssurDet;
    protected String codeBrancheAssurDetSilo;

    /**
     * Obtient la valeur de la propriété identSiloContrat.
     * 
     * @return
     *     possible object is
     *     {@link IdentSiloType }
     *     
     */
    public IdentSiloType getIdentSiloContrat() {
        return identSiloContrat;
    }

    /**
     * Définit la valeur de la propriété identSiloContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentSiloType }
     *     
     */
    public void setIdentSiloContrat(IdentSiloType value) {
        this.identSiloContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatContrat() {
        return codeNatContrat;
    }

    /**
     * Définit la valeur de la propriété codeNatContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatContrat(String value) {
        this.codeNatContrat = value;
    }

    /**
     * Obtient la valeur de la propriété libNatContrat.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNatContrat() {
        return libNatContrat;
    }

    /**
     * Définit la valeur de la propriété libNatContrat.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNatContrat(String value) {
        this.libNatContrat = value;
    }

    /**
     * Obtient la valeur de la propriété codeNatContratSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNatContratSilo() {
        return codeNatContratSilo;
    }

    /**
     * Définit la valeur de la propriété codeNatContratSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNatContratSilo(String value) {
        this.codeNatContratSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrancheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrancheAssur() {
        return codeBrancheAssur;
    }

    /**
     * Définit la valeur de la propriété codeBrancheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrancheAssur(String value) {
        this.codeBrancheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété libBrancheAssur.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibBrancheAssur() {
        return libBrancheAssur;
    }

    /**
     * Définit la valeur de la propriété libBrancheAssur.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibBrancheAssur(String value) {
        this.libBrancheAssur = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrancheAssurSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrancheAssurSilo() {
        return codeBrancheAssurSilo;
    }

    /**
     * Définit la valeur de la propriété codeBrancheAssurSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrancheAssurSilo(String value) {
        this.codeBrancheAssurSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrancheAssurDet.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrancheAssurDet() {
        return codeBrancheAssurDet;
    }

    /**
     * Définit la valeur de la propriété codeBrancheAssurDet.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrancheAssurDet(String value) {
        this.codeBrancheAssurDet = value;
    }

    /**
     * Obtient la valeur de la propriété libBrancheAssurDet.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibBrancheAssurDet() {
        return libBrancheAssurDet;
    }

    /**
     * Définit la valeur de la propriété libBrancheAssurDet.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibBrancheAssurDet(String value) {
        this.libBrancheAssurDet = value;
    }

    /**
     * Obtient la valeur de la propriété codeBrancheAssurDetSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeBrancheAssurDetSilo() {
        return codeBrancheAssurDetSilo;
    }

    /**
     * Définit la valeur de la propriété codeBrancheAssurDetSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeBrancheAssurDetSilo(String value) {
        this.codeBrancheAssurDetSilo = value;
    }

}
