
package com.alm.esb.service.gestcontrat_2.recherchercontrats_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour IdPersonneDansSiloType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="IdPersonneDansSiloType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdentifiantDansSilo" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="codeAppli" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeSysInfo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdPersonneDansSiloType", propOrder = {
    "identifiantDansSilo",
    "codeAppli",
    "codeSysInfo"
})
public class IdPersonneDansSiloType {

    @XmlElement(name = "IdentifiantDansSilo", required = true)
    protected String identifiantDansSilo;
    protected String codeAppli;
    protected String codeSysInfo;

    /**
     * Obtient la valeur de la propriété identifiantDansSilo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentifiantDansSilo() {
        return identifiantDansSilo;
    }

    /**
     * Définit la valeur de la propriété identifiantDansSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentifiantDansSilo(String value) {
        this.identifiantDansSilo = value;
    }

    /**
     * Obtient la valeur de la propriété codeAppli.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAppli() {
        return codeAppli;
    }

    /**
     * Définit la valeur de la propriété codeAppli.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAppli(String value) {
        this.codeAppli = value;
    }

    /**
     * Obtient la valeur de la propriété codeSysInfo.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeSysInfo() {
        return codeSysInfo;
    }

    /**
     * Définit la valeur de la propriété codeSysInfo.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeSysInfo(String value) {
        this.codeSysInfo = value;
    }

}
