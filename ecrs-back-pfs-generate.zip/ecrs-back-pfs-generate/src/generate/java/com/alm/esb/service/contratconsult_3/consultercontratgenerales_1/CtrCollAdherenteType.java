
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CtrCollAdherenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CtrCollAdherenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CatPrslAdh" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratGenerales_1}CatPrslAdherenteType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CtrCollAdherenteType", propOrder = {
    "catPrslAdh"
})
public class CtrCollAdherenteType {

    @XmlElement(name = "CatPrslAdh")
    protected List<CatPrslAdherenteType> catPrslAdh;

    /**
     * Gets the value of the catPrslAdh property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the catPrslAdh property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCatPrslAdh().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CatPrslAdherenteType }
     * 
     * 
     */
    public List<CatPrslAdherenteType> getCatPrslAdh() {
        if (catPrslAdh == null) {
            catPrslAdh = new ArrayList<CatPrslAdherenteType>();
        }
        return this.catPrslAdh;
    }

}
