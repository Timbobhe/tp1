
package com.alm.esb.service.creationdemope_4.creerdemope_1;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour CreerDemOpeFuncType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="CreerDemOpeFuncType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="IdDemSilo" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}IdDemSiloType"/>
 *         &lt;element name="infoCompl" type="{http://www.alm.com/esb/service/CreationDemOpe_4/CreerDemOpe_1}InfoComplType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "CreerDemOpeFuncType", propOrder = {
    "idDemSilo",
    "infoCompl"
})
public class CreerDemOpeFuncType {

    @XmlElement(name = "IdDemSilo", required = true)
    protected IdDemSiloType idDemSilo;
    protected List<InfoComplType> infoCompl;

    /**
     * Obtient la valeur de la propriété idDemSilo.
     * 
     * @return
     *     possible object is
     *     {@link IdDemSiloType }
     *     
     */
    public IdDemSiloType getIdDemSilo() {
        return idDemSilo;
    }

    /**
     * Définit la valeur de la propriété idDemSilo.
     * 
     * @param value
     *     allowed object is
     *     {@link IdDemSiloType }
     *     
     */
    public void setIdDemSilo(IdDemSiloType value) {
        this.idDemSilo = value;
    }

    /**
     * Gets the value of the infoCompl property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoCompl property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoCompl().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoComplType }
     * 
     * 
     */
    public List<InfoComplType> getInfoCompl() {
        if (infoCompl == null) {
            infoCompl = new ArrayList<InfoComplType>();
        }
        return this.infoCompl;
    }

}
