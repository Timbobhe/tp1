
package com.alm.esb.service.gestcontrat_2.consultercontratsperscli_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.fmk.esb.framework.esbtechpivotschema.PivotTechType;


/**
 * <p>Classe Java pour ConsulterContratsPersCliInterfaceResponseType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="ConsulterContratsPersCliInterfaceResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.fmk.com/ESB/Framework/ESBTechPivotSchema}PivotTech"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ConsulterContratsPersCliInterfaceResponseType", propOrder = {
    "pivotTech"
})
public class ConsulterContratsPersCliInterfaceResponseType {

    @XmlElement(name = "PivotTech", namespace = "http://www.fmk.com/ESB/Framework/ESBTechPivotSchema", required = true)
    protected PivotTechType pivotTech;

    /**
     * Obtient la valeur de la propriété pivotTech.
     * 
     * @return
     *     possible object is
     *     {@link PivotTechType }
     *     
     */
    public PivotTechType getPivotTech() {
        return pivotTech;
    }

    /**
     * Définit la valeur de la propriété pivotTech.
     * 
     * @param value
     *     allowed object is
     *     {@link PivotTechType }
     *     
     */
    public void setPivotTech(PivotTechType value) {
        this.pivotTech = value;
    }

}
