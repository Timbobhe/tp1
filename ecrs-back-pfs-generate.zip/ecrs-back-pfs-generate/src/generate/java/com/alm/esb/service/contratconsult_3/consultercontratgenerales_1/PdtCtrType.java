
package com.alm.esb.service.contratconsult_3.consultercontratgenerales_1;

import java.math.BigInteger;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour PdtCtrType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="PdtCtrType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="codePdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ageMaxEnfMajr" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="ageMinEnfMajr" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="nomCial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nomFamillePdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutEffetPdt" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffetPdt" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="codeComposantPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libComposantPdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeDispoEnOpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDispoEnOpt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeFamillePdt" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="indGestCarteTiersPayant" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indPdtResp" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="codeNivCouverture" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libNivCouverture" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PdtCtrType", propOrder = {
    "codePdt",
    "libPdt",
    "ageMaxEnfMajr",
    "ageMinEnfMajr",
    "nomCial",
    "nomFamillePdt",
    "dateDebutEffetPdt",
    "dateFinEffetPdt",
    "codeComposantPdt",
    "libComposantPdt",
    "codeDispoEnOpt",
    "libDispoEnOpt",
    "codeFamillePdt",
    "indGestCarteTiersPayant",
    "indPdtResp",
    "codeNivCouverture",
    "libNivCouverture"
})
public class PdtCtrType {

    protected String codePdt;
    protected String libPdt;
    protected BigInteger ageMaxEnfMajr;
    protected BigInteger ageMinEnfMajr;
    protected String nomCial;
    protected String nomFamillePdt;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutEffetPdt;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffetPdt;
    protected String codeComposantPdt;
    protected String libComposantPdt;
    protected String codeDispoEnOpt;
    protected String libDispoEnOpt;
    protected String codeFamillePdt;
    protected Boolean indGestCarteTiersPayant;
    protected Boolean indPdtResp;
    protected String codeNivCouverture;
    protected String libNivCouverture;

    /**
     * Obtient la valeur de la propriété codePdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePdt() {
        return codePdt;
    }

    /**
     * Définit la valeur de la propriété codePdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePdt(String value) {
        this.codePdt = value;
    }

    /**
     * Obtient la valeur de la propriété libPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPdt() {
        return libPdt;
    }

    /**
     * Définit la valeur de la propriété libPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPdt(String value) {
        this.libPdt = value;
    }

    /**
     * Obtient la valeur de la propriété ageMaxEnfMajr.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMaxEnfMajr() {
        return ageMaxEnfMajr;
    }

    /**
     * Définit la valeur de la propriété ageMaxEnfMajr.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMaxEnfMajr(BigInteger value) {
        this.ageMaxEnfMajr = value;
    }

    /**
     * Obtient la valeur de la propriété ageMinEnfMajr.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    public BigInteger getAgeMinEnfMajr() {
        return ageMinEnfMajr;
    }

    /**
     * Définit la valeur de la propriété ageMinEnfMajr.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    public void setAgeMinEnfMajr(BigInteger value) {
        this.ageMinEnfMajr = value;
    }

    /**
     * Obtient la valeur de la propriété nomCial.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomCial() {
        return nomCial;
    }

    /**
     * Définit la valeur de la propriété nomCial.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomCial(String value) {
        this.nomCial = value;
    }

    /**
     * Obtient la valeur de la propriété nomFamillePdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNomFamillePdt() {
        return nomFamillePdt;
    }

    /**
     * Définit la valeur de la propriété nomFamillePdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNomFamillePdt(String value) {
        this.nomFamillePdt = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutEffetPdt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutEffetPdt() {
        return dateDebutEffetPdt;
    }

    /**
     * Définit la valeur de la propriété dateDebutEffetPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutEffetPdt(XMLGregorianCalendar value) {
        this.dateDebutEffetPdt = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetPdt.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffetPdt() {
        return dateFinEffetPdt;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffetPdt(XMLGregorianCalendar value) {
        this.dateFinEffetPdt = value;
    }

    /**
     * Obtient la valeur de la propriété codeComposantPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeComposantPdt() {
        return codeComposantPdt;
    }

    /**
     * Définit la valeur de la propriété codeComposantPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeComposantPdt(String value) {
        this.codeComposantPdt = value;
    }

    /**
     * Obtient la valeur de la propriété libComposantPdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibComposantPdt() {
        return libComposantPdt;
    }

    /**
     * Définit la valeur de la propriété libComposantPdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibComposantPdt(String value) {
        this.libComposantPdt = value;
    }

    /**
     * Obtient la valeur de la propriété codeDispoEnOpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDispoEnOpt() {
        return codeDispoEnOpt;
    }

    /**
     * Définit la valeur de la propriété codeDispoEnOpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDispoEnOpt(String value) {
        this.codeDispoEnOpt = value;
    }

    /**
     * Obtient la valeur de la propriété libDispoEnOpt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDispoEnOpt() {
        return libDispoEnOpt;
    }

    /**
     * Définit la valeur de la propriété libDispoEnOpt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDispoEnOpt(String value) {
        this.libDispoEnOpt = value;
    }

    /**
     * Obtient la valeur de la propriété codeFamillePdt.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeFamillePdt() {
        return codeFamillePdt;
    }

    /**
     * Définit la valeur de la propriété codeFamillePdt.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeFamillePdt(String value) {
        this.codeFamillePdt = value;
    }

    /**
     * Obtient la valeur de la propriété indGestCarteTiersPayant.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndGestCarteTiersPayant() {
        return indGestCarteTiersPayant;
    }

    /**
     * Définit la valeur de la propriété indGestCarteTiersPayant.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndGestCarteTiersPayant(Boolean value) {
        this.indGestCarteTiersPayant = value;
    }

    /**
     * Obtient la valeur de la propriété indPdtResp.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndPdtResp() {
        return indPdtResp;
    }

    /**
     * Définit la valeur de la propriété indPdtResp.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndPdtResp(Boolean value) {
        this.indPdtResp = value;
    }

    /**
     * Obtient la valeur de la propriété codeNivCouverture.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeNivCouverture() {
        return codeNivCouverture;
    }

    /**
     * Définit la valeur de la propriété codeNivCouverture.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeNivCouverture(String value) {
        this.codeNivCouverture = value;
    }

    /**
     * Obtient la valeur de la propriété libNivCouverture.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibNivCouverture() {
        return libNivCouverture;
    }

    /**
     * Définit la valeur de la propriété libNivCouverture.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibNivCouverture(String value) {
        this.libNivCouverture = value;
    }

}
