
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InformationRenteType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InformationRenteType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="montantArrieres" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="deviseArrieres" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codePeriodicitePrestationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libellePeriodicitePrestationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="codeEcheancePrestationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libEcheancePrestationRente" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateCalcul" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateProchainPaiementGlobal" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateProchainPaiementRente" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="InfoContribution" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}InfoContribType" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InformationRenteType", propOrder = {
    "montantArrieres",
    "deviseArrieres",
    "codePeriodicitePrestationRente",
    "libellePeriodicitePrestationRente",
    "codeEcheancePrestationRente",
    "libEcheancePrestationRente",
    "dateCalcul",
    "dateProchainPaiementGlobal",
    "dateProchainPaiementRente",
    "infoContribution"
})
public class InformationRenteType {

    protected BigDecimal montantArrieres;
    protected String deviseArrieres;
    protected String codePeriodicitePrestationRente;
    protected String libellePeriodicitePrestationRente;
    protected String codeEcheancePrestationRente;
    protected String libEcheancePrestationRente;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateCalcul;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchainPaiementGlobal;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateProchainPaiementRente;
    @XmlElement(name = "InfoContribution")
    protected List<InfoContribType> infoContribution;

    /**
     * Obtient la valeur de la propriété montantArrieres.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMontantArrieres() {
        return montantArrieres;
    }

    /**
     * Définit la valeur de la propriété montantArrieres.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMontantArrieres(BigDecimal value) {
        this.montantArrieres = value;
    }

    /**
     * Obtient la valeur de la propriété deviseArrieres.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeviseArrieres() {
        return deviseArrieres;
    }

    /**
     * Définit la valeur de la propriété deviseArrieres.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeviseArrieres(String value) {
        this.deviseArrieres = value;
    }

    /**
     * Obtient la valeur de la propriété codePeriodicitePrestationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodePeriodicitePrestationRente() {
        return codePeriodicitePrestationRente;
    }

    /**
     * Définit la valeur de la propriété codePeriodicitePrestationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodePeriodicitePrestationRente(String value) {
        this.codePeriodicitePrestationRente = value;
    }

    /**
     * Obtient la valeur de la propriété libellePeriodicitePrestationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibellePeriodicitePrestationRente() {
        return libellePeriodicitePrestationRente;
    }

    /**
     * Définit la valeur de la propriété libellePeriodicitePrestationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibellePeriodicitePrestationRente(String value) {
        this.libellePeriodicitePrestationRente = value;
    }

    /**
     * Obtient la valeur de la propriété codeEcheancePrestationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeEcheancePrestationRente() {
        return codeEcheancePrestationRente;
    }

    /**
     * Définit la valeur de la propriété codeEcheancePrestationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeEcheancePrestationRente(String value) {
        this.codeEcheancePrestationRente = value;
    }

    /**
     * Obtient la valeur de la propriété libEcheancePrestationRente.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibEcheancePrestationRente() {
        return libEcheancePrestationRente;
    }

    /**
     * Définit la valeur de la propriété libEcheancePrestationRente.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibEcheancePrestationRente(String value) {
        this.libEcheancePrestationRente = value;
    }

    /**
     * Obtient la valeur de la propriété dateCalcul.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateCalcul() {
        return dateCalcul;
    }

    /**
     * Définit la valeur de la propriété dateCalcul.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateCalcul(XMLGregorianCalendar value) {
        this.dateCalcul = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchainPaiementGlobal.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchainPaiementGlobal() {
        return dateProchainPaiementGlobal;
    }

    /**
     * Définit la valeur de la propriété dateProchainPaiementGlobal.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchainPaiementGlobal(XMLGregorianCalendar value) {
        this.dateProchainPaiementGlobal = value;
    }

    /**
     * Obtient la valeur de la propriété dateProchainPaiementRente.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateProchainPaiementRente() {
        return dateProchainPaiementRente;
    }

    /**
     * Définit la valeur de la propriété dateProchainPaiementRente.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateProchainPaiementRente(XMLGregorianCalendar value) {
        this.dateProchainPaiementRente = value;
    }

    /**
     * Gets the value of the infoContribution property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoContribution property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoContribution().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoContribType }
     * 
     * 
     */
    public List<InfoContribType> getInfoContribution() {
        if (infoContribution == null) {
            infoContribution = new ArrayList<InfoContribType>();
        }
        return this.infoContribution;
    }

}
