
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour RequestJSONRootType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="RequestJSONRootType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ConsulterContratTechniques" type="{http://www.alm.com/esb/service/ContratConsult_3/ConsulterContratTechniques_1}ConsulterContratTechniquesType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RequestJSONRootType", propOrder = {
    "consulterContratTechniques"
})
public class RequestJSONRootType {

    @XmlElement(name = "ConsulterContratTechniques", required = true)
    protected ConsulterContratTechniquesType consulterContratTechniques;

    /**
     * Obtient la valeur de la propriété consulterContratTechniques.
     * 
     * @return
     *     possible object is
     *     {@link ConsulterContratTechniquesType }
     *     
     */
    public ConsulterContratTechniquesType getConsulterContratTechniques() {
        return consulterContratTechniques;
    }

    /**
     * Définit la valeur de la propriété consulterContratTechniques.
     * 
     * @param value
     *     allowed object is
     *     {@link ConsulterContratTechniquesType }
     *     
     */
    public void setConsulterContratTechniques(ConsulterContratTechniquesType value) {
        this.consulterContratTechniques = value;
    }

}
