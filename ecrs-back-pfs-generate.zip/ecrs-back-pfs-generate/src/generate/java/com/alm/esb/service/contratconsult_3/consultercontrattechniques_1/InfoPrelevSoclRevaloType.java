
package com.alm.esb.service.contratconsult_3.consultercontrattechniques_1;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour InfoPrelevSoclRevaloType complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="InfoPrelevSoclRevaloType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="typePrelev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libPrelev" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="dateDebutEffetPrelev" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="dateFinEffetPrelev" type="{http://www.w3.org/2001/XMLSchema}date" minOccurs="0"/>
 *         &lt;element name="tauxPrelev" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="mntExonAnnu" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="codeDeviseMntExon" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="libDeviseMntExon" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tauxExonAnnu" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/>
 *         &lt;element name="indPrelevSoclSpecif" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "InfoPrelevSoclRevaloType", propOrder = {
    "typePrelev",
    "libPrelev",
    "dateDebutEffetPrelev",
    "dateFinEffetPrelev",
    "tauxPrelev",
    "mntExonAnnu",
    "codeDeviseMntExon",
    "libDeviseMntExon",
    "tauxExonAnnu",
    "indPrelevSoclSpecif"
})
public class InfoPrelevSoclRevaloType {

    protected String typePrelev;
    protected String libPrelev;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateDebutEffetPrelev;
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar dateFinEffetPrelev;
    protected BigDecimal tauxPrelev;
    protected BigDecimal mntExonAnnu;
    protected String codeDeviseMntExon;
    protected String libDeviseMntExon;
    protected BigDecimal tauxExonAnnu;
    protected Boolean indPrelevSoclSpecif;

    /**
     * Obtient la valeur de la propriété typePrelev.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypePrelev() {
        return typePrelev;
    }

    /**
     * Définit la valeur de la propriété typePrelev.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypePrelev(String value) {
        this.typePrelev = value;
    }

    /**
     * Obtient la valeur de la propriété libPrelev.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibPrelev() {
        return libPrelev;
    }

    /**
     * Définit la valeur de la propriété libPrelev.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibPrelev(String value) {
        this.libPrelev = value;
    }

    /**
     * Obtient la valeur de la propriété dateDebutEffetPrelev.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateDebutEffetPrelev() {
        return dateDebutEffetPrelev;
    }

    /**
     * Définit la valeur de la propriété dateDebutEffetPrelev.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateDebutEffetPrelev(XMLGregorianCalendar value) {
        this.dateDebutEffetPrelev = value;
    }

    /**
     * Obtient la valeur de la propriété dateFinEffetPrelev.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateFinEffetPrelev() {
        return dateFinEffetPrelev;
    }

    /**
     * Définit la valeur de la propriété dateFinEffetPrelev.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateFinEffetPrelev(XMLGregorianCalendar value) {
        this.dateFinEffetPrelev = value;
    }

    /**
     * Obtient la valeur de la propriété tauxPrelev.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxPrelev() {
        return tauxPrelev;
    }

    /**
     * Définit la valeur de la propriété tauxPrelev.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxPrelev(BigDecimal value) {
        this.tauxPrelev = value;
    }

    /**
     * Obtient la valeur de la propriété mntExonAnnu.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getMntExonAnnu() {
        return mntExonAnnu;
    }

    /**
     * Définit la valeur de la propriété mntExonAnnu.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setMntExonAnnu(BigDecimal value) {
        this.mntExonAnnu = value;
    }

    /**
     * Obtient la valeur de la propriété codeDeviseMntExon.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeDeviseMntExon() {
        return codeDeviseMntExon;
    }

    /**
     * Définit la valeur de la propriété codeDeviseMntExon.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeDeviseMntExon(String value) {
        this.codeDeviseMntExon = value;
    }

    /**
     * Obtient la valeur de la propriété libDeviseMntExon.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibDeviseMntExon() {
        return libDeviseMntExon;
    }

    /**
     * Définit la valeur de la propriété libDeviseMntExon.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibDeviseMntExon(String value) {
        this.libDeviseMntExon = value;
    }

    /**
     * Obtient la valeur de la propriété tauxExonAnnu.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTauxExonAnnu() {
        return tauxExonAnnu;
    }

    /**
     * Définit la valeur de la propriété tauxExonAnnu.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTauxExonAnnu(BigDecimal value) {
        this.tauxExonAnnu = value;
    }

    /**
     * Obtient la valeur de la propriété indPrelevSoclSpecif.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndPrelevSoclSpecif() {
        return indPrelevSoclSpecif;
    }

    /**
     * Définit la valeur de la propriété indPrelevSoclSpecif.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndPrelevSoclSpecif(Boolean value) {
        this.indPrelevSoclSpecif = value;
    }

}
