# ECRS-BACK-PFS-GENERATE

## Installation

```cmd
git clone git@git-prd.server.lan:A1573/ecrs-back-pfs-generate.git
```

## Génération des sources depuis WSDL

```cmd
cd ecrs-back-pfs-generate
mvn clean compile -P generate-pfs-services
```

## Génération des sources des Formulaires

```cmd
cd ecrs-back-pfs-generate
mvn clean compile -P generate-formulaire
```

## Génération des sources depuis WADL

1. Copier les WADL dans le répertoire `${basedir}/src/main/resources/wadl`.

2. Modifier le POM.XML en rajoutant le nom du fichier WADL

```xml
<includes>PaimtDigi_1.wadl</includes>
```

3. Exécuter la commande 

```cmd
cd ecrs-back-pfs-generate
mvn -Djavax.xml.accessExternalSchema=all -P generate-pfs-services-rest wadl-client:generate
```

*Aussi disponible via une Configuration IntelliJ `.run/generate-pfs-service-rest.run.xml`.*

3. Supprimer le répertoire `src/generate/java/supprimer`


## génération depuis swagger

1. Copier les YAML dans le répertoire `${basedir}/src/main/resources/swagger`.

2. Modifier le POM.XML en rajoutant le nom du fichier yaml

```xml
   <inputSpec>${basedir}/src/main/resources/swagger/RechercherPrestations.yaml</inputSpec>
```

3. Modifier le nom du package à partir de la variable paths du yaml

```xml
   <modelPackage>${output.package.swagger}.prestations_2.rechercherprestations_1</modelPackage>
```

4. Exécuter la commande

```cmd
mvn clean compile -P generate-pfs-services-rest-swagger
```
