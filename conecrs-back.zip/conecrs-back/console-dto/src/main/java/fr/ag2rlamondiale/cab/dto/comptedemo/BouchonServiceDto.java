package fr.ag2rlamondiale.cab.dto.comptedemo;

import java.util.Date;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class BouchonServiceDto {

    private Long id;
    private Long idCmpDemo;
    private String idService;
    private String idRequete;
    private boolean pieceJointeExists;

    @ToString.Exclude
    private String vaRep;
    private Date dateCreation;
    private Date dateMiseAjour;

    @ToString.Exclude
    private String pieceJointe;
}
