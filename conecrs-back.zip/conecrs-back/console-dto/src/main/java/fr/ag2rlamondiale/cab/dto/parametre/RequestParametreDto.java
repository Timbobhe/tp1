package fr.ag2rlamondiale.cab.dto.parametre;

import lombok.Data;

import java.time.LocalDate;

@Data
public class RequestParametreDto {
    private String typeParam;
    private LocalDate date;
}
