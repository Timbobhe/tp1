package fr.ag2rlamondiale.cab.dto.comptedemo;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModificationBouchonServiceDto {
    @NotBlank(message = "ID Service: ne peut pas etre vide")
    private String idService;

    @NotBlank(message = "ID Requete: ne peut pas etre vide")
    private String idRequete;

    @NotBlank(message = "R\u00E9ponse: ne peut pas etre vide")
    private String vaRep;

    private String pieceJointe;
}
