package fr.ag2rlamondiale.cab.tool.comptedemo;

import fr.ag2rlamondiale.cab.dto.comptedemo.BouchonServiceDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.CompteDemoDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.ContextStartedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
@Service
public class CopyBouchonTool /* implements ApplicationListener<ApplicationEvent>*/ {

    @Autowired
    private CopyBouchonConfig config;

    @Autowired
    private RestTemplate restTemplate;

    @EventListener
    public void onApplicationEvent(ApplicationReadyEvent ae) {
        log.info("Execution de {} avec la Config = {}", this.getClass().getSimpleName(), this.config);
        execute();
    }

    public void execute() {
        // 1. Récuperer le compte démo
        log.info("1. Récuperer le compte démo");
        CompteDemoDto cdmSource = restTemplate.getForObject(config.getUrlSource() + "/compte-demo/" + config.getIdCompteDemo(), CompteDemoDto.class);

        // 2. Récupérer les bouchons
        BouchonServiceDto[] bouchonsSources = restTemplate.getForObject(config.getUrlSource() + "/bouchon-service/find-all?idCmpDem=" + config.getIdCompteDemo(), BouchonServiceDto[].class);

        // 3. Créer le Compte Démo (vérifier l'existance)
        CompteDemoDto cdmCible = null;
        log.info("Création du compte Démo cible depuis {}", cdmSource);
        if (!config.isDummy()) {
            try {
                ResponseEntity<CompteDemoDto> cmdCibleEntity = restTemplate.getForEntity(config.getUrlCible() + "/compte-demo/find?numReferenceExterne={0}", CompteDemoDto.class, cdmSource.getNumReferenceExterne());
                cdmCible = cmdCibleEntity.getBody();
                log.info("Récupération du compte Démo cible ID = {}", cdmCible.getId());
            } catch (HttpClientErrorException.NotFound e) {
                cdmCible = restTemplate.postForEntity(config.getUrlCible() + "/compte-demo", cdmSource, CompteDemoDto.class).getBody();
                log.info("Création du compte Démo cible ID = {}", cdmCible.getId());
            }

        }

        // 4. Copier les bouchon
        for (BouchonServiceDto bouchonsSource : bouchonsSources) {
            if (!config.isDummy()) {
                Objects.requireNonNull(cdmCible);
                BouchonServiceDto bouchonCible = bouchonsSource.toBuilder()
                        .idCmpDemo(cdmCible.getId())
                        .build();

                try {
                    Map<String, Object> vars = new HashMap<>();
                    vars.put("idCmpDem", cdmCible.getId());
                    vars.put("idService", bouchonCible.getIdService());
                    vars.put("idRequete", bouchonCible.getIdRequete());
                    vars.put("pieceJointe", bouchonCible.getPieceJointe());

                    ResponseEntity<BouchonServiceDto> bouchonEntity = restTemplate.getForEntity(config.getUrlCible() + "/bouchon-service/find?idCmpDem={idCmpDem}&idService={idService}&idRequete={idRequete}&pieceJointe={pieceJointe}", BouchonServiceDto.class, vars);
                    log.info("Bouchon déjà présent = {}", bouchonEntity.getBody().getId());
                } catch (HttpClientErrorException.NotFound e) {
                    final BouchonServiceDto bcs = restTemplate.postForObject(config.getUrlCible() + "/bouchon-service", bouchonCible, BouchonServiceDto.class);
                    log.info("Bouchon créé = {}", bcs.getId());
                }


            } else {
                log.info("Création du bouchon {}", bouchonsSource);
            }
        }

    }

    @PostConstruct
    public void postConstruct() {
        log.info("post {}", this);
    }
}
