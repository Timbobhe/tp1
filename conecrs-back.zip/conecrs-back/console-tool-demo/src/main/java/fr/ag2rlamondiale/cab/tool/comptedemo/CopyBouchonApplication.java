package fr.ag2rlamondiale.cab.tool.comptedemo;

import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class CopyBouchonApplication {

    public static void main(String[] args) {
        new SpringApplicationBuilder(CopyBouchonApplication.class)
                .web(WebApplicationType.NONE)
                .run(args);
    }
}
