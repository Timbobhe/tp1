package fr.ag2rlamondiale.cab.tool.comptedemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class CopyBouchonLaunchParams {

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

    @Bean
    public CopyBouchonConfig copyBouchonConfig() {
        return CopyBouchonConfig.builder()
                .dummy(false)
                .idCompteDemo(1L)
                .urlSource("http://a1791-cab.kdev/api/public")
                .urlCible("http://a1791-cab.kqua/api/public")
//                .urlCible("http://a1791-cab.kqua/api/public")
                .build();
    }

//    @Bean
//    public CopyBouchonConfig copyBouchonConfig() {
//        return CopyBouchonConfig.builder()
//                .dummy(false)
//                .idCompteDemo(1L)
//                .urlSource("http://localhost:8085/api/public")
//                .urlCible("http://localhost:8085/api/public")
//                .build();
//    }

}
