package fr.ag2rlamondiale.cab.tool.comptedemo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * http://a1791-cab.kdev/api/unsecure/compte-demo
 * http://a1791-cab.krec/api/unsecure/compte-demo
 * http://a1791-cab.kqua/api/unsecure/compte-demo
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CopyBouchonConfig {
    private boolean dummy;

    private String urlSource;
    private String urlCible;

    private Long idCompteDemo;
}
