package fr.ag2rlamondiale.cab.pp.api.unsecure;

import fr.ag2rlamondiale.cab.pp.business.IPersonnePhysiqueFacade;
import fr.ag2rlamondiale.cab.pp.dto.RechercheSalarieParametersDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.runners.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PersonnePhysiqueRestControllerTest {
    @InjectMocks
    @Spy
    PersonnePhysiqueRestController personnePhysiqueRestController;

    @Mock
    private IPersonnePhysiqueFacade personnePhysiqueFacade;

    @Test
    public void rechercherPersonnesPhysiques() {
        personnePhysiqueRestController.rechercherPersonnesPhysiques(new RechercheSalarieParametersDto());
        verify(personnePhysiqueRestController, times(1)).rechercherPersonnesPhysiques(any(RechercheSalarieParametersDto.class));
    }
}
