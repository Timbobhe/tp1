package fr.ag2rlamondiale.cab.pp.business.impl;

import fr.ag2rlamondiale.cab.pp.dto.RechercheSalarieParametersDto;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.IRechercherPersonnePhysiqueClient;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.RechercherPPIn;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.SalarieDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonnePhysiqueFacadeImplTest {
    @InjectMocks
    @Spy
    PersonnePhysiqueFacadeImpl personnePhysiqueFacade;

    @Mock
    private IRechercherPersonnePhysiqueClient rechercherPersonnePhysiqueClient;

    @Mock
    private IRechercherHabiliPersClient rechercherHabiliPersClient;


    @Test
    public void rechercherPersonnePhysique_ere_by_idGdi() {
        // Given
        Mockito.when(rechercherHabiliPersClient.rechercherHabilitation(Matchers.any(RechercherHabiliIn.class))).thenReturn(getPersonnePhysique(true));
        Mockito.when(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(Matchers.any(RechercherPPIn.class))).thenReturn(getSalaries(true));

        // When
        List<SalarieDto> salarieDtos = personnePhysiqueFacade.rechercherPersonnePhysique(getSalarieParameters("idGdi", null, null, null, null, true, false));

        // Then
        assertNotNull(salarieDtos);
        assertEquals("C13263", salarieDtos.get(0).getIdPersonne());
        assertEquals("ABADIE", salarieDtos.get(0).getNom());
        assertEquals("ANNE MARIE", salarieDtos.get(0).getPrenom());
    }

    @Test
    public void rechercherPersonnePhysique_mdp_by_idGdi() {
        // Given
        Mockito.when(rechercherHabiliPersClient.rechercherHabilitation(Matchers.any(RechercherHabiliIn.class))).thenReturn(getPersonnePhysique(false));
        Mockito.when(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(Matchers.any(RechercherPPIn.class))).thenReturn(getSalaries(false));

        // When
        List<SalarieDto> salarieDtos = personnePhysiqueFacade.rechercherPersonnePhysique(getSalarieParameters("idGdi", null, null, null, null, false, true));

        // Then
        assertNotNull(salarieDtos);
        assertEquals("C13263", salarieDtos.get(0).getIdPersonne());
        assertEquals("FRAN IS", salarieDtos.get(0).getNom());
        assertEquals("JEAN JACQUES", salarieDtos.get(0).getPrenom());
    }

    @Test
    public void rechercherPersonnePhysique_ere_by_idPersonne() {
        // Given
        Mockito.when(rechercherHabiliPersClient.rechercherHabilitation(Matchers.any(RechercherHabiliIn.class))).thenReturn(getPersonnePhysique(true));
        Mockito.when(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(Matchers.any(RechercherPPIn.class))).thenReturn(getSalaries(true));

        // When
        List<SalarieDto> salarieDtos = personnePhysiqueFacade.rechercherPersonnePhysique(getSalarieParameters(null, "idPersonne", null, null, null, true, false));

        // Then
        assertNotNull(salarieDtos);
        assertEquals("C13263", salarieDtos.get(0).getIdPersonne());
        assertEquals("ABADIE", salarieDtos.get(0).getNom());
        assertEquals("ANNE MARIE", salarieDtos.get(0).getPrenom());
        assertEquals("idGdi2", salarieDtos.get(0).getIdGdi());
    }

    @Test
    public void rechercherPersonnePhysique_mdp_by_idPersonne() {
        // Given
        Mockito.when(rechercherHabiliPersClient.rechercherHabilitation(Matchers.any(RechercherHabiliIn.class))).thenReturn(getPersonnePhysique(false));
        Mockito.when(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(Matchers.any(RechercherPPIn.class))).thenReturn(getSalaries(false));

        // When
        List<SalarieDto> salarieDtos = personnePhysiqueFacade.rechercherPersonnePhysique(getSalarieParameters(null, "idPersonne", null, null, null, false, true));

        // Then
        assertNotNull(salarieDtos);
        assertEquals("C13263", salarieDtos.get(0).getIdPersonne());
        assertEquals("FRAN IS", salarieDtos.get(0).getNom());
        assertEquals("JEAN JACQUES", salarieDtos.get(0).getPrenom());
        assertEquals("idGdi2", salarieDtos.get(0).getIdGdi());
    }

    @Test
    public void rechercherPersonnePhysique_mdp_by_dateNaissance() {
        // Given
        Mockito.when(rechercherHabiliPersClient.rechercherHabilitation(Matchers.any(RechercherHabiliIn.class))).thenReturn(getPersonnePhysique(false));
        Mockito.when(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(Matchers.any(RechercherPPIn.class))).thenReturn(getSalaries(false));

        // When
        List<SalarieDto> salarieDtos = personnePhysiqueFacade.rechercherPersonnePhysique(getSalarieParameters(null, null, null, null, new Date(), false, true));

        // Then
        assertNotNull(salarieDtos);
        assertEquals("C13263", salarieDtos.get(0).getIdPersonne());
        assertEquals("FRAN IS", salarieDtos.get(0).getNom());
        assertEquals("JEAN JACQUES", salarieDtos.get(0).getPrenom());
        assertEquals("idGdi2", salarieDtos.get(0).getIdGdi());
    }

    private PersonnePhysique getPersonnePhysique(boolean isEre) {
        PersonnePhysique personnePhysique = new PersonnePhysique();
        if (isEre) {
            personnePhysique.setNumeroPersonneEre("P4393784");
        } else {
            personnePhysique.setNumeroPersonneMdpro("P4393784");
        }
        personnePhysique.setNom("FRAN IS");
        personnePhysique.setPrenom("JEAN JACQUES");
        personnePhysique.setIdGdi("idGdi2");
        return personnePhysique;
    }

    private RechercheSalarieParametersDto getSalarieParameters(String idGdi, String idPersonne, String nom, String prenom, Date dateNaissance, boolean isEre, boolean isMdp) {
        RechercheSalarieParametersDto dto = new RechercheSalarieParametersDto();
        dto.setIdGdi(idGdi);
        dto.setIdPersonne(idPersonne);
        dto.setNom(nom);
        dto.setPrenom(prenom);
        dto.setDateNaissance(dateNaissance);
        dto.setTypeSalarie(isEre);
        dto.setTypeSocietaire(isMdp);
        return dto;
    }

    private List<SalarieDto> getSalaries(boolean isEre) {
        SalarieDto salarieDto = new SalarieDto();
        if (isEre) {
            salarieDto.setIdPersonne("C13263");
            salarieDto.setNom("ABADIE");
            salarieDto.setPrenom("ANNE MARIE");
            salarieDto.setTypePersonne("ERE");
        } else {
            salarieDto.setIdPersonne("C13263");
            salarieDto.setNom("FRAN IS");
            salarieDto.setPrenom("JEAN JACQUES");
            salarieDto.setTypePersonne("MDP");
        }

        return List.of(salarieDto);
    }
}
