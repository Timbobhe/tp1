package fr.ag2rlamondiale.cab.pp.business.impl;

import fr.ag2rlamondiale.cab.pp.business.IPersonnePhysiqueFacade;
import fr.ag2rlamondiale.cab.pp.dto.RechercheSalarieParametersDto;
import fr.ag2rlamondiale.trm.client.rest.IRechercherHabiliPersClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.habilitation.RechercherHabiliIn;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.pfs.personnephysique.client.rest.IRechercherPersonnePhysiqueClient;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.RechercherPPIn;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.SalarieDto;
import fr.ag2rlamondiale.trm.security.NoAuthRequired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PersonnePhysiqueFacadeImpl implements IPersonnePhysiqueFacade {
    @Autowired
    private IRechercherPersonnePhysiqueClient rechercherPersonnePhysiqueClient;

    @Autowired
    private IRechercherHabiliPersClient rechercherHabiliPersClient;


    @Override
    @NoAuthRequired
    public List<SalarieDto> rechercherPersonnePhysique(RechercheSalarieParametersDto parameters) {
        List<SalarieDto> salaries = new ArrayList<>();
        RechercherPPIn rechercherPPIn = new RechercherPPIn();
        if (parameters.getIdGdi() != null) {
            RechercherHabiliIn in = new RechercherHabiliIn();
            in.setIdGdi(parameters.getIdGdi());
            PersonnePhysique pp = rechercherHabilitation(in);
            if (pp == null) {
                return salaries;
            }
            if (parameters.isTypeSalarie() && pp.getNumeroPersonneEre() != null) {
                rechercherPPIn.setIdPersPhys(pp.getNumeroPersonneEre());
                rechercherPPIn.setTypeSalarie(parameters.isTypeSalarie());

                salaries.addAll(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(rechercherPPIn));
            }
            if (parameters.isTypeSocietaire() && pp.getNumeroPersonneMdpro() != null) {
                rechercherPPIn.setIdPersPhys(pp.getNumeroPersonneMdpro());
                rechercherPPIn.setTypeSocietaire(parameters.isTypeSocietaire());

                salaries.addAll(rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(rechercherPPIn));
            }

            return salaries;
        } else if (parameters.getIdPersonne() != null) {
            rechercherPPIn.setIdPersPhys(parameters.getIdPersonne());
            rechercherPPIn.setTypeSalarie(parameters.isTypeSalarie());
            rechercherPPIn.setTypeSocietaire(parameters.isTypeSocietaire());
        } else if (parameters.getNom() != null || parameters.getPrenom() != null || parameters.getDateNaissance() != null) {
            rechercherPPIn.setNom(parameters.getNom());
            rechercherPPIn.setPrenom(parameters.getPrenom());
            rechercherPPIn.setTypeSalarie(parameters.isTypeSalarie());
            rechercherPPIn.setTypeSocietaire(parameters.isTypeSocietaire());
        }

        salaries = rechercherPersonnePhysiqueClient.rechercherPersonnePhysique(rechercherPPIn);

        if (parameters.getIdGdi() != null) {
            for (SalarieDto s : salaries) {
                s.setIdGdi(parameters.getIdGdi());
            }
        } else {
            RechercherHabiliIn in = new RechercherHabiliIn();
            for (SalarieDto s : salaries) {
                in.setCodeSilo(CodeSiloType.valueOf(s.getTypePersonne()));
                in.setNumeroPersonne(s.getIdPersonne());
                s.setIdGdi(rechercherHabilitation(in) != null ? rechercherHabilitation(in).getIdGdi() : null);
            }
        }
        return salaries;
    }

    private PersonnePhysique rechercherHabilitation(RechercherHabiliIn in) {
        return rechercherHabiliPersClient.rechercherHabilitation(in);
    }
}
