package fr.ag2rlamondiale.cab.pp.dto;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class RechercheSalarieParametersDto implements Serializable {
    private static final long serialVersionUID = -43418794107176417L;

    private String idGdi;

    private String idPersonne;

    private boolean isTypeSalarie;

    private boolean isTypeSocietaire;

    private String nom;

    private String prenom;

    private Date dateNaissance;
}
