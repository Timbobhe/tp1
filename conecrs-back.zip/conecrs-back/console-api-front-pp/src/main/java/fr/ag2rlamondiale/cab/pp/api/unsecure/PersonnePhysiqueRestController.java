package fr.ag2rlamondiale.cab.pp.api.unsecure;

import fr.ag2rlamondiale.cab.pp.business.IPersonnePhysiqueFacade;
import fr.ag2rlamondiale.cab.pp.dto.RechercheSalarieParametersDto;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.SalarieDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping({"/unsecure", "/public"})
public class PersonnePhysiqueRestController {
    @Autowired
    private IPersonnePhysiqueFacade personnePhysiqueFacade;

    @PostMapping("/personne-physique/search")
    public ResponseEntity<List<SalarieDto>> rechercherPersonnesPhysiques(@RequestBody RechercheSalarieParametersDto parameters) {
        List<SalarieDto> salaries = personnePhysiqueFacade.rechercherPersonnePhysique(parameters);
        return ResponseEntity.status(HttpStatus.OK).body(salaries);
    }
}
