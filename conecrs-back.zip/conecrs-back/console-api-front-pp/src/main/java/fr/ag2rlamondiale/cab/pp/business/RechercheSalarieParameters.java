package fr.ag2rlamondiale.cab.pp.business;

import java.io.Serializable;

public interface RechercheSalarieParameters extends Serializable {
}
