package fr.ag2rlamondiale.cab.pp.config;

import fr.ag2rlamondiale.trm.pfs.personnephysique.PfsPersonnePhysiqueConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({PfsPersonnePhysiqueConfig.class})
public class ConsoleApiFrontPPConfig {
}
