package fr.ag2rlamondiale.cab.pp.business;

import fr.ag2rlamondiale.cab.pp.dto.RechercheSalarieParametersDto;
import fr.ag2rlamondiale.trm.pfs.personnephysique.dto.SalarieDto;

import java.util.List;

public interface IPersonnePhysiqueFacade {
    List<SalarieDto> rechercherPersonnePhysique(RechercheSalarieParametersDto parameters);
}
