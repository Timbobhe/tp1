package fr.ag2rlamondiale.cab.pm.api.unsecure;

import fr.ag2rlamondiale.cab.pm.business.IPersonneMoraleFacade;
import fr.ag2rlamondiale.cab.pm.dto.RechercheEntrepriseParametersDto;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.EntrepriseDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping({"/unsecure", "/public"})
public class PersonneMoraleRestController {
    @Autowired
    private IPersonneMoraleFacade personneMoraleFacade;

    @PostMapping("/personne-morale/search")
    public ResponseEntity<List<EntrepriseDto>> rechercherPersonneMorale(@RequestBody RechercheEntrepriseParametersDto parameters) {
        List<EntrepriseDto> salaries = personneMoraleFacade.rechercherPersonneMorale(parameters);
        return ResponseEntity.status(HttpStatus.OK).body(salaries);
    }
}
