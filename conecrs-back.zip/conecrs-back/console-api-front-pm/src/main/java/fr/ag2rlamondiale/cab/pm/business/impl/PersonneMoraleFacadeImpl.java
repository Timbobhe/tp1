package fr.ag2rlamondiale.cab.pm.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.cab.pm.business.IPersonneMoraleFacade;
import fr.ag2rlamondiale.cab.pm.dto.RechercheEntrepriseParametersDto;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.Adherente;
import fr.ag2rlamondiale.trm.exception.TechnicalRuntimeException;
import fr.ag2rlamondiale.trm.pfs.personnemorale.client.rest.IRechercherPersonneMoraleClient;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.EntrepriseDto;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.RechercherPMIn;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.RoleCtrPersDto;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.TypeEntreprise;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@Slf4j
@Service
public class PersonneMoraleFacadeImpl implements IPersonneMoraleFacade {
    private static final String CODE_ROLE_CTR_ADHERENTE = "15";

    private static final String CODE_ROLE_CTR_CONTRACTANTE = "1";

    private static final String CODE_FILIALE_FONDS_DE_PENSION = "FDP";

    @Autowired
    private IRechercherPersonneMoraleClient rechercherPersonneMoraleClient;

    @Autowired
    private IContratsClient contratsClient;


    @Override
    public List<EntrepriseDto> rechercherPersonneMorale(RechercheEntrepriseParametersDto parameters) {
        List<EntrepriseDto> entreprisestoDisplay = new ArrayList<>();
        RechercherPMIn rechercherPMIn = new RechercherPMIn();
        if (parameters.getNumeroContrat() != null) {
            return rechercheEntreprisesParIdContrat(parameters);
        } else if (parameters.getIdGdi() != null || parameters.getIdPersonneMorale() != null) {
            rechercherPMIn.setIdGDI(parameters.getIdGdi() != null ? parameters.getIdGdi().trim().toUpperCase() : null);
            rechercherPMIn.setIdPers(parameters.getIdPersonneMorale() != null ? parameters.getIdPersonneMorale().trim().toUpperCase() : null);

            List<EntrepriseDto> entreprises = rechercherPersonneMoraleClient.rechercherPersonneMorale(rechercherPMIn);

            for (EntrepriseDto entreprise : entreprises) {
                if (CollectionUtils.isNotEmpty(entreprise.getRoleCtrPers())) {
                    String idContrat;
                    String codeRoleCtr;
                    // Récuperation de(s) CONTRAT(S)
                    for (RoleCtrPersDto roleCtrPers : entreprise.getRoleCtrPers()) {
                        idContrat = roleCtrPers.getIdentSiloCtr().getIdSilo();
                        codeRoleCtr = roleCtrPers.getCodeRoleCtr();

                        entrepriseByRoleCtrPers(parameters, entreprisestoDisplay, entreprise, idContrat, codeRoleCtr);
                    }
                }
            }
        }
        return entreprisestoDisplay;
    }

    private void entrepriseByRoleCtrPers(RechercheEntrepriseParametersDto parameters, List<EntrepriseDto> entreprisestoDisplay, EntrepriseDto entreprise, String idContrat, String codeRoleCtr) {
        if ((CODE_ROLE_CTR_ADHERENTE.equals(codeRoleCtr) || CODE_ROLE_CTR_CONTRACTANTE.equals(codeRoleCtr)) && isContractAuthorized(idContrat)) {
            try {
                ContratGeneral contratGeneral = contratsClient.consulterContratGenerales(new ConsulterContratGeneralesDto(idContrat, CodeSiloType.ERE));

                // Si l'utilisateur n'a pas le rôle "Fonds de Pension" il ne peut
                // pas voir les contrats dont la filiale est FDP
                if (isUserAllowedOnContract(contratGeneral, parameters.isHasCondifentialContratAuthority())) {
                    TypeEntreprise typeEntreprise = TypeEntreprise.ADHERENTE;

                    if (CODE_ROLE_CTR_CONTRACTANTE.equals(codeRoleCtr)) {
                        typeEntreprise = TypeEntreprise.CONTRACTANTE;
                    }

                    entreprisestoDisplay.add(new EntrepriseDto(entreprise.getIdPersonneMorale(), idContrat, null, entreprise.getRaisonSociale(), typeEntreprise, entreprise.getIdGdis(), entreprise.getRoleCtrPers()));
                }
            } catch (TechnicalException e) {
                log.error("Erreur lors de la consultation du contrat \"{}\"", idContrat, e);
                throw new TechnicalRuntimeException(e);
            }
        }
    }

    private List<EntrepriseDto> rechercheEntreprisesParIdContrat(RechercheEntrepriseParametersDto parameters) {
        List<EntrepriseDto> entreprisesToDisplay = new ArrayList<>();
        List<String> idGdis;
        String idContrat = parameters.getNumeroContrat().trim().toUpperCase();

        if (isContractAuthorized(idContrat)) {
            try {
                ContratGeneral contratGeneral = contratsClient.consulterContratGenerales(new ConsulterContratGeneralesDto(idContrat, CodeSiloType.ERE));

                // Si l'utilisateur n'a pas le rôle "Fonds de Pension" il ne peut
                // pas voir les contrats dont la filiale est FDP
                if (isUserAllowedOnContract(contratGeneral, parameters.isHasCondifentialContratAuthority())) {
                    if (contratGeneral.getContractante() != null) {
                        idGdis = getIdGdis(contratGeneral.getIdContractante());
                        entreprisesToDisplay.add(new EntrepriseDto(contratGeneral.getIdContractante(), contratGeneral.getId(), contratGeneral.getReferenceExterne(), contratGeneral.getContractante(), TypeEntreprise.CONTRACTANTE, idGdis, null));

                    }

                    if (contratGeneral.getAdherentes() != null) {
                        for (Adherente adherente : contratGeneral.getAdherentes()) {
                            idGdis = getIdGdis(adherente.getId());
                            entreprisesToDisplay.add(new EntrepriseDto(adherente.getId(), contratGeneral.getId(), contratGeneral.getReferenceExterne(), adherente.getRaisonSociale(), TypeEntreprise.ADHERENTE, idGdis, null));
                        }
                    }
                }
            } catch (TechnicalException e) {
                throw new TechnicalRuntimeException(e);
            }
        }
        return entreprisesToDisplay;
    }

    /**
     * Filtre sur les types de contrats pour ne garder que ceux définis dans l'application :
     */
    private boolean isContractAuthorized(String idContrat) {
        return idContrat.startsWith("RG") || idContrat.startsWith("RL") || idContrat.startsWith("RK") || idContrat.startsWith("RP") || idContrat.startsWith("RR");
    }

    /**
     * Récupère les idGdis attachés à une Personne Morale.
     */
    private List<String> getIdGdis(String idPersonneMorale) {
        RechercherPMIn in = new RechercherPMIn();
        in.setIdPers(idPersonneMorale);
        return rechercherPersonneMoraleClient.rechercherPersonneMorale(in).stream().findFirst().map(EntrepriseDto::getIdGdis).orElseThrow(NoSuchElementException::new);
    }


    /**
     * Vérifie si l'utilisateur a le droit de consulter le contrat défini. Si l'utilisateur n'a pas
     * le rôle correspondant au type de contrat confidentiel défini il ne peut pas les consulter.
     *
     * @param contrat                         Le contrat à vérifier
     * @param hasCondifentialContratAuthority Boolean définissant si l'utilisateur a le droit de
     *                                        consulter les contrats confidentiels (correspondants au codeFilialeConfidential)
     * @return
     */
    private boolean isUserAllowedOnContract(ContratGeneral contrat, boolean hasCondifentialContratAuthority) {
        return hasCondifentialContratAuthority || (contrat != null && contrat.getCodeFiliale() != null && !PersonneMoraleFacadeImpl.CODE_FILIALE_FONDS_DE_PENSION.equals(contrat.getCodeFiliale()));
    }
}
