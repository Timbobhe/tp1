package fr.ag2rlamondiale.cab.pm.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class RechercheEntrepriseParametersDto implements Serializable {
    private static final long serialVersionUID = 8407528868371621325L;

    private String idGdi;

    private String idPersonneMorale;

    private String numeroContrat;

    private boolean hasCondifentialContratAuthority;
}
