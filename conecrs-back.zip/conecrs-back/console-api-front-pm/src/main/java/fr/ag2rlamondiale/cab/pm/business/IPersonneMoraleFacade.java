package fr.ag2rlamondiale.cab.pm.business;

import fr.ag2rlamondiale.cab.pm.dto.RechercheEntrepriseParametersDto;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.EntrepriseDto;

import java.util.List;

public interface IPersonneMoraleFacade {
    List<EntrepriseDto> rechercherPersonneMorale(RechercheEntrepriseParametersDto parameters);
}
