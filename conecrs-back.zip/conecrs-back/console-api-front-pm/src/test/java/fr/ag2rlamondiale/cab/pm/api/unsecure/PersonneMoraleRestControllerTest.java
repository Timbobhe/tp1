package fr.ag2rlamondiale.cab.pm.api.unsecure;

import fr.ag2rlamondiale.cab.pm.business.IPersonneMoraleFacade;
import fr.ag2rlamondiale.cab.pm.dto.RechercheEntrepriseParametersDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(MockitoJUnitRunner.class)
public class PersonneMoraleRestControllerTest {
    @InjectMocks
    @Spy
    PersonneMoraleRestController personneMoraleRestController;

    @Mock
    private IPersonneMoraleFacade personneMoraleFacade;

    @Test
    public void rechercherPersonneMorale() {
        personneMoraleRestController.rechercherPersonneMorale(new RechercheEntrepriseParametersDto());
        verify(personneMoraleRestController, times(1)).rechercherPersonneMorale(any(RechercheEntrepriseParametersDto.class));
    }
}
