package fr.ag2rlamondiale.cab.pm.business.impl;

import com.ag2r.common.exceptions.TechnicalException;
import fr.ag2rlamondiale.cab.pm.dto.RechercheEntrepriseParametersDto;
import fr.ag2rlamondiale.trm.client.soap.IContratsClient;
import fr.ag2rlamondiale.trm.domain.contrat.ConsulterContratGeneralesDto;
import fr.ag2rlamondiale.trm.domain.contrat.ContratGeneral;
import fr.ag2rlamondiale.trm.domain.contrat.contratgenerale.Adherente;
import fr.ag2rlamondiale.trm.pfs.personnemorale.client.rest.IRechercherPersonneMoraleClient;
import fr.ag2rlamondiale.trm.pfs.personnemorale.dto.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.*;

@RunWith(MockitoJUnitRunner.class)
public class PersonneMoraleFacadeImplTest {
    @InjectMocks
    @Spy
    PersonneMoraleFacadeImpl personneMoraleFacade;

    @Mock
    private IRechercherPersonneMoraleClient rechercherPersonneMoraleClient;

    @Mock
    private IContratsClient contratsClient;


    @Test
    public void rechercherPersonneMorale_with_contractante_by_numeroContrat() throws TechnicalException {
        // Given
        Mockito.when(contratsClient.consulterContratGenerales(Matchers.any(ConsulterContratGeneralesDto.class))).thenReturn(getContratGeneral(true, false));
        Mockito.when(rechercherPersonneMoraleClient.rechercherPersonneMorale(Matchers.any(RechercherPMIn.class))).thenReturn(getEntreprises());

        // When
        List<EntrepriseDto> entrepriseDtos = personneMoraleFacade.rechercherPersonneMorale(getEntrepriseParameters("RR152289321", null, true));

        // Then
        assertNotNull(entrepriseDtos);
        assertEquals("idContractante", entrepriseDtos.get(0).getIdPersonneMorale());
        assertEquals("EDF", entrepriseDtos.get(0).getRaisonSociale());
        assertEquals(TypeEntreprise.CONTRACTANTE, entrepriseDtos.get(0).getTypeEntreprise());
        assertEquals(List.of("1mgu13"), entrepriseDtos.get(0).getIdGdis());
        assertEquals("RR152289321", entrepriseDtos.get(0).getIdContrat());
    }


    @Test
    public void rechercherPersonneMorale_with_adherente_by_numeroContrat() throws TechnicalException {
        // Given
        Mockito.when(contratsClient.consulterContratGenerales(Matchers.any(ConsulterContratGeneralesDto.class))).thenReturn(getContratGeneral(false, true));
        Mockito.when(rechercherPersonneMoraleClient.rechercherPersonneMorale(Matchers.any(RechercherPMIn.class))).thenReturn(getEntreprises());

        // When
        List<EntrepriseDto> entrepriseDtos = personneMoraleFacade.rechercherPersonneMorale(getEntrepriseParameters("RR152289321", null, true));

        // Then
        assertNotNull(entrepriseDtos);
        assertEquals("idAdherente", entrepriseDtos.get(0).getIdPersonneMorale());
        assertEquals("Sowee", entrepriseDtos.get(0).getRaisonSociale());
        assertEquals(TypeEntreprise.ADHERENTE, entrepriseDtos.get(0).getTypeEntreprise());
        assertEquals(List.of("1mgu13"), entrepriseDtos.get(0).getIdGdis());
        assertEquals("RR152289321", entrepriseDtos.get(0).getIdContrat());
    }


    @Test
    public void rechercherPersonneMorale_by_idPersonneMorale() throws TechnicalException {
        // Given
        Mockito.when(contratsClient.consulterContratGenerales(Matchers.any(ConsulterContratGeneralesDto.class))).thenReturn(getContratGeneral(true, false));
        Mockito.when(rechercherPersonneMoraleClient.rechercherPersonneMorale(Matchers.any(RechercherPMIn.class))).thenReturn(getEntreprises());

        // When
        List<EntrepriseDto> entrepriseDtos = personneMoraleFacade.rechercherPersonneMorale(getEntrepriseParameters(null, "S6224943", true));

        // Then
        assertNotNull(entrepriseDtos);
        assertEquals("S6224943", entrepriseDtos.get(0).getIdPersonneMorale());
        assertEquals(TypeEntreprise.CONTRACTANTE, entrepriseDtos.get(0).getTypeEntreprise());
        assertEquals(List.of("1mgu13"), entrepriseDtos.get(0).getIdGdis());
        assertEquals("RR152289321", entrepriseDtos.get(0).getIdContrat());

        assertNotNull(entrepriseDtos);
        assertEquals("S6224943", entrepriseDtos.get(1).getIdPersonneMorale());
        assertEquals(TypeEntreprise.ADHERENTE, entrepriseDtos.get(1).getTypeEntreprise());
        assertEquals(List.of("1mgu13"), entrepriseDtos.get(1).getIdGdis());
        assertEquals("RG152289322", entrepriseDtos.get(1).getIdContrat());

    }

    private ContratGeneral getContratGeneral(boolean hasContractante, boolean hasAdherente) {
        ContratGeneral contratGeneral = new ContratGeneral();
        contratGeneral.setId("RR152289321");
        contratGeneral.setCodeFiliale("FDP");
        if (hasContractante) {
            contratGeneral.setContractante("EDF");
            contratGeneral.setIdContractante("idContractante");
        }

        Adherente adherente = new Adherente();
        adherente.setRaisonSociale("Sowee");
        adherente.setId("idAdherente");
        contratGeneral.setAdherentes(hasAdherente ? List.of(adherente) : null);

        return contratGeneral;
    }


    private RechercheEntrepriseParametersDto getEntrepriseParameters(String numeroContrat, String idPersonneMorale, boolean hasCondifentialContratAuthority) {
        RechercheEntrepriseParametersDto dto = new RechercheEntrepriseParametersDto();
        dto.setNumeroContrat(numeroContrat);
        dto.setIdPersonneMorale(idPersonneMorale);
        dto.setHasCondifentialContratAuthority(hasCondifentialContratAuthority);

        return dto;
    }

    private List<EntrepriseDto> getEntreprises() {
        EntrepriseDto entrepriseDto = new EntrepriseDto();
        entrepriseDto.setIdPersonneMorale("S6224943");
        entrepriseDto.setIdGdis(List.of("1mgu13"));

        RoleCtrPersDto roleCtrPersDto = new RoleCtrPersDto();
        IdentSiloCtrDto identSiloCtrDto = new IdentSiloCtrDto();
        identSiloCtrDto.setIdSilo("RR152289321");

        roleCtrPersDto.setIdentSiloCtr(identSiloCtrDto);
        roleCtrPersDto.setCodeRoleCtr("1");


        RoleCtrPersDto roleCtrPersDto2 = new RoleCtrPersDto();
        IdentSiloCtrDto identSiloCtrDto2 = new IdentSiloCtrDto();
        identSiloCtrDto2.setIdSilo("RG152289322");

        roleCtrPersDto2.setIdentSiloCtr(identSiloCtrDto2);
        roleCtrPersDto2.setCodeRoleCtr("15");

        entrepriseDto.setRoleCtrPers(List.of(roleCtrPersDto, roleCtrPersDto2));

        return List.of(entrepriseDto);
    }
}
