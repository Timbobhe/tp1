package fr.ag2rlamondiale.cab;

public class Empty {
}
