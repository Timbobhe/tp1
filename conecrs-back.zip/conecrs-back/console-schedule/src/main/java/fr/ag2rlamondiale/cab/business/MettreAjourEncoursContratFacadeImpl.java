package fr.ag2rlamondiale.cab.business;

import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.dto.updateencours.ResultatUpdateEncoursContratDto;
import fr.ag2rlamondiale.cab.dto.updateencours.UpdateEncoursContratParamsDto;
import fr.ag2rlamondiale.cab.dto.updateencours.UpdateEncoursContratStatus;
import fr.ag2rlamondiale.cab.dto.updateencours.UpdateEncoursContratStatusDto;
import fr.ag2rlamondiale.cab.repository.IBouchonServiceRepository;
import fr.ag2rlamondiale.cab.utils.TempsUtils;
import fr.ag2rlamondiale.trm.client.soap.ICalculerEncoursContratClient;
import fr.ag2rlamondiale.trm.domain.CodeSiloType;
import fr.ag2rlamondiale.trm.domain.encours.CalculerEncoursContratDto;
import fr.ag2rlamondiale.trm.security.UserContext;
import fr.ag2rlamondiale.trm.security.UserContextHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class MettreAjourEncoursContratFacadeImpl {

    @Autowired
    private IBouchonServiceRepository bouchonServiceRepository;

    @Autowired
    private ICalculerEncoursContratClient calculerEncoursContratClient;

    @Autowired
    private UserContextHolder userContextHolder;


    @Value("ere.consoleadmin.ws.soap.idgdi")
    private String idgdi;


    @Scheduled(cron = "0 0 9 * * MON-FRI")
    public void process() {
        process(UpdateEncoursContratParamsDto.builder()
                .force(false)
                .build());
    }

    public ResultatUpdateEncoursContratDto process(UpdateEncoursContratParamsDto params) {
        ResultatUpdateEncoursContratDto resultat = new ResultatUpdateEncoursContratDto();
        List<BouchonService> bservices = bouchonServiceRepository.findBouchonServicesByIdService("GestContratTer_2/CalculerEncoursContrat_3");
        for (BouchonService bservice : bservices) {
            if (params.isForce() || bservice.getDateMiseAjour() == null || TempsUtils.isDatePasseeUneSemaine(bservice.getDateMiseAjour())) {
                var dto = new CalculerEncoursContratDto();
                dto.setIdAssure(bservice.getIdRequete().substring(0, bservices.get(0).getIdRequete().indexOf("-")));
                dto.setCodeSiloType(CodeSiloType.ERE);
                createUserContext();
                resultat.add(majResponseCalculerEncours(dto, bservice));
            } else {
                resultat.setStatus(bservice.getId(), UpdateEncoursContratStatus.NONE, "Date de mise \u00E0 jour = " + bservice.getDateMiseAjour());
            }

        }
        return resultat;
    }

    private UpdateEncoursContratStatusDto majResponseCalculerEncours(CalculerEncoursContratDto dto, BouchonService bservice) {
        try {
            String xmlResponse = calculerEncoursContratClient.getXmlResponseCalculerEncoursContrat(dto);
            if (xmlResponse != null) {
                bservice.setDateMiseAjour(null);
                bservice.setVaRep("<?xml version=\"1.0\"?>" + xmlResponse);
                log.info("mise à jour de la reponse du bouchon **:{}, {}", bservice.getId(), xmlResponse);
                bouchonServiceRepository.save(bservice);
                return UpdateEncoursContratStatusDto.builder()
                        .idBouchon(bservice.getId())
                        .status(UpdateEncoursContratStatus.OK)
                        .build();
            } else {
                return UpdateEncoursContratStatusDto.builder()
                        .idBouchon(bservice.getId())
                        .status(UpdateEncoursContratStatus.KO)
                        .message("Retour du service vide")
                        .build();
            }
        } catch (Exception e) {
            log.error("Service calculerEncoursContrat en erreur", e);
            return UpdateEncoursContratStatusDto.builder()
                    .idBouchon(bservice.getId())
                    .status(UpdateEncoursContratStatus.KO)
                    .message("Appel du service en erreur " + e.getMessage())
                    .build();
        }
    }

    private void createUserContext() {
        var userContext = new UserContext();
        userContext.setIdGdi(idgdi);
        userContext.setForSupervision(true);
        userContextHolder.set(userContext);
    }
}
