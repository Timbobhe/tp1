package fr.ag2rlamondiale.cab.dto.updateencours;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class ResultatUpdateEncoursContratDto {
    private List<UpdateEncoursContratStatusDto> resultat = new ArrayList<>();

    public void setStatus(Long idBouchonService, UpdateEncoursContratStatus status, String message) {
        add(UpdateEncoursContratStatusDto.builder()
                .idBouchon(idBouchonService)
                .status(status)
                .message(message)
                .build());
    }

    public boolean add(UpdateEncoursContratStatusDto updateEncoursContratStatusDto) {
        return resultat.add(updateEncoursContratStatusDto);
    }
}
