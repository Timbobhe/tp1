package fr.ag2rlamondiale.cab.api.unsecure;

import fr.ag2rlamondiale.cab.business.MettreAjourEncoursContratFacadeImpl;
import fr.ag2rlamondiale.cab.dto.updateencours.ResultatUpdateEncoursContratDto;
import fr.ag2rlamondiale.cab.dto.updateencours.UpdateEncoursContratParamsDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/public/schedules")
public class SchedulesRestController {

    @Autowired
    private MettreAjourEncoursContratFacadeImpl mettreAjourEncoursContrat;

    // http://localhost:8085/api/public/schedules/update-encours-contrat
    @GetMapping("/update-encours-contrat")
    public ResultatUpdateEncoursContratDto updateEncoursContrat() {
        return mettreAjourEncoursContrat.process(UpdateEncoursContratParamsDto.builder().force(true).build());
    }
}
