package fr.ag2rlamondiale.cab.utils;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;

public class TempsUtils {

    /**
     * Vérifie si une date est passée, sans tenir compte des Heures
     *
     * @param date à vérifier
     * @return true si la date est passée d'une semaine, false sinon
     */
    public static boolean isDatePasseeUneSemaine(Date date) {
        final LocalDate localDate = date.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();
        final long days = ChronoUnit.DAYS.between(localDate, LocalDate.now());
        return days >= 7;
    }
}
