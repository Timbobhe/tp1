package fr.ag2rlamondiale.cab.dto.updateencours;

public enum UpdateEncoursContratStatus {
    OK, KO, NONE
}
