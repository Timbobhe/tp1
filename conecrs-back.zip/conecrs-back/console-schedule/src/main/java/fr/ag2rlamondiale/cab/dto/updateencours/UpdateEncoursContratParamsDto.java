package fr.ag2rlamondiale.cab.dto.updateencours;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpdateEncoursContratParamsDto {
	private boolean force;
}
