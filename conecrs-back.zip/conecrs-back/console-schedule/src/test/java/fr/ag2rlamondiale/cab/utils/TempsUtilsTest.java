package fr.ag2rlamondiale.cab.utils;

import fr.ag2rlamondiale.trm.utils.DateUtils;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TempsUtilsTest {

    @Test
    void test_isDatePasseeUneSemaine() {
        final Date dateNow = DateUtils.todayMoreDays(0);
        assertFalse(TempsUtils.isDatePasseeUneSemaine(dateNow));
        assertFalse(TempsUtils.isDatePasseeUneSemaine(new Date()));

        final Date datePassee7jours = DateUtils.todayMoreDays(-7);
        assertTrue(TempsUtils.isDatePasseeUneSemaine(datePassee7jours));

        final Date dateFuture1jour = DateUtils.todayMoreDays(1);
        assertFalse(TempsUtils.isDatePasseeUneSemaine(dateFuture1jour));

        final Date dateFuture7jour = DateUtils.todayMoreDays(7);
        assertFalse(TempsUtils.isDatePasseeUneSemaine(dateFuture7jour));
    }
}
