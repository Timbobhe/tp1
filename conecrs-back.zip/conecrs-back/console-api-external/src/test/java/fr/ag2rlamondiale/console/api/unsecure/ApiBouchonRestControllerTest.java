package fr.ag2rlamondiale.console.api.unsecure;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.cab.api.unsecure.ApiBouchonRestController;
import fr.ag2rlamondiale.cab.business.impl.BouchonServiceFacadeImpl;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.ecrs.mock.gesthabili_1.rechercherhabilipers_1.ComputeRequestIdRechercherHabiliPersRequest;
import fr.ag2rlamondiale.trm.rest.jaxb.PfsRestJaxbConfig;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Collections;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(MockitoJUnitRunner.class)
public class ApiBouchonRestControllerTest {

    private MockMvc mockMvc;

    ObjectMapper mapMock = new PfsRestJaxbConfig().buildJaxbObjectMapper();

    @Mock
    private BouchonServiceFacadeImpl bouchonServiceFacade;

    @InjectMocks
    @Spy
    ApiBouchonRestController apiBouchonRestController;

    @Before
    public void init() {
        ReflectionTestUtils.setField(apiBouchonRestController, "computeRequestIdList", Collections.singletonList(new ComputeRequestIdRechercherHabiliPersRequest()));
        ReflectionTestUtils.setField(apiBouchonRestController, "jsonMapper", mapMock);
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(apiBouchonRestController).build();
    }

    @Test
    public void bouchonServiceKOTest() throws Exception {
        String testMock = "{\r\n  \"RechercherHabiliPers\" : {\r\n    \"IdtActr\" : {\r\n      \"IdentActrDansSilo\" : {\r\n        \"idSilo\" : \"1\",\r\n        \"codeAppli\" : \"A1531\"\r\n      }\r\n    },\r\n    \"IdtNumrq\" : {\r\n      \"login\" : \"cobnj6\",\r\n      \"idFseurIdtNumrq\" : \"1\"\r\n    }\r\n  }\r\n}";


        this.mockMvc.perform(post("/demo/GestHabili_1/RechercherHabiliPers_1").param("cdm", "63")
                .contentType(MediaType.APPLICATION_JSON).content(testMock)).andExpect(status().isNotFound()).andReturn()
                .getResponse().getContentAsString();
    }

    @Test
    public void bouchonServiceOKTest() {
        when(bouchonServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(anyString(), anyString(), anyLong())).then(invocationOnMock -> {
            BouchonService b = new BouchonService();
            b.setCompteDemo(CompteDemo.builder().id(1L).build());
            return b;
        });

        String testMock = "{\r\n  \"RechercherHabiliPers\" : {\r\n    \"IdtActr\" : {\r\n      \"IdentActrDansSilo\" : {\r\n        \"idSilo\" : \"1\",\r\n        \"codeAppli\" : \"A1531\"\r\n      }\r\n    },\r\n    \"IdtNumrq\" : {\r\n      \"login\" : \"cobnj6\",\r\n      \"idFseurIdtNumrq\" : \"1\"\r\n    }\r\n  }\r\n}";
        apiBouchonRestController.bouchonService("GestHabili_1", "RechercherHabiliPers_1", 63L, testMock);
        verify(apiBouchonRestController, times(1)).bouchonService("GestHabili_1", "RechercherHabiliPers_1", 63L, testMock);
    }
}

