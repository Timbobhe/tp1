package fr.ag2rlamondiale.cab.mapper.parametre;

import fr.ag2rlamondiale.cab.domain.Parametre;
import fr.ag2rlamondiale.cab.dto.parametre.ParametreDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface IParametreMapper {

    ParametreDto map(Parametre parametre);

    List<ParametreDto> map(List<Parametre> parametres);
}
