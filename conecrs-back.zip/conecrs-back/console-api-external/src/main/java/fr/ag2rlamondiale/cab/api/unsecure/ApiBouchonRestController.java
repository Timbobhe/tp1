package fr.ag2rlamondiale.cab.api.unsecure;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.cab.business.IBouchonServiceFacade;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceNonTrouveException;
import fr.ag2rlamondiale.cab.utils.RandomUtils;
import fr.ag2rlamondiale.ecrs.mock.ComputeRequestId;
import fr.ag2rlamondiale.ecrs.mock.ServiceId;
import fr.ag2rlamondiale.ecrs.mock.TypeRequest;
import fr.ag2rlamondiale.trm.utils.XmlMarshaller;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import java.nio.charset.StandardCharsets;
import java.util.*;

import static fr.ag2rlamondiale.trm.rest.jaxb.PfsRestJaxbConfig.JAXB_OBJECT_MAPPER;


@Slf4j
@RestController
@RequestMapping({"/unsecure", "/public"})
public class ApiBouchonRestController {

    @Autowired
    private IBouchonServiceFacade bServiceFacade;

    @Autowired
    private List<ComputeRequestId<?>> computeRequestIdList;


    @Qualifier(JAXB_OBJECT_MAPPER)
    @Autowired
    private ObjectMapper jsonMapper = new ObjectMapper();

    @SuppressWarnings("rawtypes")
    private ComputeRequestId findRequestIdComputer(String serviceId) {
        return computeRequestIdList
                .stream()
                .filter(computeReqId -> {
                    ServiceId annotation = AnnotationUtils.findAnnotation(computeReqId.getClass(), ServiceId.class);
                    return annotation != null && annotation.value().equals(serviceId);
                })
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Impossible de trouver le ComputeRequestId pour " + serviceId));
    }

    @SneakyThrows
    @PostMapping(path = "/demo/{part1}/{part2}")
    @SuppressWarnings({"unchecked", "rawtypes"})
    public ResponseEntity<StreamingResponseBody> bouchonService(@PathVariable("part1") String part1, @PathVariable("part2") String part2,
                                                                @RequestParam("cdm") Long idCompteDemo,
                                                                @RequestBody String request) {
        final String serviceId = part1 + "/" + part2;
        if (log.isDebugEnabled()) {
            log.debug("API Bouchon : serviceId={}, cdm={}\n{}", serviceId, idCompteDemo, request);
        }

        final ComputeRequestId requestIdComputer = findRequestIdComputer(serviceId);
        final ServiceId annotationServiceId = AnnotationUtils.findAnnotation(requestIdComputer.getClass(), ServiceId.class);
        Objects.requireNonNull(annotationServiceId);

        final String requestId;
        if (TypeRequest.REST.equals(annotationServiceId.typeRequest())) {
            jsonMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            final Object o = jsonMapper.readValue(request, annotationServiceId.requestInputClass());
            requestId = requestIdComputer.requestId(o);
        } else if (TypeRequest.SOAP.equals(annotationServiceId.typeRequest())) {
            final Object o = XmlMarshaller.convertXMLStringToObject(request, annotationServiceId.requestInputClass());
            requestId = requestIdComputer.requestId(o);
        } else {
            requestId = null;
        }

        final BouchonService bs;
        try {
            bs = bServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(requestId, serviceId, idCompteDemo);
            if (bs.getPieceJointe() != null && TypeRequest.SOAP.equals(annotationServiceId.typeRequest())) {
                return writeToStream(bs);
            }
            final StreamingResponseBody stream = outputStream -> outputStream.write(bs.getVaRep().getBytes(StandardCharsets.UTF_8));
            return ResponseEntity.ok(stream);
        } catch (BouchonServiceNonTrouveException e) {
            log.error("{}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    private ResponseEntity<StreamingResponseBody> writeToStream(BouchonService bs) {
        final byte[] data = Base64.getDecoder().decode(bs.getPieceJointe().getBytes(StandardCharsets.UTF_8));
        final String boundary = RandomUtils.unique();
        final String xml = bs.getVaRep();
        StreamingResponseBody stream = outputStream -> {
            outputStream.write(("\r\n--" + boundary + "\r\n").getBytes());
            outputStream.write(("Content-type: text/xml; charset=utf-8\r\n\r\n").getBytes());
            outputStream.write(xml.getBytes(StandardCharsets.UTF_8));
            outputStream.write(("\r\n--" + boundary + "\r\n").getBytes());

            outputStream.write(("Content-disposition: filename=\"\"\r\n" +
                    "Content-type: application/octet-stream\r\n\r\n").getBytes());
            outputStream.write(data);
            outputStream.write(("\r\n--" + boundary + "--\r\n\r\n").getBytes());
            outputStream.flush();
            outputStream.close();
        };
        Map<String, String> parameters = new HashMap<>();
        parameters.put("boundary", boundary);
        return ResponseEntity.ok()
                .contentType(new MediaType(MediaType.MULTIPART_RELATED, parameters))
                .header("Transfer-Encoding", "chunked")
                .body(stream);
    }

}
