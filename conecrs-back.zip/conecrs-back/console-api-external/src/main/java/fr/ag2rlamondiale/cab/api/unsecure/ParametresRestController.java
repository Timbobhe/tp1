package fr.ag2rlamondiale.cab.api.unsecure;

import fr.ag2rlamondiale.cab.business.IParametreFacade;
import fr.ag2rlamondiale.cab.business.IParametreGrilleFacade;
import fr.ag2rlamondiale.cab.business.IParametreTauxFacade;
import fr.ag2rlamondiale.cab.dto.parametre.ParametreDto;
import fr.ag2rlamondiale.cab.dto.parametre.RequestParametreDto;
import fr.ag2rlamondiale.cab.mapper.parametre.IParametreMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping({"/unsecure", "/public"})
public class ParametresRestController {

    @Autowired
    private IParametreFacade paramFacade;

    @Autowired
    private IParametreGrilleFacade paramGrilleFacade;

    @Autowired
    private IParametreTauxFacade paramTauxFacede;

    @Autowired
    private IParametreMapper parametreMapper;

    @PostMapping("/parametre/find")
    public List<ParametreDto> getParametres(@RequestBody RequestParametreDto req) {
        return parametreMapper.map(paramFacade.find(req));
    }

//    @GetMapping("/parametre-grille/{idGrille}")
//    public ParametreGrille getParamGrilleById(@PathVariable Long idGrille) {
//        return paramGrilleFacade.findByIdGrille(idGrille);
//    }
//
//    @PostMapping(path = "/parametre-taux/find")
//    public ParametreTaux getTauxbyTypeGrilleAndDuree(@RequestBody RechercherTauxGrilleDto dto) {
//        return paramTauxFacede.findByTypeGrille(dto.getTypeGrille(), dto.getDuree());
//    }


}
