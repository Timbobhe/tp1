package fr.ag2rlamondiale.cab.api;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@Component
public class LoggingHandlerExceptionResolver implements Ordered, HandlerExceptionResolver, InitializingBean {

    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        this.handleAnyOtherException(ex, request);

        return null;
    }


    protected void handleAnyOtherException(Exception exception, HttpServletRequest request) {
        if (log.isErrorEnabled()) {
            log.error("Spring MVC Exception for [{} {}] :\n",
                    request.getMethod(),
                    request.getRequestURI(),
                    exception);
        }

    }

    public int getOrder() {
        return HIGHEST_PRECEDENCE;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.debug("LoggingHandlerExceptionResolver init");
    }
}
