package fr.ag2rlamondiale.cab.api.redirection;

import fr.ag2rlamondiale.trm.log.LogExecutionTime;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Service de Redirection
 */
@Slf4j
@RestController
@RequestMapping
public class FrontRedirectService {
    @LogExecutionTime
    @GetMapping(path = "/secure/redirectToFront")
    public ResponseEntity<String> redirectToFront(@RequestParam(name = "service") String service) {
        return retrieveResponseEntity(service);
    }

    @LogExecutionTime
    @GetMapping(path = "/secure/swagger")
    public ResponseEntity<String> redirectToSwagger(HttpServletRequest request) {
        final int serverPort = request.getServerPort();
        String url;
        if ((serverPort == 80) || (serverPort == 443)) {
            url = String.format("%s://%s%s/%s", request.getScheme(), request.getServerName(), request.getContextPath(), "api/swagger-ui.html");
        } else {
            url = String.format("%s://%s:%s%s/%s", request.getScheme(), request.getServerName(), serverPort, request.getContextPath(), "api/swagger-ui.html");
        }
        return retrieveResponseEntity(url);
    }

    private ResponseEntity<String> retrieveResponseEntity(String url) {
        if (isInvalidURL(url)) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        HttpHeaders headers = new HttpHeaders();
        log.info("Redirection to: {}", url);
        headers.add("Location", url);
        return new ResponseEntity<>(headers, HttpStatus.FOUND);
    }

    private boolean isInvalidURL(String service) {
        try {
            new URL(service);
        } catch (MalformedURLException e) {
            return true;
        }
        return false;
    }
}
