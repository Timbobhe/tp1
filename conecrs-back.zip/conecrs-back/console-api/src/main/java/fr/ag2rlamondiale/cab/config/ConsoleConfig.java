package fr.ag2rlamondiale.cab.config;

import fr.ag2rlamondiale.ecrs.mock.PfsGenerateConfig;
import fr.ag2rlamondiale.trm.CoreConfig;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
@EntityScan("fr.ag2rlamondiale.cab")
@EnableJpaRepositories("fr.ag2rlamondiale.cab.repository")
@Import({CoreConfig.class, PfsGenerateConfig.class})
public class ConsoleConfig {
}
