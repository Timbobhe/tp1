package fr.ag2rlamondiale.cab.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class RechercherTauxGrilleDto implements Serializable {
    private static final long serialVersionUID = -4801102940316758244L;

    private Integer duree;
    private String typeGrille;

}