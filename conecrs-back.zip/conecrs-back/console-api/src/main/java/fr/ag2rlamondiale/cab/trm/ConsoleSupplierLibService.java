package fr.ag2rlamondiale.cab.trm;

import fr.ag2rlamondiale.trm.ISupplierLibService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ConsoleSupplierLibService implements ISupplierLibService {
    @Value("${ecrent.front.url}")
    private String urlFront;

    @Override
    public String getCodeCassiniAppli() {
        return "A1573";
    }

    @Override
    public String getLibelleAppli() {
        return "CONSOLE ADMINISTRATION";
    }

    @Override
    public String getUrlFront() {
        return urlFront;
    }
}
