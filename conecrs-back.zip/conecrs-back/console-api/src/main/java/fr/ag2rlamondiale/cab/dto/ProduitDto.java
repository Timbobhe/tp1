package fr.ag2rlamondiale.cab.dto;

import lombok.Data;

import java.io.Serializable;

@Data
public class ProduitDto implements Serializable {
    private static final long serialVersionUID = -4801102940316758244L;

    private Long id;
    private String typeContrat;
    private String codeFiliale;
    private String numeroGeneration;
    private String libelle;
    private String libelleFiscalite;
    private Boolean deductible;
}