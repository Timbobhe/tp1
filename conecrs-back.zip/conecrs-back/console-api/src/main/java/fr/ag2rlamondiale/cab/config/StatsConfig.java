package fr.ag2rlamondiale.cab.config;

import fr.ag2rlamondiale.stats.StatsMainConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
//@ComponentScan(basePackages = {"fr.ag2rlamondiale.stats"})
//@EnableJpaRepositories(basePackages = "fr.ag2rlamondiale.stats.dao.repository")
//@EntityScan(basePackages = "fr.ag2rlamondiale.stats.dao.domainfr.ag2rlamondiale.stats.dao.domain")
@Import(StatsMainConfig.class)
public class StatsConfig {
}
