package fr.ag2rlamondiale.cab.api.error;

import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.trm.domain.error.RestError;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;

import static fr.ag2rlamondiale.trm.utils.ErrorConstantes.ERREUR_TECHNIQUE;

@Slf4j
@ControllerAdvice(basePackages = "fr.ag2rlamondiale.cab.api")
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(CompteDemoException.class)
    @ResponseBody
    public ResponseEntity<RestError> handleCompteDemoException(CompteDemoException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null).addMessage(ex.getMessage()), HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(BouchonServiceException.class)
    @ResponseBody
    public ResponseEntity<RestError> handleBouchonServiceException(BouchonServiceException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null).addMessage(ex.getMessage()), HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler(DataIntegrityViolationException.class)
    @ResponseBody
    public ResponseEntity<RestError> handleDataIntegrityViolationException(DataIntegrityViolationException ex) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null).addMessage(buildErrorMessage(ex)), HttpStatus.NOT_ACCEPTABLE);
    }

    @ExceptionHandler({Exception.class})
    @ResponseBody
    public ResponseEntity<RestError> handleAnyException(Exception e) {
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null).addMessage(buildErrorMessage(e)), HttpStatus.SERVICE_UNAVAILABLE);
    }


    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> errorList = ex
                .getBindingResult()
                .getFieldErrors()
                .stream()
                .map(FieldError::getField)
                .collect(Collectors.toList());
        return new ResponseEntity<>(new RestError(ERREUR_TECHNIQUE, null, errorList), HttpStatus.BAD_REQUEST);
    }


    private String buildErrorMessage(Throwable excep) {
        Throwable src = ExceptionUtils.getRootCause(excep);
        if (src == null) {
            src = excep;
        }

        return src.getClass() + " : " + src.getMessage();
    }
}
