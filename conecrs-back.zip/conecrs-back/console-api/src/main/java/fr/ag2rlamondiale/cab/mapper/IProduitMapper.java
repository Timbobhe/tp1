package fr.ag2rlamondiale.cab.mapper;

import fr.ag2rlamondiale.cab.domain.Produit;
import fr.ag2rlamondiale.cab.dto.ProduitDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface IProduitMapper {
    ProduitDto map(Produit produit);

    List<ProduitDto> map(List<Produit> produits);
}
