package fr.ag2rlamondiale.cab.security;

import com.ag2r.common.exceptions.TechnicalException;
import com.ag2r.common.keys.log.FrmkLogKeys;
import fr.ag2rlamondiale.trm.domain.exception.WSSecurityException;
import fr.ag2rlamondiale.trm.domain.personne.PersonnePhysique;
import fr.ag2rlamondiale.trm.security.*;
import fr.ag2rlamondiale.trm.supervision.UserTestManager;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Slf4j
@Service
public class UserSecurityServiceImpl implements UserSecurityService {
    @Autowired
    private UserSecurityContext securityContext;

    @Autowired
    private UserContextHolder userContextHolder;

//    @Autowired
//    private IContratFacade contratFacade;

    @Override
    public boolean isAuthorized(JoinPoint joinPoint, Secure secure) {
        if (!securityContext.isContextActive()) {
            log.warn("Attention, le contexte de sécurité n'est pas encore initialisé, on laisse passer l'appel : {} ",
                    joinPoint.toLongString());
            return true;
        }

        // Cas d'attaque après connexion.
        if (isJointPointAuthorized(joinPoint)) {
            return true;
        }

        throw new WSSecurityException("Alert security param = " + secure + " [ContextSecurity] = " + securityContext
                + " [Input WS ]= " + Arrays.toString(joinPoint.getArgs()));
    }

    @Override
    public void initSecurityContext(String idGdi, PersonnePhysique personnePhysique) throws TechnicalException {
        MDC.put(FrmkLogKeys.IDENTIFIANT_UTILISATEUR, idGdi);
        securityContext.clear();
        securityContext.setIdGdi(idGdi);
        userContextHolder.get().setIdGdi(idGdi);
        userContextHolder.get().setNom(personnePhysique.getNom());
        userContextHolder.get().setPrenom(personnePhysique.getPrenom());
        userContextHolder.get().setCivilite(personnePhysique.getCivilite());
        String numPpEre = personnePhysique.getNumeroPersonneEre();
        String numPpMdpro = personnePhysique.getNumeroPersonneMdpro();
        userContextHolder.get().setNumeroPersonneEre(numPpEre);
        userContextHolder.get().setNumeroPersonneMdpro(numPpMdpro);
        securityContext.setNumeroPersonneEre(numPpEre);
        securityContext.setNumeroPersonneMdpro(numPpMdpro);

//        List<ContratHeader> contrats = contratFacade.rechercherContrats();
//        Set<CodeSiloType> silos = new HashSet<>();
//        Set<String> idContrats = new HashSet<>();
//        Set<String> idAssures = new HashSet<>();
//        contrats.forEach(contratHeader -> {
//            silos.add(contratHeader.getCodeSilo());
//            idContrats.add(contratHeader.getId());
//            idAssures.addAll(contratHeader.getIdentifiantsAssures());
//        });
//
//        userContextHolder.get().setSilos(silos);
//        userContextHolder.get().setFilialeACA(ContratHelper.isFilialeACA(contrats));
//        userContextHolder.get().setHasContratEre(ContratHelper.containsEre(contrats));

//        securityContext.setIdContrats(idContrats);
//        securityContext.setIdAssures(idAssures);

        securityContext.setContextActive(true);
        log.info("Fin initialisation {}", securityContext);
    }

    @Override
    public void initSecurityContext(UserTestManager userTestManager) {
        final String idGdi = userTestManager.getIdGdi();
        MDC.put(FrmkLogKeys.IDENTIFIANT_UTILISATEUR, idGdi);
        securityContext.clear();
        securityContext.setIdGdi(idGdi);
        userContextHolder.get().setForSupervision(true);
        userContextHolder.get().setIdGdi(idGdi);
        String numPpEre = userTestManager.getPersonnePhysique().getNumeroPersonneEre();
        String numPpMdpro = userTestManager.getPersonnePhysique().getNumeroPersonneMdpro();
        userContextHolder.get().setNumeroPersonneEre(numPpEre);
        userContextHolder.get().setNumeroPersonneMdpro(numPpMdpro);
        securityContext.setNumeroPersonneEre(numPpEre);
        securityContext.setNumeroPersonneMdpro(numPpMdpro);
        securityContext.setContextActive(true);
    }

    private boolean isJointPointAuthorized(JoinPoint joinPoint) {
        if (userContextHolder.get().isForSupervision()) {
            return true;
        }

        final List<SecurityParamValue> securityParamValues = getSecurityParamValue(joinPoint);
        boolean secured = true;
        for (SecurityParamValue securityParamValue : securityParamValues) {
            if (!securityParamValue.isEmpty()) {
                switch (securityParamValue.getSecurityParamType()) {
                    case CONTRAT:
                        secured &= securityContext.getIdContrats().contains(securityParamValue.getValue());
                        break;
                    case IDASSURE:
                        secured &= securityContext.getIdAssures().contains(securityParamValue.getValue());
                        break;
                    default:
                        return false;
                }
            }
        }

        return secured;
    }

    private List<SecurityParamValue> getSecurityParamValue(JoinPoint joinPoint) {
        final MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        final Method method = signature.getMethod();
        int index = -1;
        for (Parameter parameter : method.getParameters()) {
            ++index;
            final SecuredParam securedParam = parameter.getAnnotation(SecuredParam.class);
            if (securedParam != null) {
                final Object arg = joinPoint.getArgs()[index];
                final SecurityParamType[] securityParamTypes = securedParam.paramType();
                List<SecurityParamValue> res = new ArrayList<>();
                for (SecurityParamType securityParamType : securityParamTypes) {
                    if (arg instanceof String) {
                        res.add(new SecurityParamValue(securityParamType, (String) arg));
                    } else if (arg instanceof ISecurityParamAccess) {
                        final String value = securityParamType.getSecurityValue((ISecurityParamAccess) arg);
                        res.add(new SecurityParamValue(securityParamType, value));
                    }
                }

                return res;
            }
        }

        throw new WSSecurityException(
                "Impossible de r\u00e9cup\u00e9rer le SecuredParam sur la m\u00e9thode " + joinPoint);
    }
}
