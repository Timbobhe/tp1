package fr.ag2rlamondiale.cab.security;

import fr.ag2rlamondiale.trm.security.SecurityParamType;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
class SecurityParamValue {
    private final SecurityParamType securityParamType;
    private final String value;

    public boolean isEmpty() {
        return StringUtils.isEmpty(value);
    }
}
