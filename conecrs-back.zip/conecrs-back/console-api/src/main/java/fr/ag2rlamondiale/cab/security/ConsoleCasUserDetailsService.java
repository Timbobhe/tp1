package fr.ag2rlamondiale.cab.security;

import fr.ag2rlamondiale.metis.boot.security.dao.IApplicationRolesRetriever;
import fr.ag2rlamondiale.metis.boot.security.dao.MetisBootCasUserDetailsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.cas.authentication.CasAssertionAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ConsoleCasUserDetailsService extends MetisBootCasUserDetailsService {
    /**
     * Constructeur
     *
     * @param applicationRolesRetriever retriever des roles applicatifs
     */
    public ConsoleCasUserDetailsService(IApplicationRolesRetriever applicationRolesRetriever) {
        super(new String[]{"roles"}, applicationRolesRetriever);
    }

    @Override
    public UserDetails loadUserDetails(CasAssertionAuthenticationToken authentication) {
        long start = System.currentTimeMillis();
        log.info("Tentative de connexion avec {}", authentication);
        UserDetails userDetails = super.loadUserDetails(authentication);
        log.info("Connexion réussie pour {} en {} ms", userDetails, System.currentTimeMillis() - start);
        return userDetails;
    }
}
