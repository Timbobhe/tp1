package fr.ag2rlamondiale.cab.mapper.comptedemo;

import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.BouchonServiceDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;


@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public interface IBouchonServiceMapper {

    @Mapping(target = "idCmpDemo", source = "compteDemo", qualifiedByName = "compteDemoToId")
    @Mapping(target = "pieceJointeExists", source = ".", qualifiedByName = "pieceJointeExists")
    BouchonServiceDto toBouchonServiceDTO(BouchonService bService);

    List<BouchonServiceDto> toBouchonServiceDTOs(List<BouchonService> bServices);

    @Mapping(target = "compteDemo", source = "idCmpDemo", qualifiedByName = "idToCompteDemo")
    BouchonService toBouchonService(BouchonServiceDto bServiceDto);

    @Named("compteDemoToId")
    default Long compteDemoId(CompteDemo cp) {
        return cp.getId();
    }

    @Named("idToCompteDemo")
    default CompteDemo idToCompteDemo(Long idCmp) {
        return CompteDemo.builder().id(idCmp).build();
    }

    @Named("pieceJointeExists")
    default boolean compteDemoId(BouchonService bService) {
        return bService.getPieceJointe() != null;
    }
}
