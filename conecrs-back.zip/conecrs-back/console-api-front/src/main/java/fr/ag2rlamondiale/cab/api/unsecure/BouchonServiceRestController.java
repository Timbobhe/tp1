package fr.ag2rlamondiale.cab.api.unsecure;

import fr.ag2rlamondiale.cab.business.IBouchonServiceFacade;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.dto.comptedemo.BouchonServiceDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.MessageResponseDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationBouchonServiceDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceException;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceNonTrouveException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.mapper.comptedemo.IBouchonServiceMapper;
import fr.ag2rlamondiale.cab.utils.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@RestController
@RequestMapping({"/unsecure", "/public"})
public class BouchonServiceRestController {

    @Autowired
    private IBouchonServiceFacade bServiceFacade;

    @Autowired
    private IBouchonServiceMapper iBouchonServiceMapper;

    @GetMapping("/bouchon-service")
    public ResponseEntity<List<BouchonServiceDto>> findAllService() {
        List<BouchonServiceDto> bService = iBouchonServiceMapper.toBouchonServiceDTOs(bServiceFacade.findAll());
        return ResponseEntity.status(HttpStatus.OK).body(bService);

    }

    @GetMapping("/bouchon-service/find-all/{idCompteDemo}")
    public ResponseEntity<List<BouchonServiceDto>> findAllServiceByIdCmpDemo(@PathVariable Long idCompteDemo) {
        List<BouchonServiceDto> bService = iBouchonServiceMapper.toBouchonServiceDTOs(bServiceFacade.findAllServiceByIdCmpDemo(idCompteDemo));
        return ResponseEntity.status(HttpStatus.OK).body(bService);

    }

    @PostMapping("/bouchon-service")
    public ResponseEntity<BouchonServiceDto> createBouchonService(@RequestBody @Valid BouchonServiceDto bServiceDto) {
        try {
            bServiceDto.setId(null);
            bServiceDto.setDateCreation(null);
            bServiceDto.setDateMiseAjour(null);

            BouchonService bouchon = iBouchonServiceMapper.toBouchonService(bServiceDto);
            final BouchonService saved = bServiceFacade.save(bouchon);
            return ResponseEntity.status(HttpStatus.OK).body(iBouchonServiceMapper.toBouchonServiceDTO(saved));
        } catch (CompteDemoException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @PutMapping("/bouchon-service/{idBserviceSource}")
    public ResponseEntity<MessageResponseDto> updateService(
            @PathVariable Long idBserviceSource,
            @RequestBody @Valid ModificationBouchonServiceDto modifBservice) {
        if (!bServiceFacade.isPieceJointeAuthorized(modifBservice.getPieceJointe())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        bServiceFacade.modifier(idBserviceSource, modifBservice);
        return ResponseEntity.status(HttpStatus.OK).body(new MessageResponseDto("OK", "Success"));
    }

    @GetMapping("/bouchon-service/{id}")
    public ResponseEntity<BouchonServiceDto> findServiceById(@PathVariable Long id) {
        try {
            BouchonServiceDto bService = iBouchonServiceMapper.toBouchonServiceDTO(bServiceFacade.findById(id));
            return ResponseEntity.status(HttpStatus.FOUND).body(bService);
        } catch (BouchonServiceException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }


    @GetMapping("/bouchon-service/find")
    public ResponseEntity<BouchonServiceDto> findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(
            @RequestParam(value = "idRequete") String requeteId,
            @RequestParam(value = "idService") String serviceId,
            @RequestParam(value = "idCmpDem") Long cmpDemId) {

        BouchonService bouchon;
        try {
            bouchon = bServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(requeteId, serviceId, cmpDemId);
        } catch (BouchonServiceNonTrouveException e) {
            return ResponseEntity.notFound().build();
        }
        BouchonServiceDto cpDemos = iBouchonServiceMapper.toBouchonServiceDTO(bouchon);
        return ResponseEntity.status(HttpStatus.OK).body(cpDemos);
    }


    @DeleteMapping("/bouchon-service/{id}")
    public ResponseEntity<String> deleteBouchonService(@PathVariable Long id) {
        try {
            bServiceFacade.deleteBouchonService(id);
            return ResponseEntity.status(HttpStatus.OK).body("OK");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @GetMapping("/bouchon-service/download/{id}")
    public ResponseEntity<byte[]> downloadAttachment(@PathVariable final Long id) {
        final byte[] contenuFichier;
        final HttpHeaders headers;
        try {
            final Path fichierPath = bServiceFacade.getBouchonServiceFile(id).toPath();
            contenuFichier = Files.readAllBytes(fichierPath);
            headers = FileUtils.generateFileHttpHeaders(fichierPath, contenuFichier);
        } catch (final Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return ResponseEntity.status(HttpStatus.OK).headers(headers).body(contenuFichier);
    }
}
