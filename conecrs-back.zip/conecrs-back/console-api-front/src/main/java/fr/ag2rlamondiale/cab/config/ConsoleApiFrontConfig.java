package fr.ag2rlamondiale.cab.config;

import fr.ag2rlamondiale.jnb.JahiaNgServerConfig;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import(JahiaNgServerConfig.class)
public class ConsoleApiFrontConfig {
}
