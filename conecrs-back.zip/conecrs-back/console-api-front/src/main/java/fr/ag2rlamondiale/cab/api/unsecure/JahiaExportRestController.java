package fr.ag2rlamondiale.cab.api.unsecure;

import fr.ag2rlamondiale.jnb.business.JahiaFacadeSync;
import fr.ag2rlamondiale.jnb.dto.JahiaExportQueryDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
@RestController
@RequestMapping({"/unsecure", "/public"})
public class JahiaExportRestController {

    private static final String CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding";
    private static final String BINARY = "binary";
    private static final String APPLICATION_FORCE_DOWNLOAD = "application/force-download";
    private static final String ATTACHMENT_FILENAME = "attachment; filename=\"";

    @Autowired
    private JahiaFacadeSync jahiaFacadeSync;


    @PostMapping({"/jahia/export", "/jahia/contrib/export"})
    public void exportContribJahia(@RequestBody JahiaExportQueryDto query, HttpServletResponse httpServletResponse) throws Exception {
        final String jahiaEndpoint = query.getJahiaEndpoint();
        final String host = new URL(jahiaEndpoint).getHost();
        final String timestamp = new SimpleDateFormat("yyyyMMdd-HHmmss").format(new Date());
        final String documentName = "jahia-export-" + host + "-" + timestamp + ".zip";

        try {
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            jahiaFacadeSync.export(query, outputStream);

            try (ServletOutputStream out = httpServletResponse.getOutputStream()) {
                setDocumentHeaders(httpServletResponse, documentName);
                out.write(outputStream.toByteArray());
            }

        } catch (Exception e) {
            log.error("ZIP file has not been generated", e);
            throw e;
        }
    }

    protected void setDocumentHeaders(HttpServletResponse response, String documentName) {
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION, ATTACHMENT_FILENAME + documentName + "\"");
        response.addHeader(CONTENT_TRANSFER_ENCODING, BINARY);
        response.addHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
        response.setContentType(APPLICATION_FORCE_DOWNLOAD);
    }
}
