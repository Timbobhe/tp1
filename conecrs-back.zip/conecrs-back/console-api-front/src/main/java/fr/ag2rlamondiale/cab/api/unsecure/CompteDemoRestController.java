package fr.ag2rlamondiale.cab.api.unsecure;


import fr.ag2rlamondiale.cab.business.ICompteDemoFacade;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.MessageResponseDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationCompteDemoDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoNonTrouveException;
import fr.ag2rlamondiale.cab.mapper.comptedemo.ICompteDemoMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping({"/unsecure", "/public"})
public class CompteDemoRestController {

    @Autowired
    private ICompteDemoFacade compteDemoFacade;

    @Autowired
    private ICompteDemoMapper compteDemoMapper;

    @GetMapping("/compte-demo")
    public ResponseEntity<List<CompteDemoDto>> findAllCompteDemo() {
        List<CompteDemoDto> cpDemos = compteDemoMapper.toCompteDemoDTOs(compteDemoFacade.findAll());
        return ResponseEntity.status(HttpStatus.OK).body(cpDemos);
    }

    @PostMapping("/compte-demo")
    public ResponseEntity<CompteDemoDto> createCompteDemo(@RequestBody CompteDemoDto compteDemoDto) {
        try {
            compteDemoDto.setId(null);
            compteDemoDto.setDateCreation(null);
            compteDemoDto.setDateMiseAjour(null);

            CompteDemo cpDemo = compteDemoMapper.toCompteDemo(compteDemoDto);
            final CompteDemo saved = compteDemoFacade.save(cpDemo);
            return ResponseEntity.status(HttpStatus.OK).body(compteDemoMapper.toCompteDemoDTO(saved));
        } catch (CompteDemoException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @PutMapping("/compte-demo/{id}")
    public ResponseEntity<CompteDemoDto> updateCompteDemo(
            @PathVariable Long id,
            @Valid @RequestBody CompteDemoDto compteDemoDto) throws CompteDemoException {
            CompteDemo byId = compteDemoFacade.findById(id);
            CompteDemo cpDemo = compteDemoMapper.toCompteDemo(compteDemoDto);
            cpDemo.setId(byId.getId());
            cpDemo.setDateCreation(byId.getDateCreation());
            cpDemo.setDateMiseAjour(null);
            compteDemoFacade.save(cpDemo);
            return ResponseEntity.status(HttpStatus.OK).body(compteDemoDto);
    }

    @GetMapping("/compte-demo/{id}")
    public ResponseEntity<CompteDemoDto> findCompteDemoById(@PathVariable Long id) throws CompteDemoException {
            CompteDemoDto compteDemo = compteDemoMapper.toCompteDemoDTO(compteDemoFacade.findById(id));
            return ResponseEntity.status(HttpStatus.OK).body(compteDemo);
    }

    @GetMapping("/compte-demo/find")
    public ResponseEntity<CompteDemoDto> findCompteDemo(
            @RequestParam(value = "numReferenceExterne", required = false) String refExt,
            @RequestParam(value = "numPersonne", required = false) String numPers) {

        CompteDemoDto cpDemo;
        try {
            if (refExt != null && !refExt.isBlank()) {
                cpDemo = compteDemoMapper.toCompteDemoDTO(compteDemoFacade.findCompteDemoByRefExt(refExt));
            } else if (numPers != null && !numPers.isBlank()) {
                cpDemo = compteDemoMapper.toCompteDemoDTO(compteDemoFacade.findCompteDemoByNumPers(numPers));
            } else {
                return ResponseEntity.badRequest().body(null);
            }
        } catch (CompteDemoNonTrouveException e) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.status(HttpStatus.OK).body(cpDemo);
    }

    @DeleteMapping("/compte-demo/{id}")
    public ResponseEntity<String> deleteCompteDemo(@PathVariable Long id) {
            compteDemoFacade.deleteCompteDemo(id);
            return ResponseEntity.status(HttpStatus.OK).body("OK");
    }

    @PostMapping("/compte-demo/clone/{idCdmSource}")
    public ResponseEntity<MessageResponseDto> clonerCompteDemo(@Valid @RequestBody ModificationCompteDemoDto modifCdmDto,
                                                              @PathVariable Long idCdmSource) {
        compteDemoFacade.clone(idCdmSource, modifCdmDto);
        return ResponseEntity.status(HttpStatus.OK).body(new MessageResponseDto("OK", "Success"));
    }

    @PostMapping("/compte-demo/modifier/{idCdmSource}")
    public ResponseEntity<MessageResponseDto> modifierCompteDemo(@Valid @RequestBody ModificationCompteDemoDto modifCdmDto,
                                                                 @PathVariable Long idCdmSource) {
        compteDemoFacade.modifier(idCdmSource, modifCdmDto);
        return ResponseEntity.status(HttpStatus.OK).body(new MessageResponseDto("OK", "Success"));
    }
}

