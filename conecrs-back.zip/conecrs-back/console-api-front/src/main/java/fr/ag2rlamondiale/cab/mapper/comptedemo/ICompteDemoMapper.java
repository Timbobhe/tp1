package fr.ag2rlamondiale.cab.mapper.comptedemo;

import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.CompteDemoDto;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring",  builder = @org.mapstruct.Builder(disableBuilder = true))
public interface ICompteDemoMapper {

    CompteDemoDto toCompteDemoDTO(CompteDemo compteDemo);

    List<CompteDemoDto> toCompteDemoDTOs(List<CompteDemo> comptesDemo);

    CompteDemo toCompteDemo(CompteDemoDto compteDemoDto);

}
