package fr.ag2rlamondiale.console.api.unsecure;

import fr.ag2rlamondiale.cab.api.unsecure.CompteDemoRestController;
import fr.ag2rlamondiale.cab.business.impl.CompteDemoFacadeImpl;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationCompteDemoDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.mapper.comptedemo.ICompteDemoMapperImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;


@RunWith(MockitoJUnitRunner.class)
public class CompteDemoRestControllerTest {

    @Mock
    private CompteDemoFacadeImpl compteDemoFacade;
    @InjectMocks
    @Spy
    private CompteDemoRestController compteDemoController;

    @InjectMocks
    private ICompteDemoMapperImpl iCompteDemoMapper;

    @Before
    public void init() {
        ReflectionTestUtils.setField(compteDemoController, "compteDemoMapper", iCompteDemoMapper);
    }

    @Test
    public void findAllCompteDemoTest() {
        compteDemoController.findAllCompteDemo();
        verify(compteDemoController, times(1)).findAllCompteDemo();

    }

    private CompteDemo getCompteDemo() {

        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(13333L);
        cDemo.setNumReferenceExterne("R12");
        cDemo.setNumPersonne("P12");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        return cDemo;
    }

    private CompteDemoDto getCompteDemoDto() {

        CompteDemoDto cDemoDto = new CompteDemoDto();
        cDemoDto.setId(13333L);
        cDemoDto.setNumReferenceExterne("R12");
        cDemoDto.setNumPersonne("P12");
        cDemoDto.setDateCreation(new Date());
        cDemoDto.setDateMiseAjour(null);
        return cDemoDto;
    }

    private ModificationCompteDemoDto getModificationCompteDemoDto() {

        ModificationCompteDemoDto modifCDemoDto = new ModificationCompteDemoDto();
        modifCDemoDto.setNumReferenceExterne("R12");
        modifCDemoDto.setNumPersonne("P12");
        modifCDemoDto.setDescription("TEST");
        return modifCDemoDto;
    }

    @Test
    public void findCompteDemoByIdTest() {
        CompteDemo cDemo = getCompteDemo();
        when(compteDemoFacade.findById(13333L)).thenReturn(cDemo);
        CompteDemoDto expected = compteDemoController.findCompteDemoById(13333L).getBody();
        assertNotNull(expected);

    }

    @Test
    public void findCompteDemoByNumPersTest() {

        CompteDemo cDemo = getCompteDemo();

        when(compteDemoFacade.findCompteDemoByNumPers("P12")).thenReturn(cDemo);
        CompteDemoDto expected = compteDemoController.findCompteDemo(null, "P12").getBody();
        assertNotNull(expected);

    }

    @Test
    public void findCompteDemoByRefExtTest() {

        CompteDemo cDemo = getCompteDemo();

        when(compteDemoFacade.findCompteDemoByRefExt("R12")).thenReturn(cDemo);
        CompteDemoDto expected = compteDemoController.findCompteDemo("R12", null).getBody();
        assertNotNull(expected);

    }

    @Test
    public void saveCompteDemoTest() {
        CompteDemoDto cDemoDto = getCompteDemoDto();
        compteDemoController.createCompteDemo(cDemoDto);
        verify(compteDemoController, times(1)).createCompteDemo(cDemoDto);

    }

    @Test
    public void saveCompteDemoTestWithException() {
        CompteDemoDto cDemoDto = getCompteDemoDto();
        when(compteDemoFacade.save(any(CompteDemo.class))).thenThrow(new CompteDemoException("TEST"));
        compteDemoController.createCompteDemo(cDemoDto);
        verify(compteDemoController, times(1)).createCompteDemo(cDemoDto);

    }

    @Test
    public void deleteCompteDemoTest() {
        compteDemoController.deleteCompteDemo(13333L);
        verify(compteDemoController, times(1)).deleteCompteDemo(13333L);

    }

    @Test
    public void updateCompteDemoTest() {
        CompteDemoDto cDemoDto = getCompteDemoDto();
        when(compteDemoFacade.findById(any(Long.class))).thenReturn(getCompteDemo());
        compteDemoController.updateCompteDemo(13333L, cDemoDto);
        verify(compteDemoController, times(1)).updateCompteDemo(13333L, cDemoDto);

    }

    @Test
    public void clonerCompteDemoTest() {
        compteDemoController.clonerCompteDemo(getModificationCompteDemoDto(),13333L);
        verify(compteDemoController, times(1)).clonerCompteDemo(getModificationCompteDemoDto(),13333L);

    }

    @Test
    public void modifierCompteDemoTest() {
        compteDemoController.modifierCompteDemo(getModificationCompteDemoDto(),13333L);
        verify(compteDemoController, times(1)).modifierCompteDemo(getModificationCompteDemoDto(),13333L);

    }
}
