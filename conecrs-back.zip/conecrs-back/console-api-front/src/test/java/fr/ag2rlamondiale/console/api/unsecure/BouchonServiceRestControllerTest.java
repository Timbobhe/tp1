package fr.ag2rlamondiale.console.api.unsecure;

import fr.ag2rlamondiale.cab.api.unsecure.BouchonServiceRestController;
import fr.ag2rlamondiale.cab.business.impl.BouchonServiceFacadeImpl;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.BouchonServiceDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.CompteDemoDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.MessageResponseDto;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationBouchonServiceDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceException;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceNonTrouveException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.mapper.comptedemo.IBouchonServiceMapperImpl;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class BouchonServiceRestControllerTest {

    @Mock
    private BouchonServiceFacadeImpl bouchonServiceFacade;

    @InjectMocks
    @Spy
    private BouchonServiceRestController bouchonServiceRestController;

    @InjectMocks
    private IBouchonServiceMapperImpl iBouchonServiceMapper;

    @Before
    public void init() {
        ReflectionTestUtils.setField(bouchonServiceRestController, "iBouchonServiceMapper", iBouchonServiceMapper);
    }


    @Test
    public void findAllServiceTest() {
        bouchonServiceRestController.findAllService();
        verify(bouchonServiceRestController, times(1)).findAllService();

    }

    @Test
    public void findCompteDemoByIdTest() {
        BouchonService bService = getBouchonService();
        when(bouchonServiceFacade.findById(232334L)).thenReturn(bService);
        BouchonServiceDto expected = bouchonServiceRestController.findServiceById(232334L).getBody();
        assertNotNull(expected);

    }

    private BouchonServiceDto getBouchonServiceDto() {
        CompteDemoDto cDemoDto = new CompteDemoDto();
        cDemoDto.setId(13333L);
        cDemoDto.setNumReferenceExterne("R12");
        cDemoDto.setNumPersonne("P12");
        cDemoDto.setDateCreation(new Date());
        cDemoDto.setDateMiseAjour(null);
        BouchonServiceDto bserviceDto = new BouchonServiceDto();
        bserviceDto.setId(232334L);
        bserviceDto.setIdCmpDemo(cDemoDto.getId());
        bserviceDto.setIdService("RechercherHabiliPers");
        bserviceDto.setIdRequete("1129972_AFFILIE");
        bserviceDto.setDateCreation(new Date());
        bserviceDto.setDateMiseAjour(null);
        return bserviceDto;
    }

    private BouchonService getBouchonService() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(13333L);
        cDemo.setNumReferenceExterne("R12");
        cDemo.setNumPersonne("P12");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        BouchonService bService = new BouchonService();
        bService.setId(232334L);
        bService.setCompteDemo(cDemo);
        bService.setIdService("RechercherHabiliPers");
        bService.setIdRequete("1129972_AFFILIE");
        bService.setDateCreation(new Date());
        bService.setDateMiseAjour(null);
        return bService;
    }

    private ModificationBouchonServiceDto getModificationBserviceDto() {

        ModificationBouchonServiceDto modifbServiceDto = new ModificationBouchonServiceDto();
        modifbServiceDto.setIdService("R12");
        modifbServiceDto.setIdRequete("P12");
        modifbServiceDto.setVaRep("TEST");
        return modifbServiceDto;
    }

    private ModificationBouchonServiceDto getModificationBserviceWithBadAttachmentDto() {
        ModificationBouchonServiceDto modifbServiceDto = new ModificationBouchonServiceDto();
        modifbServiceDto.setIdService("R12");
        modifbServiceDto.setIdRequete("P12");
        modifbServiceDto.setVaRep("TEST");
        modifbServiceDto.setPieceJointe("");
        return modifbServiceDto;
    }


    @Test
    public void findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoIdTest() {

        BouchonService bs = getBouchonService();

        when(bouchonServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId("1129972_AFFILIE", "RechercherHabiliPers", 13333L)).thenReturn(bs);
        BouchonServiceDto expected = bouchonServiceRestController.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId("1129972_AFFILIE", "RechercherHabiliPers", 13333L).getBody();
        assertNotNull(expected);
    }

    @Test
    public void saveServiceTest() {
        BouchonServiceDto bsDto = getBouchonServiceDto();
        bouchonServiceRestController.createBouchonService(bsDto);
        verify(bouchonServiceRestController, times(1)).createBouchonService(bsDto);
    }

    @Test
    public void deleteCompteDemoTest() {
        bouchonServiceRestController.deleteBouchonService(232334L);
        verify(bouchonServiceRestController, times(1)).deleteBouchonService(232334L);

    }

    @Test
    public void findAllServiceByIdCompteDemoTest() {
        bouchonServiceRestController.findAllServiceByIdCmpDemo(232334L);
        verify(bouchonServiceRestController, times(1)).findAllServiceByIdCmpDemo(232334L);

    }

    @Test
    public void updateServiceTest() {
        bouchonServiceRestController.updateService(232334L,getModificationBserviceDto());
        verify(bouchonServiceRestController, times(1)).updateService(232334L,getModificationBserviceDto());
    }

    @Test
    public void updateServiceTest_PieceJointeNonAutorise() {
        ResponseEntity<MessageResponseDto> messageResponseDtoResponseEntity = bouchonServiceRestController.updateService(232334L, getModificationBserviceWithBadAttachmentDto());
        assertEquals(HttpStatus.BAD_REQUEST,messageResponseDtoResponseEntity.getStatusCode());
        verify(bouchonServiceRestController, times(1)).updateService(232334L,getModificationBserviceWithBadAttachmentDto());
    }

    @Test
    public void saveServiceTestWithException() {
        BouchonServiceDto bsDto = getBouchonServiceDto();
        when(bouchonServiceFacade.save(any(BouchonService.class))).thenThrow(new CompteDemoException("TEST"));
        bouchonServiceRestController.createBouchonService(bsDto);
        verify(bouchonServiceRestController, times(1)).createBouchonService(bsDto);
    }

    @Test
    public void findCompteDemoByIdTestWithException() {
        BouchonService bService = getBouchonService();
        when(bouchonServiceFacade.findById(any(Long.class))).thenThrow(new BouchonServiceException("TEST"));
        bouchonServiceRestController.findServiceById(232334L);
        verify(bouchonServiceRestController, times(1)).findServiceById(232334L);

    }

    @Test
    public void deleteCompteDemoTestWihException() {
        Mockito.doThrow(new BouchonServiceException("TEST")).when(bouchonServiceFacade).deleteBouchonService(any(Long.class));
        bouchonServiceRestController.deleteBouchonService(232334L);
        verify(bouchonServiceRestController, times(1)).deleteBouchonService(232334L);

    }

    @Test
    public void findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoIdTestWithException() {

        BouchonService bs = getBouchonService();

        when(bouchonServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId("1129972_AFFILIE", "RechercherHabiliPers", 13333L))
                .thenThrow(new BouchonServiceNonTrouveException("TEST","RechercherHabiliPers","1129972_AFFILIE",13333L));
        bouchonServiceRestController.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId("1129972_AFFILIE", "RechercherHabiliPers", 13333L);
        verify(bouchonServiceRestController, times(1))
                .findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId("1129972_AFFILIE", "RechercherHabiliPers", 13333L);

    }
}
