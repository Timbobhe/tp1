package fr.ag2rlamondiale.cab.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
@Table(name = "TBCLXPGR")
public class ParametreGrille {

	@Id
	@Column(name = "IDGRL", nullable = false)
	@EqualsAndHashCode.Include
	private Long id;
	
	@Column(name = "TYGRL", nullable = false)
	private String typeGrille;
	
	@Column(name = "LBGRL")
	private String libelleGrille;
	

	@Column(name = "TSCRE", nullable = false)
	@CreatedDate
	private Date dateCreation;

	@Column(name = "TSMAJ")
	@LastModifiedDate
	private Date dateMiseAjour;
	
	/*
	 * @OneToMany(targetEntity = ParametreTaux.class, fetch = FetchType.LAZY)
	 * 
	 * @ToString.Exclude private List<ParametreTaux> listTauxGrille = new
	 * ArrayList<>();
	 */

    @PrePersist
    public void prePersist() {
        this.setDateCreation(new Date());
    }

    @PreUpdate
    public void preUpdate() {
        this.setDateMiseAjour(new Date());
    }
}
