package fr.ag2rlamondiale.cab.business;

import java.util.List;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationCompteDemoDto;

@Service
public interface ICompteDemoFacade {

	List<CompteDemo> findAll();

	CompteDemo save(CompteDemo cpDemo);

	CompteDemo findById(Long id);

	CompteDemo findCompteDemoByRefExt(String refExt);

	CompteDemo findCompteDemoByNumPers(String numPers);

	void deleteCompteDemo(Long id);

	CompteDemo clone(Long idCompteDemoSource, ModificationCompteDemoDto modifCompteDemo);

	CompteDemo modifier(Long idCompteDemoSource, ModificationCompteDemoDto modifCompteDemo);

}
