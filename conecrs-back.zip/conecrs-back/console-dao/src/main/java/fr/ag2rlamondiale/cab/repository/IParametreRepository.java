package fr.ag2rlamondiale.cab.repository;

import fr.ag2rlamondiale.cab.domain.Parametre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

@Repository
public interface IParametreRepository extends JpaRepository<Parametre, Long>, JpaSpecificationExecutor<Parametre> {
//    @Query("SELECT p FROM Parametre p " +
//            "WHERE p.typeParam = ?1 and p.codeParam = ?2 " +
//            "and p.dateDebutValidite <= CURRENT_DATE and (p.dateFinValidite IS NULL OR p.dateFinValidite >= CURRENT_DATE)")
//    Parametre findParamByCode(String type, String code, LocalDate date);
//
//    @Query("SELECT p FROM Parametre p " +
//            "WHERE p.typeParam = ?1 " +
//            "and p.dateDebutValidite <= CURRENT_DATE and (p.dateFinValidite IS NULL OR p.dateFinValidite >= CURRENT_DATE)")
//    List<Parametre> findParamsByType(String type, LocalDate date);

}
