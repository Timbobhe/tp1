package fr.ag2rlamondiale.cab.business;

import java.util.List;

import fr.ag2rlamondiale.cab.dto.parametre.RequestParametreDto;
import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.domain.Parametre;

@Service
public interface IParametreFacade {

	List<Parametre> findAll();

	Parametre save(Parametre param);

    List<Parametre> find(RequestParametreDto req);
}
