package fr.ag2rlamondiale.cab.utils;

import org.apache.tika.Tika;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Map;

public class FileUtils {

    private FileUtils() {
    }

    public static final Map<String, String> fichierMimeTypeAutorise = Map.of(
            "application/pdf", "pdf");


    /**
     * @param base64
     * @return
     */
    public static final boolean isFileAuthorized(String base64) {
        Tika tika = new Tika();
        final byte[] pieceJointeBytes = Base64.getDecoder().decode(base64);
        String mimeTypeFichier = tika.detect(pieceJointeBytes);
        return fichierMimeTypeAutorise.get(mimeTypeFichier) != null;
    }

    /**
     * @param base64Bytes
     * @return
     */
    public static String extraireExtension(final byte[] base64Bytes) {
        Tika tika = new Tika();
        String mimeTypeFichier = tika.detect(base64Bytes);
        return fichierMimeTypeAutorise.get(mimeTypeFichier);
    }

    /**
     * @param pathFichier
     * @param extension
     * @return
     * @throws IOException
     */
    public static File creerFichierTemp(final String pathFichier, final String extension) throws IOException {
        return File.createTempFile(pathFichier, extension);
    }

    /**
     * @param pieceJointeBytes
     * @param fichierTemp
     */
    public static void ecrireFichier(byte[] pieceJointeBytes, File fichierTemp) throws IOException {
        Files.write(fichierTemp.toPath(), pieceJointeBytes);
    }


    /**
     * @param fichierPath
     * @param contenuFichier
     * @return
     */
    public static HttpHeaders generateFileHttpHeaders(final Path fichierPath, final byte[] contenuFichier) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentLength(contenuFichier.length);
        Tika tika = new Tika();
        final String mimeType = tika.detect(contenuFichier);
        headers.setContentType(MediaType.valueOf(mimeType));
        headers.setContentDisposition(ContentDisposition.builder("attachment")
                .filename(fichierPath.getFileName().toString())
                .build()
        );
        return headers;
    }
}
