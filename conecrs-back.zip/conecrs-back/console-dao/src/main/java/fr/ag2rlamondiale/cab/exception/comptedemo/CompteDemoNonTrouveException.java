package fr.ag2rlamondiale.cab.exception.comptedemo;

public class CompteDemoNonTrouveException extends CompteDemoException {
    public CompteDemoNonTrouveException() {
        super(AUCUN_COMPTEDEMO_TROUVE);
    }

    public CompteDemoNonTrouveException(String message) {
        super(AUCUN_COMPTEDEMO_TROUVE + " : " + message);
    }
}
