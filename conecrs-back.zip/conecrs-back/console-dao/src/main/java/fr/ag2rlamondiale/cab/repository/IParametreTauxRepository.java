package fr.ag2rlamondiale.cab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fr.ag2rlamondiale.cab.domain.ParametreTaux;

@Repository
public interface IParametreTauxRepository extends JpaRepository<ParametreTaux, Long> {
    @Query("SELECT pt FROM ParametreTaux pt WHERE pt.typeGrille = :type and (:duree is null or pt.duree = :duree)")
    ParametreTaux findTauxByTypeGrille(@Param("type") String typeGrille,@Param("duree") Integer duree);
}
