package fr.ag2rlamondiale.cab.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * Accéder aux libellé des produits ERE et MDPRO
 */
@Entity
@Table(name = "TBCLXPRD")
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Produit implements Serializable {
	private static final long serialVersionUID = 4817813927514810093L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqprd")
	@SequenceGenerator(name = "seqprd", sequenceName = "CLXPRDQ", allocationSize = 1)
	@Column(name = "IDPRD", nullable = false)
	private Long id;

	@EqualsAndHashCode.Include
	@Column(name = "TYPCTR", nullable = false)
	private String typeContrat;

	@EqualsAndHashCode.Include
	@Column(name = "COFIL", nullable = false)
	private String codeFiliale;

	@EqualsAndHashCode.Include
	@Column(name = "NOGENCTR")
	private String numeroGeneration;

	@Column(name = "LBPRD", nullable = false)
	private String libelle;

    @Column(name = "LBFIS")
    private String libelleFiscalite;

    @Column(name = "INDED")
    private Boolean deductible;
}
