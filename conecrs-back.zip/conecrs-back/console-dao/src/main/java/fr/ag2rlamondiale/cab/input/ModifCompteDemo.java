package fr.ag2rlamondiale.cab.input;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ModifCompteDemo {
    String refExterne;
    String numPersonne;
    String description;
}
