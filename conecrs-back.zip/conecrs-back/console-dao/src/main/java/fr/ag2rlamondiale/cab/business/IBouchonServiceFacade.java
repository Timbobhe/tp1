package fr.ag2rlamondiale.cab.business;

import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationBouchonServiceDto;

import java.io.File;
import java.util.List;


public interface IBouchonServiceFacade {

	List<BouchonService> findAll();

	BouchonService save(BouchonService bService);

	BouchonService findById(Long id);

	BouchonService findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(String idRequete, String idService,
			Long idCmDem);

	List<BouchonService> findAllServiceByIdCmpDemo(Long idCmDem);

	void deleteBouchonService(Long id);

	List<BouchonService> saveAll(List<BouchonService> bouchonServices);

	BouchonService modifier(Long idBservice, ModificationBouchonServiceDto modifBservice);

    File getBouchonServiceFile(final Long id);

    boolean isPieceJointeAuthorized(final String base64);
}
