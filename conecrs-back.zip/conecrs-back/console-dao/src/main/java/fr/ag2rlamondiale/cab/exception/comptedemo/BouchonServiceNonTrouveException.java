package fr.ag2rlamondiale.cab.exception.comptedemo;

public class BouchonServiceNonTrouveException extends BouchonServiceException {
    public BouchonServiceNonTrouveException(String message, String idService, String idRequete, Long idCmDem) {
        super(message, idService, idRequete, idCmDem);
    }
}
