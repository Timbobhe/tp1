package fr.ag2rlamondiale.cab.domain;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
@Table(name = "TBCLXPTX")
public class ParametreTaux {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqParamTx")
    @SequenceGenerator(name = "seqParamTx", sequenceName = "CLXPTXQ", allocationSize = 1)
    @Column(name = "IDPTX", nullable = false)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "TYPTX", nullable = false)
    private String typeTaux;

    @Column(name = "TYGRL", nullable = false)
    private String typeGrille;

    @Column(name = "DUGRL")
    private Integer duree;

    @Column(name = "VAPTX", nullable = false)
    private double taux;

    @Column(name = "TSCRE", nullable = false)
    @CreatedDate
    private Date dateCreation;

    @Column(name = "TSMAJ")
    @LastModifiedDate
    private Date dateMiseAjour;

    @PrePersist
    public void prePersist() {
        this.setDateCreation(new Date());
    }

    @PreUpdate
    public void preUpdate() {
        this.setDateMiseAjour(new Date());
    }

}
