package fr.ag2rlamondiale.cab.business.impl;


import fr.ag2rlamondiale.cab.business.IParametreFacade;
import fr.ag2rlamondiale.cab.domain.Parametre;
import fr.ag2rlamondiale.cab.dto.parametre.RequestParametreDto;
import fr.ag2rlamondiale.cab.repository.IParametreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;

import static fr.ag2rlamondiale.cab.repository.specification.ParametreSpecifications.fromType;

@Service
public class ParametreFacadeImpl implements IParametreFacade {
    @Autowired
    private IParametreRepository repository;

    @Override
    public List<Parametre> findAll() {
        return repository.findAll();
    }

    @Override
    public Parametre save(Parametre param) {
        return repository.save(param);
    }

    @Override
    public List<Parametre> find(RequestParametreDto req) {
        final Specification<Parametre> spec = fromType(req.getTypeParam(), req.getDate());

        return repository.findAll(spec);
    }


}
