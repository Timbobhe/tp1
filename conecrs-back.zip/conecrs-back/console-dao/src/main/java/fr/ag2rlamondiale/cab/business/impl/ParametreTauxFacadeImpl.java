package fr.ag2rlamondiale.cab.business.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.business.IParametreTauxFacade;
import fr.ag2rlamondiale.cab.domain.ParametreTaux;
import fr.ag2rlamondiale.cab.repository.IParametreTauxRepository;

@Service
public class ParametreTauxFacadeImpl implements IParametreTauxFacade {
    @Autowired
    private IParametreTauxRepository repository;

	@Override
	public List<ParametreTaux> findAll() {
		return repository.findAll();
	}

	@Override
	public ParametreTaux save(ParametreTaux param) {
		return repository.save(param);
	}

	@Override
	public Optional<ParametreTaux> findById(Long id) {
		return repository.findById(id);
	}

	@Override
	public ParametreTaux findByTypeGrille(String typeGrille, Integer duree) {
		return repository.findTauxByTypeGrille(typeGrille, duree);
	}

	

  
}
