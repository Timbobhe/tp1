package fr.ag2rlamondiale.cab.business.impl;

import fr.ag2rlamondiale.cab.business.IBouchonServiceFacade;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationBouchonServiceDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceException;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceNonTrouveException;
import fr.ag2rlamondiale.cab.repository.IBouchonServiceRepository;
import fr.ag2rlamondiale.cab.utils.FileUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.List;

@Slf4j
@RequiredArgsConstructor
@Service
public class BouchonServiceFacadeImpl implements IBouchonServiceFacade {
    @Autowired
    private IBouchonServiceRepository repositoryBService;

    public List<BouchonService> findAll() {
        log.info("findAll**");
        return repositoryBService.findAll();
    }

    public BouchonService save(BouchonService bServ) {
        log.info("save **:{}", bServ);
        BouchonService created = repositoryBService.save(bServ);
        log.info("Sauvegarde d'un Service :{}", created);
        return created;
    }

    public BouchonService findById(Long id) {
        log.info("findById **:{}", id);
        var bService = repositoryBService.findById(id);

        if (bService.isEmpty()) {
            log.info("Aucun element trouvé:{}", id);
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.AUCUN_ElEMENT_TROUVE.getMessage());
        }
        return bService.get();
    }

    public BouchonService findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(
            String idRequete, String idService, Long idCmDem) {
        log.info("findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId ** : idService={}, idRequete={}, idCmDem={}",
                idService, idRequete, idCmDem);
        BouchonService bouchon;
        if (idRequete.isBlank()) {
            bouchon = repositoryBService
                    .findBouchonServiceByRequeteIdEmptyAndServiceIdAndCompteDemoId(idService, idCmDem);
        } else {
            bouchon = repositoryBService
                    .findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(idRequete, idService, idCmDem);
        }
        if (bouchon == null)
            throw new BouchonServiceNonTrouveException(BouchonServiceException.ExceptionMessage.AUCUN_ElEMENT_TROUVE.getMessage(), idService, idRequete, idCmDem);
        return bouchon;

    }

    public List<BouchonService> findAllServiceByIdCmpDemo(Long idCmDem) {
        log.info("findAllServiceByIdCmpDemo ** : idCmDem={}", idCmDem);
        List<BouchonService> bouchonList = repositoryBService.findAllServiceByIdCmpDemo(idCmDem);

        return bouchonList;
    }

    public void deleteBouchonService(Long id) {
        repositoryBService.deleteById(id);
    }

    @Override
    public List<BouchonService> saveAll(List<BouchonService> bouchonServices) {
        log.info("save **:{}:{}", bouchonServices.size(), "bouchons");
        List<BouchonService> created = repositoryBService.saveAll(bouchonServices);
        log.info("Sauvegarde d'un Service :{}", created);
        return created;
    }

    @Override
    public BouchonService modifier(Long idBservice, ModificationBouchonServiceDto modifBservice) {
        log.info("modifier **: source {}  avec {}", idBservice, modifBservice);
        BouchonService bouchonServiceSource = findById(idBservice);
        BouchonService bservice = bouchonServiceSource.toBuilder()
                .idService(modifBservice.getIdService())
                .idRequete(modifBservice.getIdRequete())
                .vaRep(modifBservice.getVaRep())
                .pieceJointe(modifBservice.getPieceJointe())
                .dateMiseAjour(null)
                .pieceJointe(modifBservice.getPieceJointe())
                .build();
        if (bouchonServiceSource.isSame(bservice)) {
            throw new BouchonServiceException("bouchon service not modified");
        }
        try {
            BouchonService modified = repositoryBService.save(bservice);
            log.info("modification d'un bouchon service :{}", bservice);
            return modified;
        } catch (Exception e) {
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.NOT_MODIFIED.getMessage());
        }
    }

    @Override
    public File getBouchonServiceFile(final Long id) {
        final BouchonService bouchonServiceSource = findById(id);
        if (bouchonServiceSource == null) {
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.NOT_FOUND.getMessage());
        }
        final String pieceJointe = bouchonServiceSource.getPieceJointe();
        if (pieceJointe == null) {
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.PIECE_JOINTE_NOT_FOUND.getMessage());
        }
        final byte[] pieceJointeBytes = Base64.getDecoder().decode(pieceJointe);
        final String extension = FileUtils.extraireExtension(pieceJointeBytes);
        final String fileName = new SimpleDateFormat("yyyy-MM-dd hh-mm-ss").format(new Date());
        try {
            final File fichierTemp = FileUtils.creerFichierTemp(fileName, "." + extension);
            FileUtils.ecrireFichier(pieceJointeBytes, fichierTemp);
            return fichierTemp;
        } catch (IOException e) {
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.NOT_MODIFIED.getMessage());
        }
    }

    @Override
    public boolean isPieceJointeAuthorized(String base64) throws BouchonServiceException {
        if (base64 != null && !FileUtils.isFileAuthorized(base64)) {
            throw new BouchonServiceException(BouchonServiceException.ExceptionMessage.FILE_NOT_PERMITTED.getMessage());
        }
        return true;
    }

}
