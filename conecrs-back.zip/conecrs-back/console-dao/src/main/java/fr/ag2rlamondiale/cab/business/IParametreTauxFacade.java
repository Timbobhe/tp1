package fr.ag2rlamondiale.cab.business;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.domain.ParametreTaux;

@Service
public interface IParametreTauxFacade {

	List<ParametreTaux> findAll();

	ParametreTaux save(ParametreTaux param);

	Optional<ParametreTaux> findById(Long id);
	
	ParametreTaux findByTypeGrille(String typeGrille, Integer duree);
	
	

}
