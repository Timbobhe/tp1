package fr.ag2rlamondiale.cab.repository;

import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ICompteDemoRepository extends JpaRepository<CompteDemo, Long> {
    @Query("SELECT cd FROM CompteDemo cd WHERE cd.numReferenceExterne = ?1")
    CompteDemo findCompteDemoByRefExt(String refExt);

    @Query("SELECT cd FROM CompteDemo cd WHERE cd.numPersonne = ?1")
    CompteDemo findCompteDemoByNumPers(String numPers);
}
