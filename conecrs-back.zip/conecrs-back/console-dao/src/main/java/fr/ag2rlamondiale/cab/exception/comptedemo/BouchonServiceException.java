package fr.ag2rlamondiale.cab.exception.comptedemo;

import lombok.Getter;

public class BouchonServiceException extends RuntimeException {
    private static final long serialVersionUID = 3754132857741577568L;

    @Getter
    private String idService;

    @Getter
    private String idRequete;

    @Getter
    private Long idCmDem;

    public BouchonServiceException(String message) {
        super(message + "");
    }

    public BouchonServiceException(String message, String idService, String idRequete, Long idCmDem) {
        super(message + ", serviceId=" + idService + ", requeteId=" + idRequete + ", idCompteDemo=" + idCmDem);
        this.idService = idService;
        this.idRequete = idRequete;
        this.idCmDem = idCmDem;
    }

    public BouchonServiceException(String message, Long idCmDem) {
        super(message + " idCompteDemo=" + idCmDem);
        this.idCmDem = idCmDem;
    }

    public enum ExceptionMessage {
        AUCUN_ELEMENT_SAUVEGARDE("Aucun element n'a \u00E9t\u00E9 sauvegard\u00E9!"),
        AUCUN_REQUETE_TROUVE("Aucun requete ID n'a \u00E9t\u00E9 trouv\u00E9!"),
        AUCUN_ElEMENT_TROUVE("Aucun element n'a \u00E9t\u00E9 trouv\u00E9!"),
        NOT_MODIFIED("Bouchon non modifi\u00E9"),
        FILE_NOT_PERMITTED("Format de fichier non autorisé"),
        PIECE_JOINTE_NOT_FOUND("Piece jointe introuvable"),
        NOT_FOUND("Bouchon introuvable");
        private final String message;

        ExceptionMessage(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
}
