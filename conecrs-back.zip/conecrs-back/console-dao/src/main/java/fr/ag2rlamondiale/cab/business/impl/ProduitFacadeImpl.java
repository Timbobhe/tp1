package fr.ag2rlamondiale.cab.business.impl;


import fr.ag2rlamondiale.cab.exception.ProduitException;
import fr.ag2rlamondiale.cab.repository.IProduitRepository;
import fr.ag2rlamondiale.cab.business.IProduitFacade;
import fr.ag2rlamondiale.cab.domain.Produit;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Slf4j
@Service
public class ProduitFacadeImpl implements IProduitFacade {
    @Autowired
    private IProduitRepository repository;

    @Override
    public List<Produit> findByFiliales(String codeFiliale) {
        log.info("findByFiliales** : {}", codeFiliale);
        List<Produit> result = repository.findByFiliales(codeFiliale);
        if (CollectionUtils.isEmpty(result))
            throw new ProduitException(ProduitException.AUCUN_PRODUIT_TROUVE);

        return result;
    }
}
