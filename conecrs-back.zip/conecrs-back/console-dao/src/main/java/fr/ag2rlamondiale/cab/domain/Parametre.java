package fr.ag2rlamondiale.cab.domain;

import java.util.Date;

import javax.persistence.*;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
@Table(name = "TBCLXPRM")
public class Parametre {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqParam")
	@SequenceGenerator(name = "seqParam", sequenceName = "CLXPRMQ", allocationSize = 1)
	@Column(name = "IDPRM", nullable = false)
	@EqualsAndHashCode.Include
	private Long id;
	
	@Column(name = "TYPRM", nullable = false)
	private String typeParam;

	@Column(name = "COPRM", nullable = false)
	private String codeParam;

	@Column(name = "LBPRM")
	private String libelleParam;
	
	@Column(name = "VAPRM001")
	private String valeur1;
	
	@Column(name = "VAPRM002")
	private String valeur2;
	

	@Column(name = "DTDEBVAL", nullable = false)
	private Date dateDebutValidite;

	@Column(name = "DTFINVAL")
	private Date dateFinValidite;

	@Column(name = "TSCRE", nullable = false)
	@CreatedDate
	private Date dateCreation;

	@Column(name = "TSMAJ")
	@LastModifiedDate
	private Date dateMiseAjour;


    @PrePersist
    public void prePersist() {
        this.setDateCreation(new Date());
    }

    @PreUpdate
    public void preUpdate() {
        this.setDateMiseAjour(new Date());
    }

}
