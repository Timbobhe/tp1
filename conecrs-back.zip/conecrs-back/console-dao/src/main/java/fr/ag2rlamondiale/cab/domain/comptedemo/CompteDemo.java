package fr.ag2rlamondiale.cab.domain.comptedemo;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.util.ArrayList;
import java.util.Date;
import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;


@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
@Table(name = "TBCL0CDM")
public class CompteDemo implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqCmpDemo")
    @SequenceGenerator(name = "seqCmpDemo", sequenceName = "CL0CDMQ", allocationSize = 1)
    @Column(name = "IDCPTDEM", nullable = false)
    @EqualsAndHashCode.Include
    private Long id;

    @Column(name = "NOREFEXT", length = 50)
    private String numReferenceExterne;

    @Column(name = "NOPER", length = 20)
    private String numPersonne;

    @Column(name = "VADSC", nullable = false, length = 260)
    private String description;

    @Column(name = "TSCRE", nullable = false)
    @CreatedDate
    private Date dateCreation;

    @Column(name = "TSMAJ")
    @LastModifiedDate
    private Date dateMiseAjour;

    @OneToMany(targetEntity = BouchonService.class, cascade = CascadeType.MERGE, mappedBy = "compteDemo", fetch = FetchType.LAZY, orphanRemoval = true)
    @ToString.Exclude
    private List<BouchonService> bouchonService = new ArrayList<>();

    @PrePersist
    public void prePersist() {
        this.setDateCreation(new Date());
    }

    @PreUpdate
    public void preUpdate() {
        this.setDateMiseAjour(new Date());
    }

    public boolean isSame(CompteDemo that) {
        if (this == that) return true;
        return Objects.equals(numReferenceExterne, that.numReferenceExterne)
                && Objects.equals(numPersonne, that.numPersonne)
                && Objects.equals(description, that.description);
    }
}
