package fr.ag2rlamondiale.cab.repository.specification;

import fr.ag2rlamondiale.cab.domain.Parametre;
import fr.ag2rlamondiale.cab.utils.DateUtils;
import org.springframework.data.jpa.domain.Specification;

import javax.annotation.Nullable;
import javax.persistence.criteria.Predicate;
import java.time.LocalDate;
import java.util.Date;

/**
 * https://spring.io/blog/2011/04/26/advanced-spring-data-jpa-specifications-and-querydsl/
 */
public class ParametreSpecifications {

    public static Specification<Parametre> fromType(String typeParam, @Nullable LocalDate date) {
        return (root, query, cb) -> {

            LocalDate today = LocalDate.now();
            final Date queryDate = DateUtils.toDate(date == null ? today : date);


            final Predicate isType = cb.equal(root.get("typeParam"), typeParam);
            final Predicate isStart = cb.lessThanOrEqualTo(root.get("dateDebutValidite"), queryDate);
            final Predicate isNotTerminate = cb.or(
                    cb.isNull(root.get("dateFinValidite")),
                    cb.greaterThanOrEqualTo(root.get("dateFinValidite"), queryDate)
            );
            return cb.and(isType, isStart, isNotTerminate);
        };
    }

}
