package fr.ag2rlamondiale.cab.exception.comptedemo;

public class CompteDemoException extends RuntimeException {
    public static final String AUCUN_COMPTEDEMO_TROUVE = "Aucun compte demo n'a \u00E9t\u00E9 trouv\u00E9";
    private static final long serialVersionUID = -1306770644626030983L;

    public CompteDemoException(String message) {
        super(message);
    }

    public enum ExceptionMessage {
        NOT_FOUND("Aucun compte demo n'a \u00E9t\u00E9 trouv\u00E9"),
        NOT_CLONED("Compte Demo non clon\u00E9"),
        NOT_MODIFIED("Compte Demo non modifi\u00E9"),
        NOT_DELETED("Compte Demo non supprim\u00E9");
        private final String message;

        ExceptionMessage(String message) {
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }
}
