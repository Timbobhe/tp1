package fr.ag2rlamondiale.cab.business;

import java.util.List;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.domain.ParametreGrille;

@Service
public interface IParametreGrilleFacade {

	List<ParametreGrille> findAll();

	ParametreGrille save(ParametreGrille param);

	ParametreGrille findByIdGrille(Long id);

}
