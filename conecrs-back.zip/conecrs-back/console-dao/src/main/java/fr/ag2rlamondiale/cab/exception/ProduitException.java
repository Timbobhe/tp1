package fr.ag2rlamondiale.cab.exception;

public class ProduitException extends RuntimeException {
	private static final long serialVersionUID = -7538895188798679948L;

	public static final String AUCUN_PRODUIT_TROUVE = "Aucun produit n'a été trouvée!";

    public ProduitException(String message) {
        super(message);
    }
}
