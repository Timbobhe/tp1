package fr.ag2rlamondiale.cab.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import fr.ag2rlamondiale.cab.domain.ParametreGrille;

@Repository
public interface IParametreGrilleRepository extends JpaRepository<ParametreGrille, Long> {

}
