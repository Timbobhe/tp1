package fr.ag2rlamondiale.cab.repository;

import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface IBouchonServiceRepository extends JpaRepository<BouchonService, Long> {
    @Query("SELECT bs FROM BouchonService bs WHERE bs.idRequete=?1 and bs.idService =?2 and bs.compteDemo.id = ?3")
    BouchonService findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(String idRequete, String idService, Long id);

    @Query("SELECT bs FROM BouchonService bs WHERE bs.idService =?1 and bs.compteDemo.id = ?2")
    BouchonService findBouchonServiceByRequeteIdEmptyAndServiceIdAndCompteDemoId(String idService, Long id);

    @Query("SELECT bs FROM BouchonService bs WHERE bs.compteDemo.id = ?1")
    List<BouchonService> findAllServiceByIdCmpDemo(Long idCmDem);

    List<BouchonService> findBouchonServicesByIdService(String idService);
}