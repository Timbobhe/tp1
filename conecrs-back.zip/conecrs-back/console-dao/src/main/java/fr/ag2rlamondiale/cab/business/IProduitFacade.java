/*
 * Cree le 18 nov. 2020.
 * (c) Ag2r - La Mondiale, 2020. Tous droits reserves.
 */
package fr.ag2rlamondiale.cab.business;

import java.util.List;

import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.domain.Produit;

@Service
public interface IProduitFacade {
    List<Produit> findByFiliales(String codeFiliale);
}
