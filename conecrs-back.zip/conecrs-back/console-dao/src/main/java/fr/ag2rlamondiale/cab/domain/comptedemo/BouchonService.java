package fr.ag2rlamondiale.cab.domain.comptedemo;


import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@Table(name = "TBCL0BCH")
public class BouchonService implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seqBch")
    @SequenceGenerator(name = "seqBch", sequenceName = "CL0CDMQ", allocationSize = 1)
    @Column(name = "IDBCH", nullable = false)
    @EqualsAndHashCode.Include
    private Long id;

    @ManyToOne
    @JoinColumn(name = "IDCPTDEM")
    @ToString.Exclude
    private CompteDemo compteDemo;

    @Column(name = "IDSER", nullable = false, length = 200)
    private String idService;

    @Column(name = "IDREQ", nullable = false, length = 1000)
    private String idRequete;

    @ToString.Exclude
    @Column(name = "VAREP", nullable = false, length = 1000, columnDefinition = "CLOB")
    private String vaRep;

    @Column(name = "TSCRE", nullable = false)
    @CreatedDate
    private Date dateCreation;

    @Column(name = "TSMAJ")
    @LastModifiedDate
    private Date dateMiseAjour;

    @ToString.Exclude
    @Column(name = "VAATT", columnDefinition = "CLOB")
    private String pieceJointe;


    @PrePersist
    public void prePersist() {
        this.setDateCreation(new Date());
    }

    @PreUpdate
    public void preUpdate() {
        this.setDateMiseAjour(new Date());
    }

    public boolean isSame(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BouchonService that = (BouchonService) o;
        return Objects.equals(idService, that.idService) && Objects.equals(idRequete, that.idRequete) && Objects.equals(vaRep, that.vaRep) && Objects.equals(pieceJointe, that.pieceJointe);
    }

}
