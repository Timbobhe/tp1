package fr.ag2rlamondiale.cab.business.impl;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.ag2rlamondiale.cab.business.IParametreGrilleFacade;
import fr.ag2rlamondiale.cab.domain.ParametreGrille;
import fr.ag2rlamondiale.cab.repository.IParametreGrilleRepository;

@Service
public class ParametreGrilleFacadeImpl implements IParametreGrilleFacade {
    @Autowired
    private IParametreGrilleRepository repository;

	@Override
	public List<ParametreGrille> findAll() {
		return repository.findAll();
	}

	@Override
	public ParametreGrille save(ParametreGrille param) {
		return repository.save(param);
	}

	@Override
	public ParametreGrille findByIdGrille(Long id) {
		Optional<ParametreGrille> paramGrille = repository.findById(id);
		return paramGrille.isPresent() ? paramGrille.get() : null;
	}

	



  
}
