package fr.ag2rlamondiale.cab.business.impl;

import fr.ag2rlamondiale.cab.business.IBouchonServiceFacade;
import fr.ag2rlamondiale.cab.business.ICompteDemoFacade;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationCompteDemoDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoNonTrouveException;
import fr.ag2rlamondiale.cab.repository.ICompteDemoRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
@Service("cab.compteDemoFacadeImpl")
public class CompteDemoFacadeImpl implements ICompteDemoFacade {
    @Autowired
    private ICompteDemoRepository repositoryCDemo;
    @Autowired
    private IBouchonServiceFacade bouchonServiceFacade;

    public List<CompteDemo> findAll() {
        log.info("findAll **");
        return repositoryCDemo.findAll();
    }

    public CompteDemo save(CompteDemo cptDemo) {
        log.info("save **:{}", cptDemo);
        CompteDemo created = repositoryCDemo.save(cptDemo);
        log.info("Sauvegarde d'un compte Demo :{}", created);
        return created;
    }

    public CompteDemo findById(Long id) {
        log.info("findById **:{}", id);
        var compteDemo = repositoryCDemo.findById(id);

        if (compteDemo.isEmpty()) {
            log.info("Aucun Compte Demo  trouvé:{}", id);
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_FOUND.getMessage());
        }
        return compteDemo.get();
    }

    public CompteDemo findCompteDemoByRefExt(String refExt) {
        log.info("findByRefExt **:{}", refExt);
        CompteDemo cmpDemo = repositoryCDemo.findCompteDemoByRefExt(refExt);
        if (cmpDemo == null) {
            log.info("Aucun Compte Demo trouvé:{}", refExt);
            throw new CompteDemoNonTrouveException("refExt=" + refExt);
        }
        return cmpDemo;
    }

    public CompteDemo findCompteDemoByNumPers(String numPers) {
        log.info("findByNumeroPersonne **:{}", numPers);
        CompteDemo cmpDemo = repositoryCDemo.findCompteDemoByNumPers(numPers);
        if (cmpDemo == null) {
            log.info("Aucun Compte Demo trouvé:{}", numPers);
            throw new CompteDemoNonTrouveException("numPers=" + numPers);
        }
        return cmpDemo;
    }

    public void deleteCompteDemo(Long id) {
        log.info("supprimer **: compte demo avec id: {}", id);
        try {
            repositoryCDemo.deleteById(id);
        } catch (Exception e) {
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_DELETED.getMessage());
        }
    }

    @Override
    public CompteDemo clone(Long idCompteDemoSource, ModificationCompteDemoDto modifCompteDemo) {
        log.info("clone **: source {} avec {}", idCompteDemoSource, modifCompteDemo);
        CompteDemo compteDemoSource = findById(idCompteDemoSource);
        CompteDemo compteDemoCopy = compteDemoSource.toBuilder().id(null).dateCreation(null).dateMiseAjour(null)
                // num ref has unique constraint
                .numReferenceExterne(modifCompteDemo.getNumReferenceExterne().trim())
                // num person has unique constraint
                .numPersonne(modifCompteDemo.getNumPersonne().trim()).description(modifCompteDemo.getDescription().trim()).bouchonService(null).build();
        if ((verifBlank(compteDemoCopy.getNumReferenceExterne()) && verifBlank(compteDemoCopy.getNumPersonne())) || compteDemoSource.isSame(compteDemoCopy)) {
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_CLONED.getMessage());
        }
        try {
            CompteDemo created = repositoryCDemo.save(compteDemoCopy);
            List<BouchonService> bouchonServices = bouchonServiceFacade.findAllServiceByIdCmpDemo(compteDemoSource.getId()).stream().map(bservice -> completeInfosBouchonService(bservice, modifCompteDemo, compteDemoSource)).map(bservice -> bservice.toBuilder().id(null).dateCreation(null).dateMiseAjour(null).compteDemo(created).build()).collect(Collectors.toList());

            bouchonServiceFacade.saveAll(bouchonServices);
            return created;
        } catch (Exception e) {
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_CLONED.getMessage());
        }
    }

    public CompteDemo modifier(Long idCompteDemoSource, ModificationCompteDemoDto modifCompteDemo) {
        log.info("modifier **: source {} avec {}", idCompteDemoSource, modifCompteDemo);
        CompteDemo compteDemoSource = findById(idCompteDemoSource);
        CompteDemo cptDemo = compteDemoSource.toBuilder().numReferenceExterne(modifCompteDemo.getNumReferenceExterne()).numPersonne(modifCompteDemo.getNumPersonne()).description(modifCompteDemo.getDescription()).build();
        if ((verifBlank(cptDemo.getNumReferenceExterne()) && verifBlank(cptDemo.getNumPersonne())) || compteDemoSource.isSame(cptDemo)) {
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_MODIFIED.getMessage());
        }
        try {
            CompteDemo modified = repositoryCDemo.save(cptDemo);
            log.info("modification d'un compte Demo :{}", cptDemo);
            return modified;
        } catch (Exception e) {
            throw new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_MODIFIED.getMessage());
        }
    }

    private boolean verifBlank(String str) {
        return StringUtils.isEmpty(str) || StringUtils.isEmpty(str.trim());
    }

    private BouchonService completeInfosBouchonService(BouchonService bs, ModificationCompteDemoDto modifCompteDemo, CompteDemo compteDemoSource) {
        if ("GestPersPhys_3/RechercherPPSilo_5".equals(bs.getIdService())) {
            bs.setIdRequete(modifCompteDemo.getNumReferenceExterne());
        } else if ("GestCtrPers_1/RechercherCtrPersSilo_3".equals(bs.getIdService())) {
            bs.setVaRep(bs.getVaRep().replaceAll(compteDemoSource.getNumReferenceExterne(), modifCompteDemo.getNumReferenceExterne()));
        }
        return bs;
    }
}
