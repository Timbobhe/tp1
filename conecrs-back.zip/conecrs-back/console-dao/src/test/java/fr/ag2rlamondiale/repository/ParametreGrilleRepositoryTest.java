package fr.ag2rlamondiale.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import fr.ag2rlamondiale.cab.domain.ParametreGrille;
import fr.ag2rlamondiale.cab.repository.IParametreGrilleRepository;
import fr.ag2rlamondiale.config.ParametreJpaConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ParametreJpaConfig.class }, loader = AnnotationConfigContextLoader.class)
@Transactional
public class ParametreGrilleRepositoryTest {

	@Autowired
	private IParametreGrilleRepository repo;

	@Test
	public void should_create_new_user() throws ParseException {
		// Given
		ParametreGrille paramGrille1 = ParametreGrille.builder().id(Long.valueOf(2413))
				.typeGrille("DYNAMIQUE_avant_2016").libelleGrille("Fonds de fonds Euro Garanti")
				.dateCreation(new Date()).dateMiseAjour(new Date()).build();
		ParametreGrille paramGrille2 = ParametreGrille.builder().id(Long.valueOf(2511))
				.typeGrille("DYNAMIQUE_avant_2016").libelleGrille("Allocation Profil A").dateCreation(new Date())
				.dateMiseAjour(new Date()).build();
		ParametreGrille paramGrille3 = ParametreGrille.builder().id(Long.valueOf(2535))
				.typeGrille("DYNAMIQUE_avant_2016").libelleGrille("INTEGRALE 83").dateCreation(new Date())
				.dateMiseAjour(new Date()).build();

		// Then
		repo.save(paramGrille1);
		repo.save(paramGrille2);
		repo.save(paramGrille3);

		Optional<ParametreGrille> paramGrille = repo.findById(Long.valueOf(2511));
		List<ParametreGrille> allParams = repo.findAll();
		
		// Assert
		assertFalse(allParams.isEmpty());
		assertEquals(3, allParams.size());
		
		assertTrue(paramGrille.isPresent());
		assertNotNull(paramGrille.get());
		assertEquals("Allocation Profil A", paramGrille.get().getLibelleGrille());
		
	}

}
