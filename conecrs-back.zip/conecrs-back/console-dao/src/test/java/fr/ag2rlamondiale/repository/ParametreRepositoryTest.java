package fr.ag2rlamondiale.repository;

import fr.ag2rlamondiale.cab.domain.Parametre;
import fr.ag2rlamondiale.cab.repository.IParametreRepository;
import fr.ag2rlamondiale.config.ParametreJpaConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.Optional;

import static fr.ag2rlamondiale.cab.repository.specification.ParametreSpecifications.fromType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {ParametreJpaConfig.class}, loader = AnnotationConfigContextLoader.class)
@Transactional
public class ParametreRepositoryTest {

    @Autowired
    private IParametreRepository repo;

    @Test
    public void should_create_new_param() throws ParseException {
        // Given
        DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");


        Parametre param = Parametre.builder()
                .id(39400L)
                .typeParam("PASS")
                .codeParam("PASS")
                .valeur1("44390")
                .libelleParam("Plafond Annuel Securite sociale")
                .dateDebutValidite(formatter.parse("01-01-2020"))
                .dateFinValidite(formatter.parse("31-12-2021"))
                .build();

        Parametre param2 = Parametre.builder()
                .id(39401L)
                .typeParam("PASS")
                .codeParam("PASS")
                .valeur1("44392")
                .libelleParam("Plafond Annuel Securite sociale")
                .dateDebutValidite(formatter.parse("01-01-2022"))
                .build();

        // Then
        repo.save(param);
        repo.save(param2);
        final LocalDate anneeCourante = LocalDate.of(2022, Month.JANUARY, 27);
        final LocalDate anneePrecedente = LocalDate.of(2021, Month.MAY, 25);
        Optional<Parametre> plafondSecuriteSocialeParam = repo.findOne(fromType("PASS", anneeCourante));
        Optional<Parametre> plafondSecuriteSocialePrecedent = repo.findOne(fromType("PASS", anneePrecedente));

        // Assert
        assertFalse(plafondSecuriteSocialeParam.isEmpty());
        assertEquals(44392, Integer.valueOf(plafondSecuriteSocialeParam.get().getValeur1()));


        assertFalse(plafondSecuriteSocialePrecedent.isEmpty());
        assertEquals(44390, Integer.valueOf(plafondSecuriteSocialePrecedent.get().getValeur1()));



        final List<Parametre> pass = repo.findAll(fromType("PASS", anneeCourante));
        assertEquals(1, pass.size());
    }

}
