package fr.ag2rlamondiale.console.impl;

import fr.ag2rlamondiale.cab.business.impl.BouchonServiceFacadeImpl;
import fr.ag2rlamondiale.cab.domain.comptedemo.BouchonService;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationBouchonServiceDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.BouchonServiceException;
import fr.ag2rlamondiale.cab.repository.IBouchonServiceRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class BouchonServiceFacadeImplTest {
    @Mock
    private IBouchonServiceRepository repositoryBService;

    @InjectMocks
    private BouchonServiceFacadeImpl bouchonServiceFacade;

    private ModificationBouchonServiceDto getModificationBserviceDto() {

        ModificationBouchonServiceDto modifbServiceDto = new ModificationBouchonServiceDto();
        modifbServiceDto.setIdService("R12");
        modifbServiceDto.setIdRequete("P12");
        modifbServiceDto.setVaRep("TEST");
        modifbServiceDto.setPieceJointe("TEST");
        return modifbServiceDto;
    }

    @Test
    public void findAllTest() {
        when(this.repositoryBService.findAll()).thenReturn(getBouchonServiceList());
        List<BouchonService> bouchonServiceList = bouchonServiceFacade.findAll();
        assertEquals(getBouchonServiceList().get(0).getCompteDemo().getId(), bouchonServiceList.get(0).getCompteDemo().getId());
        assertEquals(getBouchonServiceList().get(0).getIdRequete(), bouchonServiceList.get(0).getIdRequete());
        assertEquals(getBouchonServiceList().get(0).getIdService(), bouchonServiceList.get(0).getIdService());

    }

    @Test
    public void should_throw_exception_when_findByAll_bouchonService_isEmpty() {
        when(this.repositoryBService.findAll()).thenReturn(null).thenThrow(new BouchonServiceException(BouchonServiceException.ExceptionMessage.AUCUN_ElEMENT_TROUVE.getMessage()));
    }

    private List<BouchonService> getBouchonServiceList() {
        BouchonService b = getBouchonService();
        List<BouchonService> bservice = new ArrayList<>();
        bservice.add(b);
        return bservice;
    }

    private BouchonService getBouchonService() {
        BouchonService bserv = new BouchonService();
        CompteDemo cd = new CompteDemo();
        cd.setId(787878787L);
        cd.setNumReferenceExterne("T230O3");
        cd.setNumPersonne("P12");
        cd.setDateCreation(new Date());
        cd.setDateMiseAjour(null);
        bserv.setId(123445L);
        bserv.setCompteDemo(cd);
        bserv.setIdService("RechercherHabiliPers");
        bserv.setIdRequete("1129972_AFFILIE");
        bserv.setVaRep("test");
        bserv.setPieceJointe("test");
        bserv.setDateCreation(new Date());
        bserv.setDateMiseAjour(null);
        return bserv;
    }

    @Test
    public void SaveTest() {
        BouchonService bserviceDto = getBouchonService();
        BouchonService bservice = getBouchonService();
        bservice.setIdRequete("1129973_BIA");
        when(this.repositoryBService.save(ArgumentMatchers.any(BouchonService.class))).thenReturn(bservice);
        BouchonService created = bouchonServiceFacade.save(bserviceDto);
        assertEquals(created.getId(), bserviceDto.getId());
    }

    @Test
    public void findByIdTest() {
        BouchonService bserviceDto = getBouchonService();
        BouchonService bservice = getBouchonService();
        bservice.setId(123456L);
        when(repositoryBService.findById(bservice.getId())).thenReturn(Optional.of(bservice));
        BouchonService result = bouchonServiceFacade.findById(bservice.getId());
        assertEquals(bserviceDto.getIdRequete(), result.getIdRequete());
    }

    @Test
    public void should_throw_exception_when_findById_doesnt_exist() {
        BouchonService bservice = new BouchonService();
        bservice.setId(898L);
        when(repositoryBService.findById(bservice.getId())).thenReturn(Optional.empty()).thenThrow(new BouchonServiceException(BouchonServiceException.ExceptionMessage.AUCUN_ElEMENT_TROUVE.getMessage()));
    }

    @Test
    public void findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoIdTest() {
        BouchonService bs = getBouchonService();
        CompteDemo cdemo = new CompteDemo();
        cdemo.setId(124563L);
        cdemo.setNumReferenceExterne("RE546");
        cdemo.setNumPersonne("P100");
        cdemo.setDateCreation(new Date());
        cdemo.setDateMiseAjour(null);
        bs.setIdService("S37");
        bs.setIdRequete("R43");
        bs.setCompteDemo(cdemo);
        when(this.repositoryBService.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(bs.getIdRequete(), bs.getIdService(), bs.getCompteDemo().getId())).thenReturn(getBouchonService());
        BouchonService bouchonService = bouchonServiceFacade.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(bs.getIdRequete(), bs.getIdService(), bs.getCompteDemo().getId());
        assertEquals(getBouchonService().getVaRep(), bouchonService.getVaRep());
    }

    @Test
    public void should_throw_exception_when_findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId_doesnt_exist() {
        BouchonService bservice = getBouchonService();
        CompteDemo cdemo = new CompteDemo();
        cdemo.setId(124563L);
        cdemo.setNumReferenceExterne("RE546");
        cdemo.setNumPersonne("P100");
        cdemo.setDateCreation(new Date());
        cdemo.setDateMiseAjour(null);
        bservice.setIdService("RechercherHabiliPers");
        bservice.setIdRequete("1129972_AFFILIE");
        bservice.setCompteDemo(cdemo);
        when(repositoryBService.findBouchonServiceByRequeteIdAndServiceIdAndCompteDemoId(bservice.getIdRequete(), bservice.getIdService(), bservice.getCompteDemo().getId())).thenReturn(null).thenThrow(new BouchonServiceException(BouchonServiceException.ExceptionMessage.AUCUN_ElEMENT_TROUVE.getMessage()));
    }

    @Test
    public void deleteBouchonServiceTest() {
        BouchonService bservice = getBouchonService();

        when(repositoryBService.findById(bservice.getId())).thenReturn(Optional.of(bservice));
        bouchonServiceFacade.deleteBouchonService(bservice.getId());
    }

    @Test
    public void saveAllTest() {
        List<BouchonService> listBserviceMock = Arrays.asList(new BouchonService(), new BouchonService());
        when(this.repositoryBService.saveAll(any(ArrayList.class))).thenReturn(listBserviceMock);
        List<BouchonService> created = bouchonServiceFacade.saveAll(new ArrayList<>());
        assertEquals(created.size(), listBserviceMock.size());
    }

    @Test
    public void modifierTest() {
        BouchonService bserviceMock = getBouchonService();
        when(this.repositoryBService.findById(any(Long.class))).thenReturn(Optional.of(bserviceMock));
        when(this.repositoryBService.save(any(BouchonService.class))).thenReturn(bserviceMock);
        BouchonService created = bouchonServiceFacade.modifier(124563L, getModificationBserviceDto());
        assertEquals(created, bserviceMock);
    }

    @Test
    public void findAllByIdCompteDemoTest() {
        when(this.repositoryBService.findAllServiceByIdCmpDemo(any(Long.class))).thenReturn(getBouchonServiceList());
        List<BouchonService> bouchonServiceList = bouchonServiceFacade.findAllServiceByIdCmpDemo(124563L);
        assertEquals(getBouchonServiceList().get(0).getCompteDemo().getId(), bouchonServiceList.get(0).getCompteDemo().getId());
        assertEquals(getBouchonServiceList().get(0).getIdRequete(), bouchonServiceList.get(0).getIdRequete());
        assertEquals(getBouchonServiceList().get(0).getIdService(), bouchonServiceList.get(0).getIdService());

    }
}
