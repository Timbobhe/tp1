package fr.ag2rlamondiale.repository;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.AnnotationConfigContextLoader;
import org.springframework.transaction.annotation.Transactional;

import fr.ag2rlamondiale.cab.domain.ParametreTaux;
import fr.ag2rlamondiale.cab.repository.IParametreTauxRepository;
import fr.ag2rlamondiale.config.ParametreJpaConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { ParametreJpaConfig.class }, loader = AnnotationConfigContextLoader.class)
@Transactional
public class ParametreTauxRepositoryTest {

	@Autowired
	private IParametreTauxRepository repo;

	@Test
	public void should_create_new_user() throws ParseException {
		// Given
		ParametreTaux paramTaux1 = ParametreTaux.builder().id(Long.valueOf(2413))
				.typeGrille("DYNAMIQUE_avant_2016").typeTaux("Grille").duree(46).taux(0.0241)
				.dateCreation(new Date()).dateMiseAjour(new Date()).build();
		
		ParametreTaux paramTaux2 = ParametreTaux.builder().id(Long.valueOf(2413))
				.typeGrille("Action").typeTaux("Profil").taux(0.03)
				.dateCreation(new Date()).dateMiseAjour(new Date()).build();
		
		ParametreTaux paramTaux3 = ParametreTaux.builder().id(Long.valueOf(2413))
				.typeGrille("DYNAMIQUE_avant_2016").typeTaux("Grille").duree(29).taux(0.0237)
				.dateCreation(new Date()).dateMiseAjour(new Date()).build();

		// Then
		repo.save(paramTaux1);
		repo.save(paramTaux2);
		repo.save(paramTaux3);

		ParametreTaux paramTaux = repo.findTauxByTypeGrille("DYNAMIQUE_avant_2016", 46);
		List<ParametreTaux> allParams = repo.findAll();
		
		// Assert
		assertFalse(allParams.isEmpty());
		assertEquals(3, allParams.size());
		
		assertNotNull(paramTaux);
		assertEquals(0.0241, paramTaux.getTaux());
		
	}

}
