package fr.ag2rlamondiale.console.impl;

import fr.ag2rlamondiale.cab.business.IBouchonServiceFacade;
import fr.ag2rlamondiale.cab.business.impl.BouchonServiceFacadeImpl;
import fr.ag2rlamondiale.cab.business.impl.CompteDemoFacadeImpl;
import fr.ag2rlamondiale.cab.domain.comptedemo.CompteDemo;
import fr.ag2rlamondiale.cab.dto.comptedemo.ModificationCompteDemoDto;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoException;
import fr.ag2rlamondiale.cab.exception.comptedemo.CompteDemoNonTrouveException;
import fr.ag2rlamondiale.cab.repository.ICompteDemoRepository;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class CompteDemoFacadeImplTest {
    @Mock
    private ICompteDemoRepository compteDemoRepository;

    @InjectMocks
    private CompteDemoFacadeImpl compteDemoFacade;

    @Mock
    private IBouchonServiceFacade bouchonServiceFacade;

    @Test
    public void findAllTest() {
        when(this.compteDemoRepository.findAll()).thenReturn(getCompteDemoList());
        List<CompteDemo> compteDemoLists = compteDemoFacade.findAll();
        assertEquals(getCompteDemo().getNumPersonne(), compteDemoLists.get(0).getNumPersonne());
        assertEquals(getCompteDemo().getNumReferenceExterne(), compteDemoLists.get(0).getNumReferenceExterne());

    }

    private ModificationCompteDemoDto getModificationCompteDemoDto() {

        ModificationCompteDemoDto modifCDemoDto = new ModificationCompteDemoDto();
        modifCDemoDto.setNumReferenceExterne("R12");
        modifCDemoDto.setNumPersonne("P12");
        modifCDemoDto.setDescription("TEST");
        return modifCDemoDto;
    }

    private List<CompteDemo> getCompteDemoList() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(787878787L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        List<CompteDemo> cDemoLists = new ArrayList<>();
        cDemoLists.add(cDemo);
        return cDemoLists;
    }

    private CompteDemo getCompteDemo() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        return cDemo;
    }

    @Test
    public void SaveTest() {
        CompteDemo cDemo = getCompteDemo();
        when(this.compteDemoRepository.save(any(CompteDemo.class))).thenReturn(cDemo);
        CompteDemo created = compteDemoFacade.save(cDemo);
        assertEquals(created.getId(), cDemo.getId());
    }

    @Test
    public void updateTest() {
        CompteDemo cDemo = getCompteDemo();
        CompteDemo newCDemo = getCompteDemo();
        newCDemo.setNumPersonne("UP346");
        when(compteDemoRepository.findById(cDemo.getId())).thenReturn(Optional.of(cDemo));
        compteDemoFacade.save(newCDemo);
        Mockito.verify(compteDemoRepository).save(newCDemo);
    }

    @Test
    public void findByIdTest() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(123456L);
        when(compteDemoRepository.findById(cDemo.getId())).thenReturn(Optional.of(cDemo));
        CompteDemo expected = compteDemoFacade.findById(cDemo.getId());
        assertEquals(expected.getNumPersonne(), cDemo.getNumPersonne());
    }

    @Test
    public void should_throw_exception_when_findById_doesnt_exist() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        when(compteDemoRepository.findById(cDemo.getId())).thenReturn(Optional.empty()).thenThrow(new CompteDemoException(CompteDemoException.ExceptionMessage.NOT_FOUND.getMessage()));
        Assertions.assertThrows(CompteDemoException.class, () -> compteDemoFacade.findById(cDemo.getId()));
    }

    @Test
    public void findCompteDemoByRefExtTest() {
        CompteDemo cDemo = getCompteDemo();

        when(this.compteDemoRepository.findCompteDemoByRefExt(cDemo.getNumReferenceExterne())).thenReturn(getCompteDemo());
        CompteDemo compteDemo = compteDemoFacade.findCompteDemoByRefExt(cDemo.getNumReferenceExterne());
        assertEquals(compteDemo.getNumPersonne(), getCompteDemo().getNumPersonne());
    }

    @Test
    public void should_throw_exception_when_findCompteDemoByRefExt_doesnt_exist() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        when(compteDemoRepository.findCompteDemoByRefExt(cDemo.getNumReferenceExterne())).thenReturn(null).thenThrow(new CompteDemoNonTrouveException());
        Assertions.assertThrows(CompteDemoException.class, () -> compteDemoFacade.findById(cDemo.getId()));
    }

    @Test
    public void findCompteDemoByNumPersTest() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDescription("test unitaire");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        when(this.compteDemoRepository.findCompteDemoByNumPers(cDemo.getNumPersonne())).thenReturn(getCompteDemo());
        CompteDemo compteDemo = compteDemoFacade.findCompteDemoByNumPers(cDemo.getNumPersonne());
        assertEquals(getCompteDemo().getId(), compteDemo.getId());

    }

    @Test
    public void should_throw_exception_when_findCompteDemoByNumPers_doesnt_exist() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        when(compteDemoRepository.findCompteDemoByNumPers(cDemo.getNumPersonne())).thenReturn(null).thenThrow(new CompteDemoNonTrouveException());
        Assertions.assertThrows(CompteDemoNonTrouveException.class, () -> compteDemoFacade.findCompteDemoByNumPers(cDemo.getNumPersonne()));
    }

    @Test
    public void deleteCompteDemoTest() {
        CompteDemo cDemo = new CompteDemo();
        cDemo.setId(121234L);
        cDemo.setNumReferenceExterne("RE546");
        cDemo.setNumPersonne("P100");
        cDemo.setDateCreation(new Date());
        cDemo.setDateMiseAjour(null);
        when(compteDemoRepository.findById(cDemo.getId())).thenReturn(Optional.of(cDemo));
        compteDemoFacade.deleteCompteDemo(cDemo.getId());
        Mockito.verify(compteDemoRepository).deleteById(cDemo.getId());
    }

    @Test
    public void CloneTest() {
        CompteDemo cDemo = getCompteDemo();
        when(this.compteDemoRepository.save(any(CompteDemo.class))).thenReturn(cDemo);
        when(this.compteDemoRepository.findById(any(Long.class))).thenReturn(Optional.of(cDemo));
        when(bouchonServiceFacade.findAllServiceByIdCmpDemo(any(Long.class))).thenReturn(new ArrayList<>());
        when(bouchonServiceFacade.saveAll(any(ArrayList.class))).thenReturn(new ArrayList<>());
        CompteDemo created = compteDemoFacade.clone(121234L, getModificationCompteDemoDto());
        assertEquals(created.getId(), cDemo.getId());
    }

    @Test
    public void ModifTest() {
        CompteDemo cDemo = getCompteDemo();
        when(this.compteDemoRepository.save(any(CompteDemo.class))).thenReturn(cDemo);
        when(this.compteDemoRepository.findById(any(Long.class))).thenReturn(Optional.of(cDemo));
        CompteDemo created = compteDemoFacade.modifier(121234L, getModificationCompteDemoDto());
        assertEquals(created.getId(), cDemo.getId());
    }

}
