package fr.ag2rlamondiale.cab.utils;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.*;

class FileUtilsTest{

    @Test
    void testIsFileAuthorized_ko(){
        boolean fileAuthorized = FileUtils.isFileAuthorized("");
        assertFalse(fileAuthorized);
    }

    @Test
    void testIsFileAuthorized_ok() throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("file.pdf").getFile());
        final byte[] content = Files.readAllBytes(file.toPath());
        String encodedString = Base64.getEncoder().encodeToString(content);
        boolean fileAuthorized = FileUtils.isFileAuthorized(encodedString);
        assertTrue(fileAuthorized);

    }

    @Test
    void testExtraireExtension()  throws IOException {
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("file.pdf").getFile());
        final byte[] content = Files.readAllBytes(file.toPath());
        String extension = FileUtils.extraireExtension(content);
        assertEquals("pdf", extension);
    }

}
