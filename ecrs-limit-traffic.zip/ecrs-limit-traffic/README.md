# ECRS Limit traffic

# Switch Configuration

POST http://a1573-lmt.kdev/lmt/api/public/bucket/configuration/nie
```json
{
  "tokensInheritanceStrategy": "RESET",
  "usingConfigName": "max"
}
```

```shell
curl -X POST "http://a1573-lmt.kdev/lmt/api/public/bucket/configuration/nie" -H "accept: */*" -H "Content-Type: application/json" -d "{ \"tokensInheritanceStrategy\": \"RESET\", \"usingConfigName\": \"max\"}"
```
