package fr.ag2rlamondiale.ecrs.lmt.business;

import fr.ag2rlamondiale.ecrs.lmt.configuration.BucketConfig;
import fr.ag2rlamondiale.ecrs.lmt.dto.ConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.ReplaceConfigurationDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.StateConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.UserInfoDto;
import io.github.bucket4j.Bucket;
import org.springframework.lang.Nullable;

import java.util.Collection;
import java.util.Map;

public interface IBucketFacade {

    Collection<String> getBucketNames();

    BucketConfig getBucketConfig(String bucketName);

    /**
     * @see Bucket#replaceConfiguration(io.github.bucket4j.BucketConfiguration, io.github.bucket4j.TokensInheritanceStrategy)
     */
    BucketConfig replaceConfig(String bucketName, ReplaceConfigurationDto request);

    BucketConfig replaceConfigUsing(String bucketName, ReplaceConfigurationDto request);

    ConsumptionProbeDto tryConsumeAndReturnRemaining(String bucketName, long numTokens, @Nullable UserInfoDto userInfo);

    void addTokens(String bucketName, long tokensToAdd);

    void resetConfig();

    Map<String, StateConsumptionProbeDto> getStateConsumptionProbe();
}
