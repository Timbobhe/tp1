package fr.ag2rlamondiale.ecrs.lmt.configuration;

import lombok.Getter;

import java.time.temporal.ChronoUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Getter
@SuppressWarnings("java:S115")
public enum DurationUnit {
    days(ChronoUnit.DAYS),
    hours(ChronoUnit.HOURS),
    minutes(ChronoUnit.MINUTES),
    seconds(ChronoUnit.SECONDS),
    millis(ChronoUnit.MILLIS),
    nanos(ChronoUnit.NANOS);

    private final ChronoUnit chronoUnit;

    DurationUnit(ChronoUnit chronoUnit) {
        this.chronoUnit = chronoUnit;
    }

    static String toRegexPattern() {
        return Stream.of(values()).map(Enum::name).collect(Collectors.joining("|"));
    }
}
