package fr.ag2rlamondiale.ecrs.lmt.configuration;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import io.github.bucket4j.Bandwidth;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@JsonInclude(value = JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class BandwidthConfig {
    private String id;
    private BandwidthType type;
    private long capacity;

    @JsonPropertyDescription("Format (?<value>\\d+)\\s+(?<unit>days|hours|minutes|seconds|millis|nanos)")
    @ApiModelProperty(value = "Format (?<value>\\d+)\\s+(?<unit>days|hours|minutes|seconds|millis|nanos)", example = "10 days|hours|minutes|seconds|millis|nanos")
    private String period;
    private RefillConfig refill;


    public Bandwidth toBandwidth() {
        if (type == null) {
            throw new ConfigurationException("BandwidthType null");
        }

        switch (type) {
            case simple:
                return Bandwidth.simple(capacity, DurationConfig.fromString(period).toDuration());
            case classic:
                return Bandwidth.classic(capacity, refill.toRefill());
            default:
                throw new ConfigurationException("BandwidthType non gere : " + type);
        }
    }

    public BandwidthConfig dup() {
        return toBuilder()
                .refill(refill != null ? refill.dup() : null)
                .build();
    }
}
