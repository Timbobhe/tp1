package fr.ag2rlamondiale.ecrs.lmt.configuration;

import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.local.LocalBucketBuilder;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@ApiModel(description = "La Configuration consiste à définir une liste de bande passante." +
        "\nPar exemple avoir une capacité de 100 tickets pour 30 min avec une limite d'une consommation de 10 tickets par tranche de 1 minute" +
        "\nhttps://github.com/vladimir-bukhtoyarov/bucket4j/blob/4.0/doc-pages/basic-usage.md")
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@Data
public class BucketConfig {
    private List<BandwidthConfig> bandwidths = new ArrayList<>();

    public Bucket toBucket() {
        final LocalBucketBuilder builder = Bucket4j.builder();
        bandwidths.forEach(c -> builder.addLimit(c.toBandwidth()));
        return builder.build();
    }

    public BucketConfiguration toBucketConfiguration() {
        return new BucketConfiguration(bandwidths.stream()
                .map(BandwidthConfig::toBandwidth)
                .collect(Collectors.toList()));
    }

    public BucketConfig dup() {
        final BucketConfigBuilder builder = this.toBuilder();
        if (bandwidths != null) {
            builder.bandwidths(bandwidths.stream()
                    .map(BandwidthConfig::dup)
                    .collect(Collectors.toList())
            );
        }

        return builder.build();
    }
}
