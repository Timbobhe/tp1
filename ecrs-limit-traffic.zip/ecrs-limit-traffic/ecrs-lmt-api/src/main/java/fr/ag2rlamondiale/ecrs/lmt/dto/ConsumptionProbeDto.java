package fr.ag2rlamondiale.ecrs.lmt.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumptionProbeDto {
    private boolean consumed;
    private long remainingTokens;
    private long nanosToWaitForRefill;
    private long secToWaitForRefill;
}
