package fr.ag2rlamondiale.ecrs.lmt.config;

public class LmtRoles {
    public static final String ROLE_EXTERNAL = "ROLE_EXTERNAL";

    private LmtRoles() {
    }
}
