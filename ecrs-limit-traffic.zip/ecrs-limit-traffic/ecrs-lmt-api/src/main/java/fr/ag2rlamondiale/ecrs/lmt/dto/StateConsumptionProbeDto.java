package fr.ag2rlamondiale.ecrs.lmt.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class StateConsumptionProbeDto {
    private String bucketName;
    private ZonedDateTime instant;
    private ConsumptionProbeDto consumptionProbe;
}
