package fr.ag2rlamondiale.ecrs.lmt.dto;

import fr.ag2rlamondiale.ecrs.lmt.configuration.BucketConfig;
import io.github.bucket4j.TokensInheritanceStrategy;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(description = "2 usages : soit avec +usingConfigName+ pour appliquer une configuration d\u00E9j\u00E0 param\u00E9tr\u00E9e, soit +config+ pour cr\u00E9er une nouvelle configuration")
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
@Data
public class ReplaceConfigurationDto {
    private String usingConfigName;
    private BucketConfig config;
    private TokensInheritanceStrategy tokensInheritanceStrategy;
}
