package fr.ag2rlamondiale.ecrs.lmt.business.impl;

import fr.ag2rlamondiale.ecrs.lmt.business.IBucketFacade;
import fr.ag2rlamondiale.ecrs.lmt.configuration.BucketConfig;
import fr.ag2rlamondiale.ecrs.lmt.configuration.BucketsConfiguration;
import fr.ag2rlamondiale.ecrs.lmt.dto.ConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.ReplaceConfigurationDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.StateConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.UserInfoDto;
import fr.ag2rlamondiale.ecrs.lmt.mapping.Bucket4jMapper;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.BucketConfiguration;
import io.github.bucket4j.ConsumptionProbe;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@SuppressWarnings("java:S6212")
public class BucketFacadeImpl implements IBucketFacade {

    @Autowired
    private Bucket4jMapper mapper;

    @Autowired
    private BucketsConfiguration bucketsConfiguration;

    private Map<String, Bucket> cache = new ConcurrentHashMap<>();

    private Map<String, StateConsumptionProbeDto> stateConsumptionProbe = new ConcurrentHashMap<>();

    public Bucket getBucket(String bucketName) {
        return cache.computeIfAbsent(bucketName, s -> this.basicCreateBucket(bucketName));
    }

    public Bucket basicCreateBucket(String bucketName) {
        return getBucketConfig(bucketName).toBucket();
    }

    @Override
    public Collection<String> getBucketNames() {
        return bucketsConfiguration.getConfig().keySet();
    }

    @Override
    public BucketConfig getBucketConfig(String bucketName) {
        final String name = bucketName != null ? bucketName : BucketsConfiguration.NIE;
        final BucketConfig bucketConfig = bucketsConfiguration.get(name);
        Objects.requireNonNull(bucketConfig, "bucketName inconnu : " + bucketName);
        return bucketConfig;
    }

    @Override
    public BucketConfig replaceConfig(String bucketName, ReplaceConfigurationDto request) {
        log.info("Demande de remplacement de la config : {} avec {}", bucketName, request);
        final Bucket bucket = getBucket(bucketName);
        final BucketConfiguration newConfiguration = request.getConfig().toBucketConfiguration();
        bucket.replaceConfiguration(newConfiguration, request.getTokensInheritanceStrategy());
        bucketsConfiguration.getConfig().put(bucketName, request.getConfig());
        log.info("Replace Config {} depuis {}, resultat = {}", bucketName, request, newConfiguration);
        return request.getConfig();
    }

    @Override
    public BucketConfig replaceConfigUsing(String bucketName, ReplaceConfigurationDto request) {
        log.info("Demande de remplacement de la config : {} avec {}", bucketName, request);
        final BucketConfig using = getBucketConfig(request.getUsingConfigName());
        return replaceConfig(bucketName, request.toBuilder()
                .usingConfigName(null)
                .config(using)
                .build());
    }


    @Override
    public ConsumptionProbeDto tryConsumeAndReturnRemaining(String bucketName, long numTokens, UserInfoDto userInfo) {
        ZonedDateTime now = Instant.now().atZone(ZoneId.systemDefault());
        final ConsumptionProbe consumptionProbe = getBucket(bucketName).tryConsumeAndReturnRemaining(numTokens);
        final ConsumptionProbeDto dto = mapper.map(consumptionProbe);
        final StateConsumptionProbeDto state = StateConsumptionProbeDto.builder()
                .bucketName(bucketName)
                .instant(now)
                .consumptionProbe(dto)
                .build();
        stateConsumptionProbe.put(bucketName, state);
        log.info("tryConsumeAndReturnRemaining({}, {}, {}) => {}", bucketName, numTokens, userInfo, dto);
        return dto;
    }

    @Override
    public void addTokens(String bucketName, long tokensToAdd) {
        final Bucket bucket = getBucket(bucketName);
        bucket.addTokens(tokensToAdd);
        log.info("addTokens({}, {}) => {} available tokens", bucketName, tokensToAdd, bucket.getAvailableTokens());
    }

    @Override
    public void resetConfig() {
        bucketsConfiguration.reset();
        cache = new ConcurrentHashMap<>();
        stateConsumptionProbe = new ConcurrentHashMap<>();
    }

    @Override
    public Map<String, StateConsumptionProbeDto> getStateConsumptionProbe() {
        return stateConsumptionProbe;
    }
}
