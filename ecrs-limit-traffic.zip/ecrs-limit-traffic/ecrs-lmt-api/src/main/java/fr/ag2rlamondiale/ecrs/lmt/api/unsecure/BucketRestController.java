package fr.ag2rlamondiale.ecrs.lmt.api.unsecure;

import fr.ag2rlamondiale.ecrs.lmt.business.IBucketFacade;
import fr.ag2rlamondiale.ecrs.lmt.config.LmtRoles;
import fr.ag2rlamondiale.ecrs.lmt.configuration.BucketConfig;
import fr.ag2rlamondiale.ecrs.lmt.dto.ConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.ReplaceConfigurationDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.StateConsumptionProbeDto;
import fr.ag2rlamondiale.ecrs.lmt.dto.UserInfoDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.Map;

@Api(
        value = "API s'appuyant sur la librairie bucket4j",
        description = "Voir documentation g\u00E9n\u00E9rale depuis https://github.com/vladimir-bukhtoyarov/bucket4j")
@RestController
@RequestMapping("/api/public/bucket")
@Secured(LmtRoles.ROLE_EXTERNAL)
public class BucketRestController {

    @Autowired
    private IBucketFacade bucketFacade;

    @ApiOperation("Demande de N ticket(s) pour Bucket bucketName")
    @PostMapping("try-consume/{bucketName}")
    public ConsumptionProbeDto tryConsumeAndReturnRemaining(
            @PathVariable("bucketName") String bucketName,
            @RequestParam(value = "numTokens", required = false) Long numTokens,
            @RequestBody(required = false) UserInfoDto userInfo) {
        return bucketFacade.tryConsumeAndReturnRemaining(bucketName, numTokens != null ? numTokens : 1, userInfo);
    }


    @ApiOperation("Rendre N ticket(s) dans le Bucket bucketName")
    @PostMapping("add-tokens/{bucketName}")
    public void addTokens(@PathVariable("bucketName") String bucketName,
                          @RequestParam(value = "numTokens", required = false) Long numTokens) {
        bucketFacade.addTokens(bucketName, numTokens != null ? numTokens : 1);
    }

    @ApiOperation("Retourne l'etat des Buckets")
    @GetMapping("state")
    public Map<String, StateConsumptionProbeDto> getStates() {
        return bucketFacade.getStateConsumptionProbe();
    }

    @ApiOperation("Retourne l'etat du Bucket bucketName")
    @GetMapping("state/{bucketName}")
    public StateConsumptionProbeDto getStateBucket(
            @PathVariable(value = "bucketName") String bucketName) {
        return bucketFacade.getStateConsumptionProbe().get(bucketName);
    }

    @ApiOperation("Retourne la liste des Buckets configures")
    @GetMapping("configuration")
    public Collection<String> getBucketNames() {
        return bucketFacade.getBucketNames();
    }

    @ApiOperation("RESET de la configuration")
    @PostMapping("configuration-reset")
    public void resetConfig() {
        bucketFacade.resetConfig();
    }

    @ApiOperation("Retourne la configuration courante du Bucket bucketName")
    @GetMapping("configuration/{bucketName}")
    public BucketConfig getBucketConfiguration(@PathVariable("bucketName") String bucketName) {
        return bucketFacade.getBucketConfig(bucketName);
    }

    @ApiOperation(
            value = "Modifie la configuration du Bucket bucketName",
            notes = "L'id\u00E9e g\u00E9n\u00E9rale est de d\u00E9finir la capacit\u00E9 d'un bucket pour un temps donné et une strat\u00E9gie (limitation) de consommation et de r\u00E9-alimentation des tickets." +
                    "\n2 usages de cette API : " +
                    "\n1. Remplacer la confguration du Bucket bucketName en utilisant une configuration pré-intégrée dans l'application - utiliser uniquement les propriétés usingConfigName & tokensInheritanceStrategy (PROPORTIONALLY, AS_IS, RESET, ADDITIVE)"+
                    "\n2. Créer une Configuration de toute pièce pour le Bucket bucketName - utiliser les propriétés config & tokensInheritanceStrategy"+
                    "\nvoir https://github.com/vladimir-bukhtoyarov/bucket4j/blob/master/doc-pages/basic-usage.md")
    @PostMapping("configuration/{bucketName}")
    public BucketConfig replaceConfig(
            @PathVariable("bucketName") String bucketName,
            @RequestBody ReplaceConfigurationDto request) {
        if (request.getUsingConfigName() != null) {
            return bucketFacade.replaceConfigUsing(bucketName, request);
        }

        return bucketFacade.replaceConfig(bucketName, request);
    }
}
