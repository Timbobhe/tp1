package fr.ag2rlamondiale.ecrs.lmt.mapping;

import fr.ag2rlamondiale.ecrs.lmt.dto.ConsumptionProbeDto;
import io.github.bucket4j.ConsumptionProbe;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.concurrent.TimeUnit;

@Mapper(componentModel = "spring")
public interface Bucket4jMapper {

    @Mapping(source = "nanosToWaitForRefill", target = "secToWaitForRefill", qualifiedByName = "mapNanoTosecToWaitForRefill")
    ConsumptionProbeDto map(ConsumptionProbe cp);

    @Named("mapNanoTosecToWaitForRefill")
    default long mapNanoTosecToWaitForRefill(long nanosToWaitForRefill) {
        return TimeUnit.SECONDS.convert(nanosToWaitForRefill, TimeUnit.NANOSECONDS);
    }
}
