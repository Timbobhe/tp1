package fr.ag2rlamondiale.ecrs.lmt.configuration;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationPropertiesBinding;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Data
@Component
@ConfigurationPropertiesBinding
public class BandwidthConfigConverter implements Converter<String, List<BandwidthConfig>> {

    @Override
    public List<BandwidthConfig> convert(String json) {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true);
        objectMapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
        final List<BandwidthConfig> bandwidthConfigs;
        try {
            bandwidthConfigs = objectMapper.readValue(json, new TypeReference<>() {
            });
            return bandwidthConfigs;
        } catch (JsonProcessingException e) {
            log.error("Erreur pendant la conversion de {} en BandwidthConfig[]", json, e);
            throw new ConfigurationException(e);
        }
    }
}
