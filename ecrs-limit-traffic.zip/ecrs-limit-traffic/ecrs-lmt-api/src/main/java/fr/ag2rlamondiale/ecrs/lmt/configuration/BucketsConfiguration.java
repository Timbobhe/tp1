package fr.ag2rlamondiale.ecrs.lmt.configuration;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Data
@Component
@ConfigurationProperties(prefix = "buckets")
public class BucketsConfiguration implements InitializingBean {
    public static final String NIE = "nie";

    private Map<String, BucketConfig> config = new ConcurrentHashMap<>();
    private Map<String, BucketConfig> initial = new ConcurrentHashMap<>();

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("BUCKETS CONFIG {}", this);
        config.forEach((s, bucketConfig) -> {
            log.info("BUCKETS '{}' CONFIG {}", s, bucketConfig.toBucketConfiguration());
            initial.put(s, bucketConfig.dup());
        });
    }

    public BucketConfig get(String key) {
        return config.get(key);
    }

    public void reset() {
        log.info(">>> Reset config <<<");
        final Map<String, BucketConfig> cc = new ConcurrentHashMap<>();
        initial.forEach((s, bucketConfig) -> cc.put(s, bucketConfig.dup()));
        config = cc;
    }
}
