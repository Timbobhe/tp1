package fr.ag2rlamondiale.ecrs.lmt.configuration;

@SuppressWarnings("java:S115")
public enum RefillType {
    greedy,
    intervally
}
