package fr.ag2rlamondiale.ecrs.lmt.configuration;

import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import io.github.bucket4j.Refill;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class RefillConfig {
    private RefillType type;
    private long tokens;

    @JsonPropertyDescription("Format (?<value>\\d+)\\s+(?<unit>days|hours|minutes|seconds|millis|nanos)")
    @ApiModelProperty(value = "Format (?<value>\\d+)\\s+(?<unit>days|hours|minutes|seconds|millis|nanos)", example = "10 days|hours|minutes|seconds|millis|nanos")
    private String period;

    public Refill toRefill() {
        if (type == null) {
            throw new ConfigurationException("RefillType null");
        }

        switch (type) {
            case greedy:
                return Refill.greedy(tokens, DurationConfig.fromString(period).toDuration());
            case intervally:
                return Refill.intervally(tokens, DurationConfig.fromString(period).toDuration());
            default:
                throw new ConfigurationException("RefillType non gere : " + type);
        }
    }

    public RefillConfig dup() {
        return toBuilder().build();
    }
}
