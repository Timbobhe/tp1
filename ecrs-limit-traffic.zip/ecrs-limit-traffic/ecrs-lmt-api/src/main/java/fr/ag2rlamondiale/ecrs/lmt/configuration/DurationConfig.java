package fr.ag2rlamondiale.ecrs.lmt.configuration;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DurationConfig {
    private long value;
    private DurationUnit unit;

    public Duration toDuration() {
        return Duration.of(value, unit.getChronoUnit());
    }

    public static DurationConfig fromString(String string) {
        final Pattern pattern = Pattern.compile("(?<value>\\d+)\\s+(?<unit>" + DurationUnit.toRegexPattern() + ")");
        final Matcher matcher = pattern.matcher(string);
        if (matcher.matches()) {
            return DurationConfig.builder()
                    .value(Long.parseLong(matcher.group("value")))
                    .unit(DurationUnit.valueOf(matcher.group("unit")))
                    .build();
        }
        throw new ConfigurationException("Impossible de construire une DurationConfig a partir de " + string + " => pattern = " + pattern);
    }


    @Override
    public String toString() {
        return String.format("%s %s", value, unit);
    }
}
