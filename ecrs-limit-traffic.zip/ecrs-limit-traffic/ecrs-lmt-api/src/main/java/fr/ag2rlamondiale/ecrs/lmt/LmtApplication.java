package fr.ag2rlamondiale.ecrs.lmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LmtApplication {
	public static void main(String[] args) {
		SpringApplication.run(LmtApplication.class, args);
	}
}
