package fr.ag2rlamondiale.ecrs.lmt.api.unsecure;

import fr.ag2rlamondiale.ecrs.lmt.YamlFileApplicationContextInitializer;
import fr.ag2rlamondiale.ecrs.lmt.business.IBucketFacade;
import fr.ag2rlamondiale.ecrs.lmt.business.impl.BucketFacadeImpl;
import fr.ag2rlamondiale.ecrs.lmt.config.WebSecurityConfig;
import fr.ag2rlamondiale.ecrs.lmt.mapping.Bucket4jMapper;
import fr.ag2rlamondiale.ecrs.lmt.mapping.Bucket4jMapperImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.test.context.ContextConfiguration;

@ComponentScan("fr.ag2rlamondiale.ecrs.lmt")
@ContextConfiguration(initializers = {TestBucketRestControllerConfig.class})
@Configuration
@Import(WebSecurityConfig.class)
public class TestBucketRestControllerConfig extends YamlFileApplicationContextInitializer {

    @Bean
    IBucketFacade bucketFacade() {
        return new BucketFacadeImpl();
    }

    @Bean
    Bucket4jMapper mapper() {
        return new Bucket4jMapperImpl();
    }

    @Override
    protected String getResourceLocation() {
        return "classpath:/BucketFacadeImplTest.yaml";
    }
}
