package fr.ag2rlamondiale.ecrs.lmt;

import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.util.List;

public abstract class YamlFileApplicationContextInitializer
        implements ApplicationContextInitializer<ConfigurableApplicationContext> {

    /***
     * Return location of a YAML file, e.g.: classpath:file.yml
     *
     * @return YAML file location
     */
    protected abstract String getResourceLocation();

    @Override
    public void initialize(ConfigurableApplicationContext applicationContext) {
        try {
            Resource resource = applicationContext.getResource(getResourceLocation());
            YamlPropertySourceLoader sourceLoader = new YamlPropertySourceLoader();
            List<PropertySource<?>> yamlTestProperties = sourceLoader.load("yamlTestProperties", resource);
            yamlTestProperties.forEach(f -> applicationContext.getEnvironment().getPropertySources().addFirst(f));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
