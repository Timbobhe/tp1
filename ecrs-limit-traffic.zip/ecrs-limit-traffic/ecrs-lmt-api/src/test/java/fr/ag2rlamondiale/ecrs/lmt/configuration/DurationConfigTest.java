package fr.ag2rlamondiale.ecrs.lmt.configuration;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DurationConfigTest {

    @Test
    void test_toRegex() throws Exception {
        final DurationConfig durationConfig = DurationConfig.fromString("10 minutes");
        assertEquals(10, durationConfig.getValue());
        assertEquals(DurationUnit.minutes, durationConfig.getUnit());
    }
}
