package fr.ag2rlamondiale.ecrs.lmt.configuration;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ConfigurationExceptionTest {
    @Test
    void test_1() throws Exception {
        assertNull(new ConfigurationException().getMessage());
        assertEquals("message", new ConfigurationException("message").getMessage());
        assertEquals("message", new ConfigurationException("message", new Exception()).getMessage());
        assertNotNull(new ConfigurationException("message", new Exception()).getCause());
        assertNotNull(new ConfigurationException(new Exception()).getCause());
    }
}
