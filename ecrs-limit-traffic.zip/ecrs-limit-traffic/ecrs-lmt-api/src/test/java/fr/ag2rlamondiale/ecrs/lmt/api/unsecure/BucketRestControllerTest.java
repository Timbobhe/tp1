package fr.ag2rlamondiale.ecrs.lmt.api.unsecure;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ag2rlamondiale.ecrs.lmt.configuration.*;
import fr.ag2rlamondiale.ecrs.lmt.dto.ReplaceConfigurationDto;
import io.github.bucket4j.TokensInheritanceStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.web.SpringJUnitWebConfig;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

//@SpringBootTest
@ActiveProfiles("local")
@SpringJUnitWebConfig
@ContextConfiguration(classes = TestBucketRestControllerConfig.class)
@WebMvcTest(BucketRestController.class)
class BucketRestControllerTest {

    @Autowired
    private MockMvc mockMvc;


    private final String basicAuthUser = "userEcrs";

    private final String basicAuthPassword = "a9fab1ce2b62";

    @BeforeEach
    void setUp() throws Exception {
        this.mockMvc.perform(post("/api/public/bucket/configuration-reset").headers(basicAuthHeaders()))
                .andExpect(status().isOk());
    }

    @Test
    void tryConsumeAndReturnRemaining() throws Exception {
        for (int i = 1; i <= 10; i++) {
            tryConsumeAndReturnRemaining("-testNie", null, true)
                    .andExpect(jsonPath("$.consumed").value(true));
        }

        tryConsumeAndReturnRemaining("-testNie", null, true)
                .andExpect(jsonPath("$.consumed").value(false));
    }

    @Test
    void tryConsumeAndReturnRemaining_withoutAuth() throws Exception {
        tryConsumeAndReturnRemaining("-testNie", null, false);
    }

    @Test
    void addTokens_withoutAuth() throws Exception {
        addTokens("-testNie", 5l, false);
    }

    @Test
    void addTokens() throws Exception {
        for (int i = 1; i <= 10; i++) {
            tryConsumeAndReturnRemaining("-testNie", null, true)
                    .andExpect(jsonPath("$.consumed").value(true));
        }

        tryConsumeAndReturnRemaining("-testNie", null, true)
                .andExpect(jsonPath("$.consumed").value(false));

        addTokens("-testNie", 5l, true);

        for (int i = 1; i <= 5; i++) {
            tryConsumeAndReturnRemaining("-testNie", null, true)
                    .andExpect(jsonPath("$.consumed").value(true));
        }
    }

    @Test
    void getBucketNames() throws Exception {
        this.mockMvc.perform(get("/api/public/bucket/configuration").headers(basicAuthHeaders()))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(content().string(containsString("-testNie")));
    }

    @Test
    void getBucketConfiguration() throws Exception {
        this.mockMvc.perform(get("/api/public/bucket/configuration/{bucketName}", "-testNie").headers(basicAuthHeaders()))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.bandwidths[0].id").value("default"))
                .andExpect(jsonPath("$.bandwidths[0].capacity").value(10));
    }

    @Test
    void replaceConfig_using() throws Exception {
        ReplaceConfigurationDto request = ReplaceConfigurationDto.builder()
                .usingConfigName("-testOther")
                .tokensInheritanceStrategy(TokensInheritanceStrategy.RESET)
                .build();
        this.mockMvc.perform(
                        post("/api/public/bucket/configuration/{bucketName}", "-testNie")
                                .headers(basicAuthHeaders())
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(json(request))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.bandwidths[0].id").value("default"))
                .andExpect(jsonPath("$.bandwidths[0].capacity").value(20));
    }

    @Test
    void replaceConfig_full() throws Exception {
        ReplaceConfigurationDto request = ReplaceConfigurationDto.builder()
                .config(BucketConfig.builder()
                        .bandwidths(List.of(BandwidthConfig.builder()
                                .type(BandwidthType.classic)
                                .id("default")
                                .capacity(30)
                                .refill(RefillConfig.builder()
                                        .type(RefillType.intervally)
                                        .tokens(30)
                                        .period("1 minutes")
                                        .build())
                                .build()))
                        .build())
                .tokensInheritanceStrategy(TokensInheritanceStrategy.RESET)
                .build();
        this.mockMvc.perform(
                        post("/api/public/bucket/configuration/{bucketName}", "-testNie")
                                .headers(basicAuthHeaders())
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(json(request))
                )
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.bandwidths[0].id").value("default"))
                .andExpect(jsonPath("$.bandwidths[0].capacity").value(30));
    }


    static String json(Object object) throws JsonProcessingException {
        return new ObjectMapper().writeValueAsString(object);
    }


    ResultActions tryConsumeAndReturnRemaining(String bucketName, Long numTokens, boolean withAuth) throws Exception {
        final MockHttpServletRequestBuilder request = post("/api/public/bucket/try-consume/{bucketName}", "-testNie");
        if (withAuth) {
            request.headers(basicAuthHeaders());
        }

        if (numTokens != null) {
            request.queryParam("numTokens", numTokens.toString());
        }

        final ResultActions resultActions = this.mockMvc.perform(request)
                .andDo(print());

        if (withAuth) {
            resultActions
                    .andExpect(status().isOk())
                    .andExpect(content().contentType(MediaType.APPLICATION_JSON));
        } else {
            resultActions
                    .andExpect(status().is4xxClientError());
        }

        return resultActions;
    }

    void addTokens(String bucketName, Long numTokens, boolean withAuth) throws Exception {
        final MockHttpServletRequestBuilder request = post("/api/public/bucket/add-tokens/{bucketName}", "-testNie");
        if (withAuth) {
            request.headers(basicAuthHeaders());
        }
        if (numTokens != null) {
            request.queryParam("numTokens", numTokens.toString());
        }

        final ResultActions resultActions = this.mockMvc.perform(request)
                .andDo(print());

        if (withAuth) {
            resultActions
                    .andExpect(status().isOk());
        } else {
            resultActions.andExpect(status().is4xxClientError());
        }
    }


    private HttpHeaders basicAuthHeaders() {
        final HttpHeaders httpHeaders = new HttpHeaders();
        String auth = basicAuthUser + ":" + basicAuthPassword;
        byte[] encodedAuth = Base64.getEncoder().encode(auth.getBytes(StandardCharsets.US_ASCII));
        String authHeader = "Basic " + new String(encodedAuth);
        httpHeaders.set("Authorization", authHeader);
        return httpHeaders;
    }

}
