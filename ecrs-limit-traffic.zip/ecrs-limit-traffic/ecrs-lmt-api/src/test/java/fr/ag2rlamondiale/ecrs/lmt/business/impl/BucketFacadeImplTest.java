package fr.ag2rlamondiale.ecrs.lmt.business.impl;

import fr.ag2rlamondiale.ecrs.lmt.YamlFileApplicationContextInitializer;
import fr.ag2rlamondiale.ecrs.lmt.configuration.*;
import fr.ag2rlamondiale.ecrs.lmt.dto.ReplaceConfigurationDto;
import io.github.bucket4j.TokensInheritanceStrategy;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringJUnitConfig
@SpringBootTest
@ContextConfiguration(initializers = {BucketFacadeImplTest.class})
class BucketFacadeImplTest extends YamlFileApplicationContextInitializer {

    @Autowired
    private BucketFacadeImpl bucketFacade;

    @Autowired
    private BucketsConfiguration bucketsConfiguration;

    @Override
    protected String getResourceLocation() {
        return "classpath:/BucketFacadeImplTest.yaml";
    }

    @BeforeEach
    void setUp() {
        bucketFacade.resetConfig();
    }


    @Test
    void test_init() throws Exception {
        assertNotNull(bucketFacade);
    }

    @Test
    void test_config() {
        final BucketConfig nie = bucketFacade.getBucketConfig("nie");
        assertNotNull(nie);
        assertEquals(1, nie.getBandwidths().size());
        final BandwidthConfig bc = nie.getBandwidths().get(0);
        assertEquals(BandwidthType.classic, bc.getType());
        assertEquals(10, bc.getCapacity());
        assertNotNull(bc.getPeriod());
        assertNotNull(bc.getRefill());
        assertEquals(RefillType.intervally, bc.getRefill().getType());
    }

    @Test
    void test_config2() {
        final RefillConfig refillConfig = RefillConfig.builder()
                .type(RefillType.intervally)
                .tokens(10)
                .period(DurationConfig.builder()
                        .value(10)
                        .unit(DurationUnit.minutes)
                        .build()
                        .toString())
                .build();

        final BandwidthConfig bandwidthConfig = BandwidthConfig.builder()
                .type(BandwidthType.classic)
                .capacity(10)
                .refill(refillConfig)
                .build();

        final BucketConfig bucketConfig = BucketConfig.builder()
                .bandwidths(List.of(bandwidthConfig))
                .build();

        final BucketConfig nie = bucketFacade.getBucketConfig("nie");
        assertNotNull(nie);
        assertEquals(1, nie.getBandwidths().size());
        final BandwidthConfig bc = nie.getBandwidths().get(0);
        assertEquals(BandwidthType.classic, bc.getType());
        assertEquals(10, bc.getCapacity());
        assertNotNull(bc.getPeriod());
        assertNotNull(bc.getRefill());
        assertEquals(RefillType.intervally, bc.getRefill().getType());
    }

    @Test
    void test_tryConsume() throws Exception {
        for (int i = 1; i <= 10; i++) {
            assertTrue(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
        }
        assertFalse(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
    }


    @Test
    void test_replaceConfig() throws Exception {
        final BucketConfig other = bucketsConfiguration.get("other");
        ReplaceConfigurationDto request = new ReplaceConfigurationDto();
        request.setConfig(other);
        request.setTokensInheritanceStrategy(TokensInheritanceStrategy.RESET);
        final BucketConfig newNieConfig = bucketFacade.replaceConfig("nie", request);
        for (int i = 1; i <= 20; i++) {
            assertTrue(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
        }
        assertFalse(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
    }

    @Test
    void test_replaceConfigUsing() throws Exception {
        ReplaceConfigurationDto request = new ReplaceConfigurationDto();
        request.setUsingConfigName("other");
        request.setTokensInheritanceStrategy(TokensInheritanceStrategy.RESET);
        final BucketConfig newNieConfig = bucketFacade.replaceConfigUsing("nie", request);
        for (int i = 1; i <= 20; i++) {
            assertTrue(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
        }
        assertFalse(bucketFacade.tryConsumeAndReturnRemaining("nie", 1, null).isConsumed());
    }

}
