package fr.ag2rlamondiale.ecrs.lmt.bucket4j;

import fr.ag2rlamondiale.ecrs.lmt.configuration.*;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bucket4j;
import io.github.bucket4j.Refill;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;


class TestBucket4j {

    @Test
    void test_simple() throws Exception {
        Refill refill = Refill.intervally(10, Duration.ofMinutes(1));
        Bandwidth limit = Bandwidth.classic(10, refill);
        Bucket bucket = Bucket4j.builder()
                .addLimit(limit)
                .build();

        for (int i = 1; i <= 10; i++) {
            assertTrue(bucket.tryConsume(1));
        }
        assertFalse(bucket.tryConsume(1));
    }

    @Test
    void test_simple_fromConfig() throws Exception {
        final RefillConfig refillConfig = RefillConfig.builder()
                .type(RefillType.intervally)
                .tokens(10)
                .period(DurationConfig.builder()
                        .value(10)
                        .unit(DurationUnit.minutes)
                        .build()
                        .toString())
                .build();

        final BandwidthConfig bandwidthConfig = BandwidthConfig.builder()
                .type(BandwidthType.classic)
                .capacity(10)
                .refill(refillConfig)
                .build();

        final BucketConfig bucketConfig = BucketConfig.builder()
                .bandwidths(List.of(bandwidthConfig))
                .build();

        final Bucket bucket = bucketConfig.toBucket();

        for (int i = 1; i <= 10; i++) {
            assertTrue(bucket.tryConsume(1));
        }
        assertFalse(bucket.tryConsume(1));
    }
}
